# Runtime, native libraries and tooling

How the embedded Ubuntu/Python runtime, the native libraries and the asset encryption fit together,
and what you must do once to build a working APK. For code structure see `../ARCHITECTURE.md`.

## 1. Runtime overview

The app targets **ARM64 Android**. It ships an Ubuntu 24.04 ARM64 userland (Python 3.12, pip, venv) as an encrypted archive and runs
it with **PRoot**. On first start (`InstallViewModel` → `UbuntuManager`) the app decrypts and extracts the archive to a staging directory,
validates core paths and then switches to it (recovery uses the same staging approach). The archive is about 103 MB compressed and
expands to 400+ MB. Then `ProotManager` starts `/bin/bash` (and other guest processes) inside the rootfs.

## 2. PRoot native libraries (`app/src/main/jniLibs/arm64-v8a/`)

Android 10+ W^X/SELinux rules prevent executing binaries from app-writable storage, so PRoot and its loader must be installed by Android
as **native libraries**. The Kotlin runtime looks in `ApplicationInfo.nativeLibraryDir` and accepts both loader names.

| File | Notes |
|---|---|
| `libproot.so` | PRoot executable |
| `libproot-loader.so` or `libprootloader.so` | PRoot loader (name depends on the build: patched `oonid/pr` vs. Termux) |
| `libprootloader32.so` | optional 32-bit loader |
| `libtalloc.so`, `libandroid-shmem.so` | PRoot dependencies |
| `libptybridge.so` | PTY bridge, built from `native/pty_bridge.c` with `native/build.sh` |
| `libkeybridge.so` | asset-key bridge, built from `native/key_bridge.c` with `native/build_keybridge.sh` (see §4) |

The project never substitutes a fake or host-architecture binary. If the PRoot files are missing, install real ARM64 builds:
from Termux on the phone run `bash tools/install-proot-arm64-from-termux.sh` from the project root (it fetches Termux's ARM64 `proot`,
`talloc` and `libandroid-shmem` and places them in `jniLibs/arm64-v8a/`). The `oonid/pr` project documents the Android-specific
PRoot/loader design. A separate proprietary runtime (`coderredlab/proroot`) exists but its binaries must not be copied in without a license.

## 3. Encrypted runtime assets (`app/src/main/assets/runtime/`)

Only encrypted packages (format **PSR1**, AES-256-GCM) are stored. They are decrypted as a stream by `runtime/RuntimeAssetCipher` while
installing; GCM also detects modified or truncated packages.

| Asset | Contents | Used for |
|---|---|---|
| `system.psr` | Ubuntu 24.04 ARM64 minimal system image (XZ-compressed tar) with Python 3.12, pip, venv | first-run install and recovery |
| `lsp.psr` | Python language-server wheelhouse | installed on demand (`PythonLspRuntimeInstaller`) |
| `dbg.psr` | `debugpy` 1.8.22 universal wheel | extracted on first Debug-panel use into `/opt/pyspace-debugger/site-packages` and added through `PYTHONPATH` for debug sessions; project venvs are not modified |

`system.psr` is large and may be absent from source archives produced by tooling. Put it in `assets/runtime/` before building a release.
Never leave the plaintext `system_files.tar.xz` inside `assets/`.

Other asset: `assets/pyspace_test_runner.py` — stdlib-only test runner used by the Test Explorer.

## 4. How the key works (one extra build step)

The AES key is not a Kotlin constant. It is derived natively in `native/key_bridge.c` (split master-key bytes + SHA-256, same formula as
`tools/encrypt_runtime_asset.py`) and exposed through JNI as `libkeybridge.so`, the same pattern as `libptybridge.so`.
**Build it once in Termux on an ARM64 device**: `native/build_keybridge.sh` compiles it and copies it to `jniLibs/arm64-v8a/`.
Without it the app throws a clear `UnsatisfiedLinkError` the first time it installs a runtime.

What this protects: copying the `.psr` files out of the APK or device yields unusable ciphertext; reading Kotlin/Java code does not
reveal the key. What it does not: someone who disassembles `libkeybridge.so` can still recover the key. This raises the bar; no on-device
key is truly unextractable without a server.

### Encrypting assets
```
pip install cryptography            # Termux: pkg install python-cryptography
python3 tools/encrypt_runtime_asset.py /path/to/system_files.tar.xz app/src/main/assets/runtime/system.psr --verify
python3 tools/encrypt_runtime_asset.py /path/to/debugpy-1.8.22-py2.py3-none-any.whl app/src/main/assets/runtime/dbg.psr --verify
```

### Changing the key
1. Create a new 32-byte key in `tools/runtime-key.hex`.
2. Split it as `PART_A xor PART_B` and update both arrays in `native/key_bridge.c`.
3. Rebuild with `native/build_keybridge.sh`.
4. Re-encrypt every runtime asset (`system.psr`, `lsp.psr`, `dbg.psr`) with `tools/encrypt_runtime_asset.py`.

**Release hygiene:** `tools/` (it contains `runtime-key.hex`) is not packaged into the APK, but it must not be published with the source
or shared archives.

## 5. Release build (R8) notes

`release` has `minifyEnabled` and `shrinkResources` on. `proguard-rules.pro` keeps the JNI-bound classes (`PtyNative`,
`RuntimeAssetCipher`) named and keeps constructors of every `androidx.lifecycle.ViewModel` subclass
(`-keep class * extends androidx.lifecycle.ViewModel { <init>(...); }`). The second rule exists because `ViewModelProvider` builds
ViewModels reflectively; without it a release-only crash (`NoSuchMethodException … <init>`) occurs. Everything else is shrunk and obfuscated.

## 6. Always-reachable crash viewer

A second launcher icon, **PySpace Crash Log**, opens `CrashViewerActivity` in its own process (`android:process=":viewer"`) using plain
Android Views (no Compose/Koin). `UbuntuTerminalApplication` skips Koin and services in that process. `CrashLog.install()` runs first in
`Application.onCreate`, so even a crash during Koin startup is recorded to `files/last_crash.txt`. The viewer offers Copy / Share / Clear.

## 7. Permissions and manifest

`INTERNET`, `ACCESS_NETWORK_STATE`, `FOREGROUND_SERVICE` (+ `SPECIAL_USE`), `POST_NOTIFICATIONS`, `CAMERA`.
`usesCleartextTraffic=true` is required for `http://127.0.0.1` and LAN development servers shown in the built-in browser.

## 8. Third-party notices

Bundled editor fonts and their licenses are under `THIRD_PARTY_NOTICES/fonts/` (SIL OFL 1.1 for JetBrains Mono, Fira Code, IBM Plex Mono,
Source Code Pro; Cascadia archive review note). Keep these files in any distribution.
