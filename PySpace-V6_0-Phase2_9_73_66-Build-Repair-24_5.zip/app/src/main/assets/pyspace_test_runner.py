#!/usr/bin/env python3
"""Offline-first PySpace test runner. Uses only stdlib; pytest/coverage are optional project tools."""
import argparse
import datetime
import inspect
import json
import html
import os
import sys
import time
import traceback
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

PREFIX = "PYSPACE_EVENT:"

def emit(kind, **payload):
    data = {"type": kind, **payload}
    # A leading newline prevents pytest's compact progress reporter (., F, s)
    # from prefixing the protocol frame on the same physical output line.
    sys.stdout.write("\n" + PREFIX + json.dumps(data, ensure_ascii=False, separators=(",", ":")) + "\n")
    sys.stdout.flush()

def relpath(path, root):
    try:
        return str(Path(path).resolve().relative_to(Path(root).resolve()))
    except Exception:
        return str(path or "")

def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item

def unittest_case(test, root):
    tid = test.id()
    method = getattr(test, test._testMethodName, None)
    try:
        path = inspect.getsourcefile(test.__class__) or ""
        line = inspect.getsourcelines(test.__class__)[1]
        method_path = inspect.getsourcefile(method) if method is not None else None
        if method_path and "/unittest/" not in method_path.replace("\\", "/"):
            path = method_path
            try: line = inspect.getsourcelines(method)[1]
            except Exception: pass
    except Exception:
        path, line = "", 0
    return {"id": tid, "name": tid.split(".")[-1], "file": relpath(path, root), "line": line,
            "class": test.__class__.__name__, "status": "NOT_RUN", "duration": 0.0}

class Result(unittest.TestResult):
    def __init__(self, root):
        super().__init__()
        self.root = root
        self.started = {}
        self.rows = []
    def startTest(self, test):
        super().startTest(test)
        self.started[test.id()] = time.monotonic()
    def _finish(self, test, status, detail=""):
        row = unittest_case(test, self.root)
        row.update(status=status, duration=round(time.monotonic() - self.started.get(test.id(), time.monotonic()), 4), detail=str(detail))
        self.rows.append(row)
        emit("result", **row)
    def addSuccess(self, test):
        super().addSuccess(test); self._finish(test, "PASSED")
    def addFailure(self, test, err):
        super().addFailure(test, err); self._finish(test, "FAILED", "".join(traceback.format_exception(*err)))
    def addError(self, test, err):
        super().addError(test, err); self._finish(test, "FAILED", "".join(traceback.format_exception(*err)))
    def addSkip(self, test, reason):
        super().addSkip(test, reason); self._finish(test, "SKIPPED", reason)
    def addExpectedFailure(self, test, err):
        super().addExpectedFailure(test, err); self._finish(test, "XFAILED", "Expected failure")
    def addUnexpectedSuccess(self, test):
        super().addUnexpectedSuccess(test); self._finish(test, "XPASSED", "Unexpected success")

def write_junit(rows, path, elapsed):
    root = ET.Element("testsuite", name="PySpace", tests=str(len(rows)),
        failures=str(sum(x["status"] in ("FAILED", "XPASSED") for x in rows)),
        skipped=str(sum(x["status"] in ("SKIPPED", "XFAILED") for x in rows)), time=str(round(elapsed, 4)))
    for row in rows:
        tc = ET.SubElement(root, "testcase", name=row["name"], classname=row.get("class", ""),
                           file=row.get("file", ""), line=str(row.get("line", 0)), time=str(row.get("duration", 0)))
        if row["status"] == "FAILED":
            ET.SubElement(tc, "failure", message="Test failed", type="AssertionError").text = row.get("detail", "")
        elif row["status"] in ("SKIPPED", "XFAILED"):
            ET.SubElement(tc, "skipped", message=row.get("detail", "Skipped"))
        elif row["status"] == "XPASSED":
            ET.SubElement(tc, "failure", message="Unexpected success", type="UnexpectedSuccess").text = row.get("detail", "Unexpected success")
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    ET.ElementTree(root).write(path, encoding="utf-8", xml_declaration=True)

def write_json(rows, path, elapsed, framework):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    payload = {"framework": framework, "duration": round(elapsed, 4), "tests": rows}
    Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

def write_html(rows, path, elapsed, framework):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    counts = {name: sum(row["status"] == name for row in rows) for name in ("PASSED", "FAILED", "SKIPPED", "XFAILED", "XPASSED")}
    cards = "".join('<div class="card"><b>' + str(counts[name]) + '</b><span>' + name.title() + '</span></div>' for name in counts)
    body = []
    for row in rows:
        status = row.get("status", "NOT_RUN")
        detail = html.escape(row.get("detail", ""))
        body.append('<tr><td>' + html.escape(row.get("name", "")) + '</td><td>' + html.escape(row.get("file", "")) + ':' + str(row.get("line", 0)) + '</td><td><span class="' + status.lower() + '">' + status + '</span></td><td>' + str(row.get("duration", 0)) + 's</td><td><details><summary>Details</summary><pre>' + detail + '</pre></details></td></tr>')
    generated = html.escape(datetime.datetime.now().isoformat(timespec="seconds"))
    document = ('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>PySpace Test Report</title>'
        '<style>body{font:14px system-ui,sans-serif;margin:24px;background:#10151d;color:#e7edf5}h1{margin-bottom:4px}.muted{color:#9aa8ba}.cards{display:flex;gap:10px;flex-wrap:wrap;margin:20px 0}.card{background:#1c2633;padding:14px 20px;border-radius:10px;min-width:80px}.card b{display:block;font-size:24px}.card span{font-size:11px;color:#aab6c6}table{width:100%;border-collapse:collapse;background:#1c2633}th,td{text-align:left;padding:10px;border-bottom:1px solid #334052;vertical-align:top}pre{white-space:pre-wrap;max-width:600px}.passed{color:#65d48a}.failed,.xpassed{color:#ff7777}.skipped,.xfailed{color:#ffc66d}</style></head><body>'
        '<h1>PySpace Test Report</h1><div class="muted">Framework: ' + html.escape(framework) + ' · Duration: ' + format(elapsed, '.3f') + 's · Generated: ' + generated + '</div>'
        '<div class="cards">' + cards + '</div><table><thead><tr><th>Test</th><th>Location</th><th>Status</th><th>Duration</th><th>Details</th></tr></thead><tbody>' + ''.join(body) + '</tbody></table></body></html>')
    Path(path).write_text(document, encoding="utf-8")

class PytestPlugin:
    def __init__(self, root):
        self.root = root
        self.rows = {}
    def pytest_collection_finish(self, session):
        for item in session.items:
            location = item.location
            row = {"id": item.nodeid, "name": item.name, "file": relpath(location[0], self.root),
                   "line": int(location[1]) + 1 if location[1] is not None else 0,
                   "class": getattr(getattr(item, "cls", None), "__name__", ""), "status": "NOT_RUN", "duration": 0.0}
            self.rows[item.nodeid] = row
            emit("case", **row)
    def pytest_runtest_logreport(self, report):
        if report.when not in ("call", "setup", "teardown"):
            return
        if report.when != "call" and report.passed:
            return
        was_xfail = getattr(report, "wasxfail", None)
        status = "XPASSED" if report.passed and was_xfail else ("XFAILED" if report.skipped and was_xfail else ("PASSED" if report.passed else ("SKIPPED" if report.skipped else "FAILED")))
        old = self.rows.get(report.nodeid, {"id": report.nodeid, "name": report.nodeid.split("::")[-1], "file": "", "line": 0, "class": ""})
        detail = ""
        if report.failed:
            detail = str(report.longrepr)
        elif report.skipped:
            detail = str(getattr(report, "longrepr", "Skipped"))
        row = dict(old, status=status, duration=round(float(report.duration), 4), detail=detail)
        self.rows[report.nodeid] = row
        emit("result", **row)

def update_test_analytics(rows, report_dir, framework, elapsed):
    """Persist per-test outcomes and compare this run with each test's previous outcome."""
    Path(report_dir).mkdir(parents=True, exist_ok=True)
    history_path = os.path.join(report_dir, "test-history.json")
    try:
        with open(history_path, "r", encoding="utf-8") as handle:
            history = json.load(handle)
        if not isinstance(history, dict):
            history = {}
    except Exception:
        history = {}

    tests_history = history.get("tests", {})
    if not isinstance(tests_history, dict):
        tests_history = {}
    run_number = int(history.get("run_count", 0)) + 1
    changes = []
    flaky = []
    counts = {"new": 0, "regressions": 0, "fixed": 0, "unchanged": 0}
    valid_statuses = {"PASSED", "FAILED", "XPASSED", "SKIPPED", "XFAILED"}

    for row in rows:
        status = str(row.get("status", "NOT_RUN")).upper()
        if status not in valid_statuses:
            continue
        test_id = str(row.get("id") or (str(row.get("file", "")) + "::" + str(row.get("name", ""))))
        if not test_id:
            continue
        previous = tests_history.get(test_id, {})
        outcomes = previous.get("outcomes", []) if isinstance(previous, dict) else []
        if not isinstance(outcomes, list):
            outcomes = []
        previous_status = str(outcomes[-1].get("status", "")) if outcomes and isinstance(outcomes[-1], dict) else ""
        if not previous_status and run_number == 1:
            change = "BASELINE"
        elif not previous_status:
            change = "NEW"
            counts["new"] += 1
        elif previous_status == "PASSED" and status in ("FAILED", "XPASSED"):
            change = "REGRESSION"
            counts["regressions"] += 1
        elif previous_status in ("FAILED", "XPASSED") and status == "PASSED":
            change = "FIXED"
            counts["fixed"] += 1
        else:
            change = "UNCHANGED"
            counts["unchanged"] += 1
        changes.append({"id": test_id, "name": row.get("name", test_id), "file": row.get("file", ""),
                        "line": int(row.get("line", 0) or 0), "status": status,
                        "previousStatus": previous_status, "change": change,
                        "duration": float(row.get("duration", 0.0) or 0.0)})

        outcome = {"run": run_number, "status": status, "timestamp": datetime.datetime.now().isoformat(timespec="seconds")}
        outcomes = (outcomes + [outcome])[-20:]
        tests_history[test_id] = {"name": row.get("name", test_id), "file": row.get("file", ""),
                                  "line": int(row.get("line", 0) or 0), "outcomes": outcomes}
        recent = [str(item.get("status", "")) for item in outcomes if isinstance(item, dict)]
        stable = [value for value in recent if value in ("PASSED", "FAILED", "XPASSED")]
        if len(stable) >= 3 and any(value == "PASSED" for value in stable) and any(value in ("FAILED", "XPASSED") for value in stable):
            flaky.append({"id": test_id, "name": row.get("name", test_id), "file": row.get("file", ""),
                          "line": int(row.get("line", 0) or 0), "runs": len(stable),
                          "passed": sum(value == "PASSED" for value in stable),
                          "failed": sum(value in ("FAILED", "XPASSED") for value in stable),
                          "lastStatus": status})

    history["version"] = 1
    history["run_count"] = run_number
    history["tests"] = tests_history
    history["runs"] = (history.get("runs", []) + [{"run": run_number, "timestamp": datetime.datetime.now().isoformat(timespec="seconds"),
        "framework": framework, "duration": elapsed, "tests": len(rows), "counts": counts}])[-30:]
    temporary = history_path + ".tmp"
    with open(temporary, "w", encoding="utf-8") as handle:
        json.dump(history, handle, ensure_ascii=False, indent=2)
    os.replace(temporary, history_path)

    changes.sort(key=lambda item: (0 if item["change"] == "REGRESSION" else 1 if item["change"] == "FIXED" else 2, item["file"].lower(), item["name"].lower()))
    flaky.sort(key=lambda item: (-min(item["passed"], item["failed"]), item["file"].lower(), item["name"].lower()))
    emit("analytics", runNumber=run_number, counts=counts, changes=changes[:2000], flaky=flaky[:500],
         historyPath=history_path, message="Flaky detection needs at least 3 recorded outcomes per test and flags mixed pass/fail results in the latest 20 runs.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("discover", "run"), default="discover")
    parser.add_argument("--framework", choices=("auto", "pytest", "unittest"), default="auto")
    parser.add_argument("--target", action="append", default=[])
    parser.add_argument("--keyword", default="")
    parser.add_argument("--marker", default="")
    parser.add_argument("--fail-fast", action="store_true")
    parser.add_argument("--coverage", action="store_true")
    parser.add_argument("--reports", default=".pyspace-test-reports")
    args = parser.parse_args()
    root = os.getcwd()
    started = time.monotonic()
    framework = args.framework
    if args.mode == "run":
        Path(args.reports).mkdir(parents=True, exist_ok=True)
    pytest = None
    if framework in ("auto", "pytest"):
        try:
            import pytest as pytest_module
            pytest = pytest_module
            framework = "pytest"
        except Exception:
            if framework == "pytest":
                emit("error", message="pytest is not installed in this project's Python environment.")
                return 3
            framework = "unittest"
    emit("started", framework=framework, mode=args.mode, root=root)
    # Never let a previous run's JSON report masquerade as fresh coverage.
    if args.mode == "run":
        try:
            stale_report = os.path.join(root, args.reports, "coverage.json")
            if os.path.isfile(stale_report):
                os.remove(stale_report)
        except Exception:
            pass
    cov = None
    if args.coverage:
        try:
            import coverage
            cov = coverage.Coverage(data_file=os.path.join(root, args.reports, ".coverage"), source=[root],
                                    omit=["*/.venv/*", "*/venv/*", "*/site-packages/*", "*/.pyspace-test-reports/*"])
            cov.erase()
            cov.start()
        except Exception as exc:
            emit("warning", message="Coverage unavailable: install coverage in this project's environment to enable it. " + str(exc))
            cov = None
    exit_code = 0
    rows = []
    try:
        if framework == "pytest":
            plugin = PytestPlugin(root)
            pytest_args = ["--collect-only", "-q"] if args.mode == "discover" else ["-q", "--tb=short", "--junitxml=" + os.path.join(root, args.reports, "junit.xml")]
            if args.mode == "run":
                pytest_args += args.target
                if args.keyword: pytest_args += ["-k", args.keyword]
                if args.marker: pytest_args += ["-m", args.marker]
                if args.fail_fast: pytest_args += ["-x"]
            exit_code = int(pytest.main(pytest_args, plugins=[plugin]))
            rows = list(plugin.rows.values())
        else:
            loader = unittest.defaultTestLoader
            if args.mode == "discover" or not args.target:
                suite = loader.discover(".")
            else:
                suite = unittest.TestSuite()
                for target in args.target:
                    try: suite.addTests(loader.loadTestsFromName(target))
                    except Exception as exc: emit("error", message="Cannot load " + target + ": " + str(exc))
            tests = list(flatten(suite))
            if args.keyword:
                tests = [test for test in tests if args.keyword.lower() in test.id().lower()]
            if args.marker:
                emit("warning", message="Pytest markers are not supported by unittest; marker filter was ignored.")
            if args.mode == "discover":
                for test in tests: emit("case", **unittest_case(test, root))
            else:
                result = Result(root)
                runner = unittest.TextTestRunner(stream=sys.stdout, verbosity=2, failfast=args.fail_fast, resultclass=lambda *a, **kw: result)
                runner.run(unittest.TestSuite(tests))
                rows = result.rows
                write_junit(rows, os.path.join(root, args.reports, "junit.xml"), time.monotonic() - started)
                exit_code = 1 if result.failures or result.errors or result.unexpectedSuccesses else 0
    except SystemExit as exc:
        exit_code = int(exc.code or 0) if isinstance(exc.code, int) or exc.code is None else 2
    except BaseException as exc:
        emit("error", message=type(exc).__name__ + ": " + str(exc) + "\n" + traceback.format_exc())
        exit_code = 2
    if cov is not None:
        try:
            cov.stop(); cov.save()
            percent = round(cov.report(file=sys.stdout), 2)
            cov.html_report(directory=os.path.join(root, "htmlcov"))
            cov.json_report(outfile=os.path.join(root, args.reports, "coverage.json"))
            emit("coverage", percent=percent, html=os.path.join(root, "htmlcov"), json=os.path.join(root, args.reports, "coverage.json"))
        except Exception as exc:
            emit("warning", message="Coverage report could not be generated: " + str(exc))
    elapsed = round(time.monotonic() - started, 4)
    report_dir = os.path.join(root, args.reports)
    junit_path = os.path.join(report_dir, "junit.xml")
    html_path = os.path.join(report_dir, "index.html")
    json_path = os.path.join(report_dir, "results.json")
    if args.mode == "run":
        try:
            write_junit(rows, junit_path, time.monotonic() - started)
            write_html(rows, html_path, time.monotonic() - started, framework)
            write_json(rows, json_path, time.monotonic() - started, framework)
        except Exception as exc:
            emit("warning", message="Could not write one or more test reports: " + str(exc))
        passed = sum(x["status"] == "PASSED" for x in rows)
        failed = sum(x["status"] in ("FAILED", "XPASSED") for x in rows)
        skipped = sum(x["status"] == "SKIPPED" for x in rows)
        xfailed = sum(x["status"] == "XFAILED" for x in rows)
        update_test_analytics(rows, report_dir, framework, elapsed)
        emit("summary", total=len(rows), passed=passed, failed=failed, skipped=skipped, xfailed=xfailed,
             duration=elapsed, exitCode=exit_code, report=junit_path, htmlReport=html_path, jsonReport=json_path)
    emit("finished", exitCode=exit_code, duration=elapsed)
    return exit_code

if __name__ == "__main__":
    sys.exit(main())
