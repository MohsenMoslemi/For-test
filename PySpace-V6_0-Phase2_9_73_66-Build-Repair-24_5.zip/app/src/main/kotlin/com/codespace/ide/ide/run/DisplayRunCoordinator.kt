package com.codespace.ide.ide.run

import com.codespace.ide.runtime.RuntimeDispatchers
import kotlinx.coroutines.withContext

/** Outcome of preparing the persistent X11/VNC display for one GUI run. */
enum class DisplayStartResult {
    READY,
    FAILED,
    SUPERSEDED,
}

/**
 * Coordinates the blocking Xvnc/PRoot startup separately from the viewer's
 * UI-facing connection. A stale run may leave the persistent server ready,
 * but it must never reconnect or reopen the viewer after Stop/new Run.
 */
class DisplayRunCoordinator(
    private val dispatchers: RuntimeDispatchers = RuntimeDispatchers.Default,
) {
    suspend fun start(
        shouldContinue: () -> Boolean,
        ensureDisplay: suspend () -> Boolean,
        connectViewer: () -> Unit,
    ): DisplayStartResult {
        // The generation predicate reads Compose-owned state, so evaluate it
        // on Main before beginning any expensive process/socket work.
        val currentBeforeStart = withContext(dispatchers.main) { shouldContinue() }
        if (!currentBeforeStart) return DisplayStartResult.SUPERSEDED

        val ready = withContext(dispatchers.io) { ensureDisplay() }
        return withContext(dispatchers.main) {
            // Stop or a newer GUI run may have arrived while Xvnc was starting.
            // Do not let this older request reconnect the viewer afterward.
            if (!shouldContinue()) {
                DisplayStartResult.SUPERSEDED
            } else if (!ready) {
                DisplayStartResult.FAILED
            } else {
                connectViewer()
                DisplayStartResult.READY
            }
        }
    }
}
