package com.codespace.ide.ide.testing

import com.codespace.ide.ProotManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import com.codespace.ide.runtime.ProjectScopedResourceRegistry
import java.util.concurrent.atomic.AtomicBoolean
import com.codespace.ide.ide.JSON
import com.codespace.ide.ide.projects.PyProject

// Project-scoped test discovery/run service and registry. Owns the test process; UI never does.

internal class ProjectTestController : AutoCloseable {
    private val _state = MutableStateFlow(TestSnapshot())
    val state: StateFlow<TestSnapshot> = _state.asStateFlow()
    var snapshot: TestSnapshot
        get() = _state.value
        private set(value) { _state.value = value }

    private val _expandedFiles = MutableStateFlow<Set<String>>(emptySet())
    val expandedFiles: StateFlow<Set<String>> = _expandedFiles.asStateFlow()

    private val closed = AtomicBoolean(false)
    @Volatile private var process: Process? = null
    private val generation = java.util.concurrent.atomic.AtomicInteger(0)
    private val workScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun toggleFile(file: String) {
        if (closed.get()) return
        _expandedFiles.value = _expandedFiles.value.let { current ->
            if (file in current) current - file else current + file
        }
    }

    /** Stops all project-owned work and releases the controller exactly once. */
    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        stopInternal(recordCancellation = false)
        workScope.cancel()
        _expandedFiles.value = emptySet()
    }

    fun restore(raw: String, legacyHistory: List<String> = emptyList()) {
        if (closed.get() || snapshot.cases.isNotEmpty() || snapshot.history.isNotEmpty()) return
        if (raw.isBlank()) {
            if (legacyHistory.isNotEmpty()) snapshot = snapshot.copy(history = legacyHistory.take(30))
            return
        }
        runCatching {
            val root = JSONObject(raw)
            val cases = mutableListOf<TestCase>()
            val array = root.optJSONArray("cases") ?: JSONArray()
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                cases += TestCase(o.optString("id"), o.optString("label"), o.optString("file"),
                    runCatching { TestStatus.valueOf(o.optString("status", "NOT_RUN")) }.getOrDefault(TestStatus.NOT_RUN).let { if (it == TestStatus.RUNNING) TestStatus.NOT_RUN else it },
                    o.optString("duration"), o.optString("detail"), o.optString("className"), o.optInt("line"), o.optBoolean("selected"))
            }
            val history = mutableListOf<String>(); val h = root.optJSONArray("history") ?: JSONArray()
            for (i in 0 until h.length()) h.optString(i).takeIf { it.isNotBlank() }?.let(history::add)
            snapshot = TestSnapshot(cases = cases, output = root.optString("output", "Discover tests to get started."),
                framework = root.optString("framework", "auto"), detectedFramework = root.optString("detectedFramework"),
                lastRun = root.optString("lastRun"), totalDuration = root.optString("totalDuration"), history = history,
                coveragePercent = root.optString("coveragePercent"), reportPath = root.optString("reportPath"),
                htmlReportPath = root.optString("htmlReportPath"), jsonReportPath = root.optString("jsonReportPath"),
                keyword = root.optString("keyword"), marker = root.optString("marker"), failFast = root.optBoolean("failFast"),
                coverageEnabled = root.optBoolean("coverageEnabled"), lastExitCode = root.optInt("lastExitCode", -1), runSummary = root.optString("runSummary"),
                coverageFiles = parseCoverageFiles(root.optJSONArray("coverageFiles") ?: JSONArray()),
                coverageMessage = root.optString("coverageMessage", "Run tests with coverage enabled to explore file-level coverage."),
                analyticsRunNumber = root.optInt("analyticsRunNumber", 0),
                analyticsCounts = parseAnalyticsCounts(root.optJSONObject("analyticsCounts") ?: JSONObject()),
                analyticsChanges = parseAnalyticsChanges(root.optJSONArray("analyticsChanges") ?: JSONArray()),
                flakyTests = parseFlakyTests(root.optJSONArray("flakyTests") ?: JSONArray()),
                analyticsMessage = root.optString("analyticsMessage", "Run tests at least three times to start detecting flaky tests."))
        }
    }

    fun serialize(): String {
        val root = JSONObject()
        val cases = JSONArray()
        snapshot.cases.take(10000).forEach { t ->
            cases.put(JSONObject().put("id", t.id).put("label", t.label).put("file", t.file).put("status", t.status.name)
                .put("duration", t.duration).put("detail", t.detail.take(12000)).put("className", t.className)
                .put("line", t.line).put("selected", t.selected))
        }
        root.put("cases", cases).put("output", snapshot.output.takeLast(90000)).put("framework", snapshot.framework)
            .put("detectedFramework", snapshot.detectedFramework).put("lastRun", snapshot.lastRun)
            .put("totalDuration", snapshot.totalDuration).put("coveragePercent", snapshot.coveragePercent)
            .put("reportPath", snapshot.reportPath).put("htmlReportPath", snapshot.htmlReportPath).put("jsonReportPath", snapshot.jsonReportPath)
            .put("keyword", snapshot.keyword).put("marker", snapshot.marker)
            .put("failFast", snapshot.failFast).put("coverageEnabled", snapshot.coverageEnabled).put("lastExitCode", snapshot.lastExitCode).put("runSummary", snapshot.runSummary)
            .put("coverageFiles", coverageFilesToJson(snapshot.coverageFiles)).put("coverageMessage", snapshot.coverageMessage)
            .put("analyticsRunNumber", snapshot.analyticsRunNumber).put("analyticsCounts", JSONObject()
                .put("new", snapshot.analyticsCounts.new).put("regressions", snapshot.analyticsCounts.regressions)
                .put("fixed", snapshot.analyticsCounts.fixed).put("unchanged", snapshot.analyticsCounts.unchanged))
            .put("analyticsChanges", analyticsChangesToJson(snapshot.analyticsChanges)).put("flakyTests", flakyTestsToJson(snapshot.flakyTests))
            .put("analyticsMessage", snapshot.analyticsMessage)
        val history = JSONArray(); snapshot.history.take(30).forEach { history.put(it) }; root.put("history", history)
        return root.toString()
    }

    fun loadCoverage(proot: ProotManager, project: PyProject, force: Boolean = false) {
        if (closed.get() || snapshot.running || snapshot.coverageLoading || (!force && snapshot.coverageFiles.isNotEmpty())) return
        snapshot = snapshot.copy(coverageLoading = true, coverageMessage = "Loading coverage data…")
        workScope.launch {
            val root = guestProjectPath(project)
            val path = "$root/.pyspace-test-reports/coverage.json"
            val command = "if [ -f ${shellQuote(path)} ]; then cat ${shellQuote(path)}; else echo __PYSPACE_NO_COVERAGE__; fi"
            val raw = try {
                proot.runOnce(command, 30)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                "ERROR: ${error.message}"
            }
            if (closed.get()) return@launch
            val clean = raw.substringBefore("\n[exit=").trim()
            if (clean == "__PYSPACE_NO_COVERAGE__") {
                snapshot = snapshot.copy(coverageLoading = false, coverageFiles = emptyList(), coverageMessage = "No coverage report found. Enable coverage in Test configuration, then run the tests.")
                return@launch
            }
            val parsed = runCatching {
                val json = JSONObject(clean)
                val filesObject = json.optJSONObject("files") ?: JSONObject()
                val result = mutableListOf<CoverageFile>()
                val keys = filesObject.keys()
                while (keys.hasNext()) {
                    val file = keys.next()
                    val item = filesObject.optJSONObject(file) ?: continue
                    val summary = item.optJSONObject("summary") ?: JSONObject()
                    val missing = item.optJSONArray("missing_lines") ?: JSONArray()
                    val missingLines = (0 until missing.length()).mapNotNull { index -> missing.optInt(index, -1).takeIf { it > 0 } }
                    result += CoverageFile(file, summary.optDouble("percent_covered", 0.0),
                        summary.optInt("covered_lines", 0), summary.optInt("num_statements", 0), missingLines)
                }
                result.sortedWith(compareBy<CoverageFile>({ it.percent }, { it.path.lowercase(Locale.ROOT) }))
            }.getOrElse { error ->
                snapshot = snapshot.copy(coverageLoading = false, coverageFiles = emptyList(), coverageMessage = "Coverage report could not be read: ${error.message ?: "invalid JSON"}")
                return@launch
            }
            val total = runCatching { JSONObject(clean).optJSONObject("totals")?.optDouble("percent_covered", -1.0) ?: -1.0 }.getOrDefault(-1.0)
            snapshot = snapshot.copy(coverageLoading = false, coverageFiles = parsed,
                coveragePercent = if (total >= 0.0) "${String.format(Locale.US, "%.1f", total)}%" else snapshot.coveragePercent,
                coverageMessage = if (parsed.isEmpty()) "The coverage report contains no measurable Python files." else "${parsed.size} file(s) · ${parsed.sumOf { it.missingLines.size }} uncovered line(s)")
        }
    }

    fun updateOptions(framework: String? = null, keyword: String? = null, marker: String? = null, failFast: Boolean? = null, coverage: Boolean? = null) {
        if (closed.get()) return
        snapshot = snapshot.copy(framework = framework ?: snapshot.framework, keyword = keyword ?: snapshot.keyword,
            marker = marker ?: snapshot.marker, failFast = failFast ?: snapshot.failFast, coverageEnabled = coverage ?: snapshot.coverageEnabled)
    }

    fun toggleSelection(id: String) {
        if (closed.get()) return
        snapshot = snapshot.copy(cases = snapshot.cases.map { if (it.id == id) it.copy(selected = !it.selected) else it })
    }
    fun selectAll(visibleIds: Set<String>, selected: Boolean) {
        if (closed.get()) return
        snapshot = snapshot.copy(cases = snapshot.cases.map { if (it.id in visibleIds) it.copy(selected = selected) else it })
    }
    fun clearResults() {
        if (closed.get()) return
        if (snapshot.running) return
        snapshot = snapshot.copy(cases = snapshot.cases.map { it.copy(status = TestStatus.NOT_RUN, duration = "", detail = "") },
            output = "Results cleared. Run tests to see fresh results.", coveragePercent = "", lastExitCode = -1)
    }
    fun clearHistory() { if (!closed.get()) snapshot = snapshot.copy(history = emptyList()) }

    fun stop() {
        if (closed.get()) return
        stopInternal(recordCancellation = true)
    }

    @Synchronized
    private fun stopInternal(recordCancellation: Boolean) {
        generation.incrementAndGet()
        process?.let { p -> runCatching { p.destroy() }; if (p.isAlive) runCatching { p.destroyForcibly() } }
        process = null
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val suffix = if (recordCancellation) "\n[Run cancelled by user.]\n" else ""
        val history = if (recordCancellation) (listOf("$stamp · Run cancelled") + snapshot.history).take(30) else snapshot.history
        snapshot = snapshot.copy(running = false, discovering = false, coverageLoading = false,
            output = snapshot.output + suffix,
            cases = snapshot.cases.map { if (it.status == TestStatus.RUNNING) it.copy(status = TestStatus.NOT_RUN) else it },
            history = history)
    }

    private fun runnerCommand(script: String, root: String, python: String, args: String): String {
        val encoded = java.util.Base64.getEncoder().encodeToString(script.toByteArray(Charsets.UTF_8))
        val runnerPath = "/tmp/pyspace_test_runner_${Integer.toHexString(root.hashCode())}.py"
        return "printf '%s' ${shellQuote(encoded)} | base64 -d > ${shellQuote(runnerPath)} && cd ${shellQuote(root)} && (ulimit -f 51200 2>/dev/null || true) && exec $python ${shellQuote(runnerPath)} $args 2>&1"
    }

    fun discover(proot: ProotManager, project: PyProject, runnerScript: String) {
        if (closed.get() || snapshot.discovering || snapshot.running) return
        snapshot = snapshot.copy(discovering = true, output = "Discovering tests…", cases = emptyList())
        val runId = generation.incrementAndGet()
        workScope.launch {
            val args = "--mode discover --framework ${shellQuote(snapshot.framework)}"
            val output = try {
                proot.runOnce(runnerCommand(runnerScript, guestProjectPath(project), projectPythonBin(project.dir), args), 150)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                "Discovery error: ${error.javaClass.simpleName}: ${error.message}"
            }
            if (closed.get() || generation.get() != runId) return@launch
            val discovered = linkedMapOf<String, TestCase>()
            val clean = StringBuilder()
            output.lineSequence().forEach { line ->
                if (line.contains(EVENT_PREFIX)) {
                    val event = parseEvent(line.substringAfter(EVENT_PREFIX)) ?: return@forEach
                    if (event.optString("type") == "case") {
                        val item = event.toTestCase()
                        discovered[item.id] = item
                    } else if (event.optString("type") == "error" || event.optString("type") == "warning") {
                        clean.append(event.optString("message")).append('\n')
                    }
                } else if (!line.startsWith("[exit=")) clean.append(line).append('\n')
            }
            val cases = discovered.values.sortedWith(compareBy<TestCase>({ it.file.lowercase(Locale.ROOT) }, { it.className }, { it.label }))
            val framework = output.lineSequence().mapNotNull { line -> if (line.contains(EVENT_PREFIX)) parseEvent(line.substringAfter(EVENT_PREFIX))?.optString("framework") else null }.firstOrNull { !it.isNullOrBlank() }.orEmpty()
            snapshot = snapshot.copy(cases = cases, discovering = false, detectedFramework = framework,
                output = if (cases.isEmpty()) clean.toString().ifBlank { "No tests discovered. Add test_*.py files or test cases to this project." } else "Discovered ${cases.size} test(s) using ${framework.ifBlank { snapshot.framework }}.")
        }
    }

    fun run(proot: ProotManager, project: PyProject, runnerScript: String, targetIds: List<String> = emptyList()) {
        if (closed.get() || snapshot.running || snapshot.discovering) return
        val runId = generation.incrementAndGet()
        val options = snapshot
        val rootPath = guestProjectPath(project)
        val reportPath = "$rootPath/.pyspace-test-reports/junit.xml"
        val args = buildString {
            append("--mode run --framework ").append(shellQuote(options.framework))
            targetIds.forEach { append(" --target ").append(shellQuote(it)) }
            if (options.keyword.isNotBlank()) append(" --keyword ").append(shellQuote(options.keyword))
            if (options.marker.isNotBlank()) append(" --marker ").append(shellQuote(options.marker))
            if (options.failFast) append(" --fail-fast")
            if (options.coverageEnabled) append(" --coverage")
            append(" --reports ").append(shellQuote(".pyspace-test-reports"))
        }
        val selected = targetIds.toSet()
        snapshot = snapshot.copy(running = true, output = "Starting ${if (targetIds.isEmpty()) "full test suite" else "${targetIds.size} selected test(s)"}…\n",
            coveragePercent = "", coverageFiles = emptyList(), coverageMessage = if (options.coverageEnabled) "Coverage will be available after this run." else "Coverage was not enabled for the latest test run.",
            lastExitCode = -1, runSummary = "",
            cases = snapshot.cases.map { t -> if (targetIds.isEmpty() || t.id in selected) t.copy(status = TestStatus.RUNNING, detail = "", duration = "") else t })
        workScope.launch {
            val captured = StringBuilder()
            try {
                val command = runnerCommand(runnerScript, rootPath, projectPythonBin(project.dir), args)
                val p = proot.startGuestProcess(command)
                synchronized(this@ProjectTestController) { if (generation.get() == runId) process = p else p.destroyForcibly() }
                val timeout = Thread {
                    try {
                        Thread.sleep(600_000)
                        if (p.isAlive && generation.get() == runId) p.destroyForcibly()
                    } catch (_: InterruptedException) {
                        // Normal completion or cancellation stops the watchdog.
                    }
                }.apply { isDaemon = true; name = "PySpace-Test-Timeout"; start() }
                val exit = try {
                    p.inputStream.bufferedReader().useLines { lines ->
                        lines.forEach { line ->
                            if (generation.get() != runId) return@forEach
                            synchronized(this@ProjectTestController) {
                                if (line.contains(EVENT_PREFIX)) {
                                    val before = line.substringBefore(EVENT_PREFIX)
                                    if (before.isNotBlank()) captured.append(before).append('\n')
                                    val payload = line.substringAfter(EVENT_PREFIX)
                                    val event = parseEvent(payload)
                                    if (event != null && (event.optString("type") == "warning" || event.optString("type") == "error")) captured.append(event.optString("message")).append('\n')
                                    handleEvent(payload, targetIds)
                                } else {
                                    captured.append(line).append('\n')
                                    if (captured.length > 120_000) captured.delete(0, captured.length - 100_000)
                                    snapshot = snapshot.copy(output = captured.toString())
                                }
                            }
                        }
                    }
                    p.waitFor()
                } finally {
                    timeout.interrupt()
                    if ((closed.get() || generation.get() != runId) && p.isAlive) {
                        runCatching { p.destroy() }
                        if (p.isAlive) runCatching { p.destroyForcibly() }
                    }
                }
                if (generation.get() != runId) return@launch
                val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                val current = snapshot
                val doneCases = current.cases.map { if (it.status == TestStatus.RUNNING) it.copy(status = TestStatus.NOT_RUN) else it }
                val passed = doneCases.count { it.status == TestStatus.PASSED }
                val failed = doneCases.count { it.status == TestStatus.FAILED || it.status == TestStatus.XPASSED }
                val skipped = doneCases.count { it.status == TestStatus.SKIPPED }
                val tested = doneCases.count { it.status in setOf(TestStatus.PASSED, TestStatus.FAILED, TestStatus.SKIPPED, TestStatus.XFAILED, TestStatus.XPASSED) }
                val record = "$stamp · ${current.runSummary.ifBlank { "$tested run · $passed passed · $failed failed · $skipped skipped" }} · exit $exit"
                snapshot = current.copy(cases = doneCases, running = false, lastRun = stamp,
                    totalDuration = current.totalDuration, lastExitCode = exit,
                    reportPath = if (File(project.dir, ".pyspace-test-reports/junit.xml").exists()) reportPath else current.reportPath,
                    history = (listOf(record) + current.history).take(30),
                    output = (captured.toString() + (if (captured.isNotEmpty()) "\n" else "") + "Run finished (exit $exit).\n").takeLast(100_000))
                if (options.coverageEnabled) loadCoverage(proot, project, force = true)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (t: Exception) {
                if (!closed.get() && generation.get() == runId) snapshot = snapshot.copy(running = false,
                    output = snapshot.output + "\nRunner error: ${t.javaClass.simpleName}: ${t.message}\n")
            } finally {
                synchronized(this@ProjectTestController) { if (generation.get() == runId) process = null }
            }
        }
    }

    private fun handleEvent(raw: String, targets: List<String>) {
        val event = parseEvent(raw) ?: return
        when (event.optString("type")) {
            "case", "result" -> {
                val item = event.toTestCase()
                val found = snapshot.cases.any { it.id == item.id }
                val cases = if (found) snapshot.cases.map { old -> if (old.id == item.id) item.copy(selected = old.selected) else old }
                    else snapshot.cases + item
                snapshot = snapshot.copy(cases = cases)
            }
            "summary" -> {
                val total = event.optInt("total", 0)
                val passed = event.optInt("passed", 0)
                val failed = event.optInt("failed", 0)
                val skipped = event.optInt("skipped", 0)
                val xfailed = event.optInt("xfailed", 0)
                val xfailText = if (xfailed > 0) " · $xfailed xfailed" else ""
                snapshot = snapshot.copy(totalDuration = "${event.optDouble("duration", 0.0)}s",
                    reportPath = event.optString("report"), htmlReportPath = event.optString("htmlReport"),
                    jsonReportPath = event.optString("jsonReport"), lastExitCode = event.optInt("exitCode", -1),
                    runSummary = "$total run · $passed passed · $failed failed · $skipped skipped$xfailText")
            }
            "coverage" -> snapshot = snapshot.copy(coveragePercent = "${event.optDouble("percent", 0.0)}%")
            "analytics" -> snapshot = snapshot.copy(analyticsRunNumber = event.optInt("runNumber", snapshot.analyticsRunNumber),
                analyticsCounts = parseAnalyticsCounts(event.optJSONObject("counts") ?: JSONObject()),
                analyticsChanges = parseAnalyticsChanges(event.optJSONArray("changes") ?: JSONArray()),
                flakyTests = parseFlakyTests(event.optJSONArray("flaky") ?: JSONArray()),
                analyticsMessage = event.optString("message", snapshot.analyticsMessage))
            "warning", "error" -> snapshot = snapshot.copy(output = (snapshot.output + event.optString("message") + "\n").takeLast(100_000))
        }
    }

    private fun JSONObject.toTestCase(): TestCase {
        val id = optString("id")
        val status = runCatching { TestStatus.valueOf(optString("status", "NOT_RUN").uppercase(Locale.ROOT)) }.getOrDefault(TestStatus.NOT_RUN)
        val duration = optDouble("duration", 0.0).takeIf { it > 0.0 }?.let { "${it}s" }.orEmpty()
        return TestCase(id = id, label = optString("name", id.substringAfterLast("::").substringAfterLast('.')),
            file = optString("file"), status = status, duration = duration, detail = optString("detail"),
            className = optString("class"), line = optInt("line"))
    }

    private fun parseEvent(raw: String): JSONObject? = runCatching { JSONObject(raw) }.getOrNull()

    companion object { private const val EVENT_PREFIX = "PYSPACE_EVENT:" }
}

internal object TestControllerRegistry {
    private val resources = ProjectScopedResourceRegistry { _: File -> ProjectTestController() }

    fun get(project: PyProject): ProjectTestController = resources.get(project.dir)

    /** Evicts and closes the controller when its project is deleted or permanently left. */
    fun remove(projectPath: String) {
        resources.remove(File(projectPath))
    }

    fun removeAll() = resources.closeAll()
}



internal fun shellQuote(value: String): String = "'" + value.replace("'", "'\\''") + "'"
