package com.codespace.ide.ide.codeintel

import java.io.File
import org.json.JSONArray
import org.json.JSONObject
import com.codespace.ide.ide.projects.PyProject

/**
 * Owns the project-specific Python environment and Jedi workspace configuration
 * sent to pylsp. It contains no process/session lifecycle and can be reset whenever
 * the project's environment revision changes.
 */
internal class LspWorkspaceConfiguration(private val project: PyProject) {
    @Volatile private var configuredInterpreterFingerprint: String? = null
    @Volatile private var configuredImportRoots: List<String> = emptyList()
    @Volatile private var lastImportRootScanAtMs: Long = 0L

    fun initialSettings(): JSONObject {
        val (python, fingerprint) = selectedInterpreter()
        val roots = discoverProjectImportRoots()
        configuredInterpreterFingerprint = fingerprint
        configuredImportRoots = roots
        return settingsForInterpreter(python, roots)
    }

    fun refreshInterpreterSettings(active: LspSessionTransport) {
        val (python, fingerprint) = selectedInterpreter()
        if (fingerprint != configuredInterpreterFingerprint) {
            active.notify(
                "workspace/didChangeConfiguration",
                JSONObject().put("settings", settingsForInterpreter(python, configuredImportRoots)),
            )
            configuredInterpreterFingerprint = fingerprint
        }
    }

    fun refreshProjectImportRoots(active: LspSessionTransport) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastImportRootScanAtMs < IMPORT_ROOT_RESCAN_INTERVAL_MS) return
        lastImportRootScanAtMs = now
        val discovered = discoverProjectImportRoots()
        if (discovered == configuredImportRoots) return
        val (python, fingerprint) = selectedInterpreter()
        active.notify(
            "workspace/didChangeConfiguration",
            JSONObject().put("settings", settingsForInterpreter(python, discovered)),
        )
        configuredImportRoots = discovered
        configuredInterpreterFingerprint = fingerprint
    }

    fun reset() {
        configuredInterpreterFingerprint = null
        configuredImportRoots = emptyList()
        lastImportRootScanAtMs = 0L
    }

    private fun discoverProjectImportRoots(): List<String> {
        val root = try { project.dir.canonicalFile } catch (_: Exception) { project.dir.absoluteFile }
        if (!root.isDirectory) return listOf(guestProjectPath(project))
        val ignored = setOf(
            ".git", ".hg", ".svn", ".venv", "venv", "env", "__pycache__",
            "node_modules", "build", "dist", ".mypy_cache", ".pytest_cache",
            ".tox", ".idea", ".gradle", "site-packages"
        )
        val queue = java.util.ArrayDeque<File>()
        val visited = HashSet<String>()
        queue.add(root)
        val roots = linkedSetOf(root.absolutePath)
        while (queue.isNotEmpty()) {
            val directory = queue.removeFirst()
            val canonicalDirectory = try { directory.canonicalFile } catch (_: Exception) { continue }
            if (!canonicalDirectory.path.startsWith(root.path + File.separator) && canonicalDirectory != root) continue
            if (!visited.add(canonicalDirectory.path)) continue
            val entries = try { canonicalDirectory.listFiles() ?: continue } catch (_: Exception) { continue }
            for (entry in entries) {
                if (entry.isDirectory) {
                    if (entry.name !in ignored && !isSymbolicLink(entry)) queue.addLast(entry)
                    continue
                }
                if (!entry.isFile || !entry.name.endsWith(".py", ignoreCase = true)) continue
                var packageDirectory = entry.parentFile ?: continue
                if (File(packageDirectory, "__init__.py").isFile) {
                    while (packageDirectory.parentFile != null &&
                        File(packageDirectory.parentFile, "__init__.py").isFile) {
                        packageDirectory = packageDirectory.parentFile
                    }
                    roots += (packageDirectory.parentFile ?: root).absolutePath
                } else {
                    roots += packageDirectory.absolutePath
                }
            }
        }
        return roots.mapNotNull { absolute ->
            val local = File(absolute)
            val relative = try {
                local.canonicalFile.relativeTo(root).path
            } catch (_: Exception) {
                return@mapNotNull null
            }
            val guestRoot = guestProjectPath(project).trimEnd('/')
            if (relative.isBlank() || relative == ".") guestRoot
            else guestRoot + "/" + relative.replace(File.separatorChar, '/')
        }.distinct().sorted()
    }

    private fun isSymbolicLink(file: File): Boolean = try {
        java.nio.file.Files.isSymbolicLink(file.toPath())
    } catch (_: Exception) { false }

    fun selectedInterpreter(): Pair<String?, String> {
        val venvGuest = projectVenvGuestPath(project.dir)
        val python = venvGuest?.takeIf { venvPythonReady(project.dir) }
            ?.let { "$it/bin/python" } ?: projectPythonInterpreterGuestPath(project.dir)
        val cfg = try {
            File(project.dir, "${projectVenvName(project.dir)}/pyvenv.cfg")
                .takeIf { it.isFile }?.readText()?.trim().orEmpty()
        } catch (_: Exception) { "" }
        return python to "${python}|${projectPythonVersionId(project.dir)}|$cfg"
    }

    private fun settingsForInterpreter(python: String?, importRoots: List<String>): JSONObject {
        val plugins = JSONObject()
            .put("jedi", JSONObject()
                .put("environment", python ?: JSONObject.NULL)
                .put("extra_paths", JSONArray().apply { importRoots.forEach { put(it) } }))
            .put("mccabe", JSONObject().put("enabled", false))
            .put("rope_autoimport", JSONObject().put("enabled", false))
            .put("rope_completion", JSONObject().put("enabled", false))
            .put("pyflakes", JSONObject().put("enabled", true))
            .put("autopep8", JSONObject().put("enabled", true))
            .put("pycodestyle", JSONObject().put("enabled", true)
                .put("maxLineLength", 120)
                .put("ignore", JSONArray().put("E501")))
        return JSONObject().put("pylsp", JSONObject().put("plugins", plugins))
    }

    private companion object {
        const val IMPORT_ROOT_RESCAN_INTERVAL_MS = 2_000L
    }
}
