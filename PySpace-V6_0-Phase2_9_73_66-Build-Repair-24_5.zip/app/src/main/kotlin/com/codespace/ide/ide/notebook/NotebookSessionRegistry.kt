package com.codespace.ide.ide.notebook

import java.io.File
import com.codespace.ide.ide.projects.PyProject

/**
 * Owns the application-scoped index of open notebook sessions.
 * All map access and persisted-text comparisons are serialized here; kernel
 * and ViewModel disposal are deliberately performed by NotebookRepository
 * after entries have been detached from the registry.
 */
internal class NotebookSessionRegistry {
    internal data class Entry(
        val viewModel: NotebookViewModel,
        val unsubscribe: () -> Unit,
        var lastPersistedText: String,
    )

    private val lock = Any()
    private val entries = LinkedHashMap<String, Entry>()

    private fun key(file: File, project: PyProject): String =
        file.absolutePath + "\u0000" + project.dir.absolutePath

    fun getOrCreate(
        file: File,
        project: PyProject,
        onExisting: (Entry) -> Unit,
        create: () -> Entry,
    ): Entry = synchronized(lock) {
        val sessionKey = key(file, project)
        val existing = entries[sessionKey]
        if (existing != null) {
            onExisting(existing)
            existing
        } else {
            create().also { entries[sessionKey] = it }
        }
    }

    fun findMatching(file: File, project: PyProject, persistedText: String): NotebookViewModel? =
        synchronized(lock) {
            entries[key(file, project)]
                ?.takeIf { it.lastPersistedText == persistedText }
                ?.viewModel
        }

    /** Run a persistence action only while the same session is still registered. */
    fun withCurrent(
        file: File,
        project: PyProject,
        expected: NotebookViewModel,
        action: (Entry) -> Unit,
    ): Boolean = synchronized(lock) {
        val entry = entries[key(file, project)]
        if (entry?.viewModel !== expected) false else {
            action(entry)
            true
        }
    }

    fun remove(file: File, project: PyProject): Entry? = synchronized(lock) {
        entries.remove(key(file, project))
    }

    fun removeUnder(path: File, project: PyProject): List<Entry> {
        val target = path.absolutePath
        val projectSuffix = "\u0000" + project.dir.absolutePath
        return synchronized(lock) {
            val matching = entries.entries.filter { item ->
                val notebookPath = item.key.substringBefore("\u0000")
                (notebookPath == target || notebookPath.startsWith(target + File.separator)) &&
                    item.key.endsWith(projectSuffix)
            }
            matching.forEach { entries.remove(it.key) }
            matching.map { it.value }
        }
    }

    fun removeProject(project: PyProject): List<Entry> {
        val suffix = "\u0000" + project.dir.absolutePath
        return synchronized(lock) {
            val matching = entries.entries.filter { it.key.endsWith(suffix) }
            matching.forEach { entries.remove(it.key) }
            matching.map { it.value }
        }
    }

    fun drain(): List<Entry> = synchronized(lock) {
        entries.values.toList().also { entries.clear() }
    }
}
