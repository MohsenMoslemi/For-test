package com.codespace.ide.ide

import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ProotManager
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.codespace.ide.ide.codeintel.PythonQuickFixes
import com.codespace.ide.ide.codeintel.PythonSyntaxDiagnostic
import com.codespace.ide.ide.editor.EditorBreakpoint
import com.codespace.ide.ide.editor.EditorBreakpointStore
import com.codespace.ide.ide.editor.EditorSession
import com.codespace.ide.ide.debug.DebugController
import com.codespace.ide.ide.debug.DebugVariableItem
import com.codespace.ide.ide.projects.PyProject
import com.codespace.ide.ide.terminal.ConsoleState
import com.codespace.ide.ide.theme.IdeTheme

// ---------------------------------------------------------------------------
// Bottom-panel tabs: Console (captured run output), Problems (CPython syntax
// diagnostics plus lightweight style checks), Terminal (interactive shell, hosted by IdeRoot), Debug (DAP/debugpy session), Test (pytest/unittest runner) and
// Camera (phone-camera → Python bridge status + controls).
// ---------------------------------------------------------------------------

enum class PanelTab { Console, Problems, Terminal, Debug, Test, Camera }

// -------------------------------- Console ----------------------------------

/**
 * Slim header above the console's own terminal surface: status + rerun +
 * stop. Output, scrolling, selection and input all belong to the embedded
 * terminal engine, not to this header.
 */
@Composable
fun ConsoleHeader(
    state: ConsoleState,
    canRerun: Boolean,
    onRerun: () -> Unit,
    onStop: () -> Unit,
    serverUrl: String? = null,
    serverLabel: String? = null,
    onOpenServer: ((String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (state.running) {
                CircularProgressIndicator(
                    Modifier.size(14.dp), strokeWidth = 2.dp,
                    color = Color(IdeTheme.ACCENT)
                )
                Spacer(Modifier.width(8.dp))
                Text("running… (input() works here)", color = Color(IdeTheme.ACCENT), fontSize = 12.sp)
            } else {
                Text("●", color = Color(IdeTheme.DIM), fontSize = 10.sp)
                Spacer(Modifier.width(8.dp))
                Text("idle", color = Color(IdeTheme.DIM), fontSize = 12.sp)
            }
            Spacer(Modifier.weight(1f))
            if (canRerun) {
                TextButton(onClick = onRerun) { Text("▶ Rerun", fontSize = 12.sp, color = Color(IdeTheme.ACCENT)) }
            }
            if (state.running) {
                TextButton(onClick = onStop) { Text("■ Stop", fontSize = 12.sp, color = Color(IdeTheme.ERROR)) }
            }
            if (serverUrl != null && onOpenServer != null) {
                TextButton(onClick = { onOpenServer(serverUrl) }) {
                    Text("🌐 Browser", fontSize = 12.sp, color = Color(IdeTheme.ACCENT))
                }
            }
        }
        Text(
            state.title,
            color = Color(IdeTheme.DIM), fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 12.dp),
            maxLines = 1
        )
        if (serverUrl != null) {
            Text(
                "Serving at $serverUrl",
                color = Color(IdeTheme.ACCENT), fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 12.dp),
                maxLines = 1
            )
        } else if (serverLabel != null) {
            Text(
                serverLabel,
                color = Color(IdeTheme.DIM), fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 12.dp),
                maxLines = 1
            )
        }
        Spacer(Modifier.height(2.dp))
    }
}

// -------------------------------- Problems ---------------------------------

@Composable
fun ProblemsView(
    session: EditorSession?,
    syntaxDiagnostics: Map<String, List<PythonSyntaxDiagnostic>> = emptyMap(),
    lspDiagnosticFiles: Set<String> = emptySet(),
    onOpenFile: (File, Int) -> Unit,
    onFix: (File, PythonSyntaxDiagnostic) -> Unit = { _, _ -> },
    onImport: (File, PythonSyntaxDiagnostic) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier
) {
    val tabs = session?.tabs ?: emptyList()
    var selectedFilter by remember { mutableStateOf("All") }
    fun isError(kind: String): Boolean = kind.equals("error", true) || kind.equals("syntaxerror", true)
    fun isWarning(kind: String): Boolean = kind.equals("warning", true)
    fun calculateCounts(): Triple<Int, Int, Int> {
        var errors = 0
        var warnings = 0
        var all = 0
        tabs.forEach { tab ->
            val path = tab.file.absolutePath
            if (EditorLanguageRegistry.languageFor(tab.file) == EditorLanguage.PYTHON) {
                val fallback = if (path in lspDiagnosticFiles) emptyList() else pythonProblems(tab.text)
                val diagnostics = syntaxDiagnostics[path].orEmpty()
                all += fallback.size + diagnostics.size
                errors += fallback.count { it.error } + diagnostics.count { isError(it.kind) }
                warnings += fallback.count { !it.error } + diagnostics.count { isWarning(it.kind) }
            }
        }
        return Triple(all, warnings, errors)
    }
    var counts by remember { mutableStateOf(Triple(0, 0, 0)) }
    LaunchedEffect(tabs, syntaxDiagnostics, lspDiagnosticFiles) {
        counts = calculateCounts()
        snapshotFlow { tabs.map { it.text } }.collectLatest {
            delay(250)
            counts = calculateCounts()
        }
    }

    // Tap sink: empty areas must not fall through to the interactive shell.
    val sink = Modifier.clickable(
        indication = null,
        interactionSource = remember { MutableInteractionSource() }
    ) { }

    Column(modifier.fillMaxSize().then(sink)) {
        // Compact segmented filters with live counts; selected state follows the IDE theme.
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)
                .background(Color(IdeTheme.PANEL), RoundedCornerShape(12.dp))
                .padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            listOf(
                Triple("All", counts.first, IdeTheme.ACCENT),
                Triple("Warnings", counts.second, IdeTheme.WARN),
                Triple("Errors", counts.third, IdeTheme.ERROR)
            ).forEach { (label, count, tint) ->
                val selected = selectedFilter == label
                Row(
                    Modifier.weight(1f)
                        .clip(RoundedCornerShape(9.dp))
                        .background(if (selected) Color(IdeTheme.BG) else Color.Transparent)
                        .clickable { selectedFilter = label }
                        .padding(horizontal = 5.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        label,
                        color = Color(if (selected) IdeTheme.TEXT else IdeTheme.DIM),
                        fontSize = 11.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(
                        count.toString(),
                        color = Color(if (count > 0) tint else IdeTheme.DIM),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 8.dp).then(sink)) {
            if (tabs.isEmpty()) {
                item { Text("No files open.", color = Color(IdeTheme.DIM), fontSize = 12.sp, modifier = Modifier.padding(6.dp)) }
            }
            items(tabs, key = { it.file.absolutePath }) { tab ->
                val path = tab.file.absolutePath
                val isPython = EditorLanguageRegistry.languageFor(tab.file) == EditorLanguage.PYTHON
                val hasSyntaxResult = path in lspDiagnosticFiles
                val fallback = remember(tab.text, hasSyntaxResult, isPython) {
                    if (!isPython || hasSyntaxResult) emptyList() else pythonProblems(tab.text)
                }
                val syntax = if (isPython) syntaxDiagnostics[path].orEmpty() else emptyList()
                val visibleFallback = fallback.filter { problem ->
                    selectedFilter == "All" ||
                        (selectedFilter == "Errors" && problem.error) ||
                        (selectedFilter == "Warnings" && !problem.error)
                }
                val visibleSyntax = syntax.filter { diagnostic ->
                    selectedFilter == "All" ||
                        (selectedFilter == "Errors" && isError(diagnostic.kind)) ||
                        (selectedFilter == "Warnings" && isWarning(diagnostic.kind))
                }
                if (visibleFallback.isNotEmpty() || visibleSyntax.isNotEmpty()) {
                    Column(Modifier.fillMaxWidth().padding(bottom = 5.dp)) {
                        Text(
                            tab.name, fontWeight = FontWeight.Bold, fontSize = 12.sp,
                            color = Color(IdeTheme.TEXT), modifier = Modifier.padding(top = 6.dp, bottom = 2.dp)
                        )
                        visibleSyntax.forEach { diagnostic ->
                            val severityColor = when {
                                isError(diagnostic.kind) -> Color(IdeTheme.ERROR)
                                isWarning(diagnostic.kind) -> Color(IdeTheme.WARN)
                                diagnostic.kind.equals("information", true) -> Color(IdeTheme.INFO)
                                else -> Color(IdeTheme.DIM)
                            }
                            Row(
                                Modifier.fillMaxWidth().clickable { onOpenFile(tab.file, diagnostic.line) }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("●", fontSize = 10.sp, color = severityColor)
                                Spacer(Modifier.width(6.dp))
                                Text(diagnostic.kind.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = severityColor)
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    "line ${diagnostic.line}, col ${diagnostic.column}: ${diagnostic.message}",
                                    fontSize = 12.sp, fontFamily = FontFamily.Monospace,
                                    color = Color(IdeTheme.TEXT), modifier = Modifier.weight(1f)
                                )
                                if (PythonQuickFixes.key(diagnostic) != null) {
                                    TextButton(onClick = { onFix(tab.file, diagnostic) }, modifier = Modifier.padding(start = 2.dp)) {
                                        Text("Fix", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.Bold)
                                    }
                                }
                                if (PythonQuickFixes.undefinedName(diagnostic) != null) {
                                    TextButton(onClick = { onImport(tab.file, diagnostic) }, modifier = Modifier.padding(start = 1.dp)) {
                                        Text("Import", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                        visibleFallback.forEach { problem ->
                            Row(
                                Modifier.fillMaxWidth().clickable { onOpenFile(tab.file, problem.line) }
                                    .padding(vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(if (problem.error) "●" else "○", fontSize = 10.sp,
                                    color = Color(if (problem.error) IdeTheme.ERROR else IdeTheme.WARN))
                                Spacer(Modifier.width(6.dp))
                                Text("line ${problem.line}: ${problem.message}", fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace, color = Color(IdeTheme.TEXT), modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
            item {
                val visibleCount = when (selectedFilter) {
                    "Errors" -> counts.third
                    "Warnings" -> counts.second
                    else -> counts.first
                }
                if (visibleCount == 0 && tabs.isNotEmpty()) {
                    Text(
                        if (counts.first == 0) "✓ No issues found by current checks." else "No ${selectedFilter.lowercase()} found.",
                        color = Color(IdeTheme.ACCENT), fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 10.dp)
                    )
                }
            }
        }
    }
}

// --------------------------------- Debug -----------------------------------

/** Flattens only the currently visible branches while preserving explicit parent/child relationships. */
private fun visibleDebugVariableRows(
    items: List<DebugVariableItem>,
    expanded: Set<String>
): List<DebugVariableItem> {
    val childrenByParent = items.groupBy { it.parentPath }
    val visible = ArrayList<DebugVariableItem>()
    fun appendChildren(parentPath: String?) {
        childrenByParent[parentPath].orEmpty().forEach { item ->
            visible += item
            if (item.path in expanded) appendChildren(item.path)
        }
    }
    appendChildren(null)
    return visible
}

/** Renders a true hierarchical tree; children appear directly below their expanded parent. */
@Composable
private fun DebugVariableTreeRows(
    items: List<DebugVariableItem>,
    expanded: Set<String>,
    onToggle: (DebugVariableItem) -> Unit
) {
    visibleDebugVariableRows(items, expanded).forEach { item ->
        val isExpanded = item.path in expanded
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
                .clickable(enabled = item.reference != 0 && item.depth < 12) { onToggle(item) }
                .padding(start = (item.depth * 12).dp, top = 2.dp, bottom = 2.dp)
        ) {
            Text(
                if (item.reference != 0) if (isExpanded) "▾" else "▸" else "·",
                color = Color(IdeTheme.ACCENT), fontSize = 10.sp
            )
            Text(
                if (item.isScope) item.name else "${item.name}: ${item.value}",
                color = Color(IdeTheme.TEXT), fontSize = 10.sp,
                fontFamily = FontFamily.Monospace, maxLines = 3,
                modifier = Modifier.weight(1f)
            )
            if (!item.isScope && item.type.isNotBlank()) {
                Text(item.type, color = Color(IdeTheme.DIM), fontSize = 9.sp)
            }
        }
    }
}

/**
 * Debugger panel. This is ONLY a view: the session, the debuggee process and all debugger
 * state live in [DebugController], which is owned by IdeRoot. Closing the bottom panel,
 * switching panel tabs or recomposing therefore never affects a running debug session.
 * The only state kept here is transient form input (survives tab switches via rememberSaveable).
 */
@Composable
fun DebugView(
    controller: DebugController?,
    activeFile: File?,
    modifier: Modifier = Modifier
) {
    if (controller == null) {
        Box(modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
            Text("Open a project to use the debugger.", color = Color(IdeTheme.DIM), fontSize = 12.sp)
        }
        return
    }
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember(context) { context.getSharedPreferences("pyspace_debugger", android.content.Context.MODE_PRIVATE) }
    val project = controller.project
    val projectKey = project.dir.absolutePath
    var lineInput by rememberSaveable(projectKey) { mutableStateOf("") }
    var watchInput by rememberSaveable(projectKey) { mutableStateOf("") }
    var programInput by rememberSaveable(projectKey) { mutableStateOf("") }
    var selectedBreakpointLine by rememberSaveable(projectKey) { mutableStateOf<Int?>(null) }
    var conditionInput by rememberSaveable(projectKey) { mutableStateOf("") }
    var hitConditionInput by rememberSaveable(projectKey) { mutableStateOf("") }
    var logMessageInput by rememberSaveable(projectKey) { mutableStateOf("") }
    val scroll = rememberScrollState()

    // The runtime publishes immutable snapshots; Compose observes them only here.
    val debugState by controller.uiState.collectAsState()
    val session = controller.session
    val status = debugState.status
    val starting = debugState.starting
    val output = debugState.output
    val stackFrames = debugState.stackFrames
    val debugThreads = debugState.threads
    val variables = debugState.variables
    val selectedFrameId = debugState.selectedFrameId
    val debugThreadId = debugState.threadId
    val watches = debugState.watches
    val watchValues = debugState.watchValues
    val expandedVariables = debugState.expandedVariables
    val breakOnRaised = debugState.breakOnRaised
    val debugTargetFile = debugState.targetFile
    val breakpointFile = activeFile ?: debugTargetFile
    val breakpoints = EditorBreakpointStore.all(breakpointFile)

    fun persistBreakpoints(file: File?) = controller.persistBreakpoints(file)

    // Breakpoints edited in the gutter/panel for the visible file are persisted as they change.
    LaunchedEffect(activeFile?.absolutePath) {
        val file = activeFile ?: return@LaunchedEffect
        val stored = prefs.getString("breakpoints:${file.absolutePath}", null)
        if (stored != null && EditorBreakpointStore.all(file).isEmpty()) EditorBreakpointStore.restore(file, stored)
        snapshotFlow { EditorBreakpointStore.encode(file) }.collectLatest { encoded ->
            prefs.edit().putString("breakpoints:${file.absolutePath}", encoded).apply()
        }
    }
    LaunchedEffect(output) { runCatching { scroll.scrollTo(scroll.maxValue) } }

    fun selectBreakpoint(bp: EditorBreakpoint) {
        selectedBreakpointLine = bp.line; conditionInput = bp.condition; hitConditionInput = bp.hitCondition; logMessageInput = bp.logMessage
    }

    Column(modifier.fillMaxSize().padding(10.dp).verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Python Debugger", fontWeight = FontWeight.Bold, color = Color(IdeTheme.TEXT), fontSize = 14.sp)
                Text((debugTargetFile ?: activeFile)?.let { relPath(project, it) } ?: "Open a Python file", color = Color(IdeTheme.DIM), fontSize = 10.sp, maxLines = 1)
            }
            Text("● $status", color = when (status) { "Paused" -> Color(IdeTheme.WARN); "Error" -> Color(IdeTheme.ERROR); "Running" -> Color(IdeTheme.ACCENT); else -> Color(IdeTheme.DIM) }, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(5.dp))
            if (session != null) {
                TextButton(enabled = !starting, onClick = { controller.restart(activeFile) }) { Text("Restart", color = Color(IdeTheme.ACCENT), fontSize = 10.sp) }
                TextButton(onClick = { controller.stop() }) { Text("Stop", color = Color(IdeTheme.ERROR)) }
            }
            else if (starting) {
                CircularProgressIndicator(Modifier.size(15.dp), strokeWidth = 2.dp, color = Color(IdeTheme.ACCENT))
                TextButton(onClick = { controller.stop() }) { Text("Cancel", color = Color(IdeTheme.ERROR), fontSize = 10.sp) }
            }
            else Button(enabled = activeFile?.isFile == true && activeFile.extension.equals("py", true), onClick = { controller.start(activeFile) }, colors = ButtonDefaults.buttonColors(containerColor = Color(IdeTheme.ACCENT), contentColor = Color(IdeTheme.ON_ACCENT))) { Text("▶ Start") }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            listOf("continue" to "Continue", "pause" to "Pause", "next" to "Over", "stepIn" to "Into", "stepOut" to "Out").forEach { (command, label) ->
                TextButton(enabled = session != null && (command == "pause" && status == "Running" || command != "pause" && status == "Paused"), onClick = { controller.control(command) }) { Text(label, color = Color(IdeTheme.ACCENT), fontSize = 10.sp) }
            }
            TextButton(enabled = session != null && status == "Paused", onClick = { controller.showExceptionInfo() }) { Text("Exception", color = Color(IdeTheme.DIM), fontSize = 10.sp) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            androidx.compose.material3.Checkbox(checked = breakOnRaised, onCheckedChange = { enabled -> controller.updateBreakOnRaised(enabled) })
            Text("Break on raised exceptions", color = Color(IdeTheme.TEXT), fontSize = 11.sp)
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.CARD)), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(8.dp)) {
                Text("Breakpoints · ${breakpointFile?.let { relPath(project, it) } ?: "No file"}", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = lineInput, onValueChange = { lineInput = it.filter(Char::isDigit).take(7) }, label = { Text("Line") }, singleLine = true, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(6.dp))
                    Button(enabled = breakpointFile != null && lineInput.toIntOrNull()?.let { it > 0 } == true, onClick = {
                        val line = lineInput.toIntOrNull() ?: return@Button
                        breakpointFile?.let { EditorBreakpointStore.add(it, line); persistBreakpoints(it) }; lineInput = ""
                    }) { Text("+ Add") }
                }
                if (breakpoints.isEmpty()) Text("No breakpoints · tap an editor line number or add a line above", color = Color(IdeTheme.DIM), fontSize = 10.sp)
                breakpoints.forEach { bp ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 1.dp)) {
                        Text(if (bp.enabled) "●" else "○", color = if (bp.enabled) Color(IdeTheme.WARN) else Color(IdeTheme.DIM), modifier = Modifier.clickable { breakpointFile?.let { EditorBreakpointStore.update(it, bp.copy(enabled = !bp.enabled)); persistBreakpoints(it) } }.padding(5.dp))
                        Text("${bp.line}", color = Color(IdeTheme.TEXT), fontSize = 11.sp, modifier = Modifier.weight(1f).clickable { selectBreakpoint(bp) })
                        Text(if (bp.logMessage.isNotBlank()) "LOG" else if (bp.condition.isNotBlank() || bp.hitCondition.isNotBlank()) "COND" else "LINE", color = Color(IdeTheme.DIM), fontSize = 9.sp, modifier = Modifier.clickable { selectBreakpoint(bp) }.padding(horizontal = 4.dp))
                        Text("Edit", color = Color(IdeTheme.ACCENT), fontSize = 10.sp, modifier = Modifier.clickable { selectBreakpoint(bp) }.padding(horizontal = 5.dp, vertical = 4.dp))
                        Text("×", color = Color(IdeTheme.ERROR), modifier = Modifier.clickable { breakpointFile?.let { EditorBreakpointStore.remove(it, bp.line); persistBreakpoints(it) }; if (selectedBreakpointLine == bp.line) selectedBreakpointLine = null }.padding(horizontal = 6.dp))
                    }
                }
                if (selectedBreakpointLine != null) {
                    Text("Configure line $selectedBreakpointLine", color = Color(IdeTheme.ACCENT), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 5.dp))
                    OutlinedTextField(value = conditionInput, onValueChange = { conditionInput = it.take(500) }, label = { Text("Condition · optional Python expression") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = hitConditionInput, onValueChange = { hitConditionInput = it.take(100) }, label = { Text("Hit condition · e.g. 5 or >= 3") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = logMessageInput, onValueChange = { logMessageInput = it.take(500) }, label = { Text("Log message · {expression} supported") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = {
                            val file = breakpointFile ?: return@Button
                            val line = selectedBreakpointLine ?: return@Button
                            val old = EditorBreakpointStore.all(file).firstOrNull { it.line == line } ?: EditorBreakpoint(line)
                            EditorBreakpointStore.update(file, old.copy(condition = conditionInput.trim(), hitCondition = hitConditionInput.trim(), logMessage = logMessageInput.trim()))
                            persistBreakpoints(file); selectedBreakpointLine = null
                        }) { Text("Apply") }
                        TextButton(onClick = { selectedBreakpointLine = null }) { Text("Cancel") }
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.CARD)), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(8.dp)) {
                Text("Watch expressions", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = watchInput, onValueChange = { watchInput = it.take(500) }, label = { Text("Python expression") }, singleLine = true, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(5.dp))
                    Button(enabled = watchInput.isNotBlank() && watches.size < 20, onClick = { controller.addWatch(watchInput); watchInput = "" }) { Text("Add") }
                }
                watches.forEach { expression ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(expression, color = Color(IdeTheme.TEXT), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            Text(watchValues[expression] ?: if (status == "Paused") "Not evaluated" else "Evaluated when paused", color = Color(IdeTheme.DIM), fontSize = 10.sp, maxLines = 3)
                        }
                        Text("↻", color = Color(IdeTheme.ACCENT), modifier = Modifier.clickable { controller.refreshWatches() }.padding(6.dp))
                        Text("×", color = Color(IdeTheme.ERROR), modifier = Modifier.clickable { controller.removeWatch(expression) }.padding(6.dp))
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = programInput, onValueChange = { programInput = it.take(2000) }, label = { Text("Program stdin") }, singleLine = true, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(5.dp))
            Button(enabled = session != null && programInput.isNotEmpty(), onClick = { controller.sendProgramInput(programInput) { sent -> if (sent) programInput = "" } }) { Text("Send") }
        }
        if (debugThreads.size > 1 && status == "Paused") {
            Text("Threads", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                debugThreads.forEach { thread ->
                    val id = thread.optInt("id", -1)
                    Text("${if (debugThreadId == id) "● " else "○ "}${thread.optString("name", "Thread $id")}", color = if (debugThreadId == id) Color(IdeTheme.ACCENT) else Color(IdeTheme.DIM), fontSize = 10.sp,
                        modifier = Modifier.clickable { controller.selectThread(id) }.padding(5.dp))
                }
            }
        }
        if (stackFrames.isNotEmpty()) {
            Text("Call Stack · ${stackFrames.size} frame(s)", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(top = 7.dp))
            stackFrames.take(50).forEach { frame ->
                val line = frame.optInt("line"); val name = frame.optString("name", "<module>"); val source = frame.optJSONObject("source")?.optString("path").orEmpty(); val id = frame.optInt("id", -1)
                Text("${if (selectedFrameId == id) "▶ " else "  "}$name · ${File(source).name}:$line", color = if (selectedFrameId == id) Color(IdeTheme.ACCENT) else Color(IdeTheme.DIM), fontSize = 10.sp, fontFamily = FontFamily.Monospace,
                    modifier = Modifier.fillMaxWidth().clickable { controller.selectFrame(frame) }.padding(vertical = 3.dp))
            }
        }
        if (variables.isNotEmpty()) {
            Text("Variables · selected frame", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.SemiBold, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            DebugVariableTreeRows(variables.take(500), expandedVariables) { item -> controller.toggleVariable(item) }
        }
        Spacer(Modifier.height(5.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Debugger Output", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { controller.clearOutput() }) { Text("Clear", fontSize = 11.sp) }
        }
        Text(output, fontSize = 10.sp, lineHeight = 14.sp, fontFamily = FontFamily.Monospace, color = Color(IdeTheme.TEXT), modifier = Modifier.fillMaxWidth().height(170.dp).verticalScroll(scroll).padding(bottom = 4.dp))
    }
}

// Test Explorer is implemented in TestExplorer.kt.

private fun relPath(project: PyProject?, file: File): String {
    return try {
        if (project != null) {
            project.dir.toURI().relativize(file.toURI()).path.ifEmpty { file.name }
        } else {
            file.name
        }
    } catch (_: Exception) {
        file.name
    }
}
