package com.codespace.ide.ide

/** Stable inventory and validation rules for the Python editor's extra-key bar. */
object EditorSymbolCatalog {
    const val PINNED_COUNT = 4
    const val DEFAULT_ORDER_KEY_SEPARATOR = "\u001F"

    val defaults: List<String> = listOf(
        ":", "(", ")", ",", "[", "]", "{", "}", ".", "=", "==", "+", "-", "*", "/", "//",
        "\"", "'", "#", "_", "TAB", "->", "=>"
    )

    /** Reject partial, duplicated, or unknown inventories rather than silently losing keys. */
    fun normalize(value: List<String>?): List<String> {
        val candidate = value ?: return defaults
        return if (candidate.size == defaults.size && candidate.toSet() == defaults.toSet()) {
            candidate.toList()
        } else defaults
    }

    fun decode(raw: String?): List<String> {
        if (raw.isNullOrBlank()) return defaults
        return normalize(raw.split(DEFAULT_ORDER_KEY_SEPARATOR))
    }

    fun encode(value: List<String>): String =
        normalize(value).joinToString(DEFAULT_ORDER_KEY_SEPARATOR)
}
