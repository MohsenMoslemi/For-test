package com.codespace.ide.ide

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.codespace.ide.ide.theme.IdeTheme

/** Shared PySpace dialog surface. Keeps each call site's content/actions intact
 * while giving every confirmation, prompt and information dialog one visual style. */
@Composable
fun IdeAlertDialog(
    onDismissRequest: () -> Unit,
    modifier: Modifier = Modifier,
    confirmButton: @Composable () -> Unit = {},
    dismissButton: @Composable (() -> Unit)? = null,
    title: @Composable (() -> Unit)? = null,
    text: @Composable (() -> Unit)? = null,
    icon: @Composable (() -> Unit)? = null,
    shape: Shape = RoundedCornerShape(26.dp),
    containerColor: Color = Color(IdeTheme.PANEL),
    iconContentColor: Color = Color(IdeTheme.ACCENT),
    titleContentColor: Color = Color(IdeTheme.TEXT),
    textContentColor: Color = Color(IdeTheme.DIM),
    tonalElevation: androidx.compose.ui.unit.Dp = 0.dp,
    properties: DialogProperties = DialogProperties(usePlatformDefaultWidth = false)
) {
    Dialog(onDismissRequest = onDismissRequest, properties = properties) {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .widthIn(max = 484.dp)
                .padding(horizontal = 22.dp)
                .border(1.dp, Color(IdeTheme.LINE), shape),
            shape = shape,
            colors = CardDefaults.cardColors(containerColor = containerColor),
            elevation = CardDefaults.cardElevation(defaultElevation = maxOf(tonalElevation, 18.dp))
        ) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 21.dp)
            ) {
                if (title != null || icon != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(13.dp)
                    ) {
                        Box(
                            Modifier.size(42.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(iconContentColor.copy(alpha = 0.12f))
                                .border(1.dp, iconContentColor.copy(alpha = 0.24f), RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            CompositionLocalProvider(LocalContentColor provides iconContentColor) {
                                if (icon != null) icon() else Text("✦", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        if (title != null) {
                            Box(Modifier.weight(1f)) {
                                CompositionLocalProvider(
                                    LocalContentColor provides titleContentColor,
                                    LocalTextStyle provides MaterialTheme.typography.titleLarge.copy(
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                ) { title() }
                            }
                        }
                    }
                }
                if (text != null) {
                    Spacer(Modifier.height(if (title != null || icon != null) 15.dp else 2.dp))
                    CompositionLocalProvider(LocalContentColor provides textContentColor) {
                        text()
                    }
                }
                Spacer(Modifier.height(20.dp))
                Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (dismissButton != null) dismissButton()
                        confirmButton()
                }
            }
        }
    }
}

