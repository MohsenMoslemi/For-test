package com.codespace.ide.ide.github

import android.util.Base64
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeParseException
import java.nio.file.Files
import java.nio.file.FileSystems
import java.nio.file.PathMatcher
import java.nio.file.Paths
import java.util.zip.ZipInputStream
import org.json.JSONArray
import org.json.JSONObject

// Repository import: zip/tree download, unzip and clone. All helpers block; call on Dispatchers.IO.
// Pure I/O layer: no Compose, no UI state.

/** Downloads the exact selected branch zipball to [tmpFile] (follows GitHub's redirect to
 *  codeload, whose signed URL needs no re-auth). Caps at 250 MB. Returns
 *  null on success, an error line otherwise. Never throws. */
internal fun ghDownloadZip(token: String, fullName: String, branch: String, tmpFile: File): String? {
    val parts = fullName.split('/')
    if (parts.size != 2) return "Invalid repository name."
    val repoApi = "$GH_API/repos/${ghPathSegment(parts[0])}/${ghPathSegment(parts[1])}"
    // Never silently fall back to the default branch: a user-selected branch
    // must either be imported exactly or fail with a useful message.
    val refs = listOf("$repoApi/zipball/${ghRefPath(branch)}")
    try {
        tmpFile.parentFile?.mkdirs()
        for ((attempt, apiUrl) in refs.withIndex()) {
            var api: HttpURLConnection? = null
            try {
                api = (URL(apiUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 20000
                    readTimeout = 30000
                    instanceFollowRedirects = false
                    if (token.isNotBlank()) setRequestProperty("Authorization", "Bearer $token")
                    setRequestProperty("Accept", "application/vnd.github+json")
                    setRequestProperty("X-GitHub-Api-Version", GH_VERSION)
                    setRequestProperty("User-Agent", "PySpace-IDE")
                }
                val code = api.responseCode
                if (code == 404 && attempt == 0 && refs.size > 1) continue
                val downloadUrl = when (code) {
                    301, 302, 303, 307, 308 -> api.getHeaderField("Location")
                    200 -> apiUrl
                    else -> {
                        val body = try { api.errorStream?.bufferedReader()?.use { it.readText().take(2000) } ?: "" }
                            catch (_: Exception) { "" }
                        val detail = try { JSONObject(body).optString("message", "") } catch (_: Exception) { "" }
                        if (code == 404 && attempt == refs.lastIndex) {
                            return "No downloadable archive was found. The repository may be empty, the selected branch may not exist, or the token may need Contents: read access."
                        }
                        if (code == 403) return "GitHub denied archive access. Grant the token Contents: read permission."
                        return if (detail.isNotBlank()) "GitHub $code: $detail" else "GitHub download request failed ($code)."
                    }
                } ?: return "GitHub did not provide a download location."
                val resolvedDownloadUrl = try { URL(URL(apiUrl), downloadUrl).toString() } catch (_: Exception) { downloadUrl }
                // The signed codeload URL is public for the lifetime of the
                // redirect. Never forward the personal token to another host.
                var download: HttpURLConnection? = null
                try {
                    download = (URL(resolvedDownloadUrl).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 20000
                        readTimeout = 120000
                        instanceFollowRedirects = true
                        setRequestProperty("User-Agent", "PySpace-IDE")
                    }
                    val downloadCode = download.responseCode
                    if (downloadCode != 200) {
                        val detail = try { download.errorStream?.bufferedReader()?.use { it.readText().take(2000) } ?: "" }
                            catch (_: Exception) { "" }
                        return "Archive download failed ($downloadCode)${if (detail.isNotBlank()) ": ${detail.take(300)}" else ""}."
                    }
                    var total = 0L
                    download.inputStream.use { input ->
                        tmpFile.outputStream().use { output ->
                            val buffer = ByteArray(64 * 1024)
                            while (true) {
                                val n = input.read(buffer)
                                if (n < 0) break
                                total += n
                                if (total > 250L * 1024 * 1024) return "Archive too large (>250 MB)."
                                output.write(buffer, 0, n)
                            }
                        }
                    }
                    return null
                } finally {
                    download?.disconnect()
                }
            } finally {
                api?.disconnect()
            }
        }
        return "Repository archive was not found. Check repository access and its default branch."
    } catch (_: Exception) {
        return "Network error while downloading the repository."
    }
}

/**
 * Authenticated Git Trees/Blobs fallback for private repositories when the
 * archive redirect endpoint is unavailable. Unlike codeload, every request
 * stays on api.github.com and carries the user's token.
 */
internal fun ghDownloadTreeSnapshot(token: String, fullName: String, requestedBranch: String, dest: File): String {
    val parts = fullName.split('/')
    if (parts.size != 2) return "Invalid repository name."
    val target = "${ghPathSegment(parts[0])}/${ghPathSegment(parts[1])}"
    try {
        val repo = ghRequest("GET", "$GH_API/repos/$target", token)
        if (repo.code != 200) return ghErr(repo)
        val defaultBranch = try { JSONObject(repo.body).optString("default_branch", "main").ifBlank { "main" } } catch (_: Exception) { "main" }
        val branch = requestedBranch.ifBlank { defaultBranch }
        val ref = ghRequest("GET", "$GH_API/repos/$target/git/ref/heads/${ghRefPath(branch)}", token)
        if (ref.code != 200) return ghErr(ref)
        val commitSha = try { JSONObject(ref.body).optJSONObject("object")?.optString("sha", "") ?: "" } catch (_: Exception) { "" }
        if (commitSha.isBlank()) return "The selected branch has no readable commit."
        val commit = ghRequest("GET", "$GH_API/repos/$target/git/commits/$commitSha", token)
        if (commit.code != 200) return ghErr(commit)
        val treeSha = try { JSONObject(commit.body).optJSONObject("tree")?.optString("sha", "") ?: "" } catch (_: Exception) { "" }
        if (treeSha.isBlank()) return "GitHub returned an invalid repository tree."
        val treeResponse = ghRequest("GET", "$GH_API/repos/$target/git/trees/$treeSha?recursive=1", token, maxResponseChars = 12_000_000)
        if (treeResponse.code != 200) return ghErr(treeResponse)
        val treeJson = JSONObject(treeResponse.body)
        if (treeJson.optBoolean("truncated", false)) return "Repository is too large for a complete API clone. Try again with a smaller repository or use the archive endpoint."
        val entries = treeJson.optJSONArray("tree") ?: JSONArray()
        if (entries.length() > 4_000) return "Repository contains too many files for the authenticated API fallback (limit: 4,000)."
        val root = dest.canonicalFile
        if (!root.exists() && !root.mkdirs()) return "Could not create the project folder."
        var totalBytes = 0L
        var written = 0
        for (i in 0 until entries.length()) {
            val entry = entries.optJSONObject(i) ?: continue
            if (entry.optString("type") != "blob") continue
            // Symlinks and submodules are intentionally not materialized on Android.
            if (entry.optString("mode") == "120000") continue
            val path = entry.optString("path", "")
            if (path.isBlank() || path.startsWith('/') || path.contains('\\') ||
                path.split('/').any { it.isBlank() || it == "." || it == ".." }) continue
            val out = File(root, path)
            val canonical = out.canonicalFile
            if (!canonical.toPath().startsWith(root.toPath())) continue
            val sha = entry.optString("sha", "")
            val size = entry.optLong("size", -1L)
            if (sha.isBlank() || size < 0 || size > 20L * 1024 * 1024 || totalBytes + size > 500L * 1024 * 1024) {
                return "Repository contains a file outside the API clone limits (20 MB per file, 500 MB total)."
            }
            val blob = ghRequest("GET", "$GH_API/repos/$target/git/blobs/$sha", token, maxResponseChars = 30_000_000)
            if (blob.code != 200) return ghErr(blob)
            val blobJson = JSONObject(blob.body)
            if (!blobJson.optString("encoding").equals("base64", true)) return "GitHub returned an unsupported blob encoding for $path."
            val encoded = blobJson.optString("content", "").replace("\n", "").replace("\r", "")
            val bytes = try { Base64.decode(encoded, Base64.DEFAULT) } catch (_: Exception) { return "Could not decode $path from GitHub." }
            if (bytes.size.toLong() != size) return "GitHub returned an incomplete file: $path."
            val parent = canonical.parentFile ?: return "Invalid destination for $path."
            if (!parent.exists() && !parent.mkdirs()) return "Could not create a folder for $path."
            canonical.outputStream().use { it.write(bytes) }
            totalBytes += bytes.size
            written++
        }
        return if (written == 0) "The repository tree is empty or contains no downloadable files." else "Cloned $written files using the authenticated GitHub API."
    } catch (error: Exception) {
        return "Authenticated repository download failed: ${error.message ?: "network or storage error"}."
    }
}

/** Accept only GitHub HTTPS repository URLs; branch selection is a separate field. */
internal fun parseGitHubRepositoryUrl(raw: String): String? {
    return try {
        val value = raw.trim().removeSuffix("/")
        val normalized = if (value.startsWith("https://", true)) value else "https://$value"
        val uri = java.net.URI(normalized)
        val host = uri.host?.lowercase() ?: return null
        if (host != "github.com" && host != "www.github.com") return null
        val parts = uri.path.trim('/').split('/').filter { it.isNotBlank() }
        if (parts.size != 2) return null
        val owner = parts[0]
        val repo = parts[1].removeSuffix(".git")
        if (!owner.matches(Regex("[A-Za-z0-9-]+")) || !repo.matches(Regex("[A-Za-z0-9_.-]+"))) return null
        "$owner/$repo"
    } catch (_: Exception) { null }
}

/** Clone a GitHub repository into a new, non-existing destination directory. Runs on IO. */
internal fun cloneGitHubRepository(
    token: String,
    repositoryUrl: String,
    requestedBranch: String,
    destination: File,
    cacheDirectory: File
): String {
    val fullName = parseGitHubRepositoryUrl(repositoryUrl) ?: return "Enter a valid GitHub repository URL (https://github.com/owner/repository)."
    if (destination.exists()) return "A project folder with this name already exists."
    val parts = fullName.split('/')
    val target = "${ghPathSegment(parts[0])}/${ghPathSegment(parts[1])}"
    val repo = ghRequest("GET", "$GH_API/repos/$target", token)
    if (repo.code != 200) {
        return if (repo.code == 404) "GitHub cannot access this repository. It may be private; connect an account with Metadata: read and Contents: read permission in Settings → GitHub."
        else ghErr(repo)
    }
    val defaultBranch = try { JSONObject(repo.body).optString("default_branch", "main").ifBlank { "main" } } catch (_: Exception) { "main" }
    val branch = requestedBranch.trim().ifBlank { defaultBranch }
    if (!isValidGitBranchName(branch)) return "Invalid branch name."
    if (!cacheDirectory.exists()) cacheDirectory.mkdirs()
    val zip = try { File.createTempFile("pyspace-git-clone-", ".zip", cacheDirectory) } catch (_: Exception) { return "Could not create a temporary download file." }
    try {
        val archiveError = ghDownloadZip(token, fullName, branch, zip)
        if (archiveError == null) {
            val unpacked = unzipTo(zip, destination)
            if (unpacked.startsWith("Cloned")) return "$unpacked from $fullName ($branch)."
            try { destination.deleteRecursively() } catch (_: Exception) {}
        }
        // Private repositories can expose metadata while hiding archive/content
        // endpoints if the fine-grained token lacks Contents: read.
        val apiResult = ghDownloadTreeSnapshot(token, fullName, branch, destination)
        if (apiResult.startsWith("Cloned")) return "$apiResult from $fullName ($branch)."
        try { destination.deleteRecursively() } catch (_: Exception) {}
        return "${archiveError ?: "Archive extraction failed."} API fallback: $apiResult. For private repositories, grant Contents: read access to this repository (classic token: repo scope)."
    } catch (error: Exception) {
        try { destination.deleteRecursively() } catch (_: Exception) {}
        return "Clone failed: ${error.message ?: "network or storage error"}."
    } finally {
        try { zip.delete() } catch (_: Exception) {}
    }
}

/** Extracts a zipball under [dest] (strips GitHub's single top-level dir).
 *  Zip-slip guarded and capped. Returns a human result line. Never throws. */
internal fun unzipTo(zipFile: File, dest: File): String {
    var files = 0
    var total = 0L
    try {
        val rootCanon = try {
            dest.canonicalPath
        } catch (_: Exception) {
            return "Bad destination."
        }
        ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zin ->
            while (true) {
                val e = try {
                    zin.nextEntry
                } catch (_: Exception) {
                    return "Archive is corrupt."
                } ?: break
                var name = e.name
                val slash = name.indexOf('/')
                if (slash > 0) name = name.substring(slash + 1)
                if (name.isEmpty() || e.isDirectory) {
                    try {
                        zin.closeEntry()
                    } catch (_: Exception) {
                    }
                    continue
                }
                if (files >= 20000) return "Archive has too many files."
                val out = File(dest, name)
                val canon = try {
                    out.canonicalPath
                } catch (_: Exception) {
                    ""
                }
                if (canon.isEmpty() || !(canon == rootCanon || canon.startsWith(rootCanon + File.separator))) {
                    try {
                        zin.closeEntry()
                    } catch (_: Exception) {
                    }
                    continue
                }
                val dirOk = try {
                    out.parentFile?.mkdirs()
                    true
                } catch (_: Exception) {
                    false
                }
                if (!dirOk) {
                    try {
                        zin.closeEntry()
                    } catch (_: Exception) {
                    }
                    continue
                }
                try {
                    out.outputStream().use { ous ->
                        val buf = ByteArray(64 * 1024)
                        var left = 100L * 1024 * 1024
                        while (true) {
                            val n = zin.read(buf)
                            if (n < 0) break
                            left -= n
                            total += n
                            if (left < 0 || total > 500L * 1024 * 1024) {
                                return "Archive too large to unpack."
                            }
                            ous.write(buf, 0, n)
                        }
                    }
                    files++
                } catch (_: Exception) {
                    return "Unpack failed mid-archive."
                } finally {
                    try {
                        zin.closeEntry()
                    } catch (_: Exception) {
                    }
                }
            }
        }
    } catch (_: Exception) {
        return "Unpack failed."
    }
    return if (files == 0) "Archive was empty." else "Cloned $files files ✓"
}

internal fun uniqueDir(parent: File, name: String): File {
    val safe = name.trim().replace(Regex("\\s+"), "_").ifBlank { "repository" }
    var cand = File(parent, safe)
    var i = 1
    try {
        while (cand.exists() && i < 1000) {
            cand = File(parent, "${safe}_$i")
            i++
        }
    } catch (_: Exception) {
    }
    return cand
}
