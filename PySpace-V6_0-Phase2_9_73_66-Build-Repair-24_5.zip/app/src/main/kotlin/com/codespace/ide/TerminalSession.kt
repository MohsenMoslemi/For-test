package com.codespace.ide

import java.nio.ByteBuffer
import java.nio.CharBuffer
import java.nio.charset.CharsetDecoder
import java.nio.charset.CodingErrorAction
import java.util.concurrent.atomic.AtomicBoolean

/**
 * PTY-backed persistent shell over the STABLE PRoot backend.
 *
 * One TerminalSession owns exactly one native PTY session:
 *
 *   Android UI -> TerminalSession -> PTY master (native)
 *     -> PTY slave = child stdin/stdout/stderr + controlling terminal
 *     -> existing PRoot command -> existing Ubuntu rootfs -> bash
 *
 * The shell genuinely believes it is on a terminal (job control, line
 * discipline, signals all handled by the kernel). There is intentionally NO
 * pipe transport anymore and NO silent fallback to one: if PTY creation
 * fails, [onError] reports it loudly.
 *
 * PRoot configuration is never duplicated here: argv/env come from
 * [ProotManager.interactiveShellCommand], which shares binds, workdir and
 * environment with [ProotManager.runOnce].
 *
 * Threading: [onOutput], [onExit] and [onError] are invoked on internal
 * background threads. Callers must hop to the main thread themselves.
 */
class TerminalSession(
    private val proot: ProotManager,
    private val onOutput: (String) -> Unit,
    private val onExit: (Int) -> Unit,
    private val onError: (Throwable) -> Unit
) {

    companion object {
        const val DEFAULT_ROWS = 24
        const val DEFAULT_COLS = 80
    }

    private val closed = AtomicBoolean(false)

    @Volatile
    private var masterFd = -1

    @Volatile
    private var childPid = -1

    private var readerThread: Thread? = null
    private var waiterThread: Thread? = null

    // A native read can still be inside poll()/read() while another thread
    // closes the descriptor. Serialize descriptor release with both native
    // read and write/resize calls so the OS cannot reuse the fd mid-call.
    private val readLock = Any()
    private val writeLock = Any()

    private var decoder: CharsetDecoder? = null
    private var carry: ByteBuffer? = null

    /**
     * Spawns the PTY shell. Blocks briefly while the child spawns — call off
     * the main thread. Failures (including native load problems) go to
     * [onError]; there is no fallback transport.
     *
     * @param runCommand when non-null, the child runs this guest command on
     * a real PTY instead of a login shell (IDE console runs). Null keeps the
     * exact historical shell behavior.
     * @param workDir guest-absolute starting directory for login shells.
     * @param promptVenv guest venv dir for invisible auto-activation (see
     * [ProotManager.interactiveShellCommand]). Null = plain user prompt.
     */
    fun start(
        rows: Int = DEFAULT_ROWS,
        cols: Int = DEFAULT_COLS,
        runCommand: String? = null,
        workDir: String? = null,
        promptVenv: String? = null
    ) {
        val cmd = try {
            if (runCommand != null) proot.interactiveRunCommand(runCommand)
            else proot.interactiveShellCommand(workdir = workDir, venvGuestPath = promptVenv)
        } catch (t: Throwable) {
            onError(t)
            return
        }

        val opened = try {
            PtyNative.open(
                cmd.argv.toTypedArray(),
                cmd.env.entries.map { (k, v) -> "$k=$v" }.toTypedArray(),
                rows,
                cols
            )
        } catch (t: Throwable) {
            onError(
                IllegalStateException(
                    "PTY initialization failed: " +
                        (t.message ?: t.javaClass.simpleName)
                )
            )
            return
        }

        if (opened == null || opened.size < 2) {
            val detail = try {
                PtyNative.lastError()
            } catch (_: Throwable) {
                "unknown error"
            }
            onError(IllegalStateException("PTY initialization failed: $detail"))
            return
        }

        synchronized(writeLock) {
            if (closed.get()) {
                try {
                    // Whole group (see close()): never orphan descendants.
                    if (PtyNative.killProcessGroup(opened[1], 9) != 0) {
                        PtyNative.killPid(opened[1], 9)
                    }
                } catch (_: Throwable) {
                }
                try {
                    PtyNative.closeFd(opened[0])
                } catch (_: Throwable) {
                }
                return
            }
            masterFd = opened[0]
            childPid = opened[1]
            decoder = Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPLACE)
                .onUnmappableCharacter(CodingErrorAction.REPLACE)
            carry = null
        }

        readerThread = Thread({
            val buf = ByteArray(4096)
            while (!closed.get()) {
                val n = try {
                    synchronized(readLock) {
                        if (closed.get()) -1
                        else {
                            val fd = masterFd
                            if (fd < 0) -1 else PtyNative.readFd(fd, buf, buf.size)
                        }
                    }
                } catch (_: Exception) {
                    break
                }
                if (n < 0) break
                if (n == 0) continue
                val text = try {
                    decodeChunk(buf, n)
                } catch (_: Exception) {
                    continue
                }
                if (text.isNotEmpty() && !closed.get()) {
                    try {
                        onOutput(text)
                    } catch (_: Exception) {
                        break
                    }
                }
            }
        }, "terminal-reader").also { it.isDaemon = true; it.start() }

        // Capture the spawned PID before the waiter starts. close() invalidates
        // childPid immediately, but waitpid must still reap this exact child.
        val pidToWait = childPid
        waiterThread = Thread({
            var waitFailure: Throwable? = null
            val code = try {
                PtyNative.waitPid(pidToWait)
            } catch (error: Exception) {
                waitFailure = error
                -1
            }
            if (!closed.get()) {
                try {
                    when {
                        waitFailure != null -> onError(waitFailure!!)
                        code >= 0 -> onExit(code)
                        else -> onError(IllegalStateException("Unable to wait for terminal process"))
                    }
                } catch (_: Exception) {
                } finally {
                    // waitpid has already reaped the leader. Release the PTY
                    // without signalling its numeric PID: after reaping, that
                    // number may be reused by an unrelated process group.
                    releaseAfterExit()
                }
            }
        }, "terminal-waiter").also { it.isDaemon = true; it.start() }
    }

    /**
     * Incremental UTF-8 decode: a multibyte character split across two PTY
     * reads must not become replacement garbage. Trailing incomplete bytes
     * are carried into the next chunk. (Byte handling, not emulation.)
     */
    private fun decodeChunk(bytes: ByteArray, n: Int): String {
        val dec = decoder ?: return String(bytes, 0, n, Charsets.UTF_8)
        val pending = carry
        val input = if (pending == null) {
            ByteBuffer.wrap(bytes, 0, n)
        } else {
            val merged = ByteBuffer.allocate(pending.remaining() + n)
            merged.put(pending)
            merged.put(bytes, 0, n)
            merged.flip()
            merged
        }
        carry = null
        val out = CharBuffer.allocate(n + 8)
        val sb = StringBuilder()
        while (true) {
            val res = dec.decode(input, out, false)
            out.flip()
            sb.append(out)
            out.clear()
            if (res.isUnderflow) {
                if (input.hasRemaining()) {
                    val rest = ByteArray(input.remaining())
                    input.get(rest)
                    carry = ByteBuffer.wrap(rest)
                }
                break
            }
            // OVERFLOW was flushed above; malformed input is REPLACE-d.
        }
        return sb.toString()
    }

    /** Writes raw bytes to the PTY master (user input, control chars). */
    fun send(text: String): Boolean = synchronized(writeLock) {
        val fd = masterFd
        if (closed.get() || fd < 0) return@synchronized false
        try {
            val bytes = text.toByteArray(Charsets.UTF_8)
            PtyNative.writeFd(fd, bytes, bytes.size) >= 0
        } catch (_: Exception) {
            false
        }
    }

    /** Applies TIOCSWINSZ on the PTY master. */
    fun resize(rows: Int, cols: Int): Boolean = synchronized(writeLock) {
        val fd = masterFd
        if (closed.get() || fd < 0) return@synchronized false
        try {
            PtyNative.setWinSize(fd, rows, cols) == 0
        } catch (_: Exception) {
            false
        }
    }

    fun isAlive(): Boolean {
        val pid = childPid
        if (pid <= 0 || closed.get()) return false
        return try {
            PtyNative.alive(pid)
        } catch (_: Exception) {
            false
        }
    }


    /** Releases descriptors after waitpid has reaped the child; never kill by
     * the now-reusable PID in this path. */
    private fun releaseAfterExit() {
        if (!closed.compareAndSet(false, true)) return
        childPid = -1
        try { readerThread?.interrupt() } catch (_: Exception) { }
        closeMasterFdSafely()
    }

    /**
     * Stops the shell and releases the PTY. Idempotent.
     * SIGKILL goes to the WHOLE process group first (the child setsid()s, so
     * its PID is its PGID): this kills PRoot, python, uvicorn workers — the
     * lot. Killing only the leader orphaned servers and left ports bound,
     * which is why Stop/Rerun used to lie. The blocked reader then observes
     * EOF promptly. Descriptor closure waits for any in-flight JNI read/write
     * to finish, preventing a close/read race from touching a reused fd.
     */
    fun close() {
        if (!closed.compareAndSet(false, true)) return
        val pid = childPid
        childPid = -1
        try {
            if (pid > 0) {
                if (PtyNative.killProcessGroup(pid, 9) != 0) {
                    PtyNative.killPid(pid, 9)
                }
            }
        } catch (_: Exception) {
        }
        try {
            readerThread?.interrupt()
        } catch (_: Exception) {
        }
        try {
            waiterThread?.interrupt()
        } catch (_: Exception) {
        }
        closeMasterFdSafely()
    }

    /**
     * Close only after any in-flight JNI operation has left its critical
     * section. Lock order is always readLock -> writeLock; readers and writers
     * each hold only their own lock, so this cannot form a lock cycle.
     */
    private fun closeMasterFdSafely() {
        synchronized(readLock) {
            synchronized(writeLock) {
                val fd = masterFd
                masterFd = -1
                if (fd >= 0) {
                    try { PtyNative.closeFd(fd) } catch (_: Exception) { }
                }
            }
        }
    }
}
