package com.codespace.ide.ide.run

import com.codespace.ide.runtime.RuntimeDispatchers
import java.io.File
import kotlinx.coroutines.withContext
import com.codespace.ide.ide.WebAutoRun
import com.codespace.ide.ide.WebServer
import com.codespace.ide.ide.projects.PyProject

/** Result of the disk-backed web preparation used by the Console Run action. */
data class ConsoleWebPreparation(
    val autoRun: WebAutoRun?,
    val projectGuess: WebServer?,
)

/**
 * IO boundary for project-wide web discovery and generated framework commands.
 * The existing bounded scanner remains the single source of detection rules;
 * this repository guarantees it is never called from the Compose Main thread.
 */
class ProjectWebResolverRepository(
    private val dispatchers: RuntimeDispatchers = RuntimeDispatchers.Default,
) {
    suspend fun prepareConsole(
        project: PyProject,
        activeFile: File,
        sourceSnapshot: String?,
        originalSourceText: String?,
        immediate: WebServer?,
        pythonBin: String,
    ): ConsoleWebPreparation = withContext(dispatchers.io) {
        val auto = when {
            immediate != null && !immediate.launchable ->
                webAutoRun(project.dir, activeFile, originalSourceText, immediate, pythonBin)
            immediate == null ->
                resolveProjectWebRun(project, activeFile, sourceSnapshot, pythonBin)
            else -> null
        }
        val guess = if (immediate?.launchable == true) immediate
        else detectWebServerInProject(project, activeFile, sourceSnapshot) ?: immediate
        ConsoleWebPreparation(auto, guess)
    }

    suspend fun prepareTerminal(
        project: PyProject?,
        activeFile: File?,
        sourceText: String?,
        immediate: WebServer?,
        pythonBin: String,
    ): WebAutoRun? = withContext(dispatchers.io) {
        val projectDir = project?.dir ?: activeFile?.parentFile
        if (immediate != null && !immediate.launchable && projectDir != null && activeFile != null) {
            webAutoRun(projectDir, activeFile, sourceText, immediate, pythonBin)
        } else if (immediate == null && project != null && activeFile != null && sourceText != null) {
            resolveProjectWebRun(project, activeFile, sourceText, pythonBin)
        } else {
            null
        }
    }

    suspend fun detectProject(project: PyProject, activeFile: File?, sourceText: String?): WebServer? =
        withContext(dispatchers.io) {
            detectWebServerInProject(project, activeFile, sourceText)
        }
}
