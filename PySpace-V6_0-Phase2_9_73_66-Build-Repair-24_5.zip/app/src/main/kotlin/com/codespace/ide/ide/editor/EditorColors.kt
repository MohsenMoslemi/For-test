package com.codespace.ide.ide.editor

import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextDecoration
import com.codespace.ide.ide.EditorLanguageRegistry
import com.codespace.ide.ide.codeintel.PythonSyntaxDiagnostic
import com.codespace.ide.ide.theme.IdeTheme
import java.io.File

/** Language colors and editor overlays over the untouched source buffer.
 *  The separate identity cache keeps syntax tokenization warm across cursor,
 *  diagnostic, breakpoint, and fold-presentation changes. UI-thread only. */
internal class EditorHighlightCache(private val file: File) {
    // One-entry identity cache survives fold/diagnostic presentation changes:
    // selection-only recompositions and gutter folding never re-tokenize a file.
    private var cachedInput: String? = null
    private var cachedOutput: AnnotatedString? = null
    private var cachedThemeId: String? = null

    fun highlight(source: String): AnnotatedString {
        val themeId = IdeTheme.themeId
        if (source === cachedInput && themeId == cachedThemeId) {
            val cached = cachedOutput
            if (cached != null) return cached
        }
        return EditorLanguageRegistry.highlight(file, source).also {
            cachedInput = source
            cachedThemeId = themeId
            cachedOutput = it
        }
    }
}

internal class EditorColors(
    private val highlightCache: EditorHighlightCache,
    val flashLn: Int? = null,
    private val diagnostics: List<PythonSyntaxDiagnostic> = emptyList(),
    private val foldedDocument: FoldedEditorDocument? = null,
    private val glueIndent: Boolean = false,
) : VisualTransformation {
    // Word wrap: Android may break right after the leading indentation when the first
    // word does not fit next to it, leaving a row that holds only spaces (the line number
    // then sits beside an apparently empty row and the code looks de-indented below it).
    // No-break spaces keep the indentation glued to the first word; the length and every
    // offset are unchanged, and the real text (copy, save, caret) is untouched.
    private fun finish(t: TransformedText): TransformedText =
        if (glueIndent) TransformedText(glueLeadingIndent(t.text), t.offsetMapping) else t

    override fun filter(text: AnnotatedString): TransformedText {
        val src = text.text
        val colored = highlightCache.highlight(src)
        if (flashLn == null && diagnostics.isEmpty()) {
            return finish(foldedDocument?.transformed(colored) ?: TransformedText(colored, OffsetMapping.Identity))
        }
        val out = AnnotatedString.Builder(colored)
        val ln = flashLn
        if (ln != null) {
            val range = lineRangeOf(src, ln)
            if (range != null && range.first < range.last) {
                out.addStyle(
                    SpanStyle(background = Color(IdeTheme.ACCENT).copy(alpha = 0.20f)),
                    range.first, range.last
                )
            }
        }
        diagnostics.forEach { diagnostic ->
            val range = syntaxDiagnosticRange(src, diagnostic) ?: return@forEach
            val severityColor = when (diagnostic.kind.lowercase()) {
                "error", "syntaxerror" -> Color(IdeTheme.ERROR)
                "warning" -> Color(IdeTheme.WARN)
                "information" -> Color(IdeTheme.INFO)
                else -> Color(IdeTheme.DIM)
            }
            out.addStyle(
                SpanStyle(
                    color = severityColor,
                    // Diagnostics underline the affected token; they do not
                    // paint the entire line. Selection/active-line styling owns backgrounds.
                    textDecoration = TextDecoration.Underline,
                ),
                range.first, range.last + 1
            )
        }
        val annotated = out.toAnnotatedString()
        return finish(foldedDocument?.transformed(annotated) ?: TransformedText(annotated, OffsetMapping.Identity))
    }
}
