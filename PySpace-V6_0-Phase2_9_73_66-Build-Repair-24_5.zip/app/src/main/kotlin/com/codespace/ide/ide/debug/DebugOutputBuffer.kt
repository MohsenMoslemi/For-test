package com.codespace.ide.ide.debug

/**
 * Thread-safe bounded staging buffer for debugger stdout/stderr.
 * DAP reader threads append; the controller drains on the main-thread flush
 * cadence. This class has no Android or UI dependencies.
 */
internal class DebugOutputBuffer(private val maxChars: Int = 150_000) {
    private val lock = Any()
    private val pending = StringBuilder()

    init { require(maxChars > 0) }

    fun append(text: String) {
        if (text.isEmpty()) return
        synchronized(lock) {
            pending.append(text)
            if (pending.length > maxChars) {
                pending.delete(0, pending.length - maxChars)
            }
        }
    }

    fun drain(): String = synchronized(lock) {
        if (pending.isEmpty()) return@synchronized ""
        pending.toString().also { pending.setLength(0) }
    }

    fun clear() = synchronized(lock) { pending.setLength(0) }
}
