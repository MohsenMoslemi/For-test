package com.codespace.ide.ide

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ide.theme.IdeTheme

/**
 * A slim bar above the Terminal: every program started from a terminal command shows up here with the
 * same controls as a Console run (Browser when it serves a web page, Display for graphical apps, Stop).
 */
@Composable
fun RunStrip(
    runs: List<RunInfo>,
    displayOpen: Boolean,
    onBrowser: (String) -> Unit,
    onDisplay: () -> Unit,
    onStop: (RunInfo) -> Unit,
    modifier: Modifier = Modifier
) {
    if (runs.isEmpty()) return
    Column(modifier.fillMaxWidth().background(Color(IdeTheme.PANEL))) {
        for (r in runs.take(3)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(
                    Modifier.size(12.dp), strokeWidth = 2.dp, color = Color(IdeTheme.ACCENT)
                )
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        r.title, color = Color(IdeTheme.TEXT), fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        r.webUrl ?: "Running in the Terminal",
                        color = Color(IdeTheme.DIM), fontSize = 11.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                val url = r.webUrl
                if (url != null) {
                    PillButton("Browser", Color(IdeTheme.ACCENT)) { onBrowser(url) }
                    Spacer(Modifier.width(6.dp))
                }
                if (r.usesDisplay && !displayOpen) {
                    PillButton("Display", Color(IdeTheme.TEXT)) { onDisplay() }
                    Spacer(Modifier.width(6.dp))
                }
                PillButton("Stop", Color(IdeTheme.ERROR)) { onStop(r) }
            }
        }
        Divider(color = Color(IdeTheme.LINE))
    }
}
