package com.codespace.ide.ide.shell

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModelProvider
import com.codespace.ide.ProotManager
import com.codespace.ide.ide.ConsoleRunPreparationCoordinator
import com.codespace.ide.UbuntuManager
import com.codespace.ide.runtime.RuntimeTaskScope
import com.codespace.ide.runtime.RuntimeDispatchers
import com.codespace.ide.application.editor.usecase.SerializeEditorSessionUseCase
import com.codespace.ide.domain.packages.PackageManagerRepository
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import com.codespace.ide.ide.codeintel.CodeIntelligenceRepository
import com.codespace.ide.ide.editor.EditorSession
import com.codespace.ide.ide.editor.EditorViewModel
import com.codespace.ide.ide.BrowserState
import com.codespace.ide.ide.IdeBridge
import com.codespace.ide.ide.IdeScreen
import com.codespace.ide.ide.PanelTab
import com.codespace.ide.ide.ProjectViewModelStoreRegistry
import com.codespace.ide.ide.RunHub
import com.codespace.ide.ide.RunInfo
import com.codespace.ide.ide.camera.PhoneCamera
import com.codespace.ide.ide.codeintel.PythonCompletionItem
import com.codespace.ide.ide.debug.DebugController
import com.codespace.ide.ide.display.FrameDisplay
import com.codespace.ide.ide.display.VncDisplay
import com.codespace.ide.ide.explorer.FileExplorerRepository
import com.codespace.ide.ide.gui.GuiApp
import com.codespace.ide.ide.notebook.NotebookRepository
import com.codespace.ide.ide.projects.ProjectRepository
import com.codespace.ide.ide.projects.PyProject
import com.codespace.ide.ide.projects.PythonRuntimeInstaller
import com.codespace.ide.ide.run.CameraRunCommandFactory
import com.codespace.ide.ide.run.CameraRunCoordinator
import com.codespace.ide.ide.run.ConsoleDisplayLifecycleCoordinator
import com.codespace.ide.ide.run.ConsoleRunCompletionCoordinator
import com.codespace.ide.ide.run.ConsoleRunLaunchCoordinator
import com.codespace.ide.ide.run.ConsoleRunLaunchRequest
import com.codespace.ide.ide.run.ConsoleRunPlanningCoordinator
import com.codespace.ide.ide.run.ConsoleWebPreparation
import com.codespace.ide.ide.run.DisplayRunCoordinator
import com.codespace.ide.ide.run.ExpiringPlanStore
import com.codespace.ide.ide.run.ProjectWebResolverRepository
import com.codespace.ide.ide.run.RunOrchestrator
import com.codespace.ide.ide.runtimeui.RuntimeUiViewModel
import com.codespace.ide.ide.settings.IdePrefs
import com.codespace.ide.ide.terminal.ConsoleState
import com.codespace.ide.ide.terminal.TermBridge
import com.codespace.ide.ide.terminal.TermController

/**
 * IDE host coordinator: delegates navigation/panel state and project feature ownership to
 * focused holders, while coordinating console/terminal/display runs, the IDE bridge and session persistence.
 * Created once by IdeRoot (remember) and used through `with(shell) { ... }`; it holds no
 * composition-bound objects except the camera permission launcher, which IdeRoot assigns.
 */
internal class IdeShell(
    val context: Context,
    val workspace: File,
    val proot: ProotManager,
    val ubuntu: UbuntuManager,
    val prefs: IdePrefs,
    val ideScope: CoroutineScope,
    val runtimeUiViewModel: RuntimeUiViewModel,
    val projectViewModelStores: ProjectViewModelStoreRegistry?,
    val notebookRepository: NotebookRepository,
    val hub: RunHub,
    val runOrchestrator: RunOrchestrator,
    val projectWebResolver: ProjectWebResolverRepository,
    private val runtimeTaskScope: RuntimeTaskScope,
    private val fileExplorerRepository: FileExplorerRepository,
    private val codeIntelligenceRepository: CodeIntelligenceRepository,
    private val runtimeDispatchers: RuntimeDispatchers,
    private val serializeEditorSession: SerializeEditorSessionUseCase,
    val packageManagerRepository: PackageManagerRepository,
    val projectRepository: ProjectRepository,
) {
    val appContext: Context = context.applicationContext

    // Current values of the Activity-scoped runtime UI state, read at call time by the logic below.
    // (The composable keeps its own collectAsState() locals for reactive reads.)
    private val runtimeUi get() = runtimeUiViewModel.state.value
    val displayOpen get() = runtimeUi.displayOpen
    val frameMode get() = runtimeUi.frameMode

    /** Activity-result launchers can only be created in composition; the composable assigns it. */
    lateinit var camPermission: androidx.activity.compose.ManagedActivityResultLauncher<String, Boolean>

    val bridge = run { TermBridge() }

    var venvBusyBuild by mutableStateOf(false)

    var venvBuildMsg by mutableStateOf<String?>(null)

    // Resolve the persisted launch marker once, outside the UI composition.
    // The immutable result is the sole source for both the restored screen
    // and the missing-project recovery prompt.
    private val launchRestore = IdeLaunchRestoreState.resolve(prefs.lastProject)
    val lastProjectPath = launchRestore.lastProjectPath
    val missingProjectOnLaunch = launchRestore.missingProject
    val restoredScreen = launchRestore.restoredScreen

    // Presentation state is grouped by responsibility. IdeShell keeps compatibility
    // accessors for the existing shell UI while each holder is the single state owner.
    val navigationState = IdeNavigationState(
        initialScreen = restoredScreen ?: IdeScreen.Home,
        initialMissingProject = missingProjectOnLaunch,
    )
    var screen by navigationState.screen
    var missingProject by navigationState.missingProject
    var recoveryAvailable by navigationState.recoveryAvailable
    var recoveryBusy by navigationState.recoveryBusy
    var recoveryError by navigationState.recoveryError
    var settingsOpen by navigationState.settingsOpen
    var homeTab by navigationState.homeTab

    val panelState = IdePanelState()
    var panelOpen by panelState.open
    var panelFrac by panelState.fraction
    var panelTab by panelState.tab
    var pendingImportSelection by panelState.pendingImportSelection

    // ProjectFeatureRegistry is the sole owner of project-keyed feature instances.
    // The aliases preserve the existing call surface while centralizing lifetime ownership.
    val projectFeatures = ProjectFeatureRegistry()
    val editors get() = projectFeatures.editors
    val fileExplorerViewModels get() = projectFeatures.fileExplorers
    val codeIntelligenceViewModels get() = projectFeatures.codeIntelligence
    val debugControllers get() = projectFeatures.debugControllers

    fun debugControllerFor(project: PyProject): com.codespace.ide.ide.debug.DebugController {
        val path = project.dir.absolutePath
        return debugControllers.getOrPut(path) {
            com.codespace.ide.ide.debug.DebugController(
                appContext = context,
                proot = proot,
                project = project,
                openLocation = { file, line ->
                    editors[path]?.let { editor ->
                        editor.session.jumpRequest = file.absolutePath to line
                        editor.openFile(file)
                    }
                }
            )
        }
    }

    val console = run { ConsoleState() }

    // ---- Run hub + IDE bridge: Console runs and Terminal runs share ONE state ----
    // App-scoped: the foreground service (and a recreated Activity) sees the same
    // runs, so the notification and the Stop action never disagree with the screen.
    private val runSessionState = IdeRunSessionState()
    var webPreparationRequest by runSessionState.webPreparationRequest
    var cameraPreparationRequest by runSessionState.cameraPreparationRequest

    // Stop escalation must outlive this Activity if it is recreated during
    // the 2.5-second SIGTERM grace period.
    val runTaskScope = runtimeTaskScope.scope

    val ideBridge = run { IdeBridge(File(context.filesDir, "proot-ubuntu-tmp")).also { it.startAsync() } }

    // Owns the final command + shared-registry publication transaction for Console runs.
    private val consoleRunLaunchCoordinator = ConsoleRunLaunchCoordinator(runOrchestrator)
    private val consoleRunPlanningCoordinator = ConsoleRunPlanningCoordinator()

    // Bridge callbacks run on bounded server workers. This gate prevents a callback
    // already queued by the old host from touching its disposed Compose state.
    val bridgeHostActive = run { AtomicBoolean(true) }

    var consoleRun by runSessionState.consoleRun
    var displayOwner by runSessionState.displayOwner
    var pendingConflict by runSessionState.pendingConflict

    // The console run: a guest command string + generation. Bumping runId
    // recreates the console PTY session (dispose kills the old guest).
    // `live` is the explicit lifetime: leaving the Console tab (or closing
    // the panel) ends it, so a later return can never silently re-execute
    // the program — only ▶/Rerun starts a run.
    var consoleCmd by runSessionState.consoleCmd
    var consoleRunId by runSessionState.consoleRunId
    var consoleLive by runSessionState.consoleLive

    val consoleCtl = run { TermController() }

    // Smart web-run state: a static project/framework guess made when Run
    // fires, upgraded to the exact printed address when the console logs it.
    // Guards the delayed restart in rerunConsole: a fresh Run or an explicit
    // Stop cancels a restart that has not fired yet, so one tap can never
    // resurrect a server the user just killed.
    var consoleRestartSeq by runSessionState.consoleRestartSeq

    // Embedded Linux display (Xvnc in guest + in-app VNC viewer). The
    // holder owns the server lifecycle and the viewer socket; displayOpen
    // only shows/hides the fullscreen overlay.
    val display = run { VncDisplay(proot, ideScope, context) }

    // Xvnc startup runs on IO; only a still-current run may attach the viewer.
    val displayRunCoordinator = run { DisplayRunCoordinator() }

    // Lightweight picture path (cv2.imshow / matplotlib) without X11/VNC.
    val frameDisplay = run { FrameDisplay(context, ideScope) }

    // Set when the user taps Hide: the auto-open of this run must not fight that choice.
    // Phone camera → Python bridge (CameraX + localhost JPEG server). Idle
    // until used: no permission is ever asked unless a camera start happens.
    val phoneCam = run { PhoneCamera(context, ideScope) }

    // The coordinator moves bridge socket/shim preparation to IO while keeping
    // permission prompts and CameraX activation on the Activity's Main thread.
    val cameraRunCoordinator = run { CameraRunCoordinator(phoneCam) }

    // Owns the IO-bound web/camera preparation stages before Console launch.
    private val consoleRunPreparationCoordinator = ConsoleRunPreparationCoordinator(
        scope = ideScope,
        projectWebResolver = projectWebResolver,
        cameraRunCoordinator = cameraRunCoordinator,
    )

    private val consoleDisplayLifecycle = ConsoleDisplayLifecycleCoordinator(
        scope = ideScope,
        runtimeUi = runtimeUiViewModel,
        displayRun = displayRunCoordinator,
        display = display,
        frameDisplay = frameDisplay,
        setConsoleTitle = { title -> console.title = title },
    )

    fun openCamSettings() {
        try {
            context.startActivity(
                Intent(
                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + context.packageName)
                ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
        }
    }

    // Natural Console process completion is handled by a focused lifecycle collaborator.
    private val consoleRunCompletion = ConsoleRunCompletionCoordinator(
        scope = ideScope,
        console = console,
        currentRun = { consoleRun },
        finishRun = { id -> runOrchestrator.finish(id) },
        camera = phoneCam,
        runtimeUi = runtimeUiViewModel,
        command = { consoleCmd },
        generation = { consoleRunId },
        isFrameMode = { frameMode },
    )

    init {
        consoleCtl.onDone = { consoleRunCompletion.onProcessDone() }
    }


    init {
    bridge.expand = {
        panelOpen = true
    }
    }

    init {
    bridge.goTerminal = {
        panelTab = PanelTab.Terminal
    }
    }

    init {
    bridge.onImeShown = {
        // Keyboard opened over any terminal surface: grow the panel so the
        // surface and the extra-keys bar stay usable instead of hiding.
        if (panelOpen) {
            panelFrac = panelFrac.coerceAtLeast(0.62f)
        }
    }
    }


    private val projectFeatureFactory = ProjectFeatureFactory(
        registry = projectFeatures,
        storeProvider = projectViewModelStores?.let { stores -> ProjectViewModelStoreProvider(stores::storeFor) },
        prefs = prefs,
        runtimeDispatchers = runtimeDispatchers,
        fileExplorerRepository = fileExplorerRepository,
        codeIntelligenceRepository = codeIntelligenceRepository,
        notebookRepository = notebookRepository,
    )

    fun editorFor(p: PyProject): EditorViewModel = projectFeatureFactory.editorFor(p)


    fun sessionFor(p: PyProject): EditorSession = editorFor(p).session


    /**
     * Writes the open project's state so a killed app resumes exactly here:
     * which project, which tabs, per-tab scroll/caret. [saveFiles] also
     * queues unsaved edits for background persistence when the app leaves
     * the screen, without blocking the lifecycle callback on disk I/O.
     */
    private val sessionPersistence = IdeSessionPersistence(
        prefs = prefs,
        serializeEditorSession = serializeEditorSession,
        runtimeTaskScope = runtimeTaskScope,
    )

    fun persistNow(saveFiles: Boolean, markForRestore: Boolean = false) {
        val project = (screen as? IdeScreen.Editor)?.project ?: return
        val editor = editors[project.dir.absolutePath] ?: return
        sessionPersistence.persist(project, editor, saveFiles, markForRestore)
    }


    /**
     * Brings the display up for a graphical run, IN PARALLEL with the program
     * (which has already been started and waits for the display by itself).
     * The viewer opens only once the display really answers, so it never
     * shows an empty "starting" screen while the console is blank.
     */
    fun startDisplay(title: String) = consoleDisplayLifecycle.startDisplay(title)

    fun startFrameDisplay(kind: String) = consoleDisplayLifecycle.startFrameDisplay(kind)


    fun runInConsole(
        project: PyProject,
        file: File,
        sourceText: String? = null,
        // "Run with display": a program the import scan cannot recognise
        // (dynamic imports, a library that draws windows internally) still
        // gets the display and the X environment.
        forceGui: Boolean = false,
        // True when the user already answered the "already running in the Terminal" question.
        ignoreConflict: Boolean = false,
        preparedWeb: ConsoleWebPreparation? = null,
        webPreparationComplete: Boolean = false,
        preparedSourceSnapshot: String? = null,
        cameraPreparationComplete: Boolean = false,
        preparedCameraPrefix: String = "",
    ) {
        // A fresh user Run supersedes any camera setup still being prepared.
        if (!webPreparationComplete) cameraPreparationRequest++
        val rel = try {
            project.dir.toURI().relativize(file.toURI()).path.ifEmpty { file.name }
        } catch (_: Exception) {
            file.name
        }
        // Keep one immutable source snapshot for all launch decisions. The
        // editor buffer is preferred; disk is only the fallback.
        val sourceSnapshot = if (webPreparationComplete) preparedSourceSnapshot.orEmpty()
        else sourceText ?: safeReadText(file)
        // Deterministic source classification and Console/Terminal identity are
        // one planning operation; this host only consumes the immutable result.
        val runPlan = consoleRunPlanningCoordinator.plan(
            fileName = file.name,
            sourceSnapshot = sourceSnapshot,
            forceGui = forceGui,
            projectGuestPath = guestProjectPath(project),
            relativeScriptPath = rel,
        )
        val sourceAnalysis = runPlan.sourceAnalysis
        val consoleKeys = runPlan.conflictKeys
        if (!ignoreConflict) {
            val other = runOrchestrator.findConflict(consoleKeys)
            if (other != null && other.source != "Console") {
                pendingConflict = PendingConflict(project, file, sourceText, forceGui, other)
                return
            }
        }
        val gui = sourceAnalysis.gui
        // A real PTY session (same engine as the interactive terminal):
        // output streams live, input() works, giant loops stay smooth.
        panelOpen = true
        panelTab = PanelTab.Console
        console.running = true
        // Detect a web project from the file Run is executing. This is an
        // in-memory check, so the run itself starts without waiting for disk.
        runtimeUiViewModel.setWebLiveUrl(null)
        val immediate = sourceAnalysis.webServer
        // When the file belongs to a web framework but would not start a
        // server on its own (plain `python file` would just exit), generate
        // the framework's server command instead — no manual terminal typing.
        // Files with an explicit in-code runner keep running exactly as is.
        val pythonBin = try {
            projectPythonBin(project.dir)
        } catch (_: Exception) {
            "python3"
        }
        if (!webPreparationComplete) {
            val requestId = ++webPreparationRequest
            // Disk-bound project discovery runs off Main; only the still-current
            // request is allowed to resume the ordered Console launch path.
            consoleRunPreparationCoordinator.prepareWeb(
                requestId = requestId,
                currentRequestId = { webPreparationRequest },
                project = project,
                file = file,
                sourceSnapshot = sourceSnapshot,
                originalSourceText = sourceText,
                immediate = immediate,
                pythonBin = pythonBin,
            ) { preparation ->
                runInConsole(
                    project = project,
                    file = file,
                    sourceText = sourceText,
                    forceGui = forceGui,
                    ignoreConflict = ignoreConflict,
                    preparedWeb = preparation,
                    webPreparationComplete = true,
                    preparedSourceSnapshot = sourceSnapshot,
                )
            }
            return
        }
        // The bridge shim/socket setup is IO-bound; permission UI remains on Main.
        if (sourceAnalysis.wantsCamera && !cameraPreparationComplete) {
            val requestId = ++cameraPreparationRequest
            consoleRunPreparationCoordinator.prepareCamera(
                requestId = requestId,
                currentRequestId = { cameraPreparationRequest },
                requestPermission = {
                    try {
                        camPermission.launch(android.Manifest.permission.CAMERA)
                    } catch (_: Exception) {
                    }
                },
            ) { cameraPrefix ->
                runInConsole(
                    project = project,
                    file = file,
                    sourceText = sourceText,
                    forceGui = forceGui,
                    ignoreConflict = ignoreConflict,
                    preparedWeb = preparedWeb,
                    webPreparationComplete = true,
                    preparedSourceSnapshot = sourceSnapshot,
                    cameraPreparationComplete = true,
                    preparedCameraPrefix = cameraPrefix,
                )
            }
            return
        }
        val auto = preparedWeb?.autoRun
        val effective = auto?.server ?: immediate
        runtimeUiViewModel.setWebServerGuess(effective)
        val entryRel = auto?.entryRel ?: rel
        // Graphical programs (any toolkit, see detectGuiFromSource) draw on
        // the embedded display. The prefix prepares THIS run: it waits for
        // the display, exports the common X environment and the toolkit's
        // own extras. Console-only files run exactly as before (no prefix).
        // "Run with display" (forceGui) always uses the real X11 display.
        val useFrame = sourceAnalysis.useFrame
        runtimeUiViewModel.setFrameMode(useFrame)
        runtimeUiViewModel.setFrameProject(project)
        val guiPrefix = if (gui != null) guiLaunchPrefix(gui, pythonBin, frame = useFrame) else ""
        // Phone-camera runs: the bridge URL/port go in the environment (see
        // CameraRunCommandFactory), the server starts, and the back camera opens
        // automatically. Without permission the run still starts, but the
        // helper raises an actionable error; the system dialog is requested
        // right here, at the moment the camera is first needed.
        val camPrefix = if (sourceAnalysis.wantsCamera) preparedCameraPrefix else ""
        console.title = if (auto != null) {
            "$entryRel — ${effective?.framework ?: "web"} server"
        } else if (gui != null) {
            "$rel — ${gui.framework}"
        } else {
            "$rel — python3"
        }
        // Prepare the immutable command first; commit matching Compose state;
        // then publish the run record through the single shared registry owner.
        val launchRequest = ConsoleRunLaunchRequest(
            projectGuestPath = guestProjectPath(project),
            title = console.title,
            conflictKeys = consoleKeys,
            guiPrefix = guiPrefix,
            cameraPrefix = camPrefix,
            programCommand = auto?.command ?: (pythonBin + " \"" + rel + "\""),
            bridgeUrl = ideBridge.url(),
            bridgeToken = ideBridge.token,
            usesDisplay = gui != null,
            previousRun = consoleRun,
        )
        val preparedLaunch = consoleRunLaunchCoordinator.prepare(launchRequest)
        consoleCmd = preparedLaunch.command
        consoleLive = true
        consoleRestartSeq++
        consoleRunId++
        val consoleGeneration = consoleRunId
        val launch = consoleRunLaunchCoordinator.publish(launchRequest, preparedLaunch)
        consoleRun = launch.runInfo
        if (gui != null) displayOwner = launch.runInfo.id
        if (gui != null) {
            if (useFrame) startFrameDisplay(gui.framework) else startDisplay("$rel — ${gui.framework}")
        }
        if (effective?.launchable != true) {
            val found = preparedWeb?.projectGuess ?: immediate
            if (consoleLive && consoleRunId == consoleGeneration) {
                runtimeUiViewModel.setWebServerGuess(found)
            }
        }
    }


    /**
     * Stop = end the program and let go of the display. The display SERVER
     * stays up (the next run starts instantly) unless [killDisplay], which is
     * only for leaving the project.
     */
    fun stopConsole(killDisplay: Boolean = false) {
        // Invalidate any project-web scan that has not reached the PTY yet:
        // Stop must never be followed by a late prepared launch.
        webPreparationRequest++
        cameraPreparationRequest++
        // Cancel a restart that has not fired yet: Stop means stop.
        consoleRestartSeq++
        runtimeUiViewModel.invalidateDisplayOperations()
        // A stopped run releases the camera (the bridge server stays up for
        // an instant restart from the Camera tab or the next run).
        try {
            phoneCam.stopRun("Stopped — camera released.")
        } catch (_: Exception) {
        }
        try {
            consoleCtl.stop?.invoke()
        } catch (_: Exception) {
        }
        console.running = false
        consoleRun?.let { runOrchestrator.finish(it.id) }
        runtimeUiViewModel.setWebLiveUrl(null)
        frameDisplay.stop()
        display.resetViewer()
        if (killDisplay && display.status != "Stopped") {
            ideScope.launch(Dispatchers.IO) {
                try {
                    display.stopServer()
                } catch (_: Exception) {
                }
            }
        }
    }


    private val projectLifecycleCleanup = ProjectLifecycleCleanup(
        features = projectFeatures,
        notebookRepository = notebookRepository,
        stores = projectViewModelStores,
        prefs = prefs,
    )

    fun clearDeletedProjectStateForDir(projectDir: File): Unit =
        projectLifecycleCleanup.clearDeletedProject(projectDir)


    fun clearDeletedProjectState(project: PyProject): Unit {
        clearDeletedProjectStateForDir(project.dir)
    }


    /**
     * Leaves the project for good: everything that belongs to it stops and
     * leaves no trace — the running program / server, the display, the
     * console contents, the viewer and the panel. Open tabs and their scroll
     * positions are saved first, and the "resume this project after a
     * restart" marker is cleared (a deliberate exit is not a crash).
     */
    private val projectExitCoordinator = ProjectExitCoordinator(
        sessionPersistence = sessionPersistence,
        prefs = prefs,
        currentProject = { (screen as? IdeScreen.Editor)?.project },
        persistCurrentSession = { persistNow(true, markForRestore = false) },
        debugControllerForPath = { path -> debugControllers[path] },
        stopConsole = { killDisplay -> stopConsole(killDisplay) },
        phoneCamera = phoneCam,
        console = console,
        runtimeUiViewModel = runtimeUiViewModel,
        runSessionState = runSessionState,
        panelState = panelState,
        navigationState = navigationState,
    )

    fun leaveProject(persistSession: Boolean = true) =
        projectExitCoordinator.leaveProject(persistSession)



    fun rerunConsole() {
        if (consoleCmd == null) return
        val cmd = consoleCmd!!
        // The command already carries its own display wait + environment;
        // the display itself is (re)started in parallel with the program.
        if ("IDE_VIEW_DIR=" in cmd) {
            startFrameDisplay(if ("ide_mpl_backend" in cmd) "matplotlib" else "opencv")
        } else if ("DISPLAY=:1" in cmd) {
            runtimeUiViewModel.setFrameMode(false)
            startDisplay(console.title.ifBlank { "program" })
        }
        panelOpen = true
        panelTab = PanelTab.Console
        // A live server still holds its port: stop it first and restart only
        // after it is dead. Restarting on top of it reuses the old session's
        // dispose and the new run dies with "address already in use" while
        // the old server keeps serving — exactly the reported bug.
        val wasLive = try {
            consoleCtl.isAlive?.invoke()
        } catch (_: Exception) {
            false
        } ?: false
        if (wasLive) {
            try {
                consoleCtl.stop?.invoke()
            } catch (_: Exception) {
            }
        }
        console.running = true
        runtimeUiViewModel.setWebLiveUrl(null)
        consoleLive = true
        if (!wasLive) {
            consoleRestartSeq++
            consoleRunId++
            return
        }
        val token = consoleRestartSeq + 1
        consoleRestartSeq = token
        ideScope.launch(Dispatchers.Main) {
            // SIGKILL death + socket release is effectively immediate; this
            // just makes sure the kernel has reaped the group first.
            kotlinx.coroutines.delay(800)
            if (consoleLive && consoleRestartSeq == token && consoleCmd != null) {
                consoleRunId++
            }
        }
    }


    // ---- Terminal runs: what the guest helper (ide_run.py) asks of the IDE -------------------------
    // prepare() and start() are separate HTTP callbacks. Plans are one-shot,
    // expire if the guest abandons a launch, and are bounded under repeated retries.
    val termPlans = run { ExpiringPlanStore<TermPlan>() }


    private val terminalRunLifecycle = TerminalRunLifecycleCoordinator(
        runOrchestrator = runOrchestrator,
        runTaskScope = runTaskScope,
        isConsoleLive = { consoleLive },
        isConsoleRunning = { console.running },
        stopConsole = { stopConsole() },
        displayOwner = { displayOwner },
        clearDisplayOwner = { displayOwner = null },
        frameMode = { frameMode },
        ideScope = ideScope,
        runtimeUiViewModel = runtimeUiViewModel,
        phoneCamera = phoneCam,
    )

    fun killRunGroup(info: RunInfo) = terminalRunLifecycle.killRunGroup(info)

    fun stopRun(info: RunInfo) = terminalRunLifecycle.stopRun(info)

    fun stopAllRuns() = terminalRunLifecycle.stopAllRuns()

    fun endTerminalRun(id: String) = terminalRunLifecycle.endTerminalRun(id)



    private val ideBridgeCoordinator = IdeBridgeCoordinator(
        bridge = ideBridge,
        context = context,
        hostActive = bridgeHostActive,
        cameraRunCoordinator = cameraRunCoordinator,
        requestCameraPermission = {
            try {
                camPermission.launch(android.Manifest.permission.CAMERA)
            } catch (_: Exception) {
            }
        },
        editors = { editors.values },
        projectWebResolver = projectWebResolver,
        runOrchestrator = runOrchestrator,
        termPlans = termPlans,
        runtimeUiViewModel = runtimeUiViewModel,
        ideScope = ideScope,
        hub = hub,
        startFrameDisplay = ::startFrameDisplay,
        startDisplay = ::startDisplay,
        setDisplayOwner = { displayOwner = it },
        endTerminalRun = ::endTerminalRun,
        stopRun = ::stopRun,
    ).also { it.install() }



    // ---- Web preview: built-in browser or the phone's browser (the user's choice) -----------------
    val browser = run { BrowserState() }


    /**
     * Builds the current project's venv with the interpreter selected when
     * that project was created. Older projects transparently resolve to the
     * bundled Python runtime. Falls back to --without-pip only when needed.
     */
    fun buildProjVenv() {
        val p = (screen as? IdeScreen.Editor)?.project ?: return
        venvBusyBuild = true
        venvBuildMsg = null
        ideScope.launch(Dispatchers.IO) {
            val v = projectVenvName(p.dir)
            val interpreter = projectPythonInterpreterGuestPath(p.dir)
            // Ensure the project's selected base runtime exists before rebuilding
            // its environment (normally this is already a no-op after creation).
            val out = try {
                PythonRuntimeInstaller(ubuntu, proot).ensureInstalled(projectPythonVersionId(p.dir))
                proot.runOnce(
                    "cd " + guestProjectPath(p) + " && test -x \"$interpreter\" || exit 21; rm -rf \"$v\" && " +
                    "\"$interpreter\" -m venv \"$v\" 2>&1; " +
                    "test -x \"$v/bin/python\" || \"$interpreter\" -m venv --without-pip \"$v\" 2>&1; " +
                    "test -x \"$v/bin/python\" && \"$v/bin/python\" --version && echo VENV-READY",
                    timeoutSec = 300L
                )
            } catch (t: Throwable) {
                "ERROR: ${t.message}"
            }
            withContext(Dispatchers.Main) {
                venvBusyBuild = false
                if (out.lines().any { it.trim() == "VENV-READY" }) {
                    venvBuildMsg = null
                    // The live shell gets exactly one visible line, which the
                    // user just asked for by tapping Build.
                    val activation = "source " + guestProjectPath(p) + "/$v/bin/activate\r"
                    val delivered = try { bridge.send?.invoke(activation) == true } catch (_: Exception) { false }
                    if (!delivered) bridge.pending = activation + (bridge.pending ?: "")
                } else {
                    venvBuildMsg = "build failed: " +
                    out.lines().filter { it.isNotBlank() }.takeLast(3)
                    .joinToString(" / ").take(240)
                }
            }
        }
    }

    fun openExternalUrl(url: String) {
        val uri = try {
            Uri.parse(url)
        } catch (_: Exception) {
            null
        }
        if (uri == null) return
        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
            try {
                Toast.makeText(context, "No browser found", Toast.LENGTH_LONG).show()
            } catch (_: Exception) {
            }
        }
    }


    fun openInIde(url: String) {
        browser.url = url
        browser.webView?.loadUrl(url)
        runtimeUiViewModel.setBrowserOpen(true)
    }


    /** The Browser buttons (Console, Terminal strip, ...) all end up here. */
    fun openServerUrl(url: String) {
        when (prefs.webOpenMode) {
            "ide" -> openInIde(url)
            "phone" -> openExternalUrl(url)
            else -> {
                runtimeUiViewModel.setRememberBrowserChoice(false)
                runtimeUiViewModel.requestBrowserChoice(url)
            }
        }
    }
}

internal class PendingConflict(
    val project: PyProject,
    val file: File,
    val text: String?,
    val forceGui: Boolean,
    val other: RunInfo
)

/** What the IDE decided for a Terminal run when it was prepared (used when the run really starts). */
internal class TermPlan(
    val gui: GuiApp?,
    val useFrame: Boolean,
    val title: String,
    val keys: Set<String>,
    val project: PyProject?
)

/** Does something on this loopback port answer HTTP? (Raw socket: no cleartext-traffic policy involved.) */
internal fun probeHttp(port: Int): Boolean {
    for (attempt in 0 until 6) {
        try {
            java.net.Socket().use { s ->
                s.connect(java.net.InetSocketAddress("127.0.0.1", port), 800)
                s.soTimeout = 1500
                s.getOutputStream().write("GET / HTTP/1.0\r\nHost: 127.0.0.1\r\n\r\n".toByteArray())
                val buf = ByteArray(5)
                val n = s.getInputStream().read(buf)
                if (n >= 5 && String(buf, 0, 5) == "HTTP/") return true
                if (n > 0) return false
            }
        } catch (_: Exception) {
        }
        try {
            Thread.sleep(500)
        } catch (_: InterruptedException) {
            return false
        }
    }
    return false
}

internal data class PendingImportSelection(
    val filePath: String,
    val sourceSnapshot: String,
    val symbol: String,
    val candidates: List<com.codespace.ide.ide.codeintel.PythonCompletionItem>,
)
