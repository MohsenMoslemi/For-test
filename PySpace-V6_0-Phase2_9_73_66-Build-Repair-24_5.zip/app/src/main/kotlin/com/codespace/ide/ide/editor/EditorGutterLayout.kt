package com.codespace.ide.ide.editor

import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Canonical geometry for the editor's gutter lanes.
 *
 * This policy is shared by the committed layout, pinch preview, popup anchors
 * and the code-lane origin. Keeping the calculation in one owner prevents the
 * line-number, marker and fold lanes from drifting apart during zoom hand-off.
 */
internal data class EditorGutterLayout(
    val foldSlotDp: Dp,
    val widthDp: Dp,
    val widthPx: Float,
    val effectiveWidthPx: Float,
    val effectiveWidthDp: Dp,
    val textPaddingPx: Float,
    val widthPxForFont: (Float) -> Float
) {
    companion object {
        fun calculate(
            fontSize: Float,
            density: Density,
            showLineNumbers: Boolean,
            gutterVisible: Boolean,
            lastVisibleSourceLine: Int,
            layerScaleX: Float,
            layerScaleY: Float,
            zoomAnchorPending: Boolean,
            pinchGutterWidthPx: Float
        ): EditorGutterLayout {
            val foldSlot = maxOf(28f, fontSize * 1.05f * density.fontScale).dp
            val widthForFont: (Float) -> Dp = { size ->
                editorGutterWidthDp(
                    fontSize = size,
                    fontScale = density.fontScale,
                    showLineNumbers = showLineNumbers,
                    gutterVisible = gutterVisible,
                    lastVisibleSourceLine = lastVisibleSourceLine
                )
            }
            val width = widthForFont(fontSize)
            val widthPx = with(density) { width.toPx() }
            val previewActive = (layerScaleY != 1f && layerScaleY > 0f) ||
                (layerScaleX != 1f && layerScaleX > 0f) || zoomAnchorPending
            val effectivePx = if (previewActive) pinchGutterWidthPx else widthPx
            val effectiveDp = with(density) { effectivePx.coerceAtLeast(0f).toDp() }
            val textPadding = with(density) { 8.dp.toPx() }
            val widthPxForFont: (Float) -> Float = { size ->
                with(density) { widthForFont(size).toPx() }
            }
            return EditorGutterLayout(
                foldSlotDp = foldSlot,
                widthDp = width,
                widthPx = widthPx,
                effectiveWidthPx = effectivePx,
                effectiveWidthDp = effectiveDp,
                textPaddingPx = textPadding,
                widthPxForFont = widthPxForFont
            )
        }
    }
}
