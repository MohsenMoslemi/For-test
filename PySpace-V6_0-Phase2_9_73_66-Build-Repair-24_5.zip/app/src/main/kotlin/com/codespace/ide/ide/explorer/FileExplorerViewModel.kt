package com.codespace.ide.ide.explorer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import java.io.File
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Immutable drawer state; no filesystem work is performed by Compose. */
data class FileExplorerUiState(
    val nodes: List<ExplorerTreeNode> = emptyList(),
    val fileCount: Int = 0,
    val fileCountCapped: Boolean = false,
    val isLoading: Boolean = false,
    val isOperating: Boolean = false,
    val error: String? = null,
)

class FileExplorerViewModel(
    private val repository: FileExplorerRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(FileExplorerUiState())
    val state: StateFlow<FileExplorerUiState> = _state.asStateFlow()
    private var refreshJob: Job? = null
    private var requestVersion = 0L
    private var countedContentVersion = Long.MIN_VALUE
    private val operationMutex = Mutex()

    fun refresh(
        root: File,
        expanded: Map<String, Boolean>,
        sortByType: Boolean,
        showHidden: Boolean,
        collapseChains: Boolean,
        contentVersion: Long,
    ) {
        val version = ++requestVersion
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            try {
                val shouldCount = contentVersion != countedContentVersion
                val snapshot = repository.loadSnapshot(
                    root, expanded, sortByType, showHidden, collapseChains, shouldCount
                )
                if (version == requestVersion) {
                    if (snapshot.fileCount != null) countedContentVersion = contentVersion
                    _state.value = FileExplorerUiState(
                        nodes = snapshot.nodes,
                        fileCount = snapshot.fileCount ?: _state.value.fileCount,
                        fileCountCapped = if (snapshot.fileCount != null) snapshot.fileCountCapped else _state.value.fileCountCapped,
                        isOperating = _state.value.isOperating,
                    )
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                if (version == requestVersion) {
                    _state.value = _state.value.copy(isLoading = false, error = error.message ?: "Unable to read project files")
                }
            }
        }
    }

    suspend fun findFirstMatch(root: File, query: String, showHidden: Boolean): File? =
        repository.findFirstMatch(root, query, showHidden)

    suspend fun listAllDirectories(root: File, showHidden: Boolean): List<String> =
        repository.listAllDirectories(root, showHidden)

    suspend fun listDestinationChildren(directory: File, root: File): List<ExplorerFileEntry> =
        repository.listDestinationChildren(directory, root)

    /** Long-running mutations are owned by this ViewModel, not by a drawer composition. */
    fun createEntryAsync(root: File, directory: File, name: String, isDirectory: Boolean, onComplete: (Result<File>) -> Unit) {
        viewModelScope.launch { onComplete(operate { repository.createEntry(root, directory, name, isDirectory) }) }
    }

    fun renameEntryAsync(root: File, source: File, newName: String, onComplete: (Result<File>) -> Unit) {
        viewModelScope.launch { onComplete(operate { repository.renameEntry(root, source, newName) }) }
    }

    fun deleteEntryAsync(root: File, target: File, onComplete: (Result<Unit>) -> Unit) {
        viewModelScope.launch { onComplete(operate { repository.deleteEntry(root, target) }) }
    }

    fun copyEntryAsync(root: File, source: File, destination: File, onComplete: (Result<File>) -> Unit) {
        viewModelScope.launch { onComplete(operate { repository.copyEntry(root, source, destination) }) }
    }

    fun moveEntryAsync(root: File, source: File, destination: File, onComplete: (Result<File>) -> Unit) {
        viewModelScope.launch { onComplete(operate { repository.moveEntry(root, source, destination) }) }
    }

    private suspend fun <T> operate(block: suspend () -> T): Result<T> = operationMutex.withLock {
        _state.value = _state.value.copy(isOperating = true, error = null)
        try {
            Result.success(block())
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            val message = error.message ?: "File operation failed"
            _state.value = _state.value.copy(error = message)
            Result.failure(error)
        } finally {
            _state.value = _state.value.copy(isOperating = false)
        }
    }

    class Factory(
        private val repository: FileExplorerRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (!modelClass.isAssignableFrom(FileExplorerViewModel::class.java)) {
                throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
            }
            return FileExplorerViewModel(repository) as T
        }
    }
}
