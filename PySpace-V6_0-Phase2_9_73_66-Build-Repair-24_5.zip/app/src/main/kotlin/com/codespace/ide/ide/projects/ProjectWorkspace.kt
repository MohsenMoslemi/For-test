package com.codespace.ide.ide.projects

import android.content.Context
import android.system.Os
import android.system.OsConstants
import android.util.Log
import java.io.File
import com.codespace.ide.ide.PythonRuntimeCatalog

/** One Python project = one directory inside the workspace. */
data class PyProject(val name: String, val dir: File)


/**
 * Guest-visible workspace directory name. THE single source of truth — to
 * rename it one day, change this const (plus [LEGACY_WORKSPACE_DIR_NAME]
 * handling in [workspaceRoot]): every shell command derives from it. The
 * workspace lives at `/files/<name>` (guest) = `<rootfs>/files/<name>`
 * (host).
 */
const val WORKSPACE_DIR_NAME = "projects"

/** Previous workspace name, migrated automatically (never shown to users). */
const val LEGACY_WORKSPACE_DIR_NAME = "pyspace"

/** Guest-visible workspace (`/files/projects`). */
fun guestWorkspace(): String = "/files/$WORKSPACE_DIR_NAME"

/** Guest-absolute workspace (`/files/projects`). */
fun guestWorkspaceRoot(): String = "/files/$WORKSPACE_DIR_NAME"

/** Guest-visible project dir (`/files/projects/<name>`), whatever the host used. */
fun guestProjectPath(project: PyProject): String {
    val ws = project.dir.parentFile?.name?.takeIf { it.isNotBlank() } ?: WORKSPACE_DIR_NAME
    return "/files/$ws/${project.dir.name}"
}

/** Guest-absolute project dir (`/files/projects/<name>`). */
fun guestProjectRoot(project: PyProject): String {
    val ws = project.dir.parentFile?.name?.takeIf { it.isNotBlank() } ?: WORKSPACE_DIR_NAME
    return "/files/$ws/${project.dir.name}"
}

/**
 * Workspace root on Android's private app storage. Projects are no longer
 * stored inside the Ubuntu rootfs: PRoot bind-mounts this directory at
 * `/files/projects`, so Python and Linux tools keep the same guest-visible
 * paths while an Ubuntu reinstall/repair cannot erase project data.
 *
 * Older releases stored projects at rootfs/files/projects (or the older
 * root/projects and root/pyspace locations). Import them non-destructively:
 * copy only missing files into app-private storage and leave the originals
 * untouched as a recovery copy. This is idempotent and safe to retry after
 * an interrupted migration.
 */
fun workspaceRoot(context: Context): File {
    val rootfs = File(context.filesDir, "ubuntu-rootfs")
    val privateWorkspace = File(context.filesDir, WORKSPACE_DIR_NAME)
    val migrationMarker = File(privateWorkspace, ".pyspace-private-workspace-v1")
    val legacySources = listOf(
        File(rootfs, "files/$WORKSPACE_DIR_NAME"),
        File(rootfs, "root/$WORKSPACE_DIR_NAME"),
        File(rootfs, "root/$LEGACY_WORKSPACE_DIR_NAME")
    )

    if (!privateWorkspace.exists() && !privateWorkspace.mkdirs()) {
        throw IllegalStateException("Cannot create private workspace: ${privateWorkspace.absolutePath}")
    }
    if (!privateWorkspace.isDirectory) {
        throw IllegalStateException("Private workspace path is not a directory: ${privateWorkspace.absolutePath}")
    }

    if (!migrationMarker.isFile) {
        try {
            for (source in legacySources) {
                // A missing legacy location is normal for a fresh installation.
                if (!source.exists()) continue
                if (!source.isDirectory) {
                    throw java.io.IOException("Legacy workspace is not a directory: ${source.absolutePath}")
                }
                if (source.canonicalFile != privateWorkspace.canonicalFile) {
                    copyMissingWorkspaceEntries(source, privateWorkspace)
                }
            }

            // Write marker atomically and only after every source was imported.
            val markerTemp = File(privateWorkspace, ".pyspace-migration-marker.tmp")
            if (markerTemp.exists() && !markerTemp.delete()) {
                throw java.io.IOException("Cannot clear migration marker temporary file: ${markerTemp.absolutePath}")
            }
            markerTemp.writeText("1\n")
            if (!markerTemp.renameTo(migrationMarker)) {
                markerTemp.delete()
                throw java.io.IOException("Cannot finalize migration marker: ${migrationMarker.absolutePath}")
            }
        } catch (error: Exception) {
            Log.e("PySpaceMigration", "Workspace migration failed", error)
            val diagnosticFile = File(context.filesDir, "pyspace-migration-error.log")
            try {
                val trace = java.io.StringWriter().also { writer ->
                    error.printStackTrace(java.io.PrintWriter(writer))
                }.toString()
                diagnosticFile.writeText(
                    "PySpace workspace migration failure\n" +
                        "Private workspace: ${privateWorkspace.absolutePath}\n" +
                        "Legacy sources:\n" + legacySources.joinToString("\n") { it.absolutePath } +
                        "\n\n$trace"
                )
            } catch (logError: Exception) {
                Log.e("PySpaceMigration", "Could not write migration diagnostic file", logError)
            }
            val detail = buildString {
                append(error.javaClass.simpleName)
                val message = error.message?.takeIf { it.isNotBlank() }
                if (message != null) append(": ").append(message)
            }
            throw IllegalStateException(
                "Project migration failed. $detail\nOriginal files are preserved. Diagnostic log: ${diagnosticFile.absolutePath}",
                error
            )
        }
    }
    return privateWorkspace
}

/**
 * Imports an entry without overwriting an existing private-workspace entry.
 * Uses lstat/readlink so Python venv symlinks remain symlinks rather than
 * accidentally copying their Ubuntu targets into the project directory.
 */
private fun copyMissingWorkspaceEntries(source: File, destination: File) {
    val sourceStat = try {
        Os.lstat(source.absolutePath)
    } catch (error: Exception) {
        throw java.io.IOException("Cannot inspect source entry ${source.absolutePath}: ${error.message}", error)
    }
    val sourceType = sourceStat.st_mode and OsConstants.S_IFMT

    when (sourceType) {
        OsConstants.S_IFLNK -> {
            if (destination.exists() || isSymbolicLink(destination)) return
            destination.parentFile?.let { parent ->
                if (!parent.exists() && !parent.mkdirs()) {
                    throw java.io.IOException("Cannot create destination folder ${parent.absolutePath}")
                }
            }
            val linkTarget = try {
                Os.readlink(source.absolutePath)
            } catch (error: Exception) {
                throw java.io.IOException("Cannot read symbolic link ${source.absolutePath}: ${error.message}", error)
            }
            try {
                Os.symlink(linkTarget, destination.absolutePath)
            } catch (error: Exception) {
                throw java.io.IOException("Cannot recreate symbolic link ${destination.absolutePath}: ${error.message}", error)
            }
        }
        OsConstants.S_IFDIR -> {
            if (destination.exists() && !destination.isDirectory) {
                throw java.io.IOException("Directory/file conflict: source ${source.absolutePath}, destination ${destination.absolutePath}")
            }
            if (!destination.exists() && !destination.mkdirs()) {
                throw java.io.IOException("Cannot create destination directory ${destination.absolutePath}")
            }
            val children = source.listFiles()
                ?: throw java.io.IOException("Cannot list source directory ${source.absolutePath}; check storage access")
            for (child in children) {
                copyMissingWorkspaceEntries(child, File(destination, child.name))
            }
        }
        OsConstants.S_IFREG -> {
            if (destination.exists()) {
                if (destination.isDirectory) {
                    throw java.io.IOException("File/directory conflict: source ${source.absolutePath}, destination ${destination.absolutePath}")
                }
                return // Keep the already-imported private copy.
            }
            destination.parentFile?.let { parent ->
                if (!parent.exists() && !parent.mkdirs()) {
                    throw java.io.IOException("Cannot create destination folder ${parent.absolutePath}")
                }
            }
            val temporary = File(destination.parentFile, ".${destination.name}.pyspace-migrate.tmp")
            if (temporary.exists() && !temporary.delete()) {
                throw java.io.IOException("Cannot clear temporary file ${temporary.absolutePath}")
            }
            try {
                source.copyTo(temporary, overwrite = false)
                if (!temporary.renameTo(destination)) {
                    throw java.io.IOException("Cannot finalize copied file ${destination.absolutePath}")
                }
                destination.setLastModified(source.lastModified())
            } finally {
                if (temporary.exists()) temporary.delete()
            }
        }
        else -> throw java.io.IOException(
            "Unsupported special file (mode=$sourceType): ${source.absolutePath}"
        )
    }
}

internal fun isSymbolicLink(file: File): Boolean {
    return try {
        (Os.lstat(file.absolutePath).st_mode and OsConstants.S_IFMT) == OsConstants.S_IFLNK
    } catch (_: Exception) {
        false
    }
}

/** Direct child directories = projects. */
fun listProjects(root: File): List<PyProject> {
    return try {
        (root.listFiles() ?: emptyArray())
        .filter { it.isDirectory && !it.name.startsWith(".") }
        .sortedBy { it.name.lowercase() }
        .map { PyProject(it.name, it) }
    } catch (_: Exception) {
        emptyList()
    }
}

fun sanitizeName(raw: String): String {
    return raw.trim().replace(Regex("[^A-Za-z0-9_.-]"), "_").trim('_', '.', '-')
}

/** Sensible Python defaults for new PySpace projects; users can edit this file freely. */
fun defaultPythonGitIgnore(): String = """# Python bytecode and caches
__pycache__/
*.py[cod]
*${'$'}py.class

# Virtual environments
.venv/
venv/
env/
ENV/

# Build and packaging output
build/
dist/
*.egg-info/
.eggs/

# Test, type-checker and formatter caches
.pyspace-test-reports/
.pytest_cache/
.mypy_cache/
.ruff_cache/
.tox/
.nox/
.coverage
.coverage.*
htmlcov/

# Jupyter
.ipynb_checkpoints/

# PySpace local interpreter metadata
.pyspace_venv
.pyspace_python_version
.pyspace_python_path

# Local secrets and credentials
.env
.env.*
!.env.example
*.pem
*.p12
*.pfx
*.keystore
*.jks

# IDE and operating-system files
.idea/
.vscode/
.DS_Store
Thumbs.db
"""

fun createProject(root: File, rawName: String, rawVenv: String = ".venv", pythonVersionId: String = PythonRuntimeCatalog.DEFAULT_ID): PyProject? {
    val name = sanitizeName(rawName)
    if (name.isEmpty()) return null
    val venv = sanitizeName(rawVenv).ifEmpty { ".venv" }
    return try {
        val runtime = PythonRuntimeCatalog.require(pythonVersionId)
        val dir = File(root, name)
        if (dir.exists()) return null
        dir.mkdirs()
        File(dir, "main.py").writeText(mainTemplate(name))
        File(dir, venv).mkdirs()
        File(dir, ".gitignore").writeText(defaultPythonGitIgnore())
        File(dir, ".pyspace_venv").writeText(venv)
        File(dir, ".pyspace_python_version").writeText(runtime.id)
        File(dir, ".pyspace_python_path").writeText(runtime.guestExecutable)
        PyProject(name, dir)
    } catch (_: Exception) {
        null
    }
}
