package com.codespace.ide.ide.editor

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import com.codespace.ide.ide.codeintel.PythonLspController
import com.codespace.ide.ide.codeintel.PythonReferenceOccurrence
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Owns project-wide symbol-refactor selection analysis, preview and execution.
 * Document state remains owned by PyEditor and is updated through onFieldChange.
 */
@Composable
internal fun EditorRenameWorkflow(
    tab: OpenTab,
    session: EditorSession,
    field: TextFieldValue,
    onFieldChange: (TextFieldValue) -> Unit,
    isPythonLanguage: Boolean,
    pythonLspController: PythonLspController?,
    selectionToolbar: EditorSelectionToolbarState,
    scope: CoroutineScope
) {
    var renameDialogVisible by remember(tab.file.absolutePath) { mutableStateOf(false) }
    var renameValue by remember(tab.file.absolutePath) { mutableStateOf("") }
    var renameOriginal by remember(tab.file.absolutePath) { mutableStateOf("") }
    var renameOffset by remember(tab.file.absolutePath) { mutableStateOf(-1) }
    var renameBusy by remember(tab.file.absolutePath) { mutableStateOf(false) }
    var renameProgress by remember(tab.file.absolutePath) { mutableFloatStateOf(0f) }
    var renameProgressStage by remember(tab.file.absolutePath) { mutableStateOf("Ready") }
    var renameCanCancel by remember(tab.file.absolutePath) { mutableStateOf(false) }
    var renameTask by remember(tab.file.absolutePath) { mutableStateOf<Job?>(null) }
    var renameOccurrences by remember(tab.file.absolutePath) { mutableStateOf<List<PythonReferenceOccurrence>>(emptyList()) }
    var renamePreviewMessage by remember(tab.file.absolutePath) { mutableStateOf("Loading project references…") }
    var renameResultMessage by remember(tab.file.absolutePath) { mutableStateOf("") }
    val pythonKeywords = remember {
        setOf("False", "None", "True", "and", "as", "assert", "async", "await", "break", "class", "continue", "def", "del", "elif", "else", "except", "finally", "for", "from", "global", "if", "import", "in", "is", "lambda", "nonlocal", "not", "or", "pass", "raise", "return", "try", "while", "with", "yield")
    }
    LaunchedEffect(field.text, field.selection, tab.file.absolutePath, pythonLspController) {
        selectionToolbar.refactorAction = null
        selectionToolbar.refactorLabel = "Refactor symbol"
        val start = minOf(field.selection.start, field.selection.end)
        val end = maxOf(field.selection.start, field.selection.end)
        if (!isPythonLanguage || start >= end || end > field.text.length) return@LaunchedEffect
        val selected = field.text.substring(start, end)
        if (!Regex("[A-Za-z_][A-Za-z0-9_]*").matches(selected) || selected in pythonKeywords) return@LaunchedEffect
        val controller = pythonLspController ?: return@LaunchedEffect
        val definition = controller.definitionLocation(tab.file, field.text, start) ?: return@LaunchedEffect
        if (!definition.file.extension.equals("py", true)) return@LaunchedEffect
        renameOriginal = selected
        renameValue = selected
        renameOffset = start
        val definitionLine = try { definition.file.readLines().getOrNull(definition.line - 1).orEmpty().trim() } catch (_: Exception) { "" }
        selectionToolbar.refactorLabel = when {
            Regex("^(?:async\\s+)?class\\s+${Regex.escape(selected)}\\b").containsMatchIn(definitionLine) -> "Refactor class"
            Regex("^(?:async\\s+)?def\\s+${Regex.escape(selected)}\\s*\\(").containsMatchIn(definitionLine) -> "Refactor function"
            Regex("^${Regex.escape(selected)}\\s*=").containsMatchIn(definitionLine) -> "Refactor variable"
            Regex("^${Regex.escape(selected)}\\s*:").containsMatchIn(definitionLine) -> "Refactor variable"
            else -> "Refactor symbol"
        }
        selectionToolbar.refactorAction = {
            renameOccurrences = emptyList()
            renamePreviewMessage = "Loading project references…"
            renameResultMessage = ""
            renameDialogVisible = true
        }
    }
    LaunchedEffect(renameDialogVisible, renameOffset, field.text, pythonLspController) {
        if (!renameDialogVisible || renameOffset < 0) return@LaunchedEffect
        val controller = pythonLspController ?: run {
            renamePreviewMessage = "Python language server is unavailable."
            return@LaunchedEffect
        }
        renamePreviewMessage = "Loading project references…"
        val docs = session.tabs.associate { it.file to it.text }
        val found = controller.workspaceReferences(tab.file, field.text, renameOffset, docs)
        renameOccurrences = found.orEmpty()
        renamePreviewMessage = when {
            found == null -> "Could not retrieve references from the Python language server."
            found.isEmpty() -> "No project references were reported."
            else -> "Reference scan complete. Review the breakdown below before renaming."
        }
    }
    if (renameDialogVisible) {
        EditorRenameDialog(
            title = selectionToolbar.refactorLabel,
            value = renameValue,
            onValueChange = { renameValue = it },
            originalName = renameOriginal,
            projectRoot = pythonLspController?.projectRoot,
            occurrences = renameOccurrences,
            previewMessage = renamePreviewMessage,
            resultMessage = renameResultMessage,
            busy = renameBusy,
            progress = renameProgress,
            progressStage = renameProgressStage,
            canCancel = renameCanCancel,
            canConfirm = Regex("[A-Za-z_][A-Za-z0-9_]*").matches(renameValue) &&
                renameValue !in pythonKeywords && renameValue != renameOriginal,
            onDismiss = { if (!renameBusy) renameDialogVisible = false },
            onConfirm = {
                val controller = pythonLspController ?: return@EditorRenameDialog
                renameBusy = true
                renameProgress = 0f
                renameProgressStage = "Starting…"
                renameCanCancel = true
                renameTask = scope.launch {
                    try {
                        val openDocuments = session.tabs.associate { it.file to it.text }
                        val changed = controller.renameAndApply(
                            tab.file, field.text, renameOffset, renameValue, openDocuments
                        ) { stage, percent, canCancel ->
                            renameProgressStage = stage
                            renameProgress = percent / 100f
                            renameCanCancel = canCancel
                        }
                        if (!changed.isNullOrEmpty()) {
                            val normalized = changed.entries.associate { it.key.canonicalFile to it.value }
                            session.tabs.toList().forEach { openTab ->
                                val updated = normalized[openTab.file.canonicalFile] ?: return@forEach
                                val previousLength = openTab.text.length
                                val rawStart = if (openTab === tab) field.selection.start else openTab.selStart
                                val rawEnd = if (openTab === tab) field.selection.end else openTab.selEnd
                                val safeStart = rawStart.coerceIn(0, previousLength)
                                val safeEnd = rawEnd.coerceIn(0, previousLength)
                                openTab.applyEdit(updated, minOf(safeStart, safeEnd), maxOf(safeStart, safeEnd))
                                openTab.markSaved(updated)
                                if (openTab === tab) {
                                    val expected = (renameOffset + renameOriginal.length).coerceIn(0, field.text.length)
                                    val mappedCaret = findNearestRenamedToken(updated, renameValue, expected)
                                    onFieldChange(TextFieldValue(updated, TextRange(mappedCaret)))
                                }
                            }
                            selectionToolbar.hide()
                            renameDialogVisible = false
                            session.refreshTree(contentChanged = false)
                            renameResultMessage = "Refactor completed across ${changed.size} file(s)."
                        } else {
                            val detail = controller.lastRenameFailureReason.takeIf { it.isNotBlank() }
                            renameResultMessage = buildString {
                                append("Refactor could not be applied. No files were changed.")
                                if (detail != null) append("\n").append(detail)
                            }
                        }
                    } catch (_: kotlinx.coroutines.CancellationException) {
                        renameResultMessage = "Refactor cancelled. No project files were changed."
                    } finally {
                        renameBusy = false
                        renameCanCancel = false
                        renameTask = null
                    }
                }
            },
            onCancel = {
                if (renameBusy) {
                    renameCanCancel = false
                    renameProgressStage = "Cancelling safely…"
                    renameTask?.cancel()
                } else renameDialogVisible = false
            }
        )
    }
}
