package com.codespace.ide.ide

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.LifecycleOwner
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ProotManager
import com.codespace.ide.di.AppDependencies
import com.codespace.ide.TerminalScreen
import com.codespace.ide.UbuntuManager
import com.codespace.ide.runtime.RuntimeTaskScope
import com.codespace.ide.runtime.RuntimeDispatchers
import java.io.File
import org.json.JSONObject
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.CoroutineScope
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.platform.LocalDensity
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.roundToInt
import java.util.concurrent.atomic.AtomicBoolean
import com.codespace.ide.ide.editor.IdeEditor
import com.codespace.ide.MainActivity
import com.codespace.ide.ide.projects.ProjectAutoRecoveryManager
import com.codespace.ide.ide.projects.ProjectsViewModel
import com.codespace.ide.ide.shell.IdeShell
import com.codespace.ide.ide.theme.IdeTheme
import com.codespace.ide.ide.ui.DrawerShift

// ---------------------------------------------------------------------------
// Push-style file-tree drawer (replaces ModalNavigationDrawer): the tree
// panel parks off-screen left, and the whole world below (editor screen +
// bottom panel) slides right by [DrawerShift.px] as it opens — finger,
// editor and panel move together. Drags snap 1:1; release settles with a
// soft spring. Everything derives from [px]: single source of truth.
// ---------------------------------------------------------------------------

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun IdeRoot(dependencies: AppDependencies) {
    val ubuntu = dependencies.ubuntuManager
    val proot = dependencies.prootManager
    val context = LocalContext.current
    val appContext = remember(context) { context.applicationContext }
    val workspaceBootstrap = rememberIdeWorkspace(appContext)
    val workspace = workspaceBootstrap.workspace
    if (workspace == null) {
        WorkspacePreparingScreen(workspaceBootstrap.error) { workspaceBootstrap.retry() }
        return
    }

    val hostActivity = rememberIdeHostActivity(context)
    // Activity-scoped presentation owners are provisioned outside the root
    // composable so IdeRoot remains a composition coordinator, not a second
    // ViewModel factory/dependency container.
    val rootViewModels = rememberIdeRootViewModels(
        activity = hostActivity,
        workspace = workspace,
        appContext = appContext,
        dependencies = dependencies,
    )
    val projectViewModelStores = rootViewModels.projectStores
    val projectsViewModel = rootViewModels.projects
    val projectsState by projectsViewModel.state.collectAsState()
    val settingsViewModel = rootViewModels.settings
    // The editor and Settings overlay must observe the same live state.
    // Reading SharedPreferences directly from IdeEditor is not observable,
    // so collect here and pass the current snapshot down the UI tree.
    val settingsState by settingsViewModel.state.collectAsState()
    IdeWindowThemeEffect(activity = hostActivity, themeId = settingsState.themeId)
    // Display and web-preview presentation state is Activity-scoped. The
    // actual VNC/frame servers remain owned by their existing runtime holders.
    val runtimeUiViewModel = rootViewModels.runtimeUi
    val runtimeUiState by runtimeUiViewModel.state.collectAsState()
    val displayOpen = runtimeUiState.displayOpen
    val displayUserHidden = runtimeUiState.displayUserHidden
    val frameMode = runtimeUiState.frameMode
    val frameProject = runtimeUiState.frameProject
    val displayGen = runtimeUiState.displayGeneration
    val webStatic = runtimeUiState.webServerGuess
    val webLiveUrl = runtimeUiState.webLiveUrl
    val browserOpen = runtimeUiState.browserOpen
    val openChoice = runtimeUiState.pendingBrowserChoiceUrl
    val rememberChoice = runtimeUiState.rememberBrowserChoice
    val ideScope = rememberCoroutineScope()
    // All process-scoped services were resolved by MainActivity at the
    // composition root and are passed through this typed dependency bundle.
    val notebookRepository = dependencies.notebookRepository
    val runHub = dependencies.runHub
    val runOrchestrator = dependencies.runOrchestrator
    val projectWebResolver = dependencies.projectWebResolver
    val runtimeTaskScope = dependencies.runtimeTaskScope
    val fileExplorerRepository = dependencies.fileExplorerRepository
    val codeIntelligenceRepository = dependencies.codeIntelligenceRepository
    val runtimeDispatchers = dependencies.runtimeDispatchers
    val serializeEditorSession = dependencies.serializeEditorSession
    val packageManagerRepository = dependencies.packageManagerRepository
    val shell = remember {
        IdeShell(
            context = context,
            workspace = workspace,
            proot = proot,
            ubuntu = ubuntu,
            prefs = prefs,
            ideScope = ideScope,
            runtimeUiViewModel = runtimeUiViewModel,
            projectViewModelStores = projectViewModelStores,
            notebookRepository = notebookRepository,
            hub = runHub,
            runOrchestrator = runOrchestrator,
            projectWebResolver = projectWebResolver,
            runtimeTaskScope = runtimeTaskScope,
            fileExplorerRepository = fileExplorerRepository,
            codeIntelligenceRepository = codeIntelligenceRepository,
            runtimeDispatchers = runtimeDispatchers,
            serializeEditorSession = serializeEditorSession,
            packageManagerRepository = packageManagerRepository,
            projectRepository = dependencies.projectRepository,
        )
    }
    with(shell) {
    val autoRecoveryManager = remember(appContext) {
        com.codespace.ide.ide.projects.ProjectAutoRecoveryManager(File(appContext.filesDir, "project-recovery"))
    }
    // Push-drawer state (UI only: never touches sessions, shells or files).
    val drawerShift = remember { DrawerShift() }
    drawerShift.widthPx =
    with(LocalDensity.current) { DrawerShift.WIDTH_DP.dp.toPx() }
    val drawerCommitPx = with(LocalDensity.current) { 40.dp.toPx() }
    // Page-slide transition (Home ↔ Editor): enter-only glide, chained
    // after the drawer offset so both transforms compose. Offset reads
    // are placement-only (same as the drawer swipe), so terminals never pay.
    val pageDir = if (screen is IdeScreen.Editor) 1f else -1f
    val pageSlide = remember(pageDir) { Animatable(pageDir) }
    LaunchedEffect(pageDir) {
        pageSlide.snapTo(pageDir)
        pageSlide.animateTo(
            0f,
            tween(durationMillis = 300, easing = FastOutSlowInEasing)
        )
    }
    val pageWpx = with(LocalDensity.current) {
        LocalConfiguration.current.screenWidthDp.dp.toPx()
    }
    // Leaving the IDE entirely (not a panel/tab change) releases every debuggee.
    androidx.compose.runtime.DisposableEffect(Unit) {
        onDispose {
            projectFeatures.disposeDebugControllers()
        }
    }
    CrashReportDialog()
    val hubVersion by hub.version.collectAsState()
    // Every run record belongs to a PTY surface owned by the previous IDE host.
    // Those surfaces close their whole process groups on disposal, so retire
    // stale rows after Activity recreation before they can pollute conflicts/UI.
    androidx.compose.runtime.LaunchedEffect(Unit) {
        runOrchestrator.reconcileAfterUiHostRecreated()
    }
    androidx.compose.runtime.SideEffect { proot.ideShell = ideBridge }
    // CameraX binds to the activity lifecycle; the owner is stored so a
    // guest-triggered start (phone_camera.open()) can bind too.
    val camOwner = remember(context) { context as? LifecycleOwner }
    val camActivity = remember(context) { context as? android.app.Activity }
    LaunchedEffect(camOwner, camActivity) { phoneCam.attachUi(camOwner, camActivity) }
    camPermission =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            phoneCam.onPermissionResult(granted)
        }
    // The keep-alive service posts an ongoing notification; Android 13+ needs the
    // runtime permission for it to appear. Asked only once a run actually starts.
    val notifPermission =
        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val notifPrefs = remember {
        context.getSharedPreferences("ide_notifications", android.content.Context.MODE_PRIVATE)
    }
    IdeRootRuntimeEffects(
        hubVersion = hubVersion,
        context = context,
        notificationPermission = notifPermission,
        notificationPreferences = notifPrefs,
        runOrchestrator = runOrchestrator,
        consoleRunId = consoleRunId,
        consoleLive = consoleLive,
        consoleRunning = console.running,
        consoleController = consoleCtl,
        runtimeUiViewModel = runtimeUiViewModel,
        endTerminalRun = ::endTerminalRun,
    )

    // The console must never summon the keyboard by itself — only an
    // explicit tap on its surface (e.g. for input()) may do that. So every
    // arrival on the Console tab drops focus and hides the keyboard; the
    // tap-to-focus handler inside the terminal is the sole opener.
    androidx.compose.runtime.LaunchedEffect(panelTab, panelOpen) {
        if (panelOpen && panelTab == PanelTab.Console) {
            try {
                ideFocus.clearFocus(force = true)
            } catch (_: Exception) {
            }
            try {
                ideKeyboard?.hide()
            } catch (_: Exception) {
            }
        }
    }


    IdeHostLifecycleEffects(
        lifecycleOwner = hostActivity,
        markEditorForRestore = screen is IdeScreen.Editor,
        persist = { saveFiles, markForRestore ->
            persistNow(saveFiles, markForRestore = markForRestore)
        },
        stopCamera = { phoneCam.stopAll("App paused — camera stopped.") },
    )

    // The notification's "Stop all" action reaches the real stop logic (it can close
    // the Console PTY, which a pid signal cannot do). Cleared with the screen.
    androidx.compose.runtime.SideEffect {
        hub.stopAllHandler = { stopAllRuns() }
    }
    androidx.compose.runtime.DisposableEffect(hub) {
        onDispose {
            hub.stopAllHandler = null
        }
    }
    androidx.compose.runtime.DisposableEffect(ideBridge, bridgeHostActive, termPlans) {
        onDispose {
            // Invalidate callbacks before releasing their captured UI/session data.
            bridgeHostActive.set(false)
            ideBridge.handler = null
            termPlans.close()
            // A newer Activity host may already have installed its own bridge.
            if (proot.ideShell === ideBridge) proot.ideShell = null
            ideBridge.stop()
        }
    }
    RunConflictDialog()

    BrowserChoiceDialog()
    val inEditor = screen is IdeScreen.Editor
    // Leaving the project always parks the drawer: it only exists in the
    // editor, so it must never leak a shift into Home.
    androidx.compose.runtime.LaunchedEffect(inEditor) {
        if (!inEditor) drawerShift.px.snapTo(0f)
    }
    // Idle watchdog for nested-scroll drags, which have no release callback
    // of their own: shortly after the finger stops with the drawer mid-way,
    // park it at the nearest anchor. Fling-settling normally beats it here;
    // the busy guard keeps it from fighting an in-flight animation.
    androidx.compose.runtime.LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(400)
            try {
                val d = drawerShift
                if (!d.busy && d.widthPx > 0f &&
                    SystemClock.uptimeMillis() - d.lastDragMs >= 400L
                ) {
                    val px = d.px.value
                    if (px > 2f && px < d.widthPx - 2f) d.settle(0f)
                }
            } catch (_: Exception) {
            }
        }
    }
    val activeProject = (screen as? IdeScreen.Editor)?.project
    val editorSession = (screen as? IdeScreen.Editor)?.let { sessionFor(it.project) }

    ProjectRecoveryEffects(
        project = activeProject,
        editorSession = editorSession,
        missingProjectPath = missingProject?.dir?.absolutePath,
        workspace = workspace,
        recoveryManager = autoRecoveryManager,
        scope = ideScope,
        onAvailabilityChanged = { recoveryAvailable = it },
        onErrorChanged = { recoveryError = it },
        onProjectMissing = { project ->
            missingProject = project
            recoveryError = null
            // Remove the broken editor tree immediately; do not let Compose
            // keep rendering file tabs against a vanished project root.
            screen = IdeScreen.Home
            homeTab = HomeTab.Projects
            stopAllRuns()
            stopConsole(killDisplay = true)
        }
    )

    MissingProjectDialog(projectsViewModel, autoRecoveryManager)

    val pythonLspController = rememberProjectPythonLspController(
        context = context,
        proot = proot,
        editorSession = editorSession,
        packageManagerRepository = packageManagerRepository,
        runtimeDispatchers = runtimeDispatchers,
    )
    val syntaxDiagnostics = pythonLspController?.results?.collectAsState()?.value ?: emptyMap()
    val lspDiagnostics = pythonLspController?.lspResults?.collectAsState()?.value ?: emptyMap()

    ImportSelectionDialog(editorSession)

    // Problems-panel totals are derived by a dedicated presentation adapter;
    // IdeRoot only forwards the resulting immutable counts.
    val problemCounts = rememberEditorProblemCounts(
        editorSession = editorSession,
        syntaxDiagnostics = syntaxDiagnostics,
        lspDiagnostics = lspDiagnostics,
    )
    val problemErrorCount = problemCounts.errors
    val problemWarningCount = problemCounts.warnings
    val curProject = (screen as? IdeScreen.Editor)?.project
    val curVenv = curProject?.let { projectVenvGuestPath(it.dir) }
    val curProjectKey = curProject?.dir?.absolutePath
    val projectVenvBusy = curProjectKey != null && projectsState.venvBuildingProjects.contains(curProjectKey)
    val projectVenvReady = curProject?.let { venvPythonReady(it.dir) } == true
    var observedProjectVenvBuild by remember(curProjectKey) { mutableStateOf(false) }

    // If the user opens a project while its venv is being created, the shell
    // starts in plain mode. Once the shared ProjectsViewModel reports the
    // build complete, activate the newly-created venv in that already-live
    // shell instead of requiring the user to leave/re-enter the project.
    androidx.compose.runtime.LaunchedEffect(curProjectKey, projectVenvBusy, projectVenvReady) {
        if (projectVenvBusy) {
            observedProjectVenvBuild = true
        } else if (observedProjectVenvBuild && projectVenvReady && curProject != null) {
            val guestVenv = projectVenvGuestPath(curProject.dir)
            if (guestVenv != null) {
                val command = "source $guestVenv/bin/activate\r"
                val delivered = try { bridge.send?.invoke(command) == true } catch (_: Exception) { false }
                if (!delivered) bridge.pending = command + (bridge.pending ?: "")
            }
            observedProjectVenvBuild = false
        }
    }

    // Live shells are never typed into by the IDE (no cd, no source):
    // placement comes from the process workdir + startup activation, so a
    // mid-typing session can never be clobbered and no command is doubled.
    androidx.compose.runtime.LaunchedEffect(curProject?.dir?.absolutePath, panelOpen) {
        venvBuildMsg = null
    }


    MaterialTheme(
        colorScheme = if (IdeTheme.isDark) androidx.compose.material3.darkColorScheme(
            primary = Color(IdeTheme.ACCENT),
            onPrimary = Color(IdeTheme.ON_ACCENT),
            background = Color(IdeTheme.BG),
            surface = Color(IdeTheme.PANEL),
            onBackground = Color(IdeTheme.TEXT),
            onSurface = Color(IdeTheme.TEXT),
            surfaceVariant = Color(IdeTheme.CARD),
            onSurfaceVariant = Color(IdeTheme.DIM),
            outline = Color(IdeTheme.LINE),
            error = Color(IdeTheme.ERROR)
        ) else androidx.compose.material3.lightColorScheme(
            primary = Color(IdeTheme.ACCENT),
            onPrimary = Color(IdeTheme.ON_ACCENT),
            background = Color(IdeTheme.BG),
            surface = Color(IdeTheme.PANEL),
            onBackground = Color(IdeTheme.TEXT),
            onSurface = Color(IdeTheme.TEXT),
            surfaceVariant = Color(IdeTheme.CARD),
            onSurfaceVariant = Color(IdeTheme.DIM),
            outline = Color(IdeTheme.LINE),
            error = Color(IdeTheme.ERROR)
        )
    ) {
        Box(Modifier.fillMaxSize().background(Color(IdeTheme.BG))) {
            // Push-drawer world: the editor screen AND the bottom panel
            // slide right together while the tree opens. (Inner indentation
            // keeps the historical depth; only the two wrapper Boxes are new.)
            Box(
                Modifier
                .fillMaxSize()
                .offset { IntOffset(drawerShift.px.value.roundToInt(), 0) }
                .offset { IntOffset((pageSlide.value * pageWpx).roundToInt(), 0) }
            ) {
                ScreenHost(drawerShift, pythonLspController, settingsViewModel)

                IdeBottomPanel(shell, projectsViewModel, pythonLspController, problemErrorCount, problemWarningCount)
                // Drawer scrim: dims the shifted world while the tree is open
                // (editor and panel keep sliding underneath); a tap closes
                // the tree. Above content, below the tree panel itself.
                val scrimAlpha = (drawerShift.fraction * 0.32f).coerceIn(0f, 0.32f)
                if (scrimAlpha > 0.005f) {
                    Box(
                        Modifier
                        .fillMaxSize()
                        .background(Color(IdeTheme.SCRIM).copy(alpha = scrimAlpha))
                        .drawerDrag(drawerShift, ideScope, false, drawerCommitPx)
                        .clickable(
                            indication = null,
                            interactionSource = remember { MutableInteractionSource() }
                        ) { ideScope.launch { drawerShift.close() } }
                    )
                }
            }

            FileTreePanel(drawerShift, drawerCommitPx)
        }
        DisplayOverlay()
        BrowserOverlay()
        SettingsOverlayHost(settingsViewModel, projectsViewModel)
    }
    }
}
