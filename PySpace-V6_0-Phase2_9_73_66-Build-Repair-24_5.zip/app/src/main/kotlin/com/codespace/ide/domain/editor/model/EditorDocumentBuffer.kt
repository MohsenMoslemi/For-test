package com.codespace.ide.domain.editor.model

/**
 * Compose-independent in-memory document content and save baseline.
 *
 * This class deliberately owns no file handles, dispatchers, Android APIs or UI state.
 * The editor presentation adapter is responsible for observing text changes and for
 * performing persistence. Keeping the saved baseline here makes dirty tracking a
 * deterministic, directly testable piece of document policy.
 */
class EditorDocumentBuffer(initialText: String) {
    var text: String = initialText
        private set

    var savedText: String = initialText
        private set

    val isDirty: Boolean
        get() = text != savedText

    fun replace(newText: String) {
        text = newText
    }

    /** Mark exactly the written snapshot as saved; newer edits remain dirty. */
    fun markSaved(writtenSnapshot: String) {
        savedText = writtenSnapshot
    }

    /** Replace the document from an authoritative reload and reset its save baseline. */
    fun resetFromDisk(loadedText: String) {
        text = loadedText
        savedText = loadedText
    }
}
