package com.codespace.ide.ide.github

import android.util.Base64
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeParseException
import java.nio.file.Files
import java.nio.file.FileSystems
import java.nio.file.PathMatcher
import java.nio.file.Paths
import java.util.zip.ZipInputStream
import org.json.JSONArray
import org.json.JSONObject

// Low-level GitHub REST helpers: requests, repository list/create, branches.
// Pure I/O layer: no Compose, no UI state.

internal const val GH_API = "https://api.github.com"
internal const val GH_VERSION = "2022-11-28"

internal fun ghPathSegment(value: String): String =
    java.net.URLEncoder.encode(value, "UTF-8").replace("+", "%20")

/** Encode ref path components but preserve branch separators (feature/x). */
internal fun ghRefPath(value: String): String =
    value.split('/').joinToString("/") { ghPathSegment(it) }

internal data class GhRepo(
    val fullName: String,
    val name: String,
    val isPrivate: Boolean,
    val defaultBranch: String,
    val updatedAt: String,
    val description: String
)

internal data class GhResp(val code: Int, val body: String)

/** Raw HTTPS call. Returns (status, body capped). Never throws. */
internal fun ghRequest(method: String, url: String, token: String, body: String? = null, maxResponseChars: Int = 200_000): GhResp {
    var conn: HttpURLConnection? = null
    try {
        conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 20000
            readTimeout = 60000
            if (token.isNotBlank()) setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Accept", "application/vnd.github+json")
            setRequestProperty("X-GitHub-Api-Version", GH_VERSION)
            setRequestProperty("User-Agent", "PySpace-IDE")
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
        }
        val code = try {
            conn.responseCode
        } catch (_: Exception) {
            -1
        }
        if (code < 0) return GhResp(-1, "")
        val stream = try {
            if (code in 200..299) conn.inputStream else conn.errorStream
        } catch (_: Exception) {
            null
        }
        val text = try {
            stream?.bufferedReader()?.readText()?.take(maxResponseChars.coerceAtLeast(1)) ?: ""
        } catch (_: Exception) {
            ""
        }
        return GhResp(code, text)
    } catch (_: Exception) {
        return GhResp(-1, "")
    } finally {
        try {
            conn?.disconnect()
        } catch (_: Exception) {
        }
    }
}

internal fun ghErr(r: GhResp): String {
    if (r.code == -1) return "Network error (no connection?)"
    return try {
        val m = JSONObject(r.body).optString("message", "")
        if (m.isNotBlank()) "GitHub ${r.code}: $m" else "GitHub error ${r.code}"
    } catch (_: Exception) {
        "GitHub error ${r.code}"
    }
}

internal fun parseRepos(body: String): List<GhRepo> {
    val out = mutableListOf<GhRepo>()
    try {
        val arr = JSONArray(body)
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(
                GhRepo(
                    fullName = o.optString("full_name", ""),
                    name = o.optString("name", ""),
                    isPrivate = o.optBoolean("private", false),
                    defaultBranch = o.optString("default_branch", "main").ifBlank { "main" },
                    updatedAt = o.optString("updated_at", "").take(10),
                    description = o.optString("description", "")
                )
            )
            if (out.size >= 500) break
        }
    } catch (_: Exception) {
    }
    return out.filter { it.fullName.contains("/") }
}

internal fun isValidGitBranchName(name: String): Boolean {
    if (name.isBlank() || name == "@" || name.startsWith('/') || name.endsWith('/') ||
        name.endsWith('.') || name.contains("..") || name.contains("//") || name.contains("@{")) return false
    if (name.any { it.isWhitespace() || it.isISOControl() || it in "~^:?*[\\]" }) return false
    return name.split('/').all { component ->
        component.isNotBlank() && !component.startsWith('.') && !component.endsWith(".lock")
    }
}

/** Return all branch names for a repository (up to 300). */
internal fun ghListBranches(token: String, target: String): Pair<List<String>?, String?> {
    val result = ArrayList<String>()
    for (page in 1..3) {
        val r = ghRequest("GET", "$GH_API/repos/$target/branches?per_page=100&page=$page", token)
        if (r.code != 200) return null to ghErr(r)
        try {
            val arr = JSONArray(r.body)
            for (i in 0 until arr.length()) {
                val name = arr.optJSONObject(i)?.optString("name", "") ?: ""
                if (name.isNotBlank()) result += name
            }
            if (arr.length() < 100) break
        } catch (_: Exception) {
            return null to "Could not read branch list."
        }
    }
    return result to null
}

/** Create a new branch from the selected source branch without force updates. */
internal fun ghCreateBranch(token: String, target: String, sourceBranch: String, newBranch: String): String {
    if (!isValidGitBranchName(newBranch)) return "Invalid branch name."
    val source = ghRequest("GET", "$GH_API/repos/$target/git/ref/heads/${ghRefPath(sourceBranch)}", token)
    if (source.code != 200) return ghErr(source)
    val sha = try { JSONObject(source.body).optJSONObject("object")?.optString("sha", "") ?: "" }
        catch (_: Exception) { "" }
    if (sha.isBlank()) return "Could not resolve the source branch."
    val body = JSONObject().put("ref", "refs/heads/$newBranch").put("sha", sha).toString()
    val created = ghRequest("POST", "$GH_API/repos/$target/git/refs", token, body)
    return if (created.code == 201) "Created branch $newBranch ✓" else ghErr(created)
}
