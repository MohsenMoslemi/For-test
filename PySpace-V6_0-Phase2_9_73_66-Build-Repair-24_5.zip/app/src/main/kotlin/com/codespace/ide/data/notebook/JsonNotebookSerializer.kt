package com.codespace.ide.data.notebook

import com.codespace.ide.domain.notebook.contract.NotebookSerializer
import com.codespace.ide.domain.notebook.model.NbDocSnapshot
import org.json.JSONArray
import org.json.JSONObject
import com.codespace.ide.ide.JSON

/** nbformat JSON persistence adapter. It only receives immutable domain snapshots. */
class JsonNotebookSerializer : NotebookSerializer {
    override fun serialize(snapshot: NbDocSnapshot): String {
        val root = JSONObject()
        val arr = JSONArray()
        for (cell in snapshot.cells) {
            val o = JSONObject()
            o.put("cell_type", cell.type)
            if (snapshot.useIds) o.put("id", cell.id)
            val extra = JSONObject(cell.extraJson)
            val ek = extra.keys()
            while (ek.hasNext()) {
                val key = ek.next()
                o.put(key, extra.get(key))
            }
            if (!o.has("metadata")) o.put("metadata", JSONObject())
            o.put("source", splitLines(cell.source))
            if (cell.type == "code") {
                o.put("execution_count", cell.execCount ?: JSONObject.NULL)
                val outputs = JSONArray()
                for (output in cell.outputs) {
                    val item = JSONObject()
                    when (output.kind) {
                        "stream" -> item.put("output_type", "stream")
                            .put("name", output.name).put("text", splitLines(output.text))
                        "error" -> item.put("output_type", "error")
                            .put("ename", output.ename).put("evalue", output.evalue)
                            .put("traceback", JSONArray(output.text.split("\n")))
                        else -> {
                            val data = JSONObject()
                            for ((mime, value) in output.data) {
                                data.put(mime, if (mime.startsWith("image/") && !mime.contains("svg")) value else splitLines(value))
                            }
                            item.put("output_type", if (output.kind == "result") "execute_result" else "display_data")
                                .put("data", data).put("metadata", JSONObject())
                            if (output.kind == "result") item.put("execution_count", output.execCount ?: JSONObject.NULL)
                        }
                    }
                    outputs.put(item)
                }
                o.put("outputs", outputs)
            }
            arr.put(o)
        }
        root.put("cells", arr)
        root.put("metadata", JSONObject(snapshot.metadataJson))
        root.put("nbformat", snapshot.nbformat)
        root.put("nbformat_minor", snapshot.minor)
        return root.toString(1) + "\n"
    }

    private fun splitLines(value: String): JSONArray {
        val result = JSONArray()
        if (value.isEmpty()) return result
        var start = 0
        while (start < value.length) {
            val newline = value.indexOf('\n', start)
            if (newline < 0) {
                result.put(value.substring(start))
                break
            }
            result.put(value.substring(start, newline + 1))
            start = newline + 1
        }
        return result
    }
}
