package com.codespace.ide.ide
import com.codespace.ide.ide.codeintel.PythonUnusedImport


/** Conservative, source-preserving management of module-level Python imports. */
internal object PythonImportManager {
    data class Result(
        val text: String,
        val caret: Int,
        val changed: Boolean,
        val removedDuplicates: Int = 0,
        val removedUnused: Int = 0,
        val reordered: Int = 0,
    )

    private val stdlib = setOf(
        "abc", "antigravity", "argparse", "array", "ast", "asyncio", "atexit", "base64", "bdb",
        "binascii", "bisect", "builtins", "bz2", "cProfile", "calendar", "cmath", "cmd", "code",
        "codecs", "codeop", "collections", "colorsys", "compileall", "concurrent", "configparser",
        "contextlib", "contextvars", "copy", "copyreg", "csv", "ctypes", "curses", "dataclasses",
        "datetime", "dbm", "decimal", "difflib", "dis", "doctest", "email", "encodings", "ensurepip",
        "enum", "errno", "faulthandler", "fcntl", "filecmp", "fileinput", "fnmatch", "fractions",
        "ftplib", "functools", "gc", "genericpath", "getopt", "getpass", "gettext", "glob", "graphlib",
        "grp", "gzip", "hashlib", "heapq", "hmac", "html", "http", "idlelib", "imaplib", "importlib",
        "inspect", "io", "ipaddress", "itertools", "json", "keyword", "linecache", "locale", "logging",
        "lzma", "mailbox", "marshal", "math", "mimetypes", "mmap", "modulefinder", "multiprocessing",
        "netrc", "numbers", "opcode", "operator", "optparse", "os", "pathlib", "pdb", "pickle",
        "pickletools", "pkgutil", "platform", "plistlib", "poplib", "posix", "posixpath", "pprint",
        "profile", "pstats", "pty", "pwd", "py_compile", "pyclbr", "pydoc", "pydoc_data", "pyexpat",
        "queue", "quopri", "random", "re", "readline", "reprlib", "resource", "rlcompleter", "runpy",
        "sched", "secrets", "select", "selectors", "shelve", "shlex", "shutil", "signal", "site",
        "smtplib", "socket", "socketserver", "sqlite3", "ssl", "stat", "statistics", "string",
        "stringprep", "struct", "subprocess", "symtable", "sys", "sysconfig", "syslog", "tabnanny",
        "tarfile", "tempfile", "termios", "textwrap", "this", "threading", "time", "timeit", "tkinter",
        "token", "tokenize", "tomllib", "trace", "traceback", "tracemalloc", "tty", "turtle",
        "turtledemo", "types", "typing", "unicodedata", "unittest", "urllib", "uuid", "venv", "warnings",
        "wave", "weakref", "webbrowser", "wsgiref", "xml", "xmlrpc", "zipapp", "zipfile", "zipimport",
        "zlib", "zoneinfo"
    )

    private data class Header(val lines: List<String>, val bodyStart: Int)

    /** Insert an import in the module header and normalize blank lines around it. */
    fun insert(source: String, statement: String): Pair<String, Int> {
        if (statement.isBlank()) return source to 0
        val newline = if (source.contains("\r\n")) "\r\n" else "\n"
        val lines = source.split('\n').map { it.removeSuffix("\r") }.toMutableList().also { if (source.endsWith('\n')) it.removeAt(it.lastIndex) }
        while (lines.firstOrNull()?.removeSuffix("\r")?.isBlank() == true) lines.removeAt(0)
        val clean = statement.trim()
        if (lines.any { it.trim() == clean }) return source to 0

        var i = 0
        // Preserve a shebang and a PEP-263 encoding declaration.
        if (lines.getOrNull(i)?.removeSuffix("\r")?.startsWith("#!") == true) i++
        if (i < 2 && lines.getOrNull(i)?.removeSuffix("\r")?.let { Regex("coding[:=]\\s*[-\\w.]+", RegexOption.IGNORE_CASE).containsMatchIn(it) } == true) i++
        // Keep leading license/module comments, but discard blank padding before imports.
        while (i < lines.size && lines[i].removeSuffix("\r").isBlank()) i++
        while (i < lines.size && lines[i].removeSuffix("\r").trimStart().startsWith("#")) i++
        while (i < lines.size && lines[i].removeSuffix("\r").isBlank()) i++

        // Module docstring (single- or multi-line).
        val first = lines.getOrNull(i)?.removeSuffix("\r")?.trimStart().orEmpty()
        val quote = when { first.startsWith("\"\"\"") -> "\"\"\""; first.startsWith("'''") -> "'''"; else -> null }
        if (quote != null) {
            if (first.indexOf(quote, quote.length) >= 0) i++ else {
                i++
                while (i < lines.size) { val closes = lines[i].removeSuffix("\r").contains(quote); i++; if (closes) break }
            }
        }
        // Comments/blank lines may legally appear between a module docstring and
        // future imports. Keep them in place while locating the legal insertion point.
        while (i < lines.size) {
            while (i < lines.size && (lines[i].removeSuffix("\r").isBlank() || lines[i].removeSuffix("\r").trimStart().startsWith("#"))) i++
            if (i < lines.size && lines[i].removeSuffix("\r").trimStart().startsWith("from __future__ import ")) i++ else break
        }
        while (i < lines.size && lines[i].removeSuffix("\r").isBlank()) i++

        var lastImport = -1
        var j = i
        while (j < lines.size) {
            val line = lines[j].removeSuffix("\r")
            if (line.startsWith("import ") || line.startsWith("from ") && " import " in line) {
                lastImport = j
                j++
            } else if (line.isBlank() && lastImport >= 0) {
                j++
            } else break
        }
        val insertAt = if (lastImport >= 0) lastImport + 1 else i
        // Strip blank padding immediately around the insertion point. Leading empty
        // lines in an otherwise empty editor therefore cannot push imports downward.
        var adjustedAt = insertAt.coerceIn(0, lines.size)
        while (adjustedAt > 0 && lines.getOrNull(adjustedAt - 1)?.removeSuffix("\r")?.isBlank() == true) {
            lines.removeAt(adjustedAt - 1)
            adjustedAt--
        }
        while (adjustedAt < lines.size && lines[adjustedAt].removeSuffix("\r").isBlank()) lines.removeAt(adjustedAt)
        lines.add(adjustedAt, clean)
        val headerEnd = adjustedAt + 1
        if (headerEnd < lines.size && lines[headerEnd].removeSuffix("\r").isNotBlank()) lines.add(headerEnd, "")
        // Exactly one blank line between the import block and body.
        var k = headerEnd
        while (k < lines.size && lines[k].removeSuffix("\r").isBlank()) lines.removeAt(k)
        if (k < lines.size) lines.add(k, "")
        val result = lines.joinToString(newline)
        val delta = result.length - source.length
        return result to delta
    }

    /**
     * Fixes the module import section using fresh Pyflakes F401 results from the
     * exact unsaved editor buffer. Conditional/local imports and imports below
     * executable code are intentionally untouched.
     */
    fun fix(source: String, caret: Int, unusedImports: List<PythonUnusedImport>): Result {
        val newline = if (source.contains("\r\n")) "\r\n" else "\n"
        val hadTrailingNewline = source.endsWith('\n')
        val lines = source.split('\n').map { it.removeSuffix("\r") }.toMutableList().also { if (hadTrailingNewline) it.removeAt(it.lastIndex) }
        if (lines.isEmpty()) return Result(source, caret.coerceIn(0, source.length), false)
        var i = 0
        if (lines.getOrNull(i)?.removeSuffix("\r")?.startsWith("#!") == true) i++
        if (i < 2 && lines.getOrNull(i)?.removeSuffix("\r")?.let { Regex("coding[:=]\\s*[-\\w.]+", RegexOption.IGNORE_CASE).containsMatchIn(it) } == true) i++
        while (i < lines.size && lines[i].removeSuffix("\r").isBlank()) i++
        while (i < lines.size && lines[i].removeSuffix("\r").trimStart().startsWith("#")) i++
        while (i < lines.size && lines[i].removeSuffix("\r").isBlank()) i++
        val first = lines.getOrNull(i)?.removeSuffix("\r")?.trimStart().orEmpty()
        val quote = when { first.startsWith("\"\"\"") -> "\"\"\""; first.startsWith("'''") -> "'''"; else -> null }
        if (quote != null) {
            if (first.indexOf(quote, quote.length) >= 0) i++ else {
                i++; while (i < lines.size) { val closes = lines[i].removeSuffix("\r").contains(quote); i++; if (closes) break }
            }
        }
        while (i < lines.size) {
            val line = lines[i].removeSuffix("\r")
            when {
                line.isBlank() || line.startsWith("from __future__ import ") -> i++
                isTopLevelImport(line) -> {
                    var depth = line.count { it == '(' } - line.count { it == ')' }
                    var continued = line.trimEnd().endsWith("\\")
                    i++
                    while ((depth > 0 || continued) && i < lines.size) {
                        val continuation = lines[i].removeSuffix("\r")
                        depth += continuation.count { it == '(' } - continuation.count { it == ')' }
                        continued = continuation.trimEnd().endsWith("\\")
                        i++
                    }
                }
                else -> break
            }
        }
        val headerEnd = i
        val header = lines.take(headerEnd).toMutableList()
        val body = lines.drop(headerEnd)
        val unusedByLine = unusedImports.groupBy { it.line }
        var removedUnused = 0
        val filtered = mutableListOf<String>()
        var headerIndex = 0
        while (headerIndex < header.size) {
            val candidates = unusedByLine[headerIndex + 1].orEmpty()
            val multiline = if (candidates.isNotEmpty()) {
                removeUnusedFromParenthesizedImport(header, headerIndex, candidates)
                    ?: removeUnusedContinuedImport(header, headerIndex, candidates)
            } else null
            if (multiline != null && multiline.removed > 0) {
                removedUnused += multiline.removed
                filtered.addAll(multiline.replacement)
                headerIndex += multiline.consumedLines
                continue
            }
            val raw = header[headerIndex]
            val line = raw.removeSuffix("\r")
            if (candidates.isNotEmpty()) {
                val cleaned = removeUnusedBindings(line, candidates)
                if (cleaned != null && cleaned.second > 0) {
                    removedUnused += cleaned.second
                    cleaned.first?.let(filtered::add)
                    headerIndex++
                    continue
                }
            }
            filtered += raw
            headerIndex++
        }
        // Remove duplicate import statements as whole units, including parenthesized
        // multiline imports. Never leave orphaned continuation lines behind.
        val dedupedResult = deduplicateImportStatements(filtered)
        val deduped = dedupedResult.first.toMutableList()
        val removedDuplicates = dedupedResult.second

        // Sort import blocks while treating blank lines between imports as formatting,
        // not as barriers. Comments and __future__ imports remain fixed barriers.
        var reordered = 0
        val sortedHeader = mutableListOf<String>()
        var p = 0
        while (p < deduped.size) {
            val current = deduped[p].removeSuffix("\r")
            if (!isRegularImport(current)) { sortedHeader += deduped[p]; p++; continue }
            val block = mutableListOf<String>()
            while (p < deduped.size) {
                val line = deduped[p].removeSuffix("\r")
                if (isRegularImport(line)) { block += deduped[p]; p++ }
                else if (line.isBlank()) {
                    var next = p
                    while (next < deduped.size && deduped[next].removeSuffix("\r").isBlank()) next++
                    if (next < deduped.size && isRegularImport(deduped[next].removeSuffix("\r"))) p = next else break
                } else break
            }
            val sorted = block.sortedWith(compareBy<String>({ category(it.removeSuffix("\r")) }, { it.removeSuffix("\r").lowercase() }))
            reordered += block.indices.count { block[it] != sorted[it] }
            var lastCategory = -1
            sorted.forEach { raw ->
                val group = category(raw.removeSuffix("\r"))
                if (lastCategory >= 0 && group != lastCategory && sortedHeader.lastOrNull()?.removeSuffix("\r")?.isNotBlank() == true) sortedHeader += ""
                sortedHeader += raw
                lastCategory = group
            }
        }
        deduped.clear(); deduped.addAll(sortedHeader)
        // Collapse duplicate blank lines and normalize spacing at the top of the file.
        val normalized = mutableListOf<String>()
        var previousBlank = false
        for (raw in deduped) {
            val blank = raw.removeSuffix("\r").isBlank()
            if (blank && (normalized.isEmpty() || previousBlank)) continue
            normalized += raw
            previousBlank = blank
        }
        while (normalized.lastOrNull()?.removeSuffix("\r")?.isBlank() == true) normalized.removeAt(normalized.lastIndex)
        while (normalized.firstOrNull()?.removeSuffix("\r")?.isBlank() == true) normalized.removeAt(0)
        val resultLines = normalized.toMutableList()
        if (resultLines.isNotEmpty() && body.any { it.removeSuffix("\r").isNotBlank() }) resultLines += ""
        resultLines += body
        val result = resultLines.joinToString(newline) + if (hadTrailingNewline) newline else ""
        val oldHeaderLength = if (headerEnd > 0) lines.take(headerEnd).joinToString(newline).length + newline.length else 0
        val newBodyStartLine = (resultLines.size - body.size).coerceAtLeast(0)
        val newHeaderLines = resultLines.take(newBodyStartLine)
        val newHeaderLength = if (newHeaderLines.isNotEmpty()) newHeaderLines.joinToString(newline).length + newline.length else 0
        val newCaret = if (caret >= oldHeaderLength) (caret + newHeaderLength - oldHeaderLength).coerceIn(0, result.length) else caret.coerceIn(0, result.length)
        return Result(result, newCaret, result != source, removedDuplicates, removedUnused, reordered)
    }

    private fun isRegularImport(line: String): Boolean = isTopLevelImport(line) && !line.startsWith("from __future__ import ")

    private fun isTopLevelImport(line: String): Boolean =
        !line.startsWith(" ") && !line.startsWith("\t") &&
            (line.startsWith("import ") || line.startsWith("from ") && " import " in line)

    private fun deduplicateImportStatements(lines: List<String>): Pair<List<String>, Int> {
        val output = mutableListOf<String>()
        val seen = mutableSetOf<String>()
        var removed = 0
        var index = 0
        while (index < lines.size) {
            val line = lines[index].removeSuffix("\r")
            if (!isTopLevelImport(line)) {
                output += lines[index]
                index++
                continue
            }
            val block = mutableListOf<String>()
            block += lines[index]
            var consumed = 1
            if ((line.startsWith("from ") && '(' in line) || line.trimEnd().endsWith("\\")) {
                var depth = line.count { it == '(' } - line.count { it == ')' }
                var continued = line.trimEnd().endsWith("\\")
                while ((depth > 0 || continued) && index + consumed < lines.size) {
                    val continuation = lines[index + consumed].removeSuffix("\r")
                    block += lines[index + consumed]
                    depth += continuation.count { it == '(' } - continuation.count { it == ')' }
                    continued = continuation.trimEnd().endsWith("\\")
                    consumed++
                }
            }
            val normalizedLines = block.map { it.removeSuffix("\r") }
            val hasComment = normalizedLines.any { '#' in it }
            val complete = (('(' !in line && !line.trimEnd().endsWith("\\")) ||
                normalizedLines.sumOf { it.count { ch -> ch == '(' } - it.count { ch -> ch == ')' } } == 0) &&
                !normalizedLines.lastOrNull().orEmpty().trimEnd().endsWith("\\")
            val key = if (hasComment || !complete) null else normalizedLines
                .joinToString(" ") { it.trim() }
                .replace("(", " ")
                .replace(")", " ")
                .replace(Regex("\\s+"), " ")
                .trim()
                .removeSuffix(",")
                .trim()
            if (key != null && !seen.add(key)) {
                removed++
            } else {
                output.addAll(block)
            }
            index += consumed
        }
        return output to removed
    }

    private data class MultilineCleanup(
        val replacement: List<String>,
        val consumedLines: Int,
        val removed: Int,
    )

    /** Safely handles explicit backslash-continued import statements. */
    private fun removeUnusedContinuedImport(
        lines: List<String>,
        startIndex: Int,
        diagnostics: List<PythonUnusedImport>,
    ): MultilineCleanup? {
        val first = lines.getOrNull(startIndex)?.removeSuffix("\r") ?: return null
        if (!isTopLevelImport(first) || !first.trimEnd().endsWith("\\")) return null
        val block = mutableListOf<String>()
        var index = startIndex
        var continued = true
        while (continued && index < lines.size) {
            val line = lines[index].removeSuffix("\r")
            if ('#' in line) return null
            block += line
            continued = line.trimEnd().endsWith("\\")
            index++
        }
        if (continued) return null
        val logical = block.joinToString(" ") { it.trim().removeSuffix("\\").trimEnd() }
        val cleaned = removeUnusedBindings(logical, diagnostics) ?: return null
        if (cleaned.second <= 0) return null
        val replacement = cleaned.first?.let(::listOf) ?: emptyList()
        return MultilineCleanup(replacement, block.size, cleaned.second)
    }

    /** Safely handles parenthesized from-import statements, including multiline forms. */
    private fun removeUnusedFromParenthesizedImport(
        lines: List<String>,
        startIndex: Int,
        diagnostics: List<PythonUnusedImport>,
    ): MultilineCleanup? {
        val first = lines.getOrNull(startIndex)?.removeSuffix("\r") ?: return null
        if (!first.startsWith("from ") || " import " !in first || '(' !in first) return null
        val prefixMatch = Regex("^from\\s+([^\\s]+)\\s+import\\s*\\(").find(first) ?: return null
        val module = prefixMatch.groupValues[1]
        var depth = 0
        var endIndex = -1
        for (index in startIndex until lines.size) {
            val line = lines[index].removeSuffix("\r")
            // Comments inside a parenthesized import may carry noqa/type intent;
            // do not rewrite the statement if any are present.
            if ('#' in line) return null
            depth += line.count { it == '(' } - line.count { it == ')' }
            if (depth == 0) { endIndex = index; break }
        }
        if (endIndex < startIndex) return null
        val statement = lines.subList(startIndex, endIndex + 1).joinToString("\n")
        val open = statement.indexOf('(')
        val close = statement.lastIndexOf(')')
        if (open < 0 || close <= open) return null
        val contents = statement.substring(open + 1, close).trim()
        val segments = contents.split(',').map { it.trim() }.filter { it.isNotEmpty() }
        if (segments.isEmpty()) return null
        val unusedNames = diagnostics.map { it.importedName.trim() }.toSet()
        val kept = mutableListOf<String>()
        var removed = 0
        for (segment in segments) {
            val normalized = segment.replace(Regex("\\s+as\\s+"), " as ")
            val imported = normalized.substringBefore(" as ")
            val alias = normalized.substringAfter(" as ", "")
            val canonical = module + "." + imported + if (alias.isNotEmpty()) " as $alias" else ""
            if (canonical in unusedNames) removed++ else kept += normalized
        }
        if (removed == 0) return null
        val replacement = if (kept.isEmpty()) emptyList() else listOf("from $module import " + kept.joinToString(", "))
        return MultilineCleanup(replacement, endIndex - startIndex + 1, removed)
    }

    /**
     * Removes only the bindings Pyflakes marked F401. Simple comma-separated
     * imports are edited binding-by-binding; parenthesized, continued, commented,
     * and noqa-protected statements are preserved rather than guessed at.
     * Returns (replacement line or null when the whole line is removed, count).
     */
    private fun removeUnusedBindings(
        line: String,
        diagnostics: List<PythonUnusedImport>,
    ): Pair<String?, Int>? {
        if (!isTopLevelImport(line) || line.contains('#') || '\\' in line || ';' in line ||
            '(' in line || ')' in line || line.startsWith("from __future__ import ")
        ) return null

        val fromMatch = Regex("^from\\s+([^\\s]+)\\s+import\\s+(.+)$").matchEntire(line)
        val isFrom = fromMatch != null
        val prefix: String
        val module: String
        val importsText: String
        if (isFrom) {
            module = fromMatch!!.groupValues[1]
            importsText = fromMatch.groupValues[2]
            prefix = line.substring(0, line.indexOf(importsText))
        } else if (line.startsWith("import ")) {
            module = ""
            importsText = line.removePrefix("import ")
            prefix = "import "
        } else return null

        val segments = importsText.split(',')
        if (segments.any { it.isBlank() }) return null
        val unusedNames = diagnostics.map { it.importedName.trim() }.toSet()
        val kept = mutableListOf<String>()
        var removed = 0
        for (segment in segments) {
            val normalized = segment.trim().replace(Regex("\\s+as\\s+"), " as ")
            val canonical = if (isFrom) {
                val imported = normalized.substringBefore(" as ")
                val alias = normalized.substringAfter(" as ", "")
                module + "." + imported + if (alias.isNotEmpty()) " as $alias" else ""
            } else normalized
            if (canonical in unusedNames) removed++ else kept += normalized
        }
        if (removed == 0) return null
        if (kept.isEmpty()) return null to removed
        return (prefix + kept.joinToString(", ")) to removed
    }

    private fun category(line: String): Int {
        if (line.startsWith("from .")) return 2
        val module = if (line.startsWith("import ")) line.removePrefix("import ").substringBefore(',').substringBefore(" as ").trim()
            else line.removePrefix("from ").substringBefore(' ').trim()
        return if (module.substringBefore('.').trim() in stdlib) 0 else 1
    }
}
