package com.codespace.ide.ide.editor

import kotlin.math.max

/** Immutable geometry calculations for the editor's pinch-zoom hand-off. */
internal object EditorZoomGeometry {
    data class ScaleRatio(val vertical: Float, val horizontal: Float)

    data class ScrollTarget(val x: Float, val y: Float)

    /** Convert measured old/new font metrics into the exact physical preview ratios. */
    fun scaleRatio(startMetrics: FloatArray, targetMetrics: FloatArray): ScaleRatio {
        val vertical = if (startMetrics[0] > 0f) targetMetrics[0] / startMetrics[0] else 1f
        val horizontal = if (startMetrics[1] > 0f) targetMetrics[1] / startMetrics[1] else 1f
        return ScaleRatio(vertical, horizontal)
    }

    /** The same quadratic ease-out used by the original 90 ms zoom settle. */
    fun easedScale(from: Float, to: Float, progress: Float): Float {
        val p = progress.coerceIn(0f, 1f)
        val eased = 1f - (1f - p) * (1f - p)
        return from + (to - from) * eased
    }

    /**
     * Compute scroll offsets after the committed font changes. The horizontal
     * origin is the gutter plus text padding; wrapped text keeps its horizontal
     * offset because its content is reflowed rather than scaled.
     */
    fun committedScrollTarget(
        currentX: Float,
        currentY: Float,
        oldGutterPx: Float,
        newGutterPx: Float,
        textPaddingPx: Float,
        ratio: ScaleRatio,
        wordWrap: Boolean
    ): ScrollTarget {
        val y = currentY * ratio.vertical
        val x = if (wordWrap) currentX else {
            val origin = oldGutterPx + textPaddingPx
            if (currentX > origin) {
                newGutterPx + textPaddingPx + (currentX - origin) * ratio.horizontal
            } else currentX
        }
        return ScrollTarget(x, y)
    }

    /** Preserve the same fractional point within the wrapped visual line. */
    fun wrappedAnchorScrollTarget(
        textPaddingPx: Float,
        lineTop: Float,
        lineBottom: Float,
        lineFraction: Float
    ): Float {
        val lineHeight = max(1f, lineBottom - lineTop)
        return textPaddingPx + lineTop + lineFraction * lineHeight
    }
}
