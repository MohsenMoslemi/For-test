package com.codespace.ide.service

import android.content.Context
import android.content.Intent
import com.codespace.ide.ide.RunHub

/**
 * Glue between [RunHub] (the single list of everything the IDE started) and the
 * foreground service. Started once from Application: whenever the set of running
 * things changes, the service is started/updated, and when the last one ends it
 * is stopped. No project-specific knowledge lives here.
 */
class RunServiceManager(
    private val context: Context,
    private val hub: RunHub
) {
    private var observing = false
    private var lastSignature = ""

    private val listener: () -> Unit = { sync() }

    fun start() {
        if (observing) return
        observing = true
        lastSignature = ""
        hub.addListener(listener)
        sync()
    }

    fun stop() {
        if (!observing) return
        observing = false
        hub.removeListener(listener)
        lastSignature = ""
        try {
            context.stopService(Intent(context, RunForegroundService::class.java))
        } catch (_: Exception) {
        }
    }

    @Synchronized
    private fun sync() {
        val runs = hub.running()
        if (runs.isEmpty()) {
            if (lastSignature.isNotEmpty()) {
                lastSignature = ""
                try {
                    context.stopService(Intent(context, RunForegroundService::class.java))
                } catch (_: Exception) {
                }
            }
            return
        }
        val signature = runs.joinToString("\n") { it.id + "|" + it.title + "|" + (it.webUrl ?: "") }
        if (signature == lastSignature) return
        lastSignature = signature
        val intent = Intent(context, RunForegroundService::class.java)
            .setAction(RunForegroundService.ACTION_UPDATE)
        try {
            context.startForegroundService(intent)
        } catch (_: Exception) {
            // Background-start restrictions: the run still works, only the
            // notification/keep-alive could not be raised.
            try {
                context.startService(intent)
            } catch (_: Exception) {
            }
        }
    }
}
