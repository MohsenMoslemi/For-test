package com.codespace.ide.ide

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import com.codespace.ide.ide.codeintel.PythonSyntaxDiagnostic
import com.codespace.ide.ide.editor.EditorSession

/** Immutable totals displayed by the Problems panel. */
data class EditorProblemCounts(
    val errors: Int = 0,
    val warnings: Int = 0,
)

/**
 * Derives Problems-panel totals from the active editor session and its current
 * diagnostics. The editor session remains the source of document text; this
 * adapter owns only the debounced presentation aggregation.
 */
@Composable
internal fun rememberEditorProblemCounts(
    editorSession: EditorSession?,
    syntaxDiagnostics: Map<String, List<PythonSyntaxDiagnostic>>,
    lspDiagnostics: Map<String, List<PythonSyntaxDiagnostic>>,
): EditorProblemCounts {
    var counts by remember { mutableStateOf(EditorProblemCounts()) }

    LaunchedEffect(editorSession, syntaxDiagnostics, lspDiagnostics) {
        val session = editorSession
        if (session == null) {
            counts = EditorProblemCounts()
            return@LaunchedEffect
        }

        fun calculate(): EditorProblemCounts {
            var errors = 0
            var warnings = 0
            session.tabs.forEach { tab ->
                if (EditorLanguageRegistry.languageFor(tab.file) != EditorLanguage.PYTHON) {
                    return@forEach
                }
                val path = tab.file.absolutePath
                val fallback = pythonProblems(tab.text)
                val hasLsp = lspDiagnostics.containsKey(path)
                val diagnostics = syntaxDiagnostics[path].orEmpty()
                if (hasLsp) {
                    errors += diagnostics.count { it.kind.equals("Error", true) }
                    warnings += diagnostics.count { it.kind.equals("Warning", true) }
                } else {
                    val nativeTypes = diagnostics.filter {
                        it.code?.startsWith("PYSPACE-TYPE-") == true
                    }
                    errors += fallback.count { it.error } +
                        nativeTypes.count { it.kind.equals("Error", true) }
                    warnings += fallback.count { !it.error } +
                        nativeTypes.count { it.kind.equals("Warning", true) }
                }
            }
            return EditorProblemCounts(errors, warnings)
        }

        counts = calculate()
        snapshotFlow { session.tabs.map { it.text } }.collectLatest {
            delay(220L)
            counts = calculate()
        }
    }

    return counts
}
