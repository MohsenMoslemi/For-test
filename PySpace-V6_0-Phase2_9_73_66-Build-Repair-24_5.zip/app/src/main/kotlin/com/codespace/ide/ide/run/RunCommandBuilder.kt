package com.codespace.ide.ide.run

/**
 * Builds the shell snippets used to start IDE-managed Python programs.
 *
 * This object contains only deterministic string assembly. It deliberately
 * does not inspect project files, access Android APIs, start a process, or own
 * a PTY. Runtime preparation (GUI, camera, bridge and web-framework detection)
 * remains with the existing runtime owners until those responsibilities can
 * be extracted independently.
 */
object RunCommandBuilder {

    /**
     * Creates the guest-side bridge environment prefix for a managed run.
     * A missing bridge URL means that the guest hook is unavailable, matching
     * the previous fail-open behavior.
     */
    fun buildHookPrefix(
        bridgeUrl: String?,
        token: String,
        runId: String,
    ): String {
        if (bridgeUrl.isNullOrBlank()) return ""
        return "export IDE_BRIDGE=" + bridgeUrl +
            " IDE_TOKEN=" + token +
            " IDE_RUN_ID=" + runId +
            "; export PYTHONPATH=\"/tmp/ide/py\${PYTHONPATH:+:\$PYTHONPATH}\"; "
    }

    /**
     * Builds the command used by the Console PTY. The command shape and shell
     * quoting intentionally preserve the established behavior in this phase.
     */
    fun buildConsoleCommand(
        projectGuestPath: String,
        guiPrefix: String,
        cameraPrefix: String,
        hookPrefix: String,
        programCommand: String,
    ): String =
        "cd " + projectGuestPath + " && { " +
            guiPrefix +
            cameraPrefix +
            hookPrefix +
            programCommand +
            "; }; code=\$?; echo; echo \"[exit=\$code]\""

    /**
     * Combines optional Terminal setup prefixes. Empty prefixes are ignored;
     * non-empty prefixes retain their original order and exact contents.
     */
    fun buildTerminalPrefix(guiPrefix: String, cameraPrefix: String): String =
        buildString(guiPrefix.length + cameraPrefix.length) {
            append(guiPrefix)
            append(cameraPrefix)
        }
}
