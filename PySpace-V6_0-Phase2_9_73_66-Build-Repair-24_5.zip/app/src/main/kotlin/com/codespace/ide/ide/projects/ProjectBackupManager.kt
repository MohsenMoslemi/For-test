package com.codespace.ide.ide.projects

import android.content.ContentResolver
import android.net.Uri


import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Progress is based on actual uncompressed file bytes, not an animation estimate. */
data class BackupProgress(
    val phase: String,
    val currentFile: String? = null,
    val filesProcessed: Int = 0,
    val totalFiles: Int? = null,
    val bytesProcessed: Long = 0L,
    val totalBytes: Long? = null,
) {
    val fraction: Float?
        get() = when {
            totalBytes != null && totalBytes > 0L -> (bytesProcessed.toDouble() / totalBytes).toFloat().coerceIn(0f, 1f)
            totalFiles != null && totalFiles > 0 -> (filesProcessed.toFloat() / totalFiles).coerceIn(0f, 1f)
            else -> null
        }
}

/** Portable source backup. Virtualenvs and regenerable caches are deliberately excluded. */
class ProjectBackupManager(private val resolver: ContentResolver) {
    fun exportWorkspace(
        workspace: File,
        destination: Uri,
        onProgress: (BackupProgress) -> Unit = {},
        checkCancelled: () -> Unit = {},
    ): Int {
        val projects = workspace.listFiles()?.filter { it.isDirectory && !it.name.startsWith(".") }?.sortedBy { it.name }.orEmpty()
        require(projects.isNotEmpty()) { "There are no projects to back up." }
        val totals = scanProjects(projects, onProgress, checkCancelled)
        writeBackup(destination, totals, checkCancelled) { zip, tracker ->
            putText(zip, "pyspace-backup.properties", "format=pyspace-backup\nversion=1\nkind=workspace\nprojectCount=${projects.size}\n")
            projects.forEach { project -> addProject(zip, project, "projects/${project.name}", tracker, onProgress, checkCancelled) }
        }
        onProgress(BackupProgress("Backup complete", filesProcessed = totals.first, totalFiles = totals.first, bytesProcessed = totals.second, totalBytes = totals.second))
        return projects.size
    }

    fun exportProject(
        project: PyProject,
        destination: Uri,
        onProgress: (BackupProgress) -> Unit = {},
        checkCancelled: () -> Unit = {},
    ) {
        require(project.dir.isDirectory) { "The project no longer exists." }
        val totals = scanProjects(listOf(project.dir), onProgress, checkCancelled)
        writeBackup(destination, totals, checkCancelled) { zip, tracker ->
            putText(zip, "pyspace-backup.properties", "format=pyspace-backup\nversion=1\nkind=project\nprojectCount=1\n")
            addProject(zip, project.dir, "project/${project.name}", tracker, onProgress, checkCancelled)
        }
        onProgress(BackupProgress("Backup complete", filesProcessed = totals.first, totalFiles = totals.first, bytesProcessed = totals.second, totalBytes = totals.second))
    }

    private fun writeBackup(
        destination: Uri,
        totals: Pair<Int, Long>,
        checkCancelled: () -> Unit,
        writer: (ZipOutputStream, Tracker) -> Unit,
    ) {
        try {
            checkCancelled()
            val output = resolver.openOutputStream(destination, "wt")
                ?: throw IllegalStateException("Could not create the backup file. Choose another location.")
            output.use { raw -> ZipOutputStream(BufferedOutputStream(raw)).use { zip -> writer(zip, Tracker(totalFiles = totals.first, totalBytes = totals.second)) } }
        } catch (error: Exception) {
            // A cancelled/failed export must not leave a plausible-looking partial ZIP.
            try { resolver.delete(destination, null, null) } catch (_: Exception) { }
            throw error
        }
    }

    /** Restores into staging and only publishes complete projects after validation. */
    fun restore(
        workspace: File,
        source: Uri,
        onProgress: (BackupProgress) -> Unit = {},
        checkCancelled: () -> Unit = {},
    ): List<String> {
        onProgress(BackupProgress("Inspecting backup archive…"))
        val totals = inspectArchive(source, checkCancelled)
        val staging = File(workspace, ".pyspace-restore-${System.nanoTime()}")
        if (!staging.mkdirs()) throw IllegalStateException("Could not prepare temporary restore storage.")
        val stagedProjects = mutableListOf<File>()
        val committed = mutableListOf<File>()
        try {
            var filesDone = 0
            var bytesDone = 0L
            var lastReportedBytes = 0L
            val input = resolver.openInputStream(source) ?: throw IllegalStateException("Could not open the selected backup file.")
            input.use { raw -> ZipInputStream(BufferedInputStream(raw)).use { zip ->
                var entry: ZipEntry?
                while (zip.nextEntry.also { entry = it } != null) {
                    checkCancelled()
                    val current = entry!!
                    val name = validateEntryName(current.name)
                    if (name == "pyspace-backup.properties") {
                        zip.readBytesLimited(16 * 1024)
                    } else {
                        val target = File(staging, name).canonicalFile
                        require(target.toPath().startsWith(staging.canonicalFile.toPath())) { "Unsafe backup path: $name" }
                        if (current.isDirectory) {
                            if (!target.exists() && !target.mkdirs()) throw IllegalStateException("Could not create restore folder: $name")
                        } else {
                            target.parentFile?.let { if (!it.exists() && !it.mkdirs()) throw IllegalStateException("Could not create restore folder.") }
                            require(!target.exists()) { "The backup contains a duplicate path: $name" }
                            FileOutputStream(target).use { out ->
                                val buffer = ByteArray(COPY_BUFFER_SIZE)
                                while (true) {
                                    checkCancelled()
                                    val count = zip.read(buffer)
                                    if (count < 0) break
                                    bytesDone += count
                                    require(bytesDone <= MAX_RESTORE_BYTES) { "Backup is larger than the supported 2 GB restore limit." }
                                    out.write(buffer, 0, count)
                                    if (bytesDone - lastReportedBytes >= PROGRESS_REPORT_INTERVAL) {
                                        lastReportedBytes = bytesDone
                                        onProgress(BackupProgress("Restoring files…", name, filesDone, totals.first, bytesDone, totals.second))
                                    }
                                }
                            }
                            filesDone++
                            onProgress(BackupProgress("Restoring files…", name, filesDone, totals.first, bytesDone, totals.second))
                        }
                    }
                    zip.closeEntry()
                }
            } }
            val projectRoots = sequenceOf(File(staging, "project"), File(staging, "projects"))
                .flatMap { root -> root.listFiles()?.asSequence().orEmpty() }
                .filter { it.isDirectory }.toList()
            require(projectRoots.isNotEmpty()) { "The backup does not contain any projects." }
            projectRoots.forEach { root ->
                checkCancelled()
                require(root.listFiles()?.isNotEmpty() == true) { "The project '${root.name}' appears to be empty or incomplete." }
                stagedProjects += root
            }
            val restoredNames = mutableListOf<String>()
            stagedProjects.forEach { staged ->
                checkCancelled()
                val target = uniqueProjectTarget(workspace, staged.name)
                if (!staged.renameTo(target)) throw IllegalStateException("Could not restore project '${staged.name}'. Check available storage.")
                committed += target
                restoredNames += target.name
            }
            onProgress(BackupProgress("Restore complete", filesProcessed = filesDone, totalFiles = totals.first, bytesProcessed = bytesDone, totalBytes = totals.second))
            return restoredNames
        } catch (error: Exception) {
            committed.forEach { it.deleteRecursively() }
            throw error
        } finally {
            staging.deleteRecursively()
        }
    }

    private fun inspectArchive(source: Uri, checkCancelled: () -> Unit): Pair<Int, Long> {
        val input = resolver.openInputStream(source) ?: throw IllegalStateException("Could not open the selected backup file.")
        var manifestSeen = false
        var files = 0
        var bytes = 0L
        val seen = HashSet<String>()
        input.use { raw -> ZipInputStream(BufferedInputStream(raw)).use { zip ->
            var entry: ZipEntry?
            while (zip.nextEntry.also { entry = it } != null) {
                checkCancelled()
                val current = entry!!
                val name = validateEntryName(current.name)
                if (!seen.add(name)) throw IllegalArgumentException("The backup contains a duplicate path: $name")
                if (name == "pyspace-backup.properties") {
                    val manifest = zip.readBytesLimited(16 * 1024).toString(Charsets.UTF_8)
                    require(manifest.lineSequence().any { it == "format=pyspace-backup" }) { "This is not a valid PySpace backup." }
                    require(manifest.lineSequence().any { it == "version=1" }) { "This backup format version is not supported." }
                    manifestSeen = true
                } else {
                    val parts = name.trimEnd('/').split('/')
                    require(parts.size >= 2 && parts[0] in setOf("project", "projects")) { "Unexpected item in backup: $name" }
                    require(parts.size >= 3 || current.isDirectory) { "Unexpected item in backup: $name" }
                    require(parts[1].matches(Regex("[A-Za-z0-9_.-]{1,80}")) && parts[1] !in setOf(".", "..")) { "Invalid project name in backup: ${parts[1]}" }
                    if (!current.isDirectory) {
                        files++
                        val buffer = ByteArray(COPY_BUFFER_SIZE)
                        while (true) {
                            checkCancelled()
                            val count = zip.read(buffer)
                            if (count < 0) break
                            bytes += count
                            require(bytes <= MAX_RESTORE_BYTES) { "Backup is larger than the supported 2 GB restore limit." }
                        }
                    }
                }
                zip.closeEntry()
            }
        } }
        require(manifestSeen) { "The selected ZIP is not a PySpace backup." }
        return files to bytes
    }

    private fun validateEntryName(rawName: String): String {
        val name = rawName.replace('\\', '/')
        val clean = name.trimEnd('/')
        require(clean.isNotEmpty() && !name.startsWith("/") && !name.startsWith("~") &&
            clean.split('/').none { it == ".." || it == "." || it.isEmpty() } && !Regex("^[A-Za-z]:").containsMatchIn(name)) {
            "Unsafe path in backup: $rawName"
        }
        return name
    }

    private data class Tracker(val totalFiles: Int, val totalBytes: Long, var files: Int = 0, var bytes: Long = 0L, var lastReportedBytes: Long = 0L)

    private fun scanProjects(
        projects: List<File>,
        onProgress: (BackupProgress) -> Unit,
        checkCancelled: () -> Unit,
    ): Pair<Int, Long> {
        var files = 0
        var bytes = 0L
        onProgress(BackupProgress("Scanning project files…"))
        projects.forEach { project ->
            val excluded = setOf(projectVenvName(project), ".venv", "venv", "env", ".env", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".tox", ".nox")
            val base = project.canonicalFile
            project.walkTopDown().onEnter { dir -> checkCancelled(); dir == project || dir.name !in excluded }
                .forEach fileLoop@{ file ->
                    checkCancelled()
                    val canonical = try { file.canonicalFile } catch (_: Exception) { return@fileLoop }
                    if (!canonical.toPath().startsWith(base.toPath())) return@fileLoop
                    if (file.isFile && !file.name.endsWith(".pyc", true)) { files++; bytes += file.length() }
                }
        }
        onProgress(BackupProgress("Preparing archive…", filesProcessed = 0, totalFiles = files, bytesProcessed = 0, totalBytes = bytes))
        return files to bytes
    }

    private fun addProject(
        zip: ZipOutputStream,
        project: File,
        archiveRoot: String,
        tracker: Tracker,
        onProgress: (BackupProgress) -> Unit,
        checkCancelled: () -> Unit,
    ) {
        val excludedDirs = setOf(projectVenvName(project), ".venv", "venv", "env", ".env", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".tox", ".nox")
        val base = project.canonicalFile
        project.walkTopDown().onEnter { dir -> checkCancelled(); dir == project || dir.name !in excludedDirs }.forEach { file ->
            checkCancelled()
            if (file == project) {
                zip.putNextEntry(ZipEntry("$archiveRoot/")); zip.closeEntry()
            } else {
                val relative = file.relativeTo(project).invariantSeparatorsPath
                if (relative.split('/').any { it in excludedDirs }) return@forEach
                val canonical = try { file.canonicalFile } catch (_: Exception) { return@forEach }
                if (!canonical.toPath().startsWith(base.toPath())) return@forEach
                val entryName = "$archiveRoot/$relative" + if (file.isDirectory) "/" else ""
                if (file.isDirectory) {
                    zip.putNextEntry(ZipEntry(entryName)); zip.closeEntry()
                } else if (file.isFile && !file.name.endsWith(".pyc", true)) {
                    zip.putNextEntry(ZipEntry(entryName))
                    FileInputStream(file).use { input ->
                        val buffer = ByteArray(COPY_BUFFER_SIZE)
                        while (true) {
                            checkCancelled()
                            val count = input.read(buffer)
                            if (count < 0) break
                            zip.write(buffer, 0, count)
                            tracker.bytes += count
                            if (tracker.bytes - tracker.lastReportedBytes >= PROGRESS_REPORT_INTERVAL) {
                                tracker.lastReportedBytes = tracker.bytes
                                onProgress(BackupProgress("Creating ZIP archive…", relative, tracker.files, tracker.totalFiles, tracker.bytes, tracker.totalBytes))
                            }
                        }
                    }
                    tracker.files++
                    zip.closeEntry()
                    onProgress(BackupProgress("Creating ZIP archive…", relative, tracker.files, tracker.totalFiles, tracker.bytes, tracker.totalBytes))
                }
            }
        }
    }

    private fun putText(zip: ZipOutputStream, name: String, text: String) {
        zip.putNextEntry(ZipEntry(name)); zip.write(text.toByteArray(Charsets.UTF_8)); zip.closeEntry()
    }

    private fun uniqueProjectTarget(workspace: File, name: String): File {
        var candidate = File(workspace, name)
        var index = 1
        while (candidate.exists()) candidate = File(workspace, "${name}_restored${index++}")
        return candidate
    }

    private fun ZipInputStream.readBytesLimited(limit: Int): ByteArray {
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(1024)
        while (true) { val count = read(buffer); if (count < 0) break; require(output.size() + count <= limit) { "Backup manifest is too large." }; output.write(buffer, 0, count) }
        return output.toByteArray()
    }

    companion object {
        private const val COPY_BUFFER_SIZE = 64 * 1024
        private const val PROGRESS_REPORT_INTERVAL = 512L * 1024L
        private const val MAX_RESTORE_BYTES = 2L * 1024L * 1024L * 1024L
    }
}
