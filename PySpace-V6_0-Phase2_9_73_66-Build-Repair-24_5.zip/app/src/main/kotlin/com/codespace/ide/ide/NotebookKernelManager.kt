package com.codespace.ide.ide

import android.content.Context
import com.codespace.ide.ProotManager
import java.io.File
import com.codespace.ide.ide.projects.PyProject

/**
 * Application-scoped owner of notebook kernels.
 *
 * Each notebook document owns one independent Python interpreter. A kernel is
 * retained across Compose disposal (tab switches / Raw JSON / Activity
 * recreation) and is released only when its notebook session is removed.
 */
class NotebookKernelManager(
    private val context: Context,
    private val proot: ProotManager
) {
    private val lock = Any()
    private val kernels = LinkedHashMap<String, NbKernel>()

    private fun key(file: File, project: PyProject): String =
        file.absolutePath + "\u0000" + project.dir.absolutePath

    /** Returns the existing kernel for this notebook, or creates an isolated one. */
    fun kernelFor(file: File, project: PyProject): NbKernel = synchronized(lock) {
        val k = key(file, project)
        kernels.getOrPut(k) { NbKernel(proot, context, project) }
    }

    /** Stop only the kernel owned by this notebook file. */
    fun release(file: File, project: PyProject) {
        val stopped = synchronized(lock) { kernels.remove(key(file, project)) }
        stopped?.shutdown()
    }

    /** Stops kernels whose notebook files are below a moved, renamed or deleted path. */
    fun releaseUnder(path: File, project: PyProject) {
        val target = path.absolutePath
        val projectSuffix = "\u0000" + project.dir.absolutePath
        val stopped = synchronized(lock) {
            val matching = kernels.entries.filter { entry ->
                val notebookPath = entry.key.substringBefore("\u0000")
                (notebookPath == target || notebookPath.startsWith(target + File.separator)) &&
                    entry.key.endsWith(projectSuffix)
            }
            matching.forEach { kernels.remove(it.key) }
            matching.map { it.value }
        }
        stopped.forEach { it.shutdown() }
    }

    /** Stops all kernels owned by a project that has been deleted. */
    fun releaseProject(project: PyProject) {
        val projectSuffix = "\u0000" + project.dir.absolutePath
        val stopped = synchronized(lock) {
            val matching = kernels.entries.filter { it.key.endsWith(projectSuffix) }
            matching.forEach { kernels.remove(it.key) }
            matching.map { it.value }
        }
        stopped.forEach { it.shutdown() }
    }

    /** Stops every notebook kernel (runtime reinstall, sign-out, tests). */
    fun shutdownAll() {
        val all = synchronized(lock) {
            val copy = kernels.values.toList()
            kernels.clear()
            copy
        }
        all.forEach { it.shutdown() }
    }
}
