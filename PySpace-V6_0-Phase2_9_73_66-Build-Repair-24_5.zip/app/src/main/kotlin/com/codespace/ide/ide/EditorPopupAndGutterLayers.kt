package com.codespace.ide.ide

import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.layout.BoxScope

import androidx.compose.ui.unit.Density
import androidx.compose.foundation.ScrollState
import kotlinx.coroutines.CoroutineScope

import java.io.File

import androidx.compose.animation.core.AnimationState
import androidx.compose.animation.core.DecayAnimationSpec
import androidx.compose.animation.core.animateDecay
import androidx.compose.animation.core.exponentialDecay
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.relocation.BringIntoViewResponder
import androidx.compose.foundation.relocation.bringIntoViewResponder
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.Layout
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.ui.layout.Measurable
import androidx.compose.ui.layout.Placeable
import androidx.compose.ui.layout.layoutId
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.input.nestedscroll.NestedScrollDispatcher
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.isShiftPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.zIndex
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalTextToolbar
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.Dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.Velocity
import kotlin.math.abs
import com.codespace.ide.ide.codeintel.PythonCompletionItem
import com.codespace.ide.ide.codeintel.PythonDefinitionLocation
import com.codespace.ide.ide.codeintel.PythonHoverDoc
import com.codespace.ide.ide.codeintel.PythonLspController
import com.codespace.ide.ide.codeintel.PythonSignatureInfo
import com.codespace.ide.ide.codeintel.PythonSyntaxDiagnostic
import com.codespace.ide.ide.editor.AnchorMemo
import com.codespace.ide.ide.editor.EditorHoverDocumentationWorkflow
import com.codespace.ide.ide.editor.EditorInteractionPolicy
import com.codespace.ide.ide.editor.EditorPopupPresentation
import com.codespace.ide.ide.editor.EditorPopupPreviewTransform
import com.codespace.ide.ide.editor.FoldedEditorDocument
import com.codespace.ide.ide.editor.GutterRows
import com.codespace.ide.ide.editor.OpenTab
import com.codespace.ide.ide.editor.ZoomAnchor
import com.codespace.ide.ide.editor.lineColAt
import com.codespace.ide.ide.editor.EditorCompletionPopup
import com.codespace.ide.ide.editor.EditorDocumentationBubble
import com.codespace.ide.ide.editor.EditorDocumentationCard
import com.codespace.ide.ide.editor.EditorGutterOverlay
import com.codespace.ide.ide.editor.EditorPopupLayer
import com.codespace.ide.ide.editor.EditorSignatureHelpCard



@Composable
internal fun BoxScope.EditorPopupAndGutterLayers(
    tab: OpenTab,
    foldedDocument: FoldedEditorDocument,
    field: TextFieldValue,
    onFieldChange: (TextFieldValue) -> Unit,
    fontSize: Float,
    textLayout: TextLayoutResult?,
    hoverDoc: PythonHoverDoc?,
    hoverDefinition: PythonDefinitionLocation?,
    hoverAnchorInField: Offset?,
    hoverAnchorOffset: Int?,
    viewportW: Int,
    viewportPx: Int,
    gutterPx: Float,
    sheetShiftX: Float,
    sheetShiftY: Float,
    layerScaleX: Float,
    layerScaleY: Float,
    pinchPivot: Offset,
    gutterVisible: Boolean,
    textPadPx: Float,
    pinchGutterPx: Float,
    caretMemo: AnchorMemo,
    docMemo: AnchorMemo,
    cursorDiagnostic: PythonSyntaxDiagnostic?,
    signatureInfo: PythonSignatureInfo?,
    completionItems: List<PythonCompletionItem>,
    density: Density,
    bottomInsetPx: Float,
    lineHPx: Float,
    showCompletionPopup: Boolean,
    showDocumentationPopup: Boolean,
    docExpanded: Boolean,
    showDiagnosticPopup: Boolean,
    dismissedDiag: PythonSyntaxDiagnostic?,
    effectiveGutterPx: Float,
    hScroll: ScrollState,
    vScroll: ScrollState,
    pinchGestureActive: Boolean,
    zoomCommitInProgress: Boolean,
    zoomAnchor: ZoomAnchor,
    popupHitCoords: HashMap<Int, LayoutCoordinates>,
    applyCompletion: (PythonCompletionItem) -> Unit,
    onCompletionDismiss: () -> Unit,
    hoverWorkflow: EditorHoverDocumentationWorkflow,
    onGoToDefinition: (PythonDefinitionLocation) -> Unit,
    onCloseDocumentation: () -> Unit,
    scope: CoroutineScope,
    tabWidth: Int,
    pythonLspController: PythonLspController?,
    syntaxValidatedSource: String?,
    onSyntaxEditingLineChange: (Int?) -> Unit,
    reportCursor: (Int, Int, Boolean) -> Unit,
    onDiagnosticDismiss: (PythonSyntaxDiagnostic) -> Unit,
    onSignatureDismiss: () -> Unit,
    gutterRows: GutterRows,
    showLines: Boolean,
    codeFontFamily: FontFamily,
    visibleSyntaxDiagnostics: List<PythonSyntaxDiagnostic>,
    breakpointLines: Set<Int>,
    effectiveGutterDp: Dp,
    textMeasurer: TextMeasurer,
    wordWrap: Boolean,
    layerFontRatio: Float,
    gutterFoldSlotDp: Dp,
    onBreakpointToggle: (Int) -> Unit,
    onExpandDocumentation: () -> Unit
) {
    val context = LocalContext.current
    val toast: (String) -> Unit = { message -> Toast.makeText(context, message, Toast.LENGTH_SHORT).show() }

    // ---- Popup layer (suggestions / documentation / diagnostics) ----
    // One layout places all three cards: they live in DOCUMENT
    // coordinates (so they scroll with their caret), are arranged
    // below / above / right / left of the caret according to the free
    // space in the visible code lane, never overlap each other or the
    // caret, and keep their last placement once the caret starts to
    // leave the view (so they leave together with it). The gutter is
    // drawn above this layer, so a card passing behind it goes under
    // the line numbers.
    // While a pinch preview is running the code is only GPU-scaled: the layout (and so
    // every anchor computed from it) still belongs to the OLD font size. Map each
    // anchor through the very same transform as the code layer, so the cards move with
    // the caret / word during the pinch instead of snapping back when the fingers lift.
    // (Card sizes are left alone; only their anchor point follows.)
    val layout = textLayout
    val doc = hoverDoc
    val definition = hoverDefinition
    val anchors = EditorPopupPresentation.resolveAnchors(
        layout = layout,
        foldedDocument = foldedDocument,
        expectedFontSize = fontSize.sp,
        field = field,
        documentationWanted = (doc != null || definition != null) && hoverAnchorInField != null,
        documentationOffset = hoverAnchorOffset,
        viewportWidthPx = viewportW,
        viewportHeightPx = viewportPx,
        gutterWidthPx = gutterPx,
        sheetShiftX = sheetShiftX,
        sheetShiftY = sheetShiftY,
        preview = EditorPopupPreviewTransform(
            scaleX = layerScaleX,
            scaleY = layerScaleY,
            pivotX = pinchPivot.x,
            pivotY = pinchPivot.y,
            gutterVisible = gutterVisible,
            gutterWidthPx = gutterPx,
            textPaddingPx = textPadPx,
            previewGutterPx = pinchGutterPx
        ),
        caretMemo = caretMemo,
        documentationMemo = docMemo
    )
    val caretAnchor = anchors.caret
    val docAnchor = anchors.documentation
    val diagnostic = cursorDiagnostic
    val signature = signatureInfo
    val completionHeightPx = minOf(
        with(density) { 260.dp.toPx() },
        with(density) { (50.dp + (46.dp * completionItems.size.coerceAtMost(5))).toPx() }
    )
    val docWidthDp = if (doc == null && definition != null) 196.dp else 280.dp
    val popupPlan = EditorPopupPresentation.createPlan(
        caretAnchor = caretAnchor,
        documentationAnchor = docAnchor,
        completionRequested = showCompletionPopup && completionItems.isNotEmpty(),
        documentationRequested = showDocumentationPopup,
        hasDocumentation = doc != null,
        hasDefinition = definition != null,
        documentationExpanded = docExpanded,
        diagnosticRequested = showDiagnosticPopup,
        diagnosticDismissed = diagnostic == dismissedDiag,
        hasDiagnostic = diagnostic != null,
        signatureRequested = signature != null,
        completionWidthPx = with(density) { 264.dp.toPx() },
        completionHeightPx = completionHeightPx,
        documentationWidthPx = with(density) { docWidthDp.toPx() },
        documentationHeightPx = minOf(
            with(density) { 180.dp.toPx() },
            (viewportPx - bottomInsetPx).coerceAtLeast(lineHPx) * 0.42f
        ),
        diagnosticWidthPx = with(density) { 292.dp.toPx() },
        diagnosticHeightPx = with(density) { 150.dp.toPx() },
        signatureWidthPx = with(density) { 300.dp.toPx() },
        signatureHeightPx = with(density) { 128.dp.toPx() }
    )
    val completionShown = popupPlan.completionShown
    val docShown = popupPlan.documentationShown
    val bubbleShown = popupPlan.documentationBubbleShown
    val diagShown = popupPlan.diagnosticShown
    val signatureShown = popupPlan.signatureShown
    val specs = popupPlan.specs
    if (anchors.sized && specs.any { it != null }) EditorPopupLayer(
        modifier = Modifier.matchParentSize().zIndex(0.5f),
        specs = specs,
        gapPx = with(density) { 8.dp.toPx() },
        minHeightPx = with(density) { 56.dp.toPx() },
        gutterPx = effectiveGutterPx,
        viewportW = viewportW.toFloat(),
        viewportH = (viewportPx - bottomInsetPx).coerceAtLeast(lineHPx),
        // Effective scroll = scroll minus the pending commit shift (see sheetShift*).
        scrollX = { hScroll.value - sheetShiftX.roundToInt() },
        scrollY = { vScroll.value - sheetShiftY.roundToInt() },
        lockPlacement = pinchGestureActive || zoomCommitInProgress || zoomAnchor.pending ||
            layerScaleX != 1f || layerScaleY != 1f
    ) {
        if (completionShown) {
            EditorCompletionPopup(
                items = completionItems,
                onSelect = { item -> applyCompletion(item) },
                onDismiss = onCompletionDismiss,
                onPositioned = { popupHitCoords[0] = it }
            )
        }
        if (docShown) {
            EditorDocumentationCard(
                documentation = doc,
                definition = definition,
                onGoToDefinition = { target ->
                    hoverWorkflow.clearForNavigation()
                    onGoToDefinition(target)
                },
                onClose = onCloseDocumentation,
                onPositioned = { popupHitCoords[1] = it }
            )
        }
        if (diagShown && diagnostic != null) {
            EditorDiagnosticActions(
                tab = tab,
                diagnostic = diagnostic,
                field = field,
                scope = scope,
                tabWidth = tabWidth,
                pythonLspController = pythonLspController,
                syntaxValidatedSource = syntaxValidatedSource,
                onFieldChange = onFieldChange,
                onSyntaxEditingLineChange = onSyntaxEditingLineChange,
                reportCursor = { line, column -> reportCursor(line, column, true) },
                toast = toast,
                onDismiss = { onDiagnosticDismiss(diagnostic) },
                onPositioned = { popupHitCoords[2] = it }
            )
        }
        if (signatureShown && signature != null) {
            EditorSignatureHelpCard(
                signature = signature,
                onDismiss = onSignatureDismiss,
                onPositioned = { popupHitCoords[3] = it }
            )
        }
    }

    // "i" bubble: a documented word was tapped. Opens the documentation card on tap.
    if (anchors.sized && bubbleShown && docAnchor != null) {
        val bubbleSize = 28.dp
        val bubblePx = with(density) { bubbleSize.toPx() }
        val gapPx = with(density) { 6.dp.toPx() }
        val edgePx = with(density) { 4.dp.toPx() }
        EditorDocumentationBubble(
            position = {
                val minX = hScroll.value - sheetShiftX + gutterPx + edgePx
                val maxX = hScroll.value - sheetShiftX + viewportW - bubblePx - edgePx
                val x = (docAnchor.left - bubblePx / 2f).coerceIn(minX, maxOf(minX, maxX))
                var y = docAnchor.top - bubblePx - gapPx
                if (y < vScroll.value - sheetShiftY) y = docAnchor.bottom + gapPx
                IntOffset(x.roundToInt(), y.roundToInt())
            },
            onPositioned = { popupHitCoords[10] = it },
            onClick = onExpandDocumentation
        )
    }

    if (gutterVisible) {
        EditorGutterOverlay(
            filePath = tab.file.absolutePath,
            foldedDocument = foldedDocument,
            rows = gutterRows,
            showLineNumbers = showLines,
            fontSize = fontSize,
            codeFontFamily = codeFontFamily,
            diagnostics = visibleSyntaxDiagnostics,
            breakpointLines = breakpointLines,
            width = effectiveGutterDp,
            textMeasurer = textMeasurer,
            scrollY = { vScroll.value - sheetShiftY.toInt() },
            viewportHeightPx = { viewportPx },
            pinchScale = { layerScaleY },
            fontRatio = { layerFontRatio },
            pinchPivotY = { pinchPivot.y },
            pinchGutterPx = { pinchGutterPx },
            horizontalTranslation = if (wordWrap) 0f else hScroll.value.toFloat() - sheetShiftX,
            wordWrap = wordWrap,
            foldSlotWidth = gutterFoldSlotDp,
            onLineTap = { sourceLine, foldChevron ->
                if (foldChevron) {
                    val region = foldedDocument.regions.firstOrNull { it.headerLine == sourceLine }
                    if (region != null) {
                        val selectionStartLine = lineColAt(field.text, field.selection.start)[0]
                        val selectionEndLine = lineColAt(field.text, field.selection.end)[0]
                        val decision = EditorInteractionPolicy.toggleFold(
                            currentKeys = tab.collapsedFoldKeys,
                            region = region,
                            selectionStartLine = selectionStartLine,
                            selectionEndLine = selectionEndLine,
                            sourceLength = field.text.length
                        )
                        tab.collapsedFoldKeys = decision.collapsedKeys
                        decision.caretOffsetAfterCollapse?.let { target ->
                            onFieldChange(TextFieldValue(field.text, TextRange(target)))
                            val lc = lineColAt(field.text, target)
                            reportCursor(lc[0], lc[1], false)
                        }
                    }
                } else onBreakpointToggle(sourceLine)
            }
        )
    }
}
