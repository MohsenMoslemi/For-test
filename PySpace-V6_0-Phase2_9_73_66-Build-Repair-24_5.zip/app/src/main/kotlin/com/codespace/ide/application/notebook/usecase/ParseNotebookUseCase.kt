package com.codespace.ide.application.notebook.usecase

import com.codespace.ide.domain.notebook.contract.NotebookParser
import com.codespace.ide.domain.notebook.model.NbDocSnapshot

/** Validates and parses a notebook without creating Compose state. */
class ParseNotebookUseCase(
    private val parser: NotebookParser,
) {
    operator fun invoke(source: String): NbDocSnapshot? = parser.parse(source)
}
