package com.codespace.ide.ide

import java.io.File

/** Supported ARM64 Linux CPython runtimes for project environments. */
data class PythonRuntimeOption(
    val id: String,
    val version: String,
    val title: String,
    val description: String,
    val releaseTag: String? = null,
    val sha256: String? = null,
    val isBundled: Boolean = false,
) {
    val archiveName: String
        get() = "cpython-${version}+${requireNotNull(releaseTag)}-aarch64-unknown-linux-gnu-install_only_stripped.tar.gz"

    val guestHome: String
        get() = if (isBundled) "/usr" else "/opt/pyspace-python/$version"

    val guestExecutable: String
        get() = if (isBundled) "/usr/bin/python3" else "$guestHome/bin/python${version.split('.').take(2).joinToString(".") }"

    val downloadUrl: String
        get() = "https://github.com/astral-sh/python-build-standalone/releases/download/${requireNotNull(releaseTag)}/${archiveName.replace("+", "%2B")}"

}

object PythonRuntimeCatalog {
    const val DEFAULT_ID = "ubuntu-3.12.3"

    // The bundled 3.12 runtime is kept as the zero-download default. Other
    // versions use portable, stripped ARM64 GNU/Linux builds from Astral.
    val options: List<PythonRuntimeOption> = listOf(
        PythonRuntimeOption(
            id = DEFAULT_ID,
            version = "3.12.3",
            title = "Python 3.12.3 · Bundled",
            description = "Ready immediately · Recommended default",
            isBundled = true,
        ),
        PythonRuntimeOption(
            id = "3.11.18",
            version = "3.11.18",
            title = "Python 3.11.18",
            description = "Stable · Broad package compatibility",
            releaseTag = "20261026",
            sha256 = "ecf28575cd67fa7a53c7bf2355bae5cff2c496efeb51780d50a8b54441cdce74",
        ),
        PythonRuntimeOption(
            id = "3.12.16",
            version = "3.12.16",
            title = "Python 3.12.16",
            description = "Latest 3.12 maintenance release",
            releaseTag = "20261026",
            sha256 = "bb4b6392670c5d3f93876996fcaa19858a4a413a0c7720144c18b0d6f1f0db2d",
        ),
        PythonRuntimeOption(
            id = "3.13.18",
            version = "3.13.18",
            title = "Python 3.13.18",
            description = "Modern Python · Some packages may lag behind",
            releaseTag = "20261026",
            sha256 = "578d9da1983463ffb0c8c98ab0da2f18177f44069328eb0af847860c1eb05c3e",
        ),
        PythonRuntimeOption(
            id = "3.14.10",
            version = "3.14.10",
            title = "Python 3.14.10",
            description = "Latest LSP-supported generation · Package compatibility may vary",
            releaseTag = "20261026",
            sha256 = "90f48337bc3dd4ae6eda81e001e4c981236d403b6b5a07778bbdf94ee423dc00",
        ),
        PythonRuntimeOption(
            id = "3.10.22",
            version = "3.10.22",
            title = "Python 3.10.22 · Legacy",
            description = "End-of-life branch · Only for older projects",
            releaseTag = "20261001",
            sha256 = "b25ea453d60a51c381417ed0fbf87fd393c346eb1ab3a138cdfbb86be2a4d8fe",
        ),
    )

    fun find(id: String?): PythonRuntimeOption? = options.firstOrNull { it.id == id }
    fun require(id: String): PythonRuntimeOption {
        val option = find(id) ?: throw IllegalArgumentException("Unsupported Python version: $id")
        if (!option.isBundled) {
            require(option.releaseTag != null && option.sha256?.matches(Regex("[a-fA-F0-9]{64}")) == true) {
                "Python ${option.version} is missing its verified runtime download metadata."
            }
        }
        return option
    }
}

/** Version selected when this project was created; old projects remain on bundled Python. */
fun projectPythonVersionId(projectDir: File): String {
    val stored = try {
        File(projectDir, ".pyspace_python_version").takeIf { it.isFile }?.readText()?.trim()
    } catch (_: Exception) { null }
    return PythonRuntimeCatalog.find(stored)?.id ?: PythonRuntimeCatalog.DEFAULT_ID
}

/** Guest-absolute interpreter used when the project has no virtualenv yet. */
fun projectPythonInterpreterGuestPath(projectDir: File): String =
    PythonRuntimeCatalog.require(projectPythonVersionId(projectDir)).guestExecutable

fun projectPythonVersionTitle(projectDir: File): String =
    PythonRuntimeCatalog.require(projectPythonVersionId(projectDir)).title
