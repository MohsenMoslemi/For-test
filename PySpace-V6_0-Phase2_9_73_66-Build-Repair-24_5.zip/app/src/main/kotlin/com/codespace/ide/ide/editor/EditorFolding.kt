package com.codespace.ide.ide.editor

import com.codespace.ide.ide.theme.IdeTheme

/** A conservative Python def/class folding region. Offsets are in the original source. */
data class EditorFoldRegion(
    val headerLine: Int,
    val endLine: Int,
    val headerEnd: Int,
    val bodyStart: Int,
    val foldEnd: Int,
    /**
     * Stable identity of the region: the chain of enclosing def/class names plus
     * its ordinal among same-named siblings. It deliberately contains NO line
     * number, so editing code above a collapsed region does not re-open it.
     */
    val key: String
)

/** 1..[n]: the visible-line list of a document without folds, in O(1) memory. */
private class IdentityLineList(private val n: Int) : AbstractList<Int>(), RandomAccess {
    override val size: Int get() = n
    override fun get(index: Int): Int {
        if (index < 0 || index >= n) throw IndexOutOfBoundsException("index=$index size=$n")
        return index + 1
    }
    override fun indexOf(element: Int): Int = if (element in 1..n) element - 1 else -1
    override fun contains(element: Int): Boolean = element in 1..n
}

/** Strictly increasing source line numbers backed by a primitive array. */
private class SortedLineList(private val values: IntArray) : AbstractList<Int>(), RandomAccess {
    override val size: Int get() = values.size
    override fun get(index: Int): Int = values[index]
    override fun indexOf(element: Int): Int {
        val i = java.util.Arrays.binarySearch(values, element)
        return if (i >= 0) i else -1
    }
    override fun contains(element: Int): Boolean = indexOf(element) >= 0
}

/**
 * Source-preserving document projection used by the editor's VisualTransformation.
 * Hidden source remains untouched in OpenTab; only its visual projection is folded.
 *
 * Performance contract: building a projection is O(source length) with primitive
 * arrays only, and a document without collapsed regions allocates no offset maps
 * at all ([sourceToDisplay] / [displayToSource] are null = identity).
 */
class FoldedEditorDocument private constructor(
    val source: String,
    val displayText: String,
    val regions: List<EditorFoldRegion>,
    val collapsedKeys: Set<String>,
    private val sourceToDisplay: IntArray?,
    private val displayToSource: IntArray?,
    val visibleSourceLines: List<Int>
) {
    val foldableLines: Set<Int> = regions.mapTo(linkedSetOf()) { it.headerLine }
    val collapsedLines: Set<Int> = regions.filter { it.key in collapsedKeys }.mapTo(linkedSetOf()) { it.headerLine }

    fun toDisplayOffset(sourceOffset: Int): Int {
        val map = sourceToDisplay ?: return sourceOffset.coerceIn(0, displayText.length)
        return map[sourceOffset.coerceIn(0, source.length)].coerceIn(0, displayText.length)
    }

    fun toSourceOffset(displayOffset: Int): Int {
        val map = displayToSource ?: return displayOffset.coerceIn(0, source.length)
        return map[displayOffset.coerceIn(0, displayText.length)].coerceIn(0, source.length)
    }

    fun displayLineIndexForSourceLine(sourceLine: Int): Int {
        val wanted = sourceLine.coerceAtLeast(1)
        val exact = visibleSourceLines.indexOf(wanted)
        if (exact >= 0) return exact
        // Hidden line: the last visible line before it (binary search; the list is increasing).
        var lo = 0
        var hi = visibleSourceLines.size - 1
        var answer = 0
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (visibleSourceLines[mid] < wanted) {
                answer = mid
                lo = mid + 1
            } else {
                hi = mid - 1
            }
        }
        return answer
    }

    fun transformed(annotatedSource: androidx.compose.ui.text.AnnotatedString): androidx.compose.ui.text.input.TransformedText {
        // A keystroke can reach BasicTextField before the parent recomposes the
        // cached fold projection. During that single frame, render the new source
        // unmodified rather than applying stale offsets to a different buffer.
        if (annotatedSource.text != source) {
            return androidx.compose.ui.text.input.TransformedText(
                annotatedSource,
                object : androidx.compose.ui.text.input.OffsetMapping {
                    override fun originalToTransformed(offset: Int) = offset.coerceIn(0, annotatedSource.length)
                    override fun transformedToOriginal(offset: Int) = offset.coerceIn(0, annotatedSource.length)
                }
            )
        }
        if (displayText == source) {
            return androidx.compose.ui.text.input.TransformedText(
                annotatedSource,
                object : androidx.compose.ui.text.input.OffsetMapping {
                    override fun originalToTransformed(offset: Int) = offset.coerceIn(0, source.length)
                    override fun transformedToOriginal(offset: Int) = offset.coerceIn(0, source.length)
                }
            )
        }
        val builder = androidx.compose.ui.text.AnnotatedString.Builder()
        var cursor = 0
        regions.filter { it.key in collapsedKeys }
            .sortedBy { it.headerLine }
            .forEach { region ->
                if (region.headerEnd < cursor || region.bodyStart < cursor) return@forEach
                val keepHeaderNewline = region.foldEnd < source.length || source.endsWith('\n')
                val keptHeaderEnd = if (keepHeaderNewline) region.bodyStart else region.headerEnd
                builder.append(annotatedSource.subSequence(cursor, region.headerEnd))
                builder.pushStyle(androidx.compose.ui.text.SpanStyle(
                    color = androidx.compose.ui.graphics.Color(IdeTheme.TEAL),
                    background = androidx.compose.ui.graphics.Color(IdeTheme.CARD)
                ))
                builder.append("  …")
                builder.pop()
                if (keptHeaderEnd > region.headerEnd) {
                    builder.append(annotatedSource.subSequence(region.headerEnd, keptHeaderEnd))
                }
                cursor = region.foldEnd
            }
        if (cursor < source.length) builder.append(annotatedSource.subSequence(cursor, source.length))
        return androidx.compose.ui.text.input.TransformedText(
            builder.toAnnotatedString(),
            object : androidx.compose.ui.text.input.OffsetMapping {
                override fun originalToTransformed(offset: Int) = toDisplayOffset(offset)
                override fun transformedToOriginal(offset: Int) = toSourceOffset(offset)
            }
        )
    }

    companion object {
        private val HEADER_RE = Regex("^(async\\s+def|def|class)\\s+([A-Za-z_][A-Za-z0-9_]*)\\b")

        private class StackEntry(val indent: Int, val end: Int, val key: String)

        fun build(source: String, collapsedKeys: Set<String>): FoldedEditorDocument {
            val lines = source.split('\n')
            val n = lines.size
            val starts = IntArray(n)
            var offset = 0
            for (index in 0 until n) {
                starts[index] = offset
                offset += lines[index].length + if (index < n - 1) 1 else 0
            }

            // Avoid interpreting def/class-looking text inside triple-quoted strings.
            // codeLines[i] == false means line i STARTS inside a triple-quoted string.
            val codeLines = BooleanArray(n)
            var triple: String? = null
            for (index in 0 until n) {
                val line = lines[index]
                codeLines[index] = triple == null
                var i = 0
                var quote: Char? = null
                var escaped = false
                while (i < line.length) {
                    val c = line[i]
                    val open = triple
                    if (open != null) {
                        if (line.startsWith(open, i)) {
                            triple = null
                            i += 3
                            continue
                        }
                        i++
                        continue
                    }
                    if (quote != null) {
                        if (escaped) escaped = false
                        else if (c == '\\') escaped = true
                        else if (c == quote) quote = null
                        i++
                        continue
                    }
                    if (c == '#') break
                    if ((c == '\'' || c == '"') && line.startsWith(c.toString().repeat(3), i)) {
                        triple = c.toString().repeat(3)
                        i += 3
                        continue
                    }
                    if (c == '\'' || c == '"') quote = c
                    i++
                }
            }

            // Indent width per line (tab = next multiple of 8); -1 for blank / comment-only lines.
            val lineIndent = IntArray(n)
            for (index in 0 until n) {
                val line = lines[index]
                var width = 0
                var j = 0
                while (j < line.length) {
                    val ch = line[j]
                    if (ch == ' ') width++
                    else if (ch == '\t') width = ((width / 8) + 1) * 8
                    else break
                    j++
                }
                var k = j
                while (k < line.length && line[k].isWhitespace()) k++
                lineIndent[index] = if (k >= line.length || line[k] == '#') -1 else width
            }

            val regions = ArrayList<EditorFoldRegion>()
            val stack = ArrayList<StackEntry>()
            val ordinals = HashMap<String, Int>()
            for (index in 0 until n) {
                if (!codeLines[index]) continue
                val indent = lineIndent[index]
                if (indent < 0) continue
                val line = lines[index]
                var j = 0
                while (j < line.length && (line[j] == ' ' || line[j] == '\t')) j++
                if (j >= line.length) continue
                val first = line[j]
                // Cheap reject before touching the regex: 99% of lines end here.
                if (first != 'd' && first != 'c' && first != 'a') continue
                val match = HEADER_RE.find(if (j == 0) line else line.substring(j)) ?: continue
                val kind = if (match.groupValues[1].startsWith("class")) "class" else "def"
                val name = match.groupValues[2]

                // Support both one-line and parenthesized multi-line signatures.
                var headerClose = index
                var parenDepth = 0
                var signatureClosed = false
                val headerLimit = minOf(n - 1, index + 32)
                for (candidate in index..headerLimit) {
                    val code = lines[candidate].substringBefore('#')
                    var quote: Char? = null
                    var escaped = false
                    for (ch in code) {
                        if (quote != null) {
                            if (escaped) escaped = false
                            else if (ch == '\\') escaped = true
                            else if (ch == quote) quote = null
                        } else if (ch == '\'' || ch == '"') quote = ch
                        else if (ch == '(') parenDepth++
                        else if (ch == ')') parenDepth--
                    }
                    if (parenDepth <= 0 && code.trimEnd().endsWith(':')) {
                        headerClose = candidate
                        signatureClosed = true
                        break
                    }
                }
                if (!signatureClosed) continue

                var lastBody = -1
                var c = headerClose + 1
                while (c < n) {
                    // A line that starts inside a multi-line string belongs to the
                    // statement that opened it, which is already part of the body.
                    if (!codeLines[c]) {
                        lastBody = c
                        c++
                        continue
                    }
                    val width = lineIndent[c]
                    if (width < 0) {
                        c++
                        continue
                    }
                    if (width <= indent) break
                    lastBody = c
                    c++
                }
                if (lastBody <= headerClose) continue

                val headerEnd = starts[headerClose] + lines[headerClose].length
                val bodyStart = if (headerClose < n - 1) headerEnd + 1 else headerEnd
                val foldEnd = if (lastBody < n - 1) starts[lastBody + 1] else source.length

                while (stack.isNotEmpty() && (stack[stack.lastIndex].end < index || stack[stack.lastIndex].indent >= indent)) {
                    stack.removeAt(stack.lastIndex)
                }
                val parentKey = if (stack.isEmpty()) "" else stack[stack.lastIndex].key
                val base = "$parentKey/$kind $name"
                val ordinal = (ordinals[base] ?: 0) + 1
                ordinals[base] = ordinal
                val key = "$base#$ordinal"
                regions += EditorFoldRegion(index + 1, lastBody + 1, headerEnd, bodyStart, foldEnd, key)
                stack += StackEntry(indent, lastBody, key)
            }

            // Apply only outermost collapsed ranges. Nested fold markers remain available
            // after the parent is expanded, and offsets stay monotonic.
            val applied = ArrayList<EditorFoldRegion>()
            if (collapsedKeys.isNotEmpty()) {
                var coveredUntil = -1
                regions.filter { it.key in collapsedKeys }.sortedBy { it.bodyStart }.forEach { region ->
                    if (region.bodyStart >= coveredUntil) {
                        applied += region
                        coveredUntil = region.foldEnd
                    }
                }
            }

            // Fast path (the common case): nothing collapsed -> identity projection.
            if (applied.isEmpty()) {
                return FoldedEditorDocument(source, source, regions, collapsedKeys, null, null, IdentityLineList(n))
            }

            val output = StringBuilder(source.length + 3 * applied.size)
            val s2d = IntArray(source.length + 1)
            val d2s = IntArray(source.length + 3 * applied.size + 2)
            var dn = 0
            d2s[dn++] = 0
            fun appendSource(start: Int, end: Int) {
                for (i in start until end) {
                    s2d[i] = output.length
                    output.append(source[i])
                    d2s[dn++] = i + 1
                }
                s2d[end] = output.length
            }
            var cursor = 0
            applied.forEach { region ->
                if (region.headerEnd < cursor || region.bodyStart < cursor) return@forEach
                appendSource(cursor, region.headerEnd)
                output.append("  …")
                repeat(3) { d2s[dn++] = region.headerEnd }
                val keepHeaderNewline = region.foldEnd < source.length || source.endsWith('\n')
                val keptHeaderEnd = if (keepHeaderNewline) region.bodyStart else region.headerEnd
                if (keptHeaderEnd > region.headerEnd) appendSource(region.headerEnd, keptHeaderEnd)
                val mapped = output.length
                s2d[region.headerEnd] = mapped
                d2s[dn - 1] = region.foldEnd
                for (i in keptHeaderEnd..region.foldEnd) s2d[i.coerceIn(0, source.length)] = mapped
                cursor = region.foldEnd
                // Keep the source-to-display map monotonic across the hidden range.
                if (cursor < source.length) s2d[cursor] = mapped
            }
            appendSource(cursor, source.length)
            s2d[source.length] = output.length
            while (dn < output.length + 1) d2s[dn++] = source.length
            val displayToSource = if (dn == output.length + 1) d2s else d2s.copyOf(output.length + 1)

            val display = output.toString()
            var displayLineCount = 1
            for (ch in display) if (ch == '\n') displayLineCount++
            val visible = IntArray(displayLineCount)
            var vi = 0
            var displayOffset = 0
            var scannedSourceOffset = 0
            var sourceLineNumber = 1
            while (displayOffset <= display.length && vi < displayLineCount) {
                val sourceOffset = displayToSource[displayOffset.coerceIn(0, displayToSource.lastIndex)].coerceIn(0, source.length)
                while (scannedSourceOffset < sourceOffset) {
                    if (source[scannedSourceOffset] == '\n') sourceLineNumber++
                    scannedSourceOffset++
                }
                visible[vi++] = sourceLineNumber
                val next = display.indexOf('\n', displayOffset)
                if (next < 0) break
                displayOffset = next + 1
            }
            val visibleLines = if (vi == visible.size) visible else visible.copyOf(vi)
            return FoldedEditorDocument(source, display, regions, collapsedKeys, s2d, displayToSource, SortedLineList(visibleLines))
        }
    }
}
