package com.codespace.ide.ide.presentation

import android.content.Context
import androidx.activity.ComponentActivity
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.lifecycle.ViewModelProvider
import com.codespace.ide.di.AppDependencies
import java.io.File
import com.codespace.ide.ide.ProjectViewModelStoreRegistry
import com.codespace.ide.ide.projects.ProjectsViewModel
import com.codespace.ide.ide.runtimeui.RuntimeUiViewModel
import com.codespace.ide.ide.settings.SettingsViewModel

/**
 * Activity-scoped state owners required by the IDE root.
 *
 * This is presentation wiring only: feature state and business operations stay
 * in their respective ViewModels/repositories. Keeping provider construction
 * here prevents the root screen from becoming a second dependency container.
 */
data class IdeRootViewModels(
    val projectStores: ProjectViewModelStoreRegistry,
    val projects: ProjectsViewModel,
    val settings: SettingsViewModel,
    val runtimeUi: RuntimeUiViewModel,
)

@Composable
fun rememberIdeRootViewModels(
    activity: ComponentActivity?,
    workspace: File,
    appContext: Context,
    dependencies: AppDependencies,
): IdeRootViewModels {
    val owner = checkNotNull(activity) {
        "IdeRoot must be hosted by a ComponentActivity."
    }

    val projectStores = remember(owner) {
        ViewModelProvider(owner)[ProjectViewModelStoreRegistry::class.java]
    }
    val projects = remember(owner, workspace, appContext, dependencies.projectRepository) {
        ViewModelProvider(
            owner,
            ProjectsViewModel.Factory(
                workspace,
                appContext,
                dependencies.projectRepository,
            ),
        )[ProjectsViewModel::class.java]
    }
    val settings = remember(owner, dependencies.settingsRepository) {
        ViewModelProvider(
            owner,
            SettingsViewModel.Factory(dependencies.settingsRepository),
        )[SettingsViewModel::class.java]
    }
    val runtimeUi = remember(owner) {
        ViewModelProvider(owner, RuntimeUiViewModel.Factory())[RuntimeUiViewModel::class.java]
    }

    return IdeRootViewModels(
        projectStores = projectStores,
        projects = projects,
        settings = settings,
        runtimeUi = runtimeUi,
    )
}
