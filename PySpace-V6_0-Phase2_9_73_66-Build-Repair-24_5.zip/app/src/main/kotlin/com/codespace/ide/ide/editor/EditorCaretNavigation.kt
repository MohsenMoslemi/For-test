package com.codespace.ide.ide.editor

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.State
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlin.math.abs

/** Immutable live snapshot consumed by caret-navigation coroutines. */
internal data class EditorCaretNavigationSnapshot(
    val layout: State<TextLayoutResult?>,
    val field: State<TextFieldValue>,
    val document: State<FoldedEditorDocument>,
    val lineRows: State<List<Int>>,
    val visualRowPrefix: IntArray?,
    val caretLine: Int,
    val viewportHeight: Float,
    val viewportWidth: Int,
    val bottomInset: Float,
    val lineHeight: Float,
    val textPadding: Float,
    val gutterWidth: Float,
    val handleReach: Float,
    val handleMargin: Float,
    val wordWrap: Boolean,
    val density: Density,
    val verticalScroll: ScrollState,
    val horizontalScroll: ScrollState
)

/**
 * Owns the scroll-target workflow for caret reveal and explicit caret centering.
 * It receives snapshots and scroll handles; document, selection and IME state
 * remain owned by PyEditor.
 */
internal object EditorCaretNavigation {
    private fun topRowOf(line: Int, snapshot: EditorCaretNavigationSnapshot): Int {
        val displayIndex = snapshot.document.value.displayLineIndexForSourceLine(line)
        return EditorDerivedState.firstVisualRow(displayIndex, snapshot.visualRowPrefix)
    }

    private suspend fun currentCaretRect(snapshot: EditorCaretNavigationSnapshot): androidx.compose.ui.geometry.Rect? {
        if (snapshot.viewportHeight <= 0 || snapshot.viewportWidth <= 0) return null
        var attempts = 0
        while (attempts < 3) {
            val layout = snapshot.layout.value
            if (layout != null && sameDisplay(layout.layoutInput.text.text, snapshot.document.value.displayText)) break
            withFrameNanos { }
            attempts++
        }
        val layout = snapshot.layout.value
        val field = snapshot.field.value
        val document = snapshot.document.value
        return if (layout != null && sameDisplay(layout.layoutInput.text.text, document.displayText) &&
            field.selection.end in 0..field.text.length
        ) layout.getCursorRect(document.toDisplayOffset(field.selection.end)) else null
    }

    suspend fun reveal(
        snapshot: EditorCaretNavigationSnapshot,
        line: Int,
        center: Boolean = false
    ) {
        if (snapshot.viewportHeight <= 0 || snapshot.viewportWidth <= 0) return
        currentCaretRect(snapshot)
        // Include any layout-driven scroll-range update before calculating targets.
        withFrameNanos { }
        val layout = snapshot.layout.value
        val field = snapshot.field.value
        val document = snapshot.document.value
        val rect = if (layout != null && sameDisplay(layout.layoutInput.text.text, document.displayText) &&
            field.selection.end in 0..field.text.length
        ) layout.getCursorRect(document.toDisplayOffset(field.selection.end)) else null
        val visibleHeight = (snapshot.viewportHeight - snapshot.bottomInset).coerceAtLeast(snapshot.lineHeight)
        val caretTop: Float
        val caretBottom: Float
        if (rect != null) {
            caretTop = snapshot.textPadding + rect.top
            caretBottom = snapshot.textPadding + rect.bottom
        } else {
            val startRow = topRowOf(line, snapshot)
            val displayIndex = snapshot.document.value.displayLineIndexForSourceLine(line)
            val rows = snapshot.lineRows.value.getOrElse(displayIndex) { 1 }
            caretTop = snapshot.textPadding + startRow * snapshot.lineHeight
            caretBottom = snapshot.textPadding + (startRow + rows) * snapshot.lineHeight
        }
        val vertical = snapshot.verticalScroll
        val horizontal = snapshot.horizontalScroll
        val verticalTarget = EditorCaretViewport.revealVerticalTarget(
            current = vertical.value,
            max = vertical.maxValue,
            caretTop = caretTop,
            caretBottom = caretBottom,
            visibleHeight = visibleHeight,
            lineHeight = snapshot.lineHeight,
            handleReach = snapshot.handleReach,
            handleMargin = snapshot.handleMargin,
            center = center
        )
        var horizontalTarget = horizontal.value
        if (!snapshot.wordWrap && rect != null) {
            val caretX = snapshot.gutterWidth + snapshot.textPadding + rect.left
            val margin = with(snapshot.density) { 40.dp.toPx() }
            horizontalTarget = EditorCaretViewport.revealHorizontalTarget(
                current = horizontal.value,
                max = horizontal.maxValue,
                caretX = caretX,
                gutter = snapshot.gutterWidth,
                viewportWidth = snapshot.viewportWidth.toFloat(),
                margin = margin
            )
        }
        if (verticalTarget != vertical.value) vertical.animateScrollTo(verticalTarget)
        if (horizontalTarget != horizontal.value) horizontal.animateScrollTo(horizontalTarget)
    }

    suspend fun center(snapshot: EditorCaretNavigationSnapshot) {
        if (snapshot.viewportHeight <= 0 || snapshot.viewportWidth <= 0) return
        val rect = currentCaretRect(snapshot)
        val visibleHeight = (snapshot.viewportHeight - snapshot.bottomInset).coerceAtLeast(snapshot.lineHeight)
        val caretTop: Float
        val caretBottom: Float
        if (rect != null) {
            caretTop = snapshot.textPadding + rect.top
            caretBottom = snapshot.textPadding + rect.bottom
        } else {
            caretTop = snapshot.textPadding + topRowOf(snapshot.caretLine, snapshot) * snapshot.lineHeight
            caretBottom = caretTop + snapshot.lineHeight
        }
        val vertical = snapshot.verticalScroll
        val horizontal = snapshot.horizontalScroll
        val verticalTarget = EditorCaretViewport.centeredVerticalTarget(
            caretTop = caretTop,
            caretBottom = caretBottom,
            visibleHeight = visibleHeight,
            max = vertical.maxValue
        )
        var horizontalTarget = horizontal.value
        if (!snapshot.wordWrap && rect != null) {
            val caretX = snapshot.gutterWidth + snapshot.textPadding + rect.left
            val margin = with(snapshot.density) { 24.dp.toPx() }
            horizontalTarget = EditorCaretViewport.centeredHorizontalTarget(
                current = horizontal.value,
                max = horizontal.maxValue,
                caretX = caretX,
                gutter = snapshot.gutterWidth,
                viewportWidth = snapshot.viewportWidth.toFloat(),
                margin = margin
            )
        }
        val distanceDp = abs(verticalTarget - vertical.value) / snapshot.density.density
        val duration = (220f + distanceDp * 0.2f).toInt().coerceIn(260, 520)
        val spec = tween<Float>(durationMillis = duration, easing = FastOutSlowInEasing)
        coroutineScope {
            if (verticalTarget != vertical.value) launch { vertical.animateScrollTo(verticalTarget, spec) }
            if (horizontalTarget != horizontal.value) launch { horizontal.animateScrollTo(horizontalTarget, spec) }
        }
    }
}
