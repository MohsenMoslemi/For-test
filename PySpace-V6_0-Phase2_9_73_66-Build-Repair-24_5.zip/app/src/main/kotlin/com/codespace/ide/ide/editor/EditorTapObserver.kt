package com.codespace.ide.ide.editor

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Observes editor-surface taps without competing with BasicTextField's native
 * caret placement or long-press selection recognizer. The editor remains the
 * owner of document/selection state; this modifier only resolves the fallback
 * caret target and delegates the resulting actions.
 */
internal fun Modifier.editorTapObserver(
    filePath: String,
    fieldText: String,
    scope: CoroutineScope,
    density: Density,
    latestFieldValue: () -> TextFieldValue,
    latestFieldHasFocus: () -> Boolean,
    latestTextLayout: () -> TextLayoutResult?,
    latestFieldCoordinates: () -> LayoutCoordinates?,
    latestGestureCoordinates: () -> LayoutCoordinates?,
    foldedDocument: () -> FoldedEditorDocument,
    setFirstTapPending: (Boolean) -> Unit,
    setHoverTapInProgress: (Boolean) -> Unit,
    tapIsOnPopup: (Offset, LayoutCoordinates) -> Boolean,
    placeCaret: (sourceText: String, offset: Int) -> Unit,
    reportCursor: (line: Int, column: Int) -> Unit,
    showHoverDocumentation: (Offset) -> Unit
): Modifier = pointerInput(filePath, fieldText) {
    awaitEachGesture {
        // Observe taps in Initial pass without consuming anything. BasicTextField
        // remains in charge of caret placement and native selection UI.
        val down = awaitFirstDown(
            requireUnconsumed = false,
            pass = PointerEventPass.Initial
        )
        val wasFocusedAtDown = latestFieldHasFocus()
        if (!wasFocusedAtDown) setFirstTapPending(true)
        setHoverTapInProgress(true)
        var completed = false
        try {
            var moved = false
            var released = false
            var releaseTime = down.uptimeMillis
            while (!released) {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                val change = event.changes.firstOrNull { it.id == down.id }
                if (change == null) {
                    released = true
                    continue
                }
                if (change.pressed) {
                    if ((change.position - down.position).getDistance() > viewConfiguration.touchSlop ||
                        event.changes.count { it.pressed } > 1
                    ) moved = true
                } else {
                    releaseTime = change.uptimeMillis
                    released = true
                }
            }

            val pressDuration = releaseTime - down.uptimeMillis
            if (!moved && pressDuration < viewConfiguration.longPressTimeoutMillis) {
                // Allow the field's recognizer to run first; resolve a fallback
                // only if this initial tap merely focused the field.
                val sourceAtDown = latestFieldValue().text
                scope.launch {
                    delay(80)
                    val current = latestFieldValue()
                    val layoutAtTap = latestTextLayout()
                    val fieldCoords = latestFieldCoordinates()
                    val gestureCoords = latestGestureCoordinates()
                    val document = foldedDocument()
                    if (!wasFocusedAtDown && current.text == sourceAtDown &&
                        layoutAtTap != null &&
                        sameDisplay(layoutAtTap.layoutInput.text.text, document.displayText) &&
                        fieldCoords != null && fieldCoords.isAttached &&
                        gestureCoords != null && gestureCoords.isAttached
                    ) {
                        val local = fieldCoords.localPositionOf(gestureCoords, down.position)
                        val pad = with(density) { 8.dp.toPx() }
                        val textPosition = Offset(local.x - pad, local.y - pad)
                        if (textPosition.x >= 0f && textPosition.y >= 0f &&
                            textPosition.y <= layoutAtTap.size.height.toFloat()
                        ) {
                            val line = layoutAtTap.getLineForVerticalPosition(textPosition.y)
                            if (textPosition.x <= layoutAtTap.getLineRight(line) + with(density) { 4.dp.toPx() }) {
                                val displayOffset = layoutAtTap.getOffsetForPosition(textPosition)
                                    .coerceIn(0, document.displayText.length)
                                val offset = document.toSourceOffset(displayOffset)
                                if (offset != current.selection.start || !current.selection.collapsed) {
                                    placeCaret(sourceAtDown, offset)
                                }
                                val lc = lineColAt(sourceAtDown, offset)
                                reportCursor(lc[0], lc[1])
                            }
                        }
                    }
                    setFirstTapPending(false)
                }
                val gcForPopup = latestGestureCoordinates()
                if (gcForPopup == null || !gcForPopup.isAttached || !tapIsOnPopup(down.position, gcForPopup)) {
                    showHoverDocumentation(down.position)
                }
            } else if (!wasFocusedAtDown) {
                setFirstTapPending(false)
            }
            completed = true
            // Let BasicTextField process UP and update its selection before
            // selection changes are allowed to dismiss documentation cards.
            scope.launch {
                delay(180)
                setHoverTapInProgress(false)
            }
        } finally {
            if (!completed) {
                setHoverTapInProgress(false)
                setFirstTapPending(false)
            }
        }
    }
}
