package com.codespace.ide.ide.codeintel

/**
 * Lightweight, conservative type analysis implemented entirely in Kotlin.
 *
 * This is deliberately a supplemental checker: it reports only mismatches for
 * which the source provides reliable type information. It does not execute
 * Python, inspect the Ubuntu runtime, or replace the existing LSP diagnostics.
 */
internal object KotlinPythonTypeChecker {
    private data class Parameter(val name: String, val type: String, val hasDefault: Boolean)
    private data class FunctionInfo(val name: String, val parameters: List<Parameter>, val line: Int)
    private data class VariableInfo(val type: String, val line: Int, val explicitlyDeclared: Boolean = false)

    private val functionPattern = Regex("^\\s*(?:async\\s+)?def\\s+([A-Za-z_]\\w*)\\s*\\((.*)\\)\\s*(?:->\\s*([^:]+))?:")
    private val annotatedAssignment = Regex("^\\s*([A-Za-z_]\\w*)\\s*:\\s*([^=]+?)\\s*=\\s*(.+?)\\s*$")
    private val assignment = Regex("^\\s*([A-Za-z_]\\w*)\\s*=\\s*(.+?)\\s*$")
    private val callPattern = Regex("([A-Za-z_]\\w*(?:\\.[A-Za-z_]\\w*)*)\\s*\\((.*)\\)")

    fun analyze(source: String): List<PythonSyntaxDiagnostic> {
        if (source.length > MAX_SOURCE_CHARS) return emptyList()
        val lines = source.split('\n')
        val codeLines = maskStringsAndComments(source).split('\n')
        val functions = LinkedHashMap<String, FunctionInfo>()
        val variables = LinkedHashMap<String, VariableInfo>()
        val diagnostics = ArrayList<PythonSyntaxDiagnostic>()
        val seen = HashSet<String>()
        val importedModules = HashSet<String>()

        fun report(line: Int, column: Int, endColumn: Int, message: String, code: String) {
            val key = "$line:$column:$code:$message"
            if (seen.add(key)) diagnostics += PythonSyntaxDiagnostic(
                line = line, column = column.coerceAtLeast(1),
                endLine = line, endColumn = endColumn.coerceAtLeast(column + 1),
                message = message, kind = "Error", code = code
            )
        }

        // Pass 1: collect imports, function signatures, and explicit/inferred names.
        lines.forEachIndexed { index, raw ->
            val lineNo = index + 1
            val clean = codeLines.getOrNull(index).orEmpty().trim()
            if (clean.isEmpty()) return@forEachIndexed
            Regex("^(?:import|from)\\s+([A-Za-z_]\\w*)").find(clean)?.let {
                importedModules += it.groupValues[1]
            }
            val function = functionPattern.find(raw)
            if (function != null) {
                val params = splitArguments(function.groupValues[2]).mapNotNull { token ->
                    val part = token.trim().removePrefix("*").removePrefix("*")
                    val name = part.substringBefore(':').substringBefore('=').trim()
                    if (!IDENTIFIER.matches(name)) return@mapNotNull null
                    val annotation = part.substringAfter(':', "").substringBefore('=').trim()
                    if (annotation.isBlank()) null else Parameter(
                        name = name,
                        type = normalizeType(annotation),
                        hasDefault = '=' in part
                    )
                }
                functions[function.groupValues[1]] = FunctionInfo(function.groupValues[1], params, lineNo)
            }
            val annotated = annotatedAssignment.find(raw)
            if (annotated != null) {
                val name = annotated.groupValues[1]
                val type = normalizeType(annotated.groupValues[2])
                val actual = inferExpressionType(annotated.groupValues[3], variables)
                variables[name] = VariableInfo(type, lineNo, explicitlyDeclared = true)
                if (actual != null && !isCompatible(type, actual)) {
                    val col = raw.indexOf(name).coerceAtLeast(0) + 1
                    report(lineNo, col, col + name.length,
                        "Incompatible assignment: expected '$type', received '$actual'.", "PYSPACE-TYPE-ASSIGN")
                }
            } else {
                val match = assignment.find(raw)
                if (match != null && !raw.trimStart().startsWith("#")) {
                    val name = match.groupValues[1]
                    inferExpressionType(match.groupValues[2], variables)?.let { inferred ->
                        // Keep explicit annotations authoritative, but update inferred
                        // types on reassignment. This is essential for ordinary control
                        // flow such as `value = None` followed by `value = Path(...)`.
                        // The previous implementation kept the first inferred type forever,
                        // producing stale `None` diagnostics after a valid reassignment.
                        val previous = variables[name]
                        if (previous == null || !previous.explicitlyDeclared) {
                            variables[name] = VariableInfo(inferred, lineNo)
                        }
                    }
                }
            }
        }

        // Pass 2: validate calls against annotated user functions and selected stdlib APIs.
        lines.forEachIndexed { index, raw ->
            val lineNo = index + 1
            val clean = codeLines.getOrNull(index).orEmpty()
            if (clean.isBlank()) return@forEachIndexed
            // Avoid interpreting function declarations as calls.
            if (functionPattern.containsMatchIn(raw)) return@forEachIndexed
            callPattern.findAll(clean).forEach { call ->
                val fullName = call.groupValues[1]
                val shortName = fullName.substringAfterLast('.')
                val params = functions[shortName]?.parameters
                    ?: standardLibraryParameters(fullName, importedModules)
                    ?: return@forEach
                val argumentRange = call.groups[2]?.range ?: return@forEach
                val originalArguments = raw.substring(argumentRange.first, argumentRange.last + 1)
                val args = splitArguments(originalArguments)
                val positional = params.filterNot { it.name.startsWith("*") }
                args.forEachIndexed argLoop@{ argIndex, rawArg ->
                    val arg = rawArg.trim()
                    if (arg.isEmpty() || arg.startsWith("*") || '=' in arg.takeWhile { it != '\'' && it != '"' }) return@argLoop
                    val parameter = positional.getOrNull(argIndex) ?: return@argLoop
                    val actual = inferExpressionType(arg, variables) ?: return@argLoop
                    if (!isCompatible(parameter.type, actual)) {
                        val argStart = argumentRange.first
                        val relative = originalArguments.indexOf(rawArg).coerceAtLeast(0)
                        val column = argStart + relative + 1
                        report(lineNo, column, column + rawArg.length,
                            "Argument '${parameter.name}' expects '${parameter.type}', received '$actual'.",
                            "PYSPACE-TYPE-ARGUMENT")
                    }
                }
            }
        }

        return diagnostics.sortedWith(compareBy<PythonSyntaxDiagnostic> { it.line }.thenBy { it.column })
    }

    private fun standardLibraryParameters(name: String, imports: Set<String>): List<Parameter>? = when (name) {
        "time.sleep" -> if ("time" in imports) listOf(Parameter("secs", "float", false)) else null
        "asyncio.sleep" -> if ("asyncio" in imports) listOf(Parameter("delay", "float", false)) else null
        "sleep" -> if ("time" in imports || "asyncio" in imports) listOf(Parameter("secs", "float", false)) else null
        "math.sqrt" -> if ("math" in imports) listOf(Parameter("x", "float", false)) else null
        "sqrt" -> if ("math" in imports) listOf(Parameter("x", "float", false)) else null
        "len" -> listOf(Parameter("obj", "sized", false))
        "int" -> listOf(Parameter("x", "convertible", true))
        "float" -> listOf(Parameter("x", "convertible", true))
        "str" -> listOf(Parameter("object", "any", true))
        "range" -> listOf(Parameter("start", "int", false), Parameter("stop", "int", true), Parameter("step", "int", true))
        else -> null
    }

    private fun inferExpressionType(expression: String, variables: Map<String, VariableInfo>): String? {
        val value = expression.trim().removeSurrounding("(", ")").trim()
        if (value.isEmpty()) return null
        if (value == "True" || value == "False") return "bool"
        if (value == "None") return "None"
        // Common path constructors used by pathlib-based scripts.
        val constructor = Regex("^(Path|PurePath|PurePosixPath|PureWindowsPath|PosixPath|WindowsPath)\\s*\\(").find(value)
        if (constructor != null) return "Path"
        if ((value.startsWith("\"") && value.endsWith("\"")) || (value.startsWith("'") && value.endsWith("'"))) return "str"
        if (value.startsWith("[")) return "list"
        if (value.startsWith("{")) return "dict"
        if (value.startsWith("(")) return "tuple"
        if (INTEGER.matches(value)) return "int"
        if (FLOAT.matches(value)) return "float"
        if (IDENTIFIER.matches(value)) return variables[value]?.type
        val arithmetic = Regex("^([A-Za-z_]\\w*|[-+]?\\d+(?:\\.\\d+)?)\\s*([+*/%-])\\s*([A-Za-z_]\\w*|[-+]?\\d+(?:\\.\\d+)?)$").matchEntire(value)
        if (arithmetic != null) {
            val left = inferExpressionType(arithmetic.groupValues[1], variables) ?: return null
            val right = inferExpressionType(arithmetic.groupValues[3], variables) ?: return null
            if (arithmetic.groupValues[2] == "+" && left == "str" && right == "str") return "str"
            if (left in NUMERIC && right in NUMERIC) return if ("float" in setOf(left, right) || arithmetic.groupValues[2] == "/") "float" else "int"
        }
        return null
    }

    private fun normalizeType(raw: String): String {
        val value = raw.trim().removePrefix("typing.")
        return when (value) {
            "Any", "object" -> "any"
            "str", "int", "float", "bool", "bytes", "None", "list", "dict", "tuple", "set" -> value
            else -> when {
                value.startsWith("Optional[") -> value.substringAfter('[').substringBefore(']').trim() + "?"
                value.startsWith("List[") -> "list"
                value.startsWith("Dict[") -> "dict"
                value.startsWith("Tuple[") -> "tuple"
                value.startsWith("Set[") -> "set"
                else -> value.substringBefore('[').substringBefore('|').trim()
            }
        }
    }

    private fun isCompatible(expected: String, actual: String): Boolean {
        if (expected == "any" || expected == "convertible") return true
        if (expected == "sized") return actual in setOf("str", "list", "dict", "tuple", "set", "bytes")
        if (expected.endsWith("?")) return actual == "None" || isCompatible(expected.removeSuffix("?"), actual)
        if (expected == actual) return true
        // Python bool is an int subtype; int is accepted where float is expected.
        if (expected == "int" && actual == "bool") return true
        if (expected == "float" && actual in setOf("int", "bool")) return true
        return false
    }

    private fun splitArguments(text: String): List<String> {
        if (text.isBlank()) return emptyList()
        val parts = ArrayList<String>()
        var start = 0
        var depth = 0
        var quote: Char? = null
        var escaped = false
        text.forEachIndexed { index, char ->
            if (quote != null) {
                if (escaped) escaped = false
                else if (char == '\\') escaped = true
                else if (char == quote) quote = null
            } else when (char) {
                '\'', '"' -> quote = char
                '(', '[', '{' -> depth++
                ')', ']', '}' -> depth = (depth - 1).coerceAtLeast(0)
                ',' -> if (depth == 0) { parts += text.substring(start, index); start = index + 1 }
            }
        }
        parts += text.substring(start)
        return parts
    }

    /** Masks comments and string contents without changing source offsets. */
    private fun maskStringsAndComments(source: String): String {
        val out = StringBuilder(source.length)
        var quote: Char? = null
        var triple = false
        var escaped = false
        var comment = false
        var index = 0
        while (index < source.length) {
            val char = source[index]
            if (char == '\n') {
                out.append('\n')
                comment = false
                escaped = false
                if (quote != null && !triple) quote = null
                index++
                continue
            }
            if (comment) {
                out.append(' ')
                index++
                continue
            }
            if (quote != null) {
                val closesTriple = triple && index + 2 < source.length && source[index] == quote && source[index + 1] == quote && source[index + 2] == quote
                if (closesTriple && !escaped) {
                    out.append("   ")
                    index += 3
                    quote = null
                    triple = false
                    continue
                }
                out.append(' ')
                if (!triple) {
                    if (escaped) escaped = false
                    else if (char == '\\') escaped = true
                    else if (char == quote) quote = null
                }
                index++
                continue
            }
            if (char == '#') {
                comment = true
                out.append(' ')
                index++
                continue
            }
            if (char == '\'' || char == '"') {
                val isTriple = index + 2 < source.length && source[index + 1] == char && source[index + 2] == char
                quote = char
                triple = isTriple
                out.append(if (isTriple) "   " else " ")
                index += if (isTriple) 3 else 1
                continue
            }
            out.append(char)
            index++
        }
        return out.toString()
    }

    private val IDENTIFIER = Regex("[A-Za-z_]\\w*")
    private val INTEGER = Regex("[-+]?\\d+")
    private val FLOAT = Regex("[-+]?(?:\\d+\\.\\d*|\\.\\d+)(?:[eE][-+]?\\d+)?")
    private val NUMERIC = setOf("int", "float", "bool")
    private const val MAX_SOURCE_CHARS = 200_000
}
