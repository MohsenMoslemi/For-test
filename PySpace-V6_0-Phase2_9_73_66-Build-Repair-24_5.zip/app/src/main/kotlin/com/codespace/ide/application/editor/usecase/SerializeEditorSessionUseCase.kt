package com.codespace.ide.application.editor.usecase

import com.codespace.ide.domain.editor.contract.EditorSessionSerializer
import com.codespace.ide.domain.editor.model.EditorSessionSnapshot

/** Converts a detached editor session into its persistence representation. */
class SerializeEditorSessionUseCase(
    private val serializer: EditorSessionSerializer,
) {
    operator fun invoke(snapshot: EditorSessionSnapshot): String = serializer.serialize(snapshot)
}
