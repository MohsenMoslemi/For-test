package com.codespace.ide.ide.terminal

import com.codespace.ide.TerminalSession
import kotlinx.coroutines.CoroutineScope
import com.codespace.ide.runtime.RuntimeDispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** Observable state for one composition-owned terminal surface. */
data class TerminalUiState(
    val starting: Boolean = false,
    val running: Boolean = false,
    val lastExitCode: Int? = null,
    val error: String? = null,
)

/**
 * MVVM state holder for one terminal surface.
 *
 * The surface can be embedded more than once (for example an IDE panel and a
 * standalone terminal), therefore it is deliberately instance-scoped rather
 * than a process singleton. close() is called from DisposableEffect and
 * cancels its scope as well as the native process group.
 */
class TerminalViewModel(
    private val repository: TerminalRepository,
    private val dispatchers: RuntimeDispatchers = RuntimeDispatchers.Default,
) {
    private val scope = CoroutineScope(SupervisorJob() + dispatchers.main)
    private val sendMutex = Mutex()
    private var startJob: Job? = null
    private val _state = MutableStateFlow(TerminalUiState())
    val state: StateFlow<TerminalUiState> = _state.asStateFlow()

    val currentSession: TerminalSession?
        get() = repository.currentSession

    fun start(
        config: TerminalLaunchConfig,
        callbacks: TerminalCallbacks,
        onStarted: (TerminalSession) -> Unit,
    ) {
        startJob?.cancel()
        repository.stop()
        _state.value = TerminalUiState(starting = true)
        startJob = scope.launch {
            try {
                val session = withContext(dispatchers.io) {
                    repository.start(config, object : TerminalCallbacks {
                        override fun onOutput(text: String) = callbacks.onOutput(text)
                        override fun onExit(code: Int) {
                            _state.value = _state.value.copy(
                                starting = false, running = false, lastExitCode = code
                            )
                            callbacks.onExit(code)
                        }
                        override fun onError(error: Throwable) {
                            _state.value = _state.value.copy(
                                starting = false, running = false,
                                error = error.message ?: error.javaClass.simpleName,
                            )
                            callbacks.onError(error)
                        }
                    })
                }
                if (session != null) {
                    _state.value = TerminalUiState(running = true)
                    onStarted(session)
                } else if (_state.value.starting) {
                    _state.value = _state.value.copy(starting = false, running = false)
                }
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                _state.value = TerminalUiState(
                    starting = false,
                    running = false,
                    error = error.message ?: error.javaClass.simpleName,
                )
                callbacks.onError(error)
            }
        }
    }

    /** Writes are serialized so rapid key events and bracketed paste keep order. */
    fun send(text: String) {
        if (text.isEmpty()) return
        scope.launch {
            sendMutex.withLock {
                withContext(dispatchers.io) { repository.send(text) }
            }
        }
    }

    fun resize(rows: Int, cols: Int) {
        scope.launch(dispatchers.io) { repository.resize(rows, cols) }
    }

    fun isAlive(): Boolean = repository.isAlive()

    fun stopSession() {
        startJob?.cancel()
        startJob = null
        repository.stop()
        _state.value = _state.value.copy(starting = false, running = false)
    }

    /** Final composition cleanup; safe to call more than once. */
    fun close() {
        stopSession()
        scope.cancel()
    }
}
