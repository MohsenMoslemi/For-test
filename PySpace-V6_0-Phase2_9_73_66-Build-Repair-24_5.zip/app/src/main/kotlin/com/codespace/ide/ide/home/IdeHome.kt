package com.codespace.ide.ide.home

import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.zIndex
import com.codespace.ide.ProotManager
import java.io.File
import com.codespace.ide.UbuntuManager
import com.codespace.ide.ide.HomeTab
import com.codespace.ide.ide.display.VncDisplay
import com.codespace.ide.ide.learn.Lesson
import com.codespace.ide.ide.projects.ProjectRepository
import com.codespace.ide.ide.projects.ProjectsViewModel
import com.codespace.ide.ide.projects.PyProject
import com.codespace.ide.ide.settings.IdePrefs
import com.codespace.ide.ide.terminal.TermBridge
import com.codespace.ide.ide.theme.IdeTheme

// ---------------------------------------------------------------------------
// IDE home: project manager, pip packages, lessons and settings behind a
// bottom navigation bar (same flow as the reference IDE, recreated natively).
// ---------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IdeHome(
    workspace: File,
    proot: ProotManager,
    ubuntu: com.codespace.ide.UbuntuManager,
    projectRepository: ProjectRepository,
    prefs: IdePrefs,
    bridge: TermBridge,
    display: VncDisplay,
    onOpenSettings: () -> Unit,
    tab: HomeTab,
    onTab: (HomeTab) -> Unit,
    onOpenProject: (PyProject) -> Unit,
    onOpenLesson: (Lesson) -> Unit,
    onProjectGone: (File) -> Unit = {}
) {
    // Workspace access is owned by a ViewModel/repository. The repository
    // performs all filesystem traversal on Dispatchers.IO.
    val activity = LocalContext.current as ComponentActivity
    val projectsViewModel: ProjectsViewModel by activity.viewModels {
        ProjectsViewModel.Factory(workspace, activity.applicationContext, projectRepository)
    }
    val projectsState by projectsViewModel.state.collectAsState()
    val projects = projectsState.projects
    var createProjectPage by remember { mutableStateOf(false) }
    var showExitConfirmation by remember { mutableStateOf(false) }
    var interpreterVisited by remember { mutableStateOf(tab == HomeTab.Interpreter) }
    var terminalVisited by remember { mutableStateOf(tab == HomeTab.Terminal) }
    LaunchedEffect(tab) {
        if (tab == HomeTab.Interpreter) interpreterVisited = true
        if (tab == HomeTab.Terminal) terminalVisited = true
        if (tab != HomeTab.Projects) projectsViewModel.commitPendingProjectDeletions()
    }
    LaunchedEffect(projectsState.completedDeletionEvents) {
        val completed = projectsState.completedDeletionEvents
        if (completed.isNotEmpty()) {
            completed.forEach { onProjectGone(File(it)) }
            projectsViewModel.consumeCompletedDeletionEvents()
        }
    }
    BackHandler(enabled = createProjectPage) {
        if (!projectsState.mutationBusy) createProjectPage = false
    }
    // Only the Home root asks for exit confirmation. Sub-pages keep their
    // own BackHandlers and are allowed to close/navigate normally first.
    BackHandler(enabled = !createProjectPage) {
        showExitConfirmation = true
    }
    if (showExitConfirmation) {
        ExitConfirmationDialog(
            onCancel = { showExitConfirmation = false },
            onExit = {
                showExitConfirmation = false
                projectsViewModel.commitPendingProjectDeletions { activity.finishAffinity() }
            }
        )
    }
    LaunchedEffect(workspace, tab) {
        if (tab == HomeTab.Projects || tab == HomeTab.Terminal || tab == HomeTab.Interpreter) projectsViewModel.refresh()
    }
    LaunchedEffect(projectsViewModel) {
        projectsViewModel.refreshPythonRuntimeStates()
    }
    Scaffold(
        topBar = {
            if (createProjectPage) {
                TopAppBar(
                    title = {
                        Column {
                            Text("Create project", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("Set up a new Python workspace", style = MaterialTheme.typography.labelSmall, color = Color(IdeTheme.DIM))
                        }
                    },
                    navigationIcon = {
                        TextButton(onClick = { createProjectPage = false }, enabled = !projectsState.mutationBusy) {
                            Text("‹ Back", color = Color(IdeTheme.ACCENT))
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(IdeTheme.BG))
                )
            } else {
                TopAppBar(
                    title = {
                        Column {
                            Text("PySpace IDE", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(
                                when (tab) {
                                    HomeTab.Projects -> "Python projects"
                                    HomeTab.Terminal -> "Ubuntu terminal"
                                    HomeTab.Learn -> "learn Python"
                                    HomeTab.Interpreter -> "Python interpreter"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(IdeTheme.DIM)
                            )
                        }
                    },
                    actions = {
                        if (tab == HomeTab.Projects) {
                            TextButton(onClick = { projectsViewModel.commitPendingProjectDeletions(onOpenSettings) }) {
                                Text("⚙", fontSize = 19.sp)
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(IdeTheme.BG))
                )
            }
        },
        bottomBar = {
            if (!createProjectPage) {
                NavigationBar(containerColor = Color(IdeTheme.PANEL)) {
                    IdeNavItem(tab, HomeTab.Projects, "▦", "Projects", onTab)
                    IdeNavItem(tab, HomeTab.Terminal, "⌘", "Terminal", onTab)
                    IdeNavItem(tab, HomeTab.Learn, "✎", "Learn", onTab)
                    IdeNavItem(tab, HomeTab.Interpreter, "❯", "Python", onTab)
                }
            }
        },
        containerColor = Color(IdeTheme.BG)
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            // Keep both PTY-backed home consoles in composition, even while the
            // create-project subpage or another Home tab is visible.
            if (interpreterVisited) Box(Modifier.fillMaxSize().zIndex(if (tab == HomeTab.Interpreter) 2f else 0f)) {
                InterpreterTab(
                    proot = proot,
                    prefs = prefs,
                    runtimeState = projectsState,
                    visible = tab == HomeTab.Interpreter,
                    onInstallRuntime = projectsViewModel::installPythonRuntime,
                    onCancelRuntimeInstall = projectsViewModel::cancelPythonRuntimeDownload
                )
            }
            if (terminalVisited) Box(Modifier.fillMaxSize().zIndex(if (tab == HomeTab.Terminal) 2f else 0f)) {
                GlobalTerminalTab(proot = proot, visible = tab == HomeTab.Terminal)
            }
            if (createProjectPage) {
                NewProjectPage(
                    workspace = workspace,
                    existingProjects = projects,
                    mutationBusy = projectsState.mutationBusy,
                    mutationError = projectsState.mutationError,
                    mutationProgress = projectsState.mutationProgress,
                    mutationProgressFraction = projectsState.mutationProgressFraction,
                    runtimeInstallStates = projectsState.runtimeInstallStates,
                    viewModel = projectsViewModel,
                    modifier = Modifier.fillMaxSize(),
                    onCancel = { createProjectPage = false },
                    onCreated = { createProjectPage = false }
                )
            } else if (tab != HomeTab.Interpreter && tab != HomeTab.Terminal) Column(
                Modifier.fillMaxSize().background(Color(IdeTheme.BG))
            ) {
                when (tab) {
                HomeTab.Projects -> ProjectsTab(
                    projects,
                    sortMode = projectsState.sortMode,
                    projectCreatedAt = projectsState.projectCreatedAt,
                    projectLastOpenedAt = projectsState.projectLastOpenedAt,
                    loading = projectsState.isLoading,
                    pythonFileCounts = projectsState.pythonFileCounts,
                    loadError = projectsState.error,
                    mutationError = projectsState.mutationError,
                    mutationBusy = projectsState.mutationBusy || projectsState.backupRestoreBusy,
                    backupRestoreBusy = projectsState.backupRestoreBusy,
                    backupRestoreMessage = projectsState.backupRestoreMessage,
                    backupRestoreError = projectsState.backupRestoreError,
                    backupRestoreProgress = projectsState.backupRestoreProgress,
                    busyProjects = projectsState.busyProjects,
                    runtimeInstallStates = projectsState.runtimeInstallStates,
                    venvBuildingProjects = projectsState.venvBuildingProjects,
                    pendingDeletions = projectsState.pendingDeletions,
                    projectsViewModel = projectsViewModel,
                    onNewProject = { projectsViewModel.commitPendingProjectDeletions { createProjectPage = true } },
                    onOpen = { project ->
                        projectsViewModel.commitPendingProjectDeletions {
                            projectsViewModel.markProjectOpened(project)
                            onOpenProject(project)
                        }
                    },
                    onProjectGone = onProjectGone
                )
                HomeTab.Terminal -> Unit
                HomeTab.Learn -> LearnTab(onOpenLesson)
                HomeTab.Interpreter -> Unit
                }
            }
        }
    }
}

@Composable
internal fun ExitConfirmationDialog(
    onCancel: () -> Unit,
    onExit: () -> Unit
) {
    Dialog(
        onDismissRequest = onCancel,
        properties = DialogProperties(
            dismissOnBackPress = true,
            dismissOnClickOutside = true,
            usePlatformDefaultWidth = false
        )
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 26.dp)
                .border(1.dp, Color(IdeTheme.LINE), RoundedCornerShape(26.dp)),
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.PANEL)),
            elevation = CardDefaults.cardElevation(defaultElevation = 18.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 22.dp, end = 22.dp, top = 24.dp, bottom = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(62.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(IdeTheme.ERROR).copy(alpha = 0.12f))
                        .border(1.dp, Color(IdeTheme.ERROR).copy(alpha = 0.28f), RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("⏻", color = Color(IdeTheme.ERROR), fontSize = 31.sp, fontWeight = FontWeight.Medium)
                }
                Spacer(Modifier.height(18.dp))
                Text(
                    text = "Leave PySpace?",
                    color = Color(IdeTheme.TEXT),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(9.dp))
                Text(
                    text = "Are you sure you want to exit the app? You can stay here and continue where you left off.",
                    color = Color(IdeTheme.DIM),
                    fontSize = 13.sp,
                    lineHeight = 19.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                Spacer(Modifier.height(24.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    androidx.compose.material3.OutlinedButton(
                        onClick = onCancel,
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(IdeTheme.LINE)),
                        colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(
                            contentColor = Color(IdeTheme.TEXT)
                        )
                    ) {
                        Text("Stay", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Button(
                        onClick = onExit,
                        modifier = Modifier.weight(1f).height(48.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(IdeTheme.ERROR),
                            contentColor = Color(IdeTheme.BG)
                        )
                    ) {
                        Text("Exit app", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
internal fun androidx.compose.foundation.layout.RowScope.IdeNavItem(
    current: HomeTab,
    mine: HomeTab,
    glyph: String,
    label: String,
    onTab: (HomeTab) -> Unit
) {
    NavigationBarItem(
        selected = current == mine,
        onClick = { onTab(mine) },
        icon = { Text(glyph, fontSize = 19.sp) },
        label = { Text(label, fontSize = 11.sp) },
        colors = NavigationBarItemDefaults.colors(
            selectedIconColor = Color(IdeTheme.ACCENT),
            selectedTextColor = Color(IdeTheme.ACCENT),
            unselectedIconColor = Color(IdeTheme.DIM),
            unselectedTextColor = Color(IdeTheme.DIM),
            indicatorColor = Color(IdeTheme.CARD)
        )
    )
}

// ------------------------------- Projects ----------------------------------
