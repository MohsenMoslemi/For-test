package com.codespace.ide.ide.editor

import androidx.compose.foundation.ScrollState
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.TextLayoutResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Coordinates the editor's pinch lifecycle after the pointer recognizer has
 * identified a genuine two-finger gesture. It owns the transition rules
 * between wrapped live reflow and unwrapped GPU preview/commit, while the
 * recognizer itself remains responsible only for pointer tracking.
 */
internal class EditorPinchZoomCoordinator(
    private val scope: CoroutineScope,
    private val session: EditorZoomSessionState,
    private val anchor: ZoomAnchor,
    private val verticalScroll: ScrollState,
    private val horizontalScroll: ScrollState,
    private val currentFontSize: () -> Float,
    private val currentLayout: () -> TextLayoutResult?,
    private val currentDisplayText: () -> String,
    private val textPaddingPx: Float,
    private val currentGutterPx: () -> Float,
    private val gutterPxForFont: (Float) -> Float,
    private val changeFontSize: (Float) -> Unit,
    private val commitZoom: (Float, Float) -> Unit
) {
    fun onStart(wrapMode: Boolean, startFont: Float) {
        session.targetFont.value = startFont
        if (wrapMode) session.targetFont.value = 0f
        if (wrapMode) {
            anchor.wrapToken += 1
            val layout = currentLayout()
            anchor.wrapValid = false
            if (layout != null && sameDisplay(layout.layoutInput.text.text, currentDisplayText()) &&
                verticalScroll.value > textPaddingPx
            ) {
                val yLocal = verticalScroll.value - textPaddingPx
                val line = layout.getLineForVerticalPosition(yLocal)
                val top = layout.getLineTop(line)
                val height = (layout.getLineBottom(line) - top).coerceAtLeast(1f)
                anchor.wrapOffset = layout.getLineStart(line)
                anchor.wrapFrac = ((yLocal - top) / height).coerceIn(0f, 1f)
                anchor.wrapValid = true
            }
            anchor.wrapLive = true
        }
        // Keep the top of the visible text lane fixed as the zoom origin.
        session.pivot.value = Offset(
            horizontalScroll.value.toFloat(),
            verticalScroll.value.toFloat() + textPaddingPx
        )
        session.gutterWidthPx.value = currentGutterPx()
        session.gestureActive.value = true
    }

    fun onUpdate(startFont: Float, targetFont: Float, wrapMode: Boolean) {
        if (wrapMode) {
            // Wrapped text reflows live; quantize to quarter-sp increments.
            val committedTarget = (Math.round(targetFont * 4f) / 4f).coerceIn(9f, 24f)
            if (committedTarget != currentFontSize()) changeFontSize(committedTarget)
        } else {
            session.targetFont.value = targetFont
            session.gutterWidthPx.value = gutterPxForFont(targetFont)
            val scale = if (startFont > 0f) targetFont / startFont else 1f
            session.scaleY.value = scale
            session.scaleX.value = scale
        }
    }

    fun onEnd(pinching: Boolean, wrapMode: Boolean, startFont: Float, targetFont: Float) {
        if (pinching && !wrapMode && startFont > 0f && targetFont > 0f && targetFont != startFont) {
            commitZoom(startFont, targetFont)
        }
        if (wrapMode) {
            val token = anchor.wrapToken
            scope.launch {
                delay(160)
                if (anchor.wrapToken == token) {
                    anchor.wrapLive = false
                    session.gestureActive.value = false
                }
            }
            session.targetFont.value = 0f
        } else if (!anchor.settling) {
            session.targetFont.value = 0f
            session.gestureActive.value = false
            if (!anchor.pending) session.commitInProgress.value = false
            session.scaleY.value = 1f
            session.scaleX.value = 1f
        }
    }
}
