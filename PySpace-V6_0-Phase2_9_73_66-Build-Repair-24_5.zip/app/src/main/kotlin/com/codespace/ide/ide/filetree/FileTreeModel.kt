package com.codespace.ide.ide.filetree
import com.codespace.ide.ide.explorer.ExplorerTreeNode


internal typealias TreeNode = ExplorerTreeNode
