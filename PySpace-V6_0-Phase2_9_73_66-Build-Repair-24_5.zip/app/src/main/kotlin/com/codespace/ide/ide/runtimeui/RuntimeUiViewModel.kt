package com.codespace.ide.ide.runtimeui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import com.codespace.ide.ide.RunHub
import com.codespace.ide.ide.WebServer
import com.codespace.ide.ide.projects.PyProject

/** Immutable presentation state for the IDE's display and web-preview surfaces. */
data class RuntimeUiState(
    val displayOpen: Boolean = false,
    val displayUserHidden: Boolean = false,
    val frameMode: Boolean = false,
    val frameProject: PyProject? = null,
    val displayGeneration: Int = 0,
    val webServerGuess: WebServer? = null,
    val webLiveUrl: String? = null,
    val browserOpen: Boolean = false,
    val pendingBrowserChoiceUrl: String? = null,
    val rememberBrowserChoice: Boolean = false,
)

/**
 * Owns UI-facing runtime presentation state, not the processes themselves.
 * RunHub, PRoot, VNC and frame polling keep their existing lifecycle owners;
 * this ViewModel only makes display/browser visibility and discovery state
 * observable and consistent across the IDE's Compose tree.
 */
class RuntimeUiViewModel : ViewModel() {
    private val _state = MutableStateFlow(RuntimeUiState())
    val state: StateFlow<RuntimeUiState> = _state.asStateFlow()

    fun setDisplayOpen(open: Boolean) = update { copy(displayOpen = open) }
    fun setDisplayUserHidden(hidden: Boolean) = update { copy(displayUserHidden = hidden) }
    fun setFrameMode(enabled: Boolean) = update { copy(frameMode = enabled) }
    fun setFrameProject(project: PyProject?) = update { copy(frameProject = project) }
    fun setWebServerGuess(server: WebServer?) = update { copy(webServerGuess = server) }
    fun setWebLiveUrl(url: String?) = update { copy(webLiveUrl = url) }
    fun setBrowserOpen(open: Boolean) = update { copy(browserOpen = open) }
    fun setRememberBrowserChoice(remember: Boolean) = update { copy(rememberBrowserChoice = remember) }

    fun beginDisplayOperation(): Int {
        val next = _state.value.displayGeneration + 1
        _state.value = _state.value.copy(
            displayGeneration = next,
            displayUserHidden = false,
        )
        return next
    }

    fun isCurrentDisplayOperation(generation: Int): Boolean =
        _state.value.displayGeneration == generation

    fun invalidateDisplayOperations(): Int {
        val next = _state.value.displayGeneration + 1
        _state.value = _state.value.copy(displayGeneration = next)
        return next
    }

    fun requestBrowserChoice(url: String) {
        _state.value = _state.value.copy(
            pendingBrowserChoiceUrl = url,
            rememberBrowserChoice = false,
        )
    }

    fun dismissBrowserChoice() {
        _state.value = _state.value.copy(
            pendingBrowserChoiceUrl = null,
            rememberBrowserChoice = false,
        )
    }

    fun consumeBrowserChoice(): String? {
        val url = _state.value.pendingBrowserChoiceUrl
        _state.value = _state.value.copy(
            pendingBrowserChoiceUrl = null,
            rememberBrowserChoice = false,
        )
        return url
    }

    fun resetProjectPresentation() {
        _state.value = RuntimeUiState(
            displayGeneration = _state.value.displayGeneration + 1,
        )
    }

    private inline fun update(transform: RuntimeUiState.() -> RuntimeUiState) {
        _state.value = _state.value.transform()
    }

    class Factory : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (!modelClass.isAssignableFrom(RuntimeUiViewModel::class.java)) {
                throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
            }
            return RuntimeUiViewModel() as T
        }
    }
}
