package com.codespace.ide.ide.codeintel

import org.json.JSONArray
import org.json.JSONObject

/** Immutable result of translating one LSP publishDiagnostics notification. */
internal data class MappedLspDiagnostics(
    val uri: String,
    val version: Int,
    val diagnostics: List<PythonSyntaxDiagnostic>,
)

/** Pure protocol-to-domain mapping; project freshness and publication policy stay in the controller. */
internal object LspDiagnosticMapper {
    fun map(params: JSONObject): MappedLspDiagnostics {
        val uri = params.optString("uri")
        val version = params.optInt("version", -1)
        val array = params.optJSONArray("diagnostics") ?: JSONArray()
        val diagnostics = ArrayList<PythonSyntaxDiagnostic>(array.length())
        for (index in 0 until array.length()) {
            val item = array.optJSONObject(index) ?: continue
            val range = item.optJSONObject("range") ?: JSONObject()
            val start = range.optJSONObject("start") ?: JSONObject()
            val end = range.optJSONObject("end") ?: JSONObject()
            val severity = item.optInt("severity", 1)
            val message = item.optString("message", "Python diagnostic")
            val rawCode = item.opt("code")
            val code = when (rawCode) {
                is String -> rawCode
                is Number -> rawCode.toString()
                is JSONObject -> rawCode.optString("value").ifBlank { rawCode.optString("code") }
                else -> ""
            }.ifBlank {
                Regex("\\b[A-Z][0-9]{3}\\b").find(message.uppercase())?.value.orEmpty()
            }.takeIf { it.isNotBlank() }
            diagnostics += PythonSyntaxDiagnostic(
                line = start.optInt("line", 0) + 1,
                column = start.optInt("character", 0) + 1,
                endLine = end.optInt("line", start.optInt("line", 0)) + 1,
                endColumn = end.optInt("character", start.optInt("character", 0) + 1) + 1,
                message = message,
                kind = when (severity) {
                    1 -> "Error"
                    2 -> "Warning"
                    3 -> "Information"
                    else -> "Hint"
                },
                code = code,
            )
        }
        return MappedLspDiagnostics(uri, version, diagnostics)
    }
}
