package com.codespace.ide.ide.filetree

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import com.codespace.ide.ide.codeintel.CodeIntelligenceViewModel
import com.codespace.ide.ide.editor.EditorSession
import com.codespace.ide.ide.theme.IdeTheme

/** Class/method/field outline of the active file, with a filter box.
 *  Tapping a row jumps the editor to that line (with a flash highlight). */
@Composable
internal fun StructureTab(
    session: EditorSession,
    viewModel: CodeIntelligenceViewModel,
    onJumpToLine: (File, Int) -> Unit
) {
    val tab = session.active
    val outlineState by viewModel.outline.collectAsState()
    LaunchedEffect(tab?.file?.absolutePath, tab?.text) {
        viewModel.analyze(tab?.file, tab?.text)
    }
    var filter by remember { mutableStateOf("") }
    CompositionLocalProvider(LocalContentColor provides Color(IdeTheme.TEXT)) {
    Column(Modifier.fillMaxSize()) {
        Text(
            "Structure", fontWeight = FontWeight.Bold, fontSize = 15.sp,
            color = Color(IdeTheme.TEXT),
            modifier = Modifier.padding(start = 16.dp, top = 12.dp, end = 12.dp)
        )
        OutlinedTextField(
            value = filter, onValueChange = { filter = it },
            placeholder = { Text("Filter…") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
        )
        if (tab == null) {
            Text(
                "No file open.", color = Color(IdeTheme.DIM), fontSize = 12.sp,
                modifier = Modifier.padding(16.dp)
            )
        } else {
            val items = if (outlineState.filePath == tab.file.absolutePath) outlineState.items else emptyList()
            val shown = remember(items, filter) {
                if (filter.isBlank()) items else items.filter { it.name.contains(filter, ignoreCase = true) }
            }
            if (outlineState.loading && outlineState.filePath == tab.file.absolutePath) {
                androidx.compose.material3.CircularProgressIndicator(
                    modifier = Modifier.padding(16.dp).size(22.dp), strokeWidth = 2.dp
                )
            } else if (shown.isEmpty()) {
                Text(
                    "No symbols found.", color = Color(IdeTheme.DIM), fontSize = 12.sp,
                    modifier = Modifier.padding(16.dp)
                )
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(shown) { s ->
                        Row(
                            Modifier
                            .fillMaxWidth()
                            .clickable {
                                val f = tab.file
                                onJumpToLine(f, s.line)
                            }
                            .padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            LetterBadge(
                                s.kind.toString(),
                                when (s.kind) {
                                    'C' -> 0xFFFF9E57
                                    'm' -> 0xFFB39DDB
                                    else -> IdeTheme.TEAL
                                }
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                s.name, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f), maxLines = 1
                            )
                            if (s.detail.isNotEmpty()) {
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    s.detail, color = Color(IdeTheme.DIM), fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace, maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
    }
}

// (Old terminal-based GitTab removed: the drawer Git tab is now the
// built-in GitHub client in GitHub.kt.)
