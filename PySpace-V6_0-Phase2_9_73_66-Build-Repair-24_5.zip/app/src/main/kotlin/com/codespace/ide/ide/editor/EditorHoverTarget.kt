package com.codespace.ide.ide.editor

/** Source-level identifier selected by a hover gesture. Offsets are UTF-16, like Compose TextLayout. */
internal data class EditorHoverTarget(
    val offset: Int,
    val wordStart: Int,
    val wordEnd: Int
)

/** Pure source lookup kept separate from pointer/layout and LSP orchestration. */
internal object EditorHoverTargetResolver {
    fun resolve(source: String, requestedOffset: Int): EditorHoverTarget? {
        if (source.isEmpty()) return null
        val offset = requestedOffset.coerceIn(0, source.length)
        fun isWord(c: Char) = c.isLetterOrDigit() || c == '_'

        var start = offset
        var end = offset
        if (start < source.length && !isWord(source[start]) &&
            start > 0 && isWord(source[start - 1])) start--
        while (start > 0 && isWord(source[start - 1])) start--
        while (end < source.length && isWord(source[end])) end++

        if (start >= end || !(source[start].isLetter() || source[start] == '_')) return null
        return EditorHoverTarget(offset, start, end)
    }
}
