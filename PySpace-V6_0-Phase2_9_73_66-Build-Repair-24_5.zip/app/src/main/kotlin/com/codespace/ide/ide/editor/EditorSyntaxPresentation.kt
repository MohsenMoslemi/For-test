package com.codespace.ide.ide.editor

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import com.codespace.ide.ide.EditorLanguage
import com.codespace.ide.ide.codeintel.PythonSyntaxDiagnostic
import java.io.File

/**
 * The complete syntax-rendering projection consumed by the editor surface.
 * It owns no document or analysis state: it derives the visible diagnostic
 * set and keeps the existing per-file tokenization cache warm while producing
 * the Compose VisualTransformation for the current presentation inputs.
 */
internal data class EditorSyntaxPresentation(
    val visibleDiagnostics: List<PythonSyntaxDiagnostic>,
    val colors: EditorColors,
)

/**
 * Creates the syntax presentation for one open file. Analysis results and
 * the editable buffer remain owned by their existing owners; this function
 * only projects those inputs into rendering state.
 */
@Composable
internal fun rememberEditorSyntaxPresentation(
    file: File,
    isPythonLanguage: Boolean,
    validatedSource: String?,
    currentSource: String,
    editingLine: Int?,
    diagnostics: List<PythonSyntaxDiagnostic>,
    flashLine: Int?,
    language: EditorLanguage,
    foldedDocument: FoldedEditorDocument,
    wordWrap: Boolean,
    themeId: String,
): EditorSyntaxPresentation {
    val visibleDiagnostics = remember(
        isPythonLanguage,
        validatedSource,
        currentSource,
        editingLine,
        diagnostics,
    ) {
        EditorDerivedState.visibleDiagnostics(
            isPythonLanguage = isPythonLanguage,
            validatedSource = validatedSource,
            currentSource = currentSource,
            editingLine = editingLine,
            diagnostics = diagnostics,
        )
    }
    // The cache is keyed only by file identity so cursor, fold and diagnostic
    // recompositions do not force Python tokenization again.
    val highlightCache = remember(file.absolutePath) { EditorHighlightCache(file) }
    val colors = remember(
        file.absolutePath,
        flashLine,
        visibleDiagnostics,
        language,
        foldedDocument,
        wordWrap,
        themeId,
    ) {
        EditorColors(
            highlightCache = highlightCache,
            flashLn = flashLine,
            diagnostics = if (isPythonLanguage) visibleDiagnostics else emptyList(),
            foldedDocument = foldedDocument,
            glueIndent = wordWrap,
        )
    }
    return EditorSyntaxPresentation(
        visibleDiagnostics = visibleDiagnostics,
        colors = colors,
    )
}
