package com.codespace.ide.ide.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.layoutId
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ide.codeintel.PythonDefinitionLocation
import com.codespace.ide.ide.codeintel.PythonHoverDoc
import com.codespace.ide.ide.codeintel.PythonSyntaxDiagnostic
import com.codespace.ide.ide.theme.IdeTheme

/** Documentation/definition card. All lookup and dismissal state stays in PyEditor. */
@Composable
internal fun EditorDocumentationCard(
    documentation: PythonHoverDoc?,
    definition: PythonDefinitionLocation?,
    onGoToDefinition: (PythonDefinitionLocation) -> Unit,
    onClose: () -> Unit,
    onPositioned: (LayoutCoordinates) -> Unit
) {
    val shape = RoundedCornerShape(13.dp)
    Column(
        modifier = Modifier
            .layoutId(1)
            .onGloballyPositioned(onPositioned)
            .heightIn(max = 180.dp)
            .shadow(16.dp, shape)
            .clip(shape)
            .containPopupScroll()
            .background(Color(IdeTheme.PANEL))
            .border(1.dp, Color(IdeTheme.LINE), shape)
            .verticalScroll(rememberScrollState())
            .padding(12.dp)
    ) {
        if (definition != null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f)
                        .clip(RoundedCornerShape(7.dp))
                        .clickable { onGoToDefinition(definition) }
                        .padding(horizontal = 7.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Go to", color = Color(IdeTheme.ACCENT), fontSize = 11.sp)
                    Spacer(Modifier.weight(1f))
                    Text("↗", color = Color(IdeTheme.ACCENT), fontSize = 13.sp)
                }
                Spacer(Modifier.width(5.dp))
                PopupClose(onClose)
            }
        }
        if (documentation != null) Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = documentation.name,
                color = Color(IdeTheme.TEXT),
                fontSize = 14.sp,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = documentation.kind,
                color = Color(IdeTheme.TEAL),
                fontSize = 9.sp,
                letterSpacing = 0.7.sp
            )
            Spacer(Modifier.width(4.dp))
            PopupClose(onClose)
        }
        if (documentation != null && documentation.signature.isNotBlank()) {
            Spacer(Modifier.height(7.dp))
            Text(
                text = documentation.signature,
                color = Color(IdeTheme.BUILTIN),
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp
            )
        }
        if (documentation != null && documentation.summary.isNotBlank()) {
            Spacer(Modifier.height(7.dp))
            Text(
                text = documentation.summary,
                color = Color(IdeTheme.TEXT),
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
        }
        if (documentation != null && documentation.details.isNotBlank()) {
            Spacer(Modifier.height(5.dp))
            Text(
                text = documentation.details,
                color = Color(IdeTheme.DIM),
                fontSize = 10.sp,
                lineHeight = 14.sp
            )
        }
    }
}

/** Diagnostic card presentation; source validation and edit actions are injected by the owner. */
@Composable
internal fun EditorDiagnosticCard(
    diagnostic: PythonSyntaxDiagnostic,
    canFix: Boolean,
    canReformatLine: Boolean,
    onFix: () -> Unit,
    onReformatLine: () -> Unit,
    onDismiss: () -> Unit,
    onPositioned: (LayoutCoordinates) -> Unit
) {
    val isError = diagnostic.kind.contains("error", ignoreCase = true) ||
        diagnostic.kind.equals("Fatal", true)
    val severity = if (isError) Color(IdeTheme.ERROR) else Color(IdeTheme.WARN)
    val shape = RoundedCornerShape(11.dp)
    Column(
        modifier = Modifier
            .layoutId(2)
            .onGloballyPositioned(onPositioned)
            .heightIn(max = 150.dp)
            .shadow(14.dp, shape)
            .clip(shape)
            .containPopupScroll()
            .background(Color(IdeTheme.CARD))
            .background(severity.copy(alpha = 0.10f))
            .border(1.dp, severity.copy(alpha = 0.75f), shape)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 11.dp, vertical = 9.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (isError) "ERROR" else "WARNING",
                color = severity,
                fontSize = 9.sp,
                letterSpacing = 0.8.sp
            )
            Spacer(Modifier.weight(1f))
            Text("Line ${diagnostic.line}", color = Color(IdeTheme.DIM), fontSize = 9.sp)
            Spacer(Modifier.width(4.dp))
            PopupClose(onDismiss)
        }
        Spacer(Modifier.height(5.dp))
        Text(
            diagnostic.message,
            color = Color(IdeTheme.TEXT),
            fontSize = 11.sp,
            lineHeight = 15.sp
        )
        if (canFix || canReformatLine) {
            Spacer(Modifier.height(7.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (canFix) {
                    Text(
                        "Fix",
                        color = severity,
                        fontSize = 10.sp,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable(onClick = onFix)
                            .padding(horizontal = 9.dp, vertical = 5.dp)
                    )
                }
                if (canReformatLine) {
                    Text(
                        "Reformat line",
                        color = severity,
                        fontSize = 10.sp,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable(onClick = onReformatLine)
                            .padding(horizontal = 9.dp, vertical = 5.dp)
                    )
                }
            }
        }
    }
}
