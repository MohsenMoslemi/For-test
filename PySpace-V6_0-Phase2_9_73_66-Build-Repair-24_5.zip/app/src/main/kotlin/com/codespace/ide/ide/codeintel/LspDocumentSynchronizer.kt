package com.codespace.ide.ide.codeintel

import java.io.File
import org.json.JSONArray
import org.json.JSONObject

/**
 * Owns the LSP text-document synchronization protocol for one project session.
 * It is deliberately independent of process startup, request scheduling and
 * diagnostics policy. The controller supplies environment refresh callbacks
 * because interpreter/import-root selection remains project policy.
 */
internal class LspDocumentSynchronizer(
    private val documents: LspDocumentRegistry,
    private val uriFor: (File) -> String,
    private val refreshInterpreterSettings: (LspSessionTransport) -> Unit,
    private val refreshProjectImportRoots: (LspSessionTransport) -> Unit,
) {
    fun sync(
        active: LspSessionTransport,
        file: File,
        source: String,
        refreshRoots: Boolean = true,
    ) {
        refreshInterpreterSettings(active)
        val uri = uriFor(file)
        val previous = documents.source(uri)
        // Publish the newest snapshot before sending the notification: pylsp
        // may answer on its reader thread immediately after the write flushes.
        documents.publish(uri, file, source)
        if (previous == null) {
            if (refreshRoots) refreshProjectImportRoots(active)
            active.setDocumentVersion(uri, 1)
            documents.publish(uri, file, source, 1)
            active.notify("textDocument/didOpen", JSONObject()
                .put("textDocument", JSONObject()
                    .put("uri", uri)
                    .put("languageId", "python")
                    .put("version", 1)
                    .put("text", source)))
        } else if (previous != source) {
            if (refreshRoots) refreshProjectImportRoots(active)
            val version = (active.documentVersion(uri) + 1).coerceAtLeast(2)
            active.setDocumentVersion(uri, version)
            documents.publish(uri, file, source, version)
            active.notify("textDocument/didChange", JSONObject()
                .put("textDocument", JSONObject().put("uri", uri).put("version", version))
                .put("contentChanges", JSONArray().put(JSONObject().put("text", source))))
        }
    }
}
