package com.codespace.ide.ide.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.memory.MemoryProfile
import com.codespace.ide.memory.MemoryRuntimePolicy
import com.codespace.ide.memory.MemoryTrimRegistry
import com.codespace.ide.memory.MemoryUsageSnapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.codespace.ide.ide.theme.IdeTheme

@Composable
internal fun ThemeSettingsCard(selectedTheme: String, onThemeSelected: (String) -> Unit) {
    val options = listOf(
        Triple(com.codespace.ide.ide.theme.IdeTheme.DARK, "Midnight", "The original deep charcoal palette with emerald accents."),
        Triple(com.codespace.ide.ide.theme.IdeTheme.LIGHT, "Daylight", "A clean, soft light palette with the same emerald identity."),
    )
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("APPEARANCE", color = Color(IdeTheme.DIM), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        options.forEach { (id, title, description) ->
            val isSelected = selectedTheme == id
            val preview = IdeTheme.previewColors(id)
            val previewBg = Color(preview.bg)
            val previewPanel = Color(preview.panel)
            val previewText = Color(preview.text)
            val previewDim = Color(preview.dim)
            val previewLine = Color(preview.line)
            Card(
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                    .clickable { onThemeSelected(id) },
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(IdeTheme.ACCENT).copy(alpha = .09f) else Color(IdeTheme.CARD)),
                border = androidx.compose.foundation.BorderStroke(if (isSelected) 1.5.dp else 1.dp, if (isSelected) Color(IdeTheme.ACCENT) else Color(IdeTheme.LINE))
            ) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(title, color = Color(IdeTheme.TEXT), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text(description, color = Color(IdeTheme.DIM), fontSize = 11.sp, lineHeight = 16.sp)
                        }
                        Spacer(Modifier.width(10.dp))
                        Box(
                            Modifier.size(24.dp).clip(CircleShape)
                                .background(if (isSelected) Color(IdeTheme.ACCENT) else Color.Transparent)
                                .then(if (isSelected) Modifier else Modifier.border(1.dp, Color(IdeTheme.LINE), CircleShape)),
                            contentAlignment = Alignment.Center
                        ) { if (isSelected) Text("✓", color = Color(IdeTheme.ON_ACCENT), fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(previewBg)
                            .border(1.dp, previewLine, RoundedCornerShape(12.dp)).padding(9.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("PySpace", color = previewText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("Python workspace", color = previewDim, fontSize = 9.sp)
                            Spacer(Modifier.height(7.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                Box(Modifier.weight(1f).height(6.dp).clip(CircleShape).background(Color(preview.accent)))
                                Box(Modifier.weight(.55f).height(6.dp).clip(CircleShape).background(previewLine))
                                Box(Modifier.weight(.35f).height(6.dp).clip(CircleShape).background(previewLine))
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                        Box(Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(previewPanel).border(1.dp, previewLine, RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                            Text("PS", color = Color(preview.accent), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                    if (isSelected) {
                        Spacer(Modifier.height(8.dp))
                        Text("CURRENT THEME", color = Color(IdeTheme.ACCENT), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    }
                }
            }
        }
        Text("Your selection is saved automatically and will be restored the next time you open PySpace.", color = Color(IdeTheme.DIM), fontSize = 11.sp, lineHeight = 16.sp)
    }
}

/** App-owned memory policy and diagnostics. Runtime processes and project data are never cleared here. */
@Composable
internal fun MemorySettingsCard() {
    val context = LocalContext.current.applicationContext
    var profile by remember { mutableStateOf(MemoryRuntimePolicy.profile()) }
    var automaticTrim by remember { mutableStateOf(MemoryRuntimePolicy.isAutomaticTrimmingEnabled()) }
    var usage by remember { mutableStateOf(MemoryUsageSnapshot(0, 0, 0)) }
    var cacheMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        while (true) {
            usage = withContext(Dispatchers.Default) { MemoryRuntimePolicy.usageSnapshot() }
            kotlinx.coroutines.delay(5_000L)
        }
    }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.CARD)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(18.dp)) {
            Text("MEMORY USAGE", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.3.sp)
            Spacer(Modifier.height(8.dp))
            Text("App process: ${usage.processPssMb} MB", color = Color(IdeTheme.TEXT), fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text("Java heap: ${usage.javaHeapUsedMb} / ${usage.javaHeapMaxMb} MB", color = Color(IdeTheme.DIM), fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            Text("PSS includes native memory used by the Android app process. The Java heap figure is separate; Ubuntu/PRoot child processes are not included in these app-process figures.", color = Color(IdeTheme.DIM), fontSize = 11.sp, lineHeight = 16.sp)

            Spacer(Modifier.height(18.dp))
            Divider(color = Color(IdeTheme.LINE))
            Spacer(Modifier.height(14.dp))
            Text("MEMORY PROFILE", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.3.sp)
            Spacer(Modifier.height(4.dp))
            MemoryProfile.values().forEach { option ->
                val selected = profile == option
                Row(
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (selected) Color(IdeTheme.ACCENT).copy(alpha = .10f) else Color.Transparent)
                        .clickable {
                            profile = option
                            MemoryRuntimePolicy.setProfile(context, option)
                        }
                        .padding(horizontal = 10.dp, vertical = 11.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (selected) "●" else "○", color = if (selected) Color(IdeTheme.ACCENT) else Color(IdeTheme.DIM), fontSize = 17.sp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(option.title, color = Color(IdeTheme.TEXT), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (option == MemoryProfile.LOW_MEMORY)
                                "4,000 terminal lines · smaller undo history · compact image previews"
                            else "12,000 terminal lines · larger undo history · sharper image previews",
                            color = Color(IdeTheme.DIM), fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            SettingSwitch(
                "Automatic memory optimization",
                automaticTrim,
                "Temporarily reduces retained UI caches when Android reports memory pressure, then restores your selected profile when PySpace returns to the foreground.",
                onChange = {
                    automaticTrim = it
                    MemoryRuntimePolicy.setAutomaticTrimming(context, it)
                }
            )

            Spacer(Modifier.height(8.dp))
            Divider(color = Color(IdeTheme.LINE))
            Spacer(Modifier.height(10.dp))
            TextButton(onClick = {
                MemoryTrimRegistry.clearTemporaryCaches()
                cacheMessage = "Temporary caches cleared. Active sessions and project data were preserved."
            }) {
                Text("Clear temporary caches", color = Color(IdeTheme.ACCENT))
            }
            cacheMessage?.let { Text(it, color = Color(IdeTheme.DIM), fontSize = 11.sp) }
            Spacer(Modifier.height(4.dp))
            Text(
                "Terminal output is not discarded when the UI falls behind: the reader applies backpressure until the display catches up. Undo history is reduced only under memory pressure; this action preserves it and does not stop Python kernels or running commands, erase notebook outputs, or delete project files.",
                color = Color(IdeTheme.DIM), fontSize = 11.sp, lineHeight = 16.sp
            )
        }
    }
}

/** About page. */
@Composable
internal fun AboutCard() {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.CARD)), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text("PYSPACE", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.3.sp)
            Spacer(Modifier.height(8.dp))
            Text("About this app", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(4.dp))
            Text("PySpace IDE — Python IDE with an Ubuntu terminal.", color = Color(IdeTheme.DIM), fontSize = 12.sp)
            Text("Editor UI flow inspired by CodeAssist, rebuilt natively.", color = Color(IdeTheme.DIM), fontSize = 12.sp)
        }
    }
}
