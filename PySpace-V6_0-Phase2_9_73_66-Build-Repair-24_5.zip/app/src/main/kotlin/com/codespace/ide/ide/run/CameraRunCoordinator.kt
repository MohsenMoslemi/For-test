package com.codespace.ide.ide.run

import com.codespace.ide.runtime.RuntimeDispatchers
import kotlinx.coroutines.withContext
import com.codespace.ide.ide.camera.PhoneCamera

/**
 * Prepares the phone-camera bridge for a Python run without doing socket or
 * shim-file work on the UI thread. Android permission UI and CameraX startup
 * remain on Main, where their existing Activity/Lifecycle owners live.
 */
class CameraRunCoordinator(
    private val camera: PhoneCamera,
    private val dispatchers: RuntimeDispatchers = RuntimeDispatchers.Default,
) {
    /**
     * Starts/reuses the localhost bridge on IO, then creates the run prefix.
     * [requestPermission] is invoked on Main only when permission is missing.
     */
    suspend fun prepareRun(
        shouldContinue: () -> Boolean = { true },
        requestPermission: () -> Unit,
    ): String {
        val port = withContext(dispatchers.io) { camera.ensureServer() }
        return withContext(dispatchers.main) {
            // A Console Stop/new Run may arrive while the socket/shim is being
            // prepared. Do not activate the camera or show a permission prompt
            // for a request that is no longer current.
            if (!shouldContinue()) return@withContext ""
            val granted = camera.hasPermission()
            val prefix = if (port > 0) {
                if (granted) camera.autoStartForRun()
                CameraRunCommandFactory.prefix("http://127.0.0.1:$port", granted, camera.shimDir)
            } else {
                ""
            }
            if (!granted) requestPermission()
            prefix
        }
    }
}
