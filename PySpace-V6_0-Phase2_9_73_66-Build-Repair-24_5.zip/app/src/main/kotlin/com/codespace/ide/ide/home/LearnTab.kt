package com.codespace.ide.ide.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ide.learn.Lesson
import com.codespace.ide.ide.theme.IdeTheme

@Composable
internal fun LearnTab(onOpen: (Lesson) -> Unit) {
    val lessons = remember { builtinLessons() }
    LazyColumn(
        Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(lessons) { l ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.CARD)),
                modifier = Modifier.fillMaxWidth().clickable { onOpen(l) }
            ) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text(l.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(l.subtitle, color = Color(IdeTheme.DIM), fontSize = 12.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("Tap to open the sample in the editor", color = Color(IdeTheme.ACCENT), fontSize = 12.sp)
                }
            }
        }
    }
}

// ------------------------------ Transitions --------------------------------
