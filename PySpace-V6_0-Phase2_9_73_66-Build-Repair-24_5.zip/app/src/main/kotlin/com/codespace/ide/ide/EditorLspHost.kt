package com.codespace.ide.ide

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import com.codespace.ide.ProotManager
import com.codespace.ide.domain.packages.PackageManagerRepository
import com.codespace.ide.runtime.RuntimeDispatchers
import com.codespace.ide.ide.codeintel.PythonLspController
import com.codespace.ide.ide.editor.EditorSession
import com.codespace.ide.ide.editor.OpenTab

/**
 * Owns the project-scoped LSP controller's Compose attachment lifecycle.
 *
 * The controller owns the language-server session; this host only creates it
 * for the active editor project, closes it when that project leaves the host,
 * and releases individual LSP documents when editor tabs close.
 */
@Composable
internal fun rememberProjectPythonLspController(
    context: Context,
    proot: ProotManager,
    editorSession: EditorSession?,
    packageManagerRepository: PackageManagerRepository,
    runtimeDispatchers: RuntimeDispatchers,
): PythonLspController? {
    val controller = remember(editorSession?.project?.dir) {
        editorSession?.let {
            PythonLspController(
                context,
                proot,
                it.project,
                packageManagerRepository,
                runtimeDispatchers,
            )
        }
    }

    DisposableEffect(controller) {
        onDispose { controller?.close() }
    }

    DisposableEffect(editorSession, controller) {
        val previousOnTabClosed = editorSession?.onTabClosed
        val releaseClosedDocument: (OpenTab) -> Unit = { tab ->
            try {
                previousOnTabClosed?.invoke(tab)
            } catch (_: Exception) {
            }
            controller?.closeDocument(tab.file)
        }
        editorSession?.onTabClosed = releaseClosedDocument
        onDispose {
            if (editorSession?.onTabClosed === releaseClosedDocument) {
                editorSession.onTabClosed = previousOnTabClosed
            }
        }
    }

    return controller
}
