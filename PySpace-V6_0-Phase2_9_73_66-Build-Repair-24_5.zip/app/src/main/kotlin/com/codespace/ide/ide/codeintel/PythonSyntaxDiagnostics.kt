package com.codespace.ide.ide.codeintel

import com.codespace.ide.ProotManager
import com.codespace.ide.runtime.RuntimeDispatchers
import java.io.File
import java.nio.charset.StandardCharsets
import java.util.Base64
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import com.codespace.ide.ide.projects.PyProject

/** A real CPython parser diagnostic. Line/column values are 1-based. */
data class PythonSyntaxDiagnostic(
    val line: Int,
    val column: Int,
    val endLine: Int,
    val endColumn: Int,
    val message: String,
    val kind: String = "SyntaxError",
    val code: String? = null,
)

/**
 * Debounced syntax checker backed by the project's actual Ubuntu Python.
 * The source is sent as Base64 to `compile()`; it is never executed or saved
 * to the project. A single PRoot check runs at a time to avoid process storms
 * on phones while the user is typing.
 */
class PythonSyntaxDiagnosticsController(
    private val proot: ProotManager,
    private val dispatchers: RuntimeDispatchers = RuntimeDispatchers.Default,
) : AutoCloseable {
    private val scope = CoroutineScope(SupervisorJob() + dispatchers.main)
    private val mutex = Mutex()
    private val jobs = LinkedHashMap<String, Job>()
    private val _results = MutableStateFlow<Map<String, List<PythonSyntaxDiagnostic>>>(emptyMap())
    val results: StateFlow<Map<String, List<PythonSyntaxDiagnostic>>> = _results.asStateFlow()
    // Exact source text that the current diagnostics were computed from. This
    // also signals successful validation when the diagnostics list itself did
    // not change (StateFlow would otherwise suppress an equal map value).
    private val _validatedSources = MutableStateFlow<Map<String, String>>(emptyMap())
    val validatedSources: StateFlow<Map<String, String>> = _validatedSources.asStateFlow()

    fun schedule(project: PyProject, file: File, source: String) {
        val path = file.absolutePath
        jobs.remove(path)?.cancel()
        // Keep the last successful diagnostics while the user edits. The
        // editor temporarily hides only the line currently being edited;
        // diagnostics on all other lines remain visible during the debounce.
        if (!file.extension.equals("py", ignoreCase = true) || source.length > MAX_SOURCE_CHARS) {
            _results.value = _results.value - path
            _validatedSources.value = _validatedSources.value - path
            return
        }

        val job = scope.launch {
            val ownJob = currentCoroutineContext()[Job]
            delay(DEBOUNCE_MS)
            try {
                val diagnostics = withContext(dispatchers.io) {
                    mutex.withLock { checkWithPython(project, source) }
                }
                if (diagnostics != null && ownJob?.isActive == true) {
                    _results.value = _results.value + (path to diagnostics)
                    _validatedSources.value = _validatedSources.value + (path to source)
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                // Runtime unavailable or check timed out: don't invent a
                // syntax error. Keep the last known result for this file.
            } finally {
                if (jobs[path] === ownJob) jobs.remove(path)
            }
        }
        jobs[path] = job
    }

    fun clear(file: File) {
        val path = file.absolutePath
        jobs.remove(path)?.cancel()
        _results.value = _results.value - path
        _validatedSources.value = _validatedSources.value - path
    }

    private fun checkWithPython(project: PyProject, source: String): List<PythonSyntaxDiagnostic>? {
        val sourceBytes = source.toByteArray(StandardCharsets.UTF_8)
        if (sourceBytes.size > MAX_SOURCE_BYTES) return null
        val encoded = Base64.getEncoder().encodeToString(sourceBytes)
        val script = """import base64, io, json, tokenize
source = base64.b64decode("$encoded").decode("utf-8")

def split_top_level_statements(text):
    tokens = list(tokenize.generate_tokens(io.StringIO(text).readline))
    chunks = []
    current = []
    depth = 0
    start_line = None
    last_line = None
    pending_block = False
    decorator = False
    for index, token in enumerate(tokens):
        kind = token.type
        if kind in (tokenize.ENCODING, tokenize.ENDMARKER):
            continue
        if kind in (tokenize.NL, tokenize.COMMENT):
            continue
        if kind == tokenize.INDENT:
            depth += 1
            continue
        if kind == tokenize.DEDENT:
            depth = max(0, depth - 1)
            if depth == 0 and pending_block and current:
                chunks.append((start_line, last_line))
                current = []
                start_line = None
                last_line = None
                pending_block = False
                decorator = False
            continue
        if kind == tokenize.NEWLINE:
            if depth == 0 and current:
                look = index + 1
                while look < len(tokens) and tokens[look].type in (tokenize.NL, tokenize.COMMENT):
                    look += 1
                next_type = tokens[look].type if look < len(tokens) else tokenize.ENDMARKER
                next_text = tokens[look].string if look < len(tokens) else ""
                starts_decorator = current[0].type == tokenize.OP and current[0].string == "@"
                if next_type == tokenize.INDENT:
                    pending_block = True
                elif starts_decorator and next_type == tokenize.NAME and next_text in ("def", "class", "async"):
                    decorator = True
                else:
                    if not decorator:
                        chunks.append((start_line, last_line))
                        current = []
                        start_line = None
                        last_line = None
                        pending_block = False
                    decorator = False
            continue
        if start_line is None:
            start_line = token.start[0]
        current.append(token)
        last_line = token.end[0]
    if current and start_line is not None:
        chunks.append((start_line, last_line or start_line))
    lines = text.splitlines(keepends=True)
    return [(first, last, "".join(lines[first - 1:last])) for first, last in chunks]

def diagnostic(error):
    line = error.lineno or 1
    column = error.offset or 1
    end_line = error.end_lineno or line
    end_column = error.end_offset or (column + 1)
    return {"line": line, "column": column, "endLine": end_line,
            "endColumn": end_column, "message": error.msg,
            "kind": type(error).__name__}

try:
    try:
        chunks = split_top_level_statements(source)
    except (tokenize.TokenError, IndentationError, SyntaxError):
        chunks = [(1, max(1, len(source.splitlines())), source)]
    found = []
    seen = set()
    for first, last, statement in chunks:
        # Keep each statement's surrounding suite intact, then recover from
        # one bad logical line at a time. This lets CPython report several
        # independent errors inside the same function/class/block as well as
        # errors in separate top-level statements.
        working_lines = statement.splitlines(keepends=True)
        if not working_lines:
            continue
        recovered_lines = set()
        for attempt in range(min(len(working_lines), 24)):
            candidate = "\n" * (first - 1) + "".join(working_lines)
            try:
                compile(candidate, "<editor>", "exec")
                break
            except SyntaxError as error:
                item = diagnostic(error)
                key = (item["line"], item["column"], item["message"])
                if key not in seen:
                    seen.add(key)
                    found.append(item)
                local_line = (error.lineno or first) - first
                if local_line < 0 or local_line >= len(working_lines) or local_line in recovered_lines:
                    break
                recovered_lines.add(local_line)
                original = working_lines[local_line]
                newline = "\r\n" if original.endswith("\r\n") else ("\n" if original.endswith("\n") else "")
                indentation = original[:len(original) - len(original.lstrip(" \t"))]
                stripped = original.lstrip(" \t")
                # Preserve a suite when a compound header is missing its
                # colon; otherwise replacing it with pass would create a
                # misleading unexpected-indent error on the body.
                if error.msg == "expected ':'" and stripped.split(None, 1)[0:1] and stripped.split(None, 1)[0] in ("if", "elif", "else", "for", "while", "def", "class", "try", "except", "finally", "with", "async", "match", "case"):
                    replacement = indentation + "if True:" + newline
                elif isinstance(error, IndentationError) and "unexpected indent" in error.msg:
                    replacement = "pass" + newline
                else:
                    replacement = indentation + "pass" + newline
                working_lines[local_line] = replacement
    print(json.dumps({"ok": not found, "diagnostics": found}))
except Exception:
    # If recovery/tokenization itself fails, fall back to CPython's canonical
    # first diagnostic rather than emitting guessed or fabricated errors.
    try:
        compile(source, "<editor>", "exec")
        print(json.dumps({"ok": True, "diagnostics": []}))
    except SyntaxError as error:
        print(json.dumps({"ok": False, "diagnostics": [diagnostic(error)]}))
""".trimIndent()

        val guestProject = shellQuote(guestProjectPath(project))
        val venv = projectVenvName(project.dir)
        val venvPython = "./$venv/bin/python"
        val pythonInvocation = if (
            Regex("^[A-Za-z0-9_.-]{1,64}$").matches(venv) && venvPythonReady(project.dir, venv)
        ) {
            "if [ -x ${shellQuote(venvPython)} ]; then ${shellQuote(venvPython)} -c ${shellQuote(script)}; else python3 -c ${shellQuote(script)}; fi"
        } else {
            "python3 -c ${shellQuote(script)}"
        }
        val raw = proot.runOnce("cd $guestProject || exit 1; $pythonInvocation", timeoutSec = PROCESS_TIMEOUT_SECONDS)
        val jsonLine = raw.lineSequence().map { it.trim() }.lastOrNull {
            it.startsWith("{") && it.endsWith("}")
        } ?: return null
        val json = JSONObject(jsonLine)
        if (json.optBoolean("ok", false)) return emptyList()
        val array = json.optJSONArray("diagnostics") ?: return emptyList()
        val parsed = mutableListOf<PythonSyntaxDiagnostic>()
        for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue
                val line = item.optInt("line", 1).coerceAtLeast(1)
                val column = item.optInt("column", 1).coerceAtLeast(1)
                val rawEndColumn = item.optInt("endColumn", column + 1)
                parsed.add(
                    PythonSyntaxDiagnostic(
                        line = line,
                        column = column,
                        endLine = item.optInt("endLine", line).coerceAtLeast(1),
                        endColumn = if (rawEndColumn > column) rawEndColumn else column + 1,
                        message = item.optString("message", "Invalid Python syntax").ifBlank { "Invalid Python syntax" },
                        kind = item.optString("kind", "SyntaxError").ifBlank { "SyntaxError" },
                    )
                )
        }
        return parsed
    }

    private fun shellQuote(value: String): String = "'" + value.replace("'", "'\\''") + "'"

    override fun close() {
        jobs.values.forEach { it.cancel() }
        jobs.clear()
        scope.cancel()
    }

    companion object {
        private const val MAX_SOURCE_CHARS = 48_000
        private const val MAX_SOURCE_BYTES = 64 * 1024
        private const val DEBOUNCE_MS = 250L
        private const val PROCESS_TIMEOUT_SECONDS = 5L
    }
}
