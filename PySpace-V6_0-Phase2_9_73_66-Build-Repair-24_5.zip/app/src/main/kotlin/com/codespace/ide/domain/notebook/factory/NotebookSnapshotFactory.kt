package com.codespace.ide.domain.notebook.factory

import com.codespace.ide.domain.notebook.model.NbCellSnapshot
import com.codespace.ide.domain.notebook.model.NbDocSnapshot
import java.security.SecureRandom

/** Creates valid, UI-independent nbformat 4.5 notebook snapshots. */
object NotebookSnapshotFactory {
    private val random = SecureRandom()

    fun newCellId(): String {
        val bytes = ByteArray(4)
        random.nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun emptyNotebook(): NbDocSnapshot {
        val metadata = """{"kernelspec":{"display_name":"Python 3","language":"python","name":"python3"},"language_info":{"name":"python"}}"""
        return NbDocSnapshot(
            cells = listOf(
                NbCellSnapshot(
                    id = newCellId(), type = "code", source = "", execCount = null,
                    extraJson = "{}", outputs = emptyList(),
                ),
            ),
            metadataJson = metadata,
            nbformat = 4,
            minor = 5,
            useIds = true,
        )
    }
}
