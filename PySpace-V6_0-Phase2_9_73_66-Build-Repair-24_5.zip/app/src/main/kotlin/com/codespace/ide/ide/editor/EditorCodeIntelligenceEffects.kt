package com.codespace.ide.ide.editor

import androidx.compose.runtime.Composable
import androidx.compose.ui.text.input.TextFieldValue
import com.codespace.ide.ide.codeintel.PythonCompletionItem
import com.codespace.ide.ide.codeintel.PythonLspController
import com.codespace.ide.ide.codeintel.PythonSignatureInfo
import java.io.File

/**
 * Composition boundary for the editor's asynchronous language-intelligence
 * requests. It deliberately owns no document or popup state: PyEditor passes
 * immutable snapshots and explicit setters, while the focused effect
 * components retain their existing debounce, cancellation and stale-result
 * protections.
 */
@Composable
internal fun EditorCodeIntelligenceEffects(
    file: File,
    field: TextFieldValue,
    isPythonLanguage: Boolean,
    showCompletionPopup: Boolean,
    editorLanguage: String,
    completionEditVersion: Int,
    completionTriggerCaret: Int,
    lastLspCompletionEditVersion: Int,
    environmentRevision: Long,
    lastLspCompletionEnvironmentRevision: Long,
    completionItems: List<PythonCompletionItem>,
    controller: PythonLspController?,
    onCompletionItemsChanged: (List<PythonCompletionItem>) -> Unit,
    onCompletionRangeChanged: (Pair<Int, Int>) -> Unit,
    onLastEditVersionChanged: (Int) -> Unit,
    onLastEnvironmentRevisionChanged: (Long) -> Unit,
    onSignatureInfoChanged: (PythonSignatureInfo?) -> Unit
) {
    EditorSignatureHelpEffect(
        file = file,
        source = field.text,
        caret = field.selection.start,
        selectionCollapsed = field.selection.collapsed,
        isPythonLanguage = isPythonLanguage,
        controller = controller,
        onResult = onSignatureInfoChanged
    )

    EditorCompletionEffect(
        file = file,
        field = field,
        isPythonLanguage = isPythonLanguage,
        showCompletionPopup = showCompletionPopup,
        editorLanguage = editorLanguage,
        completionEditVersion = completionEditVersion,
        completionTriggerCaret = completionTriggerCaret,
        lastLspCompletionEditVersion = lastLspCompletionEditVersion,
        environmentRevision = environmentRevision,
        lastLspCompletionEnvironmentRevision = lastLspCompletionEnvironmentRevision,
        currentItems = completionItems,
        controller = controller,
        onItemsChanged = onCompletionItemsChanged,
        onRangeChanged = onCompletionRangeChanged,
        onLastEditVersionChanged = onLastEditVersionChanged,
        onLastEnvironmentRevisionChanged = onLastEnvironmentRevisionChanged
    )
}
