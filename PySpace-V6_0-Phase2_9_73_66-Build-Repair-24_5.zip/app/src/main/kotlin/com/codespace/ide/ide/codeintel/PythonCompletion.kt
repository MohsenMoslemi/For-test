package com.codespace.ide.ide.codeintel

import java.io.File
import com.codespace.ide.ide.PythonImportManager

/** A completion candidate indexed from the current Python source. */
data class PythonCompletionItem(
    val name: String,
    val kind: String,
    val detail: String = "",
    val callable: Boolean = false,
    /** Lower values are ranked first. */
    val priority: Int = 50,
    /** Actual LSP insertion text; defaults to the visible label for legacy providers. */
    val insertText: String = name,
    /** Optional import inserted atomically with this completion. */
    val autoImportStatement: String? = null,
    /** Human-readable origin, e.g. Python Standard Library or pip package name. */
    val autoImportSource: String? = null,
    /** Original-source insertion offset for [autoImportStatement]. */
    val autoImportOffset: Int = -1,
)

data class PythonCompletionResult(
    val replaceStart: Int,
    val replaceEnd: Int,
    val items: List<PythonCompletionItem>,
)

/**
 * Lightweight, offline Python completion engine.
 *
 * It is intentionally conservative: syntactic contexts that define a name
 * (function parameters, import aliases, assignment targets) do not open a
 * suggestion list. Import statements have an isolated candidate set. In
 * expression contexts, only declarations from visible scopes are indexed;
 * arbitrary identifiers found in source text are never promoted to symbols.
 */
object PythonCompletion {
    private const val MAX_SOURCE_CHARS = 250_000
    private const val MAX_RESULTS = 24

    private val identifier = Regex("[A-Za-z_][A-Za-z0-9_]*")
    private val functionHeader = Regex("(?m)^([ \\t]*)(?:async[ \\t]+)?def[ \\t]+([A-Za-z_][A-Za-z0-9_]*)[ \\t]*\\(")
    private val classHeader = Regex("(?m)^([ \\t]*)class[ \\t]+([A-Za-z_][A-Za-z0-9_]*)")
    private val assignmentOperator = Regex("(?<![=!<>:])(?:\\*\\*=|//=|>>=|<<=|\\+=|-=|\\*=|/=|%=|&=|\\|=|\\^=|=(?!=))")

    private val modules = setOf(
        "abc", "argparse", "array", "asyncio", "base64", "collections", "concurrent", "contextlib",
        "copy", "csv", "dataclasses", "datetime", "decimal", "enum", "fractions", "functools",
        "hashlib", "heapq", "io", "itertools", "json", "logging", "math", "multiprocessing",
        "operator", "os", " pathlib", "pathlib", "pickle", "platform", "random", "re", " shutil",
        "shutil", "socket", "sqlite3", "statistics", "string", "subprocess", "sys", " tempfile",
        "tempfile", "threading", "time", " tkinter", "tkinter", "typing", "unittest", "urllib",
        "uuid", "warnings", "zipfile", "flask", "matplotlib", "numpy", "pandas", "pygame", "requests",
        "cv2", "kivy"
    ).map { it.trim() }.toSet()

    private val keywords = setOf(
        "False", "None", "True", "and", "as", "assert", "async", "await", "break", "class",
        "continue", "def", "del", "elif", "else", "except", "finally", "for", "from", "global",
        "if", "import", "in", "is", "lambda", "nonlocal", "not", "or", "pass", "raise", "return",
        "try", "while", "with", "yield"
    )

    private val builtins = mapOf(
        "abs" to "abs(x)", "aiter" to "aiter(async_iterable)", "all" to "all(iterable)",
        "anext" to "anext(async_iterator)", "any" to "any(iterable)", "ascii" to "ascii(object)",
        "bin" to "bin(x)", "bool" to "bool(x)", "breakpoint" to "breakpoint()", "bytearray" to "bytearray(...) ",
        "bytes" to "bytes(...) ", "callable" to "callable(object)", "chr" to "chr(i)",
        "classmethod" to "classmethod(function)", "compile" to "compile(source, filename, mode)",
        "complex" to "complex(real, imag)", "delattr" to "delattr(object, name)", "dict" to "dict(...) ",
        "dir" to "dir([object])", "divmod" to "divmod(a, b)", "enumerate" to "enumerate(iterable)",
        "eval" to "eval(expression)", "exec" to "exec(object)", "filter" to "filter(function, iterable)",
        "float" to "float(x)", "format" to "format(value)", "frozenset" to "frozenset(...) ",
        "getattr" to "getattr(object, name)", "globals" to "globals()", "hasattr" to "hasattr(object, name)",
        "hash" to "hash(object)", "help" to "help([object])", "hex" to "hex(x)", "id" to "id(object)",
        "input" to "input([prompt])", "int" to "int(x)", "isinstance" to "isinstance(obj, type)",
        "issubclass" to "issubclass(cls, classinfo)", "iter" to "iter(object)", "len" to "len(s)",
        "list" to "list(iterable)", "locals" to "locals()", "map" to "map(function, iterable)",
        "max" to "max(iterable)", "memoryview" to "memoryview(object)", "min" to "min(iterable)",
        "next" to "next(iterator)", "object" to "object()", "oct" to "oct(x)", "open" to "open(file, mode)",
        "ord" to "ord(c)", "pow" to "pow(base, exp)", "print" to "print(*objects)",
        "property" to "property(...) ", "range" to "range(stop)", "repr" to "repr(object)",
        "reversed" to "reversed(sequence)", "round" to "round(number)", "set" to "set(iterable)",
        "setattr" to "setattr(object, name, value)", "slice" to "slice(...) ", "sorted" to "sorted(iterable)",
        "staticmethod" to "staticmethod(function)", "str" to "str(object)", "sum" to "sum(iterable)",
        "super" to "super()", "tuple" to "tuple(iterable)", "type" to "type(object)",
        "vars" to "vars([object])", "zip" to "zip(*iterables)", "__import__" to "__import__(name)"
    )

    private val members = mapOf(
        "math" to listOf("ceil", "copysign", "cos", "degrees", "e", "exp", "fabs", "floor", "inf", "isfinite", "isnan", "log", "pi", "pow", "radians", "sin", "sqrt", "tan"),
        "random" to listOf("choice", "choices", "randint", "randrange", "random", "sample", "seed", "shuffle", "uniform"),
        "os" to listOf("chdir", "environ", "getcwd", "listdir", "makedirs", "mkdir", "path", "remove", "rename", "rmdir"),
        "os.path" to listOf("abspath", "basename", "dirname", "exists", "isdir", "isfile", "join", "split"),
        "sys" to listOf("argv", "exit", "path", "platform", "version"),
        "json" to listOf("dump", "dumps", "load", "loads"),
        "time" to listOf("sleep", "time", "strftime", "localtime"),
        "pathlib" to listOf("Path", "PurePath"),
        "dataclasses" to listOf("asdict", "astuple", "dataclass", "field", "fields", "is_dataclass", "make_dataclass", "replace"),
        "np" to listOf("array", "arange", "asarray", "concatenate", "dot", "linspace", "load", "mean", "ones", "reshape", "save", "shape", "sqrt", "std", "sum", "zeros"),
        "numpy.ndarray" to listOf("T", "all", "any", "argmax", "argmin", "argsort", "astype", "clip", "copy", "cumprod", "cumsum", "diagonal", "dtype", "flatten", "imag", "item", "max", "mean", "min", "ndim", "nbytes", "prod", "real", "repeat", "reshape", "round", "shape", "size", "sort", "squeeze", "std", "sum", "swapaxes", "tolist", "trace", "transpose", "var", "view"),
        "numpy" to listOf("array", "arange", "asarray", "concatenate", "dot", "linspace", "load", "mean", "ones", "reshape", "save", "shape", "sqrt", "std", "sum", "zeros"),
        "pd" to listOf("DataFrame", "Series", "concat", "read_csv", "read_excel", "read_json"),
        "pandas" to listOf("DataFrame", "Series", "concat", "read_csv", "read_excel", "read_json"),
        "plt" to listOf("bar", "figure", "hist", "imshow", "legend", "plot", "scatter", "show", "subplots", "title", "xlabel", "ylabel"),
        "cv2" to listOf("VideoCapture", "cvtColor", "imread", "imshow", "imwrite", "rectangle", "resize", "waitKey"),
        "pygame" to listOf("display", "draw", "event", "font", "image", "init", "quit", "time")
    )

    private data class RawFunction(val name: String, val indent: Int, val headerStart: Int, val bodyStart: Int, val parameters: List<String>)

    private data class FunctionInfo(
        val name: String,
        val indent: Int,
        val headerStart: Int,
        val bodyStart: Int,
        val bodyEnd: Int,
        val parameters: List<String>,
    )

    private data class ClassInfo(val name: String, val indent: Int, val headerStart: Int, val bodyStart: Int, val bodyEnd: Int)

    private data class Declaration(
        val name: String,
        val kind: String,
        val detail: String = "",
        val ownerFunction: Int = -1,
        val ownerClass: Int = -1,
        val priority: Int = 20,
    )

    private data class ImportContext(val mode: Int, val module: String? = null)
    // mode 1 = import module; mode 2 = from module import member

    /**
     * Re-check the identifier under the caret without requiring a text edit.
     * Used after package installation and when the user taps an existing name.
     */
    fun autoImportSuggestionsForIdentifier(
        source: String,
        tokenStart: Int,
        tokenEnd: Int,
        installedPackages: Set<String>?,
        projectRoot: File? = null,
    ): List<PythonCompletionItem> {
        if (source.length > MAX_SOURCE_CHARS || tokenStart !in 0..source.length ||
            tokenEnd !in tokenStart..source.length) return emptyList()
        val token = source.substring(tokenStart, tokenEnd)
        if (!identifier.matches(token)) return emptyList()
        if (isInsideStringOrComment(source, tokenStart)) return emptyList()
        val catalog = PythonAutoImportCatalog.suggestions(
            source = source,
            caret = tokenEnd,
            prefix = token,
            installedPackages = installedPackages,
            includeExactMatch = true,
        )
        val local = localProjectAutoImports(source, tokenEnd, token, projectRoot, includeExact = true)
        return (catalog + local).distinctBy { it.name to it.autoImportStatement }
            .sortedWith(compareBy<PythonCompletionItem> { it.priority }.thenBy { it.name.lowercase() }).take(MAX_RESULTS)
    }

    fun complete(source: String, caret: Int, installedPackages: Set<String>? = null, projectRoot: File? = null): PythonCompletionResult? {
        val cursor = caret.coerceIn(0, source.length)
        if (source.length > MAX_SOURCE_CHARS || isInsideStringOrComment(source, cursor)) return null

        var replaceStart = cursor
        while (replaceStart > 0 && isIdentifierPart(source[replaceStart - 1])) replaceStart--
        val prefix = source.substring(replaceStart, cursor)
        if (prefix.length > 40) return null

        val code = maskStringsAndComments(source)
        // A caret at offset 0 must always have a line start of 0. Searching
        // from index 0 otherwise matches a leading newline and can produce
        // lineStart == 1, causing substring(1, 0) to throw.
        val lineStart = if (cursor == 0) {
            0
        } else {
            (code.lastIndexOf('\n', cursor - 1) + 1).coerceIn(0, cursor)
        }
        val linePrefix = code.substring(lineStart, cursor)
        // Never offer completions while the user is declaring a new name.
        if (isInsideFunctionParameterList(code, cursor) || isInsideClassHeader(code, cursor)) return null
        val lineEndForTarget = code.indexOf('\n', lineStart).let { if (it < 0) code.length else it }
        val lineFullForTarget = code.substring(lineStart, lineEndForTarget)
        if (isDefiningAssignmentTarget(lineFullForTarget, cursor - lineStart)) return null

        val importContext = detectImportContext(linePrefix)
        if (importContext != null) {
            // Import statements are a closed context: no local variables,
            // builtins, keywords, or names from elsewhere in the file leak in.
            if (prefix.isEmpty()) return null
            val items = linkedMapOf<String, PythonCompletionItem>()
            val projectIndex = PythonProjectSymbolIndex.snapshot(projectRoot)
            if (importContext.mode == 1) {
                projectIndex.modules.forEach { module ->
                    if (matches(module.name, prefix)) items[module.name] = PythonCompletionItem(module.name, "module", "Project · ${module.fileName}", priority = 1)
                }
                modules.forEach { module ->
                    if (isOptionalModule(module) && !isAvailable(module, installedPackages)) return@forEach
                    if (matches(module, prefix)) items[module] = PythonCompletionItem(module, "module", priority = 0)
                }
            } else {
                val module = importContext.module.orEmpty()
                val localSymbols = projectIndex.symbols.filter { it.module == module }
                localSymbols.forEach { symbol ->
                    if (matches(symbol.name, prefix)) items[symbol.name] = PythonCompletionItem(
                        symbol.name, if (symbol.callable) "function" else "variable",
                        "Project · ${symbol.fileName}", symbol.callable, 1
                    )
                }
                val names = if (isOptionalModule(module) && !isAvailable(module, installedPackages)) emptyList()
                    else members[module] ?: emptyList()
                names.forEach { name ->
                    if (matches(name, prefix)) {
                        val callable = name !in setOf("pi", "e", "inf", "environ", "path", "argv", "platform", "version")
                        items[name] = PythonCompletionItem(name, if (callable) "member" else "attribute", importContext.module.orEmpty(), callable, 0)
                    }
                }
            }
            return buildResult(replaceStart, cursor, prefix, items)
        }

        val functions = parseFunctions(code)
        val classes = parseClasses(code)
        val currentFunction = findEnclosingFunction(functions, cursor)
        val currentClass = findEnclosingClass(classes, cursor)

        val beforePrefix = code.substring(0, replaceStart).trimEnd()
        val dotContext = beforePrefix.endsWith('.')
        if (dotContext) {
            // An empty prefix immediately after a dot is intentional: show the
            // complete member list (e.g. math.) rather than waiting for a letter.
            val beforeDot = beforePrefix.dropLast(1)
            val owner = Regex("([A-Za-z_][A-Za-z0-9_.]*)$").find(beforeDot)?.groupValues?.get(1) ?: return null
            val inferredType = inferReceiverType(code, owner)
            val moduleOwner = owner.substringBefore('.')
            val optionalOwnerUnavailable = isOptionalModule(moduleOwner) && !isAvailable(moduleOwner, installedPackages)
            val inferredNumpyUnavailable = inferredType == "numpy.ndarray" && !isAvailable("numpy", installedPackages)
            if (optionalOwnerUnavailable || inferredNumpyUnavailable) return null
            val names = if (owner == "self" && currentClass != null) {
                collectDeclarations(code, functions, classes)
                    .filter { it.ownerClass == currentClass.headerStart && it.kind in setOf("attribute", "function") }
                    .map { it.name }.distinct()
            } else members[owner] ?: inferredType?.let { members[it] } ?: return null
            val items = linkedMapOf<String, PythonCompletionItem>()
            names.forEach { rawName ->
                val name = rawName.trim()
                if (name.isNotEmpty() && matches(name, prefix)) {
                    val callable = name !in setOf("pi", "e", "inf", "argv", "path", "platform", "version", "display", "draw", "event", "font", "image", "time")
                    items[name] = PythonCompletionItem(name, if (callable) "member" else "attribute", owner, callable, 0)
                }
            }
            return buildResult(replaceStart, cursor, prefix, items)
        }

        if (prefix.isEmpty()) return null
        val visibleFunctionIndexes = visibleFunctionIndexes(functions, currentFunction)
        val declarations = collectDeclarations(code, functions, classes)
        val candidates = linkedMapOf<String, PythonCompletionItem>()

        declarations.forEach { declaration ->
            val functionVisible = declaration.ownerFunction == -1 || declaration.ownerFunction in visibleFunctionIndexes
            val classVisible = declaration.ownerClass == -1 || declaration.ownerClass == currentClass?.headerStart
            if (!functionVisible || !classVisible || !matches(declaration.name, prefix, allowExact = true)) return@forEach
            val adjustedPriority = when {
                declaration.kind == "parameter" && declaration.ownerFunction == currentFunction?.headerStart -> 0
                declaration.ownerFunction == currentFunction?.headerStart -> declaration.priority.coerceAtMost(3)
                declaration.ownerFunction == -1 -> declaration.priority + 8
                else -> declaration.priority + 14
            }
            val importedMember = declaration.detail.substringAfterLast('.', declaration.detail)
            val isCallableImport = declaration.kind == "import" && importedMember !in setOf("pi", "e", "inf", "nan", "argv", "path", "version")
            val item = PythonCompletionItem(
                declaration.name, declaration.kind, declaration.detail,
                declaration.kind in setOf("function", "class") || isCallableImport,
                adjustedPriority
            )
            val old = candidates[declaration.name]
            if (old == null || item.priority < old.priority) candidates[declaration.name] = item
        }

        // Builtins and keywords are useful in expression contexts, but are
        // intentionally lower-ranked than every declared name in this file.
        builtins.forEach { (name, signature) ->
            if (matches(name, prefix)) candidates.putIfAbsent(name, PythonCompletionItem(name, "builtin", signature, true, 60))
        }
        keywords.forEach { name ->
            if (matches(name, prefix)) candidates.putIfAbsent(name, PythonCompletionItem(name, "keyword", priority = 70))
        }
        modules.forEach { name ->
            if (isOptionalModule(name) && !isAvailable(name, installedPackages)) return@forEach
            if (matches(name, prefix)) candidates.putIfAbsent(name, PythonCompletionItem(name, "module", priority = 80))
        }

        // Third-party auto-imports are offered only for packages present in
        // this project's venv. Applying one inserts the import and symbol as
        // a single editor transaction, so Undo restores the original buffer.
        (PythonAutoImportCatalog.suggestions(source, cursor, prefix, installedPackages) +
            localProjectAutoImports(source, cursor, prefix, projectRoot, includeExact = false)).forEach { item ->
            val existing = candidates[item.name]
            if (existing == null || existing.kind == "module") candidates[item.name] = item
        }

        return buildResult(replaceStart, cursor, prefix, candidates)
    }

    private fun localProjectAutoImports(
        source: String, caret: Int, prefix: String, projectRoot: File?, includeExact: Boolean
    ): List<PythonCompletionItem> {
        if (projectRoot == null || prefix.isEmpty() || !identifier.matches(prefix)) return emptyList()
        val contextLine = source.substring(source.lastIndexOf('\n', (caret - 1).coerceAtLeast(0)) + 1, caret)
        if (detectImportContext(contextLine) != null || isInsideStringOrComment(source, caret)) return emptyList()
        val snapshot = PythonProjectSymbolIndex.snapshot(projectRoot)
        val bound = PythonSourceBindings.from(source)
        val offsetMarker = "# __PYSPACE_LOCAL_IMPORT_OFFSET__"
        val insertionOffset = com.codespace.ide.ide.PythonImportManager.insert(source, offsetMarker).first.indexOf(offsetMarker).coerceIn(0, source.length)
        return snapshot.symbols.asSequence()
            .filter { !bound.contains(it.name) && it.name.startsWith(prefix, ignoreCase = true) }
            .filter { includeExact || !it.name.equals(prefix, ignoreCase = true) }
            .map { symbol ->
                val statement = "from ${symbol.module} import ${symbol.name}"
                PythonCompletionItem(
                    name = symbol.name,
                    kind = "auto_import",
                    detail = "Quick import · $statement",
                    callable = symbol.callable,
                    priority = 4,
                    autoImportStatement = statement,
                    autoImportSource = "Project · ${symbol.fileName}",
                    autoImportOffset = insertionOffset,
                )
            }.take(MAX_RESULTS).toList()
    }

    private fun isOptionalModule(module: String): Boolean = module in setOf(
        "numpy", "np", "pandas", "pd", "matplotlib", "plt", "pygame", "cv2", "kivy", "flask", "requests"
    )

    private fun isAvailable(module: String, installedPackages: Set<String>?): Boolean {
        if (installedPackages == null) return true
        val candidates = when (module) {
            "numpy" -> setOf("numpy")
            "pandas" -> setOf("pandas")
            "matplotlib" -> setOf("matplotlib")
            "pygame" -> setOf("pygame")
            "cv2" -> setOf("opencv-python", "opencv-python-headless", "opencv-contrib-python", "opencv-contrib-python-headless")
            "kivy" -> setOf("kivy")
            "flask" -> setOf("flask")
            "requests" -> setOf("requests")
            else -> emptySet()
        }
        return installedPackages.any { it in candidates }
    }

    /** Infer common receiver types from simple assignments without importing user code. */
    private fun inferReceiverType(source: String, receiver: String): String? {
        val escaped = Regex.escape(receiver)
        val assignment = Regex("(?m)^\\s*$escaped\\s*(?::[^=]+)?=\\s*(.+?)\\s*$")
        val rhs = assignment.findAll(source).lastOrNull()?.groupValues?.get(1)?.trim() ?: return null
        return when {
            Regex("^(?:[A-Za-z_][A-Za-z0-9_]*\\.)*array\\s*\\(").containsMatchIn(rhs) -> "numpy.ndarray"
            Regex("^(?:[A-Za-z_][A-Za-z0-9_]*\\.)*asarray\\s*\\(").containsMatchIn(rhs) -> "numpy.ndarray"
            rhs.startsWith("[") -> "list"
            rhs.startsWith("{") -> if (":" in rhs) "dict" else "set"
            rhs.startsWith("(") -> "tuple"
            rhs.startsWith("\"\"") || rhs.startsWith("'") -> "str"
            rhs.matches(Regex("[-+]?\\d+")) -> "int"
            rhs.matches(Regex("[-+]?(?:\\d+\\.\\d*|\\d*\\.\\d+)(?:[eE][-+]?\\d+)?")) -> "float"
            else -> null
        }
    }

    private fun buildResult(
        replaceStart: Int,
        cursor: Int,
        prefix: String,
        candidates: Map<String, PythonCompletionItem>,
    ): PythonCompletionResult? {
        val filtered = candidates.values
            .filter { matches(it.name, prefix, allowExact = it.kind in setOf("parameter", "variable", "function", "class", "import", "attribute")) }
            .sortedWith(compareBy<PythonCompletionItem> { it.priority }
                .thenBy { !it.name.startsWith(prefix, ignoreCase = true) }
                .thenBy { it.name.length }
                .thenBy { it.name.lowercase() })
            .distinctBy { it.name }
            .take(MAX_RESULTS)
        return if (filtered.isEmpty()) null else PythonCompletionResult(replaceStart, cursor, filtered)
    }

    private fun matches(name: String, prefix: String, allowExact: Boolean = false): Boolean =
        name.startsWith(prefix, ignoreCase = true) && (allowExact || !name.equals(prefix, ignoreCase = true))

    private fun parseFunctions(code: String): List<FunctionInfo> {
        val rawFunctions = mutableListOf<RawFunction>()
        functionHeader.findAll(code).take(500).forEach { match ->
            val open = match.range.last
            val close = findMatching(code, open, '(', ')')
            if (close < 0) return@forEach
            var colon = close + 1
            while (colon < code.length && (code[colon] == ' ' || code[colon] == '\t')) colon++
            if (colon < code.length && code[colon] == '-' && colon + 1 < code.length && code[colon + 1] == '>') {
                colon += 2
                var depth = 0
                while (colon < code.length) {
                    when (code[colon]) {
                        '(', '[', '{' -> depth++
                        ')', ']', '}' -> if (depth > 0) depth--
                        ':' -> if (depth == 0) break
                    }
                    colon++
                }
            }
            if (colon >= code.length || code[colon] != ':') return@forEach
            val params = splitTopLevelParameters(code.substring(open + 1, close)).mapNotNull { raw ->
                val cleaned = raw.trim().removePrefix("**").removePrefix("*")
                Regex("^[A-Za-z_][A-Za-z0-9_]*").find(cleaned)?.value
            }.distinct()
            rawFunctions += RawFunction(match.groupValues[2], match.groupValues[1].length, match.range.first, colon + 1, params)
        }
        return rawFunctions.map { raw ->
            val bodyLine = code.indexOf('\n', raw.bodyStart).let { if (it < 0) code.length else it + 1 }
            var end = code.length
            var pos = bodyLine
            while (pos < code.length) {
                val next = code.indexOf('\n', pos).let { if (it < 0) code.length else it }
                val line = code.substring(pos, next)
                if (line.isNotBlank() && !line.trimStart().startsWith("#")) {
                    val leading = line.takeWhile { it == ' ' || it == '\t' }.length
                    if (leading <= raw.indent) { end = pos; break }
                }
                pos = (next + 1).coerceAtMost(code.length)
            }
            FunctionInfo(raw.name, raw.indent, raw.headerStart, raw.bodyStart, end, raw.parameters)
        }
    }

    private fun parseClasses(code: String): List<ClassInfo> {
        return classHeader.findAll(code).take(300).mapNotNull { match ->
            val colon = findSuiteColon(code, match.range.last + 1) ?: return@mapNotNull null
            val bodyStart = colon + 1
            val bodyLine = code.indexOf('\n', bodyStart).let { if (it < 0) code.length else it + 1 }
            var end = code.length
            var pos = bodyLine
            while (pos < code.length) {
                val next = code.indexOf('\n', pos).let { if (it < 0) code.length else it }
                val line = code.substring(pos, next)
                if (line.isNotBlank() && !line.trimStart().startsWith("#")) {
                    val leading = line.takeWhile { it == ' ' || it == '\t' }.length
                    if (leading <= match.groupValues[1].length) { end = pos; break }
                }
                pos = (next + 1).coerceAtMost(code.length)
            }
            ClassInfo(match.groupValues[2], match.groupValues[1].length, match.range.first, bodyStart, end)
        }.toList()
    }

    private fun findSuiteColon(code: String, start: Int): Int? {
        var depth = 0
        var i = start
        while (i < code.length) {
            when (code[i]) {
                '(', '[', '{' -> depth++
                ')', ']', '}' -> if (depth > 0) depth--
                ':' -> if (depth == 0) return i
                '\n' -> if (depth == 0) return null
            }
            i++
        }
        return null
    }

    private fun findEnclosingClass(classes: List<ClassInfo>, cursor: Int): ClassInfo? =
        classes.filter { cursor >= it.bodyStart && cursor <= it.bodyEnd }.maxByOrNull { it.indent }

    private fun findEnclosingFunction(functions: List<FunctionInfo>, cursor: Int): FunctionInfo? {
        return functions.filter { cursor >= it.bodyStart && cursor <= it.bodyEnd }
            .maxByOrNull { it.indent }
    }

    private fun visibleFunctionIndexes(functions: List<FunctionInfo>, current: FunctionInfo?): Set<Int> {
        if (current == null) return emptySet()
        return functions.filter { candidate ->
            candidate.headerStart == current.headerStart ||
                (candidate.bodyStart <= current.headerStart && current.headerStart < candidate.bodyEnd)
        }.map { it.headerStart }.toSet()
    }

    private fun collectDeclarations(code: String, functions: List<FunctionInfo>, classes: List<ClassInfo>): List<Declaration> {
        val out = linkedMapOf<String, Declaration>()
        fun ownerFunctionAt(offset: Int): Int = functions.filter { offset >= it.bodyStart && offset <= it.bodyEnd }
            .maxByOrNull { it.indent }?.headerStart ?: -1
        fun ownerClassAt(offset: Int): Int = classes.filter { offset >= it.bodyStart && offset <= it.bodyEnd }
            .maxByOrNull { it.indent }?.headerStart ?: -1
        val globalNamesByFunction = mutableMapOf<Int, MutableSet<String>>()
        val nonlocalNamesByFunction = mutableMapOf<Int, MutableSet<String>>()
        var scopeOffset = 0
        code.lineSequence().forEach { raw ->
            val line = raw.trimStart()
            val owner = ownerFunctionAt(scopeOffset + (raw.length - line.length))
            if (owner != -1 && line.startsWith("global ")) {
                globalNamesByFunction.getOrPut(owner) { mutableSetOf() }.addAll(identifier.findAll(line.removePrefix("global ")).map { it.value })
            } else if (owner != -1 && line.startsWith("nonlocal ")) {
                nonlocalNamesByFunction.getOrPut(owner) { mutableSetOf() }.addAll(identifier.findAll(line.removePrefix("nonlocal ")).map { it.value })
            }
            scopeOffset += raw.length + 1
        }
        fun effectiveOwners(name: String, owner: Int, ownerClass: Int, offset: Int): Pair<Int, Int> {
            if (owner == -1) return owner to ownerClass
            if (name in globalNamesByFunction[owner].orEmpty()) return -1 to -1
            if (name in nonlocalNamesByFunction[owner].orEmpty()) {
                val parent = functions.filter { it.headerStart != owner && offset >= it.bodyStart && offset <= it.bodyEnd }
                    .maxByOrNull { it.indent }
                if (parent != null) return parent.headerStart to ownerClass
            }
            return owner to ownerClass
        }
        fun add(name: String, kind: String, detail: String = "", owner: Int = -1, ownerClass: Int = -1, priority: Int = 20) {
            if (!name.matches(identifier) || name in keywords) return
            val key = "$name:$owner:$ownerClass"
            val value = Declaration(name, kind, detail, owner, ownerClass, priority)
            val old = out[key]
            if (old == null || value.priority < old.priority) out[key] = value
        }

        functions.forEach { fn ->
            add(fn.name, "function", owner = ownerFunctionAt(fn.headerStart), ownerClass = ownerClassAt(fn.headerStart), priority = 4)
            fn.parameters.forEach { add(it, "parameter", fn.name, fn.headerStart, ownerClassAt(fn.headerStart), 1) }
        }
        classes.forEach { cls ->
            add(cls.name, "class", owner = ownerFunctionAt(cls.headerStart), ownerClass = ownerClassAt(cls.headerStart), priority = 4)
        }

        var offset = 0
        code.lineSequence().forEach { raw ->
            val line = raw.trimStart()
            val lineOffset = offset + (raw.length - line.length)
            val owner = ownerFunctionAt(lineOffset)
            val ownerClass = ownerClassAt(lineOffset)
            if (line.isNotBlank() && !line.startsWith("#") &&
                !line.startsWith("def ") && !line.startsWith("async def ") && !line.startsWith("class ")) {

                // Import declarations are indexed under their bound name.
                if (line.startsWith("import ")) {
                    line.removePrefix("import ").split(',').forEach { part ->
                        val pieces = part.trim().split(Regex("\\s+as\\s+"))
                        val imported = pieces.firstOrNull()?.trim().orEmpty()
                        if (imported.isNotEmpty()) {
                            val base = imported.substringBefore('.')
                            val alias = pieces.getOrNull(1)?.trim().orEmpty().ifBlank { base }
                            val effective = effectiveOwners(alias, owner, ownerClass, lineOffset)
                            add(alias, "module", base, effective.first, effective.second, 6)
                        }
                    }
                } else if (line.startsWith("from ") && " import " in line) {
                    val module = line.substringAfter("from ").substringBefore(" import ").trim()
                    line.substringAfter(" import ").removePrefix("(").removeSuffix(")").split(',').forEach { part ->
                        val pieces = part.trim().split(Regex("\\s+as\\s+"))
                        val imported = pieces.firstOrNull()?.trim().orEmpty()
                        val alias = pieces.getOrNull(1)?.trim().orEmpty().ifBlank { imported }
                        val effective = effectiveOwners(alias, owner, ownerClass, lineOffset)
                        add(alias, "import", "$module.$imported", effective.first, effective.second, 7)
                    }
                }

                // Assignment targets: simple and destructured names, excluding
                // attribute targets (obj.x) and names inside RHS expressions.
                val op = assignmentOperator.find(line)
                if (op != null) {
                    val lhs = line.substring(0, op.range.first).trim()
                    if (lhs.isNotEmpty() && !lhs.startsWith("if ") && !lhs.startsWith("while ")) {
                        collectAssignmentTargetNames(lhs).forEach { name ->
                            if (name !in setOf("self", "cls")) {
                                val effective = effectiveOwners(name, owner, ownerClass, lineOffset)
                                add(name, "variable", owner = effective.first, ownerClass = effective.second, priority = 2)
                            }
                        }
                    }
                }

                Regex("\\bfor\\s+(.+?)\\s+in\\b").find(line)?.groupValues?.getOrNull(1)?.let { targets ->
                    collectAssignmentTargetNames(targets).forEach { name ->
                        val effective = effectiveOwners(name, owner, ownerClass, lineOffset)
                        add(name, "variable", owner = effective.first, ownerClass = effective.second, priority = 3)
                    }
                }
                if (!line.startsWith("import ") && !line.startsWith("from ")) {
                    Regex("\\bas\\s+([A-Za-z_][A-Za-z0-9_]*)").findAll(line).forEach { match ->
                        val name = match.groupValues[1]
                        val effective = effectiveOwners(name, owner, ownerClass, lineOffset)
                        add(name, "variable", owner = effective.first, ownerClass = effective.second, priority = 3)
                    }
                }
                Regex("\\bexcept(?:\\s+[^:]+)?\\s+as\\s+([A-Za-z_][A-Za-z0-9_]*)").find(line)?.groupValues?.getOrNull(1)?.let {
                    add(it, "variable", owner = owner, ownerClass = ownerClass, priority = 3)
                }
                Regex("^([A-Za-z_][A-Za-z0-9_]*)\\s*:\\s*[^=]+$").find(line)?.groupValues?.getOrNull(1)?.let { name ->
                    val effective = effectiveOwners(name, owner, ownerClass, lineOffset)
                    add(name, "variable", owner = effective.first, ownerClass = effective.second, priority = 2)
                }
                Regex("(?<![A-Za-z0-9_])([A-Za-z_][A-Za-z0-9_]*)\\s*:=").find(line)?.groupValues?.getOrNull(1)?.let { name ->
                    val effective = effectiveOwners(name, owner, ownerClass, lineOffset)
                    add(name, "variable", owner = effective.first, ownerClass = effective.second, priority = 2)
                }
                Regex("\\bself\\.([A-Za-z_][A-Za-z0-9_]*)\\s*(?:=|\\+=|-=|\\*=|/=)").findAll(line).forEach { match ->
                    if (ownerClass != -1) add(match.groupValues[1], "attribute", owner = owner, ownerClass = ownerClass, priority = 2)
                }
            }
            offset += raw.length + 1
        }
        return out.values.toList()
    }

    /** Extract only actual binding targets from assignment/for target syntax. */
    private fun collectAssignmentTargetNames(rawTarget: String): Set<String> {
        var target = rawTarget.trim()
        // Remove a top-level annotation (`value: SomeType`) before unpacking.
        var depth = 0
        var annotationAt = -1
        target.forEachIndexed { index, ch ->
            when (ch) {
                '(', '[', '{' -> depth++
                ')', ']', '}' -> if (depth > 0) depth--
                ':' -> if (depth == 0 && annotationAt < 0) annotationAt = index
            }
        }
        if (annotationAt >= 0) target = target.substring(0, annotationAt).trim()
        target = target.removePrefix("*").trim()
        if (target.matches(identifier)) return setOf(target)
        if ((target.startsWith("(") && target.endsWith(")")) || (target.startsWith("[") && target.endsWith("]"))) {
            target = target.substring(1, target.length - 1)
        }
        val parts = splitTopLevelComma(target)
        if (parts.size > 1) return parts.flatMap { collectAssignmentTargetNames(it) }.toSet()
        return emptySet()
    }

    private fun splitTopLevelComma(text: String): List<String> {
        val parts = mutableListOf<String>()
        var depth = 0
        var start = 0
        var quote: Char? = null
        var escaped = false
        text.forEachIndexed { index, ch ->
            val active = quote
            if (active != null) {
                if (escaped) escaped = false else if (ch == '\\') escaped = true else if (ch == active) quote = null
            } else when (ch) {
                '\'', '\"' -> quote = ch
                '(', '[', '{' -> depth++
                ')', ']', '}' -> if (depth > 0) depth--
                ',' -> if (depth == 0) { parts += text.substring(start, index); start = index + 1 }
            }
        }
        parts += text.substring(start)
        return parts
    }

    private fun isInsideFunctionParameterList(code: String, cursor: Int): Boolean {
        val prefix = code.substring(0, cursor)
        val match = functionHeader.findAll(prefix).lastOrNull() ?: return false
        val open = match.range.last
        val close = findMatching(code, open, '(', ')')
        return close < 0 || cursor <= close
    }

    private fun isInsideClassHeader(code: String, cursor: Int): Boolean {
        val prefix = code.substring(0, cursor)
        val match = classHeader.findAll(prefix).lastOrNull() ?: return false
        val lineEnd = code.indexOf('\n', match.range.first).let { if (it < 0) code.length else it }
        val colon = code.indexOf(':', match.range.last + 1)
        return colon < 0 || colon >= cursor && colon < lineEnd
    }

    /** Suppress completion while the caret is defining a binding/declaration name. */
    private fun isDefiningAssignmentTarget(line: String, caretInLine: Int): Boolean {
        val trimmed = line.trimStart()
        val leading = line.length - trimmed.length
        val caret = (caretInLine - leading).coerceAtLeast(0)
        if (Regex("^(?:async\\s+)?def\\s+[A-Za-z_][A-Za-z0-9_]*$").matches(trimmed) ||
            Regex("^class\\s+[A-Za-z_][A-Za-z0-9_]*$").matches(trimmed)) return true

        val forMatch = Regex("^(?:async\\s+)?for\\s+(.+)$").find(trimmed)
        if (forMatch != null) {
            val inIndex = Regex("\\bin\\b").find(trimmed)?.range?.first ?: -1
            if (inIndex < 0 || caret <= inIndex) return true
        }

        val annotation = Regex("^[A-Za-z_][A-Za-z0-9_]*\\s*:").find(trimmed)
        if (annotation != null && caret <= annotation.range.last) return true

        val op = assignmentOperator.find(trimmed) ?: return false
        if (op.range.first < caret) return false
        val lhs = trimmed.substring(0, op.range.first).trim()
        if (lhs.isEmpty()) return false
        if (lhs.startsWith("return ") || lhs.startsWith("yield ") || lhs.startsWith("raise ") ||
            lhs.startsWith("if ") || lhs.startsWith("while ") || lhs.startsWith("assert ")) return false
        return Regex("^(?:\\*{0,2}[A-Za-z_][A-Za-z0-9_]*)(?:\\s*,\\s*\\*{0,2}[A-Za-z_][A-Za-z0-9_]*)*\\s*(?::[^=]*)?$").matches(lhs)
    }

    private fun detectImportContext(linePrefix: String): ImportContext? {
        val trimmed = linePrefix.trimStart()
        if (Regex("^import(?:\\s+.*)?$").matches(trimmed)) {
            val after = trimmed.removePrefix("import").trimStart()
            if (after.contains(" as ")) return null
            val currentPart = after.substringAfterLast(',').trimStart()
            if (currentPart.contains(' ')) return null
            return ImportContext(1)
        }
        if (!trimmed.startsWith("from ")) return null
        val importIndex = trimmed.indexOf(" import ")
        if (importIndex < 0) return null
        val module = trimmed.substring(5, importIndex).trim()
        if (module.isEmpty() || module.any { !(it.isLetterOrDigit() || it == '_' || it == '.') }) return null
        val importedPart = trimmed.substring(importIndex + 8).trimStart()
        if (importedPart.contains(" as ")) return null
        val currentPart = importedPart.substringAfterLast(',').trimStart()
        if (currentPart.contains(' ')) return null
        return ImportContext(2, module)
    }

    private fun findMatching(text: String, openIndex: Int, open: Char, close: Char): Int {
        var depth = 0
        var quote: Char? = null
        var escaped = false
        for (index in openIndex until text.length) {
            val ch = text[index]
            if (quote != null) {
                if (escaped) escaped = false
                else if (ch == '\\') escaped = true
                else if (ch == quote) quote = null
                continue
            }
            if (ch == '\'' || ch == '"') { quote = ch; continue }
            when (ch) {
                open -> depth++
                close -> { depth--; if (depth == 0) return index }
            }
        }
        return -1
    }

    private fun splitTopLevelParameters(text: String): List<String> {
        if (text.isBlank()) return emptyList()
        val result = mutableListOf<String>()
        var start = 0
        var depth = 0
        var quote: Char? = null
        var escaped = false
        text.forEachIndexed { index, char ->
            val active = quote
            if (active != null) {
                if (escaped) escaped = false else if (char == '\\') escaped = true else if (char == active) quote = null
            } else when (char) {
                '\'', '"' -> quote = char
                '(', '[', '{' -> depth++
                ')', ']', '}' -> if (depth > 0) depth--
                ',' -> if (depth == 0) { result += text.substring(start, index); start = index + 1 }
            }
        }
        result += text.substring(start)
        return result
    }

    private fun maskStringsAndComments(source: String): String {
        val chars = source.toCharArray()
        var i = 0
        var quote: Char? = null
        var triple = false
        var escaped = false
        var comment = false
        while (i < chars.size) {
            val ch = chars[i]
            if (comment) {
                if (ch == '\n') comment = false else chars[i] = ' '
                i++; continue
            }
            val active = quote
            if (active != null) {
                if (ch == '\n') { if (!triple) quote = null; escaped = false; i++; continue }
                if (escaped) { chars[i] = ' '; escaped = false; i++; continue }
                if (ch == '\\') { chars[i] = ' '; escaped = true; i++; continue }
                if (triple && i + 2 < chars.size && chars[i] == active && chars[i + 1] == active && chars[i + 2] == active) {
                    chars[i] = ' '; chars[i + 1] = ' '; chars[i + 2] = ' '; quote = null; triple = false; i += 3; continue
                }
                if (!triple && ch == active) { chars[i] = ' '; quote = null; i++; continue }
                chars[i] = ' '; i++; continue
            }
            when (ch) {
                '#' -> { chars[i] = ' '; comment = true; i++ }
                '\'', '"' -> {
                    triple = i + 2 < chars.size && chars[i + 1] == ch && chars[i + 2] == ch
                    chars[i] = ' '
                    if (triple) { chars[i + 1] = ' '; chars[i + 2] = ' '; i += 3 } else i++
                    quote = ch
                }
                else -> i++
            }
        }
        return String(chars)
    }

    internal fun isInsideStringOrComment(source: String, cursor: Int): Boolean {
        val end = cursor.coerceIn(0, source.length)
        var i = 0
        var quote: Char? = null
        var triple = false
        var escaped = false
        var comment = false
        while (i < end) {
            val ch = source[i]
            if (comment) { if (ch == '\n') comment = false; i++; continue }
            val active = quote
            if (active != null) {
                if (escaped) { escaped = false; i++; continue }
                if (ch == '\\') { escaped = true; i++; continue }
                if (triple && i + 2 < source.length && source[i] == active && source[i + 1] == active && source[i + 2] == active) {
                    quote = null; triple = false; i += 3; continue
                }
                if (!triple && ch == active) { quote = null; i++; continue }
                i++; continue
            }
            when (ch) {
                '#' -> { comment = true; i++ }
                '\'', '"' -> { quote = ch; triple = i + 2 < source.length && source[i + 1] == ch && source[i + 2] == ch; i += if (triple) 3 else 1 }
                else -> i++
            }
        }
        if (quote != null || comment) return true

        // Suppress completion at every caret position inside an f-string
        // prefix (`f`, `fr`, `rf`), including before the first letter and
        // between the two letters, while its opening quote is present.
        var prefixStart = end
        while (prefixStart > 0 && source[prefixStart - 1].isLetter()) prefixStart--
        var prefixEnd = end
        while (prefixEnd < source.length && source[prefixEnd].isLetter()) prefixEnd++
        val prefix = source.substring(prefixStart, prefixEnd).lowercase()
        val quoteAfterPrefix = source.getOrNull(prefixEnd)
        if (prefix in setOf("f", "fr", "rf") &&
            (quoteAfterPrefix == '\'' || quoteAfterPrefix == '\"') &&
            (prefixStart == 0 || !isIdentifierPart(source[prefixStart - 1]))) return true
        return false
    }

    private fun isIdentifierPart(char: Char): Boolean = char == '_' || char.isLetterOrDigit()
}
