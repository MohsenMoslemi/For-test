package com.codespace.ide

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.codespace.ide.ide.CrashLog

/**
 * The one screen the user can still open when the main app will not start at all.
 *
 * On purpose this uses NO Compose, NO Koin, NO app theme, and no class outside this file and
 * [CrashLog] - whatever is crashing MainActivity (Koin wiring, a Compose screen, a native
 * library...) cannot also break this one, because:
 *  1. It runs in its own process (`android:process=":viewer"` in AndroidManifest.xml), so it is a
 *     fresh Android process, not a continuation of the crashed one.
 *  2. [UbuntuTerminalApplication.onCreate] checks the process name and skips Koin/service
 *     startup entirely for that process - see the comment there.
 *  3. The UI below is built with plain [View]s, inflated in code, so there is no XML layout, no
 *     custom theme attribute and no dependency that could itself be missing after a bad R8 keep
 *     rule, which is the exact bug class this screen exists to diagnose.
 */
class CrashViewerActivity : Activity() {

    private lateinit var textView: TextView
    private var currentText: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render(CrashLog.read(this) ?: "هیچ کرشی ثبت نشده.\n\nNo crash has been recorded yet.")
    }

    private fun render(crashText: String) {
        currentText = crashText

        textView = TextView(this).apply {
            setText(crashText)
            setTextIsSelectable(true)
            setTextColor(Color.BLACK)
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setPadding(32, 32, 32, 32)
        }

        val scroll = ScrollView(this).apply {
            addView(
                textView,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            )
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }

        fun button(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
            )
        }

        val copyBtn = button("Copy") {
            val cm = getSystemService(ClipboardManager::class.java)
            cm?.setPrimaryClip(ClipData.newPlainText("PySpace crash log", currentText))
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        }
        val shareBtn = button("Share") {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, currentText)
            }
            startActivity(Intent.createChooser(send, "Share crash log"))
        }
        val clearBtn = button("Clear") {
            CrashLog.clear(this)
            render("Cleared.\n\nThe log will be filled again the next time the app crashes.")
        }

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(16, 16, 16, 16)
            addView(copyBtn)
            addView(shareBtn)
            addView(clearBtn)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            addView(scroll)
            addView(View(this@CrashViewerActivity).apply {
                setBackgroundColor(Color.LTGRAY)
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 2)
            })
            addView(buttons)
        }
        setContentView(root)
    }
}
