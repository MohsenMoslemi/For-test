package com.codespace.ide.ide.codeintel

/**
 * Conservative, non-executing index of names bound by Python source.
 *
 * This is intentionally separate from the auto-import catalogue: catalogue
 * entries describe what could be imported, while this index describes names
 * that are already available in the buffer. It understands Python import
 * binding rules (including aliases, dotted imports and parenthesized imports)
 * and ignores comments/string contents before inspecting statements.
 */
internal class PythonSourceBindings private constructor(
    private val names: Set<String>,
) {
    fun contains(name: String): Boolean = name in names

    companion object {
        private val identifier = Regex("[A-Za-z_][A-Za-z0-9_]*")
        private val declaration = Regex("^(?:async\\s+)?(?:def|class)\\s+([A-Za-z_][A-Za-z0-9_]*)")
        private val assignment = Regex("^([A-Za-z_][A-Za-z0-9_]*(?:\\s*,\\s*[A-Za-z_][A-Za-z0-9_]*)*)\\s*(?::[^=]+)?(?<![=!<>])=(?!=)")

        fun from(source: String): PythonSourceBindings {
            val masked = maskStringsAndComments(source)
            val result = linkedSetOf<String>()
            val logical = StringBuilder()
            var depth = 0

            fun consume(statement: String) {
                val text = statement.trim()
                if (text.isEmpty()) return
                when {
                    text.startsWith("import ") -> {
                        splitImportItems(text.removePrefix("import ")).forEach { raw ->
                            val item = raw.trim().removePrefix("*")
                            if (item.isEmpty()) return@forEach
                            val parts = item.split(Regex("\\s+as\\s+"), limit = 2)
                            val imported = parts[0].trim()
                            val bound = parts.getOrNull(1)?.trim()?.takeIf { it.matches(identifier) }
                                ?: imported.substringBefore('.')
                            if (bound.matches(identifier)) result += bound
                        }
                    }
                    text.startsWith("from ") && Regex("\\s+import\\s+").containsMatchIn(text) -> {
                        val importIndex = Regex("\\s+import\\s+").find(text) ?: return
                        val module = text.substring(5, importIndex.range.first).trim()
                        val members = text.substring(importIndex.range.last + 1).trim()
                        if (module.isNotEmpty()) {
                            splitImportItems(members.removePrefix("(").removeSuffix(")")).forEach { raw ->
                                val item = raw.trim()
                                if (item.isEmpty() || item == "*") return@forEach
                                val parts = item.split(Regex("\\s+as\\s+"), limit = 2)
                                val imported = parts[0].trim()
                                val bound = parts.getOrNull(1)?.trim() ?: imported
                                if (bound.matches(identifier)) result += bound
                            }
                        }
                    }
                    else -> {
                        declaration.find(text)?.groupValues?.getOrNull(1)?.let { result += it }
                        assignment.find(text)?.groupValues?.getOrNull(1)?.let { lhs ->
                            identifier.findAll(lhs).forEach { result += it.value }
                        }
                        Regex("^(?:async\\s+)?for\\s+(.+?)\\s+in\\b").find(text)?.groupValues?.getOrNull(1)?.let { target ->
                            identifier.findAll(target).forEach { result += it.value }
                        }
                        Regex("^(?:with\\s+.+?\\s+as|except(?:\\s+[^:]+)?\\s+as)\\s+([A-Za-z_][A-Za-z0-9_]*)").find(text)
                            ?.groupValues?.getOrNull(1)?.let { result += it }
                        // Function parameters are bindings in their function scope.
                        if (declaration.containsMatchIn(text)) {
                            val open = text.indexOf('(')
                            val close = if (open >= 0) matchingParen(text, open) else -1
                            if (close > open) {
                                val parameters = text.substring(open + 1, close)
                                splitImportItems(parameters).forEach { parameter ->
                                    val name = parameter.trim().substringBefore(':').substringBefore('=').trim().removePrefix("*")
                                    if (name.matches(identifier)) result += name
                                }
                            }
                        }
                    }
                }
            }

            masked.lineSequence().forEach { line ->
                val trimmed = line.trim()
                if (logical.isNotEmpty()) logical.append(' ')
                logical.append(trimmed.removeSuffix("\\").trim())
                depth += trimmed.count { it == '(' || it == '[' || it == '{' }
                depth -= trimmed.count { it == ')' || it == ']' || it == '}' }
                val continued = trimmed.endsWith("\\") || depth > 0
                if (!continued) {
                    consume(logical.toString())
                    logical.setLength(0)
                    depth = 0
                }
            }
            if (logical.isNotEmpty()) consume(logical.toString())
            return PythonSourceBindings(result)
        }

        private fun splitImportItems(value: String): List<String> = value.split(',')

        private fun matchingParen(text: String, start: Int): Int {
            var depth = 0
            for (i in start until text.length) {
                when (text[i]) {
                    '(' -> depth++
                    ')' -> if (--depth == 0) return i
                }
            }
            return -1
        }

        /** Replace strings and comments with spaces while preserving offsets/newlines. */
        private fun maskStringsAndComments(source: String): String {
            val out = source.toCharArray()
            var i = 0
            var quote = '\u0000'
            var triple = false
            var escaped = false
            while (i < out.size) {
                val c = source[i]
                if (quote != '\u0000') {
                    if (c != '\n' && c != '\r') out[i] = ' '
                    if (escaped) escaped = false
                    else if (c == '\\') escaped = true
                    else if (c == quote) {
                        if (triple && i + 2 < source.length && source[i + 1] == quote && source[i + 2] == quote) {
                            out[i + 1] = ' '; out[i + 2] = ' '; i += 2; quote = '\u0000'; triple = false
                        } else if (!triple) quote = '\u0000'
                    }
                    i++
                    continue
                }
                if (c == '#') {
                    while (i < out.size && source[i] != '\n') { out[i] = ' '; i++ }
                    continue
                }
                if (c == '\'' || c == '"') {
                    quote = c
                    triple = i + 2 < source.length && source[i + 1] == c && source[i + 2] == c
                    out[i] = ' '
                    if (triple) { out[i + 1] = ' '; out[i + 2] = ' '; i += 2 }
                }
                i++
            }
            return String(out)
        }
    }
}
