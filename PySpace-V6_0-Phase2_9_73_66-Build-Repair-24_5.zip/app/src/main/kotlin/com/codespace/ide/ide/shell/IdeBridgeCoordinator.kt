package com.codespace.ide.ide.shell

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import com.codespace.ide.ide.editor.EditorViewModel
import com.codespace.ide.ide.IdeBridge
import com.codespace.ide.ide.IdeBridgeHandler
import com.codespace.ide.ide.RunHub
import com.codespace.ide.ide.RunInfo
import com.codespace.ide.ide.run.CameraRunCoordinator
import com.codespace.ide.ide.run.ExpiringPlanStore
import com.codespace.ide.ide.run.ProjectWebResolverRepository
import com.codespace.ide.ide.run.RunCommandBuilder
import com.codespace.ide.ide.run.RunIdentityResolver
import com.codespace.ide.ide.run.RunOrchestrator
import com.codespace.ide.ide.run.RunSourceAnalyzer
import com.codespace.ide.ide.runtimeui.RuntimeUiViewModel

/**
 * Owns the guest-to-IDE bridge protocol for terminal runs.
 * It translates prepare/start/port/done/stop callbacks into application run
 * operations while delegating UI effects and camera permission requests to the host.
 */
internal class IdeBridgeCoordinator(
    private val bridge: IdeBridge,
    private val context: Context,
    private val hostActive: AtomicBoolean,
    private val cameraRunCoordinator: CameraRunCoordinator,
    private val requestCameraPermission: () -> Unit,
    private val editors: () -> Collection<EditorViewModel>,
    private val projectWebResolver: ProjectWebResolverRepository,
    private val runOrchestrator: RunOrchestrator,
    private val termPlans: ExpiringPlanStore<TermPlan>,
    private val runtimeUiViewModel: RuntimeUiViewModel,
    private val ideScope: CoroutineScope,
    private val hub: RunHub,
    private val startFrameDisplay: (String) -> Unit,
    private val startDisplay: (String) -> Unit,
    private val setDisplayOwner: (String?) -> Unit,
    private val endTerminalRun: (String) -> Unit,
    private val stopRun: (RunInfo) -> Unit,
) {
    fun install() {
        bridge.handler = object : IdeBridgeHandler {
            override fun prepare(cwd: String, argv: List<String>): JSONObject {
                val out = JSONObject()
                if (!hostActive.get() || argv.isEmpty()) return out.put("ok", false)
                val exe = argv[0]
                val script = RunIdentityResolver.scriptArgument(argv)
                val scriptGuest = script?.let { RunIdentityResolver.resolveGuestScript(cwd, it) }
                val hostFile = scriptGuest?.let { File(File(context.filesDir, "ubuntu-rootfs"), it.trimStart('/')) }
                val text = try {
                    if (hostFile != null && hostFile.isFile) safeReadText(hostFile) else null
                } catch (_: Exception) { null }
                val sourceAnalysis = if (hostFile != null && text != null) {
                    RunSourceAnalyzer.analyze(hostFile.name, text)
                } else {
                    RunSourceAnalyzer.analyze("", null)
                }
                val gui = sourceAnalysis.gui
                val useFrame = sourceAnalysis.useFrame
                val guiPrefix = if (gui != null) guiLaunchPrefix(gui, exe, frame = useFrame) else ""
                val camPrefix = if (sourceAnalysis.wantsCamera) {
                    try {
                        kotlinx.coroutines.runBlocking {
                            cameraRunCoordinator.prepareRun(
                                shouldContinue = { hostActive.get() },
                                requestPermission = requestCameraPermission,
                            )
                        }
                    } catch (_: Exception) { "" }
                } else ""
                val project = try {
                    editors().toList().map { it.session.project }.firstOrNull {
                        val gp = guestProjectPath(it)
                        cwd == gp || cwd.startsWith("$gp/")
                    }
                } catch (_: Exception) { null }
                val webRoot = project?.let { guestProjectPath(it) } ?: cwd
                val immediate = sourceAnalysis.webServer
                val keys = RunIdentityResolver.terminalConflictKeys(
                    scriptGuestPath = scriptGuest,
                    argv = argv,
                    webRoot = webRoot,
                    webLike = immediate != null || RunIdentityResolver.isWebLauncher(argv),
                )
                val auto = try {
                    kotlinx.coroutines.runBlocking {
                        projectWebResolver.prepareTerminal(project, hostFile, text, immediate, exe)
                    }
                } catch (_: Exception) { null }
                val title = RunIdentityResolver.terminalTitle(script, argv, gui?.framework)
                if (!hostActive.get()) return out.put("ok", false)
                val id = runOrchestrator.newRunId()
                if (!termPlans.put(id, TermPlan(gui, useFrame, title, keys, project))) {
                    return out.put("ok", false)
                }
                out.put("ok", true).put("id", id)
                    .put("prefix", RunCommandBuilder.buildTerminalPrefix(guiPrefix, camPrefix))
                if (auto != null && script != null) {
                    out.put(
                        "alt",
                        JSONObject().put("command", auto.command)
                            .put("label", auto.server.framework + " server")
                            .put(
                                "why",
                                File(script).name + " defines a " + auto.server.framework +
                                    " app but does not start a server, so Python would just exit."
                            )
                    )
                }
                val other = runOrchestrator.findConflict(keys)
                if (other != null) {
                    out.put(
                        "conflict",
                        JSONObject().put("id", other.id).put("source", other.source)
                            .put("title", other.title)
                            .put("started", java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date(other.startedAt)))
                    )
                }
                return out
            }

            override fun start(id: String, pid: Int, pgid: Int, cwd: String, argv: List<String>) {
                if (!hostActive.get()) return
                val plan = termPlans.take(id)
                onMainThread {
                    if (!hostActive.get()) return@onMainThread
                    runOrchestrator.registerTerminal(
                        id = id,
                        cwd = cwd,
                        title = plan?.title ?: argv.joinToString(" "),
                        keys = plan?.keys ?: setOf(argv.joinToString(" ")),
                        pid = pid,
                        pgid = pgid,
                        usesDisplay = plan?.gui != null,
                    )
                    val gui = plan?.gui
                    if (plan != null && gui != null) {
                        setDisplayOwner(id)
                        runtimeUiViewModel.setFrameProject(plan.project)
                        if (plan.useFrame) startFrameDisplay(gui.framework)
                        else {
                            runtimeUiViewModel.setFrameMode(false)
                            startDisplay(plan.title)
                        }
                    }
                }
            }

            override fun port(id: String, host: String, port: Int) {
                if (!hostActive.get()) return
                ideScope.launch(Dispatchers.IO) {
                    if (!hostActive.get()) return@launch
                    var info: RunInfo? = null
                    for (i in 0 until 20) {
                        info = runOrchestrator.get(id)
                        if (info != null) break
                        kotlinx.coroutines.delay(100)
                    }
                    val run = info ?: return@launch
                    if (!hostActive.get() || !probeHttp(port)) return@launch
                    withContext(Dispatchers.Main) {
                        if (!hostActive.get()) return@withContext
                        if (run.webUrl == null) run.webUrl = "http://127.0.0.1:$port/"
                        hub.touch()
                    }
                }
            }

            override fun done(id: String, code: Int) {
                if (!hostActive.get()) return
                onMainThread { if (hostActive.get()) endTerminalRun(id) }
            }

            override fun stop(id: String) {
                if (!hostActive.get()) return
                onMainThread {
                    if (!hostActive.get()) return@onMainThread
                    val info = runOrchestrator.get(id)
                    if (info != null) stopRun(info)
                }
            }
        }
    }

    /** Detaches callbacks before the Activity host releases its bridge resources. */
    fun detach() {
        bridge.handler = null
    }
}
