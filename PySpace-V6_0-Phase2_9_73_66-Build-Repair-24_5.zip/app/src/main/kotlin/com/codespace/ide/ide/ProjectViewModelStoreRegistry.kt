package com.codespace.ide.ide

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelStore

/**
 * Holds a child ViewModelStore for each open project.
 *
 * The registry itself is Activity-scoped. Clearing a deleted project clears
 * all feature ViewModels together, which cancels their viewModelScope jobs and
 * releases retained editor documents, explorer trees and search results.
 */
class ProjectViewModelStoreRegistry : ViewModel() {
    private val stores = LinkedHashMap<String, ViewModelStore>()

    fun storeFor(projectPath: String): ViewModelStore =
        stores.getOrPut(projectPath) { ViewModelStore() }

    fun clearProject(projectPath: String) {
        stores.remove(projectPath)?.clear()
    }

    override fun onCleared() {
        stores.values.forEach { it.clear() }
        stores.clear()
        super.onCleared()
    }
}
