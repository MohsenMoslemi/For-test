package com.codespace.ide

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.system.Os
import java.io.File
import java.io.IOException
import com.codespace.ide.ide.projects.workspaceRoot
import com.codespace.ide.ide.IdeBridge
import com.codespace.ide.ide.IdeShellEnv
import com.codespace.ide.ide.JSON

class ProotManager(
    private val context: Context,
    private val ubuntu: UbuntuManager
) {

    data class RuntimeStatus(
        val available: Boolean,
        val message: String,
        val launcher: File?
    )

    private fun nativeDir(): File {
        return File(context.applicationInfo.nativeLibraryDir)
    }

    private fun prootBinary(): File {
        return File(nativeDir(), "libproot.so")
    }

    // BUGFIX: README claims both Termux (libprootloader.so) and oonid/pr
    // (libproot-loader.so) names are detected, but old code only checked
    // the dashed name. Support both, preferring whichever exists.
    /** Returns the existing loader file, or null when neither naming exists. */
    private fun existingLoader(): File? {
        val dashed = File(nativeDir(), "libproot-loader.so")
        if (dashed.exists()) return dashed
        val plain = File(nativeDir(), "libprootloader.so")
        if (plain.exists()) return plain
        return null
    }

    @Suppress("unused")
    private fun prootLoader(): File {
        return existingLoader() ?: File(nativeDir(), "libproot-loader.so")
    }

    private fun rootfs(): File {
        return ubuntu.rootfsDir
    }

    private fun prootTmpDir(): File {
        return File(context.filesDir, "proot-ubuntu-tmp")
    }

    private fun ensureProotTmp(): File {
        val dir = prootTmpDir()

        if (!dir.exists()) {
            if (!dir.mkdirs()) {
                throw IOException(
                    "Could not create PRoot Ubuntu temporary directory."
                )
            }
        }

        try {
            Os.chmod(dir.absolutePath, 1023)
        } catch (_: Throwable) {
            // The directory is already owned by the Android app.
            // If chmod is unavailable, continue with its existing permissions.
        }

        return dir
    }

    private fun prepareResolvConf(): File {
        val resolvConf = File(
            context.filesDir,
            "proot-resolv.conf"
        )

        // BUGFIX: old code threw when offline, breaking even local commands
        // like `uname -m`. Now falls back to public DNS so offline/local
        // commands still work and online commands get a sane default.
        val dnsHosts = mutableListOf<String>()
        try {
            val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE)
            as ConnectivityManager
            val network: Network? = connectivityManager.activeNetwork
            val linkProperties = network?.let {
                connectivityManager.getLinkProperties(it)
            }
            linkProperties?.dnsServers?.forEach { dns ->
                val host = try {
                    dns.hostAddress
                } catch (_: Exception) {
                    null
                }
                if (!host.isNullOrBlank()) dnsHosts += host
            }
        } catch (_: Exception) {
            // Keep fallback below.
        }

        if (dnsHosts.isEmpty()) {
            dnsHosts += listOf("8.8.8.8", "1.1.1.1")
        }

        val content = buildString {
            for (host in dnsHosts.distinct()) {
                append("nameserver ")
                append(host.trim())
                append('\n')
            }
        }

        resolvConf.writeText(content)

        return resolvConf
    }

    private fun ensureUbuntuDirectories() {
        val dirs = listOf(
            File(rootfs(), "root"),
            File(rootfs(), "run"),
            File(rootfs(), "var/tmp"),
            File(rootfs(), "tmp")
        )

        for (dir in dirs) {
            if (!dir.exists()) {
                dir.mkdirs()
            }
        }
    }

    /**
     * Shared PRoot invocation pieces.
     *
     * Single source of truth for bind mounts, workdir and environment.
     * Used by both [runOnce] and [interactiveShellCommand].
     * Do not change binds/env here without re-testing apt, DNS and Python flows.
     */
    private class PreparedBase(
        val args: MutableList<String>,
        val env: Map<String, String>,
        val root: File,
        val launcher: File,
        val loader: File?,
        val native: File
    )

    private fun prepareBase(runtimeStatus: RuntimeStatus): PreparedBase {
        ensureUbuntuDirectories()

        val privateTmp = ensureProotTmp()
        val resolvConf = prepareResolvConf()

        val root = rootfs()
        val launcher = runtimeStatus.launcher ?: prootBinary()
        val loader = existingLoader()
        val native = nativeDir()

        // Keep project data outside the replaceable Ubuntu rootfs. The host
        // directory is app-private; the guest keeps the stable /files/projects
        // path through a PRoot bind mount. workspaceRoot() performs the one-time
        // non-destructive import from older rootfs-backed project locations.
        val privateWorkspace = File(context.filesDir, "projects")
        if (!privateWorkspace.isDirectory && !privateWorkspace.mkdirs()) {
            throw IOException("Could not prepare the private PySpace projects directory.")
        }
        val guestWorkspaceMount = File(root, "files/projects")
        if (!guestWorkspaceMount.isDirectory && !guestWorkspaceMount.mkdirs()) {
            throw IOException("Could not prepare the Ubuntu projects mount point.")
        }

        val commandArgs = mutableListOf<String>()

        commandArgs += launcher.absolutePath

        commandArgs += "-r"
        commandArgs += root.absolutePath

        /*
         * Android host pseudo-filesystems.
         *
         * With -r alone, PRoot does not guarantee that the guest sees the
         * Android /dev, /proc and /sys trees in every execution context.
         *
         * APT and GnuPG need at least /dev/null and /dev/urandom.
         * Python, subprocesses and other Linux tools also expect /proc.
         */
        val hostDev = File("/dev")
        val hostProc = File("/proc")
        val hostSys = File("/sys")

        if (hostDev.isDirectory) {
            commandArgs += "-b"
            commandArgs += "/dev:/dev"
        }

        if (hostProc.isDirectory) {
            commandArgs += "-b"
            commandArgs += "/proc:/proc"
        }

        if (hostSys.isDirectory) {
            commandArgs += "-b"
            commandArgs += "/sys:/sys"
        }

        // Projects live in Android private app storage, independently of the
        // Ubuntu image. Every PRoot entry point shares this mount via
        // prepareBase(), including runOnce and interactive IDE terminals.
        commandArgs += "-b"
        commandArgs += "${privateWorkspace.absolutePath}:/files/projects"

        commandArgs += "-0"

        commandArgs += "--link2symlink"

        /*
         * Android-generated DNS configuration.
         */
        commandArgs += "-b"
        commandArgs += "${resolvConf.absolutePath}:/etc/resolv.conf!"

        /*
         * Private writable /tmp for Ubuntu.
         *
         * The previous problem was that Ubuntu /tmp was actually
         * showing the Android host /tmp (UID 2000), which apt cannot
         * write to from the PRoot root environment.
         */
        commandArgs += "-b"
        commandArgs += "${privateTmp.absolutePath}:/tmp"

        commandArgs += "-w"
        commandArgs += "/root"

        val env = mutableMapOf<String, String>()

        env["PATH"] =
        "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"

        env["HOME"] = "/root"
        env["USER"] = "root"
        env["LOGNAME"] = "root"

        env["TMPDIR"] = "/tmp"
        env["TEMP"] = "/tmp"
        env["TMP"] = "/tmp"

        env["LANG"] = "C.UTF-8"
        env["LC_ALL"] = "C.UTF-8"

        env["LD_LIBRARY_PATH"] =
        native.absolutePath

        env["PROOT_TMP_DIR"] =
        File(context.cacheDir, "proot-tmp").absolutePath

        env["PROOT_NO_SECCOMP"] = "1"

        if (loader != null) {
            env["PROOT_LOADER"] =
            loader.absolutePath
        }

        val prootTmp =
        File(context.cacheDir, "proot-tmp")

        if (!prootTmp.exists()) {
            prootTmp.mkdirs()
        }

        return PreparedBase(commandArgs, env, root, launcher, loader, native)
    }

    /**
     * Interactive shell command for the PTY-backed session.
     *
     * Uses the exact same binds, workdir and environment as [runOnce] (single
     * source of truth: [prepareBase]); only the final guest program differs
     * (`bash/sh -i` instead of `sh -c <command>`). The returned argv/env are
     * executed by the native PTY child (see PtyNative.open), NOT via
     * ProcessBuilder pipes — there is no pipe-based shell path anymore.
     */
    data class InteractiveCommand(
        val argv: List<String>,
        val env: Map<String, String>
    )

    /**
     * @param workdir guest-absolute starting directory (PRoot -w). Null
     * keeps the historical /root. Lets the IDE open shells directly inside
     * a project folder with zero typed commands.
     */
    /**
     * @param venvGuestPath guest venv dir (e.g. `/files/projects/MyProj/.venv`)
     * to auto-activate. Implemented as PROMPT_COMMAND — it runs after both
     * bashrc files and before the first prompt, so nothing is ever typed,
     * the native prompt format (and colors) is preserved, and the venv
     * prefix appears on the very first line. Unset-after-first-run, so a
     * later user PROMPT_COMMAND is never clobbered.
     */
    /** Set by the IDE: lets its terminals talk to the IDE (see IdeBridge). Null = plain shells. */
    @Volatile var ideShell: com.codespace.ide.ide.IdeShellEnv? = null

    fun interactiveShellCommand(
        workdir: String? = null,
        venvGuestPath: String? = null
    ): InteractiveCommand {
        val runtimeStatus = status()

        if (!runtimeStatus.available || runtimeStatus.launcher == null) {
            throw IllegalStateException(runtimeStatus.message)
        }

        val base = prepareBase(runtimeStatus)

        val commandArgs = base.args.toMutableList()
        // Override the default -w /root from prepareBase (it is always the
        // last two elements it appends).
        val wd = workdir?.takeIf { it.isNotBlank() } ?: "/root"
        if (commandArgs.size >= 2 && commandArgs[commandArgs.size - 2] == "-w") {
            commandArgs[commandArgs.size - 1] = wd
        } else {
            commandArgs += "-w"
            commandArgs += wd
        }

        // Prefer bash for a real interactive prompt; fall back to sh.
        // The prompt text itself always comes from the guest shell.
        val shell = if (File(base.root, "bin/bash").isFile) {
            "/bin/bash"
        } else {
            "/bin/sh"
        }

        commandArgs += shell
        commandArgs += "-i"

        val environment = base.env.toMutableMap()

        // Interactive-session-only addition. runOnce env is untouched.
        environment["TERM"] = "xterm-256color"

        // Invisible venv activation without typing a single line:
        // PROMPT_COMMAND runs after every startup file and before the first
        // prompt, then removes itself — so the native prompt (root@…,
        // colors, title) is untouched and only the (.venv) prefix appears.
        // Non-interactive shells (runOnce, console runs) ignore it.
        // NOTE: no ~/ here — tilde does NOT expand inside double quotes,
        // which silently broke activation (empty source, hidden output).
        // $HOME expands anywhere.
        val v = venvGuestPath?.takeIf { it.isNotBlank() }?.let {
            if (it.startsWith("~/")) "\$HOME" + it.substring(1) else it
        }
        val classic = if (v != null) {
            "source \"$v/bin/activate\" >/dev/null 2>&1; unset PROMPT_COMMAND"
        } else {
            "unset PROMPT_COMMAND"
        }
        // IDE terminals (they always get a workdir) are IDE-AWARE: python/flask/... run as managed runs
        // (display, Browser, Stop, "already running" warnings) and the venv follows the folder. The
        // bridge address and token reach the shell through its environment. If the integration script
        // is missing the shell falls back to the classic one-time venv activation.
        val ide = ideShell
        val bridgeUrl = if (ide != null && workdir != null) ide.url() else null
        if (bridgeUrl != null && ide != null) {
            environment["IDE_BRIDGE"] = bridgeUrl
            environment["IDE_TOKEN"] = ide.token
            environment["IDE_DIR"] = "/tmp/ide"
            if (v != null) environment["IDE_VENV0"] = v
            environment["PROMPT_COMMAND"] =
                "if [ -f /tmp/ide/shell-init.sh ]; then . /tmp/ide/shell-init.sh; else $classic; fi"
        } else if (v != null) {
            environment["PROMPT_COMMAND"] =
            "source \"$v/bin/activate\" >/dev/null 2>&1; unset PROMPT_COMMAND"
        }

        return InteractiveCommand(commandArgs, environment)
    }

    /**
     * Command-running variant for secondary PTY sessions (IDE console runs).
     * Same binds/workdir/env as [interactiveShellCommand] — the last two
     * argv elements ([shell, -i]) are swapped for [sh, -c, command], so the
     * child runs one program on a real PTY instead of a login shell. The
     * existing interactive path above is byte-for-byte untouched.
     */
    fun interactiveRunCommand(shellCommand: String): InteractiveCommand {
        require(shellCommand.isNotBlank()) { "empty run command" }
        val base = interactiveShellCommand()
        require(base.argv.size >= 2 && base.argv.last() == "-i") {
            "unexpected interactive argv shape"
        }
        return InteractiveCommand(
            base.argv.dropLast(2) + listOf("/bin/sh", "-c", shellCommand),
            base.env
        )
    }

    fun status(): RuntimeStatus {
        val proot = prootBinary()
        val loader = existingLoader()
        val root = rootfs()

        if (!root.exists()) {
            return RuntimeStatus(
                available = false,
                message = "Ubuntu rootfs is not installed.",
                launcher = null
            )
        }

        if (!proot.exists()) {
            return RuntimeStatus(
                available = false,
                message = "PRoot ARM64 runtime was not found.",
                launcher = null
            )
        }

        return RuntimeStatus(
            available = true,
            message = if (loader != null) {
                "Ubuntu + PRoot ARM64 runtime is ready."
            } else {
                // Loader is optional for basic commands; PRoot still works
                // without PROOT_LOADER on many kernels.
                "Ubuntu ready (no loader, basic mode)."
            },
            launcher = proot
        )
    }

    /**
     * Starts a long-lived guest process with the exact same PRoot mounts and
     * environment as runOnce(). Unlike runOnce(), stdout and stderr remain
     * separate so protocols such as LSP (Content-Length framed JSON-RPC) are
     * not corrupted by shell/runtime log output.
     *
     * The caller owns the returned Process and must close its streams and
     * destroy it when the service is no longer needed.
     */
    fun startGuestProcess(command: String, workdir: String? = null): Process {
        require(command.isNotBlank()) { "empty guest command" }
        val runtimeStatus = status()
        if (!runtimeStatus.available || runtimeStatus.launcher == null) {
            throw IllegalStateException(runtimeStatus.message)
        }
        val base = prepareBase(runtimeStatus)
        val args = base.args.toMutableList()
        if (!workdir.isNullOrBlank() && args.size >= 2 && args[args.size - 2] == "-w") {
            args[args.size - 1] = workdir
        }
        args += "/bin/sh"
        args += "-c"
        args += command
        val builder = ProcessBuilder(args)
        builder.environment().putAll(base.env)
        return builder.start()
    }

    /** Long-lived stdin/stdout session used by the in-panel Python debugger. */
    class InteractiveSession internal constructor(private val process: Process) {
        private val writer = process.outputStream.bufferedWriter()
        @Synchronized fun sendLine(command: String): Boolean = try {
            if (!process.isAlive) return false
            writer.write(command); writer.newLine(); writer.flush(); true
        } catch (_: Exception) { false }
        fun isAlive(): Boolean = process.isAlive
        fun close() {
            try { if (process.isAlive) { writer.write("q"); writer.newLine(); writer.flush() } } catch (_: Exception) { }
            try { process.destroy() } catch (_: Exception) { }
            try { if (process.isAlive) process.destroyForcibly() } catch (_: Exception) { }
        }
    }

    /** Starts a long-lived guest command and streams its output on a worker thread. */
    fun startInteractive(command: String, onOutput: (String) -> Unit, onExit: (Int) -> Unit = {}): InteractiveSession? {
        if (command.isBlank()) return null
        val runtimeStatus = status()
        if (!runtimeStatus.available || runtimeStatus.launcher == null) {
            onOutput("ERROR: ${runtimeStatus.message}\n"); return null
        }
        return try {
            val base = prepareBase(runtimeStatus)
            val args = base.args.toMutableList().apply { add("/bin/sh"); add("-c"); add(command) }
            val builder = ProcessBuilder(args).redirectErrorStream(true)
            builder.environment().putAll(base.env)
            val process = builder.start()
            val session = InteractiveSession(process)
            Thread {
                try {
                    process.inputStream.bufferedReader().use { reader ->
                        val buffer = CharArray(2048)
                        while (true) { val n = reader.read(buffer); if (n < 0) break; if (n > 0) onOutput(String(buffer, 0, n)) }
                    }
                    onExit(process.waitFor())
                } catch (t: Throwable) { onOutput("\n[debugger stream error: ${t.message}]\n"); onExit(-1) }
            }.apply { isDaemon = true; name = "PySpace-Debugger-Output"; start() }
            session
        } catch (t: Throwable) { onOutput("ERROR: ${t.javaClass.simpleName}: ${t.message}\n"); null }
    }

    /**
     * [timeoutSec] > 0 arms a watchdog that kills the process when it runs
     * too long, so a stuck guest command can never hang its caller.
     */
    fun runOnce(command: String, timeoutSec: Long = 0L): String {
        if (command.isBlank()) {
            return "ERROR: empty command"
        }
        val runtimeStatus = status()

        if (!runtimeStatus.available || runtimeStatus.launcher == null) {
            return "ERROR: ${runtimeStatus.message}"
        }

        return try {
            // Same binds/env as before, via the shared builder.
            // Resulting command line and environment are unchanged.
            val base = prepareBase(runtimeStatus)

            val commandArgs = base.args.toMutableList()

            commandArgs += "/bin/sh"
            commandArgs += "-c"
            commandArgs += command

            val processBuilder = ProcessBuilder(commandArgs)

            val environment = processBuilder.environment()
            environment.putAll(base.env)

            processBuilder.redirectErrorStream(true)

            val process = processBuilder.start()
            val watchdog = if (timeoutSec > 0L) {
                Thread {
                    try {
                        Thread.sleep(timeoutSec * 1000L)
                        if (process.isAlive) process.destroyForcibly()
                    } catch (_: InterruptedException) {
                    }
                }.also { it.isDaemon = true; it.start() }
            } else {
                null
            }

            val output =
            process.inputStream
            .bufferedReader()
            .use { it.readText() }

            val exitCode = process.waitFor()
            watchdog?.interrupt()

            buildString {
                append(output)

                if (!output.endsWith("\n")) {
                    append('\n')
                }

                append("[exit=")
                append(exitCode)
                append("]")
            }

        } catch (t: Throwable) {
            buildString {
                append("ERROR: ")
                append(t.javaClass.simpleName)
                append(": ")

                append(
                    t.message ?: "unknown error"
                )
            }
        }
    }
}
