package com.codespace.ide.ide.editor

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.LayoutCoordinates

/** Geometry-only hit testing for editor information popups. */
internal object EditorPopupHitTester {
    fun contains(
        position: Offset,
        host: LayoutCoordinates,
        popupCoordinates: Collection<LayoutCoordinates>,
        slopPx: Float
    ): Boolean = popupCoordinates.any { popup ->
        popup.isAttached && run {
            val topLeft = host.localPositionOf(popup, Offset.Zero)
            position.x >= topLeft.x - slopPx &&
                position.x <= topLeft.x + popup.size.width + slopPx &&
                position.y >= topLeft.y - slopPx &&
                position.y <= topLeft.y + popup.size.height + slopPx
        }
    }
}
