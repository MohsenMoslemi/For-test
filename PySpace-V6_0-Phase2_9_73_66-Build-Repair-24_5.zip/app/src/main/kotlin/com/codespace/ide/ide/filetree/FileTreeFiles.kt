package com.codespace.ide.ide.filetree

import java.io.File

internal fun copyPathToClipboard(ctx: android.content.Context, path: String) {
    try {
        // The tree holds Android-host paths, where <filesDir>/ubuntu-rootfs
        // IS the guest `/`. Copy the path as Ubuntu sees it — that's what
        // pasting into the terminal needs; the host form is useless there.
        val rootfs = File(ctx.filesDir, "ubuntu-rootfs").absolutePath
        val guest =
        if (path.startsWith("$rootfs/")) path.removePrefix(rootfs) else path
        val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("path", guest))
    } catch (_: Exception) {
    }
}

/** Copies a SAF-picked document into a workspace directory. */
internal fun importUriToDir(ctx: android.content.Context, uri: android.net.Uri, destDir: File): Boolean {
    var temp: File? = null
    return try {
        var name = "imported_${System.currentTimeMillis()}"
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) {
                    c.getString(idx)?.trim()?.takeIf { it.isNotEmpty() }?.let { name = it }
                }
            }
        } catch (_: Exception) {
        }
        name = name.replace('/', '_').replace('\\', '_').replace("\u0000", "_")
        var target = File(destDir, name)
        if (target.exists()) {
            val dot = name.lastIndexOf('.')
            val base = if (dot > 0) name.substring(0, dot) else name
            val ext = if (dot > 0) name.substring(dot) else ""
            var index = 1
            while (target.exists() && index < 1000) {
                target = File(destDir, "$base ($index)$ext")
                index++
            }
        }
        if (target.exists()) return false
        val staging = File(destDir, ".${target.name}.importing-${System.nanoTime()}")
        temp = staging
        ctx.contentResolver.openInputStream(uri)?.use { ins ->
            staging.outputStream().use { out -> ins.copyTo(out) }
        } ?: return false
        if (!staging.renameTo(target)) return false
        temp = null
        true
    } catch (_: Exception) {
        false
    } finally {
        try { temp?.delete() } catch (_: Exception) { }
    }
}

// --------------------------------- Git -------------------------------------

/** "Save as" picker: input = (suggested file name, mime type), output = destination Uri or null. */
internal class ExportFileContract :
    androidx.activity.result.contract.ActivityResultContract<Pair<String, String>, android.net.Uri?>() {
    override fun createIntent(context: android.content.Context, input: Pair<String, String>): android.content.Intent =
        android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT)
            .addCategory(android.content.Intent.CATEGORY_OPENABLE)
            .setType(input.second)
            .putExtra(android.content.Intent.EXTRA_TITLE, input.first)

    override fun parseResult(resultCode: Int, intent: android.content.Intent?): android.net.Uri? =
        if (resultCode == android.app.Activity.RESULT_OK) intent?.data else null
}
