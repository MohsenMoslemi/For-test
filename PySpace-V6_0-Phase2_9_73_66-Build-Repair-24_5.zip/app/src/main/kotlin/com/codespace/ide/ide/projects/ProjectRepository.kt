package com.codespace.ide.ide.projects

import com.codespace.ide.ProotManager






import com.codespace.ide.runtime.RuntimeDispatchers
import java.io.File
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import com.codespace.ide.UbuntuManager
import com.codespace.ide.ide.PythonRuntimeCatalog

/** IO boundary for workspace-backed project metadata and mutations. */
interface ProjectRepository {
    suspend fun getProjects(workspace: File): List<PyProject>
    suspend fun countPythonFiles(project: PyProject): Int
    suspend fun ensurePythonRuntime(versionId: String, onProgress: (String, Float?) -> Unit = { _, _ -> })
    suspend fun isPythonRuntimeInstalled(versionId: String): Boolean
    suspend fun removePythonRuntime(workspace: File, versionId: String)
    suspend fun changeProjectPythonVersion(project: PyProject, versionId: String)
    suspend fun createProject(workspace: File, name: String, venvName: String, pythonVersionId: String): PyProject?
    suspend fun renameProject(project: PyProject, newName: String): PyProject?
    suspend fun deleteProject(project: PyProject): Boolean
    suspend fun saveVenvName(project: PyProject, rawName: String): Boolean
    suspend fun buildVirtualEnv(project: PyProject): String
}

class FileProjectRepository(
    private val proot: ProotManager,
    private val ubuntu: com.codespace.ide.UbuntuManager,
    private val dispatchers: RuntimeDispatchers = RuntimeDispatchers.Default,
) : ProjectRepository {
    private val pythonInstaller = PythonRuntimeInstaller(ubuntu, proot)

    override suspend fun ensurePythonRuntime(versionId: String, onProgress: (String, Float?) -> Unit) =
        withContext(dispatchers.io) { pythonInstaller.ensureInstalled(versionId, onProgress) }

    override suspend fun removePythonRuntime(workspace: File, versionId: String) = withContext(dispatchers.io) {
        val option = com.codespace.ide.ide.PythonRuntimeCatalog.require(versionId)
        require(!option.isBundled) { "The bundled Python runtime cannot be removed." }
        val inUse = listProjects(workspace).firstOrNull { com.codespace.ide.ide.projectPythonVersionId(it.dir) == versionId }
        require(inUse == null) { "Python ${option.version} is used by project ${inUse?.name}. Change that project’s interpreter before removing this runtime." }
        val target = File(ubuntu.rootfsDir, "opt/pyspace-python/${option.version}")
        if (target.exists() && !target.deleteRecursively()) throw IllegalStateException("Could not remove Python ${option.version}.")
    }

    override suspend fun changeProjectPythonVersion(project: PyProject, versionId: String) = withContext(dispatchers.io) {
        val option = com.codespace.ide.ide.PythonRuntimeCatalog.require(versionId)
        ensurePythonRuntime(versionId) { _, _ -> }
        val metadata = File(project.dir, ".pyspace_python_version")
        val current = com.codespace.ide.ide.projectPythonVersionId(project.dir)
        if (current == versionId) return@withContext

        val venvName = sanitizeName(projectVenvName(project.dir)).ifEmpty { ".venv" }
        val venvDir = File(project.dir, venvName)
        if (venvDir.exists() && !com.codespace.ide.ide.projects.venvPythonReady(project.dir, venvName)) {
            throw IllegalStateException("The configured environment folder exists but is not a valid virtual environment. Rename or remove it before changing Python.")
        }

        if (com.codespace.ide.ide.projects.venvPythonReady(project.dir, venvName)) {
            val guestProject = guestProjectPath(project)
            val interpreter = option.guestExecutable
            val stage = ".${venvName}.pyspace-new"
            val backup = ".${venvName}.pyspace-old"
            val q: (String) -> String = { value -> "'" + value.replace("'", "'\\''") + "'" }
            val command = "set -eu; cd ${q(guestProject)}; " +
                "if [ -d ${q(backup)} ]; then rm -rf ${q(venvName)}; mv ${q(backup)} ${q(venvName)}; printf '%s\\n' ${q(current)} > ${q(".pyspace_python_version")}; fi; " +
                "rm -rf ${q(stage)}; " +
                "trap \"if [ -d ${q(backup)} ]; then rm -rf ${q(venvName)}; mv ${q(backup)} ${q(venvName)}; printf '%s\\\\n' ${q(current)} > ${q(".pyspace_python_version")}; fi; rm -rf ${q(stage)}\" EXIT; " +
                "${q(interpreter)} -m venv ${q(stage)} 2>&1 || ${q(interpreter)} -m venv --without-pip ${q(stage)} 2>&1; " +
                "test -f ${q(stage + "/pyvenv.cfg")} && test -x ${q(stage + "/bin/python")} && ${q(stage + "/bin/python")} --version; " +
                "mv ${q(venvName)} ${q(backup)}; mv ${q(stage)} ${q(venvName)}; " +
                "printf '%s\\n' ${q(versionId)} > ${q(".pyspace_python_version.tmp")}; " +
                "mv ${q(".pyspace_python_version.tmp")} ${q(".pyspace_python_version")}; " +
                "trap - EXIT; rm -rf ${q(backup)}; echo PYSPACE_PYTHON_CHANGED"
            val output = proot.runOnce(command, timeoutSec = 300L)
            check(output.contains("PYSPACE_PYTHON_CHANGED") && output.contains("[exit=0]")) {
                "Could not safely rebuild the project environment. The previous environment was preserved. " + output.lineSequence().filter { it.isNotBlank() }.toList().takeLast(5).joinToString(" / ").take(400)
            }
        } else {
            val temp = File(project.dir, ".pyspace_python_version.tmp")
            temp.writeText("$versionId\n")
            if (!temp.renameTo(metadata)) {
                temp.delete()
                throw IllegalStateException("Could not save the selected Python version.")
            }
        }
    }

    override suspend fun isPythonRuntimeInstalled(versionId: String): Boolean = withContext(dispatchers.io) {
        val option = com.codespace.ide.ide.PythonRuntimeCatalog.require(versionId)
        if (option.isBundled) return@withContext true
        val root = ubuntu.rootfsDir
        val binary = File(root, "opt/pyspace-python/${option.version}/bin/python${option.version.substringBeforeLast('.')}")
        val marker = File(root, "opt/pyspace-python/${option.version}/.pyspace-runtime-ready")
        binary.isFile && marker.isFile && marker.readText().trim() == option.version
    }

    override suspend fun getProjects(workspace: File): List<PyProject> =
        withContext(dispatchers.io) { listProjects(workspace) }

    override suspend fun countPythonFiles(project: PyProject): Int =
        withContext(dispatchers.io) {
            try {
                val context = currentCoroutineContext()
                var count = 0
                var visited = 0
                for (file in project.dir.walkTopDown()) {
                    if ((visited++ and 127) == 0) context.ensureActive()
                    if (file.isFile && file.extension.equals("py", ignoreCase = true)) count++
                }
                count
            } catch (_: SecurityException) {
                0
            } catch (_: java.io.IOException) {
                0
            }
        }

    override suspend fun createProject(workspace: File, name: String, venvName: String, pythonVersionId: String): PyProject? =
        withContext(dispatchers.io) { createProjectOnDisk(workspace, name, venvName, pythonVersionId) }

    override suspend fun renameProject(project: PyProject, newName: String): PyProject? =
        withContext(dispatchers.io) {
            renameFile(project.dir, newName)?.let { renamed -> PyProject(renamed.name, renamed) }
        }

    override suspend fun deleteProject(project: PyProject): Boolean =
        withContext(dispatchers.io) { deleteRecursivelySafe(project.dir) }

    override suspend fun saveVenvName(project: PyProject, rawName: String): Boolean =
        withContext(dispatchers.io) {
            val clean = sanitizeName(rawName).ifEmpty { ".venv" }
            try {
                val oldName = projectVenvName(project.dir)
                val old = File(project.dir, oldName)
                val wanted = File(project.dir, clean)
                if (old.absolutePath != wanted.absolutePath && old.exists()) {
                    if (wanted.exists() || !old.renameTo(wanted)) return@withContext false
                }
                File(project.dir, ".pyspace_venv").writeText(clean)
                true
            } catch (_: Exception) {
                false
            }
        }

    override suspend fun buildVirtualEnv(project: PyProject): String = withContext(dispatchers.io) {
        val versionId = projectPythonVersionId(project.dir)
        try {
            pythonInstaller.ensureInstalled(versionId) { _, _ -> }
        } catch (error: Exception) {
            return@withContext error.message ?: "Selected Python runtime is not available."
        }
        val venv = sanitizeName(projectVenvName(project.dir)).ifEmpty { ".venv" }
        val guestPath = guestProjectPath(project).replace("\"", "\\\"")
        val interpreter = projectPythonInterpreterGuestPath(project.dir).replace("\"", "\\\"")
        val command = "cd \"$guestPath\" || exit 1; " +
            "test -x \"$interpreter\" || { echo PYTHON-INTERPRETER-MISSING; exit 21; }; " +
            "rm -rf \"$venv\" && " +
            "\"$interpreter\" -m venv \"$venv\" 2>&1; " +
            "test -x \"$venv/bin/python\" || " +
            "\"$interpreter\" -m venv --without-pip \"$venv\" 2>&1; " +
            "test -x \"$venv/bin/python\" && \"$venv/bin/python\" --version && echo VENV-READY"
        val output = proot.runOnce(command, timeoutSec = 300L)
        val ready = output.lineSequence().any { it.trim() == "VENV-READY" } ||
            venvPythonReady(project.dir, venv)
        if (ready) "" else output.lineSequence().filter { it.isNotBlank() }
            .toList().takeLast(4).joinToString(" / ").take(300).ifBlank { "Virtual environment creation failed" }
    }
}
