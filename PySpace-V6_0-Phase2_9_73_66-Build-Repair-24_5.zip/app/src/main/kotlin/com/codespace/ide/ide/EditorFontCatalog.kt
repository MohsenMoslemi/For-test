package com.codespace.ide.ide

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.codespace.ide.R

/** Bundled typefaces available only to the source-code editor and its line-number gutter. */
data class EditorFontOption(
    val id: String,
    val title: String,
    val description: String,
    val family: FontFamily,
)

object EditorFontCatalog {
    const val DEFAULT_ID = "jetbrains_mono"

    val options: List<EditorFontOption> = listOf(
        EditorFontOption(
            "jetbrains_mono", "JetBrains Mono", "Developer-focused · programming ligatures",
            FontFamily(
                Font(R.font.jetbrains_mono_regular, FontWeight.Normal),
                Font(R.font.jetbrains_mono_medium, FontWeight.Medium),
                Font(R.font.jetbrains_mono_semibold, FontWeight.SemiBold),
                Font(R.font.jetbrains_mono_bold, FontWeight.Bold),
            )
        ),
        EditorFontOption(
            "fira_code", "Fira Code", "Distinctive programming ligatures",
            FontFamily(
                Font(R.font.fira_code_regular, FontWeight.Normal),
                Font(R.font.fira_code_medium, FontWeight.Medium),
                Font(R.font.fira_code_semibold, FontWeight.SemiBold),
                Font(R.font.fira_code_bold, FontWeight.Bold),
            )
        ),
        EditorFontOption(
            "ibm_plex_mono", "IBM Plex Mono", "Balanced · no programming ligatures",
            FontFamily(
                Font(R.font.ibm_plex_mono_regular, FontWeight.Normal),
                Font(R.font.ibm_plex_mono_medium, FontWeight.Medium),
                Font(R.font.ibm_plex_mono_semibold, FontWeight.SemiBold),
                Font(R.font.ibm_plex_mono_bold, FontWeight.Bold),
            )
        ),
        EditorFontOption(
            "source_code_pro", "Source Code Pro", "Neutral · clean and compact",
            FontFamily(
                Font(R.font.source_code_pro_regular, FontWeight.Normal),
                Font(R.font.source_code_pro_medium, FontWeight.Medium),
                Font(R.font.source_code_pro_semibold, FontWeight.SemiBold),
                Font(R.font.source_code_pro_bold, FontWeight.Bold),
            )
        ),
    )

    fun normalizeId(id: String?): String =
        options.firstOrNull { it.id == id }?.id ?: DEFAULT_ID

    fun find(id: String?): EditorFontOption =
        options.firstOrNull { it.id == normalizeId(id) } ?: options.first()
}
