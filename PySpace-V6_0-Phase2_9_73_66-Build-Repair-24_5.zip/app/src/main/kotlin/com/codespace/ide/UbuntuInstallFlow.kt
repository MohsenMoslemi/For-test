package com.codespace.ide

import com.codespace.ide.ide.IdeAlertDialog
import com.codespace.ide.ide.settings.IdePrefs
import com.codespace.ide.ide.theme.IdeTheme
import com.codespace.ide.runtime.RuntimeDispatchers
import com.codespace.ide.di.AppDependencies

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Bundle
import android.os.SystemClock
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitLongPressOrCancellation
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateOffsetAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.layout.positionInWindow
import kotlin.math.abs
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.offset
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalTextToolbar
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.codespace.ide.ui.install.InstallViewModel
import com.codespace.ide.ide.terminal.TerminalCallbacks
import com.codespace.ide.ide.terminal.TerminalLaunchConfig
import com.codespace.ide.ide.terminal.TerminalViewModel
import com.codespace.ide.ide.terminal.TerminalRepository
import com.codespace.ide.memory.MemoryRuntimePolicy
import org.koin.core.context.GlobalContext
import com.codespace.ide.ide.terminal.TerminalScreenState
import com.codespace.ide.ide.codeintel.PythonLspRuntimeInstaller

@Composable
internal fun UbuntuTerminalApp(dependencies: AppDependencies) {
    val ubuntu = dependencies.ubuntuManager
    val proot = dependencies.prootManager
    val appContext = LocalContext.current.applicationContext
    var installed by remember { mutableStateOf(ubuntu.isInstalled()) }
    LaunchedEffect(Unit) {
        // Live-install repair (idempotent, no-op when the rootfs or the
        // file is absent): silence the group-name stderr Ubuntu's
        // sudo-hint probe leaks above every first prompt. Fresh installs
        // are patched inside install().
        ubuntu.suppressGroupNoise()
    }
    LaunchedEffect(installed) {
        if (installed) {
            // Prepare Jedi/pylsp immediately after Ubuntu extraction (and on
            // later app launches for existing installations). This runs off
            // the main thread and is shared with any early editor request.
            launch(Dispatchers.IO) {
                com.codespace.ide.ide.codeintel.PythonLspRuntimeInstaller
                    .ensureInstalled(appContext, proot)
            }
        }
    }

    MaterialTheme(
        colorScheme = if (IdeTheme.isDark) darkColorScheme(
            primary = Accent,
            onPrimary = Color(IdeTheme.ON_ACCENT),
            background = TerminalBg,
            surface = Color(IdeTheme.PANEL),
            onBackground = TermText,
            onSurface = TermText
        ) else androidx.compose.material3.lightColorScheme(
            primary = Accent,
            onPrimary = Color(IdeTheme.ON_ACCENT),
            background = TerminalBg,
            surface = Color(IdeTheme.PANEL),
            onBackground = TermText,
            onSurface = TermText
        )
    ) {
        if (!installed) {
            InstallScreen(
                ubuntu = ubuntu,
                proot = proot,
                dispatchers = dependencies.runtimeDispatchers,
                isUpdate = try {
                    ubuntu.needsUpdate()
                } catch (_: Exception) {
                    false
                },
                onInstalled = { installed = true }
            )
        } else {
            // Python IDE shell: home/projects/editor/settings. The terminal
            // lives on as the IDE's bottom panel (same session, same
            // selection engine) — no longer as the launch screen.
            com.codespace.ide.ide.IdeRoot(dependencies = dependencies)
        }
    }
}

@Composable
private fun InstallScreen(
    ubuntu: UbuntuManager,
    proot: ProotManager,
    dispatchers: RuntimeDispatchers,
    isUpdate: Boolean = false,
    onInstalled: () -> Unit
) {
    val activity = LocalContext.current as ComponentActivity
    val appContext = activity.applicationContext
    val vm: InstallViewModel by activity.viewModels {
        InstallViewModel.Factory(
            ubuntu = ubuntu,
            proot = proot,
            appContext = appContext,
            dispatchers = dispatchers,
            initialLog = if (isUpdate) {
                "Your development environment needs an update. Your projects will be kept safe."
            } else {
                "Your Python workspace is being prepared for the first launch."
            }
        )
    }
    val state by vm.state.collectAsState()
    val scroll = rememberScrollState()

    LaunchedEffect(state.log) {
        try { scroll.animateScrollTo(scroll.maxValue) } catch (_: Exception) { }
    }
    LaunchedEffect(state.installed) { if (state.installed) onInstalled() }

    val title = buildAnnotatedString {
        pushStyle(SpanStyle(color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.ExtraBold))
        append("Py")
        pop()
        pushStyle(SpanStyle(color = Color(IdeTheme.TEXT), fontWeight = FontWeight.ExtraBold))
        append("Space")
        pop()
    }
    val progress = state.progress

    Column(
        modifier = Modifier.fillMaxSize().background(TerminalBg).padding(horizontal = 24.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.displaySmall.copy(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.ExtraBold), letterSpacing = (-1.5).sp)
            Text(
                "YOUR PYTHON WORKSPACE",
                color = Color(IdeTheme.ACCENT),
                fontSize = 10.sp,
                letterSpacing = 2.2.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(18.dp))
            Text(
                if (isUpdate) "A fresh workspace is on its way." else "Everything you need to build with Python.",
                color = TermText,
                fontSize = 23.sp,
                lineHeight = 30.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                if (isUpdate) "We are refreshing the runtime while keeping your projects safe."
                else "PySpace is preparing its Python runtime and offline code intelligence. This happens once.",
                color = Color(IdeTheme.DIM),
                fontSize = 14.sp,
                lineHeight = 21.sp
            )
        }

        Column(
            modifier = Modifier.fillMaxWidth().background(Color(IdeTheme.CARD), RoundedCornerShape(22.dp)).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(42.dp).background(Color(IdeTheme.ACCENT).copy(alpha = 0.13f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (state.busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color(IdeTheme.ACCENT), strokeWidth = 2.dp)
                    else Text("Py", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                }
                Spacer(Modifier.size(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (state.busy) "Setting things up" else "Ready when you are", color = TermText, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    Text(if (state.busy) "Python runtime · offline tools" else "Python · Editor · IntelliSense", color = Color(IdeTheme.DIM), fontSize = 12.sp)
                }
                if (progress != null && state.busy) {
                    Text("${(progress * 100).toInt()}%", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
            if (state.busy) {
                if (progress != null) {
                    LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape), color = Color(IdeTheme.ACCENT), trackColor = Color(IdeTheme.LINE))
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape), color = Color(IdeTheme.ACCENT), trackColor = Color(IdeTheme.LINE))
                }
                if (state.etaSeconds != null && state.etaSeconds!! > 0) {
                    val seconds = state.etaSeconds!!
                    val eta = if (seconds >= 60) "About ${seconds / 60} min ${seconds % 60} sec remaining" else "About $seconds sec remaining"
                    Text(eta, color = Color(IdeTheme.DIM), fontSize = 11.sp)
                }
            }
            Text(
                state.phase,
                color = Color(IdeTheme.TEXT),
                fontSize = 12.sp,
                lineHeight = 18.sp
            )
            Button(
                enabled = !state.busy,
                onClick = { vm.install(isUpdate) },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(IdeTheme.ACCENT), contentColor = Color(IdeTheme.ON_ACCENT))
            ) {
                Text(if (state.busy) "Preparing PySpace…" else if (isUpdate) "Update PySpace" else "Get started", fontWeight = FontWeight.Bold)
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("SETUP DETAILS", color = Color(IdeTheme.DIM), fontSize = 9.sp, letterSpacing = 1.8.sp, fontWeight = FontWeight.Bold)
            SelectionContainer(Modifier.fillMaxWidth().heightIn(max = 86.dp).verticalScroll(scroll)) {
                Text(state.log, style = TermStyle.copy(fontSize = 10.sp, lineHeight = 14.sp), color = Color(IdeTheme.DIM))
            }
            Text("Offline-first · Your projects stay yours", color = Color(IdeTheme.DIM), fontSize = 10.sp)
        }
    }
}

