package com.codespace.ide.ide.notebook

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

/** Owns output-size accounting, bounded MIME payloads and throttled cell-output publication. */
internal class NotebookOutputBuffer(private val scope: CoroutineScope) {
    private val outputSizes = HashMap<String, Int>()
    private val dirtyCells = LinkedHashSet<NbCell>()
    private var refreshJob: Job? = null

    /** Clears accounting and pending UI notifications when the document is replaced. */
    fun clear() {
        refreshJob?.cancel()
        refreshJob = null
        outputSizes.clear()
        dirtyCells.clear()
    }

    /** Retires a removed cell from both accounting and the batched notification set. */
    fun remove(cellId: String) {
        outputSizes.remove(cellId)
        dirtyCells.removeAll { it.id == cellId }
        if (dirtyCells.isEmpty()) {
            refreshJob?.cancel()
            refreshJob = null
        }
    }

    fun dataOf(message: JSONObject): Map<String, String> {
        val data = message.optJSONObject("data") ?: return emptyMap()
        val result = LinkedHashMap<String, String>()
        val keys = data.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val raw = data.opt(key)?.toString() ?: ""
            result[key] = if (raw.length > MAX_MIME_CHARS) raw.take(MAX_MIME_CHARS) + "\n… output truncated by PySpace (size limit) …" else raw
        }
        return result
    }

    fun append(cell: NbCell, output: NbOutput) {
        val currentSize = outputSizes[cell.id] ?: cell.outputs.sumOf { it.text.length + it.data.values.sumOf(String::length) }
        val incoming = output.text.length + output.data.values.sumOf(String::length)
        if (currentSize >= MAX_CELL_OUTPUT_CHARS) return
        if (incoming > MAX_CELL_OUTPUT_CHARS - currentSize) {
            val remaining = (MAX_CELL_OUTPUT_CHARS - currentSize).coerceAtLeast(0)
            val limitedText = output.text.take(remaining)
            var dataBudget = (remaining - limitedText.length).coerceAtLeast(0)
            val limitedData = LinkedHashMap<String, String>()
            for ((mime, value) in output.data) {
                if (dataBudget <= 0) break
                val part = value.take(dataBudget)
                limitedData[mime] = part
                dataBudget -= part.length
            }
            cell.outputs.add(NbOutput(output.kind, output.name, limitedText, limitedData, output.ename, output.evalue, output.execCount))
            cell.outputs.add(NbOutput("stream", text = "\n… output truncated by PySpace (cell output limit) …"))
            outputSizes[cell.id] = MAX_CELL_OUTPUT_CHARS
            cell.notifyOutputChanged()
            return
        }
        cell.outputs.add(output)
        outputSizes[cell.id] = currentSize + incoming
        cell.notifyOutputChanged()
    }

    fun appendStream(cell: NbCell, name: String, text: String) {
        val currentSize = outputSizes[cell.id] ?: cell.outputs.sumOf { it.text.length + it.data.values.sumOf(String::length) }
        if (currentSize >= MAX_CELL_OUTPUT_CHARS) return
        val remaining = MAX_CELL_OUTPUT_CHARS - currentSize
        val piece = text.take(remaining)
        val last = cell.outputs.lastOrNull()
        if (last != null && last.kind == "stream" && last.name == name) last.text += piece
        else if (piece.isNotEmpty()) cell.outputs.add(NbOutput("stream", name, piece))
        val newSize = currentSize + piece.length
        outputSizes[cell.id] = newSize
        if (piece.length < text.length || newSize >= MAX_CELL_OUTPUT_CHARS) {
            cell.outputs.add(NbOutput("stream", name, "\n… output truncated by PySpace (cell output limit) …"))
            outputSizes[cell.id] = MAX_CELL_OUTPUT_CHARS
        }
        dirtyCells.add(cell)
        if (refreshJob?.isActive != true) refreshJob = scope.launch { delay(45L); flush() }
    }

    fun flush() {
        refreshJob?.cancel()
        refreshJob = null
        if (dirtyCells.isEmpty()) return
        val changed = dirtyCells.toList()
        dirtyCells.clear()
        changed.forEach { it.notifyOutputChanged() }
    }

    fun dispose() {
        flush()
        refreshJob?.cancel()
        refreshJob = null
    }

    private companion object {
        const val MAX_CELL_OUTPUT_CHARS = 250_000
        const val MAX_MIME_CHARS = 8 * 1024 * 1024
    }
}
