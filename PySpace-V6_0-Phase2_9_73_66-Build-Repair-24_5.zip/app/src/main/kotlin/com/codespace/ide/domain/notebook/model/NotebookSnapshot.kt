package com.codespace.ide.domain.notebook.model

/** Immutable, Compose-independent representation of a Jupyter notebook. */
data class NbOutputSnapshot(
    val kind: String,
    val name: String,
    val text: String,
    val data: Map<String, String>,
    val ename: String,
    val evalue: String,
    val execCount: Int?,
)

data class NbCellSnapshot(
    val id: String,
    val type: String,
    val source: String,
    val execCount: Int?,
    val extraJson: String,
    val outputs: List<NbOutputSnapshot>,
)

data class NbDocSnapshot(
    val cells: List<NbCellSnapshot>,
    val metadataJson: String,
    val nbformat: Int,
    val minor: Int,
    val useIds: Boolean,
)
