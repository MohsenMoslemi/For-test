package com.codespace.ide.ide.notebook

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.codespace.ide.domain.notebook.model.NotebookExecutionQueue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import org.json.JSONObject
import com.codespace.ide.ide.JSON
import com.codespace.ide.ide.NbKernel

/**
 * Per-open-notebook MVVM state holder. The document and cell queue are mutated
 * on the UI dispatcher. Kernel startup and socket/process work stay behind
 * [NbKernel] and [NotebookRepository].
 */
class NotebookViewModel(
    val doc: NbDoc,
    val kernel: NbKernel,
    private val scope: CoroutineScope
) {
    private val inflight = HashMap<Int, NbCell>()
    private val queue = NotebookExecutionQueue(MAX_QUEUED_CELLS)
    private val outputBuffer = NotebookOutputBuffer(scope)
    private var current: NbCell? = null
    private var restartInProgress = false
    private var pendingDocument: NbDoc? = null
    private var persistenceJob: Job? = null
    private var persistDocument: (suspend (NbDoc, Int) -> Unit)? = null
    private var executionJob: Job? = null
    private var warmupJob: Job? = null
    @Volatile private var activeExecutionId: Int? = null
    private var restartJob: Job? = null
    @Volatile private var disposed = false

    var version by mutableStateOf(0)
        private set
    var starting by mutableStateOf(false)
        private set
    var lastError by mutableStateOf<String?>(null)
        private set

    val isDocumentReplacementPending: Boolean get() = pendingDocument != null

    init {
        // Start the isolated interpreter as soon as the notebook session is
        // opened, while the user is viewing/editing cells. Run then usually
        // finds a warm kernel instead of paying the PRoot + Python cold start.
        if (!kernel.alive()) {
            starting = true
            warmupJob = scope.launch {
                try {
                    if (!kernel.ensureStarted() && !disposed) {
                        lastError = "Python kernel could not start. Check the project Python environment."
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: Exception) {
                    if (!disposed) lastError = error.message ?: "Unable to start Python kernel"
                } finally {
                    warmupJob = null
                    if (!disposed) starting = false
                }
            }
        }
    }

    fun setPersistenceHandler(handler: suspend (NbDoc, Int) -> Unit) {
        if (disposed) return
        persistDocument = handler
        if (version > 0) schedulePersistence()
    }

    /** Apply edits made in Raw JSON without replacing a kernel that is executing a cell. */
    fun replaceDocument(replacement: NbDoc) {
        if (disposed) return
        if (kernel.state.value == "busy" || current != null) {
            clearQueue()
            pendingDocument = replacement
            lastError = "Raw JSON changes will be applied after the running cell finishes."
            persistenceJob?.cancel()
            persistenceJob = null
            return
        }
        applyDocument(replacement)
    }

    private fun applyPendingDocumentIfReady() {
        val replacement = pendingDocument ?: return
        if (kernel.state.value == "busy" || current != null) return
        pendingDocument = null
        applyDocument(replacement)
    }

    private fun applyDocument(replacement: NbDoc) {
        clearQueue()
        inflight.clear()
        outputBuffer.clear()
        current = null
        doc.cells.clear()
        doc.cells.addAll(replacement.cells)
        doc.meta = replacement.meta
        doc.nbformat = replacement.nbformat
        doc.minor = replacement.minor
        doc.useIds = replacement.useIds
        lastError = null
        touch()
    }

    fun touch() {
        if (disposed) return
        version++
        schedulePersistence()
    }

    private fun schedulePersistence() {
        val handler = persistDocument ?: return
        if (pendingDocument != null) return
        persistenceJob?.cancel()
        val revision = version
        persistenceJob = scope.launch {
            delay(PERSIST_DEBOUNCE_MS)
            if (revision == version) handler(doc, revision)
        }
    }

    fun run(cells: List<NbCell>) {
        if (disposed || restartInProgress) return
        for (cell in cells) {
            if (cell.type != "code" || cell.source.isBlank() || cell.queued || cell.running) continue
            if (!queue.enqueue(cell.id)) {
                lastError = "Too many cells are queued. Run a smaller selection."
                break
            }
            cell.queued = true
        }
        pump()
    }

    private fun clearQueue() {
        queue.clear().forEach { cellId ->
            doc.cells.firstOrNull { it.id == cellId }?.queued = false
        }
    }

    private fun pump() {
        if (disposed || current != null || restartInProgress) return
        val nextId = queue.poll() ?: return
        val next = doc.cells.firstOrNull { it.id == nextId }
        if (next == null) {
            // A cell may have been removed while queued. Skip it without
            // disturbing the active kernel request or later queue entries.
            pump()
            return
        }
        current = next
        executionJob?.cancel()
        executionJob = scope.launch {
            currentCoroutineContext().ensureActive()
            if (disposed) return@launch
            starting = !kernel.alive()
            lastError = null
            val ok = try {
                kernel.ensureStarted()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                lastError = error.message ?: "Unable to start Python kernel"
                false
            } finally {
                starting = false
            }
            currentCoroutineContext().ensureActive()
            if (disposed) return@launch
            if (!ok) {
                next.queued = false
                next.running = false
                appendOutput(next, NbOutput(
                    "error",
                    text = lastError ?: "The Python kernel did not start. Is Python installed for this project?",
                    ename = "KernelError",
                    evalue = "start failed"
                ))
                current = null
                clearQueue()
                touch()
                return@launch
            }
            next.queued = false
            next.running = true
            next.outputs.clear()
            outputBuffer.remove(next.id)
            val id = kernel.nextId()
            activeExecutionId = id
            inflight[id] = next
            kernel.execute(id, next.source)
            touch()
        }
    }

    private fun appendOutput(cell: NbCell, output: NbOutput) = outputBuffer.append(cell, output)
    private fun appendStream(cell: NbCell, name: String, text: String) = outputBuffer.appendStream(cell, name, text)

    fun onMessage(message: JSONObject) {
        if (disposed) return
        val type = message.optString("type")
        if (type == "reset") {
            // This notebook's own interpreter was restarted. Clear its stale
            // in-flight and queued cell bookkeeping.
            for (cell in doc.cells) {
                cell.running = false
                cell.queued = false
            }
            inflight.clear()
            outputBuffer.clear()
            activeExecutionId = null
            current = null
            clearQueue()
            lastError = null
            applyPendingDocumentIfReady()
            touch()
            return
        }
        if (type == "dead") {
            for (cell in doc.cells) {
                cell.running = false
                cell.queued = false
            }
            inflight.clear()
            outputBuffer.clear()
            activeExecutionId = null
            current?.running = false
            current?.queued = false
            current = null
            clearQueue()
            lastError = "Python kernel stopped unexpectedly. Restart the kernel to continue."
            applyPendingDocumentIfReady()
            touch()
            return
        }
        val id = message.optInt("id")
        val cell = inflight[id]
        // Messages queued by an old socket can arrive after a restart. Ignore
        // them instead of advancing the new execution queue.
        if (cell == null) return
        if (type == "stream") {
            appendStream(cell, message.optString("name", "stdout"), message.optString("text"))
            return
        }
        if (type == "done") outputBuffer.flush()
        when (type) {
            "display" -> appendOutput(cell, NbOutput("display", data = outputBuffer.dataOf(message)))
            "result" -> appendOutput(cell, NbOutput("result", data = outputBuffer.dataOf(message), execCount = message.optInt("execution_count")))
            "error" -> {
                val traceback = message.optJSONArray("traceback")
                val lines = if (traceback == null) "" else (0 until traceback.length())
                    .joinToString("\n") { traceback.optString(it) }.take(MAX_TRACEBACK_CHARS)
                appendOutput(cell, NbOutput(
                    "error", text = lines,
                    ename = message.optString("ename"), evalue = message.optString("evalue")
                ))
            }
            "clear" -> {
                cell.outputs.clear()
                cell.notifyOutputChanged()
                outputBuffer.remove(cell.id)
            }
            "done" -> {
                cell.running = false
                cell.execCount = message.optInt("execution_count")
                inflight.remove(id)
                if (activeExecutionId == id) activeExecutionId = null
                outputBuffer.remove(cell.id)
                if (current === cell) current = null
                // Like Jupyter: Run All stops at the first failed cell.
                if (message.optString("status") == "error") clearQueue()
                if (pendingDocument != null) {
                    applyPendingDocumentIfReady()
                } else {
                    pump()
                }
            }
        }
        touch()
    }

    fun interrupt() {
        if (disposed) return
        clearQueue()
        val executionId = activeExecutionId
        if (executionId != null) {
            // Cancel only this notebook's active request. Other notebooks
            // have separate kernels and cannot be affected.
            kernel.cancel(executionId)
        } else {
            // This cell (or the eager warm-up) is still waiting for this
            // notebook's own kernel. No other notebook can be interrupted.
            kernel.cancelStartup()
            warmupJob?.cancel()
            warmupJob = null
            executionJob?.cancel()
            current?.queued = false
            current?.running = false
            current = null
            starting = false
        }
        touch()
    }

    fun restart() {
        if (disposed || restartInProgress) return
        restartInProgress = true
        clearQueue()
        executionJob?.cancel()
        executionJob = null
        warmupJob?.cancel()
        warmupJob = null
        restartJob?.cancel()
        restartJob = scope.launch {
            doc.cells.forEach { cell ->
                cell.running = false
                cell.queued = false
            }
            inflight.clear()
            outputBuffer.clear()
            activeExecutionId = null
            current = null
            starting = true
            lastError = null
            try {
                currentCoroutineContext().ensureActive()
                if (disposed) return@launch
                if (!kernel.restart()) lastError = "Kernel restart failed. Check the project Python environment."
                applyPendingDocumentIfReady()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                lastError = error.message ?: "Kernel restart failed"
            } finally {
                starting = false
                restartInProgress = false
                if (!disposed) touch()
            }
        }
    }

    fun add(index: Int, type: String): NbCell {
        if (disposed) return NbCell(newCellId(), type, "", null, emptyList())
        val cell = NbCell(newCellId(), type, "", null, emptyList())
        doc.cells.add(index.coerceIn(0, doc.cells.size), cell)
        touch()
        return cell
    }

    fun delete(index: Int) {
        if (disposed) return
        if (index !in doc.cells.indices) return
        val removed = doc.cells.removeAt(index)
        queue.remove(removed.id)
        removed.queued = false
        // A running Python statement is not killed just because its cell is
        // removed from the document. Keep its in-flight mapping until `done`
        // arrives so the next queued cell cannot overlap it.
        if (current !== removed) outputBuffer.remove(removed.id)
        if (doc.cells.isEmpty()) doc.cells.add(NbCell(newCellId(), "code", "", null, emptyList()))
        touch()
    }

    fun move(index: Int, delta: Int) {
        if (disposed) return
        val to = index + delta
        if (index !in doc.cells.indices || to !in doc.cells.indices) return
        val cell = doc.cells.removeAt(index)
        doc.cells.add(to, cell)
        touch()
    }

    fun clearOutputs(cell: NbCell) {
        if (disposed) return
        cell.outputs.clear()
        cell.notifyOutputChanged()
        cell.execCount = null
        outputBuffer.remove(cell.id)
        touch()
    }

    /** Stop pending persistence when this notebook file/session is released. */
    fun dispose() {
        if (disposed) return
        outputBuffer.dispose()
        disposed = true
        activeExecutionId?.let { kernel.cancel(it) }
        activeExecutionId = null
        persistenceJob?.cancel()
        persistenceJob = null
        warmupJob?.cancel()
        warmupJob = null
        executionJob?.cancel()
        executionJob = null
        restartJob?.cancel()
        restartJob = null
        persistDocument = null
    }

    private companion object {
        const val MAX_QUEUED_CELLS = 500
        const val MAX_TRACEBACK_CHARS = 32_000
        const val PERSIST_DEBOUNCE_MS = 650L
    }
}
