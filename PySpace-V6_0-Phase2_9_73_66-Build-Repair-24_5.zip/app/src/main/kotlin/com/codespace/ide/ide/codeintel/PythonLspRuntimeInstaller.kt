package com.codespace.ide.ide.codeintel

import android.content.Context
import com.codespace.ide.ProotManager
import com.codespace.ide.runtime.RuntimeAssetCipher
import java.io.File
import java.util.zip.ZipInputStream

/** Installs the bundled Python language server once, off the UI thread. */
object PythonLspRuntimeInstaller {
    private const val WHEELHOUSE_ASSET = "runtime/lsp.psr"
    private const val READY_MARKER = ".installed-v2.1.0-jedi-0.20.1-formatting"
    private const val INSTALL_TIMEOUT_SECONDS = 180L

    /**
     * Synchronized because app-startup prewarming and an early editor request
     * may race. The caller must invoke this from an IO/background dispatcher.
     */
    @Synchronized
    fun ensureInstalled(context: Context, proot: ProotManager): Boolean {
        val rootfs = File(context.filesDir, "ubuntu-rootfs")
        val base = File(rootfs, "opt/pyspace-lsp")
        val wheelhouse = File(base, "wheelhouse")
        val installed = File(base, READY_MARKER)
        if (installed.isFile && File(base, "venv/bin/pylsp").isFile) return true
        return try {
            if (!File(wheelhouse, ".ready-v2").isFile) {
                if (wheelhouse.exists()) wheelhouse.deleteRecursively()
                if (!wheelhouse.mkdirs()) return false
                RuntimeAssetCipher.openAsset(context, WHEELHOUSE_ASSET).use { raw ->
                    ZipInputStream(raw).use { zip ->
                        while (true) {
                            val entry = zip.nextEntry ?: break
                            if (!entry.isDirectory) {
                                val normalized = entry.name.replace('\\', '/')
                                if (normalized.startsWith("/") || normalized.split('/').any { it == ".." }) {
                                    throw IllegalStateException("Unsafe wheelhouse asset entry")
                                }
                                val relative = normalized.removePrefix("pyspace-lsp-wheelhouse/")
                                if (relative.isNotBlank() && relative != normalized) {
                                    val out = File(wheelhouse, relative)
                                    out.parentFile?.mkdirs()
                                    out.outputStream().use { target -> zip.copyTo(target) }
                                }
                            }
                            zip.closeEntry()
                        }
                    }
                }
                File(wheelhouse, ".ready-v2").writeText("pyspace-lsp-wheelhouse-v2\n")
            }
            val script = "set -eu; " +
                "mkdir -p /opt/pyspace-lsp; " +
                "if [ ! -x /opt/pyspace-lsp/venv/bin/python ]; then /usr/bin/python3 -m venv /opt/pyspace-lsp/venv; fi; " +
                "if ! /opt/pyspace-lsp/venv/bin/python -c 'import pylsp,jedi,pyflakes,pycodestyle' >/dev/null 2>&1; then " +
                "/opt/pyspace-lsp/venv/bin/python -m pip install --disable-pip-version-check --no-index --find-links=/opt/pyspace-lsp/wheelhouse " +
                "'python-lsp-server==1.15.0' 'pyflakes==3.2.0' 'pycodestyle==2.12.1'; fi; " +
                // Optional offline formatter: install only if the APK wheelhouse ships its wheel.
                "set -- /opt/pyspace-lsp/wheelhouse/autopep8-*.whl; " +
                "if [ -f \"\$1\" ]; then /opt/pyspace-lsp/venv/bin/python -m pip install --disable-pip-version-check --no-index --find-links=/opt/pyspace-lsp/wheelhouse autopep8; fi; " +
                "/opt/pyspace-lsp/venv/bin/python -c 'import pylsp,jedi,pyflakes; assert jedi.__version__ == \"0.20.1\"; print(\"PYSPACE_LSP_READY\")'; " +
                "touch /opt/pyspace-lsp/$READY_MARKER"
            val output = proot.runOnce(script, timeoutSec = INSTALL_TIMEOUT_SECONDS)
            output.contains("PYSPACE_LSP_READY") && output.contains("[exit=0]") && installed.isFile
        } catch (_: Exception) {
            false
        }
    }
}
