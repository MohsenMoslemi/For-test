package com.codespace.ide.ide.terminal

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import android.os.SystemClock
import android.widget.Toast
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.offset
import androidx.compose.ui.unit.sp
import com.codespace.ide.FLUSH_WINDOW_MS
import com.codespace.ide.HandleH
import com.codespace.ide.HandleTipY
import com.codespace.ide.HandleW
import com.codespace.ide.IME_SENTINEL
import com.codespace.ide.MAX_COPY_CHARS
import com.codespace.ide.MAX_FLUSH_CHARS
import com.codespace.ide.SMALL_FLUSH_CHARS
import com.codespace.ide.TRAILING_FLUSH_MS
import com.codespace.ide.TermHandle
import com.codespace.ide.TermSelection
import com.codespace.ide.TermStyle
import com.codespace.ide.TerminalEmulator
import com.codespace.ide.TerminalScreen
import com.codespace.ide.TerminalSession
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Non-UI core of TerminalScreen: emulator + selection model/geometry, PTY size and flush pump,
 * key/IME translation, clipboard actions. Created once per TerminalScreen (remember) and used via
 * `with(state) { ... }`; composition-bound inputs (clipboard, keyboard, density, text toolbar)
 * are refreshed by TerminalScreen on every composition.
 */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class, androidx.compose.material3.ExperimentalMaterial3Api::class)
internal class TerminalScreenState(
    val scope: kotlinx.coroutines.CoroutineScope,
    val appCtx: android.content.Context,
    val listState: androidx.compose.foundation.lazy.LazyListState,
    var clipboard: androidx.compose.ui.platform.ClipboardManager,
    var keyboard: androidx.compose.ui.platform.SoftwareKeyboardController?,
    var density: androidx.compose.ui.unit.Density,
    var textToolbar: androidx.compose.ui.platform.TextToolbar,
) {
    /** Re-created by TerminalScreen whenever [sessionTick] changes (same key as before the extraction). */
    lateinit var terminalViewModel: TerminalViewModel

    fun toast(msg: String) {
        try {
            Toast.makeText(appCtx, msg, Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
        }
    }

    // The terminal emulator IS the screen state: no separate output/input
    // split. The cursor and typed text live inside it, fed by PTY bytes.
    // Declared before the toolbar/select-all wiring below so the shared
    // copy helpers can use it without forward references.

    val emulator = run { TerminalEmulator() }

    // Independent terminal selection (see TermSelection). Positions address
    // the emulator's transcript — never Compose SelectionManager nodes — so
    // selecting across virtualized rows cannot crash, and Select All covers
    // the whole scrollback rather than composed items. Cleared on terminal
    // tap or restart; new output does NOT clear it.

    var termSel by mutableStateOf<TermSelection?>(null)
    // Latest terminal-surface coordinates, for placing the context menu.
    // Plain holder (not state): written on every layout pass, read only on
    // long-press, so it can never ping-pong into a recomposition loop.

    val termCoordsBox = run { arrayOfNulls<LayoutCoordinates>(1) }

    val menuWanted = run { booleanArrayOf(false) }

    val menuJobBox = run { arrayOfNulls<Job>(1) }

    val lastWinPosBox = run { arrayOfNulls<Offset>(1) }

    fun hideTermMenu() {
        menuWanted[0] = false
        try {
            textToolbar.hide()
        } catch (_: Exception) {
        }
    }
    // Per-line text layouts for pixel-exact hit-testing/placement (see the
    // helpers above offsetToPos). Plain holders (not state): written from
    // onTextLayout during layout, read from gestures and composition
    // without ever triggering recomposition. Declared early: doRestart
    // clears them.

    val lineLayouts = run { mutableMapOf<Any, TextLayoutResult>() }

    val layoutOrder = run { ArrayDeque<Any>() }

    /**
     * Copies one transcript range, built straight from the scrollback
     * buffer (never from composed UI nodes). Over-cap ranges are refused
     * with a message instead of crashing or silently truncating.
     */

    fun copyRange(range: TermSelection): Boolean {
        val text = try {
            emulator.selectionText(range.normalized(), MAX_COPY_CHARS)
        } catch (t: RuntimeException) {
            null
        } catch (t: OutOfMemoryError) {
            null
        }
        if (text == null) {
            toast(
                "Too large for clipboard (over $MAX_COPY_CHARS chars). " +
                "Select a smaller range."
            )
            return true
        }
        // A fresh/cleared screen still has blank live rows, so a full-range
        // (or whitespace-only) selection builds newlines, not "". Copying
        // that would fill the clipboard with invisible junk; treat it as
        // empty instead. Real whitespace the user explicitly wants can still
        // go through select-all on a screen that has real content, since
        // any non-blank char makes isBlank() false.
        if (text.isBlank()) {
            toast("Nothing to copy: selection is empty.")
            return true
        }
        return try {
            clipboard.setText(AnnotatedString(text))
            true
        } catch (t: RuntimeException) {
            toast("Copy failed (${t.javaClass.simpleName})")
            true
        } catch (t: OutOfMemoryError) {
            toast("Copy failed (out of memory)")
            true
        }
    }

    /**
     * Full-transcript copy shared by the Copy All button and the
     * Select-All-then-Copy menu path. Size first (cheap, no big temp),
     * then a single bounded build: never hands the clipboard a giant
     * Binder transaction, never silently truncates.
     */

    fun doCopyAll(): Boolean {
        return copyRange(emulator.fullRange())
    }


    var imeField by run {
        mutableStateOf(TextFieldValue(IME_SENTINEL, TextRange(IME_SENTINEL.length)))
    }

    // Focus provenance for IME commits: keystrokes can only originate from
    // the focused conduit. Commits arriving while unfocused (focus churn
    // from dialogs/drawers/panel moves, IME resyncs) are swallowed instead
    // of being typed into the shell as phantom input. Legit typing always
    // holds focus first, so this has no false positives. Plain state (not
    // a holder): the conduit is the only reader.

    var imeFocused by mutableStateOf(false)
    // CTRL/ALT latch state for the extra-keys bar. Each latch applies to the
    // next key exactly once, then auto-clears, so modifiers can never stick.

    var ctrlLatch by mutableStateOf(false)

    var altLatch by mutableStateOf(false)

    var alive by mutableStateOf(false)

    var starting by mutableStateOf(true)

    var exitMessage by mutableStateOf<String?>(null)

    var sessionTick by mutableStateOf(0)

    var confirmRestart by mutableStateOf(false)

    val sessionBox = run { arrayOfNulls<TerminalSession>(1) }


    val showJump by run { derivedStateOf { listState.canScrollForward } }

    // Explicit follow intent (the auto-follow fix). True while the user is
    // at the live bottom; set false ONLY by settled-away scroll position,
    // never by the mere presence of new items below the viewport (that was
    // the old bug: during a burst, fresh items below always read as "left",
    // so follow could never engage). Output flushes never write this.

    var follow by mutableStateOf(true)
    // Gesture ownership between the surface long-press drag recognizer and
    // the two selection-handle drag recognizers. Both observe the same
    // pointer stream, so without arbitration a press-and-hold on a handle
    // fires the surface long-press too: it re-anchors the selection at the
    // raw finger point and then both writers fight over termSel every
    // frame (handle jumps/jitter). null = free, 0 = surface drag owns it,
    // 1 = a handle drag owns it. Plain holders (not state): read/written
    // from gesture callbacks without ever triggering recomposition.
    // Declared before the follow collector below, which reads ownership.

    val selOwnerBox = run { arrayOfNulls<Int>(1) }
    // Per-gesture kill switch for the surface recognizer: set when its
    // long-press lands on a handle (or a handle already owns the pointer),
    // so its onDrag stays silent and the handle moves the endpoint alone.

    val surfaceDeadBox = run { arrayOf(false) }
    // Active selection-handle drag: which display slot owns a live gesture
    // (0 = start handle, 1 = end handle), or -1 for none. State, not a
    // holder: the handle overlay reads it during composition so a mid-drag
    // collapse (the dragged endpoint landing exactly on the other one makes
    // the range read empty) cannot unmount the TermHandle driving the very
    // gesture — that removal cancelled the drag with the finger still down
    // (handles vanished mid-move; lifting and re-grabbing re-anchored the
    // selection = the reported jump).

    val activeHandleBox = run { mutableStateOf(-1) }
    // Last good anchor per handle slot. endpointPos keeps it fresh on every
    // success and falls back to it while a handle drag is active, so a
    // transient null (empty range, line between compositions, alt-screen
    // flip) returns the last drawn position instead of yanking the node out
    // from under the gesture. Plain holder: read only during an active drag.

    val lastAnchorBox = run { arrayOfNulls<Offset>(2) }

    // Re-arm follow purely from settled position: when scrolling comes to
    // rest AT the bottom (manual scroll back, jump button, resize snap),
    // follow resumes. This collector NEVER clears follow: fresh items
    // arriving below the viewport also read as "can scroll forward", and
    // clearing on that is exactly what strangled follow during bursts
    // (every settled moment mid-burst looked like "user left"). Resting
    // is key — transient mid-drag/fling states never touch the latch.

    // Owns the bounded, lossless PTY-reader -> UI-thread output hand-off.
    val outputBuffer = TerminalOutputBuffer()

    var inputExpected by mutableStateOf(false)

    val flushScheduled = run { AtomicBoolean(false) }

    var hasOutput by mutableStateOf(false)
    // PTY geometry from the measured surface (no hardcoded dims): cell width
    // comes from the real monospace advance, rows from the real line height.
    //
    // The geometry is LATCHED for the life of the session, and the shell
    // follows the surface WIDTH only (Termux model: a fixed grid in a
    // resizable window). A height change is a pure VIEWPORT change — the
    // keyboard opening/closing, the panel being dragged — and the fixed grid
    // simply scrolls inside the shorter/taller box.
    //
    // Resizing the PTY on those animations used to fire TIOCSWINSZ/SIGWINCH
    // on every frame of the keyboard/drag, so the shell redrew its input line
    // dozens of times per gesture; each redraw landed on a row the emulator
    // had already preserved, which showed up as a copy of the previous line
    // after every keyboard toggle or panel drag.

    var surfacePx by mutableStateOf(0 to 0)

    var lastPtySize by mutableStateOf(0 to 0)
    // A surface smaller than this is not a real viewport (a not-yet-laid-out
    // box, a collapsed panel): the latched geometry stands instead.

    val minPtyCols = 20

    val minPtyRows = 6

    /** Monospace advance in px, measured with the rendered font/size. */

    fun measureCellWPx(): Float {
        return try {
            val fontPx = with(density) { TermStyle.fontSize.toPx() }
            if (fontPx <= 0f) return 0f
            val paint = Paint().apply {
                typeface = Typeface.MONOSPACE
                textSize = fontPx
                isAntiAlias = true
            }
            paint.measureText("MMMMMMMMMM") / 10f
        } catch (_: Exception) {
            0f
        }
    }


    fun lastIndex(): Int {
        // Last line that is actually rendered (scrollback + trimmed grid
        // tail, see TerminalEmulator.lastRenderedRow) — the empty grid
        // rows below the prompt are not items, so "bottom" here always
        // means the cursor/last-content line, never phantom whitespace.
        return (emulator.renderedLineCount() - 1).coerceAtLeast(0)
    }


    fun scrollToBottom(instant: Boolean) {
        // Explicit user/bottom intent (jump button, resize re-pin).
        follow = true
        val last = lastIndex()
        if (last < 0) return
        scope.launch(Dispatchers.Main) {
            try {
                if (instant) {
                    listState.scrollToItem(last)
                } else {
                    listState.animateScrollToItem(last)
                }
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Latches the PTY geometry from the measured surface. Runs AFTER layout
     * (see the LaunchedEffect on surfacePx below), never inside onSizeChanged:
     * mutating the emulator and the scroll position mid-layout is what left
     * stale/blank rows behind during the keyboard animation.
     *
     * Columns follow the surface width (only a real width change re-wraps
     * text). Rows are latched once per session and never follow the viewport
     * height, so the keyboard and the panel drag can resize the window as much
     * as they like without a single SIGWINCH.
     */

    fun applyPtySize() {
        if (sessionBox[0] == null) return
        val (w, h) = surfacePx
        if (w <= 0 || h <= 0) return
        // Real glyph measurement with the same monospace size the terminal
        // renders (framework Paint: works on every API level, no
        // compose-version dependency).
        val cellW = measureCellWPx()
        if (cellW <= 0f) return
        val lineH = try {
            with(density) { TermStyle.lineHeight.toPx() }
        } catch (_: Exception) {
            return
        }
        if (lineH <= 0f) return
        val cols = (w / cellW).toInt().coerceIn(2, 500)
        val rows = (h / lineH).toInt().coerceIn(2, 200)
        // Unmeasurable surface (nothing laid out yet, collapsed panel): the
        // latched geometry stands instead of shrinking the shell to nothing.
        if (cols < minPtyCols || rows < minPtyRows) return
        // Rows stay latched; a restart zeroes lastPtySize, which re-latches
        // them from the current viewport for the fresh shell.
        val fixedRows = if (lastPtySize.first >= minPtyRows) lastPtySize.first else rows
        // Width unchanged => nothing to do. This single line is why opening
        // or closing the keyboard, or dragging the panel, can no longer
        // resize the shell (and redraw its input line) behind the user's back.
        if (lastPtySize.second == cols) return
        lastPtySize = fixedRows to cols
        // Emulator grid first (Main thread), then TIOCSWINSZ so any repaint
        // the shell emits lands in a correctly sized grid. Resize alone
        // never restarts the session and appends no output.
        val wasFollowing = follow
        emulator.setSize(fixedRows, cols)
        // A narrower viewport can strand a follower above the new bottom
        // (canScrollForward flips true with zero touch input). Re-pin
        // explicitly instead of waiting for output that may never come.
        if (wasFollowing) {
            scrollToBottom(true)
        }
        terminalViewModel.resize(fixedRows, cols)
    }

    // Drag auto-scroll job holder (plain holder, not state: start/stop
    // must not recompose anything; only the selection highlight does).

    val dragJobBox = run { arrayOfNulls<Job>(1) }


    fun stopDragScroll() {
        try {
            dragJobBox[0]?.cancel()
        } catch (_: Exception) {
        }
        dragJobBox[0] = null
    }

    /**
     * Restart destroys the shell AND the visible terminal state, so it
     * always runs behind the confirmation dialog — never on a bare tap.
     */

    fun doRestart() {
        terminalViewModel.stopSession()
        sessionBox[0] = null
        stopDragScroll()
        selOwnerBox[0] = null
        activeHandleBox.value = -1
        surfaceDeadBox[0] = false
        termSel = null
        // Restart clears the selection, so any open selection menu must go
        // with it — otherwise it floats over a fresh shell. Never touches
        // input/focus/keyboard state.
        try {
            hideTermMenu()
        } catch (_: Exception) {
        }
        follow = true
        try {
            lineLayouts.clear()
            layoutOrder.clear()
        } catch (_: Exception) {
        }
        emulator.reset()
        imeField = TextFieldValue(
            IME_SENTINEL,
            TextRange(IME_SENTINEL.length)
        )
        // Force re-apply: the new PTY opens at the default
        // size and onSizeChanged will not refire by itself.
        lastPtySize = 0 to 0
        sessionTick++
    }

    /**
     * Viewport paging (Termux reference): PGUP/PGDN move OUR LazyColumn by
     * ~one visible page and are NEVER forwarded to the shell, so they can
     * never touch command history. Uses the same logical scrollback model
     * as touch scrolling (no second buffer). One instant jump per fire —
     * repeat-safe, no animation pile-up, no recomposition flood. New output
     * while scrolled up still respects the existing stick logic, and
     * reaching the bottom resumes live auto-scroll normally.
     */

    fun pageScroll(down: Boolean) {
        scope.launch(Dispatchers.Main) {
            try {
                val first = listState.firstVisibleItemIndex
                val page = listState.layoutInfo.visibleItemsInfo.size.coerceAtLeast(1)
                val last = lastIndex()
                if (last < 0) return@launch
                val target = if (down) {
                    (first + page).coerceAtMost(last)
                } else {
                    (first - page).coerceAtLeast(0)
                }
                // Viewport paging is explicit user navigation: landing at
                // the bottom resumes follow, anything above drops it. The
                // settle snapshot would converge anyway; this is instant.
                follow = target >= last
                listState.scrollToItem(target)
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Single coalesced UI pass: drain the queue (bounded per pass so one
     * huge backlog cannot block the Main thread), parse once, notify once,
     * scroll at most once. Safe to call from the Main thread only.
     */

    fun doFlush() {
        flushScheduled.set(false)
        val chunk = outputBuffer.drain(MAX_FLUSH_CHARS)
        if (chunk.isEmpty()) return
        emulator.processText(chunk)
        hasOutput = true
        outputBuffer.markFlushed()
    }

    /**
     * Coalesces reader-thread notifications into a bounded UI-thread flush.
     */

    fun requestFlush() {
        if (SystemClock.uptimeMillis() - outputBuffer.lastFlushMs >= FLUSH_WINDOW_MS) {
            if (flushScheduled.compareAndSet(false, true)) {
                scope.launch(Dispatchers.Main) { doFlush() }
            }
        } else if (outputBuffer.pendingChars < SMALL_FLUSH_CHARS) {
            // Continuous light interaction (typing, TAB, small echoes):
            // trail closely instead of idling until the 64ms loop tick.
            // A single scheduled trailing flush covers everything queued
            // meanwhile; bulk backlog stays on the loop path. The scheduled
            // flag is shared, so bursts never pile up extra flushes.
            if (flushScheduled.compareAndSet(false, true)) {
                scope.launch(Dispatchers.Main) {
                    delay(TRAILING_FLUSH_MS)
                    doFlush()
                }
            }
        }
    }

    /** Pastes clipboard text into the PTY (same path as typed paste). */
    /** Pastes clipboard text into the PTY (same path as typed paste). */

    fun pasteFromClipboard() {
        val clip = try {
            clipboard.getText()?.text
        } catch (_: Exception) {
            null
        }
        if (clip.isNullOrEmpty()) {
            toast("Clipboard is empty")
            return
        }
        if (sessionBox[0] == null) return
        val t = clip.replace("\n", "\r")
        terminalViewModel.send(
            if (emulator.bracketedPaste && t.length > 1) {
                "\u001B[200~" + t + "\u001B[201~"
            } else {
                t
            }
        )
    }


    fun sendToPty(s: String) {
        if (s.isEmpty() || sessionBox[0] == null) return
        terminalViewModel.send(s)
    }

    // IDE bridge: lets the IDE shell (Run button, Git shortcuts, pip)
    // send text to this exact PTY session without touching any terminal
    // state. Re-registered every composition; plain-var write, no
    // recomposition involved.

    fun sendKey(s: String) {
        if (s.isEmpty()) return
        var out = s
        val hadMod = ctrlLatch || altLatch
        if (ctrlLatch && s.length == 1 && s[0].isLetter()) {
            out = ((s[0].uppercaseChar().code - 64) and 0x1F).toChar().toString()
        }
        if (altLatch) {
            out = "\u001B$out"
        }
        if (hadMod) {
            ctrlLatch = false
            altLatch = false
        }
        sendToPty(out)
    }

    // Stable callback instances: they only read current latch/session state
    // at fire time, so the toolbar keeps identical inputs across terminal
    // recompositions and is never rebuilt by output flushes.

    val fireKey = run { { s: String -> sendKey(s) } }

    val pageFn = run { { down: Boolean -> pageScroll(down) } }

    val toggleCtrl = run { { ctrlLatch = !ctrlLatch } }

    val toggleAlt = run { { altLatch = !altLatch } }

    val fireStop = run {
        {
            ctrlLatch = false
            altLatch = false
            sendToPty("\u0003")
        }
    }

    /**
     * Hidden-field IME input. Every committed char goes straight to the PTY
     * (echo comes back through the emulator at the real cursor position).
     * Enter commits "\n" -> mapped to "\r". Multi-char commits are treated
     * as paste (bracketed-paste wrapped when the terminal enabled it).
     *
     * The buffer GROWS with what was actually sent and is never rewritten
     * per keystroke: rewriting the field behind the IME's back makes it
     * resend commits (duplicated lines), and selection-only commits must
     * not touch anything either. Only a runaway buffer is compacted, rarely.
     */

    fun onImeChange(new: TextFieldValue) {
        // Unfocused commit (dialog/drawer focus churn, never the user):
        // ignore it WITHOUT touching the field, so the diff resumes
        // cleanly on refocus and no resend loop can start.
        if (!imeFocused) {
            return
        }
        val old = imeField.text
        val str = new.text
        if (str == old) {
            return
        }
        var prefix = 0
        while (prefix < old.length && prefix < str.length &&
            old[prefix] == str[prefix]
        ) {
            prefix++
        }
        val removed = old.length - prefix
        var added = str.substring(prefix)
        if (removed > 0 || added.isNotEmpty()) {
            // Fresh keystrokes supersede any open selection menu; a stale
            // menu must not linger while typing. Keyboard visibility alone
            // must not govern this — and hiding the keyboard must never
            // clear the selection itself (nothing here touches termSel).
            try {
                hideTermMenu()
            } catch (_: Exception) {
            }
        }
        repeat(removed) { sendToPty("\u007f") }
        if (added.isNotEmpty()) {
            added = added.replace("\n", "\r")
            if ((ctrlLatch || altLatch) && added.length == 1) {
                // A latched bar modifier applies to the next typed char.
                sendKey(added)
            } else {
                if (ctrlLatch || altLatch) {
                    ctrlLatch = false
                    altLatch = false
                }
                sendToPty(
                    if (emulator.bracketedPaste && added.length > 1) {
                        "\u001B[200~" + added + "\u001B[201~"
                    } else {
                        added
                    }
                )
            }
        }
        imeField = if (new.text.length > 4096) {
            TextFieldValue(IME_SENTINEL, TextRange(IME_SENTINEL.length))
        } else {
            new
        }
    }


    fun arrow(dir: String) {
        // Application-cursor mode (vim/top) uses SS3, normal mode uses CSI.
        sendKey(if (emulator.appCursorKeys) "\u001BO$dir" else "\u001B[$dir")
    }

    // Declared after arrow(): stable instance for the toolbar (see above).

    val fireArrow = run { { d: String -> arrow(d) } }

    // Drag auto-scroll job holder (plain holder, not state: start/stop
    // must not recompose anything; only the selection highlight does).
    /**
     * Per-line text layouts for pixel-exact hit-testing/placement, keyed by
     * the STABLE item key (same keys as the LazyColumn items), so scrollback
     * trim can never alias them to wrong lines. Plain holders (not state):
     * written from onTextLayout during layout, read from gestures and
     * composition without ever triggering recomposition. Bounded FIFO
     * (a viewport holds ~dozens of lines); misses fall back to the average
     * advance, so behavior degrades gracefully, never crashes.
     */

    fun rememberLayout(key: Any, layout: TextLayoutResult) {
        try {
            if (!lineLayouts.containsKey(key)) {
                layoutOrder.addLast(key)
                while (layoutOrder.size > 96) {
                    lineLayouts.remove(layoutOrder.removeFirst())
                }
            }
            lineLayouts[key] = layout
        } catch (_: Exception) {
        }
    }

    /** Stable LazyColumn item key for a transcript line (mirrors rendering). */

    fun layoutKeyFor(line: Int): Any? {
        return try {
            if (emulator.isAltActive()) {
                if (line in 0 until emulator.rows) "row-$line" else null
            } else {
                val sb = emulator.scrollbackCount()
                if (line < 0) {
                    null
                } else if (line < sb) {
                    emulator.scrollbackId(line)
                } else if (line - sb < emulator.rows) {
                    "row-${line - sb}"
                } else {
                    null
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    /** Exact column via real text layout; -1 when no layout cached. */

    fun layoutColFor(line: Int, xPx: Float): Int {
        val key = layoutKeyFor(line) ?: return -1
        val layout = try {
            lineLayouts[key]
        } catch (_: Exception) {
            return -1
        } ?: return -1
        val textLen = emulator.lineTextAt(line).length
        if (textLen <= 0) return 0
        return try {
            layout.getOffsetForPosition(Offset(xPx, 0f)).coerceIn(0, textLen)
        } catch (_: Exception) {
            -1
        }
    }

    /** Exact x of a column via real text layout; -1f when unavailable. */

    fun layoutXFor(line: Int, col: Int): Float {
        val key = layoutKeyFor(line) ?: return -1f
        val layout = try {
            lineLayouts[key]
        } catch (_: Exception) {
            return -1f
        } ?: return -1f
        val textLen = emulator.lineTextAt(line).length
        if (textLen <= 0) return 0f
        return try {
            // Primary-direction horizontal (the old primary-horizontal API
            // was removed in recent Compose; this is its replacement).
            layout.getHorizontalPosition(col.coerceIn(0, textLen), true)
        } catch (_: Exception) {
            -1f
        }
    }

    /** Maps a surface-relative touch offset to a transcript (line, col). */

    fun offsetToPos(offsetPx: Offset, clampY: Boolean = false): Pair<Int, Int>? {
        val items = try {
            listState.layoutInfo.visibleItemsInfo
        } catch (_: Exception) {
            return null
        }
        val total = emulator.renderedLineCount()
        var item = items.firstOrNull {
            val top = it.offset.toFloat()
            offsetPx.y in top..(top + it.size.toFloat())
        }
        if (item == null && clampY) {
            // Dragging a handle: like Android's own handles, the finger may
            // wander above/below the text (or far off the line) and the
            // handle must keep following it horizontally on the NEAREST
            // line, instead of freezing because no line is under the finger.
            item = items
            .filter { it.index in 0 until total }
            .minByOrNull {
                val top = it.offset.toFloat()
                val bottom = top + it.size.toFloat()
                when {
                    offsetPx.y < top -> top - offsetPx.y
                    offsetPx.y > bottom -> offsetPx.y - bottom
                    else -> 0f
                }
            }
        }
        val hit = item ?: return null
        val line = hit.index
        if (line < 0 || line >= total) return null
        val textLen = emulator.lineTextAt(line).length
        // Real text layout first: snaps to the true character
        // boundary (stable under finger jitter); average advance
        // only as fallback.
        val exact = layoutColFor(line, offsetPx.x)
        if (exact >= 0) return line to exact
        val cellW = measureCellWPx()
        if (cellW <= 0f) return line to 0
        val col = (offsetPx.x / cellW).toInt().coerceIn(0, textLen)
        return line to col
    }

    /** Word under (line, col): alnum plus path-ish chars, else single char. */

    fun wordAt(line: Int, col: Int): TermSelection {
        val text = emulator.lineTextAt(line)
        if (text.isEmpty()) return TermSelection(line, 0, line, 0)
        fun isWord(c: Char): Boolean {
            return c.isLetterOrDigit() || c == '_' || c == '.' || c == '/' ||
            c == '-' || c == ':'
        }
        val at = col.coerceIn(0, text.length)
        if (at >= text.length || !isWord(text[at])) {
            return TermSelection(line, at, line, (at + 1).coerceAtMost(text.length))
        }
        var s = at
        var e = at
        while (s > 0 && isWord(text[s - 1])) s--
        while (e < text.length && isWord(text[e])) e++
        return TermSelection(line, s, line, e)
    }

    /** Long-press entry: anchor a word selection at the touch point. */

    fun beginSelectionAt(offsetPx: Offset) {
        val pos = offsetToPos(offsetPx) ?: return
        termSel = wordAt(pos.first, pos.second)
    }

    /**
     * Viewport auto-scroll while a selection drag is pinned outside the
     * viewport: exactly ONE loop (restarted per move event, cancelled on
     * release/re-entry). Each step also pins the dragged selection end to
     * the newly exposed edge line, so the range keeps growing correctly.
     */
    /**
     * Edge auto-scroll direction for a surface-relative finger y: -1 up,
     * +1 down, 0 none. Only returns non-zero when the list can REALLY scroll
     * that way. Before, a short terminal (one prompt line at the very top)
     * had every line inside the 12% edge zone, so any handle drag started
     * the auto-scroll loop, which cannot scroll and just pinned the dragged
     * end to column 0 / line end = the handle "jumping" to the line start.
     */

    fun edgeScrollDir(y: Float): Int {
        val hPx = surfacePx.second
        if (hPx <= 0) return 0
        val edge = with(density) { 28.dp.toPx() }.coerceAtMost(hPx * 0.12f)
        val d = when {
            y < edge -> -1
            y > hPx - edge -> 1
            else -> 0
        }
        return try {
            when {
                d < 0 && !listState.canScrollBackward -> 0
                d > 0 && !listState.canScrollForward -> 0
                else -> d
            }
        } catch (_: Exception) {
            0
        }
    }

    /**
     * Auto-scroll speed in px per 16ms frame: gentle at the edge of the
     * zone, faster the deeper the finger goes. The old fixed 96px/frame
     * (~6000px/s) blew past many lines per frame, which read as the
     * selection "jumping to another part".
     */

    fun edgeScrollStep(y: Float, dir: Int): Float {
        val hPx = surfacePx.second
        if (hPx <= 0) return 12f
        val edge = with(density) { 28.dp.toPx() }.coerceAtMost(hPx * 0.12f)
        val depth = if (dir < 0) (edge - y) / edge else (y - (hPx - edge)) / edge
        return 6f + 22f * depth.coerceIn(0f, 1f)
    }

    /** Clamps a candidate start so it never passes the (normalized) end. */

    fun clampStart(l: Int, c: Int, cur: TermSelection): Pair<Int, Int> {
        return if (l > cur.endLine || (l == cur.endLine && c > cur.endCol)) {
            cur.endLine to cur.endCol
        } else {
            l to c
        }
    }

    /** Clamps a candidate end so it never passes the (normalized) start. */

    fun clampEnd(l: Int, c: Int, cur: TermSelection): Pair<Int, Int> {
        return if (l < cur.startLine || (l == cur.startLine && c < cur.startCol)) {
            cur.startLine to cur.startCol
        } else {
            l to c
        }
    }


    fun driveDragScroll(
        dir: Int,
        moveStart: Boolean = false,
        handleDrag: Boolean = false,
        xPx: Float = -1f,
        step: Float = 12f
    ) {
        stopDragScroll()
        follow = false
        dragJobBox[0] = scope.launch(Dispatchers.Main) {
            while (true) {
                try {
                    val consumed = listState.scrollBy(if (dir < 0) -step else step)
                    // Hit the end: stop instead of pinning the selection
                    // to the edge line every frame.
                    if (consumed == 0f) break
                } catch (_: Exception) {
                    break
                }
                // Handle drags always work on the NORMALIZED range, so slot
                // 0 is truly the start and slot 1 truly the end.
                val cur = if (handleDrag) termSel?.normalized() else termSel
                if (cur != null) {
                    val edgeIdx = try {
                        val vis = listState.layoutInfo.visibleItemsInfo
                        if (vis.isEmpty()) -1
                        else if (dir < 0) vis.first().index
                        else vis.last().index
                    } catch (_: Exception) {
                        -1
                    }
                    val total = emulator.renderedLineCount()
                    if (edgeIdx in 0 until total) {
                        // Column under the finger's x on the edge line (the
                        // old code jammed column 0 / line end here).
                        val exact = if (xPx >= 0f) layoutColFor(edgeIdx, xPx) else -1
                        val col = if (exact >= 0) {
                            exact
                        } else if (dir < 0) {
                            0
                        } else {
                            emulator.lineTextAt(edgeIdx).length
                        }
                        termSel = if (moveStart) {
                            val p = if (handleDrag) {
                                clampStart(edgeIdx, col, cur)
                            } else {
                                edgeIdx to col
                            }
                            TermSelection(
                                p.first, p.second, cur.endLine, cur.endCol
                            )
                        } else {
                            val p = if (handleDrag) {
                                clampEnd(edgeIdx, col, cur)
                            } else {
                                edgeIdx to col
                            }
                            TermSelection(
                                cur.startLine, cur.startCol, p.first, p.second
                            )
                        }
                    }
                }
                delay(16)
            }
        }
    }

    /** Drag extension: the anchor stays, the focus end follows the finger. */

    fun dragExtend(offsetPx: Offset) {
        val cur = termSel ?: return
        // A selection drag is explicit user navigation: never let a live
        // follow yank the viewport mid-gesture. Idempotent per move event.
        follow = false
        val dir = edgeScrollDir(offsetPx.y)
        if (dir != 0) {
            driveDragScroll(
                dir,
                xPx = offsetPx.x,
                step = edgeScrollStep(offsetPx.y, dir)
            )
            return
        }
        stopDragScroll()
        val pos = offsetToPos(offsetPx, clampY = true) ?: return
        termSel = TermSelection(cur.startLine, cur.startCol, pos.first, pos.second)
    }

    /**
     * Moves ONE selection endpoint (0 = start handle, 1 = end handle) to a
     * surface-relative touch point. Used exclusively by handle drags; the
     * long-press drag path (dragExtend) always moves the end. Clears follow
     * like any other user navigation. Edge zones reuse the single
     * auto-scroll loop, pinning the same endpoint being dragged.
     */

    fun moveEndpoint(whichEnd: Int, offsetPx: Offset) {
        // Normalized: handle slots are display-ordered (0 = earlier point),
        // but termSel may be reversed after a backward long-press drag.
        // Using the raw fields moved the WRONG end = "jumps elsewhere".
        val cur = termSel?.normalized() ?: return
        follow = false
        val dir = edgeScrollDir(offsetPx.y)
        if (dir != 0) {
            driveDragScroll(
                dir,
                whichEnd == 0,
                handleDrag = true,
                xPx = offsetPx.x,
                step = edgeScrollStep(offsetPx.y, dir)
            )
            return
        }
        stopDragScroll()
        val pos = offsetToPos(offsetPx, clampY = true) ?: return
        termSel = if (whichEnd == 0) {
            val p = clampStart(pos.first, pos.second, cur)
            TermSelection(p.first, p.second, cur.endLine, cur.endCol)
        } else {
            val p = clampEnd(pos.first, pos.second, cur)
            TermSelection(cur.startLine, cur.startCol, p.first, p.second)
        }
    }

    /**
     * Surface-relative pixel position of one selection endpoint, or null
     * when that line is not currently composed (offscreen). Read during
     * composition for handle placement: handles track scrolling for free
     * and only ever exist for visible lines. Raw failure behavior; the
     * endpointPos wrapper below layers drag continuity on top.
     */

    fun endpointPosRaw(whichEnd: Int): Offset? {
        val sel = termSel?.normalized() ?: return null
        // A collapsed range keeps its anchors while a handle is dragged.
        if (sel.isEmpty() && activeHandleBox.value < 0) return null
        val line = if (whichEnd == 0) sel.startLine else sel.endLine
        val col = if (whichEnd == 0) sel.startCol else sel.endCol
        val items = try {
            listState.layoutInfo.visibleItemsInfo
        } catch (_: Exception) {
            return null
        }
        val item = items.firstOrNull { it.index == line } ?: return null
        val total = emulator.renderedLineCount()
        if (line < 0 || line >= total) return null
        val textLen = emulator.lineTextAt(line).length
        val c = col.coerceIn(0, textLen)
        // Real glyph position first; average advance only as fallback.
        val exactX = layoutXFor(line, c)
        val x = if (exactX >= 0f) {
            exactX
        } else {
            val cellW = measureCellWPx()
            if (cellW <= 0f) return null
            c * cellW
        }
        val yTop = item.offset.toFloat()
        val yBottom = yTop + item.size.toFloat()
        return Offset(x, yBottom)
    }

    /**
     * endpointPos with drag continuity. Every successful position is
     * remembered; while any handle drag is active a failure (the range
     * momentarily reads empty when the dragged endpoint lands exactly on
     * the other one, or the line is between compositions) falls back to
     * the last good anchor instead of null — a null here unmounts the
     * TermHandle node, which cancels the very gesture that produced it
     * (handles vanished mid-drag; lifting and re-grabbing re-anchored the
     * selection = the reported jump).
     */

    fun endpointPos(whichEnd: Int): Offset? {
        val pos = endpointPosRaw(whichEnd)
        if (pos != null) {
            lastAnchorBox[whichEnd] = pos
            return pos
        }
        if (activeHandleBox.value >= 0) return lastAnchorBox[whichEnd]
        return null
    }

    /**
     * Where a grabbed handle's selection point really is: the middle of the
     * endpoint's line (the drawn anchor sits on the line's bottom edge,
     * which is shared with the next line, so using it directly made every
     * tiny finger move flip the selection to the line below).
     */

    fun endpointTouchPos(whichEnd: Int): Offset? {
        val a = endpointPos(whichEnd) ?: return null
        val h = try {
            listState.layoutInfo.visibleItemsInfo.firstOrNull()?.size ?: 0
        } catch (_: Exception) {
            0
        }
        return Offset(a.x, a.y - (if (h > 0) h / 2f else 20f))
    }

    /**
     * Shows Copy / Select all / Paste for the terminal selection model.
     * The menu is anchored to the whole SELECTION (top of the first selected
     * line down to below the handles), never to the finger. The system
     * places a floating toolbar above the rect (or below it when there is no
     * room), so it can no longer sit on the selected text or on a handle.
     */

    fun showTermMenu(anchorPx: Offset) {
        val rect = try {
            val coords = termCoordsBox[0]
            val handlePx = with(density) { (HandleH - HandleTipY).toPx() }
            val lineH = listState.layoutInfo.visibleItemsInfo
            .firstOrNull()?.size?.toFloat() ?: 40f
            val surfW = surfacePx.first.toFloat()
            val surfH = surfacePx.second.toFloat()
            val sp = endpointPosRaw(0)
            val ep = endpointPosRaw(1)
            val top = if (sp != null) sp.y - lineH else 0f
            val bottom = if (ep != null) ep.y + handlePx else surfH
            var left = 0f
            var right = surfW
            if (sp != null && ep != null) {
                left = minOf(sp.x, ep.x)
                right = maxOf(sp.x, ep.x)
            }
            if (right < left + 8f) right = left + 8f
            val c = coords
            if (c != null) {
                val tl = c.localToWindow(Offset(left, top))
                val br = c.localToWindow(Offset(right, bottom))
                Rect(tl.x, tl.y, br.x, br.y)
            } else {
                Rect(anchorPx.x - 4f, anchorPx.y - 4f, anchorPx.x + 4f, anchorPx.y + 4f)
            }
        } catch (_: Exception) {
            Rect.Zero
        }
        menuWanted[0] = true
        try {
            textToolbar.showMenu(
                rect = rect,
                onCopyRequested = {
                    menuWanted[0] = false
                    val sel = termSel
                    if (sel == null || sel.normalized().isEmpty()) {
                        toast("Nothing selected — long-press to select")
                    } else {
                        copyRange(sel)
                    }
                },
                onPasteRequested = {
                    menuWanted[0] = false
                    pasteFromClipboard()
                },
                onCutRequested = null,
                onSelectAllRequested = {
                    termSel = emulator.fullRange()
                    // Re-show immediately so Copy stays one tap away: summoning
                    // the menu again would need another long-press, which
                    // starts a NEW word selection and would destroy the full
                    // range just made. Posted, never looping (needs taps).
                    scope.launch(Dispatchers.Main) {
                        showTermMenu(anchorPx)
                    }
                }
            )
        } catch (_: Exception) {
        }
    }


    fun isOnHandle(p: Offset): Boolean {
        val halfW: Float
        val above: Float
        val below: Float
        with(density) {
            halfW = (HandleW / 2).toPx()
            above = HandleTipY.toPx()
            below = (HandleH - HandleTipY).toPx()
        }
        for (which in 0..1) {
            val a = endpointPos(which) ?: continue
            if (p.x in (a.x - halfW)..(a.x + halfW) &&
                p.y in (a.y - above)..(a.y + below)
            ) {
                return true
            }
        }
        return false
    }


    fun onTerminalKey(event: KeyEvent): Boolean {
        if (event.type != KeyEventType.KeyDown) return false
        if (event.isCtrlPressed) {
            // A real hardware modifier wins: drop bar latches so the two
            // modifier sources can never tangle into a stuck state.
            if (ctrlLatch || altLatch) {
                ctrlLatch = false
                altLatch = false
            }
            // Real control bytes: readline/job control own line editing now,
            // so Ctrl+A/E/K/U/W/R all behave like a physical terminal.
            val kc = event.key.keyCode
            if (kc in 29L..54L) {
                sendToPty(String(Character.toChars((kc - 28).toInt())))
                return true
            }
            // Android KEYCODE_SPACE = 62 (Key.Space is missing in this
            // compose version, so compare the raw code like the others).
            if (kc == 62L) {
                sendToPty("\u0000")
                return true
            }
            return false
        }
        return when (event.key) {
            Key.Enter, Key.NumPadEnter -> {
                sendToPty("\r")
                true
            }
            Key.DirectionUp -> {
                arrow("A")
                true
            }
            Key.DirectionDown -> {
                arrow("B")
                true
            }
            Key.DirectionRight -> {
                arrow("C")
                true
            }
            Key.DirectionLeft -> {
                arrow("D")
                true
            }
            Key.Tab -> {
                sendToPty("\t")
                true
            }
            Key.Escape -> {
                sendToPty("\u001B")
                true
            }
            else -> when (event.key.keyCode) {
                122L -> {
                    sendToPty("\u001B[H")
                    true
                }
                123L -> {
                    sendToPty("\u001B[F")
                    true
                }
                112L -> {
                    sendToPty("\u001B[3~")
                    true
                }
                124L -> {
                    sendToPty("\u001B[2~")
                    true
                }
                92L -> {
                    pageScroll(false)
                    true
                }
                93L -> {
                    pageScroll(true)
                    true
                }
                // Backspace (67) is NOT consumed: the sentinel diff turns it
                // into a real DEL, exactly once.
                else -> false
            }
        }
    }

    /**
     * Read-only tail of the rendered transcript for IDE conveniences (such as
     * finding a printed local-server URL). Bounded and allocation-capped, so a
     * huge scrollback cannot stall the Main thread. Main thread only.
     */

    fun consoleTranscriptTail(maxLines: Int = 240, maxChars: Int = 60_000): String {
        return try {
            val total = emulator.renderedLineCount()
            if (total <= 0) return ""
            val start = (total - maxLines).coerceAtLeast(0)
            buildString {
                for (i in start until total) {
                    append(emulator.lineTextAt(i))
                    append('\n')
                    if (length >= maxChars) break
                }
            }
        } catch (_: Exception) {
            ""
        }
    }


    fun appendChunk(raw: String) {
        // Enqueue only on the reader thread; the buffer applies bounded,
        // lossless back-pressure and the UI scheduler coalesces flushes.
        if (outputBuffer.enqueue(raw)) requestFlush()
    }

    // Console only: does the running program wait for typed input? A tap used
    // to open the keyboard on ANY touch of the console, which is wrong for
    // plain output (scrolling/selecting would pop it up). A program is taken
    // to be waiting when it is alive, has stopped printing for a moment and
    // left the cursor mid-line (what input("name: ") does). Once per prompt,
    // when the prompt ends like a typical question, the keyboard also opens by
    // itself. Programs that require explicit input can still receive keyboard focus when their prompt is detected.
}
