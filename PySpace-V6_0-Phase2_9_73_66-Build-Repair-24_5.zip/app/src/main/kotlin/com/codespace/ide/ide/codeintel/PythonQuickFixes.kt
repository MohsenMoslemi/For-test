package com.codespace.ide.ide.codeintel
import com.codespace.ide.ide.PythonImportManager


/** Safe, deterministic source edits for diagnostics. Edits target the unsaved buffer. */
object PythonQuickFixes {
    data class Result(val text: String, val selection: Int)

    fun key(diagnostic: PythonSyntaxDiagnostic): String? {
        val code = diagnostic.code?.trim()?.uppercase().orEmpty()
        val message = diagnostic.message.lowercase()
        return when {
            code == "F541" || message.contains("f-string is missing placeholders") -> "F541"
            code == "W291" || message.contains("trailing whitespace") -> "W291"
            code == "W292" || message.contains("no newline at end of file") -> "W292"
            code == "W293" || message.contains("blank line contains whitespace") -> "W293"
            code == "W191" || message.contains("indentation contains tabs") -> "W191"
            code == "F401" || message.contains("imported but unused") -> "F401"
            code == "E101" || message.contains("indentation contains mixed spaces and tabs") -> "E101"
            code == "E303" || message.contains("too many blank lines") -> "E303"
            code == "E302" || code == "E305" -> code
            else -> null
        }
    }

    /** Returns the importable symbol name for a Pyflakes undefined-name diagnostic. */
    fun undefinedName(diagnostic: PythonSyntaxDiagnostic): String? {
        val message = diagnostic.message
        return Regex("undefined name ['\\\"]([A-Za-z_][A-Za-z0-9_]*)['\\\"]", RegexOption.IGNORE_CASE)
            .find(message)?.groupValues?.getOrNull(1)
    }

    fun importSuggestions(source: String, diagnostic: PythonSyntaxDiagnostic, installed: Set<String>?): List<PythonCompletionItem> {
        val name = undefinedName(diagnostic) ?: return emptyList()
        val lineStart = source.split('\n').take((diagnostic.line - 1).coerceAtLeast(0)).sumOf { it.length + 1 }
        val line = source.indexOf('\n', lineStart).let { if (it < 0) source.length else it }
        val col = (lineStart + diagnostic.column - 1).coerceIn(lineStart, line)
        var start = col
        while (start > lineStart && (source[start - 1].isLetterOrDigit() || source[start - 1] == '_')) start--
        var end = col
        while (end < line && (source[end].isLetterOrDigit() || source[end] == '_')) end++
        if (source.substring(start, end) != name) {
            start = source.indexOf(name, lineStart).takeIf { it in lineStart until line } ?: return emptyList()
            end = start + name.length
        }
        return PythonCompletion.autoImportSuggestionsForIdentifier(source, start, end, installed)
            .filter { !it.autoImportStatement.isNullOrBlank() }
            .distinctBy { it.autoImportStatement }
            .take(20)
    }

    fun applyImport(source: String, statement: String): Result? {
        if (statement.isBlank()) return null
        val (text, delta) = PythonImportManager.insert(source, statement)
        if (text == source) return null
        return Result(text, (source.length + delta).coerceIn(0, text.length))
    }

    fun apply(source: String, diagnostic: PythonSyntaxDiagnostic): Result? {
        val key = key(diagnostic) ?: return null
        val lines = source.split('\n').toMutableList()
        val lineIndex = diagnostic.line - 1
        fun absolute(line: Int, col: Int): Int = lines.take(line).sumOf { it.length + 1 } + col
        return when (key) {
            "F401" -> {
                val imported = Regex("['\"]([^'\"]+)['\"] imported but unused", RegexOption.IGNORE_CASE)
                    .find(diagnostic.message)?.groupValues?.getOrNull(1) ?: return null
                val result = PythonImportManager.fix(
                    source, 0,
                    listOf(PythonUnusedImport(diagnostic.line, (diagnostic.column - 1).coerceAtLeast(0), imported))
                )
                if (!result.changed) null else Result(result.text, result.caret)
            }
            "F541" -> {
                if (lineIndex !in lines.indices) return null
                val line = lines[lineIndex]
                val regex = Regex("""(?i)(?<![A-Za-z0-9_])([rub]*)(f)([rub]*)(?=['\"])""")
                val candidates = regex.findAll(line).toList()
                if (candidates.isEmpty()) return null
                val start = (diagnostic.column - 1).coerceAtLeast(0)
                val match = if (candidates.size == 1) candidates.first() else candidates.minByOrNull {
                    kotlin.math.abs((it.range.first + it.groupValues[1].length) - start)
                } ?: return null
                val f = match.range.first + match.groupValues[1].length
                lines[lineIndex] = line.removeRange(f, f + 1)
                val out = lines.joinToString("\n")
                Result(out, absolute(lineIndex, f).coerceAtMost(out.length))
            }
            "W291", "W293" -> {
                if (lineIndex !in lines.indices) return null
                val old = lines[lineIndex]
                val fixed = old.trimEnd(' ', '\t', '\r')
                if (fixed == old) return null
                lines[lineIndex] = fixed
                val out = lines.joinToString("\n")
                Result(out, absolute(lineIndex, fixed.length).coerceAtMost(out.length))
            }
            "W292" -> if (source.isNotEmpty() && !source.endsWith('\n')) Result("$source\n", source.length + 1) else null
            "W191", "E101" -> {
                if (lineIndex !in lines.indices) return null
                val old = lines[lineIndex]
                val lead = old.takeWhile { it == ' ' || it == '\t' }
                val fixed = lead.replace("\t", "    ") + old.drop(lead.length)
                if (fixed == old) return null
                lines[lineIndex] = fixed
                val out = lines.joinToString("\n")
                Result(out, absolute(lineIndex, fixed.length).coerceAtMost(out.length))
            }
            "E303" -> {
                if (lineIndex !in lines.indices || lines[lineIndex].isBlank()) return null
                // E303 is reported on the statement following an excessive
                // blank-line run. Keep the statement and all surrounding code;
                // remove only blank lines beyond the PEP 8 maximum of two.
                var firstBlank = lineIndex
                while (firstBlank > 0 && lines[firstBlank - 1].isBlank()) firstBlank--
                val blankCount = lineIndex - firstBlank
                val excess = (blankCount - 2).coerceAtLeast(0)
                if (excess == 0) return null
                repeat(excess) { lines.removeAt(firstBlank) }
                val out = lines.joinToString("\n")
                val caret = lines.take(firstBlank).sumOf { it.length + 1 }
                Result(out, caret.coerceIn(0, out.length))
            }
            "E302", "E305" -> {
                if (lineIndex !in lines.indices) return null
                var first = lineIndex
                while (first > 0 && lines[first - 1].isBlank()) first--
                val wanted = if (key == "E302") 2 else 2
                val have = lineIndex - first
                if (have >= wanted) return null
                repeat(wanted - have) { lines.add(first, "") }
                val out = lines.joinToString("\n")
                Result(out, absolute(lineIndex + wanted - have, 0).coerceAtMost(out.length))
            }
            else -> null
        }
    }

}
