package com.codespace.ide.ide

import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.isShiftPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalTextToolbar
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.codespace.ide.ide.editor.OpenTab
import com.codespace.ide.ide.editor.EditorHoverDocumentationWorkflow
import com.codespace.ide.ide.editor.EditorColors
import com.codespace.ide.ide.editor.EditorSelectionToolbarState
import com.codespace.ide.ide.editor.EditorSelectionToolbarOverlay
import com.codespace.ide.ide.editor.FoldedEditorDocument
import com.codespace.ide.ide.editor.EditorInteractionPolicy
import com.codespace.ide.ide.editor.EditorInputEditProcessor
import com.codespace.ide.ide.editor.lineColAt
import com.codespace.ide.ide.codeintel.PythonCompletionItem
import com.codespace.ide.ide.theme.IdeTheme
import com.codespace.ide.ide.editor.LineGutter

@Composable
internal fun EditorCodeInputLayer(
    field: TextFieldValue,
    onFieldChange: (TextFieldValue) -> Unit,
    tab: OpenTab,
    tabWidth: Int,
    autoIndent: Boolean,
    isPythonLanguage: Boolean,
    onFlashLineClear: () -> Unit,
    hoverTapInProgress: Boolean,
    hoverDoc: String?,
    hoverWorkflow: EditorHoverDocumentationWorkflow,
    completionItems: List<PythonCompletionItem>,
    onCompletionItemsChange: (List<PythonCompletionItem>) -> Unit,
    completionRange: Pair<Int, Int>,
    onCompletionRangeChange: (Pair<Int, Int>) -> Unit,
    onCompletionEdit: () -> Unit,
    onCompletionTriggerCaret: (Int) -> Unit,
    onSyntaxEditingLineChange: (Int) -> Unit,
    reportCursor: (Int, Int) -> Unit,
    style: TextStyle,
    colors: EditorColors,
    focusRequester: FocusRequester,
    showCompletionPopup: Boolean,
    applyCompletion: (PythonCompletionItem) -> Unit,
    onTextLayout: (TextLayoutResult) -> Unit,
    onFieldFocusChange: (Boolean) -> Unit,
    onFocusChange: (Boolean) -> Unit,
    onFieldCoordinates: (LayoutCoordinates) -> Unit,
    editorContentMinHeight: Dp,
    onFieldWidthChange: (Int) -> Unit,
    selectionToolbar: EditorSelectionToolbarState,
    active: Boolean,
    pinchGestureActive: Boolean,
    zoomCommitInProgress: Boolean,
    textLayout: TextLayoutResult?,
    foldedDocument: FoldedEditorDocument,
    viewportW: Int,
    viewportPx: Int,
    gutterPx: Float,
    textPadPx: Float,
    bottomInsetPx: Float,
    hScroll: ScrollState,
    vScroll: ScrollState,
    gutterVisible: Boolean,
    gutterDp: Dp,
    pinchPivot: Offset,
    layerScaleX: Float,
    layerScaleY: Float,
    pinchGutterPx: Float,
    density: androidx.compose.ui.unit.Density
) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .graphicsLayer {
                        // Live pinch preview of the CODE only (draw phase, no relayout).
                        // The gutter is not part of this layer: it draws itself at the
                        // width the final layout will have (see LineGutter).
                        // layerScaleX/Y are captured from composition (see above), so they
                        // switch in the same frame as the committed font size.
                        val sx = layerScaleX
                        val sy = layerScaleY
                        if ((sx != 1f || sy != 1f) && sx > 0f && sy > 0f && size.width > 0f && size.height > 0f) {
                            val h = pinchPivot.x
                            scaleX = sx
                            scaleY = sy
                            transformOrigin = TransformOrigin(h / size.width, pinchPivot.y / size.height)
                            // Left edge over the gutter / text padding: the text ORIGIN
                            // (gutter + 8dp padding) must land on the new origin. The
                            // padding is a constant, not scaled with the font, so it is
                            // part of the origin rather than of the scaled column offset.
                            if (gutterVisible && h <= gutterPx + textPadPx) {
                                translationX = (pinchGutterPx + textPadPx) - h -
                                    (gutterPx + textPadPx - h) * sx
                            }
                        }
                    }
            ) {
            // This spacer belongs to the scaled code Row, so it must retain
            // the committed width: graphicsLayer scales it with the code and
            // the row translation moves its visual edge to effectiveGutterDp.
            if (gutterVisible) Spacer(Modifier.width(gutterDp))
            // The caret/selection handle is a separate platform window, so it
            // would stay on top of the gutter, the file tree and even the
            // settings overlay. It is only visible while the caret/selection
            // is inside the visible code lane of an active editor.
            val themedSelectionColors = remember(IdeTheme.ACCENT, IdeTheme.SELECTION) {
                TextSelectionColors(
                    handleColor = Color(IdeTheme.ACCENT),
                    backgroundColor = Color(IdeTheme.SELECTION).copy(alpha = 0.72f)
                )
            }
            val handleReachPx = with(density) { 26.dp.toPx() }
            val handleVisible by remember(
                gutterPx, bottomInsetPx, active, handleReachPx,
                pinchGestureActive, zoomCommitInProgress
            ) {
                derivedStateOf {
                    // Read snapshot-backed values inside derivedStateOf so edits, layout
                    // updates and scroll changes invalidate the decision without capturing
                    // a stale FoldedEditorDocument or TextFieldValue.
                    EditorInteractionPolicy.shouldShowSelectionHandles(
                        active = active,
                        pinchGestureActive = pinchGestureActive,
                        zoomCommitInProgress = zoomCommitInProgress,
                        layout = textLayout,
                        field = field,
                        foldedDocument = foldedDocument,
                        viewportWidthPx = viewportW,
                        viewportHeightPx = viewportPx,
                        gutterWidthPx = gutterPx,
                        textPaddingPx = textPadPx,
                        handleReachPx = handleReachPx,
                        bottomInsetPx = bottomInsetPx,
                        horizontalScrollPx = hScroll.value,
                        verticalScrollPx = vScroll.value
                    )
                }
            }
            CompositionLocalProvider(
                LocalTextSelectionColors provides if (handleVisible) themedSelectionColors
                else TextSelectionColors(Color.Transparent, themedSelectionColors.backgroundColor),
                LocalTextToolbar provides selectionToolbar
            ) {
            BasicTextField(
                value = field,
                onValueChange = { v ->
                    // Any user edit or cursor move clears the jump flash.
                    onFlashLineClear()
                    if (v.selection != field.selection && !hoverTapInProgress && hoverDoc == null) {
                        hoverWorkflow.dismissAnchor()
                    }
                    val rawNew = v.text
                    if (rawNew != field.text) {
                        // The old result describes the previous source snapshot.
                        // Hide it immediately while the debounced request for the
                        // edited text is being calculated, so stale rows cannot
                        // remain visible during the debounce/LSP round trip.
                        onCompletionItemsChange(emptyList())
                        onCompletionRangeChange(v.selection.start.coerceIn(0, rawNew.length) to
                            v.selection.start.coerceIn(0, rawNew.length))
                        onCompletionEdit()
                        hoverWorkflow.clearPresentation()
                    } else if (v.selection != field.selection) {
                        // A selection-only callback means the user moved the
                        // caret (or changed the selection). Dismiss synchronously
                        // before the caret-keyed effect runs; that effect may
                        // subsequently show only a freshly validated Auto Import
                        // for the identifier now under the caret. In particular,
                        // an empty line must not retain the previous popup.
                        onCompletionItemsChange(emptyList())
                        val safeCaret = v.selection.start.coerceIn(0, rawNew.length)
                        onCompletionRangeChange(safeCaret to safeCaret)
                    }
                    // Selection-only callbacks must not dismiss completion.
                    // Android IMEs can emit them while opening/resizing the keyboard;
                    // the existing completion result remains valid until the next edit.
                    val processed = EditorInputEditProcessor.process(
                        documentText = tab.text,
                        incoming = v,
                        tabWidth = tabWidth,
                        autoIndent = autoIndent && isPythonLanguage
                    )
                    if (!processed.changesDocument) {
                        onFieldChange(processed.value)
                        val lc = lineColAt(rawNew, processed.value.selection.start)
                        reportCursor(lc[0], lc[1])
                        return@BasicTextField
                    }
                    val fixed = processed.value.text
                    val cur = processed.value.selection.start
                    onCompletionTriggerCaret(cur)
                    tab.applyEdit(fixed, field.selection.start, field.selection.end)
                    onFieldChange(processed.value)
                    val lc = lineColAt(fixed, cur)
                    onSyntaxEditingLineChange(lc[0])
                    reportCursor(lc[0], lc[1])
                },
                textStyle = style,
                visualTransformation = colors,
                cursorBrush = SolidColor(Color(IdeTheme.ACCENT)),
                // Text, not Ascii: Ascii makes the keyboard Latin-only (no
                // language switch, so Persian/Arabic/… strings and comments
                // could not be typed). autoCorrect=false still asks the IME
                // for no suggestions/composition, which this editor relies on.
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.None,
                    autoCorrect = false,
                    keyboardType = KeyboardType.Text
                ),
                onTextLayout = { onTextLayout(it) },
                modifier = Modifier
                // Full-measured on purpose (no weight/fillMaxHeight, no
                // own verticalScroll): the outer container is the only
                // scroller, so the field can never scroll internally out
                // from under the gutter. fillMaxWidth keeps taps anywhere
                // on a short line inside the field.
                .fillMaxWidth()
                .focusRequester(focusRequester)
                .onPreviewKeyEvent { event ->
                    if (event.type != KeyEventType.KeyDown) {
                        false
                    } else if (event.key == Key.Tab && showCompletionPopup && completionItems.isNotEmpty()) {
                        applyCompletion(completionItems.first())
                        true
                    } else if (!event.isCtrlPressed) {
                        false
                    } else {
                        val snapshot = when (event.key) {
                            Key.Z -> if (event.isShiftPressed) {
                                tab.redo(field.selection.start, field.selection.end)
                            } else {
                                tab.undo(field.selection.start, field.selection.end)
                            }
                            Key.Y -> tab.redo(field.selection.start, field.selection.end)
                            else -> null
                        }
                        if (event.key != Key.Z && event.key != Key.Y) {
                            false
                        } else {
                            if (snapshot != null) {
                                val start = snapshot.selectionStart.coerceIn(0, snapshot.text.length)
                                val end = snapshot.selectionEnd.coerceIn(0, snapshot.text.length)
                                onFieldChange(TextFieldValue(snapshot.text, TextRange(start, end)))
                                val lc = lineColAt(snapshot.text, start)
                                onFlashLineClear()
                                reportCursor(lc[0], lc[1])
                            }
                            true
                        }
                    }
                }
                .onFocusChanged {
                    onFieldFocusChange(it.isFocused)
                    onFocusChange(it.isFocused)
                }
                .onGloballyPositioned { onFieldCoordinates(it) }
                .padding(8.dp)
                // A fixed minimum based on the measured viewport makes the
                // field itself fill the available editor height without using
                // fillMaxHeight inside the unbounded vertical scroll content.
                // bottomInset is excluded here because its Spacer is appended
                // after the code row to preserve the existing scroll clearance.
                .heightIn(min = editorContentMinHeight)
                // AFTER padding => this is the exact width the text
                // wraps at (the wrap width), fed to the row measuring.
                .onSizeChanged { onFieldWidthChange(it.width) }
            )
            }
            }
            EditorSelectionToolbarOverlay(selectionToolbar)

}
