package com.codespace.ide.ide

import android.os.FileObserver
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberUpdatedState
import java.io.File
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.codespace.ide.ide.editor.EditorSession
import com.codespace.ide.ide.projects.ProjectAutoRecoveryManager
import com.codespace.ide.ide.projects.ProjectRecoveryWatcher
import com.codespace.ide.ide.projects.PyProject

/**
 * Owns the Compose-lifecycle integration for project recovery.
 *
 * The recovery store itself remains a data/runtime service. This adapter owns
 * only when snapshots are captured, which filesystem observers are active, and
 * how a vanished active project is reported to the IDE host.
 */
@Composable
internal fun ProjectRecoveryEffects(
    project: PyProject?,
    editorSession: EditorSession?,
    missingProjectPath: String?,
    workspace: File,
    recoveryManager: ProjectAutoRecoveryManager,
    scope: CoroutineScope,
    onAvailabilityChanged: (Boolean) -> Unit,
    onErrorChanged: (String?) -> Unit,
    onProjectMissing: (PyProject) -> Unit,
) {
    val currentMissingPath = rememberUpdatedState(missingProjectPath)
    val currentAvailabilityCallback = rememberUpdatedState(onAvailabilityChanged)
    val currentErrorCallback = rememberUpdatedState(onErrorChanged)
    val currentMissingCallback = rememberUpdatedState(onProjectMissing)

    val dirtyDocuments = editorSession?.tabs
        ?.filter { it.dirty && it.editable }
        ?.associate { it.file.absolutePath to it.text }
        .orEmpty()

    // Capture unsaved editor buffers shortly after typing settles. Dirty text
    // may not exist on disk, so this snapshot is independent of file events.
    LaunchedEffect(project?.dir?.absolutePath, dirtyDocuments) {
        val active = project ?: return@LaunchedEffect
        if (dirtyDocuments.isEmpty()) return@LaunchedEffect
        delay(1_200L)
        if (active.dir.isDirectory && currentMissingPath.value != active.dir.absolutePath) {
            try {
                withContext(Dispatchers.IO) {
                    recoveryManager.snapshot(active, dirtyDocuments, forceHash = true)
                }
                currentAvailabilityCallback.value(
                    withContext(Dispatchers.IO) { recoveryManager.hasSnapshot(active) }
                )
                currentErrorCallback.value(null)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                currentErrorCallback.value(error.message ?: "Automatic recovery could not be updated.")
            }
        }
    }

    // Periodic reconciliation catches missed filesystem events and external
    // changes while preserving the dirty editor buffers as snapshot overlays.
    LaunchedEffect(project?.dir?.absolutePath, editorSession) {
        val active = project ?: return@LaunchedEffect
        suspend fun synchronize() {
            if (!active.dir.isDirectory || currentMissingPath.value == active.dir.absolutePath) return
            try {
                val unsaved = editorSession?.tabs
                    ?.filter { it.dirty && it.editable }
                    ?.associate { it.file.absolutePath to it.text }
                    .orEmpty()
                withContext(Dispatchers.IO) { recoveryManager.snapshot(active, unsaved) }
                currentAvailabilityCallback.value(
                    withContext(Dispatchers.IO) { recoveryManager.hasSnapshot(active) }
                )
                currentErrorCallback.value(null)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                currentErrorCallback.value(error.message ?: "Automatic recovery could not be updated.")
            }
        }
        synchronize()
        while (active.dir.isDirectory && currentMissingPath.value != active.dir.absolutePath) {
            delay(30_000L)
            synchronize()
        }
    }

    // Recursively watch project files. ProjectRecoveryWatcher performs its own
    // debounce and observer refresh off the UI thread.
    DisposableEffect(project?.dir?.absolutePath, editorSession, missingProjectPath) {
        val active = project ?: return@DisposableEffect onDispose { }
        val watcher = ProjectRecoveryWatcher(active.dir) {
            scope.launch {
                if (!active.dir.isDirectory || currentMissingPath.value == active.dir.absolutePath) return@launch
                try {
                    val unsaved = editorSession?.tabs
                        ?.filter { it.dirty && it.editable }
                        ?.associate { it.file.absolutePath to it.text }
                        .orEmpty()
                    withContext(Dispatchers.IO) {
                        recoveryManager.snapshot(active, unsaved, forceHash = true)
                    }
                    currentAvailabilityCallback.value(
                        withContext(Dispatchers.IO) { recoveryManager.hasSnapshot(active) }
                    )
                    currentErrorCallback.value(null)
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: Exception) {
                    currentErrorCallback.value(error.message ?: "Automatic recovery could not be updated.")
                }
            }
        }
        watcher.start()
        onDispose { watcher.close() }
    }

    // Observe direct-child deletion/moves from Ubuntu or any external process.
    DisposableEffect(project?.dir?.absolutePath, workspace, missingProjectPath) {
        val active = project ?: return@DisposableEffect onDispose { }
        val mainHandler = Handler(Looper.getMainLooper())
        val observer = object : FileObserver(
            workspace.absolutePath,
            FileObserver.DELETE or FileObserver.MOVED_FROM
        ) {
            override fun onEvent(event: Int, path: String?) {
                if (path != active.name) return
                mainHandler.postDelayed({
                    scope.launch {
                        val stillExists = withContext(Dispatchers.IO) { active.dir.isDirectory }
                        if (!stillExists) currentMissingCallback.value(active)
                    }
                }, 180L)
            }
        }
        observer.startWatching()
        onDispose { observer.stopWatching() }
    }
}
