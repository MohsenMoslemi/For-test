package com.codespace.ide.ide.codeintel

import java.io.File
import java.util.concurrent.ConcurrentHashMap

/** Project-scoped source-of-truth for documents currently synchronized with pylsp. */
internal class LspDocumentRegistry {
    private val sources = ConcurrentHashMap<String, String>()
    private val files = ConcurrentHashMap<String, File>()
    private val versions = ConcurrentHashMap<String, Int>()

    fun source(uri: String): String? = sources[uri]
    fun file(uri: String): File? = files[uri]
    fun version(uri: String): Int? = versions[uri]

    /** Publishes the newest editor snapshot before its didOpen/didChange notification is sent. */
    fun publish(uri: String, file: File, source: String, version: Int? = null) {
        files[uri] = file
        sources[uri] = source
        if (version != null) versions[uri] = version
    }

    fun remove(uri: String) {
        sources.remove(uri)
        files.remove(uri)
        versions.remove(uri)
    }

    fun clear() {
        sources.clear()
        files.clear()
        versions.clear()
    }
}
