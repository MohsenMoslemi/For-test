package com.codespace.ide.ide
import com.codespace.ide.ide.projects.PyProject


// Top-level navigation destinations of the IDE shell.

/** Home bottom-navigation destinations (Python-IDE flavored). */
enum class HomeTab { Projects, Terminal, Learn, Interpreter }

/** Top-level IDE destinations. */
sealed interface IdeScreen {
    data object Home : IdeScreen
    data class Editor(val project: PyProject) : IdeScreen
}
