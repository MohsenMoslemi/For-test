package com.codespace.ide.ide.codeintel

import java.io.File
import java.net.URI
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import com.codespace.ide.ide.projects.PyProject

/**
 * Resolves project-wide Python references by combining pylsp/Jedi locations with
 * the bounded local source index. It owns reference aggregation and source lookup,
 * while the controller remains responsible for the LSP session and request lane.
 */
internal class PythonWorkspaceReferenceResolver(
    private val project: PyProject,
    private val ioDispatcher: kotlinx.coroutines.CoroutineDispatcher,
    private val prepareDocument: suspend (File, String) -> LspSessionTransport?,
    private val requestReferences: suspend (File, String, Int, Boolean) -> Any?,
    private val findDefinition: suspend (File, String, Int) -> PythonDefinitionLocation?,
    private val refreshImportRoots: suspend (LspSessionTransport) -> Unit,
) {
    suspend fun resolve(
        file: File,
        source: String,
        offset: Int,
        openDocuments: Map<File, String> = emptyMap(),
    ): List<PythonReferenceOccurrence>? = withContext(ioDispatcher) {
        val active = prepareDocument(file, source) ?: return@withContext null
        val root = runCatching { project.dir.canonicalFile }.getOrNull() ?: return@withContext null
        val openByPath = openDocuments.entries.mapNotNull { (candidate, text) ->
            runCatching { candidate.canonicalFile to text }.getOrNull()
        }.toMap()
        try {
            val operationContext = currentCoroutineContext()
            refreshImportRoots(active)
            val response = requestReferences(file, source, offset, true) as? JSONArray ?: JSONArray()
            val oldName = identifierAt(source, offset)
            val definition = findDefinition(file, source, offset)
            val rootPath = root.absolutePath.trimEnd(File.separatorChar)
            val guestRoot = guestProjectPath(project).trimEnd('/')
            val result = LinkedHashMap<String, PythonReferenceOccurrence>()
            for (i in 0 until response.length()) {
                val location = response.optJSONObject(i) ?: continue
                val target = workspaceUriFile(location.optString("uri"), root, rootPath, guestRoot) ?: continue
                val range = location.optJSONObject("range") ?: continue
                val start = range.optJSONObject("start") ?: continue
                val line = start.optInt("line", -1)
                val column = start.optInt("character", -1)
                if (line < 0 || column < 0) continue
                val targetSource = openByPath[target] ?: if (target.canonicalFile == file.canonicalFile) source
                    else runCatching { target.readText(Charsets.UTF_8) }.getOrNull() ?: continue
                val snippet = targetSource.lines().getOrNull(line)?.trim().orEmpty()
                val key = "${target.absolutePath}:$line:$column"
                result[key] = PythonReferenceOccurrence(
                    target, line + 1, column, snippet,
                    PythonReferenceClassifier.classify(targetSource, line + 1, column, oldName),
                )
            }
            // Only merge the local supplement when the bounded scan completed;
            // otherwise the visible result would falsely imply completeness.
            if (definition != null && oldName.isNotBlank()) {
                val indexed = WorkspacePythonReferenceIndex.findReferences(
                    root, definition.file, oldName, openByPath,
                    checkCancelled = { operationContext.ensureActive() },
                )
                if (indexed.complete) indexed.hits.forEach { hit ->
                    val key = "${hit.file.absolutePath}:${hit.line - 1}:${hit.column}"
                    val hitSource = openByPath[hit.file.canonicalFile]
                        ?: runCatching { hit.file.readText(Charsets.UTF_8) }.getOrDefault("")
                    result[key] = PythonReferenceOccurrence(
                        hit.file, hit.line, hit.column, hit.snippet,
                        PythonReferenceClassifier.classify(hitSource, hit.line, hit.column, oldName),
                    )
                }
            }
            result.values.sortedWith(
                compareBy<PythonReferenceOccurrence> { it.file.relativeTo(root).path }
                    .thenBy { it.line }.thenBy { it.column },
            )
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            null
        }
    }

    private fun workspaceUriFile(uri: String, root: File, rootPath: String, guestRoot: String): File? {
        return try {
            val path = URI(uri).normalize().path ?: return null
            val relative = when {
                path == guestRoot -> ""
                path.startsWith("$guestRoot/") -> path.removePrefix(guestRoot).trimStart('/')
                path == rootPath -> ""
                path.startsWith(rootPath + File.separator) -> path.removePrefix(rootPath).trimStart(File.separatorChar)
                else -> return null
            }
            if (relative.isBlank()) return null
            val target = File(root, relative).canonicalFile
            if (!target.absolutePath.startsWith(rootPath + File.separator) || target == root) null else target
        } catch (_: Exception) { null }
    }

    private fun identifierAt(source: String, rawOffset: Int): String {
        if (source.isEmpty()) return ""
        val offset = rawOffset.coerceIn(0, source.length)
        var start = offset.coerceAtMost(source.length - 1)
        if (start == source.length || !isIdentifierPart(source[start])) start--
        if (start < 0) return ""
        var end = start + 1
        while (start > 0 && isIdentifierPart(source[start - 1])) start--
        while (end < source.length && isIdentifierPart(source[end])) end++
        return source.substring(start, end)
    }

    private fun isIdentifierPart(char: Char): Boolean = char == '_' || char.isLetterOrDigit()
}
