package com.codespace.ide.ide.codeintel

import android.os.FileObserver
import android.os.Handler
import android.os.Looper
import com.codespace.ide.ProotManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Independent package/interpreter index for one project's effective Python
 * interpreter. It deliberately inventories installed distributions through
 * importlib.metadata (the interpreter's own view), while filesystem observers
 * watch only the selected venv's library tree. It never walks package source
 * trees or feeds them into the project symbol/reference index.
 */
class PythonEnvironmentIndexMonitor(
    private val projectRoot: File,
    private val guestProjectRoot: String,
    private val pythonCommandProvider: () -> String,
    private val venvNameProvider: () -> String,
    private val proot: ProotManager
) : AutoCloseable {
    data class Package(val name: String, val version: String)
    data class Change(val time: Long, val message: String, val kind: String)
    enum class Status { IDLE, SCANNING, READY, ERROR }
    data class State(
        val status: Status = Status.IDLE,
        val pythonVersion: String = "—",
        val pipVersion: String = "—",
        val interpreter: String = "",
        val packageCount: Int = 0,
        val packages: List<Package> = emptyList(),
        val added: List<Package> = emptyList(),
        val removed: List<Package> = emptyList(),
        val updated: List<Pair<Package, Package>> = emptyList(),
        val activities: List<Change> = emptyList(),
        val lastRefreshedAt: Long = 0L,
        val message: String = "Waiting to inspect Python environment",
        val error: String? = null,
        val liveWatchAvailable: Boolean = false
    )

    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "PySpace-EnvironmentIndex").apply { isDaemon = true } }
    private val handler = Handler(Looper.getMainLooper())
    private val closed = AtomicBoolean(false)
    private val scheduled = AtomicBoolean(false)
    private val dirty = AtomicBoolean(false)
    private val observers = ArrayList<FileObserver>()
    private val mutableState = MutableStateFlow(State(interpreter = pythonCommandProvider()))
    private val pythonCommand: String get() = pythonCommandProvider()
    private val venvName: String get() = venvNameProvider()
    val state: StateFlow<State> = mutableState.asStateFlow()
    @Volatile private var started = false
    @Volatile private var pendingPath = "Python environment files"

    private val fallbackPoll = object : Runnable {
        override fun run() {
            if (closed.get()) return
            if (!mutableState.value.liveWatchAvailable) refreshNow()
            handler.postDelayed(this, FALLBACK_POLL_MS)
        }
    }

    private val refreshRunnable: Runnable = Runnable {
        if (closed.get()) return@Runnable
        dirty.set(true)
        if (scheduled.compareAndSet(false, true)) {
            worker.execute {
                try {
                    do {
                        dirty.set(false)
                        val reason = pendingPath
                        attachObservers()
                        refresh(reason)
                    } while (dirty.get() && !closed.get())
                } finally {
                    scheduled.set(false)
                    if (dirty.get() && !closed.get()) schedulePendingRefresh()
                }
            }
        }
    }

    private fun schedulePendingRefresh() {
        if (!closed.get()) handler.post(refreshRunnable)
    }

    fun start() {
        if (closed.get() || started) return
        started = true
        worker.execute { attachObservers(); refresh("Environment opened") }
        handler.postDelayed(fallbackPoll, FALLBACK_POLL_MS)
    }

    fun refreshNow() {
        if (closed.get()) return
        pendingPath = "Manual environment refresh"
        dirty.set(true)
        if (scheduled.compareAndSet(false, true)) {
            worker.execute {
                try {
                    do {
                        dirty.set(false)
                        val reason = pendingPath
                        attachObservers()
                        refresh(reason)
                    } while (dirty.get() && !closed.get())
                } finally {
                    scheduled.set(false)
                    if (dirty.get() && !closed.get()) schedulePendingRefresh()
                }
            }
        }
    }

    @Synchronized private fun attachObservers() {
        if (closed.get()) return
        observers.forEach { runCatching { it.stopWatching() } }
        observers.clear()
        // Keep a lightweight project-root observer so a venv created after
        // the editor opens can be attached without restarting the monitor.
        runCatching {
            val rootObserver = object : FileObserver(projectRoot.absolutePath, MASK) {
                override fun onEvent(event: Int, path: String?) {
                    if (closed.get()) return
                    if (path == venvName || path == ".pyspace_venv") {
                        pendingPath = "virtual environment changed"
                        dirty.set(true)
                        handler.removeCallbacks(refreshRunnable)
                        handler.postDelayed(refreshRunnable, DEBOUNCE_MS)
                    }
                }
            }
            rootObserver.startWatching()
            observers.add(rootObserver)
        }
        val venv = File(projectRoot, venvName)
        val library = File(venv, "lib")
        if (venv.isDirectory) {
            runCatching {
                val venvObserver = object : FileObserver(venv.absolutePath, MASK) {
                    override fun onEvent(event: Int, path: String?) {
                        if (closed.get() || path != "lib") return
                        pendingPath = "virtual environment library changed"
                        dirty.set(true)
                        handler.removeCallbacks(refreshRunnable)
                        handler.postDelayed(refreshRunnable, DEBOUNCE_MS)
                    }
                }
                venvObserver.startWatching()
                observers.add(venvObserver)
            }
        }
        if (!library.isDirectory) {
            mutableState.value = mutableState.value.copy(liveWatchAvailable = false)
            return
        }
        val stack = ArrayDeque<File>()
        val visited = HashSet<String>()
        stack.add(library)
        while (stack.isNotEmpty() && observers.size < MAX_WATCHED_DIRECTORIES) {
            val dir = stack.removeLast()
            val canonical = runCatching { dir.canonicalPath }.getOrDefault(dir.absolutePath)
            if (!visited.add(canonical)) continue
            runCatching {
                val observer = object : FileObserver(dir.absolutePath, MASK) {
                    override fun onEvent(event: Int, path: String?) {
                        if (closed.get() || event and MASK == 0) return
                        pendingPath = path?.takeIf { it.isNotBlank() } ?: "package metadata"
                        dirty.set(true)
                        handler.removeCallbacks(refreshRunnable)
                        handler.postDelayed(refreshRunnable, DEBOUNCE_MS)
                    }
                }
                observer.startWatching()
                observers.add(observer)
            }
            val children = runCatching { dir.listFiles() }.getOrNull().orEmpty()
            children.filter { it.isDirectory && !isSymlink(it) && it.name !in IGNORED_DIRS }
                .forEach { stack.add(it) }
        }
        mutableState.value = mutableState.value.copy(liveWatchAvailable = observers.size > 1)
    }

    private fun refresh(reason: String) {
        if (closed.get()) return
        mutableState.value = mutableState.value.copy(status = Status.SCANNING, message = "Inspecting installed packages…", error = null)
        val script = "import json,sys,importlib.metadata as m\n" +
            "pkgs=[]\n" +
            "\nfor d in m.distributions():\n try: pkgs.append({'name': d.metadata.get('Name') or d.metadata.get('name') or '', 'version': d.version})\n except Exception: pass\n" +
            "try: pip=m.version('pip')\nexcept Exception: pip='not installed'\n" +
            "print('__PYSPACE_ENV__'+json.dumps({'python':sys.version.split()[0],'pip':pip,'packages':pkgs}, separators=(',',':')))"
        val command = "cd ${shellQuote(guestProjectRoot)} && ${shellQuote(pythonCommand)} -c ${shellQuote(script)}"
        val output = try { proot.runOnce(command, timeoutSec = COMMAND_TIMEOUT_SECONDS) }
        catch (t: Throwable) { "ERROR: ${t.message}" }
        val marker = output.indexOf(SENTINEL)
        if (marker < 0) {
            mutableState.value = mutableState.value.copy(
                status = Status.ERROR,
                message = "Python environment inspection failed",
                error = output.takeLast(1800).ifBlank { "The selected Python interpreter returned no package inventory." }
            )
            return
        }
        val jsonStart = marker + SENTINEL.length
        val jsonEnd = output.indexOf("\n[exit=", jsonStart).let { if (it < 0) output.length else it }
        val parsed = try { JSONObject(output.substring(jsonStart, jsonEnd).trim()) }
        catch (t: Throwable) {
            mutableState.value = mutableState.value.copy(status = Status.ERROR, message = "Invalid package inventory", error = t.message ?: "Could not parse package list")
            return
        }
        val packages = parsePackages(parsed.optJSONArray("packages") ?: JSONArray())
        val previous = mutableState.value.packages.associateBy { normalize(it.name) }
        val current = packages.associateBy { normalize(it.name) }
        val added = packages.filter { normalize(it.name) !in previous }
        val removed = mutableState.value.packages.filter { normalize(it.name) !in current }
        val updated = packages.mapNotNull { now ->
            val before = previous[normalize(now.name)]
            if (before != null && before.version != now.version) before to now else null
        }
        val activities = mutableState.value.activities.toMutableList()
        val hasPackageChanges = added.isNotEmpty() || removed.isNotEmpty() || updated.isNotEmpty()
        if (mutableState.value.lastRefreshedAt == 0L) {
            activities.add(0, Change(System.currentTimeMillis(), "Indexed ${packages.size} installed distributions", "success"))
        } else if (hasPackageChanges) {
            val parts = ArrayList<String>()
            if (added.isNotEmpty()) parts += "+${added.size} installed"
            if (removed.isNotEmpty()) parts += "−${removed.size} removed"
            if (updated.isNotEmpty()) parts += "~${updated.size} upgraded"
            activities.add(0, Change(System.currentTimeMillis(), "${parts.joinToString(" · ")} · $reason", "change"))
        } else if (reason == "Manual environment refresh") {
            activities.add(0, Change(System.currentTimeMillis(), "No package changes detected", "info"))
        }
        val python = parsed.optString("python", "unknown")
        val pip = parsed.optString("pip", "unknown")
        mutableState.value = mutableState.value.copy(
            status = Status.READY, pythonVersion = python, pipVersion = pip, interpreter = pythonCommand,
            packageCount = packages.size, packages = packages,
            added = if (hasPackageChanges) added else mutableState.value.added,
            removed = if (hasPackageChanges) removed else mutableState.value.removed,
            updated = if (hasPackageChanges) updated else mutableState.value.updated,
            activities = activities.take(MAX_ACTIVITIES), lastRefreshedAt = System.currentTimeMillis(),
            message = if (added.isNotEmpty() || removed.isNotEmpty() || updated.isNotEmpty()) "Environment changes detected" else "Python environment is up to date",
            error = null
        )
    }

    private fun parsePackages(array: JSONArray): List<Package> {
        val result = LinkedHashMap<String, Package>()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val name = item.optString("name").trim()
            val version = item.optString("version").trim()
            if (name.isNotEmpty()) result[normalize(name)] = Package(name, version)
        }
        return result.values.sortedBy { it.name.lowercase() }
    }

    private fun normalize(name: String): String = name.lowercase().replace(Regex("[-_.]+"), "-")
    private fun shellQuote(value: String): String = "'" + value.replace("'", "'\\''") + "'"
    private fun isSymlink(file: File): Boolean = runCatching { java.nio.file.Files.isSymbolicLink(file.toPath()) }.getOrDefault(false)

    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        handler.removeCallbacksAndMessages(null)
        synchronized(this) { observers.forEach { runCatching { it.stopWatching() } }; observers.clear() }
        worker.shutdownNow()
    }

    companion object {
        private const val SENTINEL = "__PYSPACE_ENV__"
        private const val DEBOUNCE_MS = 1100L
        private const val COMMAND_TIMEOUT_SECONDS = 60L
        private const val FALLBACK_POLL_MS = 30_000L
        private const val MAX_WATCHED_DIRECTORIES = 1800
        private const val MAX_ACTIVITIES = 80
        private val MASK = FileObserver.CREATE or FileObserver.DELETE or FileObserver.MOVED_FROM or FileObserver.MOVED_TO or FileObserver.CLOSE_WRITE or FileObserver.ATTRIB or FileObserver.DELETE_SELF or FileObserver.MOVE_SELF
        private val IGNORED_DIRS = setOf("__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache")
    }
}
