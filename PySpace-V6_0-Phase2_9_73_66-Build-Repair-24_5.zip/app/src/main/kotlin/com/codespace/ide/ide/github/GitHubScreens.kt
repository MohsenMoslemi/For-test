package com.codespace.ide.ide.github

import android.util.Base64
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeParseException
import java.nio.file.Files
import java.nio.file.FileSystems
import java.nio.file.PathMatcher
import java.nio.file.Paths
import java.util.zip.ZipInputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import com.codespace.ide.ide.editor.EditorSession
import com.codespace.ide.ide.settings.IdePrefs
import com.codespace.ide.ide.theme.IdeTheme

// ---------------------------------------------------------------------------
// Built-in GitHub client: app-wide token validation, repository list/create,
// source snapshot import and snapshot publishing — all through GitHub HTTPS APIs.
// This is not a local Git client and does not maintain a .git directory.
// No git binary or extra dependencies. Every helper below BLOCKS and must run on
// Dispatchers.IO; the UI enforces that.
// ---------------------------------------------------------------------------

@Composable
private fun GhPurpleButton(label: String, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .background(Color(IdeTheme.ACCENT).copy(alpha = if (enabled) 1f else 0.4f))
        .clickable(enabled = enabled, onClick = onClick)
        .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color(IdeTheme.ON_ACCENT), fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

/** App-wide GitHub account management. The encrypted token is shared by every project. */
@Composable
fun GitHubAccountSettingsCard() {
    val context = LocalContext.current.applicationContext
    val prefs = remember { IdePrefs(context) }
    val scope = rememberCoroutineScope()
    var tokenInput by remember { mutableStateOf("") }
    var expiryInput by remember {
        mutableStateOf(
            prefs.githubTokenExpiresAt.takeIf { it > 0L }?.let {
                java.time.Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate().toString()
            } ?: ""
        )
    }
    var checking by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var messageOk by remember { mutableStateOf(true) }
    var accountLogin by remember { mutableStateOf(prefs.githubLogin) }
    var hasToken by remember { mutableStateOf(prefs.githubToken.isNotBlank()) }
    val expiry = prefs.githubTokenExpiresAt
    val expired = expiry > 0L && expiry <= System.currentTimeMillis()
    val expiryStatus = when {
        !hasToken -> "No account connected"
        expired -> "Saved expiration date has passed"
        expiry > 0L -> {
            val days = ((expiry - System.currentTimeMillis() + 86_399_999L) / 86_400_000L).toInt()
            if (days <= 7) "Token expires in $days day${if (days == 1) "" else "s"}"
            else "Token expiration: ${java.time.Instant.ofEpochMilli(expiry).atZone(ZoneOffset.UTC).toLocalDate()}"
        }
        else -> "No expiration date recorded"
    }

    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color(IdeTheme.PANEL)).padding(16.dp),
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Color(IdeTheme.ACCENT).copy(alpha = .16f)), contentAlignment = Alignment.Center) {
                Text("GH", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(if (hasToken) accountLogin.ifBlank { "GitHub account connected" } else "Connect GitHub", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(expiryStatus, color = if (expired) Color(IdeTheme.ERROR) else Color(IdeTheme.DIM), fontSize = 11.sp)
            }
            if (checking) CircularProgressIndicator(Modifier.size(19.dp), strokeWidth = 2.dp, color = Color(IdeTheme.ACCENT))
        }
        Text(
            "Connect once here. Repository browsing, private imports, cloning and publishing in every project will use this account automatically.",
            color = Color(IdeTheme.DIM), fontSize = 12.sp, lineHeight = 17.sp
        )
        OutlinedTextField(
            value = tokenInput,
            onValueChange = { tokenInput = it },
            modifier = Modifier.fillMaxWidth(),
            enabled = !checking,
            singleLine = true,
            label = { Text(if (hasToken) "Replace personal access token (optional)" else "Personal access token") },
            placeholder = { Text(if (hasToken) "Leave blank to verify saved token" else "ghp_… or github_pat_…") },
            visualTransformation = PasswordVisualTransformation()
        )
        OutlinedTextField(
            value = expiryInput,
            onValueChange = { expiryInput = it },
            modifier = Modifier.fillMaxWidth(),
            enabled = !checking,
            singleLine = true,
            label = { Text("Token expiration date (optional)") },
            placeholder = { Text("YYYY-MM-DD") },
            supportingText = { Text("GitHub does not expose personal-token expiry through the account API. Enter the date shown when creating your token.", color = Color(IdeTheme.DIM), fontSize = 10.sp) }
        )
        GhPurpleButton(if (checking) "Checking…" else if (hasToken) "Verify and save account" else "Connect account", enabled = !checking) {
            val candidate = tokenInput.trim().ifBlank { prefs.githubToken }
            if (candidate.isBlank()) {
                message = "Enter a personal access token first."
                messageOk = false
            } else {
                val expiryMillis = try {
                    if (expiryInput.isBlank()) {
                        if (candidate == prefs.githubToken) prefs.githubTokenExpiresAt else 0L
                    } else {
                        LocalDate.parse(expiryInput.trim()).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
                    }
                } catch (_: DateTimeParseException) { -1L }
                if (expiryMillis < 0L) {
                    message = "Use a valid date in YYYY-MM-DD format."
                    messageOk = false
                } else if (expiryMillis > 0L && expiryMillis <= System.currentTimeMillis()) {
                    message = "This expiration date has already passed. Update the token or its expiration date."
                    messageOk = false
                } else {
                    checking = true
                    message = null
                    scope.launch(Dispatchers.IO) {
                        val response = ghRequest("GET", "$GH_API/user", candidate)
                        val login = if (response.code == 200) try { JSONObject(response.body).optString("login", "") } catch (_: Exception) { "" } else ""
                        withContext(Dispatchers.Main) {
                            checking = false
                            if (response.code == 200 && login.isNotBlank()) {
                                if (prefs.saveGithubAccount(candidate, login, expiryMillis)) {
                                    accountLogin = login
                                    hasToken = prefs.githubToken.isNotBlank()
                                    tokenInput = ""
                                    message = "Connected as $login. This account is now available across PySpace."
                                    messageOk = true
                                } else {
                                    message = "Could not securely store the token. Check Android Keystore availability and try again."
                                    messageOk = false
                                }
                            } else {
                                message = if (response.code == 401) "GitHub rejected this token. It may be expired, revoked or malformed." else ghErr(response)
                                messageOk = false
                            }
                        }
                    }
                }
            }
        }
        if (hasToken) {
            TextButton(
                enabled = !checking,
                onClick = {
                    prefs.clearGithubAccount()
                    hasToken = false
                    accountLogin = ""
                    tokenInput = ""
                    expiryInput = ""
                    message = "GitHub account disconnected from this app."
                    messageOk = true
                }
            ) { Text("Disconnect account", color = Color(IdeTheme.ERROR), fontSize = 12.sp) }
        }
        message?.let {
            Text(it, color = if (messageOk) Color(IdeTheme.ACCENT) else Color(IdeTheme.ERROR), fontSize = 11.sp, lineHeight = 16.sp)
        }
        Text(
            "Permissions: classic token → repo (plus workflow only if you publish GitHub Actions workflows). Fine-grained token → Contents: Read and write for the repositories you use; Metadata: read is required automatically.",
            color = Color(IdeTheme.DIM), fontSize = 10.sp, lineHeight = 15.sp
        )
        Text("The token is encrypted with Android Keystore and is never stored as plain text.", color = Color(IdeTheme.DIM), fontSize = 10.sp)
    }
}

/** Drawer Git tab: uses the app-wide account for repositories, import and publishing.
 *  Snapshot-based operations do not maintain a local .git directory/history. */
@Composable
fun GitHubTab(session: EditorSession) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { IdePrefs(ctx) }
    var token by remember { mutableStateOf(prefs.githubToken) }
    var tokenExpiry by remember { mutableStateOf(prefs.githubTokenExpiresAt) }
    var ghLogin by remember { mutableStateOf<String?>(null) }
    var authChecked by remember { mutableStateOf(false) }
    var repos by remember { mutableStateOf<List<GhRepo>?>(null) }
    var busy by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<String?>(null) }
    var resultOk by remember { mutableStateOf(true) }
    var showNew by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var newDesc by remember { mutableStateOf("") }
    var newPrivate by remember { mutableStateOf(true) }
    var cloneFor by remember { mutableStateOf<GhRepo?>(null) }
    var pushTarget by remember { mutableStateOf(prefs.githubTarget(session.project.name).substringBefore("@")) }
    var pushBranch by remember {
        mutableStateOf(
            prefs.githubTarget(session.project.name).substringAfter("@", "")
        )
    }
    var pushMsg by remember { mutableStateOf("") }
    var repoFilter by remember { mutableStateOf("") }
    var activeSection by remember { mutableStateOf("Repositories") }
    var branches by remember { mutableStateOf<List<String>>(emptyList()) }
    var showBranches by remember { mutableStateOf(false) }
    var showCreateBranch by remember { mutableStateOf(false) }
    var newBranchName by remember { mutableStateOf("") }

    // Keep an already-open project GitHub panel in sync with app-wide account changes.
    DisposableEffect(ctx) {
        val shared = ctx.getSharedPreferences("pyspace_ide", android.content.Context.MODE_PRIVATE)
        val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "github_token_enc" || key == "github_token" || key == "github_token_expires_at") {
                val updated = prefs.githubToken
                val updatedExpiry = prefs.githubTokenExpiresAt
                if (updated != token || updatedExpiry != tokenExpiry) {
                    if (updated != token) {
                        token = updated
                        ghLogin = null
                        repos = null
                        result = null
                    }
                    tokenExpiry = updatedExpiry
                    authChecked = false
                }
            }
        }
        shared.registerOnSharedPreferenceChangeListener(listener)
        onDispose { shared.unregisterOnSharedPreferenceChangeListener(listener) }
    }

    fun fail(msg: String) {
        result = msg
        resultOk = false
        busy = ""
    }

    fun done(msg: String) {
        result = msg
        resultOk = true
        busy = ""
    }

    fun loadRepos(t: String) {
        busy = "Loading repositories…"
        result = null
        scope.launch(Dispatchers.IO) {
            // GitHub paginates repository lists. Load up to five pages so
            // accounts with more than 100 repositories are not silently truncated.
            val combined = JSONArray()
            var r = GhResp(200, "[]")
            for (page in 1..5) {
                r = ghRequest("GET", "$GH_API/user/repos?per_page=100&page=$page&sort=updated", t)
                if (r.code != 200) break
                val pageItems = try { JSONArray(r.body) } catch (_: Exception) { JSONArray() }
                for (i in 0 until pageItems.length()) combined.put(pageItems.optJSONObject(i))
                if (pageItems.length() < 100) break
            }
            if (r.code == 200) r = GhResp(200, combined.toString())
            withContext(Dispatchers.Main) {
                if (r.code == 200) {
                    repos = parseRepos(r.body)
                    busy = ""
                } else if (r.code == 401) {
                    ghLogin = null
                    repos = null
                    fail("GitHub rejected the saved token. It may be expired, revoked, or missing repository permissions. Update it in Settings → GitHub.")
                } else {
                    fail(ghErr(r))
                }
            }
        }
    }

    fun login(t: String) {
        val tok = t.trim()
        if (tok.isEmpty()) {
            fail("Paste a personal access token first.")
            return
        }
        busy = "Signing in…"
        result = null
        scope.launch(Dispatchers.IO) {
            val r = ghRequest("GET", "$GH_API/user", tok)
            withContext(Dispatchers.Main) {
                if (r.code == 200) {
                    val login = try {
                        JSONObject(r.body).optString("login", "")
                    } catch (_: Exception) {
                        ""
                    }
                    if (login.isBlank()) {
                        fail("Sign-in failed.")
                    } else {
                        prefs.githubToken = tok
                        prefs.githubLogin = login
                        token = tok
                        ghLogin = login
                        authChecked = true
                        busy = ""
                        loadRepos(tok)
                    }
                } else if (r.code == 401) {
                    fail("Invalid token or missing GitHub access permissions.")
                } else {
                    fail(ghErr(r))
                }
            }
        }
    }

    fun selectRepo(repo: GhRepo) {
        pushTarget = repo.fullName
        pushBranch = repo.defaultBranch
        prefs.setGithubTarget(session.project.name, repo.fullName + "@" + repo.defaultBranch)
    }

    fun loadBranches() {
        if (pushTarget.count { it == '/' } != 1) return
        busy = "Loading branches…"
        scope.launch(Dispatchers.IO) {
            val (items, error) = ghListBranches(token, pushTarget)
            withContext(Dispatchers.Main) {
                if (error == null) {
                    branches = items ?: emptyList()
                    showBranches = true
                    busy = ""
                } else fail(error)
            }
        }
    }

    fun createBranch() {
        val name = newBranchName.trim()
        if (name.isBlank()) { fail("Enter a branch name."); return }
        busy = "Creating branch…"
        scope.launch(Dispatchers.IO) {
            val out = ghCreateBranch(token, pushTarget, pushBranch, name)
            withContext(Dispatchers.Main) {
                if (out.startsWith("Created")) {
                    pushBranch = name
                    prefs.setGithubTarget(session.project.name, "$pushTarget@$name")
                    newBranchName = ""
                    showCreateBranch = false
                    done(out)
                    loadBranches()
                } else fail(out)
            }
        }
    }

    fun doCreate() {
        val name = newName.trim()
        if (!name.matches(Regex("[A-Za-z0-9_.-]+"))) {
            fail("Repository name: letters, digits, . - _")
            return
        }
        busy = "Creating repository…"
        result = null
        scope.launch(Dispatchers.IO) {
            val body = try {
                JSONObject().put("name", name).put("private", newPrivate)
                .put("description", newDesc.trim()).toString()
            } catch (_: Exception) {
                ""
            }
            if (body.isEmpty()) {
                withContext(Dispatchers.Main) { fail("Create build failed.") }
                return@launch
            }
            val r = ghRequest("POST", "$GH_API/user/repos", token, body)
            withContext(Dispatchers.Main) {
                if (r.code == 201) {
                    val full = try {
                        JSONObject(r.body).optString("full_name", "")
                    } catch (_: Exception) {
                        ""
                    }
                    newName = ""
                    newDesc = ""
                    showNew = false
                    if (full.contains("/")) {
                        pushTarget = full
                        pushBranch = "main"
                        prefs.setGithubTarget(session.project.name, "$full@main")
                        activeSection = "Publish"
                    }
                    loadRepos(token)
                    done("Created $full ✓")
                } else {
                    fail(ghErr(r))
                }
            }
        }
    }

    fun doClone(repo: GhRepo) {
        cloneFor = null
        busy = "Importing ${repo.name} snapshot…"
        result = null
        scope.launch(Dispatchers.IO) {
            val parent = try {
                session.project.dir.parentFile
            } catch (_: Exception) {
                null
            }
            if (parent == null) {
                withContext(Dispatchers.Main) { fail("No workspace folder.") }
                return@launch
            }
            val dest = uniqueDir(parent, repo.name)
            val tmp = try {
                File.createTempFile("ghclone", ".zip", ctx.cacheDir)
            } catch (_: Exception) {
                null
            }
            if (tmp == null) {
                withContext(Dispatchers.Main) { fail("No space for download.") }
                return@launch
            }
            val err = ghDownloadZip(token, repo.fullName, repo.defaultBranch, tmp)
            var msg = if (err == null) unzipTo(tmp, dest) else err
            try { tmp.delete() } catch (_: Exception) {}
            if (!msg.startsWith("Cloned")) {
                try { dest.deleteRecursively() } catch (_: Exception) {}
                msg = ghDownloadTreeSnapshot(token, repo.fullName, repo.defaultBranch, dest)
            }
            if (!msg.startsWith("Cloned")) {
                // Roll back a partial extraction on the IO dispatcher, never
                // block the drawer's main thread with recursive deletion.
                try { dest.deleteRecursively() } catch (_: Exception) {}
            }
            if (msg.startsWith("Cloned")) {
                try {
                    val ignore = File(dest, ".gitignore")
                    if (!ignore.exists()) ignore.writeText(defaultPythonGitIgnore())
                } catch (_: Exception) {}
            }
            withContext(Dispatchers.Main) {
                if (msg.startsWith("Cloned")) {
                    done(msg.replaceFirst("Cloned", "Imported") + " into ${dest.name} — open it from Projects.")
                } else fail(msg)
            }
        }
    }

    fun doPush() {
        val tgt = pushTarget.trim()
        val br = pushBranch.trim().ifBlank { "main" }
        val msg = pushMsg.trim()
        if (tgt.count { it == '/' } != 1) {
            fail("Pick a repository above first (tap one).")
            return
        }
        if (msg.isEmpty()) {
            fail("Write a commit message first.")
            return
        }
        prefs.setGithubTarget(session.project.name, "$tgt@$br")
        busy = "Collecting files…"
        result = null
        scope.launch(Dispatchers.IO) {
            val snapshot = collectPushFiles(session.project.dir)
            val files = snapshot.files
            if (files.isEmpty()) {
                withContext(Dispatchers.Main) { fail("No publishable project files were found.") }
                return@launch
            }
            withContext(Dispatchers.Main) {
                busy = if (snapshot.complete) "Publishing ${files.size} files…"
                    else "Publishing ${files.size} files (large files / scan limits detected)…"
            }
            val out = ghPushSnapshot(
                token, tgt, br, msg, files, snapshot.preservedDirectories, snapshot.complete, snapshot.gitIgnoreMatcher
            )
            withContext(Dispatchers.Main) {
                if (out.startsWith("Published")) {
                    pushMsg = ""
                    done(out)
                } else {
                    fail(out)
                }
            }
        }
    }

    // Auto sign-in with the stored token (once per project).
    LaunchedEffect(session.project.dir.absolutePath, token, tokenExpiry, authChecked) {
        val t = token
        val expiresAt = tokenExpiry
        if (t.isNotBlank() && !authChecked) {
            if (expiresAt > 0L && expiresAt <= System.currentTimeMillis()) {
                authChecked = true
                fail("The saved GitHub token expiration date has passed. Update it in Settings → GitHub.")
            } else login(t)
        } else if (t.isBlank()) authChecked = true
    }

    CompositionLocalProvider(LocalContentColor provides Color(IdeTheme.TEXT)) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)
    ) {
        Text("GitHub", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(IdeTheme.TEXT))
        Text("Repositories · branches · publishing", fontSize = 11.sp, color = Color(IdeTheme.DIM))
        Spacer(Modifier.height(12.dp))
        val user = ghLogin
        if (user == null) {
            Text(
                "Connect your GitHub account once from Settings → GitHub. The saved account is shared across all projects; you do not need to enter a token here.",
                color = Color(IdeTheme.DIM), fontSize = 12.sp, lineHeight = 18.sp
            )
            Spacer(Modifier.height(8.dp))
            Text("Private repositories require Contents: read permission. If a private repository appears in the list but cannot be imported, update the token permissions in Settings.", color = Color(IdeTheme.DIM), fontSize = 11.sp)
        } else {
            Row(
                Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(IdeTheme.CARD))
                .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(IdeTheme.ACCENT).copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        user.firstOrNull()?.uppercase() ?: "G",
                        fontWeight = FontWeight.Bold, fontSize = 16.sp,
                        color = Color(IdeTheme.ACCENT)
                    )
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(user, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, color = Color(IdeTheme.TEXT))
                    Text("Signed in", color = Color(IdeTheme.DIM), fontSize = 11.sp)
                }
                TextButton(onClick = { loadRepos(token) }) {
                    Text("Refresh", color = Color(IdeTheme.DIM), fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                    .background(Color(IdeTheme.CARD)).padding(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("Repositories", "Publish").forEach { section ->
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                            .background(if (activeSection == section) Color(IdeTheme.ACCENT).copy(alpha = 0.18f) else Color.Transparent)
                            .clickable { activeSection = section }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(section, color = if (activeSection == section) Color(IdeTheme.ACCENT) else Color(IdeTheme.DIM),
                            fontSize = 12.sp, fontWeight = if (activeSection == section) FontWeight.Bold else FontWeight.Medium)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            if (activeSection == "Repositories") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Repositories", fontWeight = FontWeight.Bold, fontSize = 14.sp,
                    color = Color(IdeTheme.TEXT), modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { loadRepos(token) }) {
                    Text("⟳", fontSize = 14.sp, color = Color(IdeTheme.DIM))
                }
                TextButton(onClick = { showNew = !showNew }) {
                    Text(
                        if (showNew) "Close" else "+ New",
                        fontSize = 13.sp, color = Color(IdeTheme.ACCENT)
                    )
                }
            }
            if (showNew) {
                OutlinedTextField(
                    value = newName, onValueChange = { newName = it },
                    label = { Text("Repository name") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = newDesc, onValueChange = { newDesc = it },
                    label = { Text("Description (optional)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Private", fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Switch(checked = newPrivate, onCheckedChange = { newPrivate = it })
                }
                Spacer(Modifier.height(6.dp))
                GhPurpleButton("Create repository") { doCreate() }
                Spacer(Modifier.height(6.dp))
            }
            OutlinedTextField(
                value = repoFilter, onValueChange = { repoFilter = it },
                label = { Text("Search repositories") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(6.dp))
            val list = repos?.filter {
                repoFilter.isBlank() || it.fullName.contains(repoFilter, true) ||
                    it.description.contains(repoFilter, true)
            }
            if (list == null) {
                if (busy.isNotBlank()) {
                    Text("…", color = Color(IdeTheme.DIM), fontSize = 12.sp)
                }
            } else if (list.isEmpty()) {
                Text(
                    if (repoFilter.isBlank()) "No repositories yet." else "No matching repositories.", color = Color(IdeTheme.DIM),
                    fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp)
                )
            } else {
                Column(
                    Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(IdeTheme.CARD))
                    .padding(vertical = 4.dp)
                ) {
                    list.forEach { repo ->
                        val sel = pushTarget == repo.fullName
                        Row(
                            Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (sel) Color(IdeTheme.ACCENT).copy(alpha = 0.14f)
                                else Color.Transparent
                            )
                            .clickable { selectRepo(repo) }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        repo.name, fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold, maxLines = 1,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (repo.isPrivate) {
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            "private", color = Color(IdeTheme.DIM),
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                                if (repo.description.isNotBlank() || repo.updatedAt.isNotBlank()) {
                                    Text(
                                        listOf(
                                            repo.description.take(60),
                                            repo.updatedAt
                                        ).filter { it.isNotBlank() }.joinToString(" · "),
                                        color = Color(IdeTheme.DIM), fontSize = 11.sp,
                                        maxLines = 1
                                    )
                                }
                            }
                            TextButton(onClick = { cloneFor = repo }) {
                                Text("Import", fontSize = 12.sp, color = Color(IdeTheme.ACCENT))
                            }
                        }
                    }
                }
            }
            }
            if (activeSection == "Publish") {
            Text("Publish current project", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(IdeTheme.TEXT))
            Spacer(Modifier.height(4.dp))
            Text(
                "Publishes the current project as a commit, including local file additions, edits and deletions. " +
                    "Credential files and virtual environments are excluded automatically. Review project contents before publishing.",
                color = Color(IdeTheme.DIM), fontSize = 11.sp
            )
            Spacer(Modifier.height(4.dp))
            Text(
                if (pushTarget.contains("/")) "To: $pushTarget"
                else "Choose a repository in the Repositories tab before publishing.",
                color = Color(IdeTheme.DIM), fontSize = 12.sp
            )
            if (!pushTarget.contains("/")) {
                TextButton(onClick = { activeSection = "Repositories" }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 0.dp, vertical = 2.dp)) {
                    Text("Choose or create a repository →", color = Color(IdeTheme.ACCENT), fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = pushBranch, onValueChange = { pushBranch = it },
                    label = { Text("Target branch") }, singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(6.dp))
                TextButton(onClick = { loadBranches() }, enabled = pushTarget.contains("/")) {
                    Text("Branches", color = Color(IdeTheme.ACCENT), fontSize = 11.sp)
                }
                TextButton(onClick = { showCreateBranch = true }, enabled = pushTarget.contains("/")) {
                    Text("+", color = Color(IdeTheme.ACCENT), fontSize = 16.sp)
                }
            }
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = pushMsg, onValueChange = { pushMsg = it },
                label = { Text("Commit message") }, singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            GhPurpleButton("Publish project") { doPush() }
            }
        }
        if (busy.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(busy, color = Color(IdeTheme.ACCENT), fontSize = 12.sp)
        }
        val res = result
        if (res != null) {
            Spacer(Modifier.height(8.dp))
            Text(
                res, fontSize = 12.sp,
                color = if (resultOk) Color(IdeTheme.ACCENT) else Color(IdeTheme.ERROR)
            )
        }
        Spacer(Modifier.height(24.dp))
    }
    if (cloneFor != null) {
        val repo = cloneFor!!
        IdeAlertDialog(
            onDismissRequest = { cloneFor = null },
            title = { Text("Import ${repo.name}?", fontSize = 15.sp) },
            text = {
                Text(
                    "Downloads the ${repo.defaultBranch} branch and imports its files as a new project " +
                        "next to the current project. The import preserves the source tree, not local Git metadata.",
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(onClick = { doClone(repo) }) {
                    Text("Import snapshot", color = Color(IdeTheme.ACCENT))
                }
            },
            dismissButton = {
                TextButton(onClick = { cloneFor = null }) { Text("Cancel") }
            }
        )
    }
    if (showBranches) {
        IdeAlertDialog(
            onDismissRequest = { showBranches = false },
            title = { Text("Branches", color = Color(IdeTheme.TEXT)) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    branches.forEach { branch ->
                        TextButton(onClick = {
                            pushBranch = branch
                            prefs.setGithubTarget(session.project.name, "$pushTarget@$branch")
                            showBranches = false
                        }) { Text(branch, color = if (branch == pushBranch) Color(IdeTheme.ACCENT) else Color(IdeTheme.TEXT)) }
                    }
                    if (branches.isEmpty()) Text("No branches found.", color = Color(IdeTheme.DIM))
                }
            },
            confirmButton = { TextButton(onClick = { showBranches = false }) { Text("Close") } }
        )
    }
    if (showCreateBranch) {
        IdeAlertDialog(
            onDismissRequest = { showCreateBranch = false },
            title = { Text("Create branch", color = Color(IdeTheme.TEXT)) },
            text = {
                Column {
                    Text("Create from $pushBranch", color = Color(IdeTheme.DIM), fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newBranchName, onValueChange = { newBranchName = it },
                        label = { Text("New branch name") }, singleLine = true
                    )
                }
            },
            confirmButton = { TextButton(onClick = { createBranch() }) { Text("Create", color = Color(IdeTheme.ACCENT)) } },
            dismissButton = { TextButton(onClick = { showCreateBranch = false }) { Text("Cancel") } }
        )
    }
    }
}
