package com.codespace.ide.ide.codeintel

/** Pure source-level classification for workspace reference results. */
internal object PythonReferenceClassifier {
    fun classify(source: String, lineNumber: Int, column: Int, symbol: String): PythonReferenceKind {
        val lines = source.split('\n')
        val line = lines.getOrNull(lineNumber - 1).orEmpty()
        val declaration = Regex("^(?:async\\s+)?(?:def|class)\\s+${Regex.escape(symbol)}\\b")
        if (declaration.containsMatchIn(line)) return PythonReferenceKind.DEFINITION

        // Import references can be split over several physical lines. Walk back to
        // the beginning of the logical import statement before classifying it.
        var statementStart = lineNumber - 1
        var nesting = line.count { it == '(' } - line.count { it == ')' }
        while (statementStart > 0 && nesting > 0) {
            statementStart--
            val previous = lines[statementStart]
            nesting += previous.count { it == '(' } - previous.count { it == ')' }
        }
        val logicalPrefix = lines.subList(statementStart.coerceAtLeast(0), lineNumber.coerceAtMost(lines.size)).joinToString(" ").trimStart()
        if (Regex("^(?:from\\b.*\\bimport\\b|import\\b)", RegexOption.DOT_MATCHES_ALL).containsMatchIn(logicalPrefix)) {
            return PythonReferenceKind.IMPORT
        }

        // LSP columns and Kotlin String indices both use UTF-16 code units.
        val after = line.substring((column + symbol.length).coerceIn(0, line.length)).dropWhile { it.isWhitespace() }
        if (after.startsWith("(")) return PythonReferenceKind.CALL
        return PythonReferenceKind.OTHER
}
}
