package com.codespace.ide.ide.theme

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import com.codespace.ide.ide.settings.IdePrefs

/** Semantic color palettes shared by every native IDE surface. */
data class IdeThemePreviewColors(val bg: Long, val panel: Long, val text: Long, val dim: Long, val line: Long, val accent: Long)

private data class IdeColorPalette(
    val bg: Long, val panel: Long, val card: Long, val line: Long,
    val accent: Long, val violet: Long, val lilac: Long, val teal: Long,
    val warn: Long, val text: Long, val dim: Long,
    val keyword: Long, val string: Long, val comment: Long,
    val number: Long, val builtin: Long, val decorator: Long, val function: Long,
    val className: Long, val constant: Long, val operator: Long, val error: Long,
    val onAccent: Long, val onViolet: Long, val onError: Long, val selection: Long, val successSurface: Long,
    val warningSurface: Long, val info: Long, val scrim: Long,
)

/**
 * Runtime-switchable theme tokens. Reading a token from a composable observes
 * the backing Compose state, so the entire UI updates in one composition when
 * the user changes theme. Theme IDs are persisted by IdePrefs.
 */
object IdeTheme {
    const val DARK = "dark"
    const val LIGHT = "light"

    private val darkPalette = IdeColorPalette(
        bg = 0xFF090D13, panel = 0xFF0E141D, card = 0xFF131B26, line = 0xFF1E2836,
        accent = 0xFF3DDC84, violet = 0xFF7E57C2, lilac = 0xFFCE93D8, teal = 0xFF4DD0E1,
        warn = 0xFFFFB74D, text = 0xFFE6EDF3, dim = 0xFF8B98A9,
        keyword = 0xFFC792EA, string = 0xFF9CCC65, comment = 0xFF5C6773,
        number = 0xFFF78C6C, builtin = 0xFF82AAFF, decorator = 0xFFFFCB6B,
        function = 0xFF80CBC4, className = 0xFFFFCB6B, constant = 0xFFFF9E80, operator = 0xFF89DDFF,
        error = 0xFFFF8A80, onAccent = 0xFF07110B, onViolet = 0xFFFFFFFF, onError = 0xFF101418, selection = 0xFF263442,
        successSurface = 0xFF10271D, warningSurface = 0xFF2B2418,
        info = 0xFF64B5F6, scrim = 0x99000000,
    )
    private val lightPalette = IdeColorPalette(
        bg = 0xFFF3F6FA, panel = 0xFFFFFFFF, card = 0xFFEAF0F5, line = 0xFFD5DEE8,
        accent = 0xFF168653, violet = 0xFF6F4AA8, lilac = 0xFF8056A8, teal = 0xFF087F8C,
        warn = 0xFF9A5B00, text = 0xFF17212B, dim = 0xFF647383,
        keyword = 0xFF75449B, string = 0xFF2F7132, comment = 0xFF667482,
        number = 0xFFA84625, builtin = 0xFF2457A6, decorator = 0xFF9A4B00,
        function = 0xFF087E8B, className = 0xFF6D3BA5, constant = 0xFF9A3412, operator = 0xFF6D3BA5,
        error = 0xFFB3261E, onAccent = 0xFFFFFFFF, onViolet = 0xFFFFFFFF, onError = 0xFFFFFFFF, selection = 0xFFDCE7F0,
        successSurface = 0xFFE1F3E9, warningSurface = 0xFFFFF1D9,
        info = 0xFF246AA5, scrim = 0x66000000,
    )
    // Register palettes here when adding future themes; all UI consumes the
    // same semantic token interface regardless of the selected palette.
    private val palettes = mapOf(DARK to darkPalette, LIGHT to lightPalette)
    private var current by androidx.compose.runtime.mutableStateOf(darkPalette)
    var themeId: String by androidx.compose.runtime.mutableStateOf(DARK)
        private set

    fun normalizeThemeId(id: String?): String = id?.takeIf { palettes.containsKey(it) } ?: DARK

    fun previewColors(id: String): IdeThemePreviewColors {
        val p = palettes[normalizeThemeId(id)] ?: darkPalette
        return IdeThemePreviewColors(p.bg, p.panel, p.text, p.dim, p.line, p.accent)
    }

    fun setTheme(id: String) {
        val safe = normalizeThemeId(id)
        val palette = palettes[safe] ?: darkPalette
        if (themeId == safe && current == palette) return
        themeId = safe
        current = palette
    }

    val isDark: Boolean get() = themeId != LIGHT
    val BG get() = current.bg
    val PANEL get() = current.panel
    val CARD get() = current.card
    val LINE get() = current.line
    val ACCENT get() = current.accent
    val VIOLET get() = current.violet
    val LILAC get() = current.lilac
    val TEAL get() = current.teal
    val WARN get() = current.warn
    val TEXT get() = current.text
    val DIM get() = current.dim
    val KEYWORD get() = current.keyword
    val STRING get() = current.string
    val COMMENT get() = current.comment
    val NUMBER get() = current.number
    val BUILTIN get() = current.builtin
    val DECORATOR get() = current.decorator
    val FUNCTION get() = current.function
    val CLASS_NAME get() = current.className
    val CONSTANT get() = current.constant
    val OPERATOR get() = current.operator
    val ERROR get() = current.error
    val ON_ACCENT get() = current.onAccent
    val ON_VIOLET get() = current.onViolet
    val ON_ERROR get() = current.onError
    val SELECTION get() = current.selection
    val SUCCESS_SURFACE get() = current.successSurface
    val WARNING_SURFACE get() = current.warningSurface
    val INFO get() = current.info
    val SCRIM get() = current.scrim
}
