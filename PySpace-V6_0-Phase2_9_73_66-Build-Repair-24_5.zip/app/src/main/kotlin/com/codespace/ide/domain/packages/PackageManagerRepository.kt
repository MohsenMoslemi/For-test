package com.codespace.ide.domain.packages

import java.io.File

data class InstalledPythonPackage(val name: String, val version: String)

data class PackageCommandResult(val success: Boolean, val output: String, val exitCode: Int?)

/** Domain contract for operations against a project's isolated Python environment. */
interface PackageManagerRepository {
    suspend fun listInstalled(projectDir: File): List<InstalledPythonPackage>
    suspend fun install(projectDir: File, requirement: String): PackageCommandResult
    suspend fun uninstall(projectDir: File, packageName: String): PackageCommandResult
}
