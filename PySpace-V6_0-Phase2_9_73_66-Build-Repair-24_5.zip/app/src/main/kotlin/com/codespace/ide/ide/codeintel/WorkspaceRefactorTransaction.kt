package com.codespace.ide.ide.codeintel

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID

/** Durable, user-directed recovery for interrupted multi-file workspace refactors. */
object WorkspaceRefactorTransaction {
    private const val DIRECTORY = ".pyspace-refactor-transactions"
    private const val MANIFEST = "manifest.json"
    private const val VERSION = 1

    data class Pending(val directory: File, val fileCount: Int, val createdAt: Long)

    private data class Entry(
        val relativePath: String,
        val backupName: String,
        val stagedName: String,
        val originalHash: String,
        val updatedHash: String
    )

    private data class Manifest(val state: String, val createdAt: Long, val entries: List<Entry>)

    fun pending(root: File): List<Pending> = runCatching {
        val base = File(root, DIRECTORY)
        if (!base.isDirectory) return emptyList()
        base.listFiles().orEmpty().filter { it.isDirectory }.mapNotNull { dir ->
            val manifestFile = File(dir, MANIFEST)
            val manifest = readManifest(dir)
            if (manifest == null) {
                // No published manifest means prepare never reached its commit
                // point; originals are guaranteed untouched. A published but
                // unreadable manifest must be surfaced, never silently ignored.
                if (manifestFile.exists()) Pending(dir, 0, dir.lastModified())
                else { dir.deleteRecursively(); null }
            } else if (manifest.state == "COMMITTED") {
                dir.deleteRecursively()
                null
            } else Pending(dir, manifest.entries.size, manifest.createdAt)
        }.sortedBy { it.createdAt }
    }.getOrDefault(emptyList())

    /** Creates and fsyncs every backup, staged result and manifest before touching originals. */
    fun prepare(root: File, replacements: Map<File, String>): File {
        val canonicalRoot = root.canonicalFile
        val base = File(canonicalRoot, DIRECTORY)
        if (!base.exists() && !base.mkdirs()) error("Unable to create the refactor recovery directory")
        if (pending(canonicalRoot).isNotEmpty()) error("An interrupted refactor must be resolved first")
        val transaction = File(base, UUID.randomUUID().toString())
        if (!transaction.mkdirs()) error("Unable to create the refactor transaction")
        try {
            val entries = ArrayList<Entry>()
            replacements.entries.forEachIndexed { index, (candidate, updated) ->
                val target = candidate.canonicalFile
                val prefix = canonicalRoot.path + File.separator
                require(target.path.startsWith(prefix) && target.isFile) { "A refactor target is outside the project" }
                val relative = target.path.removePrefix(prefix)
                val backupName = "backup_$index.bin"
                val stagedName = "staged_$index.bin"
                val backup = File(transaction, backupName)
                val staged = File(transaction, stagedName)
                copyDurable(target, backup)
                writeDurable(staged, updated.toByteArray(Charsets.UTF_8))
                entries += Entry(relative, backupName, stagedName, sha256(backup), sha256(staged))
            }
            val manifest = JSONObject()
                .put("version", VERSION)
                .put("state", "PREPARED")
                .put("createdAt", System.currentTimeMillis())
                .put("entries", JSONArray().also { array -> entries.forEach { entry ->
                    array.put(JSONObject()
                        .put("path", entry.relativePath)
                        .put("backup", entry.backupName)
                        .put("staged", entry.stagedName)
                        .put("originalHash", entry.originalHash)
                        .put("updatedHash", entry.updatedHash))
                } })
            writeDurable(File(transaction, "$MANIFEST.tmp"), manifest.toString().toByteArray(Charsets.UTF_8))
            moveReplace(File(transaction, "$MANIFEST.tmp"), File(transaction, MANIFEST))
            syncDirectory(transaction)
            return transaction
        } catch (error: Exception) {
            transaction.deleteRecursively()
            throw error
        }
    }

    /** Complete is repeatable: each target is verified by hash before being replaced. */
    fun complete(root: File, transaction: File) {
        val manifest = requireManifest(root, transaction)
        for (entry in manifest.entries) {
            val target = resolveTarget(root, entry.relativePath)
            val staged = transactionFile(transaction, entry.stagedName, "staged")
            val backup = transactionFile(transaction, entry.backupName, "backup")
            require(backup.isFile && sha256(backup) == entry.originalHash) { "Recovery backup is damaged: ${entry.relativePath}" }
            if (target.isFile) {
                val currentHash = sha256(target)
                if (currentHash == entry.updatedHash) continue
                require(currentHash == entry.originalHash) { "File changed outside PySpace after interruption: ${entry.relativePath}" }
            }
            require(staged.isFile && sha256(staged) == entry.updatedHash) { "Staged refactor data is missing: ${entry.relativePath}" }
            replaceWithCopy(staged, target)
        }
        writeState(transaction, "COMMITTED", manifest)
        transaction.deleteRecursively()
    }

    /** Rollback is repeatable and restores every original from its verified backup. */
    fun rollback(root: File, transaction: File) {
        val manifest = requireManifest(root, transaction)
        for (entry in manifest.entries.asReversed()) {
            val target = resolveTarget(root, entry.relativePath)
            val backup = transactionFile(transaction, entry.backupName, "backup")
            require(backup.isFile && sha256(backup) == entry.originalHash) { "Recovery backup is damaged: ${entry.relativePath}" }
            if (target.isFile) {
                val currentHash = sha256(target)
                if (currentHash == entry.originalHash) continue
                require(currentHash == entry.updatedHash) { "File changed outside PySpace after interruption: ${entry.relativePath}" }
            }
            replaceWithCopy(backup, target)
        }
        transaction.deleteRecursively()
    }

    private fun requireManifest(root: File, transaction: File): Manifest {
        val canonicalRoot = root.canonicalFile
        val base = File(canonicalRoot, DIRECTORY).canonicalFile
        val dir = transaction.canonicalFile
        require(dir.parentFile == base && dir.isDirectory) { "Invalid recovery transaction location" }
        return readManifest(dir) ?: error("The refactor recovery record is missing or damaged")
    }

    private fun readManifest(dir: File): Manifest? = runCatching {
        val json = JSONObject(File(dir, MANIFEST).readText(Charsets.UTF_8))
        require(json.optInt("version") == VERSION)
        val entriesJson = json.getJSONArray("entries")
        val entries = (0 until entriesJson.length()).map { index ->
            val item = entriesJson.getJSONObject(index)
            Entry(item.getString("path"), item.getString("backup"), item.getString("staged"), item.getString("originalHash"), item.getString("updatedHash"))
        }
        require(entries.isNotEmpty())
        Manifest(json.getString("state"), json.optLong("createdAt"), entries)
    }.getOrNull()

    private fun transactionFile(transaction: File, name: String, prefix: String): File {
        require(Regex("${prefix}_[0-9]+\\.bin").matches(name)) { "Invalid recovery artifact name" }
        val file = File(transaction, name).canonicalFile
        require(file.parentFile == transaction.canonicalFile) { "Recovery artifact escapes its transaction" }
        return file
    }

    private fun resolveTarget(root: File, relative: String): File {
        require(relative.isNotBlank() && !relative.startsWith("/") && relative.split('/').none { it == ".." })
        val canonicalRoot = root.canonicalFile
        val target = File(canonicalRoot, relative).canonicalFile
        require(target.path.startsWith(canonicalRoot.path + File.separator)) { "Recovery path escapes the project" }
        return target
    }

    private fun writeState(transaction: File, state: String, manifest: Manifest) {
        val json = JSONObject()
            .put("version", VERSION)
            .put("state", state)
            .put("createdAt", manifest.createdAt)
            .put("entries", JSONArray().also { array -> manifest.entries.forEach { entry ->
                array.put(JSONObject().put("path", entry.relativePath).put("backup", entry.backupName)
                    .put("staged", entry.stagedName).put("originalHash", entry.originalHash).put("updatedHash", entry.updatedHash))
            } })
        val temp = File(transaction, "$MANIFEST.tmp")
        writeDurable(temp, json.toString().toByteArray(Charsets.UTF_8))
        moveReplace(temp, File(transaction, MANIFEST))
        syncDirectory(transaction)
    }

    private fun replaceWithCopy(source: File, target: File) {
        val parent = target.parentFile ?: error("Invalid target path")
        if (!parent.exists() && !parent.mkdirs()) error("Unable to create ${parent.path}")
        val temp = File(parent, ".${target.name}.refactor-recovery-${UUID.randomUUID()}.tmp")
        try {
            copyDurable(source, temp)
            moveReplace(temp, target)
            syncDirectory(parent)
        } finally { temp.delete() }
    }

    private fun copyDurable(source: File, target: File) {
        FileInputStream(source).use { input -> FileOutputStream(target, false).use { output ->
            val buffer = ByteArray(64 * 1024)
            while (true) { val count = input.read(buffer); if (count < 0) break; output.write(buffer, 0, count) }
            output.fd.sync()
        } }
    }

    private fun writeDurable(target: File, bytes: ByteArray) {
        FileOutputStream(target, false).use { it.write(bytes); it.fd.sync() }
    }

    private fun moveReplace(source: File, target: File) {
        try {
            java.nio.file.Files.move(source.toPath(), target.toPath(), java.nio.file.StandardCopyOption.ATOMIC_MOVE, java.nio.file.StandardCopyOption.REPLACE_EXISTING)
        } catch (_: Exception) {
            java.nio.file.Files.move(source.toPath(), target.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING)
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(64 * 1024)
            while (true) { val count = input.read(buffer); if (count < 0) break; digest.update(buffer, 0, count) }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun syncDirectory(directory: File) { runCatching { FileOutputStream(File(directory, ".sync")).use { it.fd.sync() }; File(directory, ".sync").delete() } }
}
