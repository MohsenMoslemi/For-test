package com.codespace.ide.ide.editor

import com.codespace.ide.ide.DetectedFile
import com.codespace.ide.ide.detectFile
import com.codespace.ide.ide.readDetectedText
import com.codespace.ide.ide.codeintel.ProjectTransactionManager
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import kotlinx.coroutines.CancellationException
import com.codespace.ide.runtime.RuntimeDispatchers
import kotlinx.coroutines.withContext

/** A fully inspected document, created off the UI thread. */
data class LoadedEditorDocument(
    val file: File,
    val detected: DetectedFile,
    val text: String,
)

/** Filesystem boundary for editor documents. All methods are main-safe. */
interface EditorRepository {
    suspend fun load(file: File): LoadedEditorDocument
    suspend fun save(file: File, text: String): Result<Unit>
}

class FileEditorRepository(
    private val dispatchers: RuntimeDispatchers = RuntimeDispatchers.Default,
    private val projectRoot: File? = null,
) : EditorRepository {
    override suspend fun load(file: File): LoadedEditorDocument = withContext(dispatchers.io) {
        val detected = detectFile(file)
        val text = if (detected.viewableText) readDetectedText(file, detected) else ""
        LoadedEditorDocument(file, detected, text)
    }

    override suspend fun save(file: File, text: String): Result<Unit> = withContext(dispatchers.io) {
        try {
            ProjectTransactionManager.execute(projectRoot ?: (file.parentFile ?: file).canonicalFile, "SAVE", listOf(file)) {
            val parent = file.absoluteFile.parentFile
                ?: throw IllegalStateException("File has no parent directory")
            if (!parent.exists() && !parent.mkdirs()) {
                throw IllegalStateException("Unable to create parent directory")
            }
            // Write to a sibling temporary file first. The original document
            // remains intact if writing fails or the device runs out of space.
            val temp = File.createTempFile(".pyspace-${file.name.take(16)}-", ".tmp", parent)
            try {
                FileOutputStream(temp).use { stream ->
                    stream.write(text.toByteArray(Charsets.UTF_8))
                    stream.fd.sync()
                }
                // Preserve POSIX mode bits where the backing filesystem exposes them.
                try {
                    val permissions = Files.getPosixFilePermissions(file.toPath())
                    Files.setPosixFilePermissions(temp.toPath(), permissions)
                } catch (_: Exception) {
                    // Android shared/proot filesystems may not expose POSIX attributes.
                }
                try {
                    Files.move(
                        temp.toPath(), file.toPath(),
                        StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE,
                    )
                } catch (_: Exception) {
                    // Some filesystems do not support ATOMIC_MOVE. A same-
                    // directory rename is still preferable to truncating the
                    // destination before the new contents are ready.
                    if (!temp.renameTo(file)) {
                        Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING)
                    }
                }
            } finally {
                if (temp.exists()) temp.delete()
            }
            Unit
            }
            Result.success(Unit)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            Result.failure(error)
        }
    }
}
