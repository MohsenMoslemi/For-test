package com.codespace.ide.ide.shell

import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import java.io.File
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt
import kotlinx.coroutines.launch
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.material3.Divider
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import com.codespace.ide.TerminalScreen


import androidx.compose.foundation.layout.BoxScope
import com.codespace.ide.ide.codeintel.PythonLspController
import com.codespace.ide.ide.codeintel.PythonQuickFixes
import com.codespace.ide.ide.editor.EditorSession
import com.codespace.ide.ide.editor.IdeEditor
import com.codespace.ide.UbuntuTerminalApplication
import com.codespace.ide.ide.CrashLog
import com.codespace.ide.ide.HomeTab
import com.codespace.ide.ide.IdeScreen
import com.codespace.ide.ide.PanelTab
import com.codespace.ide.ide.learn.Lesson
import com.codespace.ide.ide.projects.ProjectAutoRecoveryManager
import com.codespace.ide.ide.projects.ProjectsViewModel
import com.codespace.ide.ide.settings.SettingsViewModel
import com.codespace.ide.ide.theme.IdeTheme
import com.codespace.ide.ide.ui.DrawerShift

// Dialogs and overlays of the IDE shell, extracted from IdeRoot. They are extension composables on
// IdeShell so they read the same state/logic members the old inline code did.

@Composable
internal fun IdeShell.CrashReportDialog() {
    // ---- Last crash report: written by CrashLog (installed in UbuntuTerminalApplication.onCreate,
    // before Koin - this remember{} is NOT the installation point) when the app died, shown once on the next start ----
    var lastCrash by remember { mutableStateOf(CrashLog.read(context)) }
    val crashText = lastCrash
    if (crashText != null) {
        IdeAlertDialog(
            onDismissRequest = { CrashLog.clear(context); lastCrash = null },
            title = { Text("The app closed unexpectedly last time") },
            text = {
                androidx.compose.foundation.layout.Column(
                    Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())
                ) {
                    Text(
                        crashText, fontSize = 10.sp,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        color = Color(IdeTheme.DIM)
                    )
                }
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    try {
                        val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("crash", crashText))
                        Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                    } catch (_: Exception) {
                    }
                    CrashLog.clear(context)
                    lastCrash = null
                }) { Text("Copy and close") }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { CrashLog.clear(context); lastCrash = null }) { Text("Close") }
            }
        )
    }
}

@Composable
internal fun IdeShell.RunConflictDialog() {
    val pc = pendingConflict
    if (pc != null) {
        IdeAlertDialog(
            onDismissRequest = { pendingConflict = null },
            title = { Text("Already running") },
            text = {
                Text(
                    pc.other.title + " is already running in the " + pc.other.source + " (since " +
                        java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date(pc.other.startedAt)) +
                        "). Stop it and run here, or start another copy?"
                )
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    pendingConflict = null
                    stopRun(pc.other)
                    ideScope.launch {
                        kotlinx.coroutines.delay(900)
                        runInConsole(pc.project, pc.file, pc.text, pc.forceGui, ignoreConflict = true)
                    }
                }) { Text("Stop it and run here") }
            },
            dismissButton = {
                Row {
                    androidx.compose.material3.TextButton(onClick = { pendingConflict = null }) { Text("Cancel") }
                    androidx.compose.material3.TextButton(onClick = {
                        pendingConflict = null
                        runInConsole(pc.project, pc.file, pc.text, pc.forceGui, ignoreConflict = true)
                    }) { Text("Run anyway") }
                }
            }
        )
    }
}

@Composable
internal fun IdeShell.BrowserChoiceDialog() {
    val runtimeUiState by runtimeUiViewModel.state.collectAsState()
    val openChoice = runtimeUiState.pendingBrowserChoiceUrl
    val rememberChoice = runtimeUiState.rememberBrowserChoice
    val oc = openChoice
    if (oc != null) {
        IdeAlertDialog(
            onDismissRequest = { runtimeUiViewModel.dismissBrowserChoice() },
            title = { Text("Open web page") },
            text = {
                Column {
                    Text(oc, fontSize = 13.sp, color = Color(IdeTheme.DIM))
                    Spacer(Modifier.height(10.dp))
                    Row(
                        Modifier.clickable { runtimeUiViewModel.setRememberBrowserChoice(!rememberChoice) },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        androidx.compose.material3.Checkbox(checked = rememberChoice, onCheckedChange = { runtimeUiViewModel.setRememberBrowserChoice(it) })
                        Text("Remember my choice (change it in Settings)", fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = {
                    if (rememberChoice) prefs.webOpenMode = "ide"
                    runtimeUiViewModel.dismissBrowserChoice()
                    openInIde(oc)
                }) { Text("IDE browser") }
            },
            dismissButton = {
                Row {
                    androidx.compose.material3.TextButton(onClick = { runtimeUiViewModel.dismissBrowserChoice() }) { Text("Cancel") }
                    androidx.compose.material3.TextButton(onClick = {
                        if (rememberChoice) prefs.webOpenMode = "phone"
                        runtimeUiViewModel.dismissBrowserChoice()
                        openExternalUrl(oc)
                    }) { Text("Phone browser") }
                }
            }
        )
    }
}

@Composable
internal fun IdeShell.MissingProjectDialog(projectsViewModel: ProjectsViewModel, autoRecoveryManager: com.codespace.ide.ide.projects.ProjectAutoRecoveryManager) {
    LaunchedEffect(missingProject?.dir?.absolutePath) {
        val project = missingProject ?: run { recoveryAvailable = false; return@LaunchedEffect }
        recoveryAvailable = withContext(Dispatchers.IO) { autoRecoveryManager.hasSnapshot(project) }
    }

    missingProject?.let { project ->
        IdeAlertDialog(
            onDismissRequest = { /* A vanished project must be resolved explicitly. */ },
            title = { Text("Project is no longer available") },
            text = {
                Column {
                    Text("The project '${project.name}' appears to have been deleted or moved while it was open.")
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (recoveryAvailable) "An automatic recovery copy is available."
                        else "No completed automatic recovery copy is available yet.",
                        color = Color(IdeTheme.DIM), fontSize = 12.sp
                    )
                    recoveryError?.let {
                        Text(it, color = Color(IdeTheme.ERROR), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                    }
                    if (recoveryBusy) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 12.dp)) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Text("Restoring project…", modifier = Modifier.padding(start = 10.dp), fontSize = 12.sp)
                        }
                    }
                }
            },
            confirmButton = {
                androidx.compose.material3.TextButton(
                    enabled = recoveryAvailable && !recoveryBusy,
                    onClick = {
                        if (recoveryBusy) return@TextButton
                        recoveryBusy = true
                        recoveryError = null
                        ideScope.launch {
                            try {
                                val restored = withContext(Dispatchers.IO) {
                                    autoRecoveryManager.restore(project, workspace)
                                }
                                clearDeletedProjectState(project)
                                leaveProject(persistSession = false)
                                missingProject = null
                                recoveryBusy = false
                                homeTab = HomeTab.Projects
                                projectsViewModel.refresh()
                                Toast.makeText(context, "Project restored: ${restored.name}", Toast.LENGTH_LONG).show()
                            } catch (cancelled: CancellationException) {
                                recoveryBusy = false
                                throw cancelled
                            } catch (error: Exception) {
                                recoveryBusy = false
                                recoveryError = error.message ?: "Could not restore the project."
                            }
                        }
                    }
                ) { Text("Restore Project") }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(
                    enabled = !recoveryBusy,
                    onClick = {
                        clearDeletedProjectState(project)
                        leaveProject(persistSession = false)
                        missingProject = null
                        recoveryError = null
                        homeTab = HomeTab.Projects
                        projectsViewModel.refresh()
                    }
                ) { Text("Exit to Projects") }
            }
        )
    }
}

@Composable
internal fun IdeShell.ImportSelectionDialog(editorSession: EditorSession?) {
    pendingImportSelection?.let { pending ->
        IdeAlertDialog(
            onDismissRequest = { pendingImportSelection = null },
            containerColor = Color(IdeTheme.PANEL),
            title = {
                Column {
                    Text("Choose an import", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.Bold)
                    Text(
                        "Select which library provides '${pending.symbol}'.",
                        color = Color(IdeTheme.DIM), fontSize = 12.sp
                    )
                }
            },
            text = {
                androidx.compose.foundation.lazy.LazyColumn(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 360.dp),
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    items(pending.candidates, key = { it.autoImportStatement.orEmpty() }) { candidate ->
                        androidx.compose.material3.Surface(
                            modifier = Modifier.fillMaxWidth().clickable {
                                val tab = editorSession?.tabs?.firstOrNull {
                                    runCatching { it.file.canonicalPath == pending.filePath }.getOrDefault(false)
                                }
                                if (tab == null) {
                                    Toast.makeText(context, "The file is no longer open.", Toast.LENGTH_SHORT).show()
                                } else if (tab.text != pending.sourceSnapshot) {
                                    Toast.makeText(context, "Code changed. Run Import again to refresh suggestions.", Toast.LENGTH_LONG).show()
                                } else {
                                    val statement = candidate.autoImportStatement.orEmpty()
                                    val fix = PythonQuickFixes.applyImport(tab.text, statement)
                                    if (fix == null) {
                                        Toast.makeText(context, "This import is already present or cannot be inserted.", Toast.LENGTH_SHORT).show()
                                    } else {
                                        tab.applyEdit(fix.text, fix.selection, fix.selection)
                                        Toast.makeText(context, "Imported: $statement", Toast.LENGTH_SHORT).show()
                                    }
                                }
                                pendingImportSelection = null
                            },
                            color = Color(IdeTheme.BG),
                            shape = RoundedCornerShape(12.dp),
                            tonalElevation = 1.dp
                        ) {
                            Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp)) {
                                Text(
                                    candidate.autoImportSource ?: "Unknown package",
                                    color = Color(IdeTheme.ACCENT), fontSize = 11.sp, fontWeight = FontWeight.Bold
                                )
                                Spacer(Modifier.height(3.dp))
                                Text(
                                    candidate.autoImportStatement.orEmpty(),
                                    color = Color(IdeTheme.TEXT), fontSize = 13.sp,
                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = { pendingImportSelection = null }) {
                    Text("Cancel", color = Color(IdeTheme.DIM))
                }
            }
        )
    }
}

@Composable
internal fun IdeShell.DisplayOverlay() {
    val runtimeUiState by runtimeUiViewModel.state.collectAsState()
    val displayOpen = runtimeUiState.displayOpen
    val frameMode = runtimeUiState.frameMode
    val frameProject = runtimeUiState.frameProject
    val inEditor = screen is IdeScreen.Editor
    // Embedded display viewer: fullscreen overlay above everything,
    // OUTSIDE the sliding world so the drawer never shifts it.
    OverlaySlideUp(visible = inEditor && displayOpen) {
        Box(
            Modifier.fillMaxSize()
            .background(Color(IdeTheme.BG))
        ) {
            if (frameMode) {
                FrameViewer(
                    display = frameDisplay,
                    title = console.title,
                    saveDir = frameProject?.let { File(it.dir, "captures") },
                    onSaved = { frameProject?.let { p -> try { sessionFor(p).refreshTree() } catch (_: Exception) { } } },
                    running = console.running,
                    onMinimize = { runtimeUiViewModel.setDisplayOpen(false) },
                    onStop = {
                        stopConsole()
                        runtimeUiViewModel.setDisplayOpen(false)
                    }
                )
            } else DisplayViewer(
                display = display,
                title = console.title,
                saveDir = frameProject?.let { File(it.dir, "captures") },
                onSaved = { frameProject?.let { p -> try { sessionFor(p).refreshTree() } catch (_: Exception) { } } },
                running = console.running,
                // Hide: the app and the display keep running; the editor
                // top bar shows a live "Display" chip to come back.
                onMinimize = {
                    runtimeUiViewModel.setDisplayUserHidden(true)
                    runtimeUiViewModel.setDisplayOpen(false)
                },
                // Stop: same as the editor's Stop (ends the run AND shuts
                // the display down), then leave the viewer.
                onStop = {
                    stopConsole()
                    runtimeUiViewModel.setDisplayOpen(false)
                }
            )
        }
    }
}

@Composable
internal fun IdeShell.BrowserOverlay() {
    val browserOpen = runtimeUiViewModel.state.collectAsState().value.browserOpen
    // Built-in browser (above everything, like the display viewer).
    OverlaySlideUp(visible = browserOpen) {
        Box(Modifier.fillMaxSize().background(Color(IdeTheme.BG))) {
            BrowserScreen(
                state = browser,
                onClose = { runtimeUiViewModel.setBrowserOpen(false) },
                onOpenExternal = { openExternalUrl(it) }
            )
        }
    }
}

@Composable
internal fun IdeShell.SettingsOverlayHost(settingsViewModel: SettingsViewModel, projectsViewModel: ProjectsViewModel) {
    // Settings hub overlay (above everything, outside the sliding world).
    OverlaySlideUp(visible = settingsOpen) {
        Box(
            Modifier.fillMaxSize()
            .background(Color(IdeTheme.BG))
        ) {
            SettingsOverlay(
                settingsViewModel = settingsViewModel,
                projectsViewModel = projectsViewModel,
                ubuntu = ubuntu,
                proot = proot,
                packageManagerRepository = packageManagerRepository,
                bridge = bridge,
                display = display,
                onClose = { settingsOpen = false }
            )
        }
    }
}

@Composable
internal fun IdeShell.FileTreePanel(drawerShift: DrawerShift, drawerCommitPx: Float) {
    val inEditor = screen is IdeScreen.Editor
    val editorSession = (screen as? IdeScreen.Editor)?.let { sessionFor(it.project) }
    // File-tree panel (unshifted, topmost): parked off-screen left
    // when closed, revealed as the world slides right with the finger.
    if (inEditor) {
        Box(
            Modifier
            .fillMaxHeight()
            .width(DrawerShift.WIDTH_DP.dp)
            .offset {
                IntOffset(
                    (drawerShift.px.value - drawerShift.widthPx).roundToInt(), 0
                )
            }
            .background(Color(IdeTheme.PANEL))
            .drawerDrag(drawerShift, ideScope, false, drawerCommitPx)
        ) {
            val es = editorSession
            if (es != null) {
                val editor = editorFor(es.project)
                FileTreeDrawer(
                    editorViewModel = editor,
                    explorerViewModel = checkNotNull(fileExplorerViewModels[es.project.dir.absolutePath]) { "File explorer ViewModel was not initialized for the active project" },
                    codeIntelligenceViewModel = checkNotNull(codeIntelligenceViewModels[es.project.dir.absolutePath]) { "Code intelligence ViewModel was not initialized for the active project" },
                    bridge = bridge,
                    proot = proot,
                    onOpenFile = { f ->
                        editor.openFile(f)
                        ideScope.launch { drawerShift.close() }
                    },
                    onJumpToLine = { f, ln ->
                        editor.openFile(f)
                        es.jumpRequest = f.absolutePath to ln
                        ideScope.launch { drawerShift.close() }
                    }
                )
            }
        }
    }
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
internal fun IdeShell.ScreenHost(
    drawerShift: DrawerShift,
    pythonLspController: PythonLspController?,
    settingsViewModel: SettingsViewModel,
) {
    val settingsState by settingsViewModel.state.collectAsState()
    val browserOpen = runtimeUiViewModel.state.collectAsState().value.browserOpen
    val hubVersion by hub.version.collectAsState()
    val terminalRuns = runOrchestrator.running().filter { it.source != "Console" }
    when (val s = screen) {
        is IdeScreen.Home -> IdeHome(
            workspace = workspace,
            proot = proot,
            ubuntu = ubuntu,
            projectRepository = projectRepository,
            prefs = prefs,
            bridge = bridge,
            display = display,
            onOpenSettings = { settingsOpen = true },
            tab = homeTab,
            onTab = { homeTab = it },
            onOpenProject = { screen = IdeScreen.Editor(it) },
            onProjectGone = { clearDeletedProjectStateForDir(it) },
            onOpenLesson = { lesson ->
                // Lesson project creation and example-file writes touch
                // the Ubuntu-backed workspace; keep them off Compose Main.
                ideScope.launch {
                    try {
                        val (lp, lessonFile) = withContext(Dispatchers.IO) {
                            val project = ensureLessonsProject(workspace)
                            val file = File(project.dir, lesson.fileName)
                            if (!file.isFile) file.writeText(lesson.code)
                            project to file
                        }
                        withContext(Dispatchers.Main) {
                            editorFor(lp).openFile(lessonFile)
                            screen = IdeScreen.Editor(lp)
                        }
                    } catch (cancelled: CancellationException) {
                        throw cancelled
                    } catch (_: Exception) {
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "Could not open lesson", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        )
        is IdeScreen.Editor -> {
            val editor = editorFor(s.project)
            val es = editor.session
            IdeEditor(
                editorViewModel = editor,
                prefs = prefs,
                settings = settingsState,
                onCodeFontSizeChange = settingsViewModel::setCodeFontSize,
                bridge = bridge,
                proot = proot,
                pythonLspController = pythonLspController,
                notebookRepository = notebookRepository,
                onRun = { t ->
                    val sourceSnapshot = t.text
                    val startRun = { runInConsole(es.project, t.file, sourceSnapshot) }
                    if (t.dirty) {
                        editor.save(t) { saved ->
                            if (saved) startRun() else Toast.makeText(context, "Could not save file", Toast.LENGTH_SHORT).show()
                        }
                    } else startRun()
                },
                onRunWithDisplay = { t ->
                    val sourceSnapshot = t.text
                    val startRun = { runInConsole(es.project, t.file, sourceSnapshot, forceGui = true) }
                    if (t.dirty) {
                        editor.save(t) { saved ->
                            if (saved) startRun() else Toast.makeText(context, "Could not save file", Toast.LENGTH_SHORT).show()
                        }
                    } else startRun()
                },
                onOpenSettings = { settingsOpen = true },
                drawerShift = drawerShift,
                isRunActive = (consoleLive && console.running) || terminalRuns.isNotEmpty(),
                onStopRun = { stopAllRuns() },
                displayHidden = !displayOpen && (
                    (consoleLive && console.running &&
                        (consoleCmd?.contains("DISPLAY=:1") == true ||
                            consoleCmd?.contains("IDE_VIEW_DIR=") == true)) ||
                        (displayOwner?.let { runOrchestrator.get(it)?.running } == true)
                    ),
                onShowDisplay = { runtimeUiViewModel.setDisplayOpen(true) },
                projectRunning = (consoleLive && console.running) || terminalRuns.isNotEmpty(),
                onExitProject = { leaveProject() },
                editorActive = !settingsOpen && !browserOpen && !displayOpen,
                onBack = { leaveProject() }
            )
        }
    }
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
internal fun BoxScope.IdeBottomPanel(
    shell: IdeShell,
    projectsViewModel: ProjectsViewModel,
    pythonLspController: PythonLspController?,
    problemErrorCount: Int,
    problemWarningCount: Int,
) {
    with(shell) {
    val projectsState by projectsViewModel.state.collectAsState()
    val runtimeUiState by runtimeUiViewModel.state.collectAsState()
    val webStatic = runtimeUiState.webServerGuess
    val webLiveUrl = runtimeUiState.webLiveUrl
    val ideKeyboard = LocalSoftwareKeyboardController.current
    val ideFocus = LocalFocusManager.current
    val inEditor = screen is IdeScreen.Editor
    val activeProject = (screen as? IdeScreen.Editor)?.project
    val editorSession = (screen as? IdeScreen.Editor)?.let { sessionFor(it.project) }
    val curProject = activeProject
    val curVenv = curProject?.let { projectVenvGuestPath(it.dir) }
    val curProjectKey = curProject?.dir?.absolutePath
    val projectVenvBusy = curProjectKey != null && projectsState.venvBuildingProjects.contains(curProjectKey)
    val syntaxDiagnostics = pythonLspController?.results?.collectAsState()?.value ?: emptyMap()
    val lspDiagnostics = pythonLspController?.lspResults?.collectAsState()?.value ?: emptyMap()
    val hubVersion by hub.version.collectAsState()
    val terminalRuns = runOrchestrator.running().filter { it.source != "Console" }
        // Sessions dock: ALWAYS composed while in a project (never
        // display:none) and ALWAYS measured at the real panel size, in
        // both states: the closed dock is parked off-screen by the offset
        // alone. A collapsed (1dp) dock used to measure ~2 rows, so the
        // shell started life in a 2-row terminal and the first real open
        // showed a mangled redrawn prompt. Placed in both states, so text
        // fields never trip bring-into-view, and ✕ only HIDES: sessions
        // die solely on project leave. The visible icon toolbar below is
        // a separate chrome shown while closed (never with the keyboard).
        val imeVisible = WindowInsets.isImeVisible
        if (inEditor) {
            val hidden = !panelOpen
            Column(
                Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .fillMaxHeight(panelFrac)
                .offset { IntOffset(0, if (!hidden) 0 else 100000) }
                .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                .background(Color(IdeTheme.PANEL))
            ) {
                if (!hidden) {
                    PanelChrome(
                        tab = panelTab,
                        problemErrorCount = problemErrorCount,
                        problemWarningCount = problemWarningCount,
                        maximized = panelFrac >= 0.84f,
                        compact = false,
                        onTab = { panelTab = it },
                        onToggleMax = {
                            panelFrac = if (panelFrac >= 0.84f) 0.38f else 0.85f
                        },
                        onClose = {
                            // Hide only: sessions keep running underneath.
                            panelOpen = false
                            try {
                                ideFocus.clearFocus(force = true)
                            } catch (_: Exception) {
                            }
                            try {
                                ideKeyboard?.hide()
                            } catch (_: Exception) {
                            }
                        },
                        onDrag = { dyPx ->
                            panelFrac = (panelFrac - dyPx / 2000f).coerceIn(0.22f, 0.85f)
                        }
                    )
                    Divider(color = Color(IdeTheme.LINE))
                }
                Box(Modifier.fillMaxSize().weight(1f)) {
                    // L0: the interactive shell (always).
                    Column(Modifier.fillMaxSize()) {
                        // No silent plain shell: when the project venv is
                        // missing, say so and offer a one-tap build.
                        if (!hidden && panelTab == PanelTab.Terminal && curProject != null &&
                            (projectVenvBusy || venvBusyBuild || !venvPythonReady(curProject.dir))
                        ) {
                            VenvBanner(
                                venvName = projectVenvName(curProject.dir),
                                busy = venvBusyBuild || projectVenvBusy,
                                msg = venvBuildMsg ?: projectsState.mutationError,
                                onBuild = { buildProjVenv() }
                            )
                        }
                        if (!hidden && panelTab == PanelTab.Terminal) {
                            RunStrip(
                                runs = terminalRuns,
                                displayOpen = displayOpen,
                                onBrowser = ::openServerUrl,
                                onDisplay = { runtimeUiViewModel.setDisplayOpen(true) },
                                onStop = { stopRun(it) }
                            )
                        }
                        TerminalTabs(
                            root = proot,
                            bridge = bridge,
                            autoActivate = curVenv,
                            workDir = curProject?.let { guestProjectRoot(it) },
                            visible = !hidden && panelTab == PanelTab.Terminal,
                            modifier = Modifier.fillMaxSize().weight(1f)
                        )
                    }
                    // L1: the console run — always full size (so its measured
                    // geometry is identical whether or not its tab is
                    // showing), simply covered by the offset while
                    // another tab is active or the panel is closed.
                    val consoleVisible = !hidden && panelTab == PanelTab.Console
                    val webUrl = if (consoleLive) {
                        webLiveUrl ?: consoleRun?.webUrl ?: webStatic?.takeIf { it.launchable }?.url
                    } else {
                        null
                    }
                    val webLabel = if (consoleLive && webUrl == null) {
                        webStatic?.let { "${it.framework} project detected — waiting for server URL…" }
                    } else {
                        null
                    }
                    Box(
                        Modifier
                        .fillMaxSize()
                        .offset { IntOffset(0, if (consoleVisible) 0 else 100000) }
                    ) {
                        if (consoleCmd != null && consoleLive) {
                            Column(
                                Modifier.fillMaxSize().background(Color(IdeTheme.PANEL))
                            ) {
                                if (consoleVisible) {
                                    ConsoleHeader(
                                        state = console,
                                        canRerun = true,
                                        onRerun = { rerunConsole() },
                                        onStop = { stopConsole() },
                                        serverUrl = webUrl,
                                        serverLabel = webLabel,
                                        onOpenServer = ::openServerUrl
                                    )
                                    Divider(color = Color(IdeTheme.LINE))
                                }
                                key(consoleRunId) {
                                    TerminalScreen(
                                        root = proot,
                                        bridge = null,
                                        showTopBar = false,
                                        runCommand = consoleCmd,
                                        controller = consoleCtl,
                                        exitHint = "press Rerun",
                                        showExtraKeys = false,
                                        visible = consoleVisible,
                                        showManualKeyboardButton = false,
                                        modifier = Modifier.fillMaxSize().weight(1f)
                                    )
                                }
                            }
                        }
                    }
                    // L2: the remaining tabs cover everything beneath.
                    if (!hidden && panelTab != PanelTab.Terminal && panelTab != PanelTab.Console) {
                        when (panelTab) {
                            PanelTab.Console -> {}
                            PanelTab.Problems -> ProblemsView(
                                session = editorSession,
                                syntaxDiagnostics = syntaxDiagnostics,
                                lspDiagnosticFiles = lspDiagnostics.keys,
                                onOpenFile = { f, line -> editorSession?.let { es ->
                                    es.jumpRequest = f.absolutePath to line
                                    editorFor(es.project).openFile(f)
                                } },
                                onFix = { file, diagnostic ->
                                    val es = editorSession
                                    val tab = es?.tabs?.firstOrNull {
                                        it.file.canonicalFile == file.canonicalFile
                                    }
                                    if (tab == null) {
                                        Toast.makeText(context, "Open the file before applying this fix.", Toast.LENGTH_SHORT).show()
                                    } else {
                                        val fix = PythonQuickFixes.apply(tab.text, diagnostic)
                                        if (fix == null || fix.text == tab.text) {
                                            Toast.makeText(context, "Could not apply this fix: the diagnostic may be outdated or the source has changed.", Toast.LENGTH_LONG).show()
                                        } else {
                                            // All quick fixes are normal editor edits: undo/redo,
                                            // dirty state and the existing save pipeline stay intact.
                                            tab.applyEdit(fix.text, fix.selection, fix.selection)
                                            Toast.makeText(context, "Quick fix applied. You can Undo to revert it.", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                onImport = { file, diagnostic ->
                                    val tab = editorSession?.tabs?.firstOrNull {
                                        runCatching { it.file.canonicalFile == file.canonicalFile }.getOrDefault(false)
                                    }
                                    if (tab == null) {
                                        Toast.makeText(context, "Open the file before importing.", Toast.LENGTH_SHORT).show()
                                    } else {
                                        val candidates = PythonQuickFixes.importSuggestions(
                                            tab.text, diagnostic, pythonLspController?.installedPackagesSnapshot()
                                        )
                                        if (candidates.isEmpty()) {
                                            Toast.makeText(context, "No safe import candidate found for this name.", Toast.LENGTH_LONG).show()
                                        } else {
                                            val symbol = PythonQuickFixes.undefinedName(diagnostic).orEmpty()
                                            pendingImportSelection = PendingImportSelection(
                                                filePath = runCatching { file.canonicalPath }.getOrDefault(file.absolutePath),
                                                sourceSnapshot = tab.text,
                                                symbol = symbol,
                                                candidates = candidates
                                            )
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxSize().background(Color(IdeTheme.PANEL))
                            )
                            PanelTab.Terminal -> {}
                            PanelTab.Debug -> DebugView(
                                controller = editorSession?.project?.let { debugControllerFor(it) },
                                activeFile = editorSession?.active?.file,
                                modifier = Modifier.fillMaxSize().background(Color(IdeTheme.PANEL))
                            )
                            PanelTab.Test -> TestView(
                                proot = proot,
                                project = editorSession?.project,
                                modifier = Modifier.fillMaxSize().background(Color(IdeTheme.PANEL)),
                                onSaveBeforeRun = { complete ->
                                    val activeProject = editorSession?.project
                                    val vm = activeProject?.let { editors[it.dir.absolutePath] }
                                    if (vm == null) complete(true, null)
                                    else vm.saveDirtyDocuments { success, _, error -> complete(success, error) }
                                },
                                onOpenLocation = { path, line ->
                                    val session = editorSession
                                    val project = session?.project
                                    if (project != null) {
                                        val candidate = File(path)
                                        val target = if (candidate.isAbsolute) candidate else File(project.dir, path)
                                        if (target.exists()) session?.let { es ->
                                            es.jumpRequest = target.absolutePath to line
                                            editorFor(project).openFile(target)
                                        }
                                    }
                                }
                            )
                            PanelTab.Camera -> CameraPanel(
                                cam = phoneCam,
                                hasProject = editorSession?.project != null,
                                onStartRequest = { f -> phoneCam.startFromUi(f, camPermission) },
                                onStop = { phoneCam.stopRun("Stopped from the Camera tab.") },
                                onOpenSettings = { openCamSettings() },
                                modifier = Modifier.fillMaxSize().background(Color(IdeTheme.PANEL))
                            )
                        }
                    } else if (!hidden && panelTab == PanelTab.Console &&
                        (consoleCmd == null || !consoleLive)
                    ) {
                        Column(
                            Modifier.fillMaxSize().background(Color(IdeTheme.PANEL))
                            .clickable(
                                indication = null,
                                interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
                            ) { }
                            .padding(20.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("◈", color = Color(IdeTheme.ACCENT), fontSize = 32.sp)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                if (consoleCmd == null) {
                                    "No run yet — open a file and press ▶."
                                } else {
                                    "Run ended — press ▶ Rerun for a fresh run."
                                },
                                color = Color(IdeTheme.DIM), fontSize = 13.sp
                            )
                            if (consoleCmd != null) {
                                Spacer(Modifier.height(10.dp))
                                TextButton(onClick = { rerunConsole() }) {
                                    Text(
                                        "▶ Rerun", color = Color(IdeTheme.ACCENT),
                                        fontSize = 14.sp, fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
            // Visible icon toolbar while closed (never with the keyboard).
            if (hidden && !imeVisible) {
                Column(
                    Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .wrapContentHeight()
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                    .background(Color(IdeTheme.PANEL))
                ) {
                    PanelChrome(
                        tab = panelTab,
                        problemErrorCount = problemErrorCount,
                        problemWarningCount = problemWarningCount,
                        maximized = false,
                        compact = true,
                        onTab = {
                            panelTab = it
                            panelOpen = true
                        },
                        onToggleMax = { },
                        onClose = { },
                        onDrag = { }
                    )
                }
            }
        }
}
}
