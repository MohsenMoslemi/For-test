package com.codespace.ide.ide.editor

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.platform.TextToolbar
import androidx.compose.ui.platform.TextToolbarStatus
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.window.PopupProperties
import com.codespace.ide.ide.theme.IdeTheme

/** TextToolbar bridge used by BasicTextField; Android's contextual toolbar is never shown. */
internal class EditorSelectionToolbarState : TextToolbar {
    var visible by mutableStateOf(false)
        private set
    var anchor by mutableStateOf(Rect.Zero)
        private set
    var copyAction by mutableStateOf<(() -> Unit)?>(null)
        private set
    var cutAction by mutableStateOf<(() -> Unit)?>(null)
        private set
    var pasteAction by mutableStateOf<(() -> Unit)?>(null)
        private set
    var selectAllAction by mutableStateOf<(() -> Unit)?>(null)
        private set
    var refactorAction by mutableStateOf<(() -> Unit)?>(null)
    var refactorLabel by mutableStateOf("Refactor symbol")
    var moreExpanded by mutableStateOf(false)

    override val status: TextToolbarStatus
        get() = if (visible) TextToolbarStatus.Shown else TextToolbarStatus.Hidden

    override fun showMenu(
        rect: Rect,
        onCopyRequested: (() -> Unit)?,
        onPasteRequested: (() -> Unit)?,
        onCutRequested: (() -> Unit)?,
        onSelectAllRequested: (() -> Unit)?
    ) {
        anchor = rect
        copyAction = onCopyRequested
        pasteAction = onPasteRequested
        cutAction = onCutRequested
        selectAllAction = onSelectAllRequested
        // A newly reported selection starts with a closed overflow menu.
        moreExpanded = false
        visible = true
    }

    override fun hide() {
        visible = false
        moreExpanded = false
    }
}

@Composable
internal fun EditorSelectionToolbarOverlay(state: EditorSelectionToolbarState) {
    if (!state.visible) return
    val shape = RoundedCornerShape(10.dp)
    val accent = Color(IdeTheme.ACCENT)
    val surface = Color(IdeTheme.CARD)
    val actions = listOfNotNull(
        state.copyAction?.let { Triple("Copy", it, false) },
        state.cutAction?.let { Triple("Cut", it, false) },
        state.pasteAction?.let { Triple("Paste", it, false) }
    )
    if (actions.isEmpty() && state.selectAllAction == null && state.refactorAction == null) return
    Popup(
        popupPositionProvider = EditorToolbarPositionProvider(state.anchor),
        onDismissRequest = { state.hide() },
        // Keep this popup non-focusable. It is hosted beside BasicTextField and
        // must never take input focus away from the editor/IME.
        properties = PopupProperties(focusable = false, clippingEnabled = true)
    ) {
        AnimatedVisibility(
            visible = state.visible,
            enter = fadeIn() + scaleIn(initialScale = 0.94f),
            exit = fadeOut() + scaleOut(targetScale = 0.96f)
        ) {
            Column(
                horizontalAlignment = Alignment.End,
                modifier = Modifier
                    .background(surface, shape)
                    .border(1.dp, accent.copy(alpha = 0.42f), shape)
                    .padding(horizontal = 4.dp, vertical = 3.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                actions.forEach { (label, action, emphasized) ->
                    Text(
                        text = label,
                        color = if (emphasized) accent else Color(IdeTheme.TEXT),
                        modifier = Modifier
                            .clickable {
                                state.hide()
                                action()
                            }
                            .padding(horizontal = 7.dp, vertical = 6.dp),
                        maxLines = 1,
                        fontSize = 12.sp,
                        lineHeight = 14.sp
                    )
                }

                // This is deliberately an in-popup menu, not Material3
                // DropdownMenu. DropdownMenu creates a second focusable
                // Android Popup; that steals focus from BasicTextField, makes
                // the IME restart, and causes the selection toolbar to blink.
                if (state.refactorAction != null) {
                    Text(
                        text = "⋮",
                        color = Color(IdeTheme.TEXT),
                        fontSize = 18.sp,
                        modifier = Modifier
                            .clickable { state.moreExpanded = !state.moreExpanded }
                            .padding(horizontal = 9.dp, vertical = 4.dp)
                    )
                }

                if (state.refactorAction != null && state.selectAllAction != null) {
                    Box(
                        Modifier
                            .padding(horizontal = 3.dp)
                            .size(width = 1.dp, height = 19.dp)
                            .background(Color(IdeTheme.DIM).copy(alpha = 0.55f))
                    )
                }

                state.selectAllAction?.let { action ->
                    Text(
                        text = "Select all",
                        color = accent,
                        modifier = Modifier
                            .clickable {
                                state.hide()
                                action()
                            }
                            .padding(horizontal = 9.dp, vertical = 6.dp),
                        maxLines = 1,
                        fontSize = 12.sp,
                        lineHeight = 14.sp
                    )
                }
                }
                if (state.moreExpanded && state.refactorAction != null) {
                    Column(
                        modifier = Modifier
                            .width(164.dp)
                            .shadow(8.dp, RoundedCornerShape(9.dp))
                            .background(surface, RoundedCornerShape(9.dp))
                            .border(1.dp, accent.copy(alpha = 0.35f), RoundedCornerShape(9.dp))
                            .padding(vertical = 4.dp)
                    ) {
                        Text(
                            text = state.refactorLabel,
                            color = Color(IdeTheme.TEXT),
                            fontSize = 13.sp,
                            maxLines = 1,
                            modifier = Modifier
                                .clickable {
                                    val action = state.refactorAction
                                    state.hide()
                                    action?.invoke()
                                }
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        )
                    }
                }
            }
        }
    }
}

private class EditorToolbarPositionProvider(private val anchor: Rect) : PopupPositionProvider {
    override fun calculatePosition(
        anchorBounds: IntRect,
        windowSize: IntSize,
        layoutDirection: LayoutDirection,
        popupContentSize: IntSize
    ): IntOffset {
        val centerX = anchor.center.x.toInt().takeIf { anchor != Rect.Zero }
            ?: (anchorBounds.left + anchorBounds.right) / 2
        val anchorTop = anchor.top.toInt().takeIf { anchor != Rect.Zero } ?: anchorBounds.top
        val anchorBottom = anchor.bottom.toInt().takeIf { anchor != Rect.Zero } ?: anchorBounds.bottom
        val x = (centerX - popupContentSize.width / 2)
            .coerceIn(8, (windowSize.width - popupContentSize.width - 8).coerceAtLeast(8))
        val above = anchorTop - popupContentSize.height - 10
        val y = if (above >= 8) above else (anchorBottom + 10)
            .coerceIn(8, (windowSize.height - popupContentSize.height - 8).coerceAtLeast(8))
        return IntOffset(x, y)
    }
}
