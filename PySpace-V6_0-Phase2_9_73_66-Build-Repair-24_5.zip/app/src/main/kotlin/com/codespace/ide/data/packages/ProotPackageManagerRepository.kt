package com.codespace.ide.data.packages

import com.codespace.ide.ProotManager
import com.codespace.ide.domain.packages.InstalledPythonPackage
import com.codespace.ide.domain.packages.PackageCommandResult
import com.codespace.ide.domain.packages.PackageManagerRepository
import com.codespace.ide.domain.packages.PythonPackageSpec
import com.codespace.ide.ide.projects.PyProject
import com.codespace.ide.ide.projects.guestProjectPath
import com.codespace.ide.ide.projects.guestAwareExists
import com.codespace.ide.ide.projects.projectVenvName
import com.codespace.ide.ide.projects.venvPythonReady
import com.codespace.ide.runtime.RuntimeDispatchers
import java.io.File
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * Executes pip only through the same project venv binary used by the existing
 * IDE and terminal. Commands are serialized to avoid concurrent pip mutations
 * (pip install/uninstall/list) racing over site-packages on low-memory phones.
 */
class ProotPackageManagerRepository(
    private val proot: ProotManager,
    private val dispatchers: RuntimeDispatchers = RuntimeDispatchers.Default,
) : PackageManagerRepository {
    private val commandMutex = Mutex()

    override suspend fun listInstalled(projectDir: File): List<InstalledPythonPackage> =
        withContext(dispatchers.io) {
            commandMutex.withLock {
                val result = execute(projectDir, "list --format=freeze")
                if (!result.success) {
                    throw IllegalStateException(result.output.ifBlank { "Unable to read installed packages." })
                }
                PythonPackageSpec.parseFreeze(result.output)
            }
        }

    override suspend fun install(
        projectDir: File,
        requirement: String,
    ): PackageCommandResult {
        val normalized = requirement.trim()
        require(PythonPackageSpec.isSafeRequirement(normalized)) {
            "Enter a package name with an optional version, for example requests or numpy==2.1.0."
        }
        return withContext(dispatchers.io) {
            commandMutex.withLock { execute(projectDir, "install ${shellQuote(normalized)}") }
        }
    }

    override suspend fun uninstall(
        projectDir: File,
        packageName: String,
    ): PackageCommandResult {
        val normalized = packageName.trim()
        require(PACKAGE_NAME.matches(normalized)) { "Invalid package name." }
        require(!normalized.equals("pip", ignoreCase = true)) {
            "pip is required by this project's virtual environment and cannot be removed here."
        }
        return withContext(dispatchers.io) {
            commandMutex.withLock {
                execute(projectDir, "uninstall -y ${shellQuote(normalized)}")
            }
        }
    }

    private fun execute(projectDir: File, pipArguments: String): PackageCommandResult {
        val project = PyProject(projectDir.name, projectDir)
        check(venvPythonReady(projectDir)) {
            "This project's virtual environment is not initialized yet. Open the project and let its environment setup finish before managing packages."
        }
        val projectPath = shellQuote(guestProjectPath(project))
        val venvName = projectVenvName(projectDir)
        require(Regex("^[A-Za-z0-9_.-]{1,64}$").matches(venvName)) {
            "The project's virtual-environment directory name is invalid."
        }
        val pipScript = File(File(projectDir, venvName), "bin/pip")
        // Never fall back to Ubuntu's global pip: if the venv's pip script is
        // absent, invoke that same venv's Python module instead.
        val pip = if (guestAwareExists(pipScript)) {
            shellQuote("./$venvName/bin/pip")
        } else {
            "${shellQuote("./$venvName/bin/python")} -m pip"
        }
        // Keep pip's output bounded without piping pip directly into `head`:
        // a pipe could close early and terminate a legitimate installation.
        // `cd ... || exit` is deliberate: never run pip from /root if the
        // project directory cannot be entered.
        val command = "cd $projectPath || exit \$?; o=/tmp/pyspace-pip-\$\$.log; " +
            "$pip $pipArguments >\"\$o\" 2>&1; code=\$?; " +
            "head -c $MAX_OUTPUT_BYTES \"\$o\" 2>/dev/null; " +
            "rm -f \"\$o\"; exit \$code"
        val raw = proot.runOnce(command)
        val exitMatch = EXIT_CODE.find(raw)
        val exitCode = exitMatch?.groupValues?.getOrNull(1)?.toIntOrNull()
        val output = if (exitMatch != null) raw.substring(0, exitMatch.range.first).trimEnd() else raw.trimEnd()
        val success = exitCode == 0 && !raw.startsWith("ERROR:")
        return PackageCommandResult(success, output.take(MAX_OUTPUT_BYTES), exitCode)
    }

    private fun shellQuote(value: String): String = "'" + value.replace("'", "'\\''") + "'"

    private companion object {
        const val MAX_OUTPUT_BYTES = 120_000
        val EXIT_CODE = Regex("(?m)^\\[exit=(-?\\d+)\\]\\s*$")
        val PACKAGE_NAME = Regex("^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
    }
}
