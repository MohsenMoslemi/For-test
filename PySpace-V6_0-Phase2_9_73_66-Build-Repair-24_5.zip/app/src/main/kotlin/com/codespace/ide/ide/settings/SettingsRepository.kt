package com.codespace.ide.ide.settings

import android.content.Context
import com.codespace.ide.ide.EditorFontCatalog
import com.codespace.ide.ide.EditorSymbolCatalog
import com.codespace.ide.ide.theme.IdeTheme


/** Immutable snapshot of the preferences presented by the Settings screens. */
data class IdeSettingsState(
    val themeId: String = com.codespace.ide.ide.theme.IdeTheme.DARK,
    val codeFontSize: Float = 13f,
    val editorFontFamilyId: String = com.codespace.ide.ide.EditorFontCatalog.DEFAULT_ID,
    val editorSymbolOrder: List<String> = com.codespace.ide.ide.EditorSymbolCatalog.defaults,
    val tabWidth: Int = 4,
    val autoIndent: Boolean = true,
    val lineNumbers: Boolean = true,
    val wordWrap: Boolean = false,
    val webOpenMode: String = "ask",
    val pan2D: Boolean = false,
    val pinchZoom: Boolean = true,
    val showDiagnosticPopup: Boolean = true,
    val showCompletionPopup: Boolean = true,
    val showDocumentationPopup: Boolean = true,
)

/** Persistence boundary for user-facing IDE preferences. */
interface SettingsRepository {
    fun setThemeId(value: String)
    fun readSettings(): IdeSettingsState
    fun setCodeFontSize(value: Float)
    fun setEditorFontFamilyId(value: String)
    fun setEditorSymbolOrder(value: List<String>)
    fun setTabWidth(value: Int)
    fun setAutoIndent(value: Boolean)
    fun setLineNumbers(value: Boolean)
    fun setWordWrap(value: Boolean)
    fun setWebOpenMode(value: String)
    fun setPan2D(value: Boolean)
    fun setPinchZoom(value: Boolean)
    fun setShowDiagnosticPopup(value: Boolean)
    fun setShowCompletionPopup(value: Boolean)
    fun setShowDocumentationPopup(value: Boolean)
}

/**
 * SharedPreferences-backed settings storage. It deliberately reuses the
 * existing preference keys so upgrades preserve every user's current choices.
 * SharedPreferences.Editor.apply() performs disk persistence asynchronously.
 */
class SharedPreferencesSettingsRepository(context: Context) : SettingsRepository {
    private val prefs = IdePrefs(context.applicationContext)

    override fun readSettings(): IdeSettingsState = IdeSettingsState(
        themeId = prefs.themeId,
        codeFontSize = prefs.codeFontSize,
        editorFontFamilyId = prefs.editorFontFamilyId,
        editorSymbolOrder = prefs.editorSymbolOrder,
        tabWidth = prefs.tabWidth,
        autoIndent = prefs.autoIndent,
        lineNumbers = prefs.lineNumbers,
        wordWrap = prefs.wordWrap,
        webOpenMode = prefs.webOpenMode
            .takeIf { it == "ask" || it == "ide" || it == "phone" } ?: "ask",
        pan2D = prefs.pan2D,
        pinchZoom = prefs.pinchZoom,
        showDiagnosticPopup = prefs.showDiagnosticPopup,
        showCompletionPopup = prefs.showCompletionPopup,
        showDocumentationPopup = prefs.showDocumentationPopup,
    )

    override fun setThemeId(value: String) { prefs.themeId = value }
    override fun setCodeFontSize(value: Float) { prefs.codeFontSize = value.coerceIn(9f, 24f) }
    override fun setEditorFontFamilyId(value: String) { prefs.editorFontFamilyId = value }
    override fun setEditorSymbolOrder(value: List<String>) { prefs.editorSymbolOrder = value }
    override fun setTabWidth(value: Int) { prefs.tabWidth = value.coerceIn(2, 8) }
    override fun setAutoIndent(value: Boolean) { prefs.autoIndent = value }
    override fun setLineNumbers(value: Boolean) { prefs.lineNumbers = value }
    override fun setWordWrap(value: Boolean) { prefs.wordWrap = value }
    override fun setWebOpenMode(value: String) {
        prefs.webOpenMode = value.takeIf { it == "ask" || it == "ide" || it == "phone" } ?: "ask"
    }
    override fun setPan2D(value: Boolean) { prefs.pan2D = value }
    override fun setPinchZoom(value: Boolean) { prefs.pinchZoom = value }
    override fun setShowDiagnosticPopup(value: Boolean) { prefs.showDiagnosticPopup = value }
    override fun setShowCompletionPopup(value: Boolean) { prefs.showCompletionPopup = value }
    override fun setShowDocumentationPopup(value: Boolean) { prefs.showDocumentationPopup = value }
}
