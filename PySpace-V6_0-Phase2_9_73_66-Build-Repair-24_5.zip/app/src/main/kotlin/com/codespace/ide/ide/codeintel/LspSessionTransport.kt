package com.codespace.ide.ide.codeintel

import java.io.Closeable
import org.json.JSONObject
import com.codespace.ide.ide.JSON

/**
 * Boundary between project-level language-server orchestration and the
 * concrete process/JSON-RPC transport. Implementations own transport resources
 * only; document snapshots and diagnostic policy belong to the controller.
 */
internal interface LspSessionTransport : Closeable {
    val isAlive: Boolean
    fun documentVersion(uri: String): Int
    fun setDocumentVersion(uri: String, version: Int)
    fun forgetDocument(uri: String)
    fun notify(method: String, params: JSONObject)
    fun request(method: String, params: JSONObject, timeoutMs: Long): Any?
}
