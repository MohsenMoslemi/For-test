package com.codespace.ide.ide.browser

import android.webkit.WebView

/**
 * Owns the Activity lifecycle hooks for the browser's currently attached WebView.
 * All methods are called from the Android main thread (Compose/Lifecycle callbacks).
 * The controller never creates a WebView and never retains one after release.
 */
class BrowserWebViewLifecycle {
    private var attached: WebView? = null
    private var hostPaused: Boolean = false

    fun attach(view: WebView) {
        val previous = attached
        if (previous !== view) {
            // If AndroidView replaces its platform view, release the previous
            // instance before taking ownership of the new one.
            if (previous != null) release(previous)
            attached = view
        }
        if (hostPaused) pause(view) else resume(view)
    }

    fun onHostPause() {
        hostPaused = true
        attached?.let(::pause)
    }

    fun onHostResume() {
        hostPaused = false
        attached?.let(::resume)
    }

    /** Idempotent: AndroidView onRelease and Activity ON_DESTROY may both call it. */
    fun release(view: WebView) {
        // ON_DESTROY and AndroidView.onRelease can both arrive for the same
        // instance. Only the current owner performs native destruction.
        if (attached !== view) return
        attached = null
        try { view.stopLoading() } catch (_: Exception) { }
        try { view.onPause() } catch (_: Exception) { }
        try { view.webChromeClient = null } catch (_: Exception) { }
        try { view.destroy() } catch (_: Exception) { }
    }

    private fun pause(view: WebView) {
        try { view.onPause() } catch (_: Exception) { }
    }

    private fun resume(view: WebView) {
        try { view.onResume() } catch (_: Exception) { }
    }
}
