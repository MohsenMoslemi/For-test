package com.codespace.ide.ide.shell

import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import com.codespace.ide.ide.codeintel.CodeIntelligenceViewModel
import com.codespace.ide.ide.editor.EditorViewModel
import com.codespace.ide.ide.HomeTab
import com.codespace.ide.ide.IdeScreen
import com.codespace.ide.ide.PanelTab
import com.codespace.ide.ide.RunInfo
import com.codespace.ide.ide.debug.DebugController
import com.codespace.ide.ide.explorer.FileExplorerViewModel
import com.codespace.ide.ide.projects.PyProject

/** Owns top-level navigation and recovery presentation state for one IDE host. */
internal class IdeNavigationState(
    initialScreen: IdeScreen,
    initialMissingProject: PyProject?,
) {
    val screen: MutableState<IdeScreen> = mutableStateOf(initialScreen)
    val missingProject: MutableState<PyProject?> = mutableStateOf(initialMissingProject)
    val recoveryAvailable: MutableState<Boolean> = mutableStateOf(false)
    val recoveryBusy: MutableState<Boolean> = mutableStateOf(false)
    val recoveryError: MutableState<String?> = mutableStateOf(null)
    val settingsOpen: MutableState<Boolean> = mutableStateOf(false)
    val homeTab: MutableState<HomeTab> = mutableStateOf(HomeTab.Projects)
}

/** Owns the bottom-panel's visibility, sizing, selected surface and pending UI action. */
internal class IdePanelState {
    val open: MutableState<Boolean> = mutableStateOf(false)
    val fraction: MutableState<Float> = mutableStateOf(0.38f)
    val tab: MutableState<PanelTab> = mutableStateOf(PanelTab.Console)
    val pendingImportSelection: MutableState<PendingImportSelection?> = mutableStateOf(null)
}

/**
 * Single owner for feature ViewModels/controllers keyed by canonical project path.
 * The registry intentionally exposes its maps to the owning shell coordinator only;
 * removal/closing remains explicit at project-deletion and host-disposal boundaries.
 */
internal class ProjectFeatureRegistry {
    val editors = mutableMapOf<String, EditorViewModel>()
    val fileExplorers = mutableMapOf<String, FileExplorerViewModel>()
    val codeIntelligence = mutableMapOf<String, CodeIntelligenceViewModel>()
    val debugControllers = mutableMapOf<String, DebugController>()

    fun removeProject(path: String) {
        editors.remove(path)
        fileExplorers.remove(path)
        codeIntelligence.remove(path)
        debugControllers.remove(path)?.dispose()
    }

    fun disposeDebugControllers() {
        debugControllers.values.toList().forEach { it.dispose() }
        debugControllers.clear()
    }
}

/** Owns transient state for one active console/display/camera run session. */
internal class IdeRunSessionState {
    val webPreparationRequest = mutableStateOf(0L)
    val cameraPreparationRequest = mutableStateOf(0L)
    val consoleRun = mutableStateOf<com.codespace.ide.ide.RunInfo?>(null)
    val displayOwner = mutableStateOf<String?>(null)
    val pendingConflict = mutableStateOf<PendingConflict?>(null)
    val consoleCmd = mutableStateOf<String?>(null)
    val consoleRunId = mutableStateOf(0)
    val consoleLive = mutableStateOf(false)
    val consoleRestartSeq = mutableStateOf(0)
}
