package com.codespace.ide.ui.install

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.codespace.ide.UbuntuManager
import com.codespace.ide.ProotManager
import com.codespace.ide.ide.codeintel.PythonLspRuntimeInstaller
import com.codespace.ide.runtime.RuntimeDispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * State of the first-run install/update screen.
 *
 * [log] is the visible installer output, [busy] disables the action button and
 * [installed] is set once the rootfs is verified, so the composable only has to
 * react to state instead of owning the install coroutine itself.
 */
data class InstallUiState(
    val busy: Boolean = false,
    val log: String = "",
    val installed: Boolean = false,
    val progress: Float? = null,
    val etaSeconds: Long? = null,
    val phase: String = "Ready to prepare your workspace",
)

/**
 * Owns the install use case for the lifetime of the Activity, so rotating the
 * device (or a configuration change) no longer cancels an in-flight install:
 * [viewModelScope] survives the composition and is only cancelled when the
 * Activity is really finished.
 */
class InstallViewModel(
    private val ubuntu: UbuntuManager,
    private val proot: ProotManager,
    private val appContext: Context,
    private val dispatchers: RuntimeDispatchers,
    initialLog: String,
) : ViewModel() {

    private val maxLogChars = 48_000
    private val _state = MutableStateFlow(InstallUiState(log = initialLog.takeLast(maxLogChars)))
    val state: StateFlow<InstallUiState> = _state.asStateFlow()

    private fun appendLog(message: String) {
        if (message.startsWith("@progress:")) {
            val parts = message.removePrefix("@progress:").split('|')
            val fraction = parts.getOrNull(0)?.toFloatOrNull()?.coerceIn(0f, 1f)
            val phase = parts.getOrNull(1)?.takeIf { it.isNotBlank() } ?: "Preparing runtime"
            val eta = parts.getOrNull(2)?.toLongOrNull()
            _state.update { it.copy(progress = fraction, phase = phase, etaSeconds = eta) }
            return
        }
        _state.update { current ->
            val safeMessage = message
                .replace("Ubuntu rootfs", "Python runtime")
                .replace("Ubuntu installation", "PySpace setup")
                .replace("Ubuntu", "runtime")
            val next = current.log + safeMessage + "\n"
            current.copy(
                log = if (next.length > maxLogChars) next.takeLast(maxLogChars) else next,
                phase = safeMessage.take(100),
            )
        }
    }

    fun install(isUpdate: Boolean) {
        if (_state.value.busy) return
        _state.update {
            it.copy(
                busy = true,
                progress = 0f,
                etaSeconds = null,
                phase = if (isUpdate) "Updating Python runtime" else "Preparing Python runtime",
                log = if (isUpdate) "Refreshing your development environment…\n" else "Preparing your Python workspace…\n",
            )
        }
        viewModelScope.launch {
            try {
                ubuntu.install(::appendLog)
                if (ubuntu.isInstalled()) {
                    appendLog("@progress:0.92|Setting up offline code intelligence|")
                    appendLog("Preparing offline Python language tools…")
                    val lspReady = withContext(dispatchers.io) {
                        PythonLspRuntimeInstaller.ensureInstalled(appContext, proot)
                    }
                    appendLog(if (lspReady) "Python language tools are ready." else
                        "Python language tools will retry automatically when the IDE starts.")
                    if (lspReady) appendLog("@progress:1.0|Finishing up|")
                }
                val ok = ubuntu.isInstalled()
                _state.update {
                    it.copy(
                        busy = false,
                        installed = ok,
                        progress = if (ok) 1f else it.progress,
                        phase = if (ok) "Your workspace is ready" else "Setup needs another try",
                        log = it.log + if (ok) "READY\n" else "SETUP INCOMPLETE\n",
                    )
                }
            } catch (cancelled: CancellationException) {
                // Never turn structured cancellation into a successful-looking UI state.
                _state.update { it.copy(busy = false) }
                throw cancelled
            } catch (t: Exception) {
                val detail = (t.message?.take(500) ?: t.javaClass.simpleName).replace("Ubuntu", "runtime")
                _state.update {
                    val next = it.log + "\nERROR: $detail\n"
                    it.copy(busy = false, log = next.takeLast(maxLogChars))
                }
            }
        }
    }

    class Factory(
        private val ubuntu: UbuntuManager,
        private val proot: ProotManager,
        private val appContext: Context,
        private val dispatchers: RuntimeDispatchers,
        private val initialLog: String,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            InstallViewModel(ubuntu, proot, appContext, dispatchers, initialLog) as T
    }
}
