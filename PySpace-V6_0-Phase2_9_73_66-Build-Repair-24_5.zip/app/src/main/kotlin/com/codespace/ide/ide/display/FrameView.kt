package com.codespace.ide.ide.display

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import com.codespace.ide.memory.MemoryRuntimePolicy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

// ---------------------------------------------------------------------------
// Frame view: a display path WITHOUT X11/VNC for cv2.imshow() and matplotlib.
//
// The guest side (Python shims below) writes each frame as a JPEG into the
// guest /tmp (= filesDir/proot-ubuntu-tmp on the host) with an atomic rename.
// This class polls that file and decodes it straight into a Bitmap that
// Compose draws. Input goes the other way: taps/keys are appended to an
// "events" file that the shim reads inside waitKey()/plt.show().
// The viewer is a small "window": toolbar (zoom, fit, 100%, pause, save),
// a status bar with pixel readout, and a clear key panel.
// ---------------------------------------------------------------------------

class FrameDisplay(context: Context, private val scope: CoroutineScope) {
    var status by mutableStateOf("Idle")
    /** Bumped whenever the visible frame state changes. */
    var version by mutableStateOf(0)
    var frameW by mutableStateOf(0)
    var frameH by mutableStateOf(0)
    var fps by mutableStateOf(0)
    /** "opencv" or "matplotlib": decides which key panel the viewer shows. */
    var kind by mutableStateOf("opencv")
    @Volatile var hasFrame = false
        private set
    var bitmap: Bitmap? = null
        private set

    private val dir = File(File(context.applicationContext.filesDir, "proot-ubuntu-tmp"), "ide-view")
    private val frameFile = File(dir, "frame.jpg")
    private val eventsFile = File(dir, "events")
    @Volatile private var t0 = 0L
    /** Every start/stop invalidates workers belonging to the previous run. */
    @Volatile private var generation = 0L
    private var pollJob: Job? = null
    private var writerJob: Job? = null
    private var outCh: Channel<String>? = null
    private var lastMoveAt = 0L

    /** Begins a new run: forgets the old picture and starts one guarded poller. */
    fun start() {
        stop()
        val runGeneration = ++generation
        t0 = System.currentTimeMillis()
        hasFrame = false
        bitmap = null
        frameW = 0
        frameH = 0
        fps = 0
        version++
        status = "Waiting for the first frame…"

        val ch = Channel<String>(Channel.UNLIMITED)
        outCh = ch
        writerJob = scope.launch(Dispatchers.IO) {
            try {
                for (line in ch) {
                    // A queued event from an old viewer must never leak into a
                    // newer run's event stream (the path is intentionally shared).
                    if (!isActive || generation != runGeneration) break
                    try {
                        dir.mkdirs()
                        if (generation == runGeneration) eventsFile.appendText(line)
                    } catch (_: Exception) {
                    }
                }
            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                throw cancelled
            } catch (_: Throwable) {
            }
        }

        pollJob = scope.launch(Dispatchers.IO) {
            var lastStamp = 0L
            var lastLen = -1L
            var winStart = System.currentTimeMillis()
            var winCount = 0
            while (isActive && generation == runGeneration) {
                try {
                    val stamp = frameFile.lastModified()
                    val len = frameFile.length()
                    if (len > 0 && (stamp != lastStamp || len != lastLen) && stamp >= t0 - 1500) {
                        lastStamp = stamp
                        lastLen = len
                        // Decode off Main. The decoded bitmap is published only
                        // if this poller still belongs to the active run.
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeFile(frameFile.path, bounds)
                        val decoded = if (bounds.outWidth > 0 && bounds.outHeight > 0) {
                            val maxEdge = MemoryRuntimePolicy.imageMaxEdge()
                            var sample = 1
                            while (bounds.outWidth / sample > maxEdge || bounds.outHeight / sample > maxEdge) {
                                sample *= 2
                            }
                            BitmapFactory.decodeFile(
                                frameFile.path,
                                BitmapFactory.Options().apply { inSampleSize = sample }
                            )
                        } else null
                        if (decoded != null) {
                            var accepted = false
                            try {
                                withContext(Dispatchers.Main.immediate) {
                                    if (generation == runGeneration) {
                                        bitmap = decoded
                                        frameW = decoded.width
                                        frameH = decoded.height
                                        hasFrame = true
                                        status = "Live"
                                        version++
                                        accepted = true
                                    }
                                }
                            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                                if (!accepted && !decoded.isRecycled) decoded.recycle()
                                throw cancelled
                            }
                            // A stale decode was never handed to Compose and can
                            // be released immediately. Published bitmaps are not
                            // recycled here because Compose / Save may still hold them.
                            if (!accepted && !decoded.isRecycled) decoded.recycle()
                            if (accepted) winCount++
                        }
                    }

                    val now = System.currentTimeMillis()
                    if (now - winStart >= 1000L) {
                        val measuredFps = winCount
                        winCount = 0
                        winStart = now
                        withContext(Dispatchers.Main.immediate) {
                            if (generation == runGeneration) fps = measuredFps
                        }
                    }
                } catch (cancelled: kotlinx.coroutines.CancellationException) {
                    throw cancelled
                } catch (_: Throwable) {
                    // A transient partial/renamed JPEG must not terminate polling.
                }
                delay(20)
            }
        }
    }

    /**
     * Ends the current frame session. Worker jobs are cancelled and their
     * generation is invalidated before state is cleared, so a late decode can
     * never republish a bitmap after Stop or after a newer run has started.
     * Published bitmaps are left for GC rather than recycled while UI/save code
     * may still hold a reference.
     */
    fun stop() {
        generation++
        pollJob?.cancel()
        pollJob = null
        outCh?.close()
        outCh = null
        writerJob?.cancel()
        writerJob = null
        hasFrame = false
        bitmap = null
        frameW = 0
        frameH = 0
        fps = 0
        status = "Idle"
        version++
    }

    /** ASCII code like cv2.waitKey() returns (q=113, Esc=27, Enter=13 …). */
    fun sendKey(code: Int) {
        outCh?.trySend("k $code\n")
    }

    /** kind: 0 move, 1 left down, 4 left up (cv2.EVENT_* values). */
    fun sendMouse(kind: Int, x: Int, y: Int, dragging: Boolean = false) {
        if (kind == 0) {
            val now = System.currentTimeMillis()
            if (now - lastMoveAt < 30L) return
            lastMoveAt = now
        }
        val flags = if (dragging || kind == 1) 1 else 0
        outCh?.trySend("m $kind $x $y $flags\n")
    }

    /** "Continue": lets a blocking plt.show() return. */
    fun sendContinue() {
        outCh?.trySend("c\n")
    }
}

internal const val MIN_ZOOM = 0.25f
internal const val MAX_ZOOM = 10f

@Composable
fun FrameViewer(
    display: FrameDisplay,
    title: String,
    saveDir: File?,
    onSaved: () -> Unit,
    running: Boolean,
    onMinimize: () -> Unit,
    onStop: () -> Unit
) {
    BackHandler { onMinimize() }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val ver = display.version
    val live = display.bitmap
    var paused by remember { mutableStateOf(false) }
    var frozen by remember { mutableStateOf<Bitmap?>(null) }
    val bmp = if (paused) frozen else live
    var boxW by remember { mutableStateOf(0) }
    var boxH by remember { mutableStateOf(0) }
    var zoom by remember { mutableStateOf(1f) }
    var tx by remember { mutableStateOf(0f) }
    var ty by remember { mutableStateOf(0f) }
    var moveMode by remember { mutableStateOf(false) }
    var probe by remember { mutableStateOf<String?>(null) }
    var showTyping by remember { mutableStateOf(false) }
    var typed by remember { mutableStateOf("") }

    fun fitScale(): Float {
        val fw = bmp?.width ?: 0
        val fh = bmp?.height ?: 0
        if (fw <= 0 || fh <= 0 || boxW <= 0 || boxH <= 0) return 1f
        return min(boxW.toFloat() / fw, boxH.toFloat() / fh)
    }

    fun clampT() {
        if (zoom <= 1f) {
            tx = 0f
            ty = 0f
        } else {
            val mx = (zoom - 1f) * boxW / 2f
            val my = (zoom - 1f) * boxH / 2f
            tx = tx.coerceIn(-mx, mx)
            ty = ty.coerceIn(-my, my)
        }
    }

    fun zoomBy(factor: Float, px: Float = boxW / 2f, py: Float = boxH / 2f) {
        val nz = (zoom * factor).coerceIn(MIN_ZOOM, MAX_ZOOM)
        val z = nz / zoom
        val cx = boxW / 2f
        val cy = boxH / 2f
        tx = (1f - z) * (px - cx) + z * tx
        ty = (1f - z) * (py - cy) + z * ty
        zoom = nz
        clampT()
    }

    // Screen point -> image pixel, undoing the zoom/pan layer and the Fit letterbox.
    fun mapXY(px: Float, py: Float): Pair<Int, Int> {
        val fw = bmp?.width ?: 0
        val fh = bmp?.height ?: 0
        if (fw <= 0 || fh <= 0 || boxW <= 0 || boxH <= 0) return 0 to 0
        val cx = boxW / 2f
        val cy = boxH / 2f
        val lx = (px - cx - tx) / zoom + cx
        val ly = (py - cy - ty) / zoom + cy
        val s = min(boxW.toFloat() / fw, boxH.toFloat() / fh)
        val ox = (boxW - fw * s) / 2f
        val oy = (boxH - fh * s) / 2f
        val x = ((lx - ox) / s).toInt().coerceIn(0, fw - 1)
        val y = ((ly - oy) / s).toInt().coerceIn(0, fh - 1)
        return x to y
    }

    fun readPixel(x: Int, y: Int) {
        val b = bmp ?: return
        try {
            val c = b.getPixel(x, y)
            probe = "x=$x  y=$y   R ${(c shr 16) and 255}  G ${(c shr 8) and 255}  B ${c and 255}"
        } catch (_: Exception) {
        }
    }

    Column(
        Modifier.fillMaxSize().background(Color(IdeTheme.BG))
            .windowInsetsPadding(WindowInsets.statusBars.union(WindowInsets.navigationBars))
            .padding(horizontal = 10.dp)
    ) {
        // ---- header --------------------------------------------------------
        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    title.ifBlank { "Live view" }, color = Color(IdeTheme.TEXT),
                    fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    when {
                        !running -> "Finished — you can still zoom and save"
                        display.fps > 0 -> "Live · ${display.fps} fps"
                        else -> display.status
                    },
                    color = Color(IdeTheme.DIM), fontSize = 11.sp
                )
            }
            PillButton("Hide", Color(IdeTheme.TEXT)) { onMinimize() }
            Spacer(Modifier.width(8.dp))
            PillButton(if (running) "Stop" else "Close", Color(IdeTheme.ERROR)) { onStop() }
        }

        // ---- the "window": toolbar + picture + status -----------------------
        Column(
            Modifier.weight(1f).fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, Color(IdeTheme.LINE), RoundedCornerShape(14.dp))
                .background(Color(IdeTheme.PANEL))
        ) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ToolBtn("+", "Zoom in") { zoomBy(1.5f) }
                ToolBtn("−", "Zoom out") { zoomBy(1f / 1.5f) }
                ToolBtn("□", "Fit") { zoom = 1f; tx = 0f; ty = 0f }
                ToolBtn("1:1", "100%") {
                    val f = fitScale()
                    zoom = (1f / f).coerceIn(MIN_ZOOM, MAX_ZOOM)
                    tx = 0f
                    ty = 0f
                    clampT()
                }
                ToolBtn(
                    if (moveMode) "↔" else "↖",
                    if (moveMode) "Move" else "Click",
                    active = moveMode
                ) { moveMode = !moveMode }
                ToolBtn(
                    if (paused) "▶" else "❚❚",
                    if (paused) "Resume" else "Pause",
                    active = paused
                ) {
                    if (paused) {
                        paused = false
                        frozen = null
                    } else {
                        frozen = live
                        paused = frozen != null
                    }
                }
                ToolBtn("↓", "Save") {
                    val b = bmp
                    if (b == null) {
                        Toast.makeText(ctx, "No picture yet", Toast.LENGTH_SHORT).show()
                    } else {
                        scope.launch(Dispatchers.IO) {
                            val saved = saveFrame(ctx, b, saveDir)
                            withContext(Dispatchers.Main) {
                                Toast.makeText(
                                    ctx,
                                    if (saved != null) "Saved: $saved" else "Could not save the picture",
                                    Toast.LENGTH_SHORT
                                ).show()
                                if (saved != null) onSaved()
                            }
                        }
                    }
                }
            }
            Box(
                Modifier.weight(1f).fillMaxWidth().background(Color.Black).clipToBounds()
                    .onSizeChanged { boxW = it.width; boxH = it.height }
                    .pointerInput(moveMode) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            var multi = false
                            var mouseDown = false
                            var lx = -1
                            var ly = -1
                            if (!moveMode) {
                                val (x0, y0) = mapXY(down.position.x, down.position.y)
                                display.sendMouse(1, x0, y0)
                                mouseDown = true
                                lx = x0
                                ly = y0
                                readPixel(x0, y0)
                            }
                            while (true) {
                                val ev = awaitPointerEvent()
                                val pressed = ev.changes.count { it.pressed }
                                if (pressed == 0) {
                                    if (mouseDown) {
                                        val c = ev.changes.first()
                                        val (x, y) = mapXY(c.position.x, c.position.y)
                                        display.sendMouse(4, x, y)
                                    }
                                    break
                                }
                                if (pressed >= 2) {
                                    if (mouseDown) {
                                        display.sendMouse(4, lx, ly)
                                        mouseDown = false
                                    }
                                    multi = true
                                    val z = ev.calculateZoom()
                                    val pan = ev.calculatePan()
                                    val cen = ev.calculateCentroid(useCurrent = true)
                                    zoomBy(z, cen.x, cen.y)
                                    tx += pan.x
                                    ty += pan.y
                                    clampT()
                                    ev.changes.forEach { it.consume() }
                                } else if (!multi) {
                                    val c = ev.changes.firstOrNull { it.pressed } ?: continue
                                    if (moveMode) {
                                        val d = c.position - c.previousPosition
                                        tx += d.x
                                        ty += d.y
                                        clampT()
                                        c.consume()
                                    } else {
                                        val (x, y) = mapXY(c.position.x, c.position.y)
                                        if (x != lx || y != ly) {
                                            display.sendMouse(0, x, y, dragging = true)
                                            lx = x
                                            ly = y
                                            readPixel(x, y)
                                        }
                                    }
                                }
                            }
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                if (bmp != null && ver >= 0) {
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize().graphicsLayer(
                            scaleX = zoom, scaleY = zoom, translationX = tx, translationY = ty
                        )
                    )
                } else {
                    Text(display.status, color = Color(IdeTheme.DIM), fontSize = 13.sp)
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    probe ?: if (moveMode) "Move mode: drag to pan, pinch to zoom"
                    else "Tap the picture to read a pixel · pinch to zoom",
                    color = Color(IdeTheme.DIM), fontSize = 11.sp,
                    modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                val sz = if (bmp != null) "${bmp.width}×${bmp.height}" else "—"
                Text(
                    "$sz · ${(zoom * fitScale() * 100f).toInt()}%",
                    color = Color(IdeTheme.TEXT), fontSize = 11.sp
                )
            }
        }

        // ---- keys ------------------------------------------------------------
        Spacer(Modifier.height(8.dp))
        Text(
            if (display.kind == "matplotlib") "Plot controls" else "Keys sent to your program (cv2.waitKey)",
            color = Color(IdeTheme.DIM), fontSize = 11.sp,
            modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
        )
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (display.kind == "matplotlib") {
                KeyCap("Continue  ▶", "close the figure and keep running", Modifier.weight(1f), primary = true) {
                    display.sendContinue()
                }
            } else {
                KeyCap("Q", "quit", Modifier.weight(1f)) { display.sendKey(113) }
                KeyCap("Esc", "exit", Modifier.weight(1f)) { display.sendKey(27) }
                KeyCap("Space", "pause / next", Modifier.weight(1.3f)) { display.sendKey(32) }
                KeyCap("Enter", "confirm", Modifier.weight(1.2f)) { display.sendKey(13) }
            }
            KeyCap("⌨", "type", Modifier.weight(0.8f), active = showTyping) { showTyping = !showTyping }
        }
        if (showTyping) {
            Spacer(Modifier.height(8.dp))
            BasicTextField(
                value = typed,
                onValueChange = { nv ->
                    nv.forEach { display.sendKey(it.code) }
                    typed = ""
                },
                textStyle = TextStyle(color = Color(IdeTheme.TEXT), fontSize = 15.sp),
                cursorBrush = SolidColor(Color(IdeTheme.ACCENT)),
                modifier = Modifier.fillMaxWidth()
                    .background(Color(IdeTheme.CARD), RoundedCornerShape(10.dp))
                    .border(1.dp, Color(IdeTheme.LINE), RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                decorationBox = { inner ->
                    Box {
                        if (typed.isEmpty()) {
                            Text("Type here: each letter is sent as a key press", color = Color(IdeTheme.DIM), fontSize = 13.sp)
                        }
                        inner()
                    }
                }
            )
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
internal fun PillButton(label: String, color: Color, onClick: () -> Unit) {
    Text(
        label, fontSize = 13.sp, color = color, fontWeight = FontWeight.Medium,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .border(1.dp, Color(IdeTheme.LINE), RoundedCornerShape(20.dp))
            .background(Color(IdeTheme.CARD))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
internal fun ToolBtn(glyph: String, label: String, active: Boolean = false, onClick: () -> Unit) {
    val fg = if (active) Color(IdeTheme.BG) else Color(IdeTheme.TEXT)
    Column(
        Modifier
            .width(58.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (active) Color(IdeTheme.ACCENT) else Color(IdeTheme.CARD))
            .clickable { onClick() }
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(glyph, fontSize = 17.sp, color = fg, fontWeight = FontWeight.Bold)
        Text(label, fontSize = 10.sp, color = if (active) fg else Color(IdeTheme.DIM), maxLines = 1)
    }
}

@Composable
internal fun KeyCap(
    key: String,
    hint: String,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    active: Boolean = false,
    onClick: () -> Unit
) {
    val bg = when {
        primary -> Color(IdeTheme.ACCENT)
        active -> Color(IdeTheme.VIOLET)
        else -> Color(IdeTheme.CARD)
    }
    val fg = if (primary) Color(IdeTheme.BG) else Color(IdeTheme.TEXT)
    Column(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .border(1.dp, Color(IdeTheme.LINE), RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 9.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(key, fontSize = 16.sp, color = fg, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(hint, fontSize = 10.sp, color = if (primary) fg else Color(IdeTheme.DIM), maxLines = 1)
    }
}

/**
 * Saves the picture as a PNG inside the PROJECT (captures/capture_<time>.png) so it shows up in
 * the file tree. Returns a short label for the toast, or null on failure. Without a project
 * folder it falls back to Pictures/IDE in the gallery.
 */
internal fun saveFrame(ctx: Context, bmp: Bitmap, dir: File?): String? {
    return try {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        if (dir != null) {
            dir.mkdirs()
            val f = File(dir, "capture_$stamp.png")
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            "${dir.name}/${f.name}"
        } else {
            val name = "IDE_$stamp.png"
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/IDE")
                }
                val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    ?: return null
                ctx.contentResolver.openOutputStream(uri)?.use {
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, it)
                } ?: return null
                "Pictures/IDE/$name"
            } else {
                val d = ctx.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: return null
                d.mkdirs()
                File(d, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                name
            }
        }
    } catch (_: Exception) {
        null
    }
}

// ---------------------------------------------------------------------------
// Guest side (Python). Installed by guiLaunchPrefix(frame = true) into
// /opt/ide-view/<VERSION>. NOTE: raw strings — keep this text free of the
// Kotlin dollar sign and of triple quotes.
// ---------------------------------------------------------------------------

const val VIEW_SHIM_VERSION = "v1"

val VIEW_SHIM_SOURCE = """# ide-view-shim-v1: cv2.imshow / waitKey / mouse callbacks -> IDE frame view.
# No X11, no VNC. Frames are JPEGs written atomically to IDE_VIEW_DIR.
import os, sys, time, atexit

_DIR = os.environ.get("IDE_VIEW_DIR", "/tmp/ide-view")
_FRAME = os.path.join(_DIR, "frame.jpg")
_TMP = os.path.join(_DIR, "frame.tmp")
_EV = os.path.join(_DIR, "events")
_MIN_DT = 0.03
_MAX_SIDE = 1280
_st = {"pos": 0, "keys": [], "cb": {}, "last": 0.0, "wins": {}, "scale": 1.0,
       "close": False, "dirty": False, "cv2": None, "tb": {}}


def publish_jpeg(data):
    try:
        os.makedirs(_DIR, exist_ok=True)
    except OSError:
        pass
    with open(_TMP, "wb") as f:
        f.write(data)
    os.replace(_TMP, _FRAME)
    _st["last"] = time.time()


def _poll():
    try:
        sz = os.path.getsize(_EV)
    except OSError:
        return
    if sz < _st["pos"]:
        _st["pos"] = 0
    if sz == _st["pos"]:
        return
    with open(_EV, "rb") as f:
        f.seek(_st["pos"])
        data = f.read()
    cut = data.rfind(b"\n")
    if cut < 0:
        return
    _st["pos"] += cut + 1
    for line in data[:cut].split(b"\n"):
        p = line.split()
        if not p:
            continue
        try:
            if p[0] == b"k":
                _st["keys"].append(int(p[1]))
            elif p[0] == b"c":
                _st["close"] = True
            elif p[0] == b"m":
                _mouse(int(p[1]), int(p[2]), int(p[3]), int(p[4]) if len(p) > 4 else 0)
        except Exception:
            pass


def _mouse(ev, x, y, flags):
    s = _st["scale"]
    for fn, param in list(_st["cb"].values()):
        try:
            fn(ev, int(x * s), int(y * s), flags, param)
        except Exception:
            import traceback
            traceback.print_exc()


def _to_u8(a):
    import numpy as np
    cv2 = _st["cv2"]
    if a.dtype != np.uint8:
        if a.dtype.kind == "f":
            a = (np.clip(a, 0.0, 1.0) * 255.0).astype(np.uint8)
        elif a.dtype == np.uint16:
            a = (a >> 8).astype(np.uint8)
        else:
            a = np.clip(a, 0, 255).astype(np.uint8)
    if a.ndim == 2:
        a = cv2.cvtColor(a, cv2.COLOR_GRAY2BGR)
    elif a.ndim == 3 and a.shape[2] == 4:
        a = a[:, :, :3]
    elif a.ndim == 3 and a.shape[2] == 1:
        a = cv2.cvtColor(a, cv2.COLOR_GRAY2BGR)
    return a


def _compose():
    import numpy as np
    cv2 = _st["cv2"]
    imgs = list(_st["wins"].values())
    if not imgs:
        return None
    if len(imgs) == 1:
        img = imgs[0]
    else:
        w = max(i.shape[1] for i in imgs)
        rows = []
        for i in imgs:
            if i.shape[1] != w:
                i = cv2.resize(i, (w, max(1, int(i.shape[0] * w / i.shape[1]))))
            rows.append(i)
        img = np.vstack(rows)
    h, w = img.shape[:2]
    m = max(h, w)
    _st["scale"] = 1.0
    if m > _MAX_SIDE:
        s = float(_MAX_SIDE) / m
        img = cv2.resize(img, (max(1, int(w * s)), max(1, int(h * s))), interpolation=cv2.INTER_AREA)
        _st["scale"] = 1.0 / s
    return img


def _flush():
    cv2 = _st["cv2"]
    img = _compose()
    _st["dirty"] = False
    if img is None:
        return
    ok, buf = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), 80])
    if ok:
        publish_jpeg(buf.tobytes())


def imshow(name, mat):
    _st["wins"][name] = _to_u8(mat)
    if time.time() - _st["last"] >= _MIN_DT:
        _flush()
    else:
        _st["dirty"] = True


def waitKey(delay=0):
    if _st["dirty"] and time.time() - _st["last"] >= _MIN_DT:
        _flush()
    end = None if delay <= 0 else time.time() + delay / 1000.0
    while True:
        _poll()
        if _st["keys"]:
            return _st["keys"].pop(0)
        if end is not None and time.time() >= end:
            return -1
        time.sleep(0.004)


def wait_close():
    # plt.show() semantics: block until the user taps Continue (or presses a key).
    _st["close"] = False
    while True:
        _poll()
        if _st["close"] or _st["keys"]:
            _st["close"] = False
            _st["keys"].clear()
            return
        time.sleep(0.02)


def destroyAllWindows():
    _st["wins"].clear()


def destroyWindow(name):
    _st["wins"].pop(name, None)


def setMouseCallback(name, fn, param=None):
    if fn is None:
        _st["cb"].pop(name, None)
    else:
        _st["cb"][name] = (fn, param)


def getWindowProperty(name, prop):
    return 1.0


def createTrackbar(name, win, value, count, on_change=None):
    _st["tb"][(win, name)] = value


def getTrackbarPos(name, win):
    return _st["tb"].get((win, name), 0)


def setTrackbarPos(name, win, pos):
    _st["tb"][(win, name)] = pos


def _noop(*a, **k):
    return None


def _patch_cv2(m):
    _st["cv2"] = m
    table = (
        ("imshow", imshow), ("waitKey", waitKey), ("waitKeyEx", waitKey),
        ("destroyAllWindows", destroyAllWindows), ("destroyWindow", destroyWindow),
        ("namedWindow", _noop), ("moveWindow", _noop), ("resizeWindow", _noop),
        ("setWindowTitle", _noop), ("setWindowProperty", _noop), ("startWindowThread", _noop),
        ("setMouseCallback", setMouseCallback), ("getWindowProperty", getWindowProperty),
        ("createTrackbar", createTrackbar), ("getTrackbarPos", getTrackbarPos),
        ("setTrackbarPos", setTrackbarPos),
    )
    for n, f in table:
        try:
            setattr(m, n, f)
        except Exception:
            pass


class _Finder:
    def find_spec(self, name, path, target=None):
        if name != "cv2":
            return None
        try:
            sys.meta_path.remove(self)
        except ValueError:
            return None
        import importlib.util
        spec = importlib.util.find_spec("cv2")
        if spec is None or spec.loader is None:
            return None
        loader = spec.loader
        orig = loader.exec_module

        def exec_module(mod):
            orig(mod)
            try:
                _patch_cv2(sys.modules.get("cv2", mod))
            except Exception:
                pass

        try:
            loader.exec_module = exec_module
        except Exception:
            return spec
        return spec


def _atexit():
    try:
        if _st["dirty"] and _st["cv2"] is not None:
            _flush()
    except Exception:
        pass


try:
    atexit.register(_atexit)
    if "cv2" in sys.modules:
        _patch_cv2(sys.modules["cv2"])
    else:
        sys.meta_path.insert(0, _Finder())
except Exception:
    pass
"""

val VIEW_MPL_BACKEND_SOURCE = """# ide-mpl-backend-v1: matplotlib backend that draws into the IDE frame view.
import io
import matplotlib
from matplotlib.backend_bases import FigureManagerBase, _Backend
from matplotlib.backends.backend_agg import FigureCanvasAgg
import ide_view_shim as _v
import com.codespace.ide.ide.theme.IdeTheme

try:
    if matplotlib.rcParams["figure.dpi"] < 140:
        matplotlib.rcParams["figure.dpi"] = 140
except Exception:
    pass


def _render(fig):
    fig.canvas.draw()
    from PIL import Image
    w, h = fig.canvas.get_width_height()
    im = Image.frombuffer("RGBA", (int(w), int(h)), fig.canvas.buffer_rgba(), "raw", "RGBA", 0, 1)
    bio = io.BytesIO()
    im.convert("RGB").save(bio, "JPEG", quality=88)
    _v._st["scale"] = 1.0
    _v.publish_jpeg(bio.getvalue())


class FigureManagerIde(FigureManagerBase):
    def show(self):
        _render(self.canvas.figure)


class FigureCanvasIde(FigureCanvasAgg):
    # matplotlib >= 3.6 takes the manager class from the CANVAS class.
    manager_class = FigureManagerIde


@_Backend.export
class _BackendIde(_Backend):
    FigureCanvas = FigureCanvasIde
    FigureManager = FigureManagerIde
    mainloop = staticmethod(_v.wait_close)
"""
