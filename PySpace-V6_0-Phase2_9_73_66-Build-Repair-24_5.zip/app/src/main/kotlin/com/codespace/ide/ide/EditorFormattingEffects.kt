package com.codespace.ide.ide

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.codespace.ide.ide.codeintel.PythonImportAnalysis
import com.codespace.ide.ide.codeintel.PythonLspController
import com.codespace.ide.ide.codeintel.PythonSyntaxDiagnostic
import com.codespace.ide.ide.codeintel.PythonUnusedImport
import com.codespace.ide.ide.editor.OpenTab
import com.codespace.ide.ide.editor.lineColAt

/** Owns asynchronous format/fix-import workflows while the editor retains document/UI ownership. */
@Composable
internal fun EditorFormattingEffects(
    tab: OpenTab,
    field: TextFieldValue,
    onFieldChange: (TextFieldValue) -> Unit,
    tabWidth: Int,
    isPythonLanguage: Boolean,
    reformatRequest: Int,
    onReformatConsumed: () -> Unit,
    fixImportsRequest: Int,
    onFixImportsConsumed: () -> Unit,
    analyzeImports: suspend (String) -> PythonImportAnalysis,
    pythonLspController: PythonLspController?,
    syntaxDiagnostics: List<PythonSyntaxDiagnostic>,
    syntaxValidatedSource: String?,
    toast: (String) -> Unit,
    applyReformat: (ReformatResult) -> Unit,
    onFlatIndentationDetected: (ReformatResult, ReformatResult) -> Unit,
    reportCursor: (Int, Int) -> Unit,
) {
    LaunchedEffect(reformatRequest, isPythonLanguage) {
        if (reformatRequest <= 0) return@LaunchedEffect
        if (!isPythonLanguage) {
            onReformatConsumed()
            return@LaunchedEffect
        }
        val base = field.text
        val caret = field.selection.start
        // Prefer pylsp formatting; the local source-preserving formatter remains
        // the offline fallback and handles the same original caret location.
        val serverFormatted = runCatching {
            pythonLspController?.formatText(tab.file, base, tabWidth)
        }.getOrNull()
        val formattedBase = serverFormatted ?: base
        val originalPosition = lineColAt(base, caret)
        val mappedCaret = run {
            val lines = formattedBase.split('\n')
            val line = (originalPosition[0] - 1).coerceIn(0, lines.lastIndex)
            lines.take(line).sumOf { it.length + 1 } +
                originalPosition[1].coerceIn(0, lines[line].length)
        }.coerceIn(0, formattedBase.length)
        val local = reformat(formattedBase, mappedCaret, tabWidth, rebuild = false)
        val result = if (local.text != base) local else ReformatResult(
            formattedBase,
            mappedCaret,
            if (formattedBase == base) 0 else 1,
            local.flat
        )
        // Do not reset the effect key until the suspendable formatter is done.
        onReformatConsumed()
        if (result.flat) {
            val rebuilt = reformat(formattedBase, mappedCaret, tabWidth, rebuild = true)
            // The UI asks before accepting reconstructed indentation.
            onFlatIndentationDetected(result, rebuilt)
        } else {
            applyReformat(result)
        }
    }

    LaunchedEffect(fixImportsRequest, isPythonLanguage) {
        if (fixImportsRequest <= 0) return@LaunchedEffect
        if (!isPythonLanguage) {
            onFixImportsConsumed()
            return@LaunchedEffect
        }
        val base = field.text
        val caret = field.selection.start
        // Keep the request key stable until the background analysis and edit finish;
        // otherwise changing it early cancels the in-flight effect.
        val analysis = withContext(Dispatchers.IO) { analyzeImports(base) }
        if (tab.text != base) {
            toast("Code changed during import analysis; run Fix Imports again")
            onFixImportsConsumed()
            return@LaunchedEffect
        }
        val unusedImports = if (analysis.available) {
            analysis.unusedImports
        } else if (syntaxValidatedSource == base) {
            syntaxDiagnostics.mapNotNull { diagnostic ->
                if (!diagnostic.message.contains("imported but unused", true)) return@mapNotNull null
                val imported = Regex("['‘](.+?)['’]\\s+imported but unused", RegexOption.IGNORE_CASE)
                    .find(diagnostic.message)?.groupValues?.getOrNull(1) ?: return@mapNotNull null
                PythonUnusedImport(diagnostic.line, diagnostic.column - 1, imported)
            }
        } else emptyList()
        val result = withContext(Dispatchers.Default) {
            PythonImportManager.fix(base, caret, unusedImports)
        }
        if (!result.changed) {
            val message = when {
                !analysis.available -> "No safe changes; Pyflakes analysis unavailable"
                analysis.unusedImports.isNotEmpty() -> "Unused imports need manual review in this context"
                else -> "Imports are already clean"
            }
            toast(message)
        } else {
            tab.applyEdit(result.text, field.selection.start, field.selection.end)
            onFieldChange(TextFieldValue(result.text, TextRange(result.caret)))
            val location = lineColAt(result.text, result.caret)
            reportCursor(location[0], location[1])
            val details = buildList {
                if (result.removedDuplicates > 0) add("${result.removedDuplicates} duplicate")
                if (result.removedUnused > 0) add("${result.removedUnused} unused")
                if (result.reordered > 0) add("${result.reordered} reordered")
            }
            val suffix = if (analysis.available) "" else " (unused analysis unavailable)"
            toast((if (details.isEmpty()) "Imports fixed" else "Imports fixed: " + details.joinToString(", ")) + suffix)
        }
        onFixImportsConsumed()
    }
}

