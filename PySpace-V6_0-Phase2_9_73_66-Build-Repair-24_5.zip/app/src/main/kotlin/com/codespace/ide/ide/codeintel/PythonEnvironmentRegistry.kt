package com.codespace.ide.ide.codeintel

import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import com.codespace.ide.ide.packages.PackageManagerViewModel

/**
 * Process-wide, project-scoped snapshot of the selected venv's installed packages.
 * PackageManagerViewModel updates it after pip mutations; the LSP controller uses
 * its revision to discard Jedi's environment/index caches.
 */
object PythonEnvironmentRegistry {
    private data class Snapshot(val revision: Long, val packages: Set<String>?)
    private val snapshots = ConcurrentHashMap<String, Snapshot>()
    private val revisions = AtomicLong(1)
    private val _revisionMap = MutableStateFlow<Map<String, Long>>(emptyMap())
    val revisionMap: StateFlow<Map<String, Long>> = _revisionMap.asStateFlow()

    fun projectKey(projectDir: File): String = runCatching { projectDir.canonicalPath }
        .getOrElse { projectDir.absolutePath }

    fun revision(projectDir: File): Long = snapshots[projectKey(projectDir)]?.revision ?: 0L

    /** Null means not yet inspected; an empty set means inspection completed and none are installed. */
    fun installedPackages(projectDir: File): Set<String>? = snapshots[projectKey(projectDir)]?.packages

    fun invalidate(projectDir: File) {
        val projectKey = projectKey(projectDir)
        val revision = revisions.getAndIncrement()
        snapshots[projectKey] = Snapshot(revision, emptySet())
        _revisionMap.value = _revisionMap.value + (projectKey to revision)
    }

    fun update(projectDir: File, packageNames: Collection<String>) {
        val normalized = packageNames.map { it.substringBefore('=')
            .trim().lowercase().replace('_', '-').replace('.', '-') }.filter { it.isNotBlank() }.toSet()
        val projectKey = projectKey(projectDir)
        val revision = revisions.getAndIncrement()
        snapshots[projectKey] = Snapshot(revision, normalized)
        _revisionMap.value = _revisionMap.value + (projectKey to revision)
    }

    fun moduleAvailable(projectDir: File, module: String): Boolean {
        val packages = installedPackages(projectDir) ?: return true // preserve legacy fallback until first inventory
        return moduleAvailableFromPackages(module, packages)
    }

    fun moduleAvailableFromPackages(module: String, packages: Set<String>): Boolean {
        val candidates = when (module) {
            "np", "numpy", "numpy.ndarray" -> setOf("numpy")
            "pd", "pandas" -> setOf("pandas")
            "plt", "matplotlib" -> setOf("matplotlib")
            "cv2" -> setOf("opencv-python", "opencv-python-headless", "opencv-contrib-python", "opencv-contrib-python-headless")
            "pygame" -> setOf("pygame")
            "kivy" -> setOf("kivy")
            "flask" -> setOf("flask")
            "requests" -> setOf("requests")
            else -> return true
        }
        return packages.any { it in candidates }
    }
}
