package com.codespace.ide.runtime

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/**
 * Central dispatcher policy for runtime and data-layer work.
 *
 * Keeping dispatchers behind one dependency makes threading decisions
 * consistent and allows deterministic dispatchers in unit tests. Do not use
 * [io] for CPU-heavy parsing, or [cpu] for blocking file/process/socket I/O.
 */
class RuntimeDispatchers(
    val main: CoroutineDispatcher,
    val io: CoroutineDispatcher,
    val cpu: CoroutineDispatcher,
) {
    companion object {
        /** Shared production policy; Dispatchers.IO is already a bounded,
         * elastic coroutine dispatcher managed by kotlinx.coroutines. */
        val Default: RuntimeDispatchers by lazy {
            RuntimeDispatchers(
                main = Dispatchers.Main.immediate,
                io = Dispatchers.IO,
                cpu = Dispatchers.Default,
            )
        }
    }
}

/**
 * Process-lifetime scope for work whose owner is the installed app runtime,
 * not an Activity or Composable (for example notebook document persistence).
 * It deliberately uses SupervisorJob so one failed task cannot cancel peers.
 * Android process death remains the final lifetime boundary.
 */
class RuntimeTaskScope(dispatchers: RuntimeDispatchers) {
    private val rootJob = SupervisorJob()
    val scope: CoroutineScope = CoroutineScope(rootJob + dispatchers.main)

    /** Reserved for explicit runtime shutdown in tests or controlled teardown. */
    fun cancel() {
        rootJob.cancel()
    }
}
