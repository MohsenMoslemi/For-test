package com.codespace.ide.ide.projects



import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.Base64

/**
 * Content-addressed incremental recovery store. Only new/changed file contents
 * are copied; manifests are atomically published and the previous manifest is
 * retained as a rollback point. The store is outside the Ubuntu workspace.
 */
class ProjectAutoRecoveryManager(private val recoveryRoot: File) {
    @Synchronized
    fun snapshot(project: PyProject, unsavedFiles: Map<String, String> = emptyMap(), forceHash: Boolean = false): Boolean {
        val source = project.dir
        if (!source.isDirectory) return false
        val key = safeKey(source.absolutePath)
        val store = File(recoveryRoot, key)
        val blobs = File(store, "blobs")
        if (!blobs.exists() && !blobs.mkdirs()) throw IllegalStateException("Could not prepare automatic recovery storage.")
        val currentManifest = File(store, MANIFEST)
        val previousManifest = File(store, PREVIOUS_MANIFEST)
        val oldEntries = readManifest(currentManifest) ?: readManifest(previousManifest)
        val oldByPath = oldEntries?.associateBy { it.path }.orEmpty()
        val excluded = excludedDirectories(source)
        val base = source.canonicalFile
        val overlays = LinkedHashMap<String, String>()
        unsavedFiles.forEach { (rawPath, content) ->
            val file = File(rawPath)
            val canonical = try { file.canonicalFile } catch (_: Exception) { return@forEach }
            if (isInside(base, canonical)) {
                val relative = canonical.relativeTo(base).invariantSeparatorsPath
                if (relative.isNotBlank() && relative.split('/').none { it in excluded }) overlays[relative] = content
            }
        }

        val entries = ArrayList<Entry>()
        val seen = HashSet<String>()
        source.walkTopDown().onEnter { dir ->
            dir == source || (dir.name !in excluded && isInside(base, dir))
        }.forEach { item ->
            if (item == source) return@forEach
            val canonical = try { item.canonicalFile } catch (_: Exception) { return@forEach }
            if (!isInside(base, canonical)) return@forEach
            val relative = item.relativeTo(source).invariantSeparatorsPath
            if (relative.split('/').any { it in excluded }) return@forEach
            if (item.isDirectory) {
                entries += Entry(relative, true, "", 0L, item.lastModified())
                seen += relative
            } else if (item.isFile && !item.name.endsWith(".pyc", true)) {
                val overlay = overlays[relative]
                val length = overlay?.toByteArray(Charsets.UTF_8)?.size?.toLong() ?: item.length()
                val modified = if (overlay != null) -1L else item.lastModified()
                val previous = oldByPath[relative]
                val hash = if (overlay == null && !forceHash && previous != null && !previous.directory &&
                    previous.length == length && previous.modified == modified && File(blobs, previous.hash).isFile
                ) previous.hash else if (overlay != null) storeBytes(blobs, overlay.toByteArray(Charsets.UTF_8)) else storeFile(blobs, item)
                entries += Entry(relative, false, hash, length, modified)
                seen += relative
            }
        }
        // Dirty editor buffers can represent newly-created files not yet on disk.
        overlays.forEach { (relative, content) ->
            if (relative !in seen) {
                val bytes = content.toByteArray(Charsets.UTF_8)
                entries += Entry(relative, false, storeBytes(blobs, bytes), bytes.size.toLong(), -1L)
                seen += relative
            }
        }
        if (!source.isDirectory) throw IllegalStateException("The project disappeared while its recovery copy was being created.")

        val manifestText = buildString {
            append("format=pyspace-auto-recovery\nversion=2\n")
            append("project=").append(encode(source.name)).append('\n')
            append("source=").append(encode(source.absolutePath)).append('\n')
            entries.sortedBy { it.path }.forEach { entry ->
                append(if (entry.directory) "D\t" else "F\t")
                append(encode(entry.path))
                if (!entry.directory) append('\t').append(entry.hash).append('\t').append(entry.length).append('\t').append(entry.modified)
                append('\n')
            }
        }
        val oldText = try { currentManifest.takeIf { it.isFile }?.readText(Charsets.UTF_8) } catch (_: Exception) { null }
        if (oldText == manifestText && readManifest(currentManifest) != null) return false
        val temp = File(store, "$MANIFEST.tmp")
        temp.writeText(manifestText, Charsets.UTF_8)
        FileOutputStream(temp, true).use { it.fd.sync() }
        if (currentManifest.isFile) {
            val prevTemp = File(store, "$PREVIOUS_MANIFEST.tmp")
            currentManifest.copyTo(prevTemp, overwrite = true)
            FileOutputStream(prevTemp, true).use { it.fd.sync() }
            if (previousManifest.exists() && !previousManifest.delete()) throw IllegalStateException("Could not rotate the previous recovery manifest.")
            if (!prevTemp.renameTo(previousManifest)) throw IllegalStateException("Could not preserve the previous recovery manifest.")
        }
        if (currentManifest.exists() && !currentManifest.delete()) throw IllegalStateException("Could not publish the recovery manifest.")
        if (!temp.renameTo(currentManifest)) throw IllegalStateException("Could not publish the recovery manifest.")
        // Keep blobs referenced by both committed manifests; older orphan blobs
        // are safe to remove only after both manifests have been committed.
        pruneBlobs(blobs, listOf(currentManifest, previousManifest))
        return true
    }

    fun hasSnapshot(project: PyProject): Boolean {
        val store = File(recoveryRoot, safeKey(project.dir.absolutePath))
        return readManifest(File(store, MANIFEST)) != null || readManifest(File(store, PREVIOUS_MANIFEST)) != null ||
            isLegacySnapshot(store)
    }

    @Synchronized
    fun restore(project: PyProject, workspace: File): File {
        val store = File(recoveryRoot, safeKey(project.dir.absolutePath))
        val manifestFile = sequenceOf(File(store, MANIFEST), File(store, PREVIOUS_MANIFEST))
            .firstOrNull { isCompleteManifest(it, store) }
        if (manifestFile == null) return restoreLegacy(project, workspace, store)
        val manifest = readManifest(manifestFile) ?: throw IllegalStateException("No valid automatic recovery copy is available.")
        val originalName = manifestFile.readLines(Charsets.UTF_8).firstOrNull { it.startsWith("project=") }
            ?.substringAfter('=')?.let(::decode)?.takeIf { it.isNotBlank() } ?: project.name
        require(validProjectName(originalName)) { "The recovery snapshot contains an invalid project name." }
        val target = uniqueTarget(workspace, originalName, "_recovered")
        val staging = File(workspace, ".pyspace-recovery-${System.nanoTime()}")
        if (!staging.mkdirs()) throw IllegalStateException("Could not prepare the project restore location.")
        try {
            val blobs = File(store, "blobs")
            manifest.forEach { entry ->
                val destination = File(staging, entry.path)
                require(isInside(staging.canonicalFile, destination.canonicalFile)) { "The recovery snapshot contains an unsafe path." }
                if (entry.directory) {
                    if (!destination.exists() && !destination.mkdirs()) throw IllegalStateException("Could not restore folder: ${entry.path}")
                } else {
                    val blob = File(blobs, entry.hash)
                    require(blob.isFile && blob.length() == entry.length && hashFile(blob) == entry.hash) {
                        "A recovery file is missing, damaged, or incomplete: ${entry.path}"
                    }
                    destination.parentFile?.let { if (!it.exists() && !it.mkdirs()) throw IllegalStateException("Could not prepare restored folder.") }
                    blob.inputStream().use { input -> FileOutputStream(destination).use { output ->
                        input.copyTo(output, COPY_BUFFER_SIZE); output.fd.sync()
                    } }
                }
            }
            if (!staging.renameTo(target)) throw IllegalStateException("Could not finish restoring the project. Check available storage.")
            return target
        } catch (error: Exception) {
            staging.deleteRecursively(); throw error
        }
    }

    private fun restoreLegacy(project: PyProject, workspace: File, store: File): File {
        val marker = File(store, LEGACY_MARKER)
        require(isLegacySnapshot(store)) { "No automatic recovery copy is available for this project." }
        val name = marker.readLines(Charsets.UTF_8).firstOrNull { it.startsWith("project=") }?.substringAfter('=') ?: project.name
        require(validProjectName(name)) { "The recovery snapshot contains an invalid project name." }
        val target = uniqueTarget(workspace, name, "_recovered")
        val staging = File(workspace, ".pyspace-recovery-${System.nanoTime()}")
        if (!staging.mkdirs()) throw IllegalStateException("Could not prepare the project restore location.")
        try {
            store.walkTopDown().forEach { item ->
                if (item == store || item == marker) return@forEach
                val relative = item.relativeTo(store).invariantSeparatorsPath
                val dest = File(staging, relative)
                if (item.isDirectory) dest.mkdirs() else if (item.isFile) {
                    dest.parentFile?.mkdirs(); item.copyTo(dest, overwrite = true)
                }
            }
            if (!staging.renameTo(target)) throw IllegalStateException("Could not finish restoring the project.")
            return target
        } catch (error: Exception) { staging.deleteRecursively(); throw error }
    }

    private fun storeFile(blobs: File, source: File): String {
        val initialLength = source.length()
        val initialModified = source.lastModified()
        val hash = hashFile(source)
        if (source.length() != initialLength || source.lastModified() != initialModified) {
            throw IllegalStateException("A project file changed during recovery capture: ${source.name}")
        }
        val target = File(blobs, hash)
        if (target.isFile) return hash

        // Only write a new blob after hashing proves that this content is not
        // already stored. This keeps event-triggered reconciliation read-only
        // for unchanged files instead of copying the whole project to temp.
        val temp = File(blobs, ".${System.nanoTime()}.tmp")
        try {
            BufferedInputStream(FileInputStream(source)).use { input -> FileOutputStream(temp).use { output ->
                input.copyTo(output, COPY_BUFFER_SIZE)
                output.fd.sync()
            } }
            if (source.length() != initialLength || source.lastModified() != initialModified ||
                temp.length() != initialLength || hashFile(temp) != hash) {
                throw IllegalStateException("A project file changed during recovery capture: ${source.name}")
            }
            if (target.exists()) temp.delete()
            else if (!temp.renameTo(target)) throw IllegalStateException("Could not commit a recovery data block.")
            return hash
        } catch (error: Exception) { temp.delete(); throw error }
    }

    private fun storeBytes(blobs: File, bytes: ByteArray): String {
        val hash = MessageDigest.getInstance("SHA-256").digest(bytes).toHex()
        val target = File(blobs, hash)
        if (!target.isFile) {
            val temp = File(blobs, ".${System.nanoTime()}.tmp")
            FileOutputStream(temp).use { it.write(bytes); it.fd.sync() }
            if (!temp.renameTo(target)) { temp.delete(); if (!target.isFile) throw IllegalStateException("Could not commit a recovery data block.") }
        }
        return hash
    }

    private fun readManifest(file: File): List<Entry>? {
        return try {
            if (!file.isFile) return null
            val lines = file.readLines(Charsets.UTF_8)
            if (lines.size < 2 || lines[0] != "format=pyspace-auto-recovery" || lines[1] != "version=2") return null
            lines.drop(2).filter { it.isNotBlank() && !it.startsWith("project=") && !it.startsWith("source=") }.map { line ->
                val parts = line.split('\t')
                require(parts.size >= 2)
                val path = decode(parts[1])
                require(path.isNotBlank() && !path.startsWith('/') && path.split('/').none { it.isBlank() || it == "." || it == ".." })
                if (parts[0] == "D") Entry(path, true, "", 0L, 0L) else {
                    require(parts.size == 5 && parts[2].matches(Regex("[a-f0-9]{64}")))
                    Entry(path, false, parts[2], parts[3].toLong(), parts[4].toLong())
                }
            }
        } catch (_: Exception) { null }
    }

    private fun hashFile(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        BufferedInputStream(FileInputStream(file)).use { input ->
            val buffer = ByteArray(COPY_BUFFER_SIZE)
            while (true) { val count = input.read(buffer); if (count < 0) break; digest.update(buffer, 0, count) }
        }
        return digest.digest().toHex()
    }

    private fun isCompleteManifest(file: File, store: File): Boolean {
        val entries = readManifest(file) ?: return false
        val blobs = File(store, "blobs")
        return entries.asSequence().filterNot { it.directory }.all { entry ->
            val blob = File(blobs, entry.hash)
            blob.isFile && blob.length() == entry.length && try { hashFile(blob) == entry.hash } catch (_: Exception) { false }
        }
    }

    private fun pruneBlobs(blobs: File, manifests: List<File>) {
        val keep = manifests.flatMap { readManifest(it).orEmpty() }.filterNot { it.directory }.map { it.hash }.toHashSet()
        blobs.listFiles()?.filter { it.isFile && !it.name.startsWith(".") && it.name !in keep }?.forEach { it.delete() }
    }

    private fun isLegacySnapshot(store: File): Boolean {
        val marker = File(store, LEGACY_MARKER)
        return store.isDirectory && marker.isFile && try {
            marker.readLines(Charsets.UTF_8).any { it == "format=pyspace-auto-recovery" } &&
                marker.readLines(Charsets.UTF_8).any { it == "version=1" }
        } catch (_: Exception) { false }
    }

    private fun excludedDirectories(project: File) = setOf(projectVenvName(project), ".venv", "venv", "env", ".env", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".tox", ".nox")
    private fun isInside(base: File, child: File) = child.toPath().startsWith(base.toPath())
    private fun safeKey(value: String) = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8)).toHex()
    private fun encode(value: String) = Base64.getUrlEncoder().withoutPadding().encodeToString(value.toByteArray(Charsets.UTF_8))
    private fun decode(value: String) = String(Base64.getUrlDecoder().decode(value), Charsets.UTF_8)
    private fun validProjectName(name: String) = name.isNotBlank() && name != "." && name != ".." && !name.contains('/') && !name.contains('\\')
    private fun uniqueTarget(workspace: File, name: String, suffix: String): File {
        var target = File(workspace, name); var index = 1
        while (target.exists()) target = File(workspace, "$name$suffix${index++}")
        return target
    }
    private fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }

    private data class Entry(val path: String, val directory: Boolean, val hash: String, val length: Long, val modified: Long)

    companion object {
        private const val COPY_BUFFER_SIZE = 64 * 1024
        private const val MANIFEST = "manifest.v2"
        private const val PREVIOUS_MANIFEST = "manifest.previous"
        private const val LEGACY_MARKER = ".pyspace-recovery-info"
    }
}
