package com.codespace.ide.ide.shell

import java.io.File
import com.codespace.ide.ide.ProjectViewModelStoreRegistry
import com.codespace.ide.ide.notebook.NotebookRepository
import com.codespace.ide.ide.projects.PyProject
import com.codespace.ide.ide.settings.IdePrefs
import com.codespace.ide.ide.testing.TestControllerRegistry

/** Performs deterministic teardown of project-scoped IDE resources on deletion. */
internal class ProjectLifecycleCleanup(
    private val features: ProjectFeatureRegistry,
    private val notebookRepository: NotebookRepository,
    private val stores: ProjectViewModelStoreRegistry?,
    private val prefs: IdePrefs,
) {
    fun clearDeletedProject(projectDir: File) {
        val path = projectDir.absolutePath
        val editor = features.editors.remove(path)
        editor?.session?.let { session ->
            notebookRepository.releaseProject(session.project)
            session.closeAllTabs()
        }
        stores?.clearProject(path)
        features.removeProject(path)
        TestControllerRegistry.remove(path)
        try { prefs.setSessionJson(path, "") } catch (_: Exception) { }
    }

    fun clearDeletedProject(project: PyProject) = clearDeletedProject(project.dir)
}
