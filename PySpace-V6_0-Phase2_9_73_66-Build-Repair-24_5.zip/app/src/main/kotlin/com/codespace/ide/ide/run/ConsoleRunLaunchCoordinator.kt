package com.codespace.ide.ide.run
import com.codespace.ide.ide.RunInfo


/** Immutable inputs required to publish a fully prepared Console launch. */
data class ConsoleRunLaunchRequest(
    val projectGuestPath: String,
    val title: String,
    val conflictKeys: Set<String>,
    val guiPrefix: String,
    val cameraPrefix: String,
    val programCommand: String,
    val bridgeUrl: String?,
    val bridgeToken: String,
    val usesDisplay: Boolean,
    val previousRun: RunInfo?,
)

/** Result consumed by the presentation host to update its Compose-backed state. */
data class PreparedConsoleRunLaunch(
    val runId: String,
    val command: String,
)

data class ConsoleRunLaunch(
    val command: String,
    val runInfo: RunInfo,
)

/**
 * Owns the final Console launch transaction: id allocation, guest bridge hook,
 * command assembly, retirement of the previous Console record, and publication
 * of the replacement in the shared RunOrchestrator registry.
 *
 * It deliberately does not own PTYs, Compose state, camera/display resources,
 * source analysis, or asynchronous web/camera preparation.
 */
class ConsoleRunLaunchCoordinator(
    private val runs: RunOrchestrator,
) {
    fun prepare(request: ConsoleRunLaunchRequest): PreparedConsoleRunLaunch {
        val runId = runs.newRunId()
        val hookPrefix = RunCommandBuilder.buildHookPrefix(
            bridgeUrl = request.bridgeUrl,
            token = request.bridgeToken,
            runId = runId,
        )
        val command = RunCommandBuilder.buildConsoleCommand(
            projectGuestPath = request.projectGuestPath,
            guiPrefix = request.guiPrefix,
            cameraPrefix = request.cameraPrefix,
            hookPrefix = hookPrefix,
            programCommand = request.programCommand,
        )
        return PreparedConsoleRunLaunch(runId, command)
    }

    /** Publish only after the host has committed its matching Console state. */
    fun publish(
        request: ConsoleRunLaunchRequest,
        prepared: PreparedConsoleRunLaunch,
    ): ConsoleRunLaunch {
        request.previousRun?.let { previous -> runs.finish(previous.id) }
        val runInfo = runs.registerConsole(
            id = prepared.runId,
            cwd = request.projectGuestPath,
            title = request.title,
            keys = request.conflictKeys,
            usesDisplay = request.usesDisplay,
        )
        return ConsoleRunLaunch(command = prepared.command, runInfo = runInfo)
    }
}
