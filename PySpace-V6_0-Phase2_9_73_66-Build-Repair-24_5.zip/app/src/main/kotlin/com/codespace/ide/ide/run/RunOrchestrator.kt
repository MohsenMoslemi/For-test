package com.codespace.ide.ide.run

import android.system.Os
import android.system.OsConstants
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import com.codespace.ide.ide.RunHub
import com.codespace.ide.ide.RunInfo
import com.codespace.ide.runtime.RuntimeTaskScope

/**
 * The single application-level policy boundary for IDE run registration,
 * conflict lookup, completion and terminal process-group shutdown.
 *
 * RunHub remains the observable registry used by the foreground service and
 * existing UI. This class coordinates policy around that registry; it does
 * not own PTYs, PRoot, the guest bridge, display servers or WebViews.
 */
class RunOrchestrator(
    private val hub: RunHub,
    private val processSignaler: RunProcessSignaler = AndroidRunProcessSignaler,
) {
    private val stoppingIds = ConcurrentHashMap.newKeySet<String>()
    fun newRunId(): String = hub.newId()

    fun registerConsole(
        id: String,
        cwd: String,
        title: String,
        keys: Set<String>,
        usesDisplay: Boolean = false,
    ): RunInfo {
        val info = RunInfo(id, "Console", cwd, title, keys)
        info.usesDisplay = usesDisplay
        hub.add(info)
        return info
    }

    /** Registers a Terminal run using the id allocated during bridge prepare. */
    fun registerTerminal(
        id: String,
        cwd: String,
        title: String,
        keys: Set<String>,
        pid: Int,
        pgid: Int,
        usesDisplay: Boolean = false,
    ): RunInfo {
        val info = RunInfo(id, "Terminal", cwd, title, keys)
        info.pid = pid
        info.pgid = pgid
        info.usesDisplay = usesDisplay
        hub.add(info)
        return info
    }

    fun get(id: String): RunInfo? = hub.get(id)

    fun running(): List<RunInfo> = hub.running()

    fun findConflict(keys: Set<String>, exceptId: String? = null): RunInfo? =
        hub.findConflict(keys, exceptId)

    /** Marks a run complete. Repeated exit/cleanup signals are harmless. */
    fun finish(id: String) {
        stoppingIds.remove(id)
        hub.finish(id)
    }

    /**
     * Fallback for the notification action when no IDE composition is alive.
     * UI-owned PTY surfaces are closed when their composition is disposed, so
     * their registry rows are stale; Terminal process groups are still signalled
     * here and escalated from the application-lifetime scope.
     */
    fun stopAllWithoutUi(
        scope: CoroutineScope,
        gracePeriodMs: Long = DEFAULT_STOP_GRACE_MS,
    ) {
        val active = running()
        active.filter { it.source == "Console" }.forEach { finish(it.id) }
        active.filter { it.source != "Console" }.forEach {
            // The bridge belongs to the disposed IDE host, so no done callback
            // can retire these rows. Finish after the stop window ourselves.
            stopTerminal(it, scope, gracePeriodMs, finishAfterGrace = true)
        }
    }

    /**
     * A newly-created IDE host means the previous Activity's PTY surfaces have
     * been disposed. Retire their old registry rows so notifications and run
     * conflict checks cannot keep showing dead sessions after recreation.
     */
    fun reconcileAfterUiHostRecreated() {
        running().forEach { finish(it.id) }
    }

    /**
     * Stops a Terminal-launched process group. SIGKILL is sent after the grace
     * period only if the run is still registered as running. Production callers
     * pass the application RuntimeTaskScope so Activity recreation cannot cancel
     * the escalation between SIGTERM and SIGKILL.
     */
    fun stopTerminal(
        info: RunInfo,
        scope: CoroutineScope,
        gracePeriodMs: Long = DEFAULT_STOP_GRACE_MS,
        finishAfterGrace: Boolean = false,
    ) {
        if (!info.running || !stoppingIds.add(info.id)) return
        signal(info, OsConstants.SIGTERM)
        scope.launch {
            try {
                delay(gracePeriodMs.coerceAtLeast(0L))
                if (info.running) signal(info, OsConstants.SIGKILL)
                if (finishAfterGrace && info.running) finish(info.id)
            } finally {
                stoppingIds.remove(info.id)
            }
        }
    }

    fun stopAllTerminal(scope: CoroutineScope) {
        running().filter { it.source != "Console" }.forEach { stopTerminal(it, scope) }
    }

    private fun signal(info: RunInfo, signal: Int) {
        try {
            processSignaler.signal(info, signal)
        } catch (_: Exception) {
            // The process may have exited between the state check and signal.
            // The bridge's done event / process reaper remains authoritative.
        }
    }

    companion object {
        const val DEFAULT_STOP_GRACE_MS = 2_500L
    }
}

/** Small seam so process signalling policy can be smoke-tested without Android. */
fun interface RunProcessSignaler {
    fun signal(info: RunInfo, signal: Int)
}

private object AndroidRunProcessSignaler : RunProcessSignaler {
    override fun signal(info: RunInfo, signal: Int) {
        val pgid = info.pgid
        val pid = info.pid
        if (pgid > 1 && pgid != android.os.Process.myPid()) {
            Os.kill(-pgid, signal)
        } else if (pid > 1 && pid != android.os.Process.myPid()) {
            Os.kill(pid, signal)
        }
    }
}
