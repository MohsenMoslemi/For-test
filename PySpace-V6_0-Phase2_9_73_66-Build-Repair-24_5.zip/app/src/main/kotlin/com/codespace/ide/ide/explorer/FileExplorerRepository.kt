package com.codespace.ide.ide.explorer

import java.io.File
import java.io.IOException
import java.nio.file.Files
import com.codespace.ide.runtime.RuntimeDispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import com.codespace.ide.ide.codeintel.ProjectTransactionManager

/** A render-ready row produced away from the Compose main thread. */
data class ExplorerTreeNode(
    val file: File,
    val depth: Int,
    val overflow: Int = 0,
    val label: String? = null,
    val isPkg: Boolean = false,
    val isDirectory: Boolean,
)

data class ExplorerFileEntry(val file: File, val isDirectory: Boolean)

data class ExplorerSnapshot(
    val nodes: List<ExplorerTreeNode>,
    val fileCount: Int?,
    val fileCountCapped: Boolean,
)

/** All filesystem access for the editor's project drawer. */
interface FileExplorerRepository {
    suspend fun loadSnapshot(
        root: File,
        expanded: Map<String, Boolean>,
        sortByType: Boolean,
        showHidden: Boolean,
        collapseChains: Boolean,
        countFiles: Boolean,
    ): ExplorerSnapshot

    suspend fun findFirstMatch(root: File, query: String, showHidden: Boolean): File?
    suspend fun listAllDirectories(root: File, showHidden: Boolean): List<String>
    suspend fun listDestinationChildren(directory: File, root: File): List<ExplorerFileEntry>
    suspend fun createEntry(root: File, directory: File, name: String, isDirectory: Boolean): File
    suspend fun renameEntry(root: File, source: File, newName: String): File
    suspend fun deleteEntry(root: File, target: File)
    suspend fun copyEntry(root: File, source: File, destination: File): File
    suspend fun moveEntry(root: File, source: File, destination: File): File
}

class DefaultFileExplorerRepository(
    private val dispatchers: RuntimeDispatchers = RuntimeDispatchers.Default,
) : FileExplorerRepository {
    override suspend fun loadSnapshot(
        root: File,
        expanded: Map<String, Boolean>,
        sortByType: Boolean,
        showHidden: Boolean,
        collapseChains: Boolean,
        countFiles: Boolean,
    ): ExplorerSnapshot = withContext(dispatchers.io) {
        require(root.isDirectory) { "Project directory is unavailable" }
        val context = currentCoroutineContext()
        val out = ArrayList<ExplorerTreeNode>(128)
        out += ExplorerTreeNode(root, 0, isDirectory = true)
        var visitedRows = 0

        fun checkCancellation() {
            if ((visitedRows++ and 63) == 0) context.ensureActive()
        }

        fun children(dir: File): List<File> {
            checkCancellation()
            // Filter before sorting. Hidden Files reveals dotfiles and managed
            // folders; managed folders are still traversed only on explicit expansion.
            val entries = dir.listFiles { _, name -> isVisibleTreeEntry(dir, name, showHidden) }
                ?: return emptyList()
            return entries.asSequence()
                .sortedWith(
                    if (sortByType) compareBy<File>({ it.extension.lowercase() }, { it.name.lowercase() })
                    else compareBy<File>({ !it.isDirectory }, { it.name.lowercase() })
                )
                .toList()
        }

        fun collapse(start: File): Pair<File, List<String>> {
            var current = start
            val names = mutableListOf(start.name)
            val seen = HashSet<String>()
            seen += safeCanonicalPath(start)
            while (names.size < MAX_COLLAPSE_DEPTH && !isSymbolicLink(current)) {
                val next = children(current)
                if (next.size != 1 || !next[0].isDirectory || isSymbolicLink(next[0])) break
                val candidate = next[0]
                val canonical = safeCanonicalPath(candidate)
                if (!seen.add(canonical)) break
                current = candidate
                names += current.name
            }
            return current to names
        }

        fun appendChildren(directory: File, depth: Int, ancestors: Set<String>) {
            context.ensureActive()
            // Managed directories (notably Python virtual environments) are
            // intentionally excluded from background scans, but an explicit
            // user expansion is allowed to enumerate this directory's direct
            // children. Recursion still happens only for individually expanded
            // rows, keeping large site-packages trees lazy and bounded.
            if (depth > MAX_DEPTH || out.size >= MAX_NODES || isSymbolicLink(directory)) return
            val canonical = safeCanonicalPath(directory)
            if (canonical in ancestors) return
            val nextAncestors = ancestors + canonical
            val all = children(directory)
            val visible = all.take(MAX_CHILDREN)
            for (entry in visible) {
                context.ensureActive()
                if (out.size >= MAX_NODES) break
                if (!entry.isDirectory) {
                    out += ExplorerTreeNode(entry, depth, isDirectory = false)
                    continue
                }
                // Keep every directory as its own row. Collapsing one-child
                // chains made expansion state belong to the deepest path and
                // confused nested-folder toggles after create/move operations.
                val (deep, names) = entry to listOf(entry.name)
                val direct = if (isSymbolicLink(deep) || isManagedTreeDirectory(deep)) emptyList() else children(deep)
                val isPackage = direct.any {
                    it.isFile && it.extension.lowercase() in PACKAGE_EXTENSIONS
                }
                out += ExplorerTreeNode(
                    file = deep,
                    depth = depth,
                    label = names.takeIf { it.size > 1 }?.joinToString("/"),
                    isPkg = isPackage,
                    isDirectory = true,
                )
                if (expanded[deep.absolutePath] == true) {
                    appendChildren(deep, depth + 1, nextAncestors)
                }
            }
            if (all.size > visible.size && out.size < MAX_NODES) {
                out += ExplorerTreeNode(directory, depth, overflow = all.size - visible.size, isDirectory = true)
            }
        }

        if (expanded[root.absolutePath] == true) {
            appendChildren(root, 1, emptySet())
        }
        val (count, capped) = if (countFiles) countFilesBounded(root, context) else null to false
        ExplorerSnapshot(out.toList(), count, capped)
    }

    override suspend fun findFirstMatch(root: File, query: String, showHidden: Boolean): File? =
        withContext(dispatchers.io) {
            val needle = query.trim().lowercase()
            if (needle.length < 2 || !root.isDirectory) return@withContext null
            val context = currentCoroutineContext()
            val stack = ArrayDeque<File>()
            stack.add(root)
            var visited = 0
            while (stack.isNotEmpty() && visited < MAX_SEARCH_ENTRIES) {
                if ((visited++ and 63) == 0) context.ensureActive()
                val current = stack.removeLast()
                val children = try {
                    current.listFiles { _, name -> isVisibleTreeEntry(current, name, showHidden) } ?: continue
                } catch (_: SecurityException) { continue }
                for (child in children) {
                    if (child.name.lowercase().contains(needle)) return@withContext child
                    if (child.isDirectory && !isSymbolicLink(child) && !isManagedTreeDirectory(child)) stack.add(child)
                    if (stack.size + visited >= MAX_SEARCH_ENTRIES) break
                }
            }
            null
        }

    override suspend fun listAllDirectories(root: File, showHidden: Boolean): List<String> =
        withContext(dispatchers.io) {
            require(root.isDirectory) { "Project directory is unavailable" }
            val context = currentCoroutineContext()
            val stack = ArrayDeque<File>()
            val result = ArrayList<String>()
            val seen = HashSet<String>()
            stack.add(root)
            var visited = 0
            while (stack.isNotEmpty() && result.size < MAX_EXPAND_DIRECTORIES) {
                if ((visited++ and 63) == 0) context.ensureActive()
                val directory = stack.removeLast()
                val canonical = safeCanonicalPath(directory)
                if (!seen.add(canonical)) continue
                result += directory.absolutePath
                val entries = try {
                    directory.listFiles { _, name -> isVisibleTreeEntry(directory, name, showHidden) } ?: continue
                } catch (_: SecurityException) { continue }
                for (entry in entries) {
                    if (!entry.isDirectory || isSymbolicLink(entry) || isManagedTreeDirectory(entry)) continue
                    stack.add(entry)
                }
            }
            result
        }

    override suspend fun listDestinationChildren(directory: File, root: File): List<ExplorerFileEntry> =
        withContext(dispatchers.io) {
            require(isInside(root, directory) && directory.isDirectory) { "Invalid destination directory" }
            (directory.listFiles { _, name -> isVisibleTreeEntry(directory, name, false) } ?: emptyArray())
                .sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))
                .take(MAX_CHILDREN)
                .map { ExplorerFileEntry(it, it.isDirectory) }
        }

    override suspend fun createEntry(root: File, directory: File, name: String, isDirectory: Boolean): File =
        ProjectTransactionManager.execute(root, "CREATE", listOf(File(directory, name))) {
        withContext(dispatchers.io) {
            val clean = validateName(name)
            require(isInside(root, directory) && directory.isDirectory) { "Parent directory is unavailable" }
            val target = uniqueDestination(directory, clean)
            val created = if (isDirectory) target.mkdir() else target.createNewFile()
            if (!created) throw IOException("Could not create ${if (isDirectory) "folder" else "file"}")
            if (!isDirectory && clean.endsWith(".py", ignoreCase = true)) {
                try { target.writeText("# $clean\n") } catch (error: Exception) {
                    target.delete()
                    throw error
                }
            }
            target
        }
    }

    override suspend fun renameEntry(root: File, source: File, newName: String): File =
        ProjectTransactionManager.execute(root, "RENAME", listOf(source, File(source.parentFile, newName))) {
        withContext(dispatchers.io) {
            require(isInside(root, source) && safeCanonicalPath(source) != safeCanonicalPath(root) && source.exists()) {
                "Source is unavailable or is the project root"
            }
            val target = File(source.parentFile ?: throw IOException("Missing parent"), validateName(newName))
            require(!target.exists()) { "An item with this name already exists" }
            require(isInside(root, target) && !isSymbolicLink(source)) { "Invalid rename target" }

            // Prepare import rewrites before touching the filesystem. Only
            // Python module/package renames produce edits; unrelated names are
            // left completely untouched.
            val importUpdates = PythonImportPathRefactor.collect(root, source, target)
            val staged = LinkedHashMap<File, File>()
            val backups = LinkedHashMap<File, File>()
            var sourceMoved = false
            try {
                if (!source.renameTo(target)) throw IOException("Rename failed")
                sourceMoved = true
                // Resolve files inside a renamed directory against their new
                // paths. This also keeps absolute imports within a package in sync.
                for ((originalFile, content) in importUpdates) {
                    val sourcePath = source.canonicalFile.absolutePath
                    val originalPath = originalFile.canonicalFile.absolutePath
                    val effectiveFile = when {
                        originalPath == sourcePath -> target
                        originalPath.startsWith(sourcePath + File.separator) ->
                            File(target, originalFile.canonicalFile.relativeTo(source.canonicalFile).invariantSeparatorsPath)
                        else -> originalFile
                    }
                    val temp = File(effectiveFile.parentFile, ".${effectiveFile.name}.import-rename-${System.nanoTime()}.tmp")
                    temp.writeText(content, Charsets.UTF_8)
                    staged[effectiveFile] = temp
                }
                for ((file, temp) in staged) {
                    val backup = File(file.parentFile, ".${file.name}.import-rename-backup-${System.nanoTime()}")
                    if (!file.renameTo(backup)) throw IOException("Unable to stage import update: ${file.name}")
                    backups[file] = backup
                    if (!temp.renameTo(file)) throw IOException("Unable to update import: ${file.name}")
                }
                backups.values.forEach { it.delete() }
                target
            } catch (error: Exception) {
                // Restore every import file and move the renamed item back.
                for ((file, backup) in backups.entries.toList().asReversed()) {
                    runCatching { file.delete(); backup.renameTo(file) }
                }
                staged.values.forEach { runCatching { it.delete() } }
                if (sourceMoved) runCatching { target.renameTo(source) }
                throw IOException(error.message ?: "Rename transaction failed", error)
            }
        }
    }

    override suspend fun deleteEntry(root: File, target: File) {
        ProjectTransactionManager.deleteRecoverably(root, target) { quarantined ->
            if (!deleteWithoutFollowingLinks(quarantined)) {
                throw IOException("Delete cleanup is incomplete; the item remains in transaction quarantine")
            }
        }
    }

    override suspend fun copyEntry(root: File, source: File, destination: File): File =
        ProjectTransactionManager.execute(root, "COPY", listOf(source, destination)) {
        withContext(dispatchers.io) {
            validateTransfer(root, source, destination)
            val target = uniqueDestination(destination, source.name)
            copyAtomically(source, target)
            target
        }
    }

    override suspend fun moveEntry(root: File, source: File, destination: File): File =
        ProjectTransactionManager.execute(root, "MOVE", listOf(source, destination)) {
        withContext(dispatchers.io) {
            validateTransfer(root, source, destination)
            require(source.parentFile?.let(::safeCanonicalPath) != safeCanonicalPath(destination)) {
                "Item is already in this folder"
            }
            val target = uniqueDestination(destination, source.name)
            if (source.renameTo(target)) return@withContext target
            copyAtomically(source, target)
            val removed = withContext(NonCancellable) { deleteWithoutFollowingLinks(source) }
            if (!removed) {
                withContext(NonCancellable) { deleteWithoutFollowingLinks(target) }
                throw IOException("Move could not remove the original item")
            }
            target
        }
    }

    private fun countFilesBounded(root: File, context: kotlin.coroutines.CoroutineContext): Pair<Int, Boolean> {
        val stack = ArrayDeque<File>()
        stack.add(root)
        var count = 0
        var visited = 0
        while (stack.isNotEmpty()) {
            if ((visited++ and 127) == 0) context.ensureActive()
            val directory = stack.removeLast()
            val entries = try {
                directory.listFiles { _, name -> !isManagedTreeDirectory(File(directory, name)) && !name.startsWith(".") } ?: continue
            } catch (_: SecurityException) { continue }
            for (entry in entries) {
                if (entry.isDirectory) {
                    if (!isSymbolicLink(entry)) stack.add(entry)
                } else if (entry.isFile) {
                    count++
                    if (count >= MAX_COUNTED_FILES) return count to true
                }
            }
        }
        return count to false
    }

    private fun validateTransfer(root: File, source: File, destination: File) {
        require(isInside(root, source) && safeCanonicalPath(source) != safeCanonicalPath(root) && source.exists()) {
            "Invalid source item"
        }
        require(isInside(root, destination) && destination.isDirectory) { "Invalid destination folder" }
        val sourcePath = source.absoluteFile.normalizePath()
        val destinationPath = destination.absoluteFile.normalizePath()
        require(destinationPath != sourcePath && !destinationPath.startsWith(sourcePath + File.separator)) {
            "Cannot copy or move a folder into itself"
        }
    }

    private suspend fun copyAtomically(source: File, target: File) {
        val context = currentCoroutineContext()
        val temp = File(target.parentFile, ".${target.name}.copying-${System.nanoTime()}")
        try {
            copyWithoutFollowingLinks(source, temp, context)
            context.ensureActive()
            if (!temp.renameTo(target)) throw IOException("Could not finalize copied item")
        } catch (error: Exception) {
            withContext(NonCancellable) { deleteWithoutFollowingLinks(temp) }
            throw error
        }
    }

    private fun copyWithoutFollowingLinks(
        source: File,
        target: File,
        context: kotlin.coroutines.CoroutineContext,
    ) {
        val pending = ArrayDeque<Pair<File, File>>()
        pending.add(source to target)
        while (pending.isNotEmpty()) {
            context.ensureActive()
            val (from, to) = pending.removeLast()
            if (isSymbolicLink(from)) {
                Files.createSymbolicLink(to.toPath(), Files.readSymbolicLink(from.toPath()))
            } else if (from.isDirectory) {
                if (!to.mkdirs()) throw IOException("Could not create destination folder")
                val entries = from.listFiles() ?: throw IOException("Could not read ${from.name}")
                for (entry in entries) pending.add(entry to File(to, entry.name))
            } else {
                from.inputStream().use { input ->
                    to.outputStream().use { output ->
                        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                        while (true) {
                            context.ensureActive()
                            val read = input.read(buffer)
                            if (read < 0) break
                            output.write(buffer, 0, read)
                        }
                        output.flush()
                    }
                }
            }
        }
    }

    private fun deleteWithoutFollowingLinks(target: File): Boolean {
        val pending = ArrayDeque<Pair<File, Boolean>>()
        pending.add(target to false)
        while (pending.isNotEmpty()) {
            val (current, visited) = pending.removeLast()
            if (current.isDirectory && !isSymbolicLink(current) && !visited) {
                val entries = current.listFiles() ?: return false
                pending.add(current to true)
                for (entry in entries) pending.add(entry to false)
            } else if (!current.delete()) {
                if (current.exists() || isSymbolicLink(current)) return false
            }
        }
        return true
    }

    private fun uniqueDestination(directory: File, name: String): File {
        val normalized = name.trim().replace(Regex("\\s+"), "_")
        var candidate = File(directory, normalized)
        if (!candidate.exists() && !isSymbolicLink(candidate)) return candidate
        val dot = normalized.lastIndexOf('.')
        val base = if (dot > 0) normalized.substring(0, dot) else normalized
        val extension = if (dot > 0) normalized.substring(dot) else ""
        var index = 1
        while (index < 1000) {
            candidate = File(directory, "${base}_$index$extension")
            if (!candidate.exists() && !isSymbolicLink(candidate)) return candidate
            index++
        }
        throw IOException("Could not find an available destination name")
    }

    private fun validateName(name: String): String {
        val clean = name.trim().replace(Regex("\\s+"), "_")
        require(clean.isNotEmpty() && clean != "." && clean != ".." &&
            !clean.contains('/') && !clean.contains('\\') && !clean.contains('\u0000')) { "Invalid name" }
        return clean
    }

    private fun isInside(root: File, candidate: File): Boolean {
        val rootPath = safeCanonicalPath(root).trimEnd(File.separatorChar)
        val candidatePath = safeCanonicalPath(candidate)
        return candidatePath == rootPath || candidatePath.startsWith(rootPath + File.separator)
    }

    private fun safeCanonicalPath(file: File): String = try { file.canonicalPath } catch (_: Exception) { file.absoluteFile.normalizePath() }
    private fun File.normalizePath(): String = toPath().normalize().toAbsolutePath().toString()
    private fun isSymbolicLink(file: File): Boolean = try { Files.isSymbolicLink(file.toPath()) } catch (_: Exception) { false }

    private companion object {
        const val MAX_CHILDREN = 300
        const val MAX_COLLAPSE_DEPTH = 32
        const val MAX_DEPTH = 64
        const val MAX_NODES = 2500
        const val MAX_SEARCH_ENTRIES = 2000
        const val MAX_EXPAND_DIRECTORIES = 5_000
        const val MAX_COUNTED_FILES = 100_000
        val PACKAGE_EXTENSIONS = setOf("py", "kt", "java")
    }
}
