package com.codespace.ide.ide.editor

import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.geometry.Offset

/**
 * Compose-owned transient state for one editor surface's pinch-zoom session.
 *
 * Keeping the preview, commit hand-off and gutter measurements together makes
 * their lifetime explicit and prevents individual zoom flags from drifting
 * into unrelated editor state declarations. The zoom workflows still receive
 * the underlying MutableState handles so their frame-by-frame behavior stays
 * unchanged.
 */
internal class EditorZoomSessionState {
    val scaleY: MutableState<Float> = mutableStateOf(1f)
    val scaleX: MutableState<Float> = mutableStateOf(1f)
    val targetFont: MutableState<Float> = mutableStateOf(0f)
    val pivot: MutableState<Offset> = mutableStateOf(Offset.Zero)
    val gestureActive: MutableState<Boolean> = mutableStateOf(false)
    val commitInProgress: MutableState<Boolean> = mutableStateOf(false)
    val commitShiftX: MutableState<Float> = mutableStateOf(0f)
    val commitShiftY: MutableState<Float> = mutableStateOf(0f)
    val gutterWidthPx: MutableState<Float> = mutableStateOf(0f)
    val anchor: ZoomAnchor = ZoomAnchor()

    val layerScaleY: Float
        get() = if (commitInProgress.value) 1f else scaleY.value

    val layerScaleX: Float
        get() = if (commitInProgress.value) 1f else scaleX.value

    fun layerFontRatio(committedFontSize: Float): Float {
        val target = targetFont.value
        return if (commitInProgress.value || target <= 0f || committedFontSize <= 0f) {
            1f
        } else {
            target / committedFontSize
        }
    }

    val sheetShiftX: Float get() = commitShiftX.value
    val sheetShiftY: Float get() = commitShiftY.value
}

@Composable
internal fun rememberEditorZoomSessionState(): EditorZoomSessionState = remember {
    EditorZoomSessionState()
}
