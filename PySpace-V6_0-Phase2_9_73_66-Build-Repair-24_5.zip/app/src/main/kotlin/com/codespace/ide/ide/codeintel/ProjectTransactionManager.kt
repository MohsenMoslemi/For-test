package com.codespace.ide.ide.codeintel

import java.io.File
import java.io.FileOutputStream
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Project-wide serialization and durable operation journal.
 *
 * This is the coordination layer for mutations that originate in different IDE
 * features (editor saves, explorer operations and language-server refactors).
 * Feature repositories still own their domain-specific staging/rollback rules;
 * this class guarantees a single mutation lane and records the lifecycle before
 * and after the mutation so an interrupted operation is never reported as a
 * successful one.
 */
object ProjectTransactionManager {
    private const val DIRECTORY = ".pyspace-transactions"
    private const val JOURNAL = "operations.jsonl"
    private const val MAX_HISTORY = 250
    private const val MAX_JOURNAL_BYTES = 512 * 1024L
    private val locks = ConcurrentHashMap<String, Mutex>()

    enum class Status { COMMITTED, FAILED, INTERRUPTED, RESTORED }

    data class HistoryEntry(
        val id: String,
        val operation: String,
        val status: Status,
        val startedAt: Long,
        val finishedAt: Long?,
        val paths: List<String>,
        val detail: String,
        val recoveryAvailable: Boolean = false,
    )

    /** Execute one project mutation in the project's serialized transaction lane. */
    suspend fun <T> execute(
        projectRoot: File,
        operation: String,
        affectedPaths: Collection<File> = emptyList(),
        block: suspend () -> T,
    ): T {
        val root = projectRoot.canonicalFile
        require(root.isDirectory) { "Project directory is unavailable" }
        val key = root.path
        val mutex = locks.getOrPut(key) { Mutex() }
        return mutex.withLock {
            withContext(Dispatchers.IO) {
                purgeCommittedQuarantines(root)
                val id = UUID.randomUUID().toString()
                val startedAt = System.currentTimeMillis()
                val paths = affectedPaths.map { relativePath(root, it) }.distinct().take(24)
                appendEvent(root, JSONObject()
                    .put("id", id)
                    .put("operation", operation.take(64))
                    .put("status", "STARTED")
                    .put("startedAt", startedAt)
                    .put("paths", JSONArray(paths)))
                try {
                    val result = block()
                    // The mutation is already committed. A journal-tail write failure
                    // must not make the caller believe the filesystem operation failed.
                    withContext(NonCancellable + Dispatchers.IO) {
                        runCatching {
                            appendEvent(root, JSONObject()
                                .put("id", id)
                                .put("status", "COMMITTED")
                                .put("finishedAt", System.currentTimeMillis()))
                        }
                    }
                    result
                } catch (error: Throwable) {
                    withContext(NonCancellable + Dispatchers.IO) {
                        runCatching {
                            appendEvent(root, JSONObject()
                                .put("id", id)
                                .put("status", "FAILED")
                                .put("finishedAt", System.currentTimeMillis())
                                .put("detail", (error.message ?: error.javaClass.simpleName).take(240)))
                        }
                    }
                    throw error
                }
            }
        }
    }

    /**
     * Delete by first atomically moving the item into a project-local quarantine.
     * The durable COMMITTED marker is written before the quarantined bytes are
     * purged. If the process dies between quarantine and commit, the history
     * contains enough information to restore the original path.
     */
    suspend fun deleteRecoverably(
        projectRoot: File,
        target: File,
        purgeQuarantine: (File) -> Unit,
    ) {
        val root = projectRoot.canonicalFile
        require(root.isDirectory) { "Project directory is unavailable" }
        val mutex = locks.getOrPut(root.path) { Mutex() }
        mutex.withLock {
            withContext(Dispatchers.IO) {
                purgeCommittedQuarantines(root)
                val originalParent = target.absoluteFile.parentFile?.canonicalFile
                    ?: throw IllegalArgumentException("Invalid delete target")
                val original = File(originalParent, target.name)
                // A direct child of the project has the project root itself as
                // its parent. Accept that case as well as deeper descendants,
                // while still rejecting the root (whose parent is outside it)
                // and paths whose canonical parent escapes through a symlink.
                val parentIsInsideProject = originalParent.path == root.path ||
                    originalParent.path.startsWith(root.path + File.separator)
                require(parentIsInsideProject &&
                    (original.exists() || java.nio.file.Files.isSymbolicLink(original.toPath()))) {
                    "Cannot delete project root or an external path"
                }
                val id = UUID.randomUUID().toString()
                val startedAt = System.currentTimeMillis()
                val trashDir = File(File(root, DIRECTORY), "trash")
                if (!trashDir.exists() && !trashDir.mkdirs()) throw IllegalStateException("Cannot create project delete quarantine")
                require(!java.nio.file.Files.isSymbolicLink(File(root, DIRECTORY).toPath()) && !java.nio.file.Files.isSymbolicLink(trashDir.toPath())) {
                    "Project transaction quarantine is not a safe directory"
                }
                val quarantine = File(trashDir, id)
                val originalRelative = relativePathWithoutFollowingLeaf(root, original)
                val quarantineRelative = relativePathWithoutFollowingLeaf(root, quarantine)
                appendEvent(root, JSONObject()
                    .put("id", id)
                    .put("operation", "DELETE")
                    .put("status", "STARTED")
                    .put("startedAt", startedAt)
                    .put("paths", JSONArray(listOf(originalRelative)))
                    .put("originalPath", originalRelative)
                    .put("quarantinePath", quarantineRelative))
                if (!original.renameTo(quarantine)) {
                    withContext(NonCancellable + Dispatchers.IO) {
                        runCatching { appendEvent(root, JSONObject().put("id", id).put("status", "FAILED")
                            .put("finishedAt", System.currentTimeMillis()).put("detail", "Could not move the item into delete quarantine.")) }
                    }
                    throw IllegalStateException("Delete could not safely stage the item")
                }
                try {
                    appendEvent(root, JSONObject().put("id", id).put("status", "COMMITTED")
                        .put("finishedAt", System.currentTimeMillis()))
                } catch (journalError: Exception) {
                    val restored = quarantine.renameTo(original)
                    if (restored) {
                        withContext(NonCancellable + Dispatchers.IO) {
                            runCatching { appendEvent(root, JSONObject().put("id", id).put("status", "FAILED")
                                .put("finishedAt", System.currentTimeMillis()).put("detail", "Journal commit failed; original item was restored.")) }
                        }
                    }
                    throw IllegalStateException(
                        if (restored) "Delete was cancelled because its transaction could not be recorded; the original item was restored."
                        else "Delete journal failed and the quarantined item could not be restored. Use Transaction history to recover it.",
                        journalError,
                    )
                }
                // The logical delete is committed. Purging is best-effort and
                // non-cancellable; a leftover quarantine is hidden and safe to clean later.
                withContext(NonCancellable + Dispatchers.IO) {
                    runCatching { if (quarantine.exists()) purgeQuarantine(quarantine) }
                }
            }
        }
    }

    /** Restore a delete whose process died before its COMMITTED marker. */
    suspend fun restoreInterruptedDelete(projectRoot: File, transactionId: String): Boolean {
        val root = projectRoot.canonicalFile
        require(root.isDirectory) { "Project directory is unavailable" }
        val mutex = locks.getOrPut(root.path) { Mutex() }
        return mutex.withLock {
            withContext(Dispatchers.IO) {
                require(transactionId.matches(Regex("[A-Fa-f0-9-]{36}"))) { "Invalid transaction identifier" }
                val journal = journalFile(root)
                if (!journal.isFile) return@withContext false
                var start: JSONObject? = null
                val terminal = HashSet<String>()
                runCatching {
                    journal.useLines(StandardCharsets.UTF_8) { lines ->
                        lines.forEach { line -> runCatching {
                            val event = JSONObject(line)
                            if (event.optString("id") == transactionId) {
                                when (event.optString("status")) {
                                    "STARTED" -> start = event
                                    "COMMITTED", "FAILED", "RESTORED" -> terminal += transactionId
                                }
                            }
                        } }
                    }
                }
                if (start == null || transactionId in terminal || start?.optString("operation") != "DELETE") return@withContext false
                val original = resolveProjectPath(root, start!!.optString("originalPath")) ?: return@withContext false
                val quarantine = resolveProjectPath(root, start!!.optString("quarantinePath")) ?: return@withContext false
                if (original.exists() || java.nio.file.Files.isSymbolicLink(original.toPath()) ||
                    !(quarantine.exists() || java.nio.file.Files.isSymbolicLink(quarantine.toPath()))) return@withContext false
                val parent = original.parentFile ?: return@withContext false
                if (!parent.isDirectory || !quarantine.renameTo(original)) return@withContext false
                appendEvent(root, JSONObject().put("id", transactionId).put("status", "RESTORED")
                    .put("finishedAt", System.currentTimeMillis()).put("detail", "Original item restored from delete quarantine."))
                true
            }
        }
    }

    /** Most recent operations, with unmatched STARTED records surfaced as INTERRUPTED. */
    suspend fun history(projectRoot: File, limit: Int = 100): List<HistoryEntry> =
        withContext(Dispatchers.IO) {
            val root = projectRoot.canonicalFile
            val mutex = locks.getOrPut(root.path) { Mutex() }
            mutex.withLock {
                val file = journalFile(root)
                if (!file.isFile) return@withLock emptyList()
                val starts = LinkedHashMap<String, JSONObject>()
                val terminals = HashMap<String, JSONObject>()
                runCatching {
                    file.useLines(StandardCharsets.UTF_8) { lines ->
                        lines.forEach { line ->
                            if (line.length > 16_384) return@forEach
                            runCatching {
                                val event = JSONObject(line)
                                val id = event.optString("id")
                                if (id.isNotBlank()) {
                                    when (event.optString("status")) {
                                        "STARTED" -> starts[id] = event
                                        "COMMITTED", "FAILED", "RESTORED" -> terminals[id] = event
                                    }
                                }
                            }
                        }
                    }
                }
                starts.map { (id, start) ->
                    val end = terminals[id]
                    val rawStatus = end?.optString("status")
                    val status = when (rawStatus) {
                        "COMMITTED" -> Status.COMMITTED
                        "FAILED" -> Status.FAILED
                        "RESTORED" -> Status.RESTORED
                        else -> Status.INTERRUPTED
                    }
                    val pathsJson = start.optJSONArray("paths") ?: JSONArray()
                    HistoryEntry(
                        id = id,
                        operation = start.optString("operation", "File operation"),
                        status = status,
                        startedAt = start.optLong("startedAt"),
                        finishedAt = end?.optLong("finishedAt")?.takeIf { it > 0L },
                        paths = (0 until pathsJson.length()).mapNotNull { index -> pathsJson.optString(index).takeIf(String::isNotBlank) },
                        detail = end?.optString("detail").orEmpty().ifBlank {
                            if (status == Status.INTERRUPTED) "The app stopped before this operation was recorded as complete." else ""
                        },
                        recoveryAvailable = status == Status.INTERRUPTED && start.optString("operation") == "DELETE" &&
                            (resolveProjectPath(root, start.optString("quarantinePath"))?.let {
                                it.exists() || java.nio.file.Files.isSymbolicLink(it.toPath())
                            } == true),
                    )
                }.sortedByDescending { it.startedAt }.take(limit.coerceIn(1, MAX_HISTORY))
            }
        }

    /** Clean quarantines left behind only after their DELETE was durably committed. */
    private fun purgeCommittedQuarantines(root: File) {
        val journal = journalFile(root)
        if (!journal.isFile) return
        val starts = HashMap<String, JSONObject>()
        val terminals = HashMap<String, String>()
        runCatching {
            journal.useLines(StandardCharsets.UTF_8) { lines ->
                lines.forEach { line -> runCatching {
                    val event = JSONObject(line)
                    val id = event.optString("id")
                    if (id.isNotBlank()) when (event.optString("status")) {
                        "STARTED" -> starts[id] = event
                        "COMMITTED", "FAILED", "RESTORED" -> terminals[id] = event.optString("status")
                    }
                } }
            }
        }
        starts.forEach { (id, start) ->
            if (start.optString("operation") == "DELETE" && terminals[id] == "COMMITTED") {
                resolveProjectPath(root, start.optString("quarantinePath"))?.let { quarantined ->
                    if (quarantined.exists() || java.nio.file.Files.isSymbolicLink(quarantined.toPath())) {
                        runCatching { deleteTreeWithoutFollowingLinks(quarantined) }
                    }
                }
            }
        }
    }

    private fun deleteTreeWithoutFollowingLinks(target: File): Boolean {
        val pending = ArrayDeque<Pair<File, Boolean>>()
        pending.add(target to false)
        while (pending.isNotEmpty()) {
            val (current, visited) = pending.removeLast()
            val isLink = java.nio.file.Files.isSymbolicLink(current.toPath())
            if (current.isDirectory && !isLink && !visited) {
                val children = current.listFiles() ?: return false
                pending.add(current to true)
                children.forEach { pending.add(it to false) }
            } else if (!current.delete() && (current.exists() || isLink)) return false
        }
        return true
    }

    private fun appendEvent(root: File, event: JSONObject) {
        val file = journalFile(root)
        val parent = file.parentFile ?: error("Invalid transaction journal path")
        if (!parent.exists() && !parent.mkdirs()) throw IllegalStateException("Cannot create project transaction journal")
        FileOutputStream(file, true).use { output ->
            output.write((event.toString() + "\n").toByteArray(StandardCharsets.UTF_8))
            output.fd.sync()
        }
        if (file.length() > MAX_JOURNAL_BYTES) compact(file)
    }

    /** Keep a bounded, parseable tail; a corrupt final line is ignored by history(). */
    private fun compact(file: File) {
        val records = runCatching {
            file.readLines(StandardCharsets.UTF_8).takeLast(MAX_HISTORY * 2)
        }.getOrDefault(emptyList())
        val temp = File(file.parentFile, ".${JOURNAL}.${UUID.randomUUID()}.tmp")
        try {
            FileOutputStream(temp, false).use { output ->
                records.forEach { line ->
                    output.write(line.toByteArray(StandardCharsets.UTF_8))
                    output.write('\n'.code)
                }
                output.fd.sync()
            }
            try {
                java.nio.file.Files.move(
                    temp.toPath(), file.toPath(),
                    java.nio.file.StandardCopyOption.ATOMIC_MOVE,
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                )
            } catch (_: Exception) {
                if (!temp.renameTo(file)) throw IllegalStateException("Could not compact transaction history")
            }
        } finally {
            if (temp.exists()) temp.delete()
        }
    }

    private fun journalFile(root: File) = File(File(root, DIRECTORY), JOURNAL)

    private fun resolveProjectPath(root: File, relative: String): File? = runCatching {
        require(relative.isNotBlank() && !relative.startsWith("/") && relative.split('/').none { it == ".." })
        val canonicalRoot = root.canonicalFile
        val raw = File(canonicalRoot, relative)
        val parent = raw.parentFile?.canonicalFile ?: error("Invalid project path")
        require(parent.path.startsWith(canonicalRoot.path + File.separator))
        File(parent, raw.name)
    }.getOrNull()

    private fun relativePathWithoutFollowingLeaf(root: File, candidate: File): String = try {
        val parent = candidate.absoluteFile.parentFile?.canonicalFile ?: error("Invalid project path")
        val prefix = root.canonicalPath + File.separator
        require(parent.path.startsWith(prefix))
        (parent.path.removePrefix(prefix) + "/" + candidate.name).replace('\\', '/')
    } catch (_: Exception) { "<unresolved>" }

    private fun relativePath(root: File, candidate: File): String = try {
        val canonical = candidate.canonicalFile
        val prefix = root.path + File.separator
        if (canonical.path == root.path) "." else if (canonical.path.startsWith(prefix)) {
            canonical.path.removePrefix(prefix).replace(File.separatorChar, '/')
        } else "<external>"
    } catch (_: Exception) { "<unresolved>" }
}
