package com.codespace.ide.ide.editor

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.text.input.TextFieldValue
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.collect

/** Owns the persistence boundary between an open tab and its live Compose viewport. */
@Composable
fun EditorSessionLifecycle(
    tab: OpenTab,
    field: TextFieldValue,
    verticalScroll: ScrollState,
    horizontalScroll: ScrollState,
    hoverJob: Job?,
    onSelectionChange: (Boolean) -> Unit,
) {
    val latestHoverJob = rememberUpdatedState(hoverJob)

    LaunchedEffect(field.selection) {
        onSelectionChange(!field.selection.collapsed)
        tab.selStart = field.selection.start
        tab.selEnd = field.selection.end
    }

    LaunchedEffect(verticalScroll, horizontalScroll) {
        snapshotFlow { verticalScroll.value to horizontalScroll.value }
            .drop(1)
            .collect { (y, x) ->
                tab.scrollY = y
                tab.scrollX = x
                tab.hasView = true
            }
    }

    DisposableEffect(tab, verticalScroll, horizontalScroll) {
        onDispose {
            latestHoverJob.value?.cancel()
            tab.scrollY = verticalScroll.value
            tab.scrollX = horizontalScroll.value
            tab.hasView = true
        }
    }

    LaunchedEffect(verticalScroll.maxValue, horizontalScroll.maxValue) {
        if (verticalScroll.value > verticalScroll.maxValue) {
            verticalScroll.scrollTo(verticalScroll.maxValue)
        }
        if (horizontalScroll.value > horizontalScroll.maxValue) {
            horizontalScroll.scrollTo(horizontalScroll.maxValue)
        }
    }
}
