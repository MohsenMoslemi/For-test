package com.codespace.ide.ide.run

/** Builds the shell environment prefix for a run that uses the phone-camera bridge. */
object CameraRunCommandFactory {
    fun prefix(url: String, granted: Boolean, shimDir: String?): String {
        val builder = StringBuilder()
        val port = url.substringAfterLast(":").trim()
        builder.append("export PHONE_CAMERA_URL=\"$url\" PHONE_CAMERA_PORT=\"$port\"; ")
        builder.append("export OPENCV_FFMPEG_CAPTURE_OPTIONS=\"fflags;nobuffer|flags;low_delay|probesize;32|analyzeduration;0\"; ")
        if (shimDir != null) {
            builder.append("export PYTHONPATH=\"$shimDir\${PYTHONPATH:+:\$PYTHONPATH}\"; ")
        } else {
            builder.append("echo \"[camera] WARNING: cv2 adapter missing — VideoCapture(0) will fail. Open the Camera tab and tap Retry.\"; ")
        }
        if (granted) {
            builder.append("echo \"[camera] phone camera connected\"; ")
        } else {
            builder.append("echo \"[camera] permission not granted — grant it in the Camera tab, then Rerun (streaming will fail until then)\"; ")
        }
        return builder.toString()
    }
}
