package com.codespace.ide.ide.display

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.codespace.ide.ProotManager
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.max
import kotlin.math.min
import java.io.File
import kotlinx.coroutines.channels.Channel

// ---------------------------------------------------------------------------
// Embedded Linux display, protocol side: Xvnc server lifecycle (via proot) and an
// RFB 3.8 client (None auth, 32-bit truecolor, Raw + CopyRect). No Compose UI here;
// the viewer composable lives in ide/Vnc.kt.
// ---------------------------------------------------------------------------

private const val VNC_DISPLAY = 1
private const val VNC_PORT = 5901
/**
 * Desktop canvas: big enough for typical windows (800x600 ... 1600x1600). Xvnc only sends the damaged
 * rectangles and the viewer shows just the window, so the empty area costs memory, not speed.
 */
private const val ROOT_W = 1600
private const val ROOT_H = 1600
/** X11 Escape keysym: phone Back arrives in the guest app as ESC. */
internal const val KEY_ESC = 0xFF1B
internal const val KEY_BACKSPACE = 0xFF08
internal const val KEY_TAB = 0xFF09
internal const val KEY_RETURN = 0xFF0D

/**
 * Owns the Xvnc server lifecycle (via proot) and one viewer connection.
 * Construct once per IDE root (remember). All blocking work runs on
 * Dispatchers.IO; state writes are snapshot-safe from any thread.
 */
class VncDisplay(
    private val proot: ProotManager,
    private val appScope: CoroutineScope,
    private val context: Context
) {
    var status by mutableStateOf("Stopped")
    /** Framebuffer generation: the viewer subscribes to this. */
    var version by mutableStateOf(0)
    var geomW by mutableStateOf(1280)
    var geomH by mutableStateOf(720)

    private var pixels = IntArray(0)
    /** The VIEWPORT bitmap: the part of the screen that is shown (usually just the app window). */
    private var bmp: Bitmap? = null
    private val frameLock = Any()
    @Volatile private var reqView: IntArray? = null
    @Volatile private var vx = 0
    @Volatile private var vy = 0
    /** Screen position of the viewport bitmap's top-left corner (the viewer adds it to touches). */
    var viewX by mutableStateOf(0)
    var viewY by mutableStateOf(0)
    /** Bounding box of the app windows, published by the in-guest window manager (null = none). */
    var winRect by mutableStateOf<IntArray?>(null)
    private val tmpDir: File get() = File(context.applicationContext.filesDir, "proot-ubuntu-tmp")
    private var outs: DataOutputStream? = null
    // ALL input goes through this queue and is written by ONE IO coroutine.
    // The old code wrote to the socket straight from the UI thread; on
    // Android that throws NetworkOnMainThreadException, which the blanket
    // catch swallowed, so no touch or key ever reached the display.
    @Volatile
    private var outCh: Channel<ByteArray>? = null
    private var sock: Socket? = null
    private var loopJob: Job? = null
    private val userStop = AtomicBoolean(false)
    // Last pointer position + button mask (touched on the UI thread only).
    private var lastX = 0
    private var lastY = 0
    private var mask = 0

    val bitmap: Bitmap?
    get() = bmp

    /**
     * Is the display server answering? A plain TCP connect from the app:
     * instant. (It used to spawn a whole proot + bash for every check, a
     * second or more each, which made starting and replacing runs slow and
     * is where most of the "display is stuck" waiting came from.)
     */
    private fun probe(): Boolean {
        return try {
            Socket().use { it.connect(InetSocketAddress("127.0.0.1", VNC_PORT), 300); true }
        } catch (_: Throwable) {
            false
        }
    }

    // Start / stop / restart never overlap: a Stop followed at once by a new
    // run used to probe the DYING server, see it "running", launch the app on
    // it and watch it vanish (or keep showing the old picture).
    private val lifecycle = Mutex()

    /**
     * Makes sure the display server is running and connects the viewer to it.
     * The server is PERSISTENT: once started it stays up across runs (only
     * leaving the project or the app stops it), so the second GUI run in a
     * project finds it already there and pays nothing. Caller: IO thread.
     */
    suspend fun ensureUp(connectViewer: Boolean = true): Boolean =
        lifecycle.withLock { ensureUpLocked(connectViewer) }

    /** Drops the viewer connection and the last picture; the SERVER stays up. */
    fun resetViewer() {
        disconnect()
        clearFrame()
    }

    /** Throws away the last picture so a stale frame is never shown. */
    private fun clearFrame() {
        synchronized(frameLock) {
            bmp = null
            pixels = IntArray(0)
        }
        version++
    }

    /** Caller holds frameLock. Builds the viewport bitmap from the full-screen pixels. */
    private fun rebuildViewportLocked(rootW: Int, rootH: Int) {
        val r = reqView
        var x = 0
        var y = 0
        var w = rootW
        var h = rootH
        if (r != null) {
            x = r[0].coerceIn(0, rootW - 1)
            y = r[1].coerceIn(0, rootH - 1)
            w = r[2].coerceIn(1, rootW - x)
            h = r[3].coerceIn(1, rootH - y)
        }
        if (w < 16 || h < 16) {
            x = 0; y = 0; w = rootW; h = rootH
        }
        val nb = try {
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        } catch (_: Throwable) {
            throw IOException("no memory for framebuffer")
        }
        if (pixels.size >= rootW * rootH) {
            try {
                nb.setPixels(pixels, y * rootW + x, rootW, 0, 0, w, h)
            } catch (_: Throwable) {
            }
        }
        vx = x
        vy = y
        bmp = nb
        viewX = x
        viewY = y
        version++
    }

    private fun applyViewport() {
        try {
            synchronized(frameLock) {
                if (pixels.isNotEmpty() && pixels.size == geomW * geomH) rebuildViewportLocked(geomW, geomH)
            }
        } catch (_: Throwable) {
        }
    }

    /** Show only this part of the screen (the app window). Safe from the UI thread. */
    fun setViewport(x: Int, y: Int, w: Int, h: Int) {
        val nr = intArrayOf(x, y, w, h)
        val cur = reqView
        if (cur != null && cur.contentEquals(nr)) return
        reqView = nr
        applyViewport()
    }

    /** Show the whole screen. */
    fun setViewportAll() {
        if (reqView == null) return
        reqView = null
        applyViewport()
    }

    /** Reads the rectangle the in-guest window manager publishes ("x y w h"), or null if no window. */
    fun readWindowRect(): IntArray? {
        return try {
            val p = File(tmpDir, "ide-wm.win").readText().trim().split(" ").mapNotNull { it.toIntOrNull() }
            if (p.size == 4 && p[2] > 0 && p[3] > 0) intArrayOf(p[0], p[1], p[2], p[3]) else null
        } catch (_: Exception) {
            null
        }
    }

    suspend fun pollWindowRect() {
        val r = kotlinx.coroutines.withContext(Dispatchers.IO) { readWindowRect() }
        val cur = winRect
        if (r == null) {
            if (cur != null) winRect = null
        } else if (cur == null || !cur.contentEquals(r)) {
            winRect = r
        }
    }

    /** SIGKILL Xvnc (its clients die with it) and wait until the port frees. */
    private suspend fun killServerAndWait() {
        try {
            // [X]vnc: the bracket keeps pkill from matching this very shell,
            // whose command line contains the pattern text.
            proot.runOnce(
                "pkill -9 -f '[X]vnc :$VNC_DISPLAY'; " +
                "pkill -9 -f '[i]de-wm.py'; " +
                "rm -f /tmp/.X1-lock /tmp/.X11-unix/X1 /tmp/xvnc.pid /tmp/ide-wm.pid /tmp/ide-wm.ready /tmp/ide-wm.win; echo K",
                12L
            )
        } catch (_: Throwable) {
        }
        repeat(40) {
            if (!probe()) return
            delay(100)
        }
    }

    /** Starts Xvnc (+ optionally the window manager) and waits for the X socket. Returns the shell output. */
    private suspend fun launchServer(gw: Int, gh: Int, withWm: Boolean): String {
        return try {
            proot.runOnce(
                "command -v Xvnc >/dev/null 2>&1 || echo NO-XVNC; " +
                "rm -f /tmp/.X1-lock /tmp/.X11-unix/X1 /tmp/xvnc.pid " +
                "/tmp/ide-wm.pid /tmp/ide-wm.ready /tmp/ide-wm.win; " +
                "echo ${gw}x${gh} > /tmp/xvnc-geom; " +
                "Xvnc :$VNC_DISPLAY -geometry ${gw}x${gh} -depth 24 " +
                "-SecurityTypes None -localhost -alwaysshared " +
                ">/tmp/xvnc-1.log 2>&1 & " +
                // The launch prefix of every GUI run waits for this pid
                // file + the X socket, so the program can be started at
                // the SAME time as the display and still never race it.
                "echo \$! > /tmp/xvnc.pid; " +
                "i=0; while [ \$i -lt 100 ] && [ ! -S /tmp/.X11-unix/X1 ]; " +
                "do i=\$((i+1)); sleep 0.1; done; " +
                (if (withWm) {
                    // Window manager: centers windows and reports their rectangle.
                    "if command -v python3 >/dev/null 2>&1 && [ -f /tmp/ide-wm.py ]; then " +
                    "DISPLAY=:$VNC_DISPLAY IDE_WM_DIR=/tmp python3 /tmp/ide-wm.py " +
                    ">/tmp/ide-wm.log 2>&1 & echo \$! > /tmp/ide-wm.pid; fi; "
                } else {
                    ""
                }) +
                "echo READY",
                25L
            )
        } catch (t: Throwable) {
            "ERROR: ${t.message}"
        }
    }

    private suspend fun ensureUpLocked(connectViewer: Boolean): Boolean {
        // Apps that fill their window (Kivy) get a phone-shaped size, kept small so software
        // rendering stays fast; the window manager centers it and the viewer zooms to it.
        val dm = try {
            context.resources.displayMetrics
        } catch (_: Exception) {
            null
        }
        val dw = (dm?.widthPixels ?: 1280).coerceAtLeast(1)
        val dh = (dm?.heightPixels ?: 720).coerceAtLeast(1)
        val longSide = max(dw, dh)
        val shortSide = min(dw, dh)
        val sc = min(
            max(1280f / longSide, 720f / shortSide),
            1600f / longSide
        )
        val aw = (dw * sc).toInt().coerceIn(320, 1600)
        val ah = (dh * sc).toInt().coerceIn(320, 1600)
        // If the window manager could not start on this device once, stay on the classic setup
        // (phone-shaped screen, no window manager) instead of retrying on every run.
        val noWm = File(tmpDir, "ide-wm.fail").exists()
        val gw = if (noWm) aw else ROOT_W
        val gh = if (noWm) ah else ROOT_H
        val wantVer = if (noWm) "none" else DISPLAY_WM_VERSION
        if (probe()) {
            // Reuse the running display only if it has the same canvas and window manager version;
            // an older IDE build leaves a different one behind: restart it once.
            val same = try {
                File(tmpDir, "xvnc-geom").readText().trim() == "${gw}x${gh}" &&
                    File(tmpDir, "ide-wm.ver").readText().trim() == wantVer
            } catch (_: Exception) {
                false
            }
            if (same) {
                status = "Display running ✓"
                if (connectViewer) connect()
                return true
            }
            status = "Updating display…"
            disconnect()
            killServerAndWait()
        }
        status = "Starting display…"
        try {
            tmpDir.mkdirs()
            File(tmpDir, "ide-wm.py").writeText(DISPLAY_WM_SOURCE)
            File(tmpDir, "ide-app-size").writeText("${aw}x${ah}\n")
        } catch (_: Exception) {
        }
        var useGw = gw
        var useGh = gh
        var ver = wantVer
        var startOut = launchServer(useGw, useGh, !noWm)
        if (startOut.lines().any { it.trim() == "NO-XVNC" }) {
            status = "Xvnc missing — run Install GUI libraries first."
            return false
        }
        if (!noWm) {
            // The window manager writes a ready file within milliseconds; if it never does
            // (no python3, no libX11 ...) fall back to the classic display, once and for good.
            var ready = false
            repeat(25) {
                if (!ready) {
                    if (File(tmpDir, "ide-wm.ready").exists()) ready = true else delay(100)
                }
            }
            if (!ready) {
                try {
                    File(tmpDir, "ide-wm.fail").writeText("1\n")
                } catch (_: Exception) {
                }
                status = "Starting display…"
                disconnect()
                killServerAndWait()
                useGw = aw
                useGh = ah
                ver = "none"
                startOut = launchServer(useGw, useGh, false)
            }
        }
        repeat(60) {
            if (probe()) {
                geomW = useGw
                geomH = useGh
                try {
                    File(tmpDir, "ide-wm.ver").writeText(ver)
                } catch (_: Exception) {
                }
                status = "Display running ✓"
                if (connectViewer) connect()
                return true
            }
            delay(100)
        }
        status = "Display failed to start — see Settings › Display."
        return false
    }

    /** Stops the server and drops the viewer connection. Caller: IO thread. */
    suspend fun stopServer() {
        lifecycle.withLock {
            disconnect()
            killServerAndWait()
            clearFrame()
            status = "Stopped"
        }
    }

    /** Opens the viewer connection (idempotent). Safe from any thread. */
    fun connect() {
        if (loopJob?.isActive == true) return
        loopJob = appScope.launch(Dispatchers.IO) {
            userStop.set(false)
            try {
                // The viewer opens BEFORE Xvnc has finished starting, so the
                // first connect often fails: keep trying (≈20 s) instead of
                // giving up and leaving a black screen forever.
                var tries = 0
                while (true) {
                    if (runSession()) break
                    if (userStop.get() || ++tries >= 40) break
                    status = "Waiting for display…"
                    delay(500)
                }
            } catch (t: Throwable) {
                if (t is kotlinx.coroutines.CancellationException) {
                    status = "Disconnected"
                    throw t
                }
                if (userStop.getAndSet(false)) {
                    status = "Disconnected"
                } else {
                    status = "Display error: " + ((t.message ?: "connection failed").take(120))
                }
            }
        }
    }

    /** Drops the viewer connection (server keeps running). Any thread. */
    fun disconnect() {
        userStop.set(true)
        // Closed on a helper thread: this is called from the UI thread too,
        // and socket calls must never run there on Android.
        val s = sock
        if (s != null) {
            Thread {
                try {
                    s.close()
                } catch (_: Exception) {
                }
            }.also { it.isDaemon = true }.start()
        }
        try {
            loopJob?.cancel()
        } catch (_: Exception) {
        }
        loopJob = null
        outs = null
        try {
            outCh?.close()
        } catch (_: Exception) {
        }
        outCh = null
    }

    // ---- pointer + keyboard (queued; written off the UI thread) ---------
    private fun queue(msg: ByteArray) {
        try {
            outCh?.trySend(msg)
        } catch (_: Throwable) {
        }
    }

    /** One RFB PointerEvent (type 5): button mask + 16-bit x/y. */
    private fun sendPointer(m: Int, x: Int, y: Int) {
        lastX = x
        lastY = y
        mask = m
        queue(
            byteArrayOf(
                5, m.toByte(),
                (x shr 8).toByte(), x.toByte(),
                (y shr 8).toByte(), y.toByte()
            )
        )
    }

    /** Writer-side marker: pause so press and release are separate beats. */
    private val pauseMsg = byteArrayOf(-1)

    fun press(x: Int, y: Int) {
        // Hover first: toolkits (Kivy/SDL, Qt, Tk) expect the pointer to
        // ENTER a widget before a button goes down on it.
        sendPointer(0, x, y)
        sendPointer(1, x, y)
    }

    // Drag moves are COALESCED: only the newest position is ever queued.
    // The UI emits a move per touch sample (up to 120/s); a slow guest app
    // (software GL) could not drain that, the backlog grew, and the picture
    // trailed the finger by seconds. One token in the queue, latest pos wins.
    private val pendingMove = java.util.concurrent.atomic.AtomicReference<ByteArray?>(null)
    private val moveToken = byteArrayOf(-2)

    fun move(x: Int, y: Int) {
        lastX = x
        lastY = y
        val m = mask
        val msg = byteArrayOf(
            5, m.toByte(),
            (x shr 8).toByte(), x.toByte(),
            (y shr 8).toByte(), y.toByte()
        )
        if (pendingMove.getAndSet(msg) == null) queue(moveToken)
    }
    fun release() = sendPointer(0, lastX, lastY)

    fun tap(x: Int, y: Int) {
        sendPointer(0, x, y)
        sendPointer(1, x, y)
        // ~60 ms down-time: press and release in the same millisecond are
        // folded together by some toolkits and the click is lost.
        queue(pauseMsg)
        sendPointer(0, x, y)
    }

    private fun sendKey(down: Boolean, keysym: Int) {
        queue(
            byteArrayOf(
                4, if (down) 1 else 0, 0, 0,
                (keysym ushr 24).toByte(), (keysym ushr 16).toByte(),
                (keysym ushr 8).toByte(), keysym.toByte()
            )
        )
    }

    /**
     * Types text into the focused guest widget. Latin-1 keysyms equal their
     * code point; everything else uses the X11 Unicode keysym 0x01000000+cp,
     * which Xvnc maps on the fly (Persian, emoji, …).
     */
    fun typeText(text: String) {
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            i += Character.charCount(cp)
            when {
                cp == '\n'.code -> keyPress(KEY_RETURN)
                cp == '\t'.code -> keyPress(KEY_TAB)
                cp in 0x20..0x7E || cp in 0xA0..0xFF -> keyPress(cp)
                cp < 0x20 -> {}
                else -> keyPress(0x01000000 + cp)
            }
        }
    }

    fun backspace() = keyPress(KEY_BACKSPACE)

    fun keyDown(keysym: Int) = sendKey(true, keysym)
    fun keyUp(keysym: Int) = sendKey(false, keysym)
    fun keyPress(keysym: Int) {
        keyDown(keysym)
        keyUp(keysym)
    }

    // ---- session ----------------------------------------------------------
    /** Returns false when the server was not reachable (caller may retry). */
    private suspend fun runSession(): Boolean {
        status = "Connecting…"
        val s = Socket()
        sock = s
        try {
            s.connect(InetSocketAddress("127.0.0.1", VNC_PORT), 5000)
            s.tcpNoDelay = true
        } catch (t: Throwable) {
            try {
                s.close()
            } catch (_: Exception) {
            }
            status = "Display is not running — start it first."
            return false
        }
        val ins = DataInputStream(BufferedInputStream(s.getInputStream(), 64 * 1024))
        val o = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
        outs = o
        val ch = Channel<ByteArray>(Channel.UNLIMITED)
        val writer = appScope.launch(Dispatchers.IO) {
            try {
                for (m in ch) {
                    if (m.size == 1 && m[0] == (-1).toByte()) {
                        delay(60)
                        continue
                    }
                    val out = if (m.size == 1 && m[0] == (-2).toByte()) {
                        pendingMove.getAndSet(null) ?: continue
                    } else {
                        m
                    }
                    synchronized(o) {
                        o.write(out)
                        o.flush()
                    }
                }
            } catch (_: Throwable) {
            }
        }
        try {
            // 1. Version handshake (we speak 3.8).
            val ver = ByteArray(12)
            ins.readFully(ver)
            val vs = try {
                String(ver, Charsets.US_ASCII)
            } catch (_: Exception) {
                ""
            }
            if (!vs.startsWith("RFB 003.00")) throw IOException("bad greeting")
            o.write("RFB 003.008\n".toByteArray(Charsets.US_ASCII))
            o.flush()
            // 2. Security: expect None only.
            val nSec = ins.readUnsignedByte()
            if (nSec == 0) throw IOException("no common security")
            var haveNone = false
            repeat(nSec) { if (ins.readUnsignedByte() == 1) haveNone = true }
            if (!haveNone) throw IOException("server needs a password")
            o.writeByte(1)
            o.flush()
            if (ins.readInt() != 0) throw IOException("auth rejected")
            // 3. Share the desktop, read its geometry + pixel format.
            o.writeByte(1)
            o.flush()
            val w = ins.readUnsignedShort()
            val h = ins.readUnsignedShort()
            val pf = ByteArray(16)
            ins.readFully(pf)
            val le = pf[2].toInt() == 0
            val tc = pf[3].toInt() != 0
            val rmax = ((pf[4].toInt() and 0xFF) shl 8) or (pf[5].toInt() and 0xFF)
            val gmax = ((pf[6].toInt() and 0xFF) shl 8) or (pf[7].toInt() and 0xFF)
            val bmax = ((pf[8].toInt() and 0xFF) shl 8) or (pf[9].toInt() and 0xFF)
            val rsh = pf[10].toInt()
            val gsh = pf[11].toInt()
            val bsh = pf[12].toInt()
            if (!le || !tc || pf[0].toInt() != 32 || pf[1].toInt() != 24 ||
                rmax != 255 || gmax != 255 || bmax != 255 ||
                rsh != 16 || gsh != 8 || bsh != 0
            ) {
                throw IOException("unsupported pixel format")
            }
            val nameLen = ins.readInt()
            if (nameLen < 0 || nameLen > 1024) throw IOException("bad desktop name")
            if (nameLen > 0) ins.skipBytes(nameLen)
            if (w <= 0 || h <= 0 || w > 4096 || h > 4096) throw IOException("bad geometry")
            geomW = w
            geomH = h
            synchronized(frameLock) {
                pixels = IntArray(w * h)
                rebuildViewportLocked(w, h)
            }
            // 4. Encodings we decode: Raw + CopyRect.
            o.writeByte(2)
            o.writeByte(0)
            o.writeShort(2)
            o.writeInt(0)
            o.writeInt(1)
            o.flush()
            // Handshake is over: from here on input may be queued.
            outCh = ch
            requestUpdate(o, w, h, incremental = false)
            status = "Display running ✓"
            var scratch = ByteArray(0)
            // 5. Update loop: the server only speaks when pixels change, so
            // a plain blocking read is the whole frame clock (no polling).
            while (true) {
                when (ins.readUnsignedByte()) {
                    0 -> {
                        ins.readUnsignedByte() // pad
                        val n = ins.readUnsignedShort()
                        // Bounding box of everything this update touched: only
                        // THAT area is pushed to the bitmap. The old code copied
                        // the whole framebuffer (~3 MB on a phone-sized display)
                        // for every update, even a blinking cursor.
                        var dx0 = w
                        var dy0 = h
                        var dx1 = -1
                        var dy1 = -1
                        repeat(n) {
                            val rx = ins.readUnsignedShort()
                            val ry = ins.readUnsignedShort()
                            val rw = ins.readUnsignedShort()
                            val rh = ins.readUnsignedShort()
                            val enc = ins.readInt()
                            if (rx < 0 || ry < 0 || rw <= 0 || rh <= 0 ||
                                rx + rw > w || ry + rh > h
                            ) {
                                throw IOException("bad rect")
                            }
                            if (rx < dx0) dx0 = rx
                            if (ry < dy0) dy0 = ry
                            if (rx + rw - 1 > dx1) dx1 = rx + rw - 1
                            if (ry + rh - 1 > dy1) dy1 = ry + rh - 1
                            when (enc) {
                                0 -> {
                                    // Raw: LE wire order is B,G,R,X.
                                    val count = rw * rh
                                    if (scratch.size < count * 4) {
                                        scratch = ByteArray(count * 4)
                                    }
                                    ins.readFully(scratch, 0, count * 4)
                                    // Wire bytes B,G,R,X (little-endian) read as ONE Int are
                                    // 0x00RRGGBB: bulk-copy each row, then force alpha.
                                    val ib = java.nio.ByteBuffer.wrap(scratch, 0, count * 4)
                                        .order(java.nio.ByteOrder.LITTLE_ENDIAN).asIntBuffer()
                                    for (j in 0 until rh) {
                                        val dst = (ry + j) * w + rx
                                        ib.get(pixels, dst, rw)
                                        for (i in dst until dst + rw) {
                                            pixels[i] = pixels[i] or -0x1000000
                                        }
                                    }
                                }
                                1 -> {
                                    val sx = ins.readUnsignedShort()
                                    val sy = ins.readUnsignedShort()
                                    if (sx < 0 || sy < 0 || sx + rw > w || sy + rh > h) {
                                        throw IOException("bad copyrect")
                                    }
                                    blit(sx, sy, rx, ry, rw, rh, w)
                                }
                                else -> throw IOException("encoding $enc")
                            }
                        }
                        if (dx1 >= dx0 && dy1 >= dy0) {
                            synchronized(frameLock) {
                                try {
                                    val b = bmp
                                    if (b != null) {
                                        val ix0 = max(dx0, vx)
                                        val iy0 = max(dy0, vy)
                                        val ix1 = min(dx1, vx + b.width - 1)
                                        val iy1 = min(dy1, vy + b.height - 1)
                                        if (ix1 >= ix0 && iy1 >= iy0) {
                                            b.setPixels(
                                                pixels, iy0 * w + ix0, w,
                                                ix0 - vx, iy0 - vy, ix1 - ix0 + 1, iy1 - iy0 + 1
                                            )
                                        }
                                    }
                                } catch (_: Throwable) {
                                }
                            }
                        }
                        version++
                        requestUpdate(o, w, h, incremental = true)
                    }
                    1 -> {
                        // SetColourMapEntries (never sent for truecolor).
                        ins.readUnsignedByte()
                        ins.readUnsignedShort()
                        val n = ins.readUnsignedShort()
                        skipFully(ins, n * 6)
                    }
                    2 -> {
                    } // Bell: nothing follows.
                    3 -> {
                        // ServerCutText: ignore the payload.
                        ins.readUnsignedByte()
                        ins.readUnsignedByte()
                        ins.readUnsignedByte()
                        val n = ins.readInt()
                        if (n < 0 || n > 4 * 1024 * 1024) throw IOException("bad cut text")
                        skipFully(ins, n)
                    }
                    else -> throw IOException("message type")
                }
            }
        } finally {
            outs = null
            if (outCh === ch) outCh = null
            try {
                ch.close()
            } catch (_: Exception) {
            }
            writer.cancel()
            try {
                s.close()
            } catch (_: Exception) {
            }
            if (sock === s) sock = null
        }
    }

    private fun requestUpdate(o: DataOutputStream, w: Int, h: Int, incremental: Boolean) {
        // Same lock as the input writer: two messages must never interleave.
        synchronized(o) {
            o.writeByte(3)
            o.writeByte(if (incremental) 1 else 0)
            o.writeShort(0)
            o.writeShort(0)
            o.writeShort(w)
            o.writeShort(h)
            o.flush()
        }
    }

    private fun skipFully(ins: DataInputStream, n: Int) {
        var left = n
        val tmp = ByteArray(4096)
        while (left > 0) {
            val r = ins.read(tmp, 0, min(4096, left))
            if (r < 0) throw IOException("eof")
            left -= r
        }
    }

    /** Overlap-safe copy inside the framebuffer. */
    private fun blit(sx: Int, sy: Int, dx: Int, dy: Int, w0: Int, h0: Int, stride: Int) {
        val cw = min(w0, stride - max(sx, dx))
        val ch = min(h0, pixels.size / stride - max(sy, dy))
        if (cw <= 0 || ch <= 0) return
        val tmp = IntArray(cw * ch)
        for (j in 0 until ch) {
            System.arraycopy(pixels, (sy + j) * stride + sx, tmp, j * cw, cw)
        }
        for (j in 0 until ch) {
            System.arraycopy(tmp, j * cw, pixels, (dy + j) * stride + dx, cw)
        }
    }
}
