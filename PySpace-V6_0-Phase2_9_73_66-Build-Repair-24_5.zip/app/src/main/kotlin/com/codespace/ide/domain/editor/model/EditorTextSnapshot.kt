package com.codespace.ide.domain.editor.model

/**
 * Immutable text/caret value used by editing history and application workflows.
 * Offsets are UTF-16 indices, matching Android/Compose text APIs at the adapter boundary.
 */
data class EditorTextSnapshot(
    val text: String,
    val selectionStart: Int,
    val selectionEnd: Int,
)
