package com.codespace.ide

import com.codespace.ide.ide.theme.IdeTheme

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import java.util.LinkedHashMap
import com.codespace.ide.memory.MemoryRuntimePolicy
import com.codespace.ide.memory.MemoryTrimRegistry
import com.codespace.ide.memory.MemoryTrimmable

/**
 * Minimal VT terminal emulator: parser + screen model + renderer.
 *
 * PTY output must flow here FIRST (processText), never straight into a
 * TextView. The UI renders this state; input (cursor/line editing) lives
 * inside the emulated screen, not in a separate input box.
 *
 * Covered: printable chars, C0 controls, CSI cursor movement (CUU/CUD/CUF/
 * CUB/CNL/CPL/CHA/CUP/HVP/VPA), erase (ED/EL/ECH), insert/delete (IL/DL/ICH/
 * DCH), scroll (SU/SD + region scroll), SGR colors/attrs (16 + 256 + true
 * color), scroll margins (DECSTBM), tab stops (HTS/TBC), save/restore cursor,
 * show/hide cursor, autowrap, insert mode, app-cursor keys, bracketed paste
 * mode (kept as mode, never printed), alt screen (?1049), DSR/CPR + DA
 * answers (sent back via onResponse), OSC title (kept, never printed).
 *
 * Deliberately NOT covered (future work): double-width chars, origin mode,
 * smooth scroll, mouse protocols, sixel/graphics, full cursor-style support.
 */
private const val NO_COLOR = 0

/**
 * Scrollback is deliberately bounded for the Android app's 256 MB heap
 * class. A line is compact, but 100k Kotlin objects/strings/style lists plus
 * Compose text/layout objects can consume far more than the raw characters
 * suggest. Keep enough history for normal terminal work without allowing a
 * long-running command to exhaust the process heap.
 */
private val MAX_SCROLLBACK: Int get() = MemoryRuntimePolicy.terminalScrollbackLimit()
private val MAX_STYLED_CACHE: Int get() = MemoryRuntimePolicy.terminalStyledCacheLimit()

private class TermCell {
    var ch: Char = ' '
    var fg: Int = NO_COLOR
    var bg: Int = NO_COLOR
    var bold: Boolean = false
    var underline: Boolean = false
    var reverse: Boolean = false

    fun copy(): TermCell {
        val c = TermCell()
        c.copyFrom(this)
        return c
    }

    fun copyFrom(o: TermCell) {
        ch = o.ch
        fg = o.fg
        bg = o.bg
        bold = o.bold
        underline = o.underline
        reverse = o.reverse
    }

    fun isBlankDefault(): Boolean {
        return ch == ' ' && fg == NO_COLOR && bg == NO_COLOR &&
        !bold && !underline && !reverse
    }
}

private typealias TermLine = Array<TermCell>

private fun blankLine(cols: Int): TermLine {
    return Array(cols) { TermCell() }
}

/** One style run inside a retained line (absolute char offsets). */
private class SpanRun(
    val start: Int,
    val end: Int,
    val fg: Int,
    val bg: Int,
    val bold: Boolean,
    val underline: Boolean,
    val reverse: Boolean
)

/**
 * One retained scrollback line, stored compactly: trimmed text plus style
 * runs, built once at snapshot time. No terminal cell arrays are kept; its
 * Compose document is cached separately in the bounded LRU below.
 */
private class ScrollLine(
    val id: Long,
    val text: String,
    val spans: List<SpanRun>
)

/**
 * Independent terminal selection, addressed in transcript coordinates:
 * lines 0..S-1 are scrollback, S..S+R-1 are the live screen rows (or, while
 * the alt screen is active, lines 0..R-1 are the alt rows — see
 * renderedLineCount/lineTextAt, which use the same mapping as rendering).
 *
 * Deliberately decoupled from Compose SelectionManager (whose per-widget
 * selection state crashes on drag across virtualized LazyColumn items):
 * this model only stores positions; rendering highlights visible lines and
 * copying reads the buffer directly.
 */
data class TermSelection(
    val startLine: Int,
    val startCol: Int,
    val endLine: Int,
    val endCol: Int
) {
    /** Ordered so start <= end (line-major). Idempotent. */
    fun normalized(): TermSelection {
        return if (startLine < endLine ||
            (startLine == endLine && startCol <= endCol)
        ) {
            this
        } else {
            TermSelection(endLine, endCol, startLine, startCol)
        }
    }

    fun isEmpty(): Boolean {
        val n = normalized()
        return n.startLine == n.endLine && n.startCol == n.endCol
    }
}

private val STD_COLORS = intArrayOf(
    0xFF000000.toInt(),
    0xFFAA0000.toInt(),
    0xFF00AA00.toInt(),
    0xFFAA5500.toInt(),
    0xFF0000AA.toInt(),
    0xFFAA00AA.toInt(),
    0xFF00AAAA.toInt(),
    0xFFAAAAAA.toInt()
)

private val BRIGHT_COLORS = intArrayOf(
    0xFF555555.toInt(),
    0xFFFF5555.toInt(),
    0xFF55FF55.toInt(),
    0xFFFFFF55.toInt(),
    0xFF5555FF.toInt(),
    0xFFFF55FF.toInt(),
    0xFF55FFFF.toInt(),
    0xFFFFFFFF.toInt()
)

private fun xterm256(i: Int): Int {
    val idx = i.coerceIn(0, 255)
    if (idx < 8) return STD_COLORS[idx]
    if (idx < 16) return BRIGHT_COLORS[idx - 8]
    if (idx < 232) {
        val v = idx - 16
        val r = v / 36
        val g = (v % 36) / 6
        val b = v % 6
        fun comp(c: Int): Int {
            return if (c == 0) 0 else 55 + c * 40
        }
        return (0xFF shl 24) or (comp(r) shl 16) or (comp(g) shl 8) or comp(b)
    }
    val g = 8 + (idx - 232) * 10
    return (0xFF shl 24) or (g shl 16) or (g shl 8) or g
}

private const val S_GROUND = 0
private const val S_ESC = 1
private const val S_ESC_SKIP1 = 2
private const val S_CSI = 3
private const val S_OSC = 4
private const val S_OSC_ESC = 5
private const val S_SKIP = 6
private const val S_SKIP_ESC = 7

class TerminalEmulator(startCols: Int = 80, startRows: Int = 24) : MemoryTrimmable {

    var cols: Int = startCols.coerceIn(2, 500)
    private set
    var rows: Int = startRows.coerceIn(2, 200)
    private set

    /** Bumped on every processed chunk; the renderer subscribes to it. */
    var version by mutableStateOf(0)
    private set

    /** Last OSC 0;/2; title (shown in the toolbar, never as text). */
    var title by mutableStateOf<String?>(null)
    private set

    /** Read by the input layer: arrows + paste wrapping. */
    var appCursorKeys: Boolean = false
    var bracketedPaste: Boolean = false

    /** DSR/DA answers are written back to the PTY through this hook. */
    var onResponse: ((String) -> Unit)? = null

    private var grid: Array<TermLine> =
    Array(rows) { blankLine(cols) }
    private var altGrid: Array<TermLine>? = null
    private var altCursorRow: Int = 0
    private var altCursorCol: Int = 0
    private var altActive: Boolean = false

    private var cursorRow: Int = 0
    private var cursorCol: Int = 0
    private var savedRow: Int = 0
    private var savedCol: Int = 0
    private var topMargin: Int = 0
    private var bottomMargin: Int = rows - 1

    private var showCursor: Boolean = true
    private var autoWrap: Boolean = true
    private var insertMode: Boolean = false

    private var curFg: Int = NO_COLOR
    private var curBg: Int = NO_COLOR
    private var curBold: Boolean = false
    private var curUnderline: Boolean = false
    private var curReverse: Boolean = false

    private val scrollback = ArrayDeque<ScrollLine>()
    // Compose documents duplicate the line text and retain span/layout data.
    // An unbounded per-line cache made scrolling through old output gradually
    // retain every rendered row. Use an access-ordered, strictly bounded LRU.
    private val styledCache = LinkedHashMap<Long, AnnotatedString>(512, 0.75f, true)
    private var nextScrollId = 1L
    private var tabs = BooleanArray(cols) { it % 8 == 0 }

    private var state: Int = S_GROUND
    private val csiBuf = StringBuilder()
    private var csiPrivate: Boolean = false
    private var csiSkip: Boolean = false
    private val oscBuf = StringBuilder()

    init { MemoryTrimRegistry.register(this) }

    // ------------------------------------------------------------------
    // Input: PTY bytes (already UTF-8 decoded) enter here.
    // ------------------------------------------------------------------

    override fun trimToPolicy() {
        while (scrollback.size > MAX_SCROLLBACK) scrollback.removeFirst()
        trimStyledCache()
        version++
    }

    override fun clearTemporaryCaches() {
        styledCache.clear()
        while (scrollback.size > MAX_SCROLLBACK) scrollback.removeFirst()
        version++
    }

    private fun trimStyledCache() {
        val limit = MAX_STYLED_CACHE
        if (styledCache.size <= limit) return
        val iterator = styledCache.entries.iterator()
        while (styledCache.size > limit && iterator.hasNext()) {
            iterator.next()
            iterator.remove()
        }
    }

    fun processText(text: String) {
        if (text.isEmpty()) return
        for (i in text.indices) {
            processChar(text[i])
        }
        version++
    }

    private fun respond(s: String) {
        try {
            onResponse?.invoke(s)
        } catch (_: Exception) {
        }
    }

    private fun processChar(c: Char) {
        when (state) {
            S_GROUND -> when {
                c == '\u001B' -> state = S_ESC
                c == '\u0007' -> {
                }
                c == '\b' -> {
                    if (cursorCol > 0) cursorCol--
                }
                c == '\t' -> advanceTab()
                c == '\n' || c == '\u000B' || c == '\u000C' -> lineFeed()
                c == '\r' -> cursorCol = 0
                c.code < 0x20 || c.code == 0x7F || c.code in 0x80..0x9F -> {
                }
                else -> putChar(c)
            }
            S_ESC -> handleEsc(c)
            S_ESC_SKIP1 -> state = S_GROUND
            S_CSI -> handleCsi(c)
            S_OSC -> when {
                c == '\u0007' -> endOsc()
                c == '\u001B' -> state = S_OSC_ESC
                else -> {
                    if (oscBuf.length < 1024) oscBuf.append(c)
                }
            }
            S_OSC_ESC -> when {
                c == '\\' -> endOsc()
                c == '\u001B' -> state = S_OSC_ESC
                else -> state = S_OSC
            }
            S_SKIP -> when {
                c == '\u001B' -> state = S_SKIP_ESC
                c == '\u0007' -> state = S_GROUND
                else -> {
                }
            }
            S_SKIP_ESC -> state = if (c == '\\') S_GROUND else S_SKIP
            else -> state = S_GROUND
        }
    }

    private fun handleEsc(c: Char) {
        when (c) {
            '[' -> {
                csiBuf.setLength(0)
                csiPrivate = false
                csiSkip = false
                state = S_CSI
            }
            ']' -> {
                oscBuf.setLength(0)
                state = S_OSC
            }
            '(', ')', '#', '%', '$' -> state = S_ESC_SKIP1
            'M' -> {
                reverseIndex()
                state = S_GROUND
            }
            'D' -> {
                lineFeed()
                state = S_GROUND
            }
            'E' -> {
                cursorCol = 0
                lineFeed()
                state = S_GROUND
            }
            '7' -> {
                saveCursor()
                state = S_GROUND
            }
            '8' -> {
                restoreCursor()
                state = S_GROUND
            }
            'c' -> {
                fullReset()
                state = S_GROUND
            }
            'H' -> {
                setTab(cursorCol)
                state = S_GROUND
            }
            '=', '>' -> state = S_GROUND
            'Z' -> {
                respond("\u001B[?1;2c")
                state = S_GROUND
            }
            'P', 'X', '^', '_' -> state = S_SKIP
            else -> state = S_GROUND
        }
    }

    private fun handleCsi(c: Char) {
        when {
            csiBuf.isEmpty() && (c == '?' || c == '>' || c == '=') -> {
                if (c == '?') csiPrivate = true else csiSkip = true
            }
            // Bound the parameter buffer like oscBuf: a garbage stream of
            // digits with no terminator (e.g. catting a binary) must not
            // grow memory without limit. The final byte still terminates.
            c in '0'..'9' || c == ';' || c == ':' -> {
                if (csiBuf.length < 256) csiBuf.append(c)
            }
            c.code in 0x20..0x2F -> {
            }
            c.code in 0x40..0x7E -> {
                if (!csiSkip) dispatchCsi(c)
                state = S_GROUND
            }
            else -> state = S_GROUND
        }
    }

    private fun csiParams(): MutableList<Int> {
        if (csiBuf.isEmpty()) return mutableListOf()
        return csiBuf.toString().replace(':', ';').split(';').mapTo(mutableListOf()) {
            it.toIntOrNull() ?: 0
        }
    }

    private fun p(params: List<Int>, i: Int, dflt: Int): Int {
        if (i < params.size && params[i] != 0) return params[i]
        return dflt
    }

    private fun dispatchCsi(final: Char) {
        val params = csiParams()
        when (final) {
            'A' -> moveRow(-p(params, 0, 1))
            'B' -> moveRow(p(params, 0, 1))
            'C' -> moveCol(p(params, 0, 1))
            'D' -> moveCol(-p(params, 0, 1))
            'E' -> {
                moveRow(p(params, 0, 1))
                cursorCol = 0
            }
            'F' -> {
                moveRow(-p(params, 0, 1))
                cursorCol = 0
            }
            'G' -> cursorCol = (p(params, 0, 1) - 1).coerceIn(0, cols - 1)
            'H', 'f' -> {
                cursorRow = (p(params, 0, 1) - 1).coerceIn(0, rows - 1)
                cursorCol = (p(params, 1, 1) - 1).coerceIn(0, cols - 1)
            }
            'd' -> cursorRow = (p(params, 0, 1) - 1).coerceIn(0, rows - 1)
            // Ranges are start-inclusive / end-exclusive; the cursor cell
            // itself is included in modes 0 and 1 (xterm behavior).
            'J' -> when (p(params, 0, 0)) {
                1 -> {
                    eraseRange(0, 0, cursorRow, cursorCol + 1)
                }
                2 -> eraseAll()
                3 -> {
                    eraseAll()
                    scrollback.clear()
                    styledCache.clear()
                }
                else -> eraseRange(cursorRow, cursorCol, rows - 1, cols)
            }
            'K' -> when (p(params, 0, 0)) {
                1 -> eraseRange(cursorRow, 0, cursorRow, cursorCol + 1)
                2 -> eraseRange(cursorRow, 0, cursorRow, cols)
                else -> eraseRange(cursorRow, cursorCol, cursorRow, cols)
            }
            'L' -> insertLines(p(params, 0, 1))
            'M' -> deleteLines(p(params, 0, 1))
            '@' -> insertBlanks(p(params, 0, 1))
            'P' -> deleteChars(p(params, 0, 1))
            'X' -> eraseChars(p(params, 0, 1))
            'S' -> scrollRegionUp(p(params, 0, 1))
            'T' -> scrollRegionDown(p(params, 0, 1))
            'm' -> sgr(params)
            'h', 'l' -> {
                val on = final == 'h'
                if (csiPrivate) {
                    for (v in params) {
                        when (v) {
                            1 -> appCursorKeys = on
                            4 -> insertMode = on
                            7 -> autoWrap = on
                            25 -> showCursor = on
                            1047, 1049 -> if (on) enterAlt() else exitAlt()
                            1048 -> if (on) saveCursor() else restoreCursor()
                            2004 -> bracketedPaste = on
                        }
                    }
                } else {
                    for (v in params) {
                        if (v == 4) insertMode = on
                    }
                }
            }
            'n' -> when (p(params, 0, 0)) {
                5 -> respond("\u001B[0n")
                6 -> respond("\u001B[${cursorRow + 1};${cursorCol + 1}R")
            }
            'c' -> respond("\u001B[?1;2c")
            'r' -> {
                val top = (p(params, 0, 1) - 1).coerceIn(0, rows - 1)
                val bottom = if (params.size > 1 && params[1] != 0) {
                    (params[1] - 1).coerceIn(0, rows - 1)
                } else {
                    rows - 1
                }
                if (top < bottom) {
                    topMargin = top
                    bottomMargin = bottom
                    cursorRow = topMargin
                    cursorCol = 0
                }
            }
            's' -> saveCursor()
            'u' -> restoreCursor()
            'g' -> when (p(params, 0, 0)) {
                3 -> tabs = BooleanArray(cols) { false }
                else -> if (cursorCol < cols) tabs[cursorCol] = false
            }
            'q' -> {
            }
        }
    }

    private fun endOsc() {
        val s = oscBuf.toString()
        if ((s.startsWith("0;") || s.startsWith("2;")) && s.length > 2) {
            title = s.substring(2).take(256)
        }
        state = S_GROUND
    }

    // ------------------------------------------------------------------
    // Screen operations.
    // ------------------------------------------------------------------

    /** Write target: alt buffer while ?1049 is active, else main grid. */
    private fun activeGrid(): Array<TermLine> {
        return if (altActive) altGrid ?: grid else grid
    }

    private fun currentLine(): TermLine {
        return activeGrid()[cursorRow.coerceIn(0, rows - 1)]
    }

    private fun blankCell(): TermCell {
        val c = TermCell()
        c.bg = curBg
        return c
    }

    private fun putChar(c: Char) {
        if (cursorCol >= cols) {
            if (!autoWrap) {
                cursorCol = cols - 1
            } else {
                cursorCol = 0
                lineFeed()
            }
        }
        val line = currentLine()
        if (insertMode) {
            var i = cols - 1
            while (i > cursorCol) {
                line[i].copyFrom(line[i - 1])
                i--
            }
        }
        val cell = line[cursorCol]
        cell.ch = c
        cell.fg = curFg
        cell.bg = curBg
        cell.bold = curBold
        cell.underline = curUnderline
        cell.reverse = curReverse
        cursorCol++
    }

    private fun lineFeed() {
        if (cursorRow == bottomMargin) {
            scrollRegionUp(1)
        } else if (cursorRow < rows - 1) {
            cursorRow++
        }
    }

    private fun reverseIndex() {
        if (cursorRow == topMargin) {
            scrollRegionDown(1)
        } else if (cursorRow > 0) {
            cursorRow--
        }
    }

    private fun regionIsFull(): Boolean {
        return topMargin == 0 && bottomMargin == rows - 1
    }

    private fun scrollRegionUp(n: Int) {
        repeat(n.coerceAtLeast(1)) {
            val g = activeGrid()
            // Alt-screen scrolls never enter the main scrollback.
            if (regionIsFull() && !altActive) {
                scrollback.addLast(
                    snapshotScrollLine(g[topMargin])
                )
                while (scrollback.size > MAX_SCROLLBACK) {
                    scrollback.removeFirst()
                }
            }
            for (r in topMargin until bottomMargin) {
                g[r] = g[r + 1]
            }
            g[bottomMargin] = blankLine(cols)
        }
    }

    private fun scrollRegionDown(n: Int) {
        repeat(n.coerceAtLeast(1)) {
            val g = activeGrid()
            for (r in bottomMargin downTo topMargin + 1) {
                g[r] = g[r - 1]
            }
            g[topMargin] = blankLine(cols)
        }
    }

    /**
     * Freezes one grid line into compact scrollback form. Runs merge
     * consecutive same-attribute cells; only non-default runs are stored.
     */
    private fun snapshotScrollLine(line: TermLine): ScrollLine {
        var end = line.size
        while (end > 0 && line[end - 1].isBlankDefault()) {
            end--
        }
        val sb = StringBuilder(end)
        val spans = mutableListOf<SpanRun>()
        var i = 0
        while (i < end) {
            val c = line[i]
            var j = i + 1
            while (j < end) {
                val d = line[j]
                if (d.fg != c.fg || d.bg != c.bg || d.bold != c.bold ||
                    d.underline != c.underline || d.reverse != c.reverse
                ) {
                    break
                }
                j++
            }
            for (k in i until j) {
                sb.append(line[k].ch)
            }
            if (c.fg != NO_COLOR || c.bg != NO_COLOR || c.bold ||
                c.underline || c.reverse
            ) {
                spans.add(SpanRun(i, j, c.fg, c.bg, c.bold, c.underline, c.reverse))
            }
            i = j
        }
        return ScrollLine(nextScrollId++, sb.toString(), spans)
    }

    private fun moveRow(d: Int) {
        cursorRow = (cursorRow + d).coerceIn(0, rows - 1)
    }

    private fun moveCol(d: Int) {
        cursorCol = (cursorCol + d).coerceIn(0, cols - 1)
    }

    private fun eraseRange(r1: Int, c1: Int, r2: Int, c2: Int) {
        val g = activeGrid()
        for (r in r1.coerceIn(0, rows - 1)..r2.coerceIn(0, rows - 1)) {
            val line = g[r]
            val from = if (r == r1) c1.coerceIn(0, cols) else 0
            val to = if (r == r2) c2.coerceIn(0, cols) else cols
            for (c in from until to.coerceAtMost(line.size)) {
                line[c] = blankCell()
            }
        }
    }

    private fun eraseAll() {
        val g = activeGrid()
        for (r in 0 until rows) {
            g[r] = blankLine(cols)
        }
    }

    private fun eraseChars(n: Int) {
        val line = currentLine()
        val count = n.coerceAtLeast(1)
        var i = cursorCol
        while (i < cols && i < cursorCol + count) {
            if (i < line.size) line[i] = blankCell()
            i++
        }
    }

    private fun insertLines(n: Int) {
        val count = n.coerceAtLeast(1)
        repeat(count) {
            if (cursorRow in topMargin..bottomMargin) {
                val g = activeGrid()
                for (r in bottomMargin downTo cursorRow + 1) {
                    g[r] = g[r - 1]
                }
                g[cursorRow] = blankLine(cols)
            }
        }
    }

    private fun deleteLines(n: Int) {
        val count = n.coerceAtLeast(1)
        repeat(count) {
            if (cursorRow in topMargin..bottomMargin) {
                val g = activeGrid()
                for (r in cursorRow until bottomMargin) {
                    g[r] = g[r + 1]
                }
                g[bottomMargin] = blankLine(cols)
            }
        }
    }

    private fun insertBlanks(n: Int) {
        val line = currentLine()
        var k = n.coerceAtLeast(1)
        var i = cols - 1
        while (i >= cursorCol + k && i < line.size) {
            line[i].copyFrom(line[i - k])
            i--
        }
        var j = cursorCol
        while (j < cols && j < cursorCol + k && j < line.size) {
            line[j] = blankCell()
            j++
        }
    }

    private fun deleteChars(n: Int) {
        val line = currentLine()
        val k = n.coerceAtLeast(1)
        var i = cursorCol
        while (i + k < cols && i < line.size) {
            line[i].copyFrom(line[i + k])
            i++
        }
        while (i < cols && i < line.size) {
            line[i] = blankCell()
            i++
        }
    }

    private fun advanceTab() {
        var i = cursorCol + 1
        while (i < cols && (i >= tabs.size || !tabs[i])) {
            i++
        }
        cursorCol = i.coerceAtMost(cols - 1)
    }

    private fun setTab(col: Int) {
        if (col in 0 until cols && col < tabs.size) {
            tabs[col] = true
        }
    }

    private fun saveCursor() {
        savedRow = cursorRow
        savedCol = cursorCol
    }

    private fun restoreCursor() {
        cursorRow = savedRow.coerceIn(0, rows - 1)
        cursorCol = savedCol.coerceIn(0, cols - 1)
    }

    private fun enterAlt() {
        if (altActive) return
        altActive = true
        altCursorRow = cursorRow
        altCursorCol = cursorCol
        altGrid = Array(rows) { blankLine(cols) }
        cursorRow = 0
        cursorCol = 0
    }

    private fun exitAlt() {
        if (!altActive) return
        altActive = false
        altGrid = null
        cursorRow = altCursorRow.coerceIn(0, rows - 1)
        cursorCol = altCursorCol.coerceIn(0, cols - 1)
    }

    private fun resetAttrs() {
        curFg = NO_COLOR
        curBg = NO_COLOR
        curBold = false
        curUnderline = false
        curReverse = false
    }

    private fun sgr(params: List<Int>) {
        if (params.isEmpty()) {
            resetAttrs()
            return
        }
        var i = 0
        while (i < params.size) {
            when (val v = params[i]) {
                0 -> resetAttrs()
                1 -> curBold = true
                4 -> curUnderline = true
                7 -> curReverse = true
                22 -> curBold = false
                24 -> curUnderline = false
                27 -> curReverse = false
                in 30..37 -> curFg = STD_COLORS[v - 30]
                39 -> curFg = NO_COLOR
                in 40..47 -> curBg = STD_COLORS[v - 40]
                49 -> curBg = NO_COLOR
                in 90..97 -> curFg = BRIGHT_COLORS[v - 90]
                in 100..107 -> curBg = BRIGHT_COLORS[v - 100]
                38, 48 -> {
                    val isFg = v == 38
                    val mode = if (i + 1 < params.size) params[i + 1] else -1
                    if (mode == 5 && i + 2 < params.size) {
                        val c = xterm256(params[i + 2])
                        if (isFg) curFg = c else curBg = c
                        i += 2
                    } else if (mode == 2 && i + 4 < params.size) {
                        val r = params[i + 2].coerceIn(0, 255)
                        val g = params[i + 3].coerceIn(0, 255)
                        val b = params[i + 4].coerceIn(0, 255)
                        val c = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                        if (isFg) curFg = c else curBg = c
                        i += 4
                    } else {
                        i++
                    }
                }
                else -> {
                }
            }
            i++
        }
    }

    private fun fullReset() {
        exitAlt()
        eraseAll()
        resetAttrs()
        cursorRow = 0
        cursorCol = 0
        savedRow = 0
        savedCol = 0
        topMargin = 0
        bottomMargin = rows - 1
        showCursor = true
        autoWrap = true
        insertMode = false
        appCursorKeys = false
        bracketedPaste = false
        state = S_GROUND
    }

    // ------------------------------------------------------------------
    // Size, clear, rendering.
    // ------------------------------------------------------------------

    /**
     * Window resize, exactly like xterm/vte: the grid stays anchored at the
     * TOP, so the shell's own row N always maps to grid row N.
     *
     * Shrinking drops the rows that fall off the BOTTOM (the app redraws
     * them after SIGWINCH); growing appends blank rows below. NOTHING is
     * pushed into scrollback: scrollback only ever receives rows that
     * scrolled off during real output.
     *
     * Keeping the row mapping intact is what makes resize safe. An earlier
     * version kept the NEWEST rows and injected the cropped top rows into
     * scrollback, which shifted every row out from under the shell: the next
     * readline redraw then printed the prompt/input line straight on top of
     * preserved content, i.e. a duplicate line on every keyboard toggle or
     * panel drag, plus blank gaps from the shifted grid.
     */
    fun setSize(nRows: Int, nCols: Int) {
        val r = nRows.coerceIn(2, 200)
        val c = nCols.coerceIn(2, 500)
        if (r == rows && c == cols) return
        val old = grid
        val oldRows = old.size
        rows = r
        cols = c
        grid = Array(r) { row ->
            val line = blankLine(c)
            if (row < oldRows) {
                val keep = minOf(c, old[row].size)
                for (i in 0 until keep) {
                    line[i].copyFrom(old[row][i])
                }
            }
            line
        }
        altGrid = null
        altActive = false
        topMargin = 0
        bottomMargin = rows - 1
        cursorRow = cursorRow.coerceIn(0, rows - 1)
        cursorCol = cursorCol.coerceIn(0, cols - 1)
        tabs = BooleanArray(cols) { it % 8 == 0 }
        version++
    }

    /** Visible clear (like `clear`): screen blank + home, scrollback kept. */
    fun clearScreen() {
        eraseAll()
        cursorRow = 0
        cursorCol = 0
        version++
    }

    /** Full reset for a brand-new session. */
    fun reset() {
        scrollback.clear()
        styledCache.clear()
        title = null
        fullReset()
        version++
    }

    fun totalLines(): Int {
        return scrollback.size + rows
    }

    private fun lineText(line: TermLine): String {
        var end = line.size
        while (end > 0 && line[end - 1].isBlankDefault()) {
            end--
        }
        val sb = StringBuilder(end)
        for (i in 0 until end) {
            sb.append(line[i].ch)
        }
        return sb.toString()
    }

    fun renderPlain(): String {
        val sb = StringBuilder()
        // Copy reflects the visible screen: alt buffer alone while active.
        if (!altActive) {
            for (line in scrollback) {
                sb.append(line.text).append('\n')
            }
        }
        val g = activeGrid()
        for (r in 0 until rows) {
            sb.append(lineText(g[r]))
            if (r != rows - 1) sb.append('\n')
        }
        return sb.toString().trimEnd()
    }

    /**
     * Cheap size estimate (chars) of the full plain transcript. No strings
     * are built: used to enforce the deliberate clipboard safety cap before
     * allocating anything big.
     */
    fun plainSize(): Long {
        var n = 0L
        if (!altActive) {
            for (line in scrollback) {
                n += line.text.length + 1
            }
        }
        val g = activeGrid()
        for (r in 0 until rows) {
            n += lineText(g[r]).length + 1
        }
        return n
    }

    /** Scrollback accessors for keyed lazy rendering. */
    fun scrollbackCount(): Int {
        return scrollback.size
    }

    /**
     * Transcript lines as the UI renders them: scrollback followed by the
     * live rows (or alt-screen rows only while the alt screen is active),
     * with the grid tail TRIMMED to lastRenderedRow — the empty rows
     * below the prompt are not items, so every clamp/total in the UI
     * agrees with what is actually on screen. The independent selection
     * model addresses lines in this same space.
     */
    fun renderedLineCount(): Int {
        val n = lastRenderedRow() + 1
        return if (altActive) n else scrollback.size + n
    }

    /** Cursor column on the live screen (0 = start of line). */
    fun cursorColumn(): Int = cursorCol

    /** Text of the screen row the cursor is on ("" in odd states). */
    fun cursorRowText(): String {
        return try {
            lineText(activeGrid()[cursorRow.coerceIn(0, rows - 1)])
        } catch (_: Exception) {
            ""
        }
    }

    /** Plain text of one rendered transcript line; "" when out of range. */
    fun lineTextAt(index: Int): String {
        if (altActive) {
            if (index < 0 || index >= rows) return ""
            return lineText(activeGrid()[index.coerceIn(0, rows - 1)])
        }
        if (index < 0) return ""
        if (index < scrollback.size) return scrollback[index].text
        val r = index - scrollback.size
        if (r < 0 || r >= rows) return ""
        return lineText(activeGrid()[r])
    }

    /**
     * Deepest grid row that must be rendered: the lowest row with real
     * content, or the cursor row (a blank cursor row still shows the
     * caret). Rows below are pure empty grid — items for them were
     * selectable phantom whitespace AND extended the LazyColumn past the
     * viewport, so on a fresh prompt the first keystroke scrolled the
     * prompt itself out of view. Rendering stops here; the PTY grid stays
     * full-size (no SIGWINCH, no shell impact).
     */
    fun lastRenderedRow(): Int {
        val c = cursorRow.coerceIn(0, rows - 1)
        if (rows <= 0) return 0
        val g = activeGrid()
        for (r in (rows - 1) downTo (c + 1)) {
            if (r < g.size && lineText(g[r]).isNotBlank()) return r
        }
        return c
    }

    /**
     * Full-buffer range: first char of oldest line to end of the last
     * line with real content.
     */
    fun fullRange(): TermSelection {
        var last = renderedLineCount() - 1
        if (last < 0) return TermSelection(0, 0, 0, 0)
        // The empty grid tail below the prompt/cursor is not text the
        // user means to select — it only looks like phantom whitespace,
        // and Select All / Copy All covering it is what made a fresh
        // terminal look like it was full of blank lines.
        while (last > 0 && lineTextAt(last).isBlank()) last--
        return TermSelection(0, 0, last, lineTextAt(last).length)
    }

    /**
     * Builds the selected text straight from the scrollback buffer (never
     * from composed UI nodes, which may only cover the viewport). Returns
     * null WITHOUT building anything when the range would exceed maxChars,
     * so huge selections fail gracefully instead of crashing/OOMing.
     * The returned text matches renderPlain() line for line.
     */
    fun selectionText(range: TermSelection, maxChars: Int): String? {
        val n = range.normalized()
        val last = renderedLineCount() - 1
        if (last < 0) return ""
        val sLine = n.startLine.coerceIn(0, last)
        val eLine = n.endLine.coerceIn(0, last)
        // Size first (no big temp): walk lengths only.
        var total = 0L
        var l = sLine
        while (l <= eLine) {
            val t = lineTextAt(l)
            val from = if (l == sLine) n.startCol.coerceIn(0, t.length) else 0
            val to = if (l == eLine) n.endCol.coerceIn(0, t.length) else t.length
            total += (to - from).coerceAtLeast(0) + 1
            if (total > maxChars) return null
            l++
        }
        val sb = StringBuilder(total.coerceAtMost(maxChars.toLong() + 16).toInt())
        l = sLine
        while (l <= eLine) {
            val t = lineTextAt(l)
            val from = if (l == sLine) n.startCol.coerceIn(0, t.length) else 0
            val to = if (l == eLine) n.endCol.coerceIn(0, t.length) else t.length
            if (to > from) sb.append(t, from, to)
            if (l != eLine) sb.append('\n')
            l++
        }
        return sb.toString()
    }

    /**
     * Stable key for a scrollback row. LazyColumn may compose an item lazily
     * AFTER the deque shrank (clear/reset/ED3) but before recomposition
     * catches up with the new count; indexing blindly would throw
     * IndexOutOfBounds mid-composition and crash the app (the large-
     * selection crash pattern). The fallback key is deterministic per
     * index (never collides with real ids, which are positive) and the
     * next pass corrects the count — so this never throws.
     */
    fun scrollbackId(index: Int): Long {
        if (index in scrollback.indices) return scrollback[index].id
        // Deterministic fallback far outside real-id space (real ids are
        // positive): unique per index, so LazyColumn keys can never collide
        // even in this transient state.
        return if (index >= 0) -(index.toLong() + 1L) else Long.MIN_VALUE - index.toLong()
    }

    /**
     * Styled document for one scrollback line. Recently visible rows are
     * cached, but the cache is bounded independently of history length.
     * This keeps repeated viewport composition cheap without retaining a
     * second copy of every line after the user scrolls through a long log.
     */
    fun scrollbackStyled(index: Int): AnnotatedString {
        if (index !in scrollback.indices) return AnnotatedString("")
        val line = scrollback[index]
        styledCache[line.id]?.let { return it }
        val doc = renderRuns(line)
        styledCache[line.id] = doc
        trimStyledCache()
        return doc
    }

    private fun renderRuns(line: ScrollLine): AnnotatedString {
        return buildAnnotatedString {
            if (line.text.isEmpty()) return@buildAnnotatedString
            if (line.spans.isEmpty()) {
                append(line.text)
                return@buildAnnotatedString
            }
            var pos = 0
            for (s in line.spans) {
                val from = s.start.coerceIn(0, line.text.length)
                val to = s.end.coerceIn(from, line.text.length)
                if (from > pos) {
                    append(line.text.substring(pos, from))
                }
                pushStyle(
                    spanStyleFor(s.fg, s.bg, s.bold, s.underline, s.reverse)
                )
                append(line.text.substring(from, to))
                pop()
                pos = to
            }
            if (pos < line.text.length) {
                append(line.text.substring(pos))
            }
        }
    }

    fun isAltActive(): Boolean {
        return altActive
    }

    /** One visible screen row, cursor included. Small: rebuilt per update. */
    fun renderRow(row: Int): AnnotatedString {
        val g = if (altActive) altGrid ?: grid else grid
        val r = row.coerceIn(0, rows - 1)
        val cursorAt = if (showCursor && r == cursorRow) cursorCol else -1
        return renderCells(g[r], cursorAt)
    }

    private fun renderCells(line: TermLine, cursorAt: Int): AnnotatedString {
        return buildAnnotatedString {
            appendStyledLine(line, cursorAt)
        }
    }

    // NOTE: the old full-transcript renderStyled() was intentionally removed.
    // Rendering the whole scrollback as one document per chunk was the main
    // scalability bottleneck; the UI now renders per-line (cached) instead.

    private fun AnnotatedString.Builder.appendStyledLine(
        line: TermLine,
        cursorAt: Int
    ) {
        var end = line.size
        while (end > 0 && line[end - 1].isBlankDefault()) {
            end--
        }
        val len = maxOf(end, if (cursorAt >= 0) cursorAt + 1 else 0)
        if (len == 0) return
        var i = 0
        while (i < len) {
            val cell = if (i < line.size) line[i] else BLANK_CELL
            val isCur = i == cursorAt
            var j = i + 1
            while (j < len) {
                val d = if (j < line.size) line[j] else BLANK_CELL
                if (d.fg != cell.fg || d.bg != cell.bg || d.bold != cell.bold ||
                    d.underline != cell.underline || d.reverse != cell.reverse ||
                    (j == cursorAt) != isCur
                ) {
                    break
                }
                j++
            }
            val text = buildString(j - i) {
                for (k in i until j) {
                    append(if (k < line.size) line[k].ch else ' ')
                }
            }
            pushStyle(styleFor(cell, isCur))
            append(text)
            pop()
            i = j
        }
    }

    private fun styleFor(cell: TermCell, isCursor: Boolean): SpanStyle {
        if (isCursor) {
            return SpanStyle(
                color = Color(IdeTheme.BG),
                background = Color(IdeTheme.TEXT)
            )
        }
        return spanStyleFor(
            cell.fg, cell.bg, cell.bold, cell.underline, cell.reverse
        )
    }

    /** Shared color/attr mapping so grid rows and scrollback runs match. */
    private fun spanStyleFor(
        fgAttr: Int,
        bgAttr: Int,
        bold: Boolean,
        underline: Boolean,
        reverse: Boolean
    ): SpanStyle {
        var fg = if (fgAttr == NO_COLOR) Color(IdeTheme.TEXT) else Color(fgAttr)
        var bg: Color? = if (bgAttr == NO_COLOR) null else Color(bgAttr)
        if (reverse) {
            val t = fg
            fg = bg ?: Color(IdeTheme.BG)
            bg = t
        }
        if (bold && fgAttr == NO_COLOR) {
            fg = Color(IdeTheme.TEXT)
        }
        return SpanStyle(
            color = fg,
            background = bg ?: Color.Unspecified,
            fontWeight = if (bold) FontWeight.Bold else null,
            textDecoration = if (underline) TextDecoration.Underline else null
        )
    }

    companion object {
        private val BLANK_CELL = TermCell()
    }
}
