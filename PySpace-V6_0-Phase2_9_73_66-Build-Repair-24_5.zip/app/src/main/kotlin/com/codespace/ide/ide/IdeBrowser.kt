package com.codespace.ide.ide

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.http.SslError
import android.os.Environment
import android.text.TextUtils
import android.webkit.ConsoleMessage
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.input.pointer.pointerInput
import com.codespace.ide.domain.browser.BrowserUrlPolicy
import com.codespace.ide.ide.browser.BrowserWebViewLifecycle
import com.codespace.ide.ide.theme.IdeTheme

// ---------------------------------------------------------------------------
// Built-in browser: a full WebView (JavaScript, storage, cookies, WebSocket, file upload, downloads,
// permissions, errors) plus the tools a web developer needs on a phone:
//  - device modes (phone / small phone / tablet / laptop / desktop): user agent AND layout viewport,
//    so responsive CSS and desktop-only layouts can be checked without a computer;
//  - a console panel with the page's console.log/errors and load failures;
//  - no cache (a reload always shows the latest code) and a friendly "server not reachable" page.
// ---------------------------------------------------------------------------

enum class BrowserDevice(val label: String, val width: Int, val ua: Int) {
    /** width 0 = the device's own width. ua: 0 phone (default), 1 tablet, 2 desktop. */
    PHONE("Phone (this device)", 0, 0),
    SMALL("Small phone · 360", 360, 0),
    TABLET("Tablet · 768", 768, 1),
    LAPTOP("Laptop · 1280", 1280, 2),
    DESKTOP("Desktop · 1920", 1920, 2)
}

class ConsoleLine(val level: Int, val text: String, val source: String)

/** State + commands of one browser (Compose-observable). */
class BrowserState(startUrl: String = "") {
    var url by mutableStateOf(startUrl)
    var title by mutableStateOf("")
    var progress by mutableStateOf(0)
    var loading by mutableStateOf(false)
    var canBack by mutableStateOf(false)
    var canForward by mutableStateOf(false)
    var device by mutableStateOf(BrowserDevice.PHONE)
    var errors by mutableStateOf(0)
    var findVisible by mutableStateOf(false)
    var findQuery by mutableStateOf("")
    var findMatches by mutableStateOf(0)
    var findActive by mutableStateOf(0)
    val history = mutableStateListOf<String>()
    val console = mutableStateListOf<ConsoleLine>()
    var webView: WebView? = null
    internal val webViewLifecycle = BrowserWebViewLifecycle()
    internal var defaultUa: String = ""

    fun go(raw: String) {
        val u = BrowserUrlPolicy.normalize(raw)
        url = u
        webView?.loadUrl(u)
    }

    fun reload() {
        webView?.reload()
    }

    fun hardReload() {
        webView?.clearCache(true)
        webView?.reload()
    }

    /**
     * Clears the HTTP cache plus localStorage / IndexedDB / WebSQL of the CURRENT page's origin
     * (cookies are kept, so a Jupyter token login survives) and reloads. Stale per-origin state
     * left over from an older server on the same host:port is a classic reason why a page
     * works in the phone browser but not here.
     */
    fun clearSiteData() {
        val wv = webView ?: return
        val origin = try {
            val u = Uri.parse(url)
            if (u.scheme != null && u.authority != null) u.scheme + "://" + u.authority else null
        } catch (_: Throwable) { null }
        try { wv.clearCache(true) } catch (_: Throwable) { }
        try { wv.clearFormData() } catch (_: Throwable) { }
        try {
            if (origin != null) android.webkit.WebStorage.getInstance().deleteOrigin(origin)
            else android.webkit.WebStorage.getInstance().deleteAllData()
        } catch (_: Throwable) { }
        pushConsole(1, "[PySpace] Cleared cache and site data" + (if (origin != null) " for $origin" else ""), "")
        wv.reload()
    }

    fun stop() {
        webView?.stopLoading()
    }

    fun back() {
        webView?.goBack()
    }

    fun forward() {
        webView?.goForward()
    }

    fun find(query: String, forward: Boolean = true) {
        findQuery = query
        if (query.isBlank()) {
            webView?.clearMatches()
            findMatches = 0
            findActive = 0
            return
        }
        if (forward) webView?.findAllAsync(query) else webView?.findNext(false)
    }

    fun pushConsole(level: Int, text: String, source: String) {
        if (level >= 2) errors++
        console.add(ConsoleLine(level, text, source))
        while (console.size > 300) console.removeAt(0)
    }

    fun clearConsole() {
        console.clear()
        errors = 0
    }
}

private fun uaFor(default: String, kind: Int): String {
    if (kind == 0) return default
    val chrome = Regex("Chrome/([0-9.]+)").find(default)?.groupValues?.getOrNull(1) ?: "120.0.0.0"
    return when (kind) {
        1 -> "Mozilla/5.0 (Linux; Android 13; Tablet) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/$chrome Safari/537.36"
        2 -> "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/$chrome Safari/537.36"
        else -> default
    }
}

private const val PAGE_DIAGNOSTICS_JS = """(function(){
if(window.__pyspaceDiagnosticsInstalled)return;window.__pyspaceDiagnosticsInstalled=true;
function S(v,d){d=d||0;try{
if(v===null||v===undefined)return String(v);
if(typeof v==='string')return v;
if(v instanceof Error)return (v.name||'Error')+': '+v.message+(v.stack?'\n'+String(v.stack).split('\n').slice(0,6).join('\n'):'');
if(typeof v==='function')return '[function '+(v.name||'')+']';
if(typeof v==='object'){if(d>2)return '[object]';
if(Array.isArray(v))return '['+v.slice(0,8).map(function(x){return S(x,d+1);}).join(', ')+(v.length>8?', ...':'')+']';
var k=Object.keys(v).slice(0,12);if(!k.length&&v.message)return String(v.message);
return '{'+k.map(function(n){return n+': '+S(v[n],d+1);}).join(', ')+'}';}
return String(v);}catch(e){return '[unprintable]';}}
['warn','error'].forEach(function(n){var o=console[n];if(!o)return;console[n]=function(){var a=[].slice.call(arguments);
var has=a.some(function(x){return x&&typeof x==='object';});
if(has){try{o.call(console,a.map(function(x){return S(x);}).join(' '));return;}catch(_){}}
return o.apply(console,a);};});
window.addEventListener('error',function(e){try{var m=e.message||'Resource/script error';var s=(e.filename||location.href)+':'+(e.lineno||0)+':'+(e.colno||0);console.error('[PySpace page error] '+m+' @ '+s);}catch(_){}},true);
window.addEventListener('unhandledrejection',function(e){try{console.error('[PySpace unhandled promise] '+S(e.reason));}catch(_){}});
try{if(window.fetch){var F=window.fetch;window.fetch=function(i,o){var u=(i&&i.url)||String(i);var p=F.apply(this,arguments);
p.then(function(r){if(!r.ok)console.error('[PySpace fetch] HTTP '+r.status+' '+(r.statusText||'')+' '+u);},function(e){console.error('[PySpace fetch] failed '+u+' : '+S(e));});return p;};}}catch(_){}
try{var X=XMLHttpRequest.prototype,O=X.open;X.open=function(m,u){var t=this,url=String(u);
t.addEventListener('loadend',function(){if(t.status===0||t.status>=400)console.error('[PySpace xhr] '+(t.status||'network error')+' '+m+' '+url);});
return O.apply(this,arguments);};}catch(_){}
function ls(){try{localStorage.setItem('__p','1');localStorage.removeItem('__p');return 'ok';}catch(e){return 'FAIL '+e;}}
try{console.info('[PySpace env] UA='+navigator.userAgent+' | lang='+navigator.language+' | viewport='+innerWidth+'x'+innerHeight+' | secureContext='+window.isSecureContext+' | cookies='+navigator.cookieEnabled+' | localStorage='+ls());}catch(_){}
function chk(t){try{var b=document.body;var n=b?b.getElementsByTagName('*').length:0;
var jp=document.querySelectorAll('[class*="jp-"],[class*="lm-"]').length;var cs=b?getComputedStyle(b):null;
console.info('[PySpace watchdog '+t+'] elements='+n+' jp/lm nodes='+jp+' text='+(b?b.innerText.length:0)+' size='+(b?b.scrollWidth+'x'+b.scrollHeight:'n/a')+' display='+(cs?cs.display:'?')+' visibility='+(cs?cs.visibility:'?'));}catch(_){}}
function R(e){try{if(!e)return 'none';var r=e.getBoundingClientRect();var c=getComputedStyle(e);return (e.id?'#'+e.id:'')+'.'+String(e.className&&e.className.baseVal!==undefined?e.className.baseVal:e.className).split(' ').slice(0,3).join('.')+' @'+Math.round(r.left)+','+Math.round(r.top)+' '+Math.round(r.width)+'x'+Math.round(r.height)+' pos='+c.position+' op='+c.opacity+' vis='+c.visibility+' disp='+c.display+' ov='+c.overflow+' bg='+c.backgroundColor+' fg='+c.color;}catch(x){return 'err';}}
function geo(t){try{var de=document.documentElement,b=document.body,P='[PySpace geo '+t+'] ';
console.info(P+'inner='+innerWidth+'x'+innerHeight+' client='+de.clientWidth+'x'+de.clientHeight+' dpr='+devicePixelRatio+' hidden='+document.hidden+'/'+document.visibilityState+' sheets='+document.styleSheets.length+' mode='+document.compatMode+' scheme='+getComputedStyle(de).colorScheme);
console.info(P+'html '+R(de));console.info(P+'body '+R(b));
[].slice.call(b.children).slice(0,8).forEach(function(c,i){console.info(P+'body>'+i+' '+c.tagName+' '+R(c));});
var sh=document.querySelector('.jp-LabShell,.jp-NotebookShell,#main,[class*=Shell]');console.info(P+'shell '+R(sh));
var m=document.elementFromPoint(Math.floor(innerWidth/2),Math.floor(innerHeight/2));console.info(P+'center '+R(m));
var n=0,t0=Date.now();requestAnimationFrame(function a(){n++;if(n<30)requestAnimationFrame(a);else console.info(P+'30 animation frames in '+(Date.now()-t0)+'ms');});
}catch(x){console.info('[PySpace geo] failed '+x);}}
setTimeout(function(){chk('3s');geo('3s');},3000);setTimeout(function(){chk('10s');geo('10s');},10000);function css(){var out=[],P='[PySpace css] ';
function walk(rs,ctx){for(var j=0;j<rs.length;j++){var r=rs[j];
if(r.cssRules&&!r.selectorText){walk(r.cssRules,ctx+'@'+(r.conditionText||r.constructor.name)+' ');continue;}
var t=r.selectorText;if(!t||!r.style)continue;
if(/(^|[\s,>])(html|body|#main)(?![\w-])/.test(t)||/jp-LabShell|jp-NotebookShell|jp-ThemedContainer/.test(t)){
var p=[];['position','height','min-height','top','bottom','inset','display','overflow'].forEach(function(k){var v=r.style.getPropertyValue(k);if(v)p.push(k+':'+v);});
if(p.length&&out.length<70)out.push(P+ctx+t.slice(0,90)+' {'+p.join('; ')+'}');}}}
try{for(var i=0;i<document.styleSheets.length;i++){var rs;try{rs=document.styleSheets[i].cssRules;}catch(e){out.push(P+'sheet '+i+' unreadable '+(document.styleSheets[i].href||''));continue;}walk(rs,'');}}catch(e){out.push(P+'walk failed '+e);}
console.info(P+'support inset='+CSS.supports('inset','0')+' dvh='+CSS.supports('height','100dvh')+' vh='+CSS.supports('height','100vh')+' :has='+CSS.supports('selector(:has(a))'));
out.forEach(function(l){console.info(l);});}
function lay(){var P='[PySpace layout] ';try{var m=document.getElementById('main');if(!m){console.info(P+'no #main');return;}
console.info(P+'#main style="'+(m.getAttribute('style')||'')+'" class="'+m.className+'"');
[].slice.call(m.children).slice(0,10).forEach(function(c,i){console.info(P+'main>'+i+' '+c.tagName+' '+R(c)+' style="'+(c.getAttribute('style')||'').slice(0,120)+'"');});
var h0=m.getBoundingClientRect().height;window.dispatchEvent(new Event('resize'));
setTimeout(function(){console.info(P+'#main height before resize event='+Math.round(h0)+' after='+Math.round(m.getBoundingClientRect().height));},1500);}catch(e){console.info(P+'failed '+e);}}
setTimeout(function(){geo('20s');css();lay();},20000);
function pxCss(){return 'html,body{height:'+innerHeight+'px!important}body{position:relative!important;margin:0}';}
function fixLayout(tag){try{var m=document.getElementById('main');if(!m||!/lm-Widget/.test(m.className))return;
var h=m.getBoundingClientRect().height;if(innerHeight<200||h>=innerHeight*0.5)return;
var st=document.getElementById('__pyspace_layout_fix');if(!st){st=document.createElement('style');st.id='__pyspace_layout_fix';(document.head||document.documentElement).appendChild(st);
window.addEventListener('resize',function(){var e=document.getElementById('__pyspace_layout_fix');if(e)e.textContent=pxCss();});}
st.textContent=pxCss();
window.dispatchEvent(new Event('resize'));
setTimeout(function(){console.info('[PySpace layout-fix '+tag+'] innerHeight='+innerHeight+' #main height '+Math.round(h)+' -> '+Math.round(m.getBoundingClientRect().height)+' html='+Math.round(document.documentElement.getBoundingClientRect().height));},800);}catch(e){}}
function vhProbe(){try{var P='[PySpace vh-probe] ',r=[];['100vh','100dvh','100svh','100lvh','100%'].forEach(function(u){var d=document.createElement('div');d.style.cssText='position:absolute;left:0;top:0;width:1px;visibility:hidden;height:'+u;(document.body||document.documentElement).appendChild(d);r.push(u+'='+d.offsetHeight);d.remove();});
console.info(P+r.join(' ')+' innerHeight='+innerHeight+' outerHeight='+outerHeight+' visualViewport='+(window.visualViewport?Math.round(visualViewport.height)+'@'+visualViewport.scale:'n/a'));}catch(e){}}
setTimeout(vhProbe,3000);setTimeout(vhProbe,12000);
(function(){var n=0,iv=setInterval(function(){fixLayout('t'+n);if(++n>45)clearInterval(iv);},1000);})();
})();"""

private const val DEVICE_JS = "(function(w){var m=document.querySelector('meta[name=viewport]');" +
    "if(!m){m=document.createElement('meta');m.name='viewport';" +
    "(document.head||document.documentElement).appendChild(m);}" +
    "m.setAttribute('content','width='+w+', initial-scale=1');})(\"%s\");"

private fun errorHtml(url: String, desc: String): String {
    val u = TextUtils.htmlEncode(url)
    val d = TextUtils.htmlEncode(desc)
    return "<html><head><meta name=viewport content=\"width=device-width,initial-scale=1\"><style>" +
        "body{font-family:sans-serif;background:#0b0f14;color:#dbe4ee;display:flex;align-items:center;" +
        "justify-content:center;min-height:100vh;margin:0}.c{max-width:440px;padding:24px;text-align:center}" +
        "h2{color:#ff8a80;margin-bottom:6px}code{color:#9ccc65;word-break:break-all}" +
        "p{line-height:1.6;color:#9fb0c3}button{background:#3ddc84;border:0;padding:12px 24px;" +
        "border-radius:10px;font-size:16px;font-weight:700;margin-top:10px}</style></head><body><div class=c>" +
        "<h2>Can't reach this page</h2><p><code>" + u + "</code></p><p>" + d + "</p>" +
        "<p>If this is your own server: is it running? Start it, then retry.</p>" +
        "<button onclick=\"location.href='" + u + "'\">Retry</button></div></body></html>"
}

private class ChooserHolder {
    var callback: ValueCallback<Array<Uri>>? = null
    var launch: (() -> Unit)? = null
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun IdeWebView(state: BrowserState, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val holder = remember { ChooserHolder() }

    // WebView timers/network activity should pause with the host Activity and
    // resume only when the IDE returns to the foreground. Resolve the Activity
    // without retaining it beyond this composition.
    DisposableEffect(state, ctx) {
        val activity = generateSequence<Context>(ctx) { (it as? android.content.ContextWrapper)?.baseContext }
            .firstOrNull { it is androidx.activity.ComponentActivity } as? androidx.activity.ComponentActivity
        val lifecycle = activity?.lifecycle
        val observer = object : androidx.lifecycle.LifecycleEventObserver {
            override fun onStateChanged(
                source: androidx.lifecycle.LifecycleOwner,
                event: androidx.lifecycle.Lifecycle.Event
            ) {
                when (event) {
                    androidx.lifecycle.Lifecycle.Event.ON_PAUSE -> state.webViewLifecycle.onHostPause()
                    androidx.lifecycle.Lifecycle.Event.ON_RESUME -> state.webViewLifecycle.onHostResume()
                    androidx.lifecycle.Lifecycle.Event.ON_DESTROY -> state.webView?.let {
                        state.webViewLifecycle.release(it)
                        if (state.webView === it) state.webView = null
                    }
                    else -> Unit
                }
            }
        }
        lifecycle?.addObserver(observer)
        onDispose { lifecycle?.removeObserver(observer) }
    }
    val chooser = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        holder.callback?.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
        holder.callback = null
    }
    holder.launch = { chooser.launch(arrayOf("*/*")) }

    AndroidView(
        modifier = modifier,
        factory = { c ->
            val wv = WebView(c)
            state.defaultUa = wv.settings.userAgentString ?: ""
            wv.post {
                try {
                    val pkg = WebView.getCurrentWebViewPackage()
                    state.pushConsole(1, "[PySpace] System WebView: " + (pkg?.packageName ?: "?") + " " +
                        (pkg?.versionName ?: "?") + " | Android " + android.os.Build.VERSION.RELEASE +
                        " (SDK " + android.os.Build.VERSION.SDK_INT + ")", "")
                } catch (_: Throwable) { }
            }
            wv.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                loadsImagesAutomatically = true
                blockNetworkImage = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                mediaPlaybackRequiresUserGesture = true
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
                useWideViewPort = true
                loadWithOverviewMode = true
                allowFileAccess = true
                allowFileAccessFromFileURLs = false
                allowUniversalAccessFromFileURLs = false
                // A reload must always show the latest code you just saved.
                // Keep normal browser caching for modern web applications; Hard reload clears it.
                cacheMode = WebSettings.LOAD_DEFAULT
                setGeolocationEnabled(true)
                javaScriptCanOpenWindowsAutomatically = true
                setSupportMultipleWindows(false)
                allowContentAccess = true
                if (android.os.Build.VERSION.SDK_INT >= 26) safeBrowsingEnabled = true
                userAgentString = uaFor(state.defaultUa, state.device.ua)
            }
            CookieManager.getInstance().apply {
                setAcceptCookie(true)
                setAcceptThirdPartyCookies(wv, true)
            }
            wv.setDownloadListener(DownloadListener { url, ua, cd, mime, _ ->
                try {
                    val name = URLUtil.guessFileName(url, cd, mime)
                    val req = DownloadManager.Request(Uri.parse(url))
                        .setMimeType(mime)
                        .addRequestHeader("User-Agent", ua)
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                    (c.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                    Toast.makeText(c, "Downloading $name", Toast.LENGTH_SHORT).show()
                } catch (_: Exception) {
                    try {
                        c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Exception) {
                    }
                }
            })
            wv.setFindListener { active, count, done ->
                state.findActive = active
                state.findMatches = count
            }
            wv.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val u = request?.url?.toString() ?: return false
                    if (u.startsWith("http://") || u.startsWith("https://") || u.startsWith("file:") ||
                        u.startsWith("about:") || u.startsWith("data:") || u.startsWith("blob:")
                    ) {
                        return false
                    }
                    // tel:, mailto:, intent: ... belong to other apps.
                    try {
                        c.startActivity(Intent(Intent.ACTION_VIEW, request.url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Throwable) {
                    }
                    return true
                }

                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                    try {
                        // Best effort: hooks console/fetch/XHR as early as the platform allows.
                        view?.evaluateJavascript(PAGE_DIAGNOSTICS_JS, null)
                        state.loading = true
                        if (url != null) state.url = url
                        state.canBack = view?.canGoBack() ?: false
                        state.canForward = view?.canGoForward() ?: false
                    } catch (_: Throwable) {
                    }
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    try {
                        state.loading = false
                        if (url != null) state.url = url
                        state.canBack = view?.canGoBack() ?: false
                        state.canForward = view?.canGoForward() ?: false
                        view?.evaluateJavascript(
                            DEVICE_JS.format(if (state.device.width > 0) state.device.width.toString() else "device-width"), null
                        )
                        view?.evaluateJavascript(PAGE_DIAGNOSTICS_JS, null)
                        if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                            if (state.history.lastOrNull() != url) {
                                state.history.add(url)
                                while (state.history.size > 100) state.history.removeAt(0)
                                try {
                                    c.getSharedPreferences("pyspace_browser", Context.MODE_PRIVATE)
                                        .edit()
                                        .putString("history", state.history.joinToString("\n"))
                                        .apply()
                                } catch (_: Throwable) { }
                            }
                        }
                    } catch (_: Throwable) {
                    }
                }

                override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                    try {
                        if (request == null) return
                        val why = error?.description?.toString() ?: "unknown error"
                        val u = request.url.toString()
                        if (request.isForMainFrame) {
                            state.pushConsole(3, "Cannot load " + u + ": " + why, "")
                            view?.loadDataWithBaseURL(u, errorHtml(u, why), "text/html", "UTF-8", u)
                        } else {
                            state.pushConsole(2, "Failed to load " + u + ": " + why, "")
                        }
                    } catch (_: Throwable) {
                    }
                }

                override fun onReceivedHttpError(
                    view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?
                ) {
                    try {
                        val status = errorResponse?.statusCode ?: return
                        if (status >= 400) {
                            val url = request?.url?.toString() ?: "unknown resource"
                            val message = "HTTP $status ${errorResponse.reasonPhrase ?: "Request failed"} — $url"
                            state.pushConsole(if (request?.isForMainFrame == true) 3 else 2, message, "HTTP")
                        }
                    } catch (_: Throwable) { }
                }

                @SuppressLint("WebViewClientOnReceivedSslError")
                override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                    // Self-signed certificates are normal for a dev server on this phone; anywhere else: no.
                    val host = Uri.parse(error.url).host ?: ""
                    if (host == "localhost" || host == "127.0.0.1") handler.proceed() else handler.cancel()
                }
            }
            wv.webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    try {
                        state.progress = newProgress
                    } catch (_: Throwable) {
                    }
                }

                override fun onReceivedTitle(view: WebView?, title: String?) {
                    try {
                        state.title = title ?: ""
                    } catch (_: Throwable) {
                    }
                }

                override fun onConsoleMessage(m: ConsoleMessage?): Boolean {
                    try {
                        if (m == null) return true
                        val lvl = when (m.messageLevel()) {
                            ConsoleMessage.MessageLevel.ERROR -> 3
                            ConsoleMessage.MessageLevel.WARNING -> 2
                            ConsoleMessage.MessageLevel.DEBUG, ConsoleMessage.MessageLevel.TIP -> 0
                            else -> 1
                        }
                        // message() / sourceId() can be null for some pages (it used to crash the app).
                        val text: String = m.message() ?: ""
                        val src: String = (m.sourceId() ?: "").substringAfterLast('/')
                        state.pushConsole(lvl, text, if (src.isEmpty()) "" else src + ":" + m.lineNumber())
                    } catch (_: Throwable) {
                    }
                    return true
                }

                override fun onShowFileChooser(
                    webView: WebView, filePathCallback: ValueCallback<Array<Uri>>,
                    fileChooserParams: WebChromeClient.FileChooserParams
                ): Boolean {
                    holder.callback?.onReceiveValue(null)
                    holder.callback = filePathCallback
                    holder.launch?.invoke()
                    return true
                }

                override fun onPermissionRequest(request: PermissionRequest?) {
                    // Camera / microphone for pages that ask (the app's own permissions decide).
                    try {
                        if (request == null) return
                        val ok = request.resources.filter { resource ->
                            val permission = when (resource) {
                                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> android.Manifest.permission.CAMERA
                                // Audio capture is deliberately denied unless a future explicit
                                // microphone permission flow is implemented by the app.
                                else -> null
                            }
                            permission != null && c.checkSelfPermission(permission) ==
                                android.content.pm.PackageManager.PERMISSION_GRANTED
                        }
                        if (ok.size == request.resources.size && ok.isNotEmpty()) request.grant(ok.toTypedArray())
                        else request.deny()
                    } catch (_: Throwable) {
                    }
                }

                override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                    try {
                        val o = origin ?: ""
                        val local = o.contains("://localhost") || o.contains("://127.0.0.1")
                        callback?.invoke(o, local, false)
                    } catch (_: Throwable) {
                    }
                }
            }
            state.webView = wv
            state.webViewLifecycle.attach(wv)
            if (state.url.isNotBlank()) wv.loadUrl(state.url)
            wv
        },
        update = { wv ->
            try {
                val ua = uaFor(state.defaultUa, state.device.ua)
                if (wv.settings.userAgentString != ua) {
                    wv.settings.userAgentString = ua
                    wv.reload()
                } else {
                    wv.evaluateJavascript(DEVICE_JS.format(if (state.device.width > 0) state.device.width.toString() else "device-width"), null)
                }
            } catch (_: Throwable) {
            }
        },
        onRelease = { wv ->
            // Cancel any pending Android document-picker callback before the
            // WebView is destroyed; otherwise the WebChromeClient can retain
            // an Activity callback after the browser overlay closes.
            try { holder.callback?.onReceiveValue(null) } catch (_: Exception) { }
            holder.callback = null
            holder.launch = null
            state.webViewLifecycle.release(wv)
            if (state.webView === wv) state.webView = null
        }
    )
}

/** Full-screen browser with an address bar, device modes and a console. */
@Composable
fun BrowserScreen(
    state: BrowserState,
    onClose: () -> Unit,
    onOpenExternal: (String) -> Unit
) {
    val ctx = LocalContext.current
    val focusManager = LocalFocusManager.current
    val keyboard = LocalSoftwareKeyboardController.current
    var menu by remember { mutableStateOf(false) }
    var previewMenu by remember { mutableStateOf(false) }
    var showConsole by remember { mutableStateOf(false) }
    var showBookmarks by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var consoleHeight by remember { mutableStateOf(320f) }
    var field by remember(state.url) { mutableStateOf(state.url) }
    val browserPrefs = remember(ctx) { ctx.getSharedPreferences("pyspace_browser", Context.MODE_PRIVATE) }
    var bookmarks by remember {
        mutableStateOf(browserPrefs.getString("bookmarks", "").orEmpty().split('\n').filter { it.isNotBlank() })
    }
    LaunchedEffect(state) {
        if (state.history.isEmpty()) {
            state.history.addAll(browserPrefs.getString("history", "").orEmpty().split('\n').filter { it.isNotBlank() }.takeLast(100))
        }
    }

    BackHandler {
        when {
            menu -> menu = false
            showBookmarks -> showBookmarks = false
            showHistory -> showHistory = false
            state.findVisible -> { state.findVisible = false; state.webView?.clearMatches() }
            showConsole -> showConsole = false
            state.canBack -> state.back()
            else -> onClose()
        }
    }

    // This full-screen click target is intentional: the browser is an exclusive
    // overlay. Empty toolbar gaps/background must never forward taps to the editor
    // underneath (which has its own ⋮ menu in almost the same screen area).
    Column(
        Modifier.fillMaxSize()
            .background(Color(IdeTheme.BG))
            .clickable(
                interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                indication = null
            ) { }
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        Row(
            Modifier.fillMaxWidth()
                .background(Color(IdeTheme.PANEL))
                .padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            BrowserIcon("×", true, "Close browser") { onClose() }
            BrowserIcon("‹", state.canBack, "Go back") { state.back() }
            BrowserIcon("›", state.canForward, "Go forward") { state.forward() }
            BasicTextField(
                value = field,
                onValueChange = { field = it },
                singleLine = true,
                textStyle = TextStyle(color = Color(IdeTheme.TEXT), fontSize = 13.sp, fontFamily = FontFamily.Monospace),
                cursorBrush = SolidColor(Color(IdeTheme.ACCENT)),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = {
                    state.go(field)
                    focusManager.clearFocus()
                    keyboard?.hide()
                }),
                modifier = Modifier.weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(IdeTheme.CARD))
                    .padding(horizontal = 11.dp, vertical = 11.dp)
            )
            BrowserIcon(if (state.loading) "■" else "↻", true,
                if (state.loading) "Stop loading" else "Reload page") {
                if (state.loading) state.stop() else state.reload()
            }
            BrowserIcon("⌕", true, "Find in page") { state.findVisible = !state.findVisible }
            Box {
                BrowserIcon("⋮", true, "Browser options") { menu = true }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Add bookmark") }, onClick = {
                        menu = false
                        val updated = (bookmarks + state.url).distinct().takeLast(100)
                        bookmarks = updated
                        browserPrefs.edit().putString("bookmarks", updated.joinToString("\n")).apply()
                        Toast.makeText(ctx, "Bookmark saved", Toast.LENGTH_SHORT).show()
                    })
                    DropdownMenuItem(text = { Text("Bookmarks (${bookmarks.size})") }, onClick = {
                        menu = false
                        showBookmarks = true
                    })
                    DropdownMenuItem(text = { Text("Recent history (${state.history.size})") }, onClick = {
                        menu = false
                        showHistory = true
                    })
                    DropdownMenuItem(
                        text = { Text("Share address") },
                        onClick = {
                            menu = false
                            try {
                                val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, state.url)
                                cxtStartShare(ctx, send)
                            } catch (_: Throwable) { }
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Developer console" + if (state.errors > 0) "  (${state.errors} errors)" else "") },
                        onClick = { menu = false; showConsole = !showConsole }
                    )
                    DropdownMenuItem(
                        text = { Text("Hard reload · clear cache") },
                        onClick = { menu = false; state.hardReload() }
                    )
                    DropdownMenuItem(
                        text = { Text("Clear site data · reload") },
                        onClick = { menu = false; state.clearSiteData() }
                    )
                    DropdownMenuItem(
                        text = { Text("Open in phone browser") },
                        onClick = { menu = false; onOpenExternal(state.url) }
                    )
                    DropdownMenuItem(
                        text = { Text("Copy address") },
                        onClick = {
                            menu = false
                            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            cm.setPrimaryClip(android.content.ClipData.newPlainText("url", state.url))
                            Toast.makeText(ctx, "Address copied", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
        if (state.loading && state.progress in 1..99) {
            LinearProgressIndicator(
                progress = state.progress / 100f,
                modifier = Modifier.fillMaxWidth(),
                color = Color(IdeTheme.ACCENT),
                trackColor = Color(IdeTheme.PANEL)
            )
        } else {
            Spacer(Modifier.padding(top = 2.dp))
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    state.title.ifBlank { "IDE Browser" }, color = Color(IdeTheme.TEXT), fontSize = 12.sp,
                    maxLines = 1
                )
                Text(
                    state.url, color = Color(IdeTheme.DIM), fontSize = 10.sp,
                    maxLines = 1
                )
            }
            Box {
                Text(
                    state.device.label, color = Color(IdeTheme.ACCENT), fontSize = 10.sp,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp))
                        .clickable { previewMenu = true }
                        .background(Color(IdeTheme.CARD))
                        .padding(horizontal = 9.dp, vertical = 7.dp)
                )
                DropdownMenu(expanded = previewMenu, onDismissRequest = { previewMenu = false }) {
                    Text("DISPLAY PREVIEW", color = Color(IdeTheme.DIM), fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                    BrowserDevice.values().forEach { device ->
                        DropdownMenuItem(
                            text = { Text((if (state.device == device) "✓  " else "     ") + device.label) },
                            onClick = { previewMenu = false; state.device = device }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(if (state.device.ua == 2) "✓ Desktop site" else "Desktop site") },
                        onClick = { previewMenu = false; state.device = if (state.device.ua == 2) BrowserDevice.PHONE else BrowserDevice.DESKTOP }
                    )
                }
            }
        }
        if (state.findVisible) {
            Row(
                Modifier.fillMaxWidth().background(Color(IdeTheme.CARD)).padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = state.findQuery,
                    onValueChange = { state.find(it) },
                    singleLine = true,
                    textStyle = TextStyle(color = Color(IdeTheme.TEXT), fontSize = 13.sp),
                    cursorBrush = SolidColor(Color(IdeTheme.ACCENT)),
                    modifier = Modifier.weight(1f).padding(8.dp),
                    decorationBox = { inner -> Box { if (state.findQuery.isEmpty()) Text("Find on page", color = Color(IdeTheme.DIM), fontSize = 13.sp); inner() } }
                )
                Text("${state.findActive}/${state.findMatches}", color = Color(IdeTheme.DIM), fontSize = 11.sp)
                BrowserIcon("↑", state.findMatches > 0, "Previous match") { state.webView?.findNext(false) }
                BrowserIcon("↓", state.findMatches > 0, "Next match") { state.webView?.findNext(true) }
                BrowserIcon("×", true, "Close find") { state.findVisible = false; state.webView?.clearMatches() }
            }
        }
        // The web page always owns the full viewport. Developer Console is a
        // separate bottom overlay, so resizing it never changes the page's
        // measured height or triggers a responsive-layout/viewport reflow.
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
            IdeWebView(state, Modifier.fillMaxSize())
            if (showConsole) {
                val density = LocalDensity.current.density
                val consoleMaxHeight = (maxHeight.value - 4f).coerceAtLeast(120f)
                BrowserConsole(
                    modifier = Modifier.align(Alignment.BottomCenter),
                    state = state,
                    height = consoleHeight.coerceIn(120f, consoleMaxHeight),
                    maxHeight = consoleMaxHeight,
                    onHeightChange = { consoleHeight = it },
                    density = density,
                    onClose = { showConsole = false }
                )
            }
        }
        if (showBookmarks) {
            BrowserLinkDialog("Bookmarks", bookmarks, onDismiss = { showBookmarks = false }, onSelect = {
                showBookmarks = false; state.go(it)
            }, onRemove = { item ->
                bookmarks = bookmarks.filterNot { it == item }
                browserPrefs.edit().putString("bookmarks", bookmarks.joinToString("\n")).apply()
            })
        }
        if (showHistory) {
            BrowserLinkDialog("Recent history", state.history.toList().asReversed(), onDismiss = { showHistory = false }, onSelect = {
                showHistory = false; state.go(it)
            })
        }
    }
}

@Composable
private fun BrowserLinkDialog(
    title: String,
    links: List<String>,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit,
    onRemove: ((String) -> Unit)? = null
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(IdeTheme.PANEL),
        title = { Text(title, color = Color(IdeTheme.TEXT)) },
        text = {
            if (links.isEmpty()) Text("Nothing here yet.", color = Color(IdeTheme.DIM))
            else LazyColumn(Modifier.heightIn(max = 360.dp)) {
                items(links) { link ->
                    Row(Modifier.fillMaxWidth().clickable { onSelect(link) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(link, color = Color(IdeTheme.TEXT), fontSize = 12.sp, maxLines = 2,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        if (onRemove != null) Text("×", color = Color(IdeTheme.WARN), modifier = Modifier.clickable { onRemove(link) }.padding(8.dp))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

private fun cxtStartShare(context: Context, intent: Intent) {
    context.startActivity(Intent.createChooser(intent, "Share page").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

@Composable
private fun BrowserIcon(
    glyph: String,
    enabled: Boolean,
    description: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier.sizeIn(minWidth = 44.dp, minHeight = 46.dp)
            .clip(RoundedCornerShape(11.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) {
        Text(
            glyph, fontSize = 21.sp,
            color = Color(if (enabled) IdeTheme.TEXT else IdeTheme.DIM),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun BrowserConsole(
    modifier: Modifier = Modifier,
    state: BrowserState,
    height: Float,
    maxHeight: Float,
    onHeightChange: (Float) -> Unit,
    density: Float,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    val clipboard = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
    var filter by remember { mutableStateOf("All") }

    fun copyMessages(onlyErrors: Boolean) {
        val lines = state.console.filter { !onlyErrors || it.level >= 3 }
        val content = lines.joinToString("\n") { line ->
            buildString {
                append(if (line.level >= 3) "ERROR" else if (line.level == 2) "WARNING" else "LOG")
                append(": ")
                append(line.text)
                if (line.source.isNotBlank()) append("\n  at ").append(line.source)
            }
        }
        if (content.isNotBlank()) {
            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Browser console", content))
            Toast.makeText(ctx, if (onlyErrors) "Errors copied (${lines.size})" else "Console copied (${lines.size})", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(ctx, if (onlyErrors) "No errors to copy" else "Console is empty", Toast.LENGTH_SHORT).show()
        }
    }

    Column(modifier.fillMaxWidth().height(height.dp).background(Color(IdeTheme.PANEL))) {
        // Drag handle: drag upward to give the console more room, downward to shrink it.
        Box(
            Modifier.fillMaxWidth().height(24.dp)
                .pointerInput(density, maxHeight) {
                    var currentHeight = height
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        currentHeight = (currentHeight - dragAmount.y / density).coerceIn(120f, maxHeight)
                        onHeightChange(currentHeight)
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.width(42.dp).height(4.dp).clip(RoundedCornerShape(4.dp)).background(Color(IdeTheme.DIM)))
        }
        Row(
            Modifier.fillMaxWidth().padding(start = 10.dp, end = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Console", color = Color(IdeTheme.TEXT), fontSize = 12.sp, modifier = Modifier.weight(1f))
            listOf("All", "Warning", "Error").forEach { option ->
                val selected = filter == option
                Text(option, color = Color(if (selected) IdeTheme.ACCENT else IdeTheme.DIM), fontSize = 10.sp,
                    modifier = Modifier.clip(RoundedCornerShape(6.dp)).clickable { filter = option }
                        .background(if (selected) Color(IdeTheme.CARD) else Color.Transparent)
                        .padding(horizontal = 7.dp, vertical = 6.dp))
            }
            Text("Copy errors", color = Color(IdeTheme.WARN), fontSize = 11.sp,
                modifier = Modifier.clickable { copyMessages(true) }.padding(horizontal = 7.dp, vertical = 6.dp))
            Text("Copy all", color = Color(IdeTheme.ACCENT), fontSize = 11.sp,
                modifier = Modifier.clickable { copyMessages(false) }.padding(horizontal = 7.dp, vertical = 6.dp))
            Text("Clear", color = Color(IdeTheme.DIM), fontSize = 11.sp,
                modifier = Modifier.clickable { state.clearConsole() }.padding(horizontal = 7.dp, vertical = 6.dp))
            Text("✕", color = Color(IdeTheme.DIM), fontSize = 14.sp,
                modifier = Modifier.clickable { onClose() }.padding(horizontal = 8.dp, vertical = 4.dp))
        }
        val visibleLines = state.console.filter { line ->
            when (filter) { "Warning" -> line.level == 2; "Error" -> line.level >= 3; else -> true }
        }
        if (visibleLines.isEmpty()) {
            Text(if (state.console.isEmpty()) "No messages yet." else "No ${filter.lowercase()} messages.", color = Color(IdeTheme.DIM), fontSize = 12.sp, modifier = Modifier.padding(10.dp))
        }
        LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
            items(visibleLines.asReversed()) { line ->
                val col = when (line.level) {
                    3 -> Color(IdeTheme.ERROR)
                    2 -> Color(IdeTheme.WARN)
                    0 -> Color(IdeTheme.DIM)
                    else -> Color(IdeTheme.TEXT)
                }
                Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 3.dp)) {
                    Text(
                        line.text,
                        color = col,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (line.source.isNotBlank()) {
                        Text(line.source, color = Color(IdeTheme.DIM), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}
