package com.codespace.ide.ide.packages
import com.codespace.ide.ide.HTML



/** Curated popular packages for the graphical installer. */
data class PopularPkg(val name: String, val desc: String)

fun popularPackages(): List<PopularPkg> {
    return listOf(
        PopularPkg("requests", "HTTP for humans"),
        PopularPkg("numpy", "numerical computing"),
        PopularPkg("pandas", "data analysis"),
        PopularPkg("matplotlib", "plotting"),
        PopularPkg("flask", "micro web framework"),
        PopularPkg("django", "full web framework"),
        PopularPkg("fastapi", "modern APIs"),
        PopularPkg("pytest", "testing"),
        PopularPkg("rich", "pretty terminal output"),
        PopularPkg("pillow", "imaging (PIL)"),
        PopularPkg("opencv-python", "computer vision"),
        PopularPkg("sqlalchemy", "SQL toolkit"),
        PopularPkg("httpx", "async HTTP client"),
        PopularPkg("beautifulsoup4", "web scraping"),
        PopularPkg("lxml", "XML/HTML parsing"),
        PopularPkg("jupyter", "notebooks"),
        PopularPkg("click", "CLI builder"),
        PopularPkg("pyyaml", "YAML support"),
        PopularPkg("aiohttp", "async HTTP"),
        PopularPkg("pygame", "games")
    )
}
