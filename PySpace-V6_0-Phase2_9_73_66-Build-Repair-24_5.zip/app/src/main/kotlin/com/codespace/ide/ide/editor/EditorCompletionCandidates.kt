package com.codespace.ide.ide.editor

import com.codespace.ide.ide.codeintel.PythonCompletionItem

/** Pure candidate normalization and context filtering shared by editor completion flows. */
internal object EditorCompletionCandidates {
    fun isImportContext(source: String, cursor: Int): Boolean {
        val safeCursor = cursor.coerceIn(0, source.length)
        val lineStart = if (safeCursor == 0) 0
        else (source.lastIndexOf('\n', safeCursor - 1) + 1).coerceIn(0, safeCursor)
        val prefix = source.substring(lineStart, safeCursor).trimStart()
        return prefix.startsWith("import ") || prefix == "import" ||
            (prefix.startsWith("from ") && prefix.contains(" import"))
    }

    fun filterForContext(
        items: List<PythonCompletionItem>,
        candidatePrefix: String,
        explicitMemberContext: Boolean
    ): List<PythonCompletionItem> = items.filter { item ->
        explicitMemberContext || (candidatePrefix.isNotEmpty() &&
            item.name.startsWith(candidatePrefix) && item.name != candidatePrefix)
    }

    /** Deduplicates by visible name, preferring auto-import entries, then best rank. */
    fun mergeRanked(items: List<PythonCompletionItem>, limit: Int = 80): List<PythonCompletionItem> =
        items.groupBy { it.name }
            .values
            .map { sameName ->
                sameName.firstOrNull { it.autoImportStatement != null }
                    ?: sameName.minBy { it.priority }
            }
            .sortedWith(compareBy<PythonCompletionItem> { it.priority }.thenBy { it.name.lowercase() })
            .take(limit.coerceAtLeast(0))
}
