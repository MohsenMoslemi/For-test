package com.codespace.ide.ide.codeintel

import com.codespace.ide.ProotManager
import java.nio.charset.StandardCharsets
import java.util.Base64
import org.json.JSONObject
import com.codespace.ide.ide.projects.PyProject

/**
 * Resolves imported top-level modules against the exact interpreter selected for
 * one project. Source is parsed with Python's AST; user code is never executed.
 * A null result means the environment could not be queried reliably.
 */
internal class LspImportResolver(
    private val proot: ProotManager,
    private val project: PyProject,
    private val workspaceConfiguration: LspWorkspaceConfiguration,
) {
    fun resolve(source: String): List<PythonSyntaxDiagnostic>? {
        if (source.length > MAX_SOURCE_CHARS) return null
        val (python, _) = workspaceConfiguration.selectedInterpreter()
        if (python.isNullOrBlank()) return null
        val encoded = Base64.getEncoder().encodeToString(source.toByteArray(StandardCharsets.UTF_8))
        val script = """
            import ast, base64, importlib.util, json, sys
            source = base64.b64decode(sys.argv[1]).decode('utf-8')
            try:
                tree = ast.parse(source, filename='<pyspace-editor-buffer>')
            except SyntaxError:
                print(json.dumps({'ok': True, 'missing': []}))
                raise SystemExit(0)
            found = []
            seen = set()
            for node in ast.walk(tree):
                names = []
                if isinstance(node, ast.Import):
                    names = [alias.name for alias in node.names]
                elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                    names = [node.module]
                for name in names:
                    top_level = name.split('.', 1)[0]
                    key = (top_level, int(node.lineno))
                    if not top_level or key in seen:
                        continue
                    seen.add(key)
                    try:
                        available = importlib.util.find_spec(top_level) is not None
                    except Exception:
                        available = False
                    if not available:
                        found.append({'line': int(node.lineno), 'column': int(node.col_offset) + 1,
                                      'name': top_level})
            print(json.dumps({'ok': True, 'missing': found}, ensure_ascii=False))
            """.trimIndent()
        return try {
            val guestProject = guestProjectPath(project).trimEnd('/')
            val command = "cd ${shellQuote(guestProject)} || exit 1; ${shellQuote(python)} -c ${shellQuote(script)} ${shellQuote(encoded)}"
            val output = proot.runOnce(command, timeoutSec = IMPORT_RESOLUTION_TIMEOUT_SECONDS)
            val jsonLine = output.lineSequence().map { it.trim() }.lastOrNull {
                it.startsWith("{") && it.endsWith("}")
            } ?: return null
            val json = JSONObject(jsonLine)
            if (!json.optBoolean("ok", false)) return null
            val array = json.optJSONArray("missing") ?: return emptyList()
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    val line = item.optInt("line", 0)
                    val name = item.optString("name").trim()
                    if (line <= 0 || name.isBlank()) continue
                    add(PythonSyntaxDiagnostic(
                        line = line,
                        column = item.optInt("column", 1).coerceAtLeast(1),
                        endLine = line,
                        endColumn = (item.optInt("column", 1) + name.length).coerceAtLeast(2),
                        message = "Import '$name' could not be resolved in this project's Python environment",
                        kind = "Error",
                        code = "PYSPACE_IMPORT_NOT_FOUND",
                    ))
                }
            }
        } catch (_: Exception) {
            null
        }
    }


    private fun shellQuote(value: String): String = "'" + value.replace("'", "'\\''") + "'"


    private companion object {
        const val MAX_SOURCE_CHARS = 250_000
        const val IMPORT_RESOLUTION_TIMEOUT_SECONDS = 6L
    }
}
