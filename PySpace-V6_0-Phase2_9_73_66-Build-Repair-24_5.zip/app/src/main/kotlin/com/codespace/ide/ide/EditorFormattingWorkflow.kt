package com.codespace.ide.ide

import android.widget.Toast
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import com.codespace.ide.ide.codeintel.PythonImportAnalysis
import com.codespace.ide.ide.codeintel.PythonLspController
import com.codespace.ide.ide.codeintel.PythonSyntaxDiagnostic
import com.codespace.ide.ide.editor.OpenTab
import com.codespace.ide.ide.editor.lineColAt

/**
 * Coordinates formatting and import-fix requests, including the explicit confirmation
 * required when indentation has to be reconstructed. The caller remains the sole owner
 * of the editor buffer and receives accepted document changes through [onFieldChange].
 */
@Composable
internal fun EditorFormattingWorkflow(
    tab: OpenTab,
    field: TextFieldValue,
    onFieldChange: (TextFieldValue) -> Unit,
    tabWidth: Int,
    isPythonLanguage: Boolean,
    reformatRequest: Int,
    onReformatConsumed: () -> Unit,
    fixImportsRequest: Int,
    onFixImportsConsumed: () -> Unit,
    analyzeImports: suspend (String) -> PythonImportAnalysis,
    pythonLspController: PythonLspController?,
    syntaxDiagnostics: List<PythonSyntaxDiagnostic>,
    syntaxValidatedSource: String?,
    reportCursor: (Int, Int) -> Unit,
) {
    val context = LocalContext.current
    var flatPrompt by remember(tab.file.absolutePath) {
        mutableStateOf<Pair<ReformatResult, ReformatResult>?>(null)
    }

    fun toast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    fun applyReformat(result: ReformatResult) {
        if (result.text == field.text) {
            toast("Nothing to reformat")
            return
        }
        tab.applyEdit(result.text, field.selection.start, field.selection.end)
        onFieldChange(TextFieldValue(result.text, TextRange(result.caret)))
        val cursor = lineColAt(result.text, result.caret)
        reportCursor(cursor[0], cursor[1])
        toast("Reformatted (${result.changedLines} lines)")
    }

    EditorFormattingEffects(
        tab = tab,
        field = field,
        onFieldChange = onFieldChange,
        tabWidth = tabWidth,
        isPythonLanguage = isPythonLanguage,
        reformatRequest = reformatRequest,
        onReformatConsumed = onReformatConsumed,
        fixImportsRequest = fixImportsRequest,
        onFixImportsConsumed = onFixImportsConsumed,
        analyzeImports = analyzeImports,
        pythonLspController = pythonLspController,
        syntaxDiagnostics = syntaxDiagnostics,
        syntaxValidatedSource = syntaxValidatedSource,
        toast = ::toast,
        applyReformat = ::applyReformat,
        onFlatIndentationDetected = { ordinary, rebuilt ->
            flatPrompt = ordinary to rebuilt
        },
        reportCursor = reportCursor
    )

    val prompt = flatPrompt
    if (prompt != null) {
        IdeAlertDialog(
            onDismissRequest = { flatPrompt = null },
            title = { Text("Indentation was lost") },
            text = {
                Text(
                    "Every line starts at the left edge, so the structure has to be guessed from the " +
                        "lines that end with ':'. This is a best effort — please read the result."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    flatPrompt = null
                    applyReformat(prompt.second)
                }) { Text("Rebuild indentation") }
            },
            dismissButton = {
                androidx.compose.foundation.layout.Row {
                    TextButton(onClick = {
                        flatPrompt = null
                        applyReformat(prompt.first)
                    }) { Text("Clean up only") }
                    TextButton(onClick = { flatPrompt = null }) { Text("Cancel") }
                }
            }
        )
    }
}
