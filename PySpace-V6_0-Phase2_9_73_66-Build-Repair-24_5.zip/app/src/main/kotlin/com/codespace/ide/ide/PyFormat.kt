package com.codespace.ide.ide


// ---------------------------------------------------------------------------
// Python indentation engine: pure functions, no Android/Compose dependency.
//
//  * enterPlan      indentation of the new line after Enter (blocks, brackets, return/pass...)
//  * dedentTarget   if/elif/else, try/except/else/finally line up by themselves when ':' is typed
//  * smartBackspace Backspace inside indentation removes one whole level
//  * reformat       cleans pasted code (tabs, odd widths, base indent, NBSP, CRLF, trailing spaces)
//
// A scanner walks the text once and knows which lines start inside a string, inside brackets
// or after a backslash; those are never treated as statement starts, so strings and
// multi-line calls are safe. The logic mirrors a Python reference that has its own test-suite.
// ---------------------------------------------------------------------------

private val INVIS_REPLACE: Set<Char> =
    (setOf('\u00a0', '\u2007', '\u202f', '\u3000') + ('\u2002'..'\u200a')).toSet()
private val INVIS_REMOVE: Set<Char> = setOf('\u200b', '\u200c', '\u200d', '\u2060', '\ufeff')
private val WORD_RE = Regex("^[A-Za-z_]+")
private val CHAIN_KW = setOf("elif", "else", "except", "finally")
private val ENDER_KW = setOf("return", "break", "continue", "pass", "raise")
private val DEDENT_LINE_RE = Regex("""^( *)(else|finally)\s*:$|^( *)(elif|except)\b.*:$""")

private fun targetsOf(kw: String): Set<String> = when (kw) {
    "elif" -> setOf("if", "elif")
    "else" -> setOf("if", "elif", "for", "while", "try", "except")
    "except" -> setOf("try", "except")
    "finally" -> setOf("try", "except", "else")
    else -> emptySet()
}

internal class PyLine(
    val start: Int,
    val end: Int,
    val text: String,
    val startInStr: Boolean,
    val startDepth: Int,
    val startBs: Boolean,
    val endInStr: Boolean,
    val endDepth: Int,
    val endBs: Boolean,
    /** The line with strings replaced by "S" and comments removed. */
    val code: String,
    /** Width of the leading whitespace (tab = tabWidth). */
    val lead: Int
)

internal class PyBracket(val line: Int, val col: Int, val ch: Char)

internal class PyScan(val lines: List<PyLine>, val stack: List<PyBracket>)

private fun leadWidth(s: String, tab: Int): Int {
    var w = 0
    for (c in s) {
        if (c == ' ') w++ else if (c == '\t') w += tab else break
    }
    return w
}

private fun leadLen(s: String): Int {
    var i = 0
    while (i < s.length && (s[i] == ' ' || s[i] == '\t')) i++
    return i
}

internal fun pyScan(text: String, tab: Int, clean: Boolean = false): PyScan {
    val lines = ArrayList<PyLine>()
    val stack = ArrayList<PyBracket>()
    val n = text.length
    var i = 0
    var inStr: String? = null
    var depth = 0
    var bs = false
    var idx = 0
    while (true) {
        var j = text.indexOf('\n', i)
        if (j < 0) j = n
        val startInStr = inStr != null
        val startDepth = depth
        val startBs = bs
        val code = StringBuilder()
        val out = StringBuilder()
        var k = i
        var comment = false
        var escapedEol = false
        while (k < j) {
            var c = text[k]
            val s = inStr
            if (s != null) {
                if (c == '\\') {
                    out.append(c)
                    if (k + 1 < j) out.append(text[k + 1]) else escapedEol = true
                    k += 2
                    continue
                }
                if (text.startsWith(s, k)) {
                    out.append(s)
                    k += s.length
                    inStr = null
                    continue
                }
                out.append(c)
                k++
                continue
            }
            if (c == '#') {
                comment = true
                out.append(text, k, j)
                k = j
                break
            }
            if (clean) {
                if (c in INVIS_REMOVE) {
                    k++
                    continue
                }
                if (c in INVIS_REPLACE) c = ' '
            }
            if (c == '\'' || c == '"') {
                val three = c.toString().repeat(3)
                if (text.startsWith(three, k)) {
                    inStr = three
                    out.append(three)
                    k += 3
                } else {
                    inStr = c.toString()
                    out.append(c)
                    k++
                }
                code.append('S')
                continue
            }
            if (c == '(' || c == '[' || c == '{') {
                stack.add(PyBracket(idx, out.length, c))
                depth++
            } else if (c == ')' || c == ']' || c == '}') {
                if (stack.isNotEmpty()) stack.removeAt(stack.size - 1)
                if (depth > 0) depth--
            }
            out.append(c)
            code.append(c)
            k++
        }
        // A plain (non-triple) string cannot continue past its line unless the newline was escaped.
        val cur = inStr
        if (cur != null && cur.length == 1 && !escapedEol) inStr = null
        val lineText = out.toString()
        val bsEnd = !comment && inStr == null && lineText.endsWith("\\")
        lines.add(
            PyLine(
                start = i, end = j, text = lineText,
                startInStr = startInStr, startDepth = startDepth, startBs = startBs,
                endInStr = inStr != null, endDepth = depth, endBs = bsEnd,
                code = code.toString(), lead = leadWidth(lineText, tab)
            )
        )
        bs = bsEnd
        idx++
        if (j >= n) break
        i = j + 1
    }
    return PyScan(lines, stack)
}

private fun isStmtStart(l: PyLine) = !l.startInStr && l.startDepth == 0 && !l.startBs
private fun isBlankLine(l: PyLine) = l.text.trim(' ', '\t').isEmpty()
private fun isCommentOnly(l: PyLine) = l.code.trim().isEmpty() && l.text.trimStart(' ', '\t').startsWith("#")
private fun firstWord(code: String): String = WORD_RE.find(code.trimStart())?.value ?: ""
private fun isCodeStmt(l: PyLine) = isStmtStart(l) && !isBlankLine(l) && !isCommentOnly(l) && l.code.trim().isNotEmpty()

private fun logicalStart(lines: List<PyLine>, from: Int): Int {
    var i = from
    while (i > 0 && !isStmtStart(lines[i])) i--
    return i
}

// ----------------------------------------------------------------------------- Enter

internal class EnterPlan(val prefix: String, val indent: String, val split: Boolean, val closeIndent: String)

/** [prefix] = text before the new line break, [after] = text after it. */
internal fun enterPlan(prefix: String, after: String, tab: Int): EnterPlan {
    val sc = pyScan(prefix, tab)
    val lastIdx = sc.lines.size - 1
    val last = sc.lines[lastIdx]
    val lineText = prefix.substring(last.start)
    val lw = last.lead
    if (last.endInStr) return EnterPlan(prefix, " ".repeat(lw), false, "")
    if (lineText.isNotEmpty() && lineText.trim(' ', '\t').isEmpty() && !last.startInStr) {
        // Whitespace-only previous line: drop its trailing spaces, keep the indentation.
        return EnterPlan(prefix.substring(0, last.start), " ".repeat(lw), false, "")
    }
    if (last.endDepth > 0 && sc.stack.isNotEmpty()) {
        val br = sc.stack[sc.stack.size - 1]
        val bl = sc.lines[br.line]
        val bIndent = bl.lead
        val stripped = prefix.trimEnd(' ', '\t')
        val lastCh = if (stripped.isNotEmpty()) stripped[stripped.length - 1] else ' '
        val opener = lastCh == '(' || lastCh == '[' || lastCh == '{'
        if (opener && lastIdx == br.line && stripped.length - last.start - 1 == br.col) {
            val closer = when (lastCh) {
                '(' -> ')'
                '[' -> ']'
                else -> '}'
            }
            val split = after.isNotEmpty() && after[0] == closer
            return EnterPlan(prefix, " ".repeat(bIndent + tab), split, " ".repeat(bIndent))
        }
        if (opener) return EnterPlan(prefix, " ".repeat(last.lead + tab), false, "")
        if (br.line == lastIdx && br.col + 1 < lineText.trimEnd(' ', '\t').length) {
            return EnterPlan(prefix, " ".repeat(br.col + 1), false, "")
        }
        return EnterPlan(prefix, " ".repeat(lw), false, "")
    }
    val sIdx = logicalStart(sc.lines, lastIdx)
    val stmt = sc.lines[sIdx]
    val stmtIndent = stmt.lead
    val codeLast = last.code.trimEnd()
    val kw = firstWord(stmt.code)
    val indent = when {
        codeLast.endsWith(":") -> stmtIndent + tab
        kw in ENDER_KW -> maxOf(0, stmtIndent - tab)
        else -> stmtIndent
    }
    return EnterPlan(prefix, " ".repeat(indent), false, "")
}

// ----------------------------------------------------------------------------- ':' typed

internal class DedentResult(val lineStart: Int, val oldLead: Int, val newIndent: Int)

/** [text] already contains the ':' that ends right before [cursor]. */
internal fun dedentTarget(text: String, cursor: Int, tab: Int): DedentResult? {
    if (cursor < 1 || cursor > text.length) return null
    val ls = text.lastIndexOf('\n', cursor - 2) + 1
    val toCursor = text.substring(ls, cursor)
    val m = DEDENT_LINE_RE.find(toCursor) ?: return null
    val kw = m.groups[2]?.value ?: m.groups[4]?.value ?: return null
    val cur = (m.groups[1]?.value ?: m.groups[3]?.value ?: "").length
    val sc = pyScan(text.substring(0, cursor), tab)
    val last = sc.lines[sc.lines.size - 1]
    if (last.endInStr || last.endDepth > 0 || !isStmtStart(last)) return null
    val prev = sc.lines.subList(0, sc.lines.size - 1)
    val targets = targetsOf(kw)
    // 1) Already aligned with a valid opener at this indent?
    for (p in prev.indices.reversed()) {
        val ln = prev[p]
        if (!isCodeStmt(ln)) continue
        val w = ln.lead
        if (w > cur) continue
        if (w == cur && firstWord(ln.code) in targets) return null
        break
    }
    // 2) Find the opener this line belongs to (skipping chains that are already closed).
    var bound = cur
    for (p in prev.indices.reversed()) {
        val ln = prev[p]
        if (!isCodeStmt(ln)) continue
        val w = ln.lead
        if (w >= bound) continue
        val k = firstWord(ln.code)
        if (k in targets) return DedentResult(ls, cur, w)
        if (k in CHAIN_KW) {
            bound = w
            continue
        }
        return null
    }
    return null
}

// ----------------------------------------------------------------------------- Backspace

/** [new] is [old] with ONE space removed at index [cursor]. Returns the adjusted text and cursor. */
internal fun smartBackspace(old: String, new: String, cursor: Int, tab: Int): Pair<String, Int>? {
    if (new.length != old.length - 1 || cursor < 0 || cursor >= old.length || old[cursor] != ' ') return null
    if (!old.regionMatches(0, new, 0, cursor) || !old.regionMatches(cursor + 1, new, cursor, new.length - cursor)) {
        return null
    }
    val ls = new.lastIndexOf('\n', cursor - 1) + 1
    for (x in ls until cursor) if (new[x] != ' ') return null
    val preLen = cursor - ls
    val total = preLen + 1
    var k = total % tab
    if (k == 0) k = tab
    val extra = minOf(k - 1, preLen)
    if (extra <= 0) return null
    return (new.substring(0, cursor - extra) + new.substring(cursor)) to (cursor - extra)
}

// ----------------------------------------------------------------------------- Reformat

internal class ReformatResult(val text: String, val caret: Int, val changedLines: Int, val flat: Boolean)

private const val K_RAW = 0
private const val K_BLANK = 1
private const val K_CODE = 2
private const val K_COMMENT = 3
private const val K_CONT = 4

/**
 * Cleans [text]. With [rebuild] = true and flattened input (no indentation anywhere) it rebuilds a
 * best-effort structure from block openers. Line count never changes (except trailing blank lines).
 */
internal fun reformat(text: String, caretIn: Int, tab: Int, rebuild: Boolean): ReformatResult {
    var caret = caretIn.coerceIn(0, text.length)
    var crlf = 0
    run {
        var p = text.indexOf("\r\n")
        while (p >= 0 && p + 1 <= caret) {
            crlf++
            p = text.indexOf("\r\n", p + 2)
        }
    }
    var t = text.replace("\r\n", "\n").replace('\r', '\n')
    caret -= crlf
    if (t.startsWith("\ufeff")) {
        t = t.substring(1)
        caret = maxOf(0, caret - 1)
    }
    caret = caret.coerceIn(0, t.length)
    val sc = pyScan(t, tab, clean = true)
    val lines = sc.lines
    val n = lines.size
    val kind = IntArray(n)
    val level = IntArray(n) { -1 }
    val widths = IntArray(n)
    val opens = BooleanArray(n)
    val stack = ArrayList<Int>()
    var prevOpens = false
    var stmtStart = -1
    val codeIdx = ArrayList<Int>()
    val pending = ArrayList<Int>()
    for (i in 0 until n) {
        val ln = lines[i]
        when {
            ln.startInStr -> kind[i] = K_RAW
            isBlankLine(ln) -> kind[i] = K_BLANK
            !isStmtStart(ln) -> kind[i] = K_CONT
            isCommentOnly(ln) -> {
                kind[i] = K_COMMENT
                val w = ln.lead
                val m = stack.indexOf(w)
                if (m >= 0) level[i] = m else pending.add(i)
            }
            else -> {
                kind[i] = K_CODE
                val w = ln.lead
                widths[i] = w
                var lv: Int
                if (stack.isEmpty()) {
                    stack.add(w)
                    lv = 0
                } else {
                    val top = stack[stack.size - 1]
                    if (w > top) {
                        if (prevOpens) stack.add(w)
                        lv = stack.size - 1
                    } else if (w == top) {
                        lv = stack.size - 1
                    } else {
                        while (stack.size > 1 && stack[stack.size - 1] > w) stack.removeAt(stack.size - 1)
                        if (stack[stack.size - 1] > w) stack[0] = w
                        lv = stack.size - 1
                    }
                }
                level[i] = lv
                codeIdx.add(i)
                stmtStart = i
            }
        }
        if (!ln.endInStr && ln.endDepth == 0 && !ln.endBs && !isBlankLine(ln) &&
            (kind[i] == K_CODE || kind[i] == K_CONT || kind[i] == K_RAW) && stmtStart >= 0
        ) {
            prevOpens = ln.code.trimEnd().endsWith(":")
            opens[stmtStart] = prevOpens
        }
    }
    var flat = false
    if (codeIdx.size >= 2) {
        flat = codeIdx.all { widths[it] == 0 } && codeIdx.any { opens[it] }
    }
    val doRebuild = rebuild && flat
    if (doRebuild) {
        // fam: "if" | "loop" | "try" | "other"
        val bLevel = ArrayList<Int>()
        val bFam = ArrayList<String>()
        var cur = 0
        for (i in codeIdx) {
            val ln = lines[i]
            val kw = firstWord(ln.code)
            var fam = "other"
            var lv = cur
            fun truncate(to: Int) {
                while (bLevel.size > to) {
                    bLevel.removeAt(bLevel.size - 1)
                    bFam.removeAt(bFam.size - 1)
                }
            }
            fun lastOf(vararg fams: String): Int {
                for (k in bFam.indices.reversed()) if (bFam[k] in fams) return k
                return -1
            }
            if (kw == "if" && ln.code.trimStart().startsWith("if __name__")) {
                lv = 0
                truncate(0)
                fam = "if"
            } else if (kw == "elif") {
                val m = lastOf("if")
                if (m >= 0) {
                    lv = bLevel[m]
                    truncate(m)
                }
                fam = "if"
            } else if (kw == "else") {
                val m = lastOf("if", "loop", "try")
                if (m >= 0) {
                    lv = bLevel[m]
                    fam = bFam[m]
                    truncate(m)
                }
            } else if (kw == "except" || kw == "finally") {
                val m = lastOf("try")
                if (m >= 0) {
                    lv = bLevel[m]
                    truncate(m)
                }
                fam = "try"
            } else if (kw == "if") {
                fam = "if"
            } else if (kw == "for" || kw == "while") {
                fam = "loop"
            } else if (kw == "try") {
                fam = "try"
            }
            level[i] = lv
            if (opens[i]) {
                bLevel.add(lv)
                bFam.add(fam)
                cur = lv + 1
            } else {
                cur = lv
                if ((kw == "return" || kw == "raise" || kw == "break" || kw == "continue") && lv > 0) {
                    cur = lv - 1
                    var q = bLevel.size - 1
                    while (q >= 0) {
                        if (bLevel[q] >= lv) {
                            bLevel.removeAt(q)
                            bFam.removeAt(q)
                        }
                        q--
                    }
                }
            }
        }
        pending.clear()
        for (i in 0 until n) if (kind[i] == K_COMMENT) {
            level[i] = -1
            pending.add(i)
        }
    }
    // Comments without a known level take the level of the next code line (or the last one).
    for (k in pending) {
        var lv = 0
        var found = false
        for (c in codeIdx) if (c > k) {
            lv = level[c]
            found = true
            break
        }
        if (!found && codeIdx.isNotEmpty()) lv = level[codeIdx[codeIdx.size - 1]]
        level[k] = lv
    }
    // Emit.
    var caretLine = -1
    for (k in 0 until n) {
        if (caret >= lines[k].start && caret <= lines[k].end) {
            caretLine = k
            break
        }
    }
    val out = ArrayList<String>(n)
    var changed = 0
    var curOld = 0
    var curNew = 0
    var caretNew = 0
    var caretCol = 0
    for (k in 0 until n) {
        val ln = lines[k]
        val tk = ln.text
        val newLine: String = when (kind[k]) {
            K_RAW -> tk
            K_BLANK -> ""
            else -> {
                val leadN = leadLen(tk)
                var body = tk.substring(leadN)
                if (!ln.endInStr) body = body.trimEnd(' ', '\t')
                val oldW = ln.lead
                val newW: Int
                if (kind[k] == K_CODE || kind[k] == K_COMMENT) {
                    newW = level[k] * tab
                    if (kind[k] == K_CODE) {
                        curOld = oldW
                        curNew = newW
                    }
                } else if (doRebuild) {
                    val startsClose = body.isNotEmpty() && (body[0] == ')' || body[0] == ']' || body[0] == '}')
                    newW = if (oldW <= curOld) {
                        if (startsClose) curNew else curNew + tab
                    } else {
                        maxOf(0, oldW + curNew - curOld)
                    }
                } else {
                    newW = maxOf(0, oldW + (curNew - curOld))
                }
                " ".repeat(newW) + body
            }
        }
        if (newLine != tk) changed++
        out.add(newLine)
        if (k == caretLine) {
            val col = caret - ln.start
            val oldLead = leadLen(tk)
            val newLead = leadLen(newLine)
            var ncol = if (col <= oldLead) newLead else col - oldLead + newLead
            ncol = ncol.coerceIn(0, newLine.length)
            caretCol = ncol
        }
    }
    while (out.size > 1 && out[out.size - 1].isEmpty()) out.removeAt(out.size - 1)
    var result = out.joinToString("\n")
    result = if (result.isBlank()) "" else if (result.endsWith("\n")) result else result + "\n"
    if (caretLine >= 0) {
        var s = 0
        for (x in 0 until minOf(caretLine, out.size)) s += out[x].length + 1
        caretNew = s + caretCol
    }
    caretNew = caretNew.coerceIn(0, result.length)
    return ReformatResult(result, caretNew, if (result == text) 0 else changed, flat)
}

/**
 * Keeps only one 1-based line from a formatted snapshot and copies every other
 * line verbatim from the original source. This lets the diagnostic action use
 * the same LSP + local formatting pipeline as the editor menu without applying
 * unrelated formatter edits elsewhere in the document.
 */
/**
 * For E303 (excess blank lines), the formatter's actual change is usually in
 * the blank-line run immediately before the reported statement, not in the
 * statement line itself. Apply only that whitespace run and preserve every
 * non-blank source line verbatim.
 */
internal fun retainFormattedBlankLinesBeforeDiagnostic(
    originalText: String,
    formattedText: String,
    lineNumber: Int,
    originalCaret: Int
): ReformatResult? {
    val originalLines = originalText.split('\n').toMutableList()
    val formattedLines = formattedText.split('\n')
    val targetIndex = lineNumber - 1
    if (targetIndex !in originalLines.indices) return null
    val targetLine = originalLines[targetIndex]
    if (targetLine.isBlank()) return null

    // Match the reported statement in the formatter output. The nearest exact
    // match handles line shifts caused by blank-line removal without guessing
    // when the statement itself was reformatted.
    val matchingIndices = formattedLines.indices.filter {
        formattedLines[it] == targetLine && formattedLines[it].isNotBlank()
    }
    val formattedTarget = matchingIndices.minByOrNull { kotlin.math.abs(it - targetIndex) }
        ?: return null

    var originalRunStart = targetIndex
    while (originalRunStart > 0 && originalLines[originalRunStart - 1].isBlank()) originalRunStart--
    val originalBlankCount = targetIndex - originalRunStart

    var formattedRunStart = formattedTarget
    while (formattedRunStart > 0 && formattedLines[formattedRunStart - 1].isBlank()) formattedRunStart--
    val formattedBlankCount = formattedTarget - formattedRunStart
    if (originalBlankCount == formattedBlankCount) return null

    // Replace only the blank-line run. Never include or delete the diagnostic
    // statement, even if the formatter changes line counts elsewhere.
    repeat(originalBlankCount) { originalLines.removeAt(originalRunStart) }
    repeat(formattedBlankCount) { originalLines.add(originalRunStart, "") }
    val output = originalLines.joinToString("\n")

    val caretLine = originalText.substring(0, originalCaret.coerceIn(0, originalText.length)).count { it == '\n' }
    val caretColumn = originalCaret.coerceIn(0, originalText.length) -
        (originalText.lastIndexOf('\n', (originalCaret - 1).coerceAtLeast(0)).let { if (it < 0) 0 else it + 1 })
    val lineDelta = formattedBlankCount - originalBlankCount
    val mappedLine = if (caretLine >= targetIndex) caretLine + lineDelta else caretLine
    val outputLines = output.split('\n')
    val mappedCaret = outputLines.take(mappedLine.coerceIn(0, outputLines.lastIndex)).sumOf { it.length + 1 } +
        caretColumn.coerceIn(0, outputLines[mappedLine.coerceIn(0, outputLines.lastIndex)].length)
    return ReformatResult(output, mappedCaret.coerceIn(0, output.length), 1, false)
}

internal fun retainOnlyFormattedLine(
    originalText: String,
    formattedText: String,
    lineNumber: Int,
    formattedCaret: Int
): ReformatResult? {
    val originalLines = originalText.split('\n').toMutableList()
    val formattedLines = formattedText.split('\n')
    val lineIndex = lineNumber - 1
    if (lineIndex !in originalLines.indices || lineIndex !in formattedLines.indices) return null

    val originalLine = originalLines[lineIndex]
    val hadCarriageReturn = originalLine.endsWith('\r')
    var formattedLine = formattedLines[lineIndex].removeSuffix("\r")
    if (hadCarriageReturn) formattedLine += "\r"
    if (formattedLine == originalLine) return null

    val originalLineStart = originalLines.take(lineIndex).sumOf { it.length + 1 }
    val formattedLineStart = formattedLines.take(lineIndex).sumOf { it.length + 1 }
    val maxColumn = (formattedLine.length - if (hadCarriageReturn) 1 else 0).coerceAtLeast(0)
    val caretColumn = (formattedCaret - formattedLineStart).coerceIn(0, maxColumn)

    originalLines[lineIndex] = formattedLine
    val output = originalLines.joinToString("\n")
    return ReformatResult(
        text = output,
        caret = (originalLineStart + caretColumn).coerceIn(0, output.length),
        changedLines = 1,
        flat = false
    )
}
