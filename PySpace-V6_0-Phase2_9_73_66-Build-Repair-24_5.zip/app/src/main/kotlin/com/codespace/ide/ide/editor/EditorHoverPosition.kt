package com.codespace.ide.ide.editor

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.text.TextLayoutResult

/** Pointer-to-source mapping for hover, isolated from LSP resolution and popup state. */
object EditorHoverPosition {
    data class Hit(val fieldPosition: Offset, val displayOffset: Int)

    fun resolve(
        pressPosition: Offset,
        fieldCoordinates: LayoutCoordinates,
        gestureCoordinates: LayoutCoordinates,
        layout: TextLayoutResult,
        displayTextLength: Int,
        textPaddingPx: Float,
        lineRightSlopPx: Float
    ): Hit? {
        val fieldPosition = fieldCoordinates.localPositionOf(gestureCoordinates, pressPosition)
        val textX = fieldPosition.x - textPaddingPx
        val textY = fieldPosition.y - textPaddingPx
        if (textX < 0f || textY < 0f || textY > layout.size.height.toFloat() ||
            fieldPosition.x > fieldCoordinates.size.width.toFloat()
        ) return null

        val textPosition = Offset(textX, textY)
        val visualLine = layout.getLineForVerticalPosition(textPosition.y)
        if (textPosition.x > layout.getLineRight(visualLine) + lineRightSlopPx) return null
        val offset = layout.getOffsetForPosition(textPosition).coerceIn(0, displayTextLength)
        return Hit(fieldPosition, offset)
    }
}
