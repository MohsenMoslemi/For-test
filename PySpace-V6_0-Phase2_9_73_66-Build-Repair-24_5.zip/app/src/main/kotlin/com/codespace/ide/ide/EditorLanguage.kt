package com.codespace.ide.ide

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import java.io.File
import com.codespace.ide.ide.theme.IdeTheme

/** Language selected strictly from the file extension, never from its name/content. */
enum class EditorLanguage { PYTHON, HTML, JAVASCRIPT, PLAIN_TEXT }

/**
 * Small extensible registry for editor-only syntax highlighting.
 * Registering a language adds colors only; it does not enable language tools,
 * diagnostics, completion, formatting, execution, or project integrations.
 */
object EditorLanguageRegistry {
    private data class Entry(val language: EditorLanguage, val highlighter: (String) -> AnnotatedString)
    private val entries = LinkedHashMap<String, Entry>().apply {
        put("py", Entry(EditorLanguage.PYTHON, ::highlightPython))
        listOf("html", "htm").forEach { put(it, Entry(EditorLanguage.HTML, ::highlightHtml)) }
        listOf("js", "mjs", "cjs").forEach { put(it, Entry(EditorLanguage.JAVASCRIPT, ::highlightJavaScript)) }
    }

    @Synchronized
    fun register(extensions: Set<String>, language: EditorLanguage, highlighter: (String) -> AnnotatedString) {
        require(language != EditorLanguage.PLAIN_TEXT) { "Plain text does not need a highlighter" }
        extensions.forEach { raw ->
            val extension = raw.trim().removePrefix(".").lowercase()
            require(extension.isNotBlank()) { "Extension cannot be blank" }
            entries[extension] = Entry(language, highlighter)
        }
    }

    @Synchronized
    fun languageFor(file: File): EditorLanguage = entries[file.extension.lowercase()]?.language
        ?: EditorLanguage.PLAIN_TEXT

    @Synchronized
    fun highlight(file: File, source: String): AnnotatedString {
        val entry = entries[file.extension.lowercase()]
        return entry?.highlighter?.invoke(source) ?: AnnotatedString(source)
    }
}

private fun highlightHtml(source: String): AnnotatedString {
    if (source.isEmpty()) return AnnotatedString("")
    val tagStyle = SpanStyle(color = Color(IdeTheme.KEYWORD), fontWeight = FontWeight.Bold)
    val attrStyle = SpanStyle(color = Color(IdeTheme.BUILTIN))
    val stringStyle = SpanStyle(color = Color(IdeTheme.STRING))
    val commentStyle = SpanStyle(color = Color(IdeTheme.COMMENT))
    val numberStyle = SpanStyle(color = Color(IdeTheme.NUMBER))
    return buildAnnotatedString {
        append(source)
        var i = 0
        while (i < source.length) {
            if (source.startsWith("<!--", i)) {
                val end = source.indexOf("-->", i + 4).let { if (it < 0) source.length else it + 3 }
                addStyle(commentStyle, i, end)
                i = end
                continue
            }
            if (source[i] == '<' && i + 1 < source.length &&
                (source[i + 1].isLetter() || source[i + 1] == '/' || source[i + 1] == '!')
            ) {
                val tagStart = i
                var j = i + 1
                var quote: Char? = null
                while (j < source.length) {
                    val c = source[j]
                    if (quote != null) {
                        if (c == quote) quote = null
                    } else if (c == '\'' || c == '\"') {
                        quote = c
                    } else if (c == '>') {
                        break
                    }
                    j++
                }
                val tagEnd = (j + 1).coerceAtMost(source.length)
                addStyle(tagStyle, tagStart, tagEnd)
                var p = tagStart + 1
                while (p < tagEnd - 1) {
                    when {
                        source[p] == '\'' || source[p] == '\"' -> {
                            val q = source[p]
                            val stringStart = p++
                            while (p < tagEnd && source[p] != q) p++
                            if (p < tagEnd) p++
                            addStyle(stringStyle, stringStart, p)
                        }
                        source[p].isLetter() || source[p] == '_' || source[p] == ':' -> {
                            val wordStart = p
                            while (p < tagEnd && (source[p].isLetterOrDigit() || source[p] in "_:-")) p++
                            var next = p
                            while (next < tagEnd && source[next].isWhitespace()) next++
                            if (next < tagEnd && source[next] == '=') addStyle(attrStyle, wordStart, p)
                        }
                        else -> p++
                    }
                }
                i = tagEnd
                continue
            }
            if (source[i].isDigit()) {
                val start = i
                while (i < source.length && (source[i].isDigit() || source[i] == '.')) i++
                addStyle(numberStyle, start, i)
                continue
            }
            i++
        }
    }
}

private val JS_KEYWORDS = setOf(
    "as", "async", "await", "break", "case", "catch", "class", "const", "continue",
    "debugger", "default", "delete", "do", "else", "export", "extends", "finally",
    "for", "from", "function", "if", "import", "in", "instanceof", "let", "new",
    "of", "return", "static", "super", "switch", "this", "throw", "try", "typeof",
    "var", "void", "while", "with", "yield", "true", "false", "null", "undefined"
)
private val JS_GLOBALS = setOf(
    "Array", "BigInt", "Boolean", "Date", "Error", "JSON", "Map", "Math", "Number",
    "Object", "Promise", "RegExp", "Set", "String", "Symbol", "WeakMap", "WeakSet",
    "console", "document", "globalThis", "localStorage", "navigator", "process", "window"
)

private fun highlightJavaScript(source: String): AnnotatedString {
    if (source.isEmpty()) return AnnotatedString("")
    val keyword = SpanStyle(color = Color(IdeTheme.KEYWORD), fontWeight = FontWeight.Bold)
    val global = SpanStyle(color = Color(IdeTheme.BUILTIN))
    val string = SpanStyle(color = Color(IdeTheme.STRING))
    val comment = SpanStyle(color = Color(IdeTheme.COMMENT))
    val number = SpanStyle(color = Color(IdeTheme.NUMBER))
    return buildAnnotatedString {
        append(source)
        var i = 0
        while (i < source.length) {
            if (source.startsWith("//", i)) {
                val end = source.indexOf('\n', i).let { if (it < 0) source.length else it }
                addStyle(comment, i, end); i = end; continue
            }
            if (source.startsWith("/*", i)) {
                val end = source.indexOf("*/", i + 2).let { if (it < 0) source.length else it + 2 }
                addStyle(comment, i, end); i = end; continue
            }
            val c = source[i]
            if (c == '\'' || c == '"' || c == '`') {
                val quote = c; val start = i; i++
                while (i < source.length) {
                    if (source[i] == '\\') { i = (i + 2).coerceAtMost(source.length); continue }
                    if (source[i++] == quote) break
                }
                addStyle(string, start, i); continue
            }
            if (c.isDigit()) {
                val start = i++
                while (i < source.length && (source[i].isLetterOrDigit() || source[i] in "._")) i++
                addStyle(number, start, i); continue
            }
            if (c.isLetter() || c == '_' || c == '$') {
                val start = i++
                while (i < source.length && (source[i].isLetterOrDigit() || source[i] == '_' || source[i] == '$')) i++
                val word = source.substring(start, i)
                when (word) {
                    in JS_KEYWORDS -> addStyle(keyword, start, i)
                    in JS_GLOBALS -> addStyle(global, start, i)
                }
                continue
            }
            i++
        }
    }
}
