package com.codespace.ide.ide.terminal

import android.os.SystemClock
import com.codespace.ide.memory.MemoryRuntimePolicy
import java.util.ArrayDeque
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/** Thread-safe, bounded hand-off between the PTY reader and the Compose terminal surface. */
internal class TerminalOutputBuffer {
    // Every queue operation is guarded by monitor. ArrayDeque lets drain() put a
    // partially-consumed chunk back at the head without losing PTY byte order.
    private val chunks = ArrayDeque<String>()
    private val monitor = java.lang.Object()
    private val accepting = AtomicBoolean(true)
    private val pending = AtomicLong(0L)
    private val lastFlush = AtomicLong(0L)
    private val lastOutput = AtomicLong(0L)

    val pendingChars: Long get() = pending.get()
    val lastFlushMs: Long get() = lastFlush.get()
    val lastOutputMs: Long get() = lastOutput.get()
    val isAccepting: Boolean get() = accepting.get()
    val hasPending: Boolean get() = synchronized(monitor) { chunks.isNotEmpty() }

    /**
     * Reader-thread only. Input is split into policy-sized pieces so even one
     * unusually large PTY read cannot exceed the pending-character budget.
     * Back-pressure is lossless: the reader waits until the UI drains space.
     */
    fun enqueue(raw: String): Boolean {
        if (raw.isEmpty() || !accepting.get()) return false
        var offset = 0
        while (offset < raw.length) {
            val limit = MemoryRuntimePolicy.terminalPendingCharsLimit().coerceAtLeast(1)
            val end = offset + minOf(limit, raw.length - offset)
            val part = raw.substring(offset, end)
            synchronized(monitor) {
                while (accepting.get() && pending.get() + part.length > limit) {
                    try {
                        monitor.wait(50L)
                    } catch (interrupted: InterruptedException) {
                        Thread.currentThread().interrupt()
                        return false
                    }
                }
                if (!accepting.get()) return false
                chunks.addLast(part)
                pending.addAndGet(part.length.toLong())
                lastOutput.set(SystemClock.uptimeMillis())
            }
            offset = end
        }
        return true
    }

    /** Main-thread drain, bounded so a large backlog cannot monopolize a frame. */
    fun drain(maxChars: Int): String {
        if (maxChars <= 0) return ""
        val result = StringBuilder(minOf(maxChars, 16 * 1024))
        synchronized(monitor) {
            while (result.length < maxChars) {
                val chunk = chunks.pollFirst() ?: break
                val take = minOf(chunk.length, maxChars - result.length)
                result.append(chunk, 0, take)
                if (take < chunk.length) chunks.addFirst(chunk.substring(take))
                pending.addAndGet(-take.toLong())
            }
            if (result.isNotEmpty()) monitor.notifyAll()
        }
        return result.toString()
    }

    fun markFlushed() { lastFlush.set(SystemClock.uptimeMillis()) }

    fun resetForSession() {
        synchronized(monitor) {
            accepting.set(true)
            chunks.clear()
            pending.set(0L)
            monitor.notifyAll()
        }
    }

    fun stopAndClear() {
        synchronized(monitor) {
            accepting.set(false)
            chunks.clear()
            pending.set(0L)
            monitor.notifyAll()
        }
    }
}
