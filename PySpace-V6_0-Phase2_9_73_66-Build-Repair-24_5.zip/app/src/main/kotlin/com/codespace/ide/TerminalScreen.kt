package com.codespace.ide

import com.codespace.ide.ide.IdeAlertDialog
import com.codespace.ide.ide.settings.IdePrefs
import com.codespace.ide.ide.theme.IdeTheme
import com.codespace.ide.runtime.RuntimeDispatchers
import com.codespace.ide.di.AppDependencies

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Bundle
import android.os.SystemClock
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitLongPressOrCancellation
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateOffsetAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.layout.positionInWindow
import kotlin.math.abs
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.offset
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalTextToolbar
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.codespace.ide.ui.install.InstallViewModel
import com.codespace.ide.ide.terminal.TerminalCallbacks
import com.codespace.ide.ide.terminal.TerminalLaunchConfig
import com.codespace.ide.ide.terminal.TerminalViewModel
import com.codespace.ide.ide.terminal.TerminalRepository
import org.koin.core.context.GlobalContext
import com.codespace.ide.ide.terminal.TerminalScreenState
import com.codespace.ide.ide.terminal.TermBridge
import com.codespace.ide.ide.terminal.TermController


private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}


/** Terminal selection rendering helpers. Kept beside terminal UI, not Activity startup. */
/** Selection wash painted over terminal text while a selection is active. */
private val TermSelectBg get() = Color(IdeTheme.ACCENT).copy(alpha = 0.30f)

private fun withSelectionRange(doc: AnnotatedString, from: Int, to: Int): AnnotatedString {
    val s = from.coerceIn(0, doc.text.length)
    val e = to.coerceIn(s, doc.text.length)
    if (s >= e) return doc
    return buildAnnotatedString {
        append(doc)
        addStyle(SpanStyle(background = TermSelectBg), s, e)
    }
}

/**
 * Overlays the independent terminal selection onto one rendered line.
 * Pure function of (doc, line, selection): only visible lines ever call it,
 * so a 100k-line selection costs nothing beyond the viewport.
 */
private fun highlightLine(
    doc: AnnotatedString,
    line: Int,
    sel: TermSelection?
): AnnotatedString {
    val n = sel?.normalized() ?: return doc
    if (line < n.startLine || line > n.endLine) return doc
    val s = if (line == n.startLine) n.startCol else 0
    val e = if (line == n.endLine) n.endCol else doc.text.length
    return withSelectionRange(doc, s, e)
}


private const val REPEAT_INTERVAL_MS = 70L

@Composable
private fun Modifier.keyboardOverlapPadding(): Modifier {
    val density = LocalDensity.current
    val view = LocalView.current
    val imeInsets = WindowInsets.ime
    var surfaceBottomPx by remember { mutableIntStateOf(-1) }
    return this
        .onGloballyPositioned { coords ->
            val bottom = (coords.positionInWindow().y + coords.size.height).roundToInt()
            if (bottom != surfaceBottomPx) surfaceBottomPx = bottom
        }
        .layout { measurable, constraints ->
            val windowHeight = view.rootView.height
            // A surface parked outside the window (the editor's closed dock is
            // moved off-screen by an offset) must keep its full size: it is not
            // covered by the keyboard, and shrinking it would resize the PTY.
            val overlap = if (surfaceBottomPx < 0 || windowHeight <= 0 || surfaceBottomPx > windowHeight) {
                0
            } else {
                val keyboardTop = windowHeight - imeInsets.getBottom(density)
                (surfaceBottomPx - keyboardTop).coerceAtLeast(0)
            }
            val placeable = measurable.measure(constraints.offset(vertical = -overlap))
            val height = (placeable.height + overlap)
                .coerceIn(constraints.minHeight, constraints.maxHeight)
            layout(placeable.width, height) { placeable.placeRelative(0, 0) }
        }
}

/**
 * All terminal surfaces share one Activity window. A per-TerminalScreen
 * DisposableEffect used to restore the previous soft-input mode independently;
 * retained/hidden terminals could therefore restore ADJUST_RESIZE while the
 * visible terminal still needed ADJUST_NOTHING. Reference-count the active,
 * visible terminal surfaces so the window mode is restored only after the last
 * one leaves.
 */
private object TerminalImeWindowMode {
    private data class Entry(val originalMode: Int, var owners: Int)
    private val entries = mutableMapOf<Activity, Entry>()

    @Synchronized
    fun acquire(activity: Activity) {
        val existing = entries[activity]
        if (existing != null) {
            existing.owners += 1
            return
        }
        val original = activity.window.attributes.softInputMode
        entries[activity] = Entry(original, 1)
        activity.window.setSoftInputMode(
            (original and WindowManager.LayoutParams.SOFT_INPUT_MASK_ADJUST.inv()) or
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        )
    }

    @Synchronized
    fun release(activity: Activity) {
        val entry = entries[activity] ?: return
        entry.owners -= 1
        if (entry.owners <= 0) {
            entries.remove(activity)
            activity.window.setSoftInputMode(entry.originalMode)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun TerminalScreen(
    root: ProotManager,
    bridge: com.codespace.ide.ide.terminal.TermBridge? = null,
    showTopBar: Boolean = true,
    modifier: Modifier = Modifier,
    /**
     * Guest command instead of a login shell (IDE console runs). Null keeps
     * the exact interactive behavior.
     */
    runCommand: String? = null,
    /** Handle for console rerun/stop/done. Null for the interactive shell. */
    controller: com.codespace.ide.ide.terminal.TermController? = null,
    /** Exit-line hint: "press Restart" for shells, "press Rerun" for runs. */
    exitHint: String = "press Restart",
    /**
     * Extra-keys bar (CTRL/arrows/…). The run console hides it: a program's
     * output needs the space, and input() uses the plain soft keyboard.
     */
    showExtraKeys: Boolean = true,
    /**
     * False while the panel is closed or another tab covers the terminal:
     * the transcript stays, but any selection and its menu are dropped so
     * nothing is still selected when the panel opens again.
     */
    visible: Boolean = true,
    /**
     * Guest venv path to auto-activate when the shell starts
     * (e.g. `/files/projects/MyProj/.venv`). Delivered invisibly through the
     * session environment (never typed), so the first prompt already shows
     * `(.venv)`. Null = plain user prompt.
     */
    autoActivate: String? = null,
    /**
     * Guest-absolute starting directory (e.g. `/files/projects/MyProj`).
     * Applied as the process workdir — no typed `cd`, nothing visible,
     * nothing to race. Null keeps the historical /root.
     */
    workDir: String? = null,
    /**
     * Read-only log surface (installer): taps never take focus or pop the
     * keyboard; scrolling and text selection keep working untouched.
     */
    readOnly: Boolean = false,
    /** Hide the optional floating IME toggle on dedicated interpreter surfaces. */
    showManualKeyboardButton: Boolean = true,
    /** Hide the redundant IME key only on the editor's docked console. */
    showKeyboardToggle: Boolean = true,
    /** Interpreter profile: hide ESC, ALT, backspace and the keyboard toggle. */
    compactExtraKeys: Boolean = false
) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val hostActivity = LocalContext.current.findActivity()
    // Only a visible, interactive terminal owns the Activity IME mode. Hidden
    // retained tabs and read-only installer output must not change it. The
    // shared coordinator prevents one terminal from restoring ADJUST_RESIZE
    // while another visible terminal still needs ADJUST_NOTHING.
    val appCtx = LocalContext.current.applicationContext
    val keyboard = LocalSoftwareKeyboardController.current
    val focusRequester = remember { FocusRequester() }

    // Tell the IDE shell when the soft keyboard opens over the terminal so
    // it can grow the bottom panel (surface + extra-keys stay visible).
    // Read-only signal: nothing about input/focus/selection changes here.
    val termImeVisible = WindowInsets.isImeVisible
    val density = LocalDensity.current
    val focusManagerForKb = androidx.compose.ui.platform.LocalFocusManager.current
    val textToolbar = LocalTextToolbar.current
    // True while the Copy/Paste/Select-all menu is meant to be on screen
    // (set by showTermMenu, cleared by any deliberate hide). Lets the menu be
    // re-placed after the surface moves (panel drag, keyboard).
    val listState = rememberLazyListState()
    val ts = remember { TerminalScreenState(scope, appCtx, listState, clipboard, keyboard, density, textToolbar) }
    ts.clipboard = clipboard
    ts.keyboard = keyboard
    ts.density = density
    ts.textToolbar = textToolbar
    with(ts) {
    terminalViewModel = remember(root, sessionTick) { TerminalViewModel(TerminalRepository(root)) }
    DisposableEffect(hostActivity, visible && !readOnly) {
        val owner = hostActivity?.takeIf { visible && !readOnly }
        if (owner != null) TerminalImeWindowMode.acquire(owner)
        onDispose {
            if (owner != null) TerminalImeWindowMode.release(owner)
        }
    }
    LaunchedEffect(termImeVisible) {
        if (termImeVisible) {
            try {
                bridge?.onImeShown?.invoke()
            } catch (_: Exception) {
            }
        }
    }

    LaunchedEffect(Unit) {
        snapshotFlow { listState.isScrollInProgress to listState.canScrollForward }
        .collect { (scrolling, canFwd) ->
            // Never re-arm while a selection drag owns the pointer: the
            // list never sees a handle drag (consumed at the handle), so
            // isScrollInProgress is false and a bottom viewport would
            // otherwise re-engage follow mid-drag — then fresh output
            // scrolls the viewport under the finger and the y-to-line
            // mapping jumps lines. Outside selection drags this reads
            // exactly as before.
            if (!scrolling && !canFwd && selOwnerBox[0] == null) {
                follow = true
            }
        }
    }

    // The ONLY place follow is cleared for touch navigation: a genuine
    // finger drag on the list. Programmatic scrolls (follow jumps, PGUP/
    // PGDN buttons, selection auto-scroll, resize pins) never emit drag
    // interactions, so output growth can no longer masquerade as the user
    // leaving the bottom.
    LaunchedEffect(Unit) {
        listState.interactionSource.interactions.collect { interaction ->
            if (interaction is DragInteraction.Start) {
                follow = false
            }
        }
    }

    // Coalesced PTY->UI pipeline: the reader thread only enqueues decoded
    // chunks here. Parsing + a single version bump + at most one scroll op
    // happen in doFlush(), so a burst of thousands of chunks costs a bounded
    // number of Main-thread passes instead of one per chunk.
    bridge?.send = { s ->
        if (sessionBox[0] != null) {
            sendToPty(s)
            true
        } else false
    }

    /**
     * Single terminal-key entry point for ALL key-originated input (extra
     * bar, soft keyboard, hardware keys). A latched CTRL turns one ASCII
     * letter into its control byte; a latched ALT prefixes ESC. Latches
     * clear after one use (or when the input isn't latch-applicable), and
     * multi-char sequences with CTRL latched go through raw — predictable,
     * never stuck. DSR answers bypass this and use sendToPty directly.
     */
    LaunchedEffect(visible) {
        if (!visible) {
            stopDragScroll()
            hideTermMenu()
            activeHandleBox.value = -1
            selOwnerBox[0] = null
            surfaceDeadBox[0] = false
            termSel = null
        }
    }

    /**
     * True when a surface-relative touch point lands inside either visible
     * selection-handle touch box. The boxes are 32dp x 44dp, placed with
     * their top-center 16dp left / 29dp above the endpoint anchor (see the
     * overlay below), so the rect is anchor +/- exactly that — no snapping,
     * no inflation, just the real grab area. Null anchor (endpoint line
     * offscreen) means that handle is not rendered: skipped.
     */
    if (runCommand != null) {
        LaunchedEffect(alive) {
            var autoShownFor = ""
            while (alive) {
                kotlinx.coroutines.delay(250)
                val idle = SystemClock.uptimeMillis() - outputBuffer.lastOutputMs
                val col = try {
                    emulator.cursorColumn()
                } catch (_: Exception) {
                    0
                }
                val weak = alive && col > 0 && idle >= 350L
                if (weak != inputExpected) inputExpected = weak
                if (weak) {
                    val line = try {
                        emulator.cursorRowText().trimEnd()
                    } catch (_: Exception) {
                        ""
                    }
                    val raw = try {
                        emulator.cursorRowText()
                    } catch (_: Exception) {
                        ""
                    }
                    val promptLike = raw.endsWith(" ") ||
                    line.endsWith(":") || line.endsWith("?") ||
                    line.endsWith(">")
                    if (promptLike && line.isNotEmpty() && autoShownFor != raw) {
                        autoShownFor = raw
                        try {
                            focusRequester.requestFocus()
                        } catch (_: Exception) {
                        }
                        keyboard?.show()
                    }
                } else {
                    autoShownFor = ""
                }
            }
            inputExpected = false
        }
    }

    // Exactly one persistent shell per tick. Closed on dispose: no leaks,
    // no accidental second shells. Rotation is locked to portrait; if the
    // Activity is ever recreated, a fresh shell starts gracefully.
    DisposableEffect(sessionTick) {
        val vmForSession = terminalViewModel
        exitMessage = null
        starting = true
        alive = false
        outputBuffer.resetForSession()
        flushScheduled.set(false)
        hasOutput = false
        // DSR/CPR answers from the emulator go back into the same PTY.
        emulator.onResponse = { resp -> sendToPty(resp) }
        vmForSession.start(
            config = TerminalLaunchConfig(
                runCommand = runCommand,
                workDir = workDir,
                promptVenv = autoActivate,
                rows = lastPtySize.first.takeIf { it > 0 } ?: TerminalSession.DEFAULT_ROWS,
                cols = lastPtySize.second.takeIf { it > 0 } ?: TerminalSession.DEFAULT_COLS,
            ),
            callbacks = object : TerminalCallbacks {
                override fun onOutput(text: String) = appendChunk(text)
                override fun onExit(code: Int) {
                    scope.launch(Dispatchers.Main) {
                        alive = false
                        doFlush()
                        emulator.processText("\r\n[process exited, code=$code — $exitHint]\r\n")
                        try { controller?.onDone?.invoke() } catch (_: Exception) { }
                    }
                }
                override fun onError(error: Throwable) {
                    scope.launch(Dispatchers.Main) {
                        starting = false
                        alive = false
                        doFlush()
                        emulator.processText("\r\nERROR: ${error.message ?: error.javaClass.simpleName}\r\n")
                        try { controller?.onDone?.invoke() } catch (_: Exception) { }
                    }
                }
            },
            onStarted = { startedSession ->
                sessionBox[0] = startedSession
                starting = false
                alive = true
                val pending = bridge?.pending
                if (pending != null) {
                    bridge?.pending = null
                    sendToPty(pending)
                }
                if (runCommand == null && showTopBar) {
                    try { focusRequester.requestFocus() } catch (_: Exception) { }
                }
            },
        )
        // Console handle: rerun restarts the same command (or shell) at
        // once; stop only closes (the exit line + onDone follow).
        controller?.rerun = { doRestart() }
        controller?.stop = {
            vmForSession.stopSession()
            sessionBox[0] = null
        }
        // Optional read-only transcript tap for console conveniences. It only
        // reads the already-rendered lines; it cannot affect output, input,
        // selection, scroll, focus, or PTY behavior.
        val transcriptReader = { consoleTranscriptTail() }
        controller?.transcriptTail = transcriptReader
        // Liveness probe for the console Rerun path (stop-then-restart needs
        // to know whether a server is actually holding its port).
        val aliveProbe: () -> Boolean = {
            try {
                vmForSession.isAlive()
            } catch (_: Exception) {
                false
            }
        }
        controller?.isAlive = aliveProbe
        // Frame-paced flush loop: trailing edge of the coalescing pipeline.
        // Started once per session tick and cancelled with it — never leaks,
        // never duplicated.
        val flushLoop = scope.launch(Dispatchers.Main) {
            while (true) {
                delay(FLUSH_WINDOW_MS)
                if (outputBuffer.hasPending) {
                    if (flushScheduled.compareAndSet(false, true)) {
                        doFlush()
                    }
                }
            }
        }
        onDispose {
            outputBuffer.stopAndClear()
            flushLoop.cancel()
            vmForSession.close()
            try {
                if (controller?.transcriptTail === transcriptReader) {
                    controller?.transcriptTail = null
                }
                if (controller?.isAlive === aliveProbe) {
                    controller?.isAlive = null
                }
            } catch (_: Exception) {
            }
            sessionBox[0] = null
        }
    }

    LaunchedEffect(alive) {
        if (alive) {
            // Same gate as the startup path below: embedded panel
            // instances must never grab focus (this unconditionally fired
            // for every session — including the hidden one composed on
            // project entry — which is what popped the keyboard with no
            // file open). Only the standalone screen may.
            if (runCommand == null && showTopBar) {
                try {
                    focusRequester.requestFocus()
                } catch (_: Exception) {
                }
            }
            applyPtySize()
        }
    }

    // Surface geometry is applied AFTER layout, never inside onSizeChanged.
    // Keyed on the measured size (Pair equality), so it runs once per real
    // measurement change — and with the latched rows it does nothing at all
    // for keyboard/panel-drag height changes, which are viewport-only.
    LaunchedEffect(surfacePx) {
        applyPtySize()
    }

    // One version read per coalesced flush retriggers this scope. Keyed
    // LazyColumn items with unchanged inputs are skipped, so per-flush UI
    // work stays proportional to the viewport — never to the full history.
    // Scrollback items render from their cached per-line document and never
    // resubscribe; only visible screen rows rebuild (small, cursor included).
    val emuVersion = emulator.version
    val emuTitle = emulator.title
    val sbCount = emulator.scrollbackCount()
    // Trimmed grid items: only rows with content (plus the cursor row)
    // become LazyColumn items — the empty tail below the prompt must not
    // exist as scrollable/selectable text.
    val rowCount = emulator.lastRenderedRow() + 1
    val altActive = emulator.isAltActive()

    // Single auto-follow site. Keyed on the model version, so at most ONE
    // follow coroutine exists: a newer version cancels the previous run
    // instead of piling up. It runs AFTER this version's composition
    // commits, then follows ONLY while the explicit follow intent holds
    // (see the follow state above) and no drag is in progress — manual
    // history browsing is never overridden. The target is clamped to
    // laid-out items and a settle pass re-pins after one frame, so progress
    // is monotonic and nothing ever throws.
    LaunchedEffect(emuVersion) {
        if (!follow || listState.isScrollInProgress || selOwnerBox[0] != null) {
            return@LaunchedEffect
        }
        val total = listState.layoutInfo.totalItemsCount
        val last = lastIndex()
        if (last < 0 || total <= 0) return@LaunchedEffect
        try {
            listState.scrollToItem(last.coerceAtMost(total - 1))
        } catch (_: Exception) {
            return@LaunchedEffect
        }
        if (!follow || listState.isScrollInProgress) return@LaunchedEffect
        // Settle after one frame: if layout has now measured fresh items
        // below us, pin once more. Skipped automatically when already home.
        withFrameNanos { }
        if (emulator.version == emuVersion && follow &&
            !listState.isScrollInProgress && listState.canScrollForward &&
            selOwnerBox[0] == null
        ) {
            val last2 = lastIndex()
            if (last2 >= 0) {
                try {
                    listState.scrollToItem(last2)
                } catch (_: Exception) {
                }
            }
        }
    }

    Scaffold(
        modifier = modifier,
        topBar = {
            if (showTopBar) {
                TopAppBar(
                    title = {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "Py",
                                    color = Color(IdeTheme.ACCENT),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 17.sp
                                )
                                Text(
                                    "Space",
                                    color = Color(IdeTheme.TEXT),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp
                                )
                            }
                            Text(
                                when {
                                    starting -> "starting shell…"
                                    alive -> emuTitle ?: "shell running"
                                    else -> exitMessage ?: "shell stopped"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.Gray
                            )
                        }
                    },
                    actions = {
                        TextButton(onClick = {
                                doCopyAll()
                        }) {
                            Text("Copy All", fontSize = 12.sp)
                        }
                        TextButton(onClick = {
                                confirmRestart = true
                        }) {
                            Text("Restart", fontSize = 12.sp)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = TerminalBg
                    )
                )
            }
        },
        containerColor = TerminalBg
    ) { padding ->
        Box(
            modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .background(TerminalBg)
        ) {
            Column(
                modifier = Modifier
                .fillMaxSize()
                // The terminal Activity window is temporarily adjustNothing;
                // reserve only the part of the keyboard that actually covers
                // this surface, so the extra-keys rows sit directly on top of
                // the keyboard on every terminal surface (global, project and
                // Python interpreter) even when a Home bottom bar is below it.
                .keyboardOverlapPadding()
                .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                // One continuous emulator surface: scrollback + screen + the
                // real cursor block, rendered as a single document. There is
                // no separate input box; typing lands at the cursor inside
                // this surface via the hidden IME conduit below.
                Box(
                    modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .onSizeChanged {
                        // Measure only. The geometry itself is applied
                        // after layout (LaunchedEffect(surfacePx)
                        // below): resizing the emulator and pinning the
                        // scroll inside onSizeChanged mutated state
                        // during layout, and during the keyboard
                        // animation that left stale rows and blank gaps
                        // behind.
                        surfacePx = it.width to it.height
                    }
                    // Window coordinates for the selection context menu.
                    // Plain holder write (not state): fires on every
                    // layout pass without ever triggering recomposition.
                    .onGloballyPositioned { coords ->
                        termCoordsBox[0] = coords
                        // The floating menu lives in WINDOW coordinates,
                        // so when the surface moves (sliding panel,
                        // keyboard) it would stay behind. Hide it and
                        // re-place it once the movement settles.
                        val wp = coords.positionInWindow()
                        val last = lastWinPosBox[0]
                        lastWinPosBox[0] = wp
                        if (last != null && menuWanted[0] &&
                            (abs(last.x - wp.x) > 0.5f ||
                                abs(last.y - wp.y) > 0.5f)
                        ) {
                            try {
                                textToolbar.hide()
                            } catch (_: Exception) {
                            }
                            menuJobBox[0]?.cancel()
                            menuJobBox[0] = scope.launch(Dispatchers.Main) {
                                delay(160)
                                val cur = termSel
                                if (menuWanted[0] && cur != null &&
                                    !cur.normalized().isEmpty() &&
                                    activeHandleBox.value < 0
                                ) {
                                    showTermMenu(Offset.Zero)
                                }
                            }
                        }
                    }
                    // Tap-to-focus lives on the terminal surface only, so
                    // extra-keys bar taps never refocus or pop the IME.
                    .pointerInput(Unit) {
                        detectTapGestures(onTap = { off: Offset ->
                                // A press that lands on a selection handle is
                                // a grab attempt, not a dismiss tap: clearing
                                // the selection here yanked both handles away
                                // whenever the finger lifted before touch-slop
                                // (aiming/holding on the small dot) — the
                                // reported "handles suddenly vanish". Focus
                                // and keyboard behavior stay unchanged.
                                if (!isOnHandle(off)) {
                                    termSel = null
                                    try {
                                        hideTermMenu()
                                    } catch (_: Exception) {
                                    }
                                }
                                // Read-only log surfaces (installer): taps must
                                // never take focus or pop the keyboard.
                                // Scrolling and text selection are untouched.
                                // Console runs: only while the program waits for
                                // input, never on a plain touch of its output.
                                if (!readOnly && (runCommand == null || inputExpected)) {
                                    try {
                                        focusRequester.requestFocus()
                                    } catch (_: Exception) {
                                    }
                                    keyboard?.show()
                                }
                        })
                    }
                    .pointerInput(Unit) {
                        // Independent terminal selection gestures. This
                        // runs alongside (not instead of) tap handling
                        // and LazyColumn touch scrolling: it activates
                        // ONLY after a long-press hold, so normal scroll
                        // drags still reach the list untouched.
                        detectDragGesturesAfterLongPress(
                            onDragStart = { offset ->
                                // Yield to handle drags: a press that
                                // lands on a visible handle belongs to
                                // that handle's own detector. Anchoring
                                // here too would snap the selection to
                                // the raw finger point (up to a whole
                                // handle-box away from the true endpoint)
                                // and then fight the handle move-for-move.
                                // Pre-claim ownership for the handle; the
                                // end/cancel below frees it if the handle
                                // never moves (plain tap-hold-release).
                                if (selOwnerBox[0] != null ||
                                    isOnHandle(offset)
                                ) {
                                    selOwnerBox[0] = 1
                                    surfaceDeadBox[0] = true
                                    return@detectDragGesturesAfterLongPress
                                }
                                selOwnerBox[0] = 0
                                surfaceDeadBox[0] = false
                                beginSelectionAt(offset)
                                // Menu waits until the finger lifts: it
                                // used to pop up right under the finger,
                                // over the text and the new handles.
                                try {
                                    hideTermMenu()
                                } catch (_: Exception) {
                                }
                            },
                            onDragEnd = {
                                stopDragScroll()
                                val owned = !surfaceDeadBox[0]
                                selOwnerBox[0] = null
                                surfaceDeadBox[0] = false
                                val cur = termSel
                                if (owned && cur != null &&
                                    !cur.normalized().isEmpty()
                                ) {
                                    showTermMenu(Offset.Zero)
                                }
                            },
                            onDragCancel = {
                                stopDragScroll()
                                selOwnerBox[0] = null
                                surfaceDeadBox[0] = false
                            },
                            onDrag = { change, _ ->
                                if (surfaceDeadBox[0]) {
                                    return@detectDragGesturesAfterLongPress
                                }
                                dragExtend(change.position)
                                change.consume()
                            }
                        )
                    }
                ) {
                    // NOTE: deliberately NO SelectionContainer here. The
                    // framework SelectionManager crashes dragging across
                    // virtualized LazyColumn rows (stale selectable ids) and
                    // can only ever cover composed items. Terminal selection
                    // is fully independent (termSel + emulator buffer).
                    if (starting && !hasOutput && sbCount == 0) {
                        Text(
                            text = "Starting Ubuntu shell…",
                            style = TermStyle,
                            color = Color.Gray
                        )
                    } else {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            if (!altActive) {
                                items(sbCount, key = { i ->
                                        emulator.scrollbackId(i)
                                }) { i ->
                                    val base = emulator.scrollbackStyled(i)
                                    Text(
                                        text = remember(base, termSel) {
                                            highlightLine(base, i, termSel)
                                        },
                                        onTextLayout = { layout ->
                                            rememberLayout(
                                                emulator.scrollbackId(i),
                                                layout
                                            )
                                        },
                                        style = TermStyle,
                                        color = TermText,
                                        softWrap = false
                                    )
                                }
                            }
                            items(rowCount, key = { r -> "row-$r" }) { r ->
                                // Transcript line of this grid row (same
                                // mapping the emulator uses to render).
                                val lineIdx = if (altActive) {
                                    r
                                } else {
                                    sbCount + r
                                }
                                Text(
                                    text = remember(emuVersion, r, termSel) {
                                        highlightLine(
                                            emulator.renderRow(r),
                                            lineIdx,
                                            termSel
                                        )
                                    },
                                    onTextLayout = { layout ->
                                        rememberLayout("row-$r", layout)
                                    },
                                    style = TermStyle,
                                    color = TermText,
                                    softWrap = false
                                )
                            }
                        }
                    }
                    if (showJump) {
                        TextButton(
                            onClick = { scrollToBottom(true) },
                            modifier = Modifier.align(Alignment.BottomEnd)
                        ) {
                            Text("↓ bottom", fontSize = 12.sp)
                        }
                    }
                    // Selection handles overlay: real draggable endpoints.
                    // Drawn only for currently-visible endpoint lines; the
                    // overlay itself is touch-transparent (only the 32dp
                    // handle boxes capture input), so list scrolling, taps
                    // and the jump button keep working everywhere else.
                    // Positions derive from the transcript model + live
                    // layout on every recomposition — never from
                    // SelectionManager nodes.
                    // Own recompose scope: termSel changes on every drag move,
                    // and reading it here (inline in the screen body) used to
                    // recompose the WHOLE terminal screen per finger move,
                    // which made dragging choppy. As a local composable only
                    // this overlay recomposes.
                    @Composable
                    fun SelectionHandlesOverlay() {
                        val selHandles = termSel?.normalized()
                        // Keep the nodes mounted while a handle drag is active
                        // even if the range momentarily reads empty (collapse
                        // just as the dragged endpoint crosses the other one):
                        // unmounting would cancel the gesture driving the drag.
                        if (selHandles != null &&
                            (!selHandles.isEmpty() || activeHandleBox.value >= 0)
                        ) {
                            val startRaw = endpointPos(0)
                            val endRaw = endpointPos(1)
                            // While a handle is dragged, glide to each new
                            // character boundary instead of hopping cell by
                            // cell; at rest (and while scrolling) snap so the
                            // handles never trail the text.
                            val dragging = activeHandleBox.value >= 0
                            val glide = if (dragging) {
                                spring<Offset>(
                                    dampingRatio = Spring.DampingRatioNoBouncy,
                                    stiffness = Spring.StiffnessMedium
                                )
                            } else {
                                snap<Offset>()
                            }
                            val startAnim by animateOffsetAsState(
                                startRaw ?: Offset.Zero, glide, label = "selStart"
                            )
                            val endAnim by animateOffsetAsState(
                                endRaw ?: Offset.Zero, glide, label = "selEnd"
                            )
                            val startPx = if (startRaw != null) startAnim else null
                            val endPx = if (endRaw != null) endAnim else null
                            Box(Modifier.fillMaxSize()) {
                                if (startPx != null) {
                                    TermHandle(
                                        dotColor = Accent,
                                        locateAnchor = { endpointTouchPos(0) },
                                        claimHandle = {
                                            if (selOwnerBox[0] == 0) {
                                                false
                                            } else {
                                                selOwnerBox[0] = 1
                                                activeHandleBox.value = 0
                                                true
                                            }
                                        },
                                        releaseHandle = {
                                            if (selOwnerBox[0] == 1) {
                                                selOwnerBox[0] = null
                                            }
                                            // Gesture over for ANY reason (end,
                                            // cancel, dead-start): free the
                                            // overlay slot and stop the shared
                                            // edge auto-scroll — cancel used to
                                            // leak the loop, which then pinned
                                            // termSel to the edges every frame
                                            // (selection flying = "jumps").
                                            activeHandleBox.value = -1
                                            stopDragScroll()
                                        },
                                        onDragStart = {
                                            follow = false
                                            try {
                                                hideTermMenu()
                                            } catch (_: Exception) {
                                            }
                                        },
                                        onMove = { pos -> moveEndpoint(0, pos) },
                                        onDone = { pos ->
                                            stopDragScroll()
                                            showTermMenu(pos)
                                        },
                                        modifier = Modifier.offset {
                                            IntOffset(
                                                (startPx.x - (HandleW / 2).toPx()).roundToInt(),
                                                (startPx.y - HandleTipY.toPx()).roundToInt()
                                            )
                                        }
                                    )
                                }
                                if (endPx != null) {
                                    TermHandle(
                                        dotColor = Accent,
                                        locateAnchor = { endpointTouchPos(1) },
                                        claimHandle = {
                                            if (selOwnerBox[0] == 0) {
                                                false
                                            } else {
                                                selOwnerBox[0] = 1
                                                activeHandleBox.value = 1
                                                true
                                            }
                                        },
                                        releaseHandle = {
                                            if (selOwnerBox[0] == 1) {
                                                selOwnerBox[0] = null
                                            }
                                            activeHandleBox.value = -1
                                            stopDragScroll()
                                        },
                                        onDragStart = {
                                            follow = false
                                            try {
                                                hideTermMenu()
                                            } catch (_: Exception) {
                                            }
                                        },
                                        onMove = { pos -> moveEndpoint(1, pos) },
                                        onDone = { pos ->
                                            stopDragScroll()
                                            showTermMenu(pos)
                                        },
                                        modifier = Modifier.offset {
                                            IntOffset(
                                                (endPx.x - (HandleW / 2).toPx()).roundToInt(),
                                                (endPx.y - HandleTipY.toPx()).roundToInt()
                                            )
                                        }
                                    )
                                }
                            }
                        }
                    }
                    SelectionHandlesOverlay()
                    if (showManualKeyboardButton && runCommand != null && alive) {
                        // Manual keyboard toggle for programs that read input
                        // without printing a prompt the heuristic can spot.
                        Box(
                            Modifier
                            // BottomStart: the "↓ bottom" jump button
                            // already owns the bottom-end corner.
                            .align(Alignment.BottomStart)
                            .padding(start = 10.dp, bottom = 10.dp)
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(IdeTheme.PANEL).copy(alpha = 0.82f))
                            .clickable {
                                if (termImeVisible) {
                                    try {
                                        focusManagerForKb.clearFocus(force = true)
                                    } catch (_: Exception) {
                                    }
                                    keyboard?.hide()
                                } else {
                                    try {
                                        focusRequester.requestFocus()
                                    } catch (_: Exception) {
                                    }
                                    keyboard?.show()
                                }
                            },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "⌨", fontSize = 18.sp,
                                color = Color(if (termImeVisible) 0xFF4ADE80 else 0xFFC9D1D9)
                            )
                        }
                    }
                    // Invisible IME conduit (1dp, transparent): captures the
                    // soft keyboard and forwards bytes to the PTY. Hardware
                    // keys arrive through onPreviewKeyEvent on the same node.
                    // The 1dp field is only a keyboard conduit. Its own
                    // cursor/selection handle (same teardrop look, drawn at
                    // the top-left of the surface) showed up as a THIRD,
                    // stray handle. Make that handle fully transparent.
                    CompositionLocalProvider(
                        LocalTextSelectionColors provides TextSelectionColors(
                            handleColor = Color.Transparent,
                            backgroundColor = Color.Transparent
                        )
                    ) {
                        BasicTextField(
                            value = imeField,
                            onValueChange = { onImeChange(it) },
                            modifier = Modifier
                            .size(1.dp)
                            .focusRequester(focusRequester)
                            .onFocusChanged { imeFocused = it.isFocused }
                            .onPreviewKeyEvent(::onTerminalKey),
                            textStyle = TermStyle.copy(color = Color.Transparent),
                            singleLine = false,
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.None,
                                autoCorrect = false,
                                keyboardType = KeyboardType.Text,
                                imeAction = ImeAction.None
                            )
                        )
                    }
                }

                if (!alive && !starting) {
                    Text(
                        text = exitMessage ?: "Shell is not running.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Warn,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                // Termux-like extra-keys bar: fixed compact rows below the
                // terminal. Every key goes through sendKey() into the same
                // PTY stdin as the real keyboard — no second input system.
                // Hidden for console runs (output space + plain keyboard).
                if (showExtraKeys) {
                    ExtraKeysBar(
                        ctrlOn = ctrlLatch,
                        altOn = altLatch,
                        fireKey = fireKey,
                        fireArrow = fireArrow,
                        toggleCtrl = toggleCtrl,
                        toggleAlt = toggleAlt,
                        fireStop = fireStop,
                        onPage = pageFn,
                        showKeyboardToggle = showKeyboardToggle,
                        compact = compactExtraKeys,
                        focusRequester = focusRequester
                    )
                }
            }
        }
    }

    if (confirmRestart) {
        IdeAlertDialog(
            onDismissRequest = { confirmRestart = false },
            confirmButton = {
                TextButton(onClick = {
                        confirmRestart = false
                        doRestart()
                }) {
                    Text("Restart")
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmRestart = false }) {
                    Text("Cancel")
                }
            },
            title = { Text("Restart terminal?") },
            text = {
                Text("This kills the current shell and clears the screen.")
            }
        )
    }
    }
}

/**
 * One draggable selection handle (start or end of the terminal selection).
 * Purely visual + gesture: a 32dp touch box with an accent dot/stem whose
 * anchor tracks a transcript endpoint. Dragging updates ONLY the transcript
 * selection model (never SelectionManager nodes); auto-scroll at the edges
 * is driven by the caller through onMove. The pointerInput block is keyed
 * by a constant, so recompositions (e.g. selection updates mid-drag) never
 * restart it; all reads inside go through stable holders/state and are
 * therefore always fresh. claimHandle/releaseHandle arbitrate with the
 * surface long-press recognizer so only one writer moves termSel at a time.
 * releaseHandle fires on EVERY termination path (end, cancel, dead-start),
 * so callers also clear the active-slot marker and stop edge auto-scroll
 * there. No handles appear for empty selections (the endpointPos fallback
 * keeps a dragged one mounted through transient collapse instead).
 */
@Composable
internal fun TermHandle(
    dotColor: Color,
    locateAnchor: () -> Offset?,
    claimHandle: () -> Boolean,
    releaseHandle: () -> Unit,
    onDragStart: () -> Unit,
    onMove: (Offset) -> Unit,
    onDone: (Offset) -> Unit,
    modifier: Modifier = Modifier,
) {
    var nodeCoords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    Box(
        modifier = modifier
        .size(width = HandleW, height = HandleH)
        .onGloballyPositioned { coords -> nodeCoords = coords }
        .pointerInput("sel-handle") {
            // The handle node MOVES with the selection while it is being
            // dragged, so the pointer's node-local position (and
            // dragAmount) shrinks as the node follows the finger: the
            // handle lagged, froze, or snapped. Instead, convert every
            // pointer sample to the stable parent (surface) space using
            // the node's CURRENT position, and keep the fixed grab offset
            // between finger and selection point.
            var grab = Offset.Zero
            var haveAcc = false
            var dead = false
            var last = Offset.Zero
            fun fingerInParent(local: Offset): Offset {
                val origin = nodeCoords?.positionInParent() ?: Offset.Zero
                return origin + local
            }
            detectDragGestures(
                onDragStart = { startLocal ->
                    // Yield when the surface selection drag owns the
                    // pointer (finger crossed a handle mid-drag): two
                    // writers on termSel is exactly the jump source.
                    if (!claimHandle()) {
                        dead = true
                        return@detectDragGestures
                    }
                    dead = false
                    val anchor = locateAnchor()
                    if (anchor == null) {
                        dead = true
                        releaseHandle()
                        return@detectDragGestures
                    }
                    val finger = fingerInParent(startLocal)
                    grab = anchor - finger
                    last = anchor
                    haveAcc = true
                    onDragStart()
                },
                onDragEnd = {
                    if (!dead && haveAcc) onDone(last)
                    releaseHandle()
                },
                onDragCancel = { releaseHandle() },
                onDrag = { change, _ ->
                    if (dead || !haveAcc) return@detectDragGestures
                    last = fingerInParent(change.position) + grab
                    onMove(last)
                    change.consume()
                }
            )
        },
        contentAlignment = Alignment.TopCenter,
    ) {
        // Teardrop: a 22dp square with one sharp corner, rotated 45 degrees
        // so the sharp corner points up at the endpoint (tip at 4dp).
        Box(
            modifier = Modifier
            .padding(top = 9.dp)
            .size(22.dp)
            .rotate(45f)
            .background(
                dotColor,
                RoundedCornerShape(
                    topStart = 0.dp,
                    topEnd = 11.dp,
                    bottomEnd = 11.dp,
                    bottomStart = 11.dp
                )
            )
        )
    }
}

/**
 * One extra-key button. Custom press handling (not onClick) so hold-to-
 * repeat works and release never double-fires: the gesture scope is
 * cancelled on lift, which ends the repeat loop. Repeats call onFire
 * directly without touching Compose state, so holding an arrow cannot
 * flood recomposition. Buttons never take IME focus (no clickable focus
 * node), so the soft keyboard state is untouched by bar taps.
 */
@Composable
private fun ExtraKey(
    label: String,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    danger: Boolean = false,
    repeatable: Boolean = false,
    onFire: () -> Unit
) {
    // Latest action without restarting key handling on recomposition.
    val latestFire by rememberUpdatedState(onFire)
    val scope = rememberCoroutineScope()
    var pressed by remember { mutableStateOf(false) }
    val bg = when {
        active -> Accent.copy(alpha = 0.28f)
        pressed -> TermText.copy(alpha = 0.10f)
        else -> TermText.copy(alpha = 0.04f)
    }
    val fg = when {
        danger -> Color(IdeTheme.ERROR)
        active -> Accent
        else -> TermText
    }
    Box(
        modifier = modifier
        .height(40.dp)
        .clip(RoundedCornerShape(8.dp))
        .background(bg)
        .pointerInput(repeatable) {
            awaitEachGesture {
                val down = awaitFirstDown()
                pressed = true
                try {
                    latestFire()
                    if (repeatable) {
                        // Repeat runs in the composition scope (plain
                        // delay() is legal there); the gesture scope only
                        // waits for release, which cancels the repeat.
                        if (awaitLongPressOrCancellation(down.id) != null) {
                            val job = scope.launch {
                                while (true) {
                                    latestFire()
                                    delay(REPEAT_INTERVAL_MS)
                                }
                            }
                            try {
                                waitForUpOrCancellation()
                            } finally {
                                job.cancel()
                            }
                        }
                    } else {
                        waitForUpOrCancellation()
                    }
                } finally {
                    pressed = false
                }
            }
        },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = fg,
            maxLines = 1
        )
    }
}

/**
 * Compact two-row terminal control bar. It only subscribes to latch/IME
 * state, so PTY output flushes never rebuild it.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ExtraKeysBar(
    ctrlOn: Boolean,
    altOn: Boolean,
    fireKey: (String) -> Unit,
    fireArrow: (String) -> Unit,
    toggleCtrl: () -> Unit,
    toggleAlt: () -> Unit,
    fireStop: () -> Unit,
    onPage: (Boolean) -> Unit,
    showKeyboardToggle: Boolean,
    compact: Boolean,
    focusRequester: FocusRequester
) {
    val keyboard = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current
    val imeVisible = WindowInsets.isImeVisible
    Column(
        modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 2.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (!compact) ExtraKey("ESC", Modifier.weight(1f)) { fireKey("\u001B") }
            ExtraKey("TAB", Modifier.weight(1f)) { fireKey("\t") }
            ExtraKey("CTRL", Modifier.weight(1f), active = ctrlOn) { toggleCtrl() }
            if (!compact) ExtraKey("ALT", Modifier.weight(1f), active = altOn) { toggleAlt() }
            ExtraKey("←", Modifier.weight(1f), repeatable = true) { fireArrow("D") }
            ExtraKey("↓", Modifier.weight(1f), repeatable = true) { fireArrow("B") }
            ExtraKey("↑", Modifier.weight(1f), repeatable = true) { fireArrow("A") }
            ExtraKey("→", Modifier.weight(1f), repeatable = true) { fireArrow("C") }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            ExtraKey("HOME", Modifier.weight(1f)) { fireKey("\u001B[H") }
            ExtraKey("END", Modifier.weight(1f)) { fireKey("\u001B[F") }
            ExtraKey("PG↑", Modifier.weight(1f), repeatable = true) { onPage(false) }
            ExtraKey("PG↓", Modifier.weight(1f), repeatable = true) { onPage(true) }
            ExtraKey("DEL", Modifier.weight(1f), repeatable = true) { fireKey("\u001B[3~") }
            if (!compact) ExtraKey("⌫", Modifier.weight(1f), repeatable = true) { fireKey("\u007f") }
            ExtraKey("STOP", Modifier.weight(1f), danger = true) { fireStop() }
            if (showKeyboardToggle && !compact) ExtraKey("⌨", Modifier.weight(1f)) {
                if (imeVisible) {
                    focusManager.clearFocus()
                    keyboard?.hide()
                } else {
                    try {
                        focusRequester.requestFocus()
                    } catch (_: Exception) {
                    }
                    keyboard?.show()
                }
            }
        }
    }
}
