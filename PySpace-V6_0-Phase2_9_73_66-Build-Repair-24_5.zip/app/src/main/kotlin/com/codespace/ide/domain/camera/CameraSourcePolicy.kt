package com.codespace.ide.domain.camera

private val CAMERA_SOURCE_MARKERS = Regex(
    "phone_camera|PHONE_CAMERA_URL|stream\\.mjpg|/frame\\.jpg|phone-camera|videocapture\\s*\\(\\s*[01]",
    RegexOption.IGNORE_CASE
)

/** True when a Python source file uses the phone-camera bridge. */
fun detectCameraFromSource(fileName: String, source: String?): Boolean {
    if (fileName.substringAfterLast('.', "").lowercase() != "py") return false
    val text = (source ?: "").take(200_000)
    return text.isNotBlank() && CAMERA_SOURCE_MARKERS.containsMatchIn(text)
}
