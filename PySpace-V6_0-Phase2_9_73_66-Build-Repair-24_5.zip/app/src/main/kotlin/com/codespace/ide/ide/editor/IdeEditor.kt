package com.codespace.ide.ide.editor

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.zIndex
import com.codespace.ide.ide.ui.DrawerShift
import com.codespace.ide.ide.EditorFontCatalog
import com.codespace.ide.ide.EditorLanguage
import com.codespace.ide.ide.EditorLanguageRegistry
import com.codespace.ide.ide.EditorSymbolCatalog
import com.codespace.ide.ide.FileContent
import com.codespace.ide.ide.IdeAlertDialog
import com.codespace.ide.ide.IdeRoot
import com.codespace.ide.ide.ImageViewerTab
import com.codespace.ide.ide.NativeNotebook
import com.codespace.ide.ide.notebook.NotebookRepository
import com.codespace.ide.ide.PillButton
import com.codespace.ide.ide.PyEditor
import com.codespace.ide.ide.UnsupportedFileView
import com.codespace.ide.ide.codeintel.PythonLspController
import com.codespace.ide.ide.codeintel.WorkspaceRefactorTransaction
import com.codespace.ide.ide.ui.drawerDrag
import com.codespace.ide.ide.ui.drawerNestedScroll
import com.codespace.ide.ide.home.ProjectPackagesContent
import com.codespace.ide.ide.projects.guestProjectRoot
import com.codespace.ide.ide.pythonProblems
import com.codespace.ide.ide.settings.IdePrefs
import com.codespace.ide.ide.settings.IdeSettingsState
import com.codespace.ide.ide.terminal.TermBridge
import com.codespace.ide.ide.theme.IdeTheme
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.codespace.ide.ProotManager
import com.codespace.ide.ide.JSON
import com.codespace.ide.ide.codeintel.ProjectIndexMonitor
import com.codespace.ide.ide.codeintel.PythonImportAnalyzer
import com.codespace.ide.ide.packages.PackageManagerViewModel

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun IdeEditor(
    editorViewModel: EditorViewModel,
    prefs: IdePrefs,
    settings: IdeSettingsState,
    onCodeFontSizeChange: (Float) -> Unit,
    bridge: TermBridge,
    proot: com.codespace.ide.ProotManager,
    pythonLspController: PythonLspController? = null,
    notebookRepository: NotebookRepository,
    onRun: (OpenTab) -> Unit,
    /** Run the file with the embedded display forced on. */
    onRunWithDisplay: (OpenTab) -> Unit = {},
    /** Opens the settings hub (fullscreen overlay). */
    onOpenSettings: () -> Unit = {},
    /**
     * Push-drawer shift state, owned by IdeRoot (UI only). The editor
     * content carries the swipe gesture; the tree panel itself lives in
     * IdeRoot so editor AND bottom panel slide together.
     */
    drawerShift: DrawerShift,
    /**
     * True while a console run is live (usually the web server). The Run key
     * turns into Stop so one tap ends the server instead of starting a
     * second run on top of it.
     */
    isRunActive: Boolean,
    onStopRun: () -> Unit,
    /**
     * A GUI run is alive but its display viewer is minimized: the top bar
     * shows a spinner chip that brings the viewer back.
     */
    displayHidden: Boolean = false,
    onShowDisplay: () -> Unit = {},
    /** True while the project's program/server is running. */
    projectRunning: Boolean = false,
    /** Leave the project completely (stops everything, saves the tabs). */
    onExitProject: () -> Unit = {},
    /** False while settings / browser / display cover the editor. */
    editorActive: Boolean = true,
    onBack: () -> Unit
) {
    val session = editorViewModel.session
    // .ipynb tabs the user switched to raw JSON (default is the notebook view).
    val rawNotebooks = remember { androidx.compose.runtime.mutableStateListOf<String>() }
    val indexingSession = rememberEditorIndexingSession(session.project, proot)
    val indexMonitor = indexingSession.indexMonitor
    val indexState = indexingSession.indexState
    val environmentIndexMonitor = indexingSession.environmentIndexMonitor
    val environmentIndexState = indexingSession.environmentIndexState
    var showIndexChip by indexingSession.showIndexChip
    var showIndexDetails by remember { mutableStateOf(false) }
    var indexPanelTab by remember { mutableStateOf(0) }
    var environmentPackageFilter by remember { mutableStateOf("") }
    var runningWarn by remember { mutableStateOf(false) }
    var pendingRefactorRecoveries by remember(session.project.dir.absolutePath) {
        mutableStateOf<List<WorkspaceRefactorTransaction.Pending>>(emptyList())
    }
    var refactorRecoveryBusy by remember { mutableStateOf(false) }
    var refactorRecoveryScanComplete by remember(session.project.dir.absolutePath) { mutableStateOf(false) }
    var refactorRecoveryError by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val keyboard = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current
    // Run hides the keyboard first: output belongs to the console, and the
    // console must never auto-open the keyboard (tap the surface to type).
    fun runAndHide(t: OpenTab, withDisplay: Boolean = false) {
        try {
            focusManager.clearFocus(force = true)
        } catch (_: Exception) {
        }
        try {
            keyboard?.hide()
        } catch (_: Exception) {
        }
        if (withDisplay) onRunWithDisplay(t) else onRun(t)
    }
    var cursorLine by remember { mutableStateOf(1) }
    var cursorCol by remember { mutableStateOf(0) }
    // Live code font: pinch-to-zoom writes it (and persists it); if the
    // Settings screen moves the stored font behind our back, follow it.
    var liveFont by remember { mutableStateOf(settings.codeFontSize) }
    // Settings updates are observable now, so reflect them immediately even
    // while this editor screen remains mounted underneath the Settings overlay.
    LaunchedEffect(settings.codeFontSize) {
        liveFont = settings.codeFontSize
    }
    // Debounced persistence of a pinch-zoomed font: writing preferences and
    // re-emitting the whole settings state during the gesture made zooming
    // stutter.
    LaunchedEffect(liveFont) {
        if (liveFont != settings.codeFontSize) {
            kotlinx.coroutines.delay(300)
            onCodeFontSizeChange(liveFont)
        }
    }
    // Symbol bar shows only while the editor itself holds focus: typing in
    // the terminal/console must show only the terminal extra-keys instead.
    var edFocus by remember { mutableStateOf(false) }
    var insertReq by remember { mutableStateOf<String?>(null) }
    var moreOpen by remember { mutableStateOf(false) }
    var findReplaceOpen by remember { mutableStateOf(false) }
    var findQuery by remember { mutableStateOf("") }
    var replaceQuery by remember { mutableStateOf("") }
    var findCaseSensitive by remember { mutableStateOf(false) }
    var findWholeWord by remember { mutableStateOf(false) }
    var findRegex by remember { mutableStateOf(false) }
    var findIndex by remember { mutableStateOf(0) }
    var findReplaceMessage by remember { mutableStateOf<String?>(null) }
    var findSelectionRequest by remember { mutableStateOf<Pair<String, IntRange>?>(null) }
    // Menu > Reformat: bumped to ask the editor to reformat the active file.
    var reformatReq by remember { mutableStateOf(0) }
    var fixImportsReq by remember { mutableStateOf(0) }
    var centerCaretReq by remember { mutableStateOf(0) }
    // Touch-accessible edit commands are routed to the active editor instance.
    var editorCommand by remember { mutableStateOf<Pair<String, String>?>(null) }
    // Menu > Close all tabs while some tab has unsaved changes.
    var closeAllAsk by remember { mutableStateOf(false) }
    var pkgsOpen by remember { mutableStateOf(false) }
    var runMsg by remember { mutableStateOf<String?>(null) }
    // Live text selection (reset per file): while a selection exists, swipe
    // gestures never drive the tree, so selection drags can't be stolen.
    var edSelection by remember(session.active?.file?.absolutePath) { mutableStateOf(false) }
    // Swipe distance before the tree engages: taps, cursor nudges and short
    // scrolls never reach it.
    val drawerCommitPx = with(LocalDensity.current) { 40.dp.toPx() }
    val active = session.active
    val breakpointContext = androidx.compose.ui.platform.LocalContext.current
    val breakpointPrefs = remember(breakpointContext) { breakpointContext.getSharedPreferences("pyspace_debugger", android.content.Context.MODE_PRIVATE) }
    LaunchedEffect(active?.file?.absolutePath) {
        val file = active?.file ?: return@LaunchedEffect
        val encoded = breakpointPrefs.getString("breakpoints:${file.absolutePath}", null)
        if (encoded != null && EditorBreakpointStore.all(file).isEmpty()) EditorBreakpointStore.restore(file, encoded)
    }

    fun currentCaretOffset(tab: OpenTab): Int {
        val lines = tab.text.split('\n')
        val lineIndex = (cursorLine - 1).coerceIn(0, lines.lastIndex)
        var offset = 0
        for (i in 0 until lineIndex) offset += lines[i].length + 1
        return (offset + cursorCol.coerceAtLeast(0)).coerceIn(0, tab.text.length)
    }
    val syntaxResults = pythonLspController?.results?.collectAsState()?.value ?: emptyMap()
    val syntaxValidatedSources = pythonLspController?.validatedSources?.collectAsState()?.value ?: emptyMap()
    val activeIsPython = active?.let { EditorLanguageRegistry.languageFor(it.file) == EditorLanguage.PYTHON } == true
    val findReplaceAvailable = active?.editable == true &&
        (!active.file.extension.equals("ipynb", ignoreCase = true) || rawNotebooks.contains(active.file.absolutePath))
    val activeSyntaxDiagnostics = if (activeIsPython) active?.file?.absolutePath?.let { syntaxResults[it] }.orEmpty() else emptyList()
    val editorUiState = editorViewModel.state.collectAsState().value

    // Sync only the active Python buffer. The controller debounces edits and
    // sends document changes to one persistent project-scoped pylsp process.
    LaunchedEffect(active?.file?.absolutePath, pythonLspController) {
        val currentTab = active
        val controller = pythonLspController
        if (currentTab != null && controller != null &&
            currentTab.file.extension.equals("py", ignoreCase = true)
        ) {
            snapshotFlow { currentTab.text }.collectLatest { source ->
                controller.schedule(session.project, currentTab.file, source)
            }
        }
    }
    LaunchedEffect(editorUiState.error) {
        editorUiState.error?.let { runMsg = it }
    }
    // Debounced problems badge. The old `remember(active?.text)` KEY read
    // the buffer in this scope, so pythonProblems re-ran on every keystroke
    // and this whole editor scope recomposed per character. Text is now
    // observed OUTSIDE composition; the badge settles ~250ms after typing
    // pauses and keystrokes never trigger this scan.
    var problemsCount by remember(active?.file) { mutableStateOf(0) }
    LaunchedEffect(active, syntaxResults) {
        val a = active
        if (a != null && EditorLanguageRegistry.languageFor(a.file) == EditorLanguage.PYTHON) {
            fun countProblems(text: String): Int {
                val checks = pythonProblems(text)
                val hasParserResult = syntaxResults.containsKey(a.file.absolutePath)
                return if (hasParserResult) {
                    activeSyntaxDiagnostics.count { it.kind.equals("Error", true) || it.kind.equals("Warning", true) }
                } else checks.size
            }
            problemsCount = countProblems(a.text)
            snapshotFlow { a.text }.collectLatest { txt ->
                kotlinx.coroutines.delay(250)
                problemsCount = countProblems(txt)
            }
        } else {
            problemsCount = 0
        }
    }

    // Entering a project must never summon the keyboard by itself — in
    // particular with no file open, where nothing can receive typing. Any
    // inherited focus is dropped and the keyboard hidden; explicit taps
    // still open it wherever typing is possible.
    LaunchedEffect(session.project.dir.absolutePath) {
        refactorRecoveryScanComplete = false
        pendingRefactorRecoveries = withContext(Dispatchers.IO) {
            WorkspaceRefactorTransaction.pending(session.project.dir)
        }
        refactorRecoveryScanComplete = true
        refactorRecoveryError = null
        try {
            focusManager.clearFocus(force = true)
        } catch (_: Exception) {
        }
        try {
            keyboard?.hide()
        } catch (_: Exception) {
        }
    }

    // System back: dismiss the package page first, then close the tree, else exit.
    BackHandler {
        if (findReplaceOpen) {
            findReplaceOpen = false
        } else if (pkgsOpen) {
            pkgsOpen = false
        } else if (drawerShift.px.value > 1f) {
            scope.launch { drawerShift.close() }
        } else {
            editorViewModel.saveAll { onBack() }
        }
    }

    val currentMatches = remember(active?.file?.absolutePath, active?.text, findQuery, findCaseSensitive, findWholeWord, findRegex) {
        val source = active?.text.orEmpty()
        if (findQuery.isEmpty()) emptyList() else runCatching {
            val patternText = if (findRegex) findQuery else Regex.escape(findQuery)
            val wrapped = if (findWholeWord) "\\b(?:$patternText)\\b" else patternText
            val flags = if (findCaseSensitive) setOf() else setOf(RegexOption.IGNORE_CASE)
            Regex(wrapped, flags).findAll(source).map { it.range }.toList()
        }.getOrElse { emptyList() }
    }
    LaunchedEffect(currentMatches.size) {
        if (currentMatches.isEmpty()) findIndex = 0
        else findIndex = findIndex.coerceIn(0, currentMatches.lastIndex)
    }
    LaunchedEffect(findQuery, active?.file?.absolutePath, findReplaceOpen) {
        if (findReplaceOpen && currentMatches.isNotEmpty() && active != null) {
            findIndex = 0
            findSelectionRequest = active.file.absolutePath to currentMatches.first()
        }
    }
    fun replacementPattern(): Regex? = runCatching {
        val raw = if (findRegex) findQuery else Regex.escape(findQuery)
        Regex(if (findWholeWord) "\\b(?:$raw)\\b" else raw,
            if (findCaseSensitive) emptySet() else setOf(RegexOption.IGNORE_CASE))
    }.getOrNull()
    fun replaceCurrentMatch() {
        val tab = session.active ?: return
        if (findQuery.isEmpty() || replaceQuery.isEmpty()) return
        val regex = replacementPattern() ?: run {
            findReplaceMessage = "Invalid regular expression"
            return
        }
        val matches = runCatching { regex.findAll(tab.text).toList() }.getOrElse {
            findReplaceMessage = it.message ?: "Search failed"
            return
        }
        val match = matches.getOrNull(findIndex) ?: run {
            findReplaceMessage = "No match to replace"
            return
        }
        val changed = tab.text.replaceRange(match.range.first, match.range.last + 1, replaceQuery)
        if (changed != tab.text) {
            tab.applyEdit(changed, match.range.first + replaceQuery.length)
            findReplaceMessage = "Replaced 1 occurrence in ${tab.name}"
        }
    }

    fun replaceAllInCurrentFile() {
        val tab = session.active ?: return
        if (findQuery.isEmpty() || replaceQuery.isEmpty()) return
        val regex = replacementPattern() ?: run {
            findReplaceMessage = "Invalid regular expression"
            return
        }
        val count = runCatching { regex.findAll(tab.text).count() }.getOrElse {
            findReplaceMessage = it.message ?: "Search failed"
            return
        }
        if (count == 0) {
            findReplaceMessage = "No matches in ${tab.name}"
            return
        }
        // The transform overload treats replacement text literally (including '$'),
        // and a single applyEdit keeps the whole Replace All operation undoable.
        val changed = runCatching { regex.replace(tab.text) { replaceQuery } }.getOrElse {
            findReplaceMessage = it.message ?: "Replacement failed"
            return
        }
        if (changed != tab.text) {
            tab.applyEdit(changed, changed.length)
            findIndex = 0
            findReplaceMessage = "Replaced $count occurrence(s) in ${tab.name}"
        }
    }

    Scaffold(
        topBar = {
            // The indexing chip is layered over the app bar itself. Scaffold
            // already applies the status-bar inset above this slot, so the
            // chip is naturally below the Android status bar and is not clipped
            // by the editor content viewport.
            Box {
            TopAppBar(
                title = {
                    Column {
                        Text(session.project.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(
                            (if (active != null) active.name else "no file") +
                            (if (active?.dirty == true) " •" else ""),
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(IdeTheme.DIM)
                        )
                    }
                },
                navigationIcon = {
                    TextButton(onClick = {
                            scope.launch { drawerShift.open() }
                    }) { Text("☰", fontSize = 19.sp, color = Color(IdeTheme.TEXT)) }
                },
                actions = {
                    if (editorUiState.openingPath != null) {
                        androidx.compose.material3.CircularProgressIndicator(
                            modifier = Modifier.size(14.dp), strokeWidth = 2.dp,
                        )
                    }
                    if (displayHidden) {
                        TextButton(onClick = onShowDisplay) {
                            androidx.compose.material3.CircularProgressIndicator(
                                modifier = Modifier.size(14.dp),
                                strokeWidth = 2.dp,
                                color = Color(IdeTheme.ACCENT)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("Display", fontSize = 12.sp, color = Color(IdeTheme.ACCENT))
                        }
                    }
                    // Editing history controls appear before Save and Run.
                    TextButton(
                        onClick = { active?.let { editorCommand = it.file.absolutePath to "undo" } },
                        enabled = active?.canUndo == true,
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 5.dp, vertical = 4.dp)
                    ) { Text("↶", fontSize = 23.sp, color = Color(if (active?.canUndo == true) IdeTheme.TEXT else IdeTheme.DIM)) }
                    TextButton(
                        onClick = { active?.let { editorCommand = it.file.absolutePath to "redo" } },
                        enabled = active?.canRedo == true,
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 5.dp, vertical = 4.dp)
                    ) { Text("↷", fontSize = 23.sp, color = Color(if (active?.canRedo == true) IdeTheme.TEXT else IdeTheme.DIM)) }
                    // Save: only the ACTIVE tab. Lit while that tab has unsaved changes.
                    val canSave = active != null && active.dirty
                    TextButton(
                        onClick = {
                            val tab = active
                            if (tab != null) editorViewModel.save(tab)
                        },
                        enabled = canSave && active?.file?.absolutePath?.let { it !in editorUiState.savingPaths } == true,
                    ) {
                        if (active?.file?.absolutePath?.let { it in editorUiState.savingPaths } == true) {
                            androidx.compose.material3.CircularProgressIndicator(
                                modifier = Modifier.size(16.dp), strokeWidth = 2.dp,
                            )
                        } else SaveGlyph(Color(if (canSave) IdeTheme.ACCENT else IdeTheme.DIM))
                    }
                    if (isRunActive) {
                        TextButton(onClick = onStopRun) {
                            Text("■", fontSize = 16.sp, color = Color(IdeTheme.ERROR))
                        }
                    } else {
                        TextButton(onClick = {
                                val t = active
                                if (t == null) {
                                    runMsg = "Open a Python file first"
                                } else if (!t.editable) {
                                    runMsg = "Only text files can run (${t.detected.format})"
                                } else {
                                    runAndHide(t)
                                }
                        }) { Text("▶", fontSize = 16.sp, color = Color(IdeTheme.ACCENT)) }
                    }
                    Column {
                        TextButton(onClick = { moreOpen = true }) {
                            Text("⋮", fontSize = 18.sp, color = Color(IdeTheme.TEXT))
                        }
                        DropdownMenu(expanded = moreOpen, onDismissRequest = { moreOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("Index status") },
                                leadingIcon = { Text("◉", fontSize = 17.sp) },
                                onClick = {
                                    moreOpen = false
                                    showIndexDetails = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Reindex project") },
                                leadingIcon = { Text("↻", fontSize = 18.sp) },
                                enabled = indexState.status != com.codespace.ide.ide.codeintel.ProjectIndexMonitor.Status.INDEXING,
                                onClick = {
                                    moreOpen = false
                                    showIndexChip = true
                                    indexMonitor.rebuild()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Find / Replace") },
                                leadingIcon = { Text("⌕", fontSize = 19.sp) },
                                enabled = findReplaceAvailable,
                                onClick = {
                                    moreOpen = false
                                    findReplaceOpen = true
                                    findIndex = 0
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Settings") },
                                leadingIcon = { Text("⚙", fontSize = 17.sp) },
                                onClick = { moreOpen = false; onOpenSettings() }
                            )
                            DropdownMenuItem(
                                text = { Text("Package Manager") },
                                leadingIcon = { Text("▣", fontSize = 17.sp) },
                                onClick = { moreOpen = false; pkgsOpen = true }
                            )
                            DropdownMenuItem(
                                text = { Text("Run in console") },
                                onClick = {
                                    moreOpen = false
                                    val t = active
                                    if (t == null) {
                                        runMsg = "Open a Python file first"
                                    } else {
                                        runAndHide(t)
                                    }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Run with display") },
                                onClick = {
                                    moreOpen = false
                                    val t = active
                                    if (t == null) {
                                        runMsg = "Open a Python file first"
                                    } else {
                                        runAndHide(t, withDisplay = true)
                                    }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Save all") },
                                onClick = {
                                    moreOpen = false
                                    editorViewModel.saveAll()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Exit project") },
                                onClick = {
                                    moreOpen = false
                                    if (projectRunning) {
                                        runningWarn = true
                                    } else {
                                        editorViewModel.saveAll { onExitProject() }
                                    }
                                }
                            )
                            if (activeIsPython) DropdownMenuItem(
                                text = { Text("Reformat") },
                                onClick = {
                                    moreOpen = false
                                    val t = active
                                    if (t == null || !t.editable) {
                                        runMsg = "Open a Python file first"
                                    } else if (EditorLanguageRegistry.languageFor(t.file) != EditorLanguage.PYTHON) {
                                        runMsg = "Reformat works on Python files (.py)"
                                    } else {
                                        reformatReq++
                                    }
                                }
                            )
                            if (activeIsPython) DropdownMenuItem(
                                text = { Text("Fix Imports") },
                                onClick = {
                                    moreOpen = false
                                    val t = active
                                    if (t == null || !t.editable) {
                                        runMsg = "Open a Python file first"
                                    } else if (EditorLanguageRegistry.languageFor(t.file) != EditorLanguage.PYTHON) {
                                        runMsg = "Fix Imports works on Python files (.py)"
                                    } else {
                                        fixImportsReq++
                                    }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Close all tabs") },
                                onClick = {
                                    moreOpen = false
                                    if (session.tabs.any { it.dirty }) {
                                        closeAllAsk = true
                                    } else {
                                        session.closeAllTabs()
                                    }
                                }
                            )
                        }
                        if (runningWarn) {
                            IdeAlertDialog(
                                onDismissRequest = { runningWarn = false },
                                title = { Text("Project is running") },
                                text = {
                                    Text("The project is still running. Stop it first, then exit.")
                                },
                                confirmButton = {
                                    TextButton(onClick = {
                                            runningWarn = false
                                            onStopRun()
                                    }) { Text("Stop project") }
                                },
                                dismissButton = {
                                    TextButton(onClick = { runningWarn = false }) {
                                        Text("Cancel")
                                    }
                                }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(IdeTheme.PANEL))
            )
            androidx.compose.animation.AnimatedVisibility(
                visible = showIndexChip,
                modifier = Modifier.align(Alignment.Center).zIndex(30f),
                enter = androidx.compose.animation.fadeIn(animationSpec = tween(180)) +
                    slideInVertically(animationSpec = tween(220)) { -it / 2 },
                exit = androidx.compose.animation.fadeOut(animationSpec = tween(220)) +
                    slideOutVertically(animationSpec = tween(260)) { -it * 2 }
            ) {
                androidx.compose.material3.Surface(
                    modifier = Modifier
                        .shadow(8.dp, RoundedCornerShape(20.dp))
                        .clickable { showIndexDetails = true },
                    shape = RoundedCornerShape(20.dp),
                    color = Color(IdeTheme.PANEL),
                    tonalElevation = 5.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        when (indexState.status) {
                            com.codespace.ide.ide.codeintel.ProjectIndexMonitor.Status.IDLE,
                            com.codespace.ide.ide.codeintel.ProjectIndexMonitor.Status.INDEXING ->
                                androidx.compose.material3.CircularProgressIndicator(
                                    modifier = Modifier.size(13.dp), strokeWidth = 2.dp,
                                    color = Color(IdeTheme.ACCENT)
                                )
                            com.codespace.ide.ide.codeintel.ProjectIndexMonitor.Status.READY ->
                                Text("✓", color = Color(0xFF35B66A), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            com.codespace.ide.ide.codeintel.ProjectIndexMonitor.Status.ERROR ->
                                Text("!", color = Color(IdeTheme.ERROR), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        Text(
                            when (indexState.status) {
                                com.codespace.ide.ide.codeintel.ProjectIndexMonitor.Status.IDLE,
                                com.codespace.ide.ide.codeintel.ProjectIndexMonitor.Status.INDEXING -> "Indexing..."
                                com.codespace.ide.ide.codeintel.ProjectIndexMonitor.Status.READY -> "Indexed"
                                com.codespace.ide.ide.codeintel.ProjectIndexMonitor.Status.ERROR -> "Indexing failed"
                            },
                            color = Color(if (indexState.status == com.codespace.ide.ide.codeintel.ProjectIndexMonitor.Status.READY) 0xFF35B66A else IdeTheme.TEXT),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
            }
        },
        containerColor = Color(IdeTheme.BG)
    ) { padding ->
        Box(
            Modifier.fillMaxSize().padding(padding).imePadding()
        ) {
            Column(
                Modifier
                .fillMaxSize()
                // Tree swipe (editor area only — the panel keeps its own
                // gestures): threshold-gated, so taps, scrolling and
                // selection pass through untouched.
                .drawerDrag(drawerShift, scope, edSelection, drawerCommitPx)
                .drawerNestedScroll(drawerShift, scope, drawerCommitPx)
            ) {
            if (session.tabs.isNotEmpty()) {
                EditorTabStrip(session = session) { index, tab ->
                    // Keep the tab alive until its asynchronous save completes.
                    editorViewModel.save(tab) { saved ->
                        if (saved && !tab.dirty) session.closeTab(index)
                    }
                }
            }
            if (active != null && activeIsPython) {
                EditorBreadcrumb(session = session, activeFile = active.file) { crumb ->
                    session.revealTreePath(crumb)
                    scope.launch { drawerShift.open() }
                }
            }
            if (active != null) {
                // Stable callback identities: without these, every parent
                // recomposition (status line updates, keyboard open/close,
                // focus changes) handed PyEditor fresh lambdas — defeating
                // skipping and re-running its whole subtree for no reason.
                // They only write remembered state, so capturing it is
                // always safe (never stale).
                val onCursorCb = remember { { ln: Int, col: Int -> cursorLine = ln; cursorCol = col } }
                val onInsertConsumedCb = remember { { insertReq = null } }
                val onFocusChangeCb = remember { { v: Boolean -> edFocus = v } }
                val onSelectionChangeCb = remember { { v: Boolean -> edSelection = v } }
                val onJumpConsumedCb = remember { { session.jumpRequest = null } }
                // Persisting happens once, shortly after the zoom settles (see the
                // LaunchedEffect(liveFont) above) rather than on every change.
                val onFontSizeChangeCb = remember {
                    { v: Float -> liveFont = v }
                }
                // One shared weight modifier (a fresh instance per
                // recomposition would also defeat child skipping).
                val editorWeight = remember { Modifier.weight(1f) }
                // Key by file so switching tabs swaps the whole editor state.
                // Content routes by DETECTED kind (never by extension):
                // safe text edits, images view+zoom, everything else gets
                // an info view. Binary can never reach the text widget,
                // which is what used to freeze/crash the app on open.
                androidx.compose.runtime.key(active.file.absolutePath) {
                    val nbPath = active.file.absolutePath
                    val isNotebookFile = active.file.extension.equals("ipynb", ignoreCase = true)
                    if (isNotebookFile && rawNotebooks.contains(nbPath)) {
                        Row(
                            Modifier.fillMaxWidth().background(Color(IdeTheme.PANEL)).padding(horizontal = 12.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Raw JSON", fontSize = 12.sp, color = Color(IdeTheme.DIM), modifier = Modifier.weight(1f))
                            PillButton("Notebook view", Color(IdeTheme.ACCENT)) { rawNotebooks.remove(nbPath) }
                        }
                    }
                    when {
                        isNotebookFile && !rawNotebooks.contains(nbPath) -> NativeNotebook(
                            tab = active,
                            project = session.project,
                            codeFontFamily = EditorFontCatalog.find(settings.editorFontFamilyId).family,
                            pythonLspController = pythonLspController,
                            notebookRepository = notebookRepository,
                            onRaw = { rawNotebooks.add(nbPath) },
                            modifier = editorWeight
                        )
                        active.editable -> PyEditor(
                            tab = active,
                            session = session,
                            fontSize = liveFont,
                            codeFontFamily = EditorFontCatalog.find(settings.editorFontFamilyId).family,
                            tabWidth = settings.tabWidth,
                            autoIndent = settings.autoIndent,
                            showLines = settings.lineNumbers,
                            wordWrap = settings.wordWrap,
                            pan2D = settings.pan2D,
                            pinchZoom = settings.pinchZoom,
                            active = editorActive,
                            showDiagnosticPopup = activeIsPython && settings.showDiagnosticPopup,
                            showCompletionPopup = activeIsPython && settings.showCompletionPopup,
                            showDocumentationPopup = activeIsPython && settings.showDocumentationPopup,
                            // While the IME is open, keep the caret line clear of
                            // both editor chrome rows immediately above the keyboard:
                            // the problem/status row and the symbol shortcut row.
                            // The larger clearance is active only for the keyboard
                            // session; the normal closed-keyboard panel clearance
                            // remains unchanged.
                            bottomInset = if (WindowInsets.isImeVisible) 104.dp else 72.dp,
                            onFontSizeChange = onFontSizeChangeCb,
                            onCursor = onCursorCb,
                            insertRequest = insertReq,
                            centerCaretRequest = centerCaretReq,
                            onCenterCaretConsumed = { centerCaretReq = 0 },
                            reformatRequest = reformatReq,
                            onReformatConsumed = { reformatReq = 0 },
                            fixImportsRequest = fixImportsReq,
                            onFixImportsConsumed = { fixImportsReq = 0 },
                            analyzeImports = { source ->
                                com.codespace.ide.ide.codeintel.PythonImportAnalyzer.analyze(proot, source)
                            },
                            editorCommand = editorCommand,
                            externalSelectionRequest = findSelectionRequest?.takeIf { it.first == active.file.absolutePath }?.second,
                            onExternalSelectionConsumed = { findSelectionRequest = null },
                            onEditorCommandConsumed = { command ->
                                if (editorCommand == command) editorCommand = null
                            },
                            onInsertConsumed = onInsertConsumedCb,
                            jumpRequest = session.jumpRequest,
                            onJumpConsumed = onJumpConsumedCb,
                            onFocusChange = onFocusChangeCb,
                            onSelectionChange = onSelectionChangeCb,
                            syntaxDiagnostics = activeSyntaxDiagnostics,
                            syntaxValidatedSource = active?.file?.absolutePath?.let { syntaxValidatedSources[it] },
                            pythonLspController = pythonLspController,
                            onBreakpointToggle = { line ->
                                EditorBreakpointStore.toggle(active.file, line)
                                breakpointPrefs.edit().putString("breakpoints:${active.file.absolutePath}", EditorBreakpointStore.encode(active.file)).apply()
                            },
                            onGoToDefinition = { location ->
                                val target = location.file
                                val targetCanonical = runCatching { target.canonicalFile }.getOrDefault(target)
                                // Reuse an already-open document (including the
                                // current tab). Never create a duplicate tab for
                                // a definition in the same source file.
                                val existingIndex = session.tabs.indexOfFirst { tab ->
                                    runCatching { tab.file.canonicalFile == targetCanonical }
                                        .getOrDefault(tab.file.absolutePath == target.absolutePath)
                                }
                                if (existingIndex >= 0) {
                                    session.activeIndex = existingIndex
                                    val existingFile = session.tabs[existingIndex].file
                                    session.jumpRequest = existingFile.absolutePath to location.line
                                } else {
                                    editorViewModel.openFile(target)
                                    session.jumpRequest = target.absolutePath to location.line
                                }
                            },
                            modifier = editorWeight
                        )
                        active.detected.content == FileContent.IMAGE -> ImageViewerTab(
                            file = active.file,
                            detected = active.detected,
                            modifier = editorWeight
                        )
                        else -> UnsupportedFileView(
                            file = active.file,
                            detected = active.detected,
                            projectDir = session.project.dir,
                            modifier = editorWeight
                        )
                    }
                }
                if (active.editable) {
                    Divider(color = Color(IdeTheme.LINE))
                    EditorStatusLine(
                        tab = active, line = cursorLine, col = cursorCol,
                        problems = problemsCount,
                        onPositionClick = { centerCaretReq++ }
                    )
                    // Symbol bar lives directly above the open keyboard, and
                    // only while the editor itself is focused: a keyboard
                    // opened over the terminal/console shows only the
                    // terminal extra-keys instead. Hidden otherwise.
                    if (activeIsPython && WindowInsets.isImeVisible && edFocus) {
                        Divider(color = Color(IdeTheme.LINE))
                        PySymbolBar(
                            symbols = EditorSymbolCatalog.normalize(settings.editorSymbolOrder),
                            onInsert = { s -> insertReq = if (s == "TAB") "TAB" else s }
                        )
                    }
                }
            } else {
                Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("◈", color = Color(IdeTheme.ACCENT), fontSize = 40.sp)
                    Spacer(Modifier.height(10.dp))
                    Text(session.project.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Open the file tree (☰) and tap a file,\nor start a fresh script below.",
                        color = Color(IdeTheme.DIM), fontSize = 12.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(Modifier.height(12.dp))
                    TextButton(onClick = {
                        scope.launch {
                            try {
                                val f = File(session.project.dir, "scratch.py")
                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                                    if (!f.exists()) f.writeText("# scratch\n")
                                }
                                editorViewModel.openFile(f)
                                session.refreshTree()
                            } catch (cancelled: kotlinx.coroutines.CancellationException) {
                                throw cancelled
                            } catch (error: Exception) {
                                runMsg = error.message ?: "Could not create scratch.py"
                            }
                        }
                    }) {
                        Text("+ New scratch.py", color = Color(IdeTheme.ACCENT), fontSize = 14.sp)
                    }
                }
            }
        }
        // Floating editor overlay: it is measured independently from the
        // editor column, so showing Find/Replace never shrinks the code area.
            AnimatedVisibility(
                visible = findReplaceOpen && findReplaceAvailable,
                modifier = Modifier.fillMaxWidth().zIndex(10f),
                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(tween(230)),
                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(tween(170))
            ) {
                val canReplace = findQuery.isNotEmpty() && replaceQuery.isNotEmpty() && currentMatches.isNotEmpty()
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 9.dp, vertical = 5.dp)
                        .shadow(14.dp, RoundedCornerShape(14.dp))
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(IdeTheme.PANEL))
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("FIND / REPLACE", fontSize = 10.sp, fontWeight = FontWeight.Bold,
                            color = Color(IdeTheme.ACCENT), letterSpacing = 0.8.sp)
                        Spacer(Modifier.weight(1f))
                        Text(
                            "${if (currentMatches.isEmpty()) 0 else findIndex + 1} / ${currentMatches.size}",
                            fontSize = 11.sp, color = Color(IdeTheme.DIM)
                        )
                        TextButton(
                            onClick = { findReplaceOpen = false },
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp, vertical = 2.dp)
                        ) { Text("✕", color = Color(IdeTheme.DIM), fontSize = 15.sp) }
                    }
                    Spacer(Modifier.height(3.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = findQuery,
                            onValueChange = { findQuery = it; findIndex = 0; findReplaceMessage = null },
                            modifier = Modifier.weight(1f).height(54.dp),
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodySmall,
                            label = { Text("Find", fontSize = 10.sp) },
                            placeholder = { Text("Search in this file", fontSize = 11.sp) }
                        )
                        Spacer(Modifier.width(4.dp))
                        TextButton(
                            onClick = { findCaseSensitive = !findCaseSensitive },
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 5.dp, vertical = 3.dp)
                        ) { Text("Aa", fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                            color = Color(if (findCaseSensitive) IdeTheme.ACCENT else IdeTheme.DIM)) }
                        TextButton(
                            onClick = { findWholeWord = !findWholeWord },
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 5.dp, vertical = 3.dp)
                        ) { Text("W", fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                            color = Color(if (findWholeWord) IdeTheme.ACCENT else IdeTheme.DIM)) }
                        TextButton(
                            onClick = { findRegex = !findRegex },
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 5.dp, vertical = 3.dp)
                        ) { Text(".*", fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                            color = Color(if (findRegex) IdeTheme.ACCENT else IdeTheme.DIM)) }
                    }
                    Spacer(Modifier.height(5.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = replaceQuery,
                            onValueChange = { replaceQuery = it; findReplaceMessage = null },
                            modifier = Modifier.weight(1f).height(54.dp),
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodySmall,
                            label = { Text("Replace", fontSize = 10.sp) },
                            placeholder = { Text("Replacement text", fontSize = 11.sp) }
                        )
                        Spacer(Modifier.width(5.dp))
                        TextButton(
                            enabled = canReplace,
                            onClick = { replaceCurrentMatch() },
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 3.dp)
                        ) { Text("Replace", fontSize = 11.sp) }
                        TextButton(
                            enabled = canReplace,
                            onClick = { replaceAllInCurrentFile() },
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 3.dp)
                        ) { Text("Replace all", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                    }
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Current file only", fontSize = 10.sp, color = Color(IdeTheme.DIM))
                        Spacer(Modifier.weight(1f))
                        TextButton(
                            enabled = currentMatches.isNotEmpty(),
                            onClick = {
                                findIndex = (findIndex - 1 + currentMatches.size) % currentMatches.size
                                findSelectionRequest = active!!.file.absolutePath to currentMatches[findIndex]
                            },
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp, vertical = 0.dp)
                        ) { Text("↑", fontSize = 14.sp) }
                        TextButton(
                            enabled = currentMatches.isNotEmpty(),
                            onClick = {
                                findIndex = (findIndex + 1) % currentMatches.size
                                findSelectionRequest = active!!.file.absolutePath to currentMatches[findIndex]
                            },
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 7.dp, vertical = 0.dp)
                        ) { Text("↓", fontSize = 14.sp) }
                    }
                    findReplaceMessage?.let {
                        Text(it, color = Color(IdeTheme.DIM), fontSize = 10.sp,
                            modifier = Modifier.padding(start = 2.dp, top = 1.dp))
                    }
                }
            }


    }
    // In-project package manager is a full-screen destination, not a cramped
    // AlertDialog. The Activity-scoped PackageManagerViewModel survives this
    // surface transition and keeps an in-flight pip operation visible.
    if (pkgsOpen) {
        Dialog(
            onDismissRequest = { pkgsOpen = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Column(Modifier.fillMaxSize().background(Color(IdeTheme.BG)).navigationBarsPadding()) {
                Row(
                    Modifier.fillMaxWidth().background(Color(IdeTheme.BG))
                        .statusBarsPadding().padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { pkgsOpen = false }) {
                        Text("‹", fontSize = 28.sp, color = Color(IdeTheme.ACCENT))
                    }
                    Column(Modifier.weight(1f)) {
                        Text("Package Manager", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text(session.project.name, fontSize = 11.sp, color = Color(IdeTheme.DIM))
                    }
                    Text("PIP", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(IdeTheme.ACCENT), modifier = Modifier.padding(end = 12.dp))
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    androidx.compose.runtime.key(session.project.dir.absolutePath) {
                        ProjectPackagesContent(project = session.project, proot = proot)
                    }
                }
            }
        }
    }

    if (closeAllAsk) {
        val dirtyTabs = session.tabs.filter { it.dirty }
        IdeAlertDialog(
            onDismissRequest = { closeAllAsk = false },
            title = { Text("Unsaved changes") },
            text = {
                Column {
                    Text(
                        (if (dirtyTabs.size == 1) "This file has" else "These files have") +
                            " changes that are not saved:"
                    )
                    Spacer(Modifier.height(8.dp))
                    for (t in dirtyTabs.take(6)) {
                        Text("• " + t.name, fontSize = 13.sp, color = Color(IdeTheme.TEXT))
                    }
                    if (dirtyTabs.size > 6) {
                        Text("…and " + (dirtyTabs.size - 6) + " more", fontSize = 12.sp, color = Color(IdeTheme.DIM))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    editorViewModel.saveAll { closeAllAsk = false; session.closeAllTabs() }
                }) { Text("Save all files") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { closeAllAsk = false }) { Text("Dismiss") }
                    TextButton(onClick = {
                        closeAllAsk = false
                        session.closeAllTabs()
                    }) { Text("Close without saving", color = Color(IdeTheme.ERROR)) }
                }
            }
        )
    }
    if (runMsg != null) {
        IdeAlertDialog(
            onDismissRequest = { runMsg = null },
            title = { Text("Run") },
            text = { Text(runMsg!!) },
            confirmButton = { TextButton(onClick = { runMsg = null }) { Text("OK") } }
        )
    }
    if (!refactorRecoveryScanComplete || pendingRefactorRecoveries.isNotEmpty()) {
        IdeAlertDialog(
            onDismissRequest = {},
            properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = false, dismissOnClickOutside = false),
            title = { Text(if (refactorRecoveryScanComplete) "Interrupted refactor detected" else "Checking project recovery") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    if (!refactorRecoveryScanComplete) {
                        Text("Checking whether a previous workspace refactor was interrupted…")
                    } else {
                        Text(
                            "PySpace found ${pendingRefactorRecoveries.size} unfinished workspace refactor transaction(s) " +
                                "affecting ${pendingRefactorRecoveries.sumOf { it.fileCount }} file(s). No recovery action has been performed."
                        )
                        Text("Choose whether to complete the refactor or restore the project files to their previous contents.")
                        Text("Your choice is required before continuing to edit this project.", color = Color(IdeTheme.DIM), fontSize = 12.sp)
                    }
                    if (refactorRecoveryBusy) {
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                        Text("Verifying files and recovering transaction…", fontSize = 12.sp, color = Color(IdeTheme.DIM))
                    }
                    refactorRecoveryError?.let {
                        Text(it, color = Color(IdeTheme.ERROR), fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(enabled = refactorRecoveryScanComplete && !refactorRecoveryBusy, onClick = {
                    refactorRecoveryBusy = true
                    refactorRecoveryError = null
                    scope.launch {
                        val result = runCatching {
                            withContext(Dispatchers.IO) {
                                pendingRefactorRecoveries.forEach { pending ->
                                    WorkspaceRefactorTransaction.complete(session.project.dir, pending.directory)
                                }
                            }
                        }
                        refactorRecoveryBusy = false
                        if (result.isSuccess) {
                            pendingRefactorRecoveries = emptyList()
                            session.treeContentVersion++
                        } else {
                            refactorRecoveryError = "Could not complete recovery: ${result.exceptionOrNull()?.message ?: "unknown error"}. Your recovery data has been retained."
                            pendingRefactorRecoveries = withContext(Dispatchers.IO) { WorkspaceRefactorTransaction.pending(session.project.dir) }
                        }
                    }
                }) { Text("Complete Refactor") }
            },
            dismissButton = {
                Row {
                    TextButton(enabled = refactorRecoveryScanComplete && !refactorRecoveryBusy, onClick = { onExitProject() }) { Text("Exit Project") }
                    TextButton(enabled = refactorRecoveryScanComplete && !refactorRecoveryBusy, onClick = {
                        refactorRecoveryBusy = true
                        refactorRecoveryError = null
                        scope.launch {
                            val result = runCatching {
                                withContext(Dispatchers.IO) {
                                    pendingRefactorRecoveries.asReversed().forEach { pending ->
                                        WorkspaceRefactorTransaction.rollback(session.project.dir, pending.directory)
                                    }
                                }
                            }
                            refactorRecoveryBusy = false
                            if (result.isSuccess) {
                                pendingRefactorRecoveries = emptyList()
                                session.treeContentVersion++
                            } else {
                                refactorRecoveryError = "Could not restore all original files: ${result.exceptionOrNull()?.message ?: "unknown error"}. Recovery data has been retained."
                                pendingRefactorRecoveries = withContext(Dispatchers.IO) { WorkspaceRefactorTransaction.pending(session.project.dir) }
                            }
                        }
                    }) { Text("Restore Previous State", color = Color(IdeTheme.ERROR)) }
                }
            }
        )
    }
    }
    EditorIndexDetailsDialog(
        visible = showIndexDetails,
        onDismiss = { showIndexDetails = false },
        projectName = session.project.name,
        indexState = indexState,
        indexMonitor = indexMonitor,
        environmentIndexState = environmentIndexState,
        environmentIndexMonitor = environmentIndexMonitor,
        indexPanelTab = indexPanelTab,
        onSelectedTabChange = { indexPanelTab = it },
        environmentPackageFilter = environmentPackageFilter,
        onPackageFilterChange = { environmentPackageFilter = it }
    )
}
