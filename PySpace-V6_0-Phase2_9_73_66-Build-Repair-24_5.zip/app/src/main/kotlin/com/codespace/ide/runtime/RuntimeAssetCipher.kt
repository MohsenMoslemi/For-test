package com.codespace.ide.runtime

import android.content.Context
import java.io.IOException
import java.io.InputStream
import java.nio.ByteBuffer
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import com.codespace.ide.PtyNative

/**
 * Reads the encrypted runtime assets (format "PSR1", see tools/encrypt_runtime_asset.py).
 *
 * The packages inside the APK are AES-256-GCM encrypted in 256 KiB chunks, so they are useless when
 * copied out of the app. Decryption is streamed: nothing is ever written to disk in clear form except
 * the extracted runtime inside the app's private storage. GCM also authenticates every chunk and the
 * end of the stream, so a modified or truncated package fails instead of being half-installed.
 *
 * The AES key itself is derived natively (native/key_bridge.c, libkeybridge.so): the split master-key
 * bytes and the SHA-256 combination step never exist as readable Kotlin/Java bytecode, unlike a plain
 * Kotlin constant, which any decompiler (jadx, JEB) recovers instantly. This raises the bar to
 * disassembling arm64 machine code; it does not make the key unrecoverable by a determined attacker.
 * R8 also strips/obfuscates this class in release builds (this class and PtyNative are kept named,
 * via proguard-rules.pro, only because their native libraries bind to them by exact name).
 */
object RuntimeAssetCipher {
    private val MAGIC = byteArrayOf(0x50, 0x53, 0x52, 0x31) // "PSR1"
    private const val HEADER_SIZE = 12
    private const val TAG_SIZE = 16

    init {
        try {
            System.loadLibrary("keybridge")
        } catch (t: UnsatisfiedLinkError) {
            throw UnsatisfiedLinkError(
                "libkeybridge.so is missing. Build it once: native/build_keybridge.sh in Termux " +
                    "(see RUNTIME-ENCRYPTION.md). ${t.message}"
            )
        }
    }

    /** Implemented in native/key_bridge.c; returns the 32-byte AES-256 key. */
    @JvmStatic
    private external fun nativeDeriveKey(): ByteArray

    /** Opens an encrypted asset and returns its decrypted contents as a stream. */
    fun openAsset(context: Context, assetName: String): InputStream =
        decrypt(context.assets.open(assetName))

    /** Wraps an encrypted stream; closing the result closes [source]. */
    fun decrypt(source: InputStream): InputStream = DecryptingStream(source, deriveKey())

    private fun deriveKey(): SecretKeySpec {
        val key = nativeDeriveKey()
        require(key.size == 32) { "Invalid native key material" }
        val spec = SecretKeySpec(key, "AES")
        key.fill(0)
        return spec
    }

    private fun readFully(input: InputStream, buffer: ByteArray): Int {
        var total = 0
        while (total < buffer.size) {
            val n = input.read(buffer, total, buffer.size - total)
            if (n < 0) break
            total += n
        }
        return total
    }

    private class DecryptingStream(
        private val source: InputStream,
        private val key: SecretKeySpec
    ) : InputStream() {
        private val header = ByteArray(HEADER_SIZE)
        private var current = ByteArray(0)
        private var next = ByteArray(0)
        private var currentLen = 0
        private var plain = ByteArray(0)
        private var plainPos = 0
        private var counter = 0L
        private var started = false
        private var finished = false

        private fun start() {
            started = true
            if (readFully(source, header) != HEADER_SIZE ||
                !header.copyOfRange(0, 4).contentEquals(MAGIC)
            ) {
                throw IOException("Invalid runtime package")
            }
            val chunkSize = ByteBuffer.wrap(header, 8, 4).int
            if (chunkSize < 4096 || chunkSize > (4 shl 20)) throw IOException("Invalid runtime package")
            current = ByteArray(chunkSize + TAG_SIZE)
            next = ByteArray(chunkSize + TAG_SIZE)
            currentLen = readFully(source, current)
        }

        /** Decrypts the next chunk into [plain]. Returns false once the stream is exhausted. */
        private fun fill(): Boolean {
            if (finished) return false
            if (!started) start()
            if (currentLen < TAG_SIZE) throw IOException("Runtime package is truncated")
            val nextLen = if (currentLen == current.size) readFully(source, next) else 0
            val last = nextLen == 0
            val nonce = ByteArray(12)
            System.arraycopy(header, 4, nonce, 0, 4)
            ByteBuffer.wrap(nonce, 4, 8).putLong(counter)
            try {
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, nonce))
                cipher.updateAAD(header)
                cipher.updateAAD(byteArrayOf(if (last) 1 else 0))
                plain = cipher.doFinal(current, 0, currentLen)
            } catch (e: java.security.GeneralSecurityException) {
                throw IOException("Runtime package failed verification", e)
            }
            plainPos = 0
            if (last) {
                finished = true
            } else {
                val swap = current
                current = next
                next = swap
                currentLen = nextLen
                counter++
            }
            return true
        }

        override fun read(): Int {
            val one = ByteArray(1)
            val n = read(one, 0, 1)
            return if (n < 0) -1 else one[0].toInt() and 0xFF
        }

        override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
            if (length == 0) return 0
            while (plainPos >= plain.size) {
                if (!fill()) return -1
            }
            val n = minOf(length, plain.size - plainPos)
            System.arraycopy(plain, plainPos, buffer, offset, n)
            plainPos += n
            return n
        }

        override fun available(): Int = plain.size - plainPos

        override fun close() {
            source.close()
        }
    }
}
