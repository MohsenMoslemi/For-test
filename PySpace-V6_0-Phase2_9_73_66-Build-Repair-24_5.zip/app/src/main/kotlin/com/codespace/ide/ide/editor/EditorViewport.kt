package com.codespace.ide.ide.editor

import androidx.compose.animation.core.AnimationState
import androidx.compose.animation.core.DecayAnimationSpec
import androidx.compose.animation.core.animateDecay
import androidx.compose.animation.core.exponentialDecay
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.relocation.BringIntoViewResponder
import androidx.compose.foundation.relocation.bringIntoViewResponder
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollDispatcher
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.drawText
import androidx.compose.ui.unit.Velocity
import kotlin.math.abs
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Swallows the text field's own "bring the caret into view" requests, which
 * otherwise fling the horizontal scroller to the end of the line when a word
 * is tapped. The request is replaced by a rectangle that is already visible
 * ([viewportOrigin] = top-left of the viewport in this node's coordinates),
 * so the scroll containers above do nothing. Caret visibility is handled by
 * PyEditor.pinCaretToView instead.
 */
/** Where a pinch ended, so the scroll position can follow the new font size. */
internal class ZoomAnchor {
    var pending = false
    /** Scroll offsets (px) that keep the anchored spot under the fingers in the NEW layout. */
    var targetX = 0f
    var targetY = 0f
    /** Bumped on every commit so a late effect never clears a newer commit's state. */
    var token = 0
    /** True from the finger lift until the font size has been committed (settle animation). */
    var settling = false
    var job: Job? = null
    /** Word-wrap live zoom: the font is committed on every pinch step, the text reflows. */
    var wrapLive = false
    var wrapValid = false
    /** Display offset of the visual line at the viewport top when the pinch began, and the
     *  fraction of that line already scrolled past, so the same text stays at the top. */
    var wrapOffset = 0
    var wrapFrac = 0f
    var wrapToken = 0
}

@OptIn(ExperimentalFoundationApi::class)
internal fun Modifier.holdViewportOnBringIntoView(viewportOrigin: () -> Offset): Modifier =
    bringIntoViewResponder(object : BringIntoViewResponder {
        override fun calculateRectForParent(localRect: Rect): Rect {
            val o = viewportOrigin()
            return Rect(o.x + 1f, o.y + 1f, o.x + 2f, o.y + 2f)
        }

        override suspend fun bringChildIntoView(localRect: () -> Rect?) {
            // Intentionally empty.
        }
    })

/**
 * Free two-axis touch pan: ONE finger moves both scroll states at once, so
 * circling the finger circles the content. Single-finger only (a second
 * finger aborts the pan so pinch-zoom keeps working); nothing is consumed
 * before touch slop, so taps, long-press selection and the caret behave as
 * before; a pointer a child already consumed (selection drag) is left alone.
 *
 * It talks to the tree drawer through a NestedScrollDispatcher exactly like
 * a native scrollable: scroll the content could not use (and the release
 * fling) is offered to the parent, only for horizontal-dominant strokes, so
 * "scroll to the start first, then the tree opens" keeps working and a
 * diagonal read-down never drags the drawer.
 */
@Composable
internal fun Modifier.twoAxisPan(
    vScroll: ScrollState,
    hScroll: ScrollState,
    enabled: Boolean
): Modifier {
    if (!enabled) return this
    val scope = rememberCoroutineScope()
    val dispatcher = remember { NestedScrollDispatcher() }
    val passive = remember { object : NestedScrollConnection {} }
    val flings = remember { arrayOfNulls<Job>(2) }
    return this
    .nestedScroll(passive, dispatcher)
    .pointerInput(vScroll, hScroll) {
        val slop = viewConfiguration.touchSlop
        val decay = exponentialDecay<Float>(
            frictionMultiplier = 1.2f,
            absVelocityThreshold = 40f
        )
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            // A touch stops a fling in progress (like any scroller).
            flings[0]?.cancel()
            flings[1]?.cancel()
            val tracker = VelocityTracker()
            tracker.addPosition(down.uptimeMillis, down.position)
            var pan = Offset.Zero
            var total = Offset.Zero
            var started = false
            var lifted = false
            while (true) {
                val event = awaitPointerEvent()
                if (event.changes.count { it.pressed } > 1) break
                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                if (!change.pressed) {
                    tracker.addPosition(change.uptimeMillis, change.position)
                    lifted = true
                    break
                }
                if (change.isConsumed) break
                val delta = change.positionChange()
                tracker.addPosition(change.uptimeMillis, change.position)
                total += delta
                var d = delta
                if (!started) {
                    pan += delta
                    val dist = pan.getDistance()
                    if (dist <= slop) continue
                    started = true
                    // Only the part past the slop moves the content.
                    d = pan * ((dist - slop) / dist)
                }
                change.consume()
                if (d == Offset.Zero) continue
                val pre = dispatcher.dispatchPreScroll(d, NestedScrollSource.UserInput)
                val rem = d - pre
                // dispatchRawDelta works in scroll space (finger up =
                // positive); what the content consumed, in finger space:
                val consumed = Offset(
                    -hScroll.dispatchRawDelta(-rem.x),
                    -vScroll.dispatchRawDelta(-rem.y)
                )
                var left = rem - consumed
                // A mostly-vertical stroke never offers sideways leftover
                // to the drawer.
                if (abs(total.x) <= abs(total.y)) left = Offset(0f, left.y)
                dispatcher.dispatchPostScroll(
                    consumed + pre,
                    left,
                    NestedScrollSource.UserInput
                )
            }
            if (started && lifted) {
                val v = tracker.calculateVelocity()
                val vx = v.x
                val vy = v.y
                scope.launch {
                    // Offer the release to the drawer first: a drawer the
                    // finger left mid-travel takes it and settles itself.
                    val left = dispatcher.dispatchPostFling(
                        Velocity.Zero,
                        Velocity(vx, vy)
                    )
                    if (left.x != 0f || left.y != 0f) {
                        flings[0] = launch { flingAxis(hScroll, vx, decay) }
                        flings[1] = launch { flingAxis(vScroll, vy, decay) }
                    }
                }
            }
        }
    }
}

/** Momentum for one axis; [velocity] is finger velocity (px/s). */
internal suspend fun flingAxis(
    state: ScrollState,
    velocity: Float,
    decay: DecayAnimationSpec<Float>
) {
    if (abs(velocity) < 50f) return
    var last = 0f
    AnimationState(initialValue = 0f, initialVelocity = -velocity).animateDecay(decay) {
        val delta = value - last
        last = value
        val consumed = state.dispatchRawDelta(delta)
        // Hit the edge: stop instead of grinding against it.
        if (abs(delta - consumed) > 0.5f) cancelAnimation()
    }
}

/** Draws [layout] at ([left], [top]); when [k] != 1 it is scaled by [k] about [pivot]. */
internal fun DrawScope.drawScaledLayout(layout: TextLayoutResult, left: Float, top: Float, k: Float, pivot: Offset) {
    if (k == 1f) {
        drawText(layout, topLeft = Offset(left, top))
    } else {
        withTransform({ scale(k, k, pivot) }) {
            drawText(layout, topLeft = Offset(left, top))
        }
    }
}
