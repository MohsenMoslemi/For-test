package com.codespace.ide.ide.editor

import com.codespace.ide.ide.PythonImportManager
import com.codespace.ide.ide.codeintel.PythonCompletionItem

/** Result of accepting one completion; the caller commits it as a single editor edit. */
internal data class EditorCompletionEdit(
    val text: String,
    val caret: Int
)

/**
 * Builds the text/caret result for an accepted completion without touching Compose state.
 * Import insertion and callable-parenthesis rules live here so the UI only commits the edit.
 */
internal object EditorCompletionApplier {
    fun apply(
        source: String,
        replaceStart: Int,
        replaceEnd: Int,
        item: PythonCompletionItem
    ): EditorCompletionEdit {
        val start = replaceStart.coerceIn(0, source.length)
        val end = replaceEnd.coerceIn(start, source.length)
        val nextChar = source.getOrNull(end)
        val baseInsertion = item.insertText.ifBlank { item.name }
        // Auto Import rows are import actions, never function-call requests.
        val isAutoImport = !item.autoImportStatement.isNullOrBlank()
        // A callable inside a decorator is a symbol reference, not an invocation.
        val lineStart = if (start == 0) 0 else source.lastIndexOf('\n', start - 1) + 1
        val linePrefix = source.substring(lineStart, start).trimStart()
        val isDecoratorExpression = linePrefix.startsWith("@")
        // Imported names are references, not calls (e.g. `from x import ad`).
        val isImportStatement = linePrefix.startsWith("import ") || linePrefix == "import" ||
            linePrefix.startsWith("from ") || linePrefix == "from"
        val alreadyHasCall = baseInsertion.endsWith("(") || baseInsertion.endsWith("()")
        val actualSuffix = if (
            !isAutoImport && !isImportStatement && !isDecoratorExpression &&
            item.callable && !alreadyHasCall && nextChar != '('
        ) "()" else ""
        val insertion = baseInsertion + actualSuffix
        val updated = source.substring(0, start) + insertion + source.substring(end)
        val caretInsideCall = !isAutoImport &&
            (actualSuffix.isNotEmpty() || (item.callable && baseInsertion.endsWith("()")))
        var caret = start + insertion.length - if (caretInsideCall) 1 else 0
        var finalText = updated
        val importStatement = item.autoImportStatement
        if (!importStatement.isNullOrBlank()) {
            // Recompute against the edited buffer; the old cached offset may be stale.
            val inserted = PythonImportManager.insert(finalText, importStatement)
            finalText = inserted.first
            caret = (caret + inserted.second).coerceIn(0, finalText.length)
        }
        return EditorCompletionEdit(finalText, caret.coerceIn(0, finalText.length))
    }
}
