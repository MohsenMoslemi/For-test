package com.codespace.ide.domain.editor.contract

import com.codespace.ide.domain.editor.model.EditorSessionSnapshot

/** Persistence boundary for an immutable editor-session snapshot. */
interface EditorSessionSerializer {
    fun serialize(snapshot: EditorSessionSnapshot): String
}
