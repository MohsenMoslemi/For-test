package com.codespace.ide.ide.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.codespace.ide.ide.PythonRuntimeCatalog
import com.codespace.ide.ide.projects.ProjectsViewModel
import com.codespace.ide.ide.projects.PyProject
import com.codespace.ide.ide.projects.RuntimeInstallUiState
import com.codespace.ide.ide.settings.IdePrefs
import com.codespace.ide.ide.theme.IdeTheme

@Composable
internal fun NewProjectPage(
    workspace: File,
    existingProjects: List<PyProject>,
    mutationBusy: Boolean,
    mutationError: String?,
    mutationProgress: String?,
    mutationProgressFraction: Float?,
    runtimeInstallStates: Map<String, com.codespace.ide.ide.projects.RuntimeInstallUiState>,
    viewModel: ProjectsViewModel,
    modifier: Modifier = Modifier,
    onCancel: () -> Unit,
    onCreated: () -> Unit
) {
    var projectName by remember { mutableStateOf("") }
    var venvName by remember { mutableStateOf("venv") }
    var buildVenv by remember { mutableStateOf(true) }
    var selectedPythonVersion by remember { mutableStateOf(PythonRuntimeCatalog.DEFAULT_ID) }
    var pythonVersionMenuExpanded by remember { mutableStateOf(false) }
    val selectedRuntime = PythonRuntimeCatalog.require(selectedPythonVersion)
    var cloneFromGit by remember { mutableStateOf(false) }
    var repositoryUrl by remember { mutableStateOf("") }
    var repositoryBranch by remember { mutableStateOf("") }
    var cloneBusy by remember { mutableStateOf(false) }
    var cloneError by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current.applicationContext
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { viewModel.refreshPythonRuntimeStates() }
    val safeName = projectName.trim()
        .replace(Regex("[^A-Za-z0-9_.-]"), "_")
        .trim('_', '.', '-')
    val safeVenv = venvName.trim()
        .replace(Regex("[^A-Za-z0-9_.-]"), "_")
        .trim('_', '.', '-')
        .ifBlank { ".venv" }
    val duplicate = existingProjects.any { it.name.equals(safeName, ignoreCase = true) }
    val valid = safeName.isNotBlank() && safeName !in setOf(".", "..") && !duplicate

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.CARD))
        ) {
            Column(Modifier.fillMaxWidth().padding(20.dp)) {
                Box(
                    Modifier.size(54.dp).clip(RoundedCornerShape(16.dp))
                        .background(Color(IdeTheme.ACCENT).copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) { Text("＋", color = Color(IdeTheme.ACCENT), fontSize = 30.sp, fontWeight = FontWeight.Light) }
                Spacer(Modifier.height(14.dp))
                Text("A fresh space for your ideas", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Create an isolated Python project with its own files and optional virtual environment.",
                    color = Color(IdeTheme.DIM), fontSize = 13.sp, lineHeight = 19.sp
                )
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.PANEL))
        ) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("PROJECT DETAILS", color = Color(IdeTheme.ACCENT), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = projectName,
                    onValueChange = { projectName = it; viewModel.clearMutationError() },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !mutationBusy && !cloneBusy,
                    singleLine = true,
                    label = { Text("Project name") },
                    placeholder = { Text("e.g. DataAnalysis") },
                    supportingText = {
                        Text(
                            when {
                                projectName.isBlank() -> "Use letters, numbers, dots, dashes or underscores."
                                duplicate -> "A project with this name already exists."
                                else -> "Folder name: $safeName"
                            },
                            color = if (duplicate) Color(IdeTheme.ERROR) else Color(IdeTheme.DIM)
                        )
                    }
                )
                OutlinedTextField(
                    value = venvName,
                    onValueChange = { venvName = it },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !mutationBusy && !cloneBusy,
                    singleLine = true,
                    label = { Text("Virtual environment folder") },
                    placeholder = { Text("venv") },
                    supportingText = { Text("Folder name: $safeVenv", color = Color(IdeTheme.DIM)) }
                )
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(Color(IdeTheme.BG)).padding(14.dp)
                ) {
                    Text("PROJECT LOCATION", color = Color(IdeTheme.DIM), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text(
                        if (safeName.isBlank()) workspace.absolutePath else File(workspace, safeName).absolutePath,
                        color = Color(IdeTheme.TEXT), fontSize = 12.sp
                    )
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.PANEL))
        ) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("CLONE FROM GIT", color = Color(IdeTheme.ACCENT), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(3.dp))
                        Text("Download a branch from an existing GitHub repository", color = Color(IdeTheme.DIM), fontSize = 11.sp)
                    }
                    Switch(checked = cloneFromGit, onCheckedChange = { cloneFromGit = it; cloneError = null }, enabled = !mutationBusy && !cloneBusy)
                }
                if (cloneFromGit) {
                    OutlinedTextField(
                        value = repositoryUrl,
                        onValueChange = { value ->
                            repositoryUrl = value
                            cloneError = null
                            if (projectName.isBlank()) projectName = value.trimEnd('/').substringAfterLast('/').substringBefore('?').substringBefore('#').removeSuffix(".git")
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !cloneBusy,
                        singleLine = true,
                        label = { Text("GitHub repository URL") },
                        placeholder = { Text("https://github.com/owner/repository") }
                    )
                    OutlinedTextField(
                        value = repositoryBranch,
                        onValueChange = { repositoryBranch = it; cloneError = null },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !cloneBusy,
                        singleLine = true,
                        label = { Text("Branch (optional)") },
                        placeholder = { Text("Default branch") },
                        supportingText = { Text("Leave empty to clone the repository's default branch.", color = Color(IdeTheme.DIM), fontSize = 10.sp) }
                    )
                    Text(
                        if (IdePrefs(context).githubToken.isBlank()) "Public repositories can be cloned without signing in. Connect an account in Settings → GitHub to access private repositories. This imports source files, not local Git history."
                        else "Uses the GitHub account saved in app Settings. Private repositories require Contents: read permission. This imports source files, not local Git history.",
                        color = Color(IdeTheme.DIM), fontSize = 10.sp, lineHeight = 15.sp
                    )
                    cloneError?.let { Text(it, color = Color(IdeTheme.ERROR), fontSize = 11.sp, lineHeight = 16.sp) }
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.PANEL))
        ) {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                Text("PYTHON ENVIRONMENT", color = Color(IdeTheme.ACCENT), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Python version", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Box(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .background(Color(IdeTheme.BG)).clickable(enabled = !mutationBusy) { pythonVersionMenuExpanded = true }
                            .padding(horizontal = 13.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(selectedRuntime.title, color = Color(IdeTheme.TEXT), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(3.dp))
                            Text(selectedRuntime.description, color = Color(IdeTheme.DIM), fontSize = 11.sp)
                        }
                        Text("⌄", color = Color(IdeTheme.ACCENT), fontSize = 20.sp)
                    }
                    DropdownMenu(
                        expanded = pythonVersionMenuExpanded,
                        onDismissRequest = { pythonVersionMenuExpanded = false },
                        modifier = Modifier.width((androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp - 68).coerceAtLeast(240).dp)
                            .background(Color(IdeTheme.PANEL))
                    ) {
                        PythonRuntimeCatalog.options.forEach { option ->
                            val installState = runtimeInstallStates[option.id]
                            val isInstalled = option.isBundled || installState?.status == "installed"
                            val isInstalling = installState?.status == "preparing" || installState?.status == "downloading" || installState?.status == "installing"
                            DropdownMenuItem(
                                enabled = !mutationBusy,
                                text = {
                                    Column(Modifier.fillMaxWidth()) {
                                        Text(option.title, color = Color(IdeTheme.TEXT), fontWeight = FontWeight.SemiBold)
                                        Text(option.description, color = Color(IdeTheme.DIM), fontSize = 10.sp)
                                        if (isInstalling) {
                                            Spacer(Modifier.height(5.dp))
                                            Text(installState?.message ?: "Installing…", color = Color(IdeTheme.ACCENT), fontSize = 10.sp)
                                            installState?.fraction?.let { LinearProgressIndicator(progress = { it }, modifier = Modifier.fillMaxWidth()) }
                                        }
                                        installState?.error?.let { Text(it, color = Color(IdeTheme.ERROR), fontSize = 10.sp, maxLines = 2) }
                                    }
                                },
                                trailingIcon = {
                                    when {
                                        isInstalled -> Text("Installed", color = Color(IdeTheme.DIM), fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                        isInstalling -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            if (installState?.status == "downloading" || installState?.status == "preparing") {
                                                TextButton(onClick = { viewModel.cancelPythonRuntimeDownload(option.id) }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 0.dp)) { Text("Cancel", color = Color(IdeTheme.ERROR), fontSize = 11.sp) }
                                            } else {
                                                Text("Installing…", color = Color(IdeTheme.ACCENT), fontSize = 9.sp)
                                                CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                                            }
                                        }
                                        else -> TextButton(
                                            enabled = !mutationBusy,
                                            onClick = { viewModel.installPythonRuntime(option.id) },
                                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) { Text("Install", fontSize = 12.sp) }
                                    }
                                },
                                onClick = {
                                    selectedPythonVersion = option.id
                                    pythonVersionMenuExpanded = false
                                }
                            )
                        }
                    }
                }
                Text(
                    if (selectedRuntime.isBundled) "Already included · no extra download required."
                    else "First use downloads the ARM64 runtime once (approximately 25–35 MB). An internet connection is required only for the first installation.",
                    color = Color(IdeTheme.DIM), fontSize = 11.sp, lineHeight = 16.sp
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Build virtual environment now", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Spacer(Modifier.height(3.dp))
                        Text("Uses the selected Python version · recommended", color = Color(IdeTheme.DIM), fontSize = 11.sp)
                    }
                    Switch(checked = buildVenv, onCheckedChange = { buildVenv = it }, enabled = !mutationBusy)
                }
                if (buildVenv) {
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("✓", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Spacer(Modifier.width(8.dp))
                        Text("The project will be ready for isolated package installs.", color = Color(IdeTheme.DIM), fontSize = 11.sp)
                    }
                } else {
                    Text("You can build it later from the project menu or Terminal panel.", color = Color(IdeTheme.DIM), fontSize = 11.sp)
                }
            }
        }

        if (mutationBusy && !mutationProgress.isNullOrBlank()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.PANEL))
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Color(IdeTheme.ACCENT))
                    Column(Modifier.weight(1f)) {
                        Text("Preparing your Python environment", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Spacer(Modifier.height(3.dp))
                        Text(mutationProgress, color = Color(IdeTheme.DIM), fontSize = 11.sp, lineHeight = 16.sp)
                    }
                    mutationProgressFraction?.let {
                        Text("${(it * 100f).toInt()}%", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
        if (mutationError != null) {
            Text(mutationError, color = Color(IdeTheme.ERROR), fontSize = 12.sp)
        }
        Spacer(Modifier.height(2.dp))
        Button(
            onClick = {
                if (!cloneFromGit) {
                    viewModel.createProject(safeName, safeVenv, buildVenv, selectedPythonVersion) { onCreated() }
                } else {
                    val prefs = IdePrefs(context)
                    val token = prefs.githubToken
                    if (token.isNotBlank() && prefs.githubTokenExpiresAt > 0L && prefs.githubTokenExpiresAt <= System.currentTimeMillis()) {
                        cloneError = "The saved GitHub token has expired. Update it in Settings → GitHub."
                    } else if (repositoryUrl.isBlank()) {
                        cloneError = "Enter a GitHub repository URL."
                    } else {
                        cloneBusy = true
                        cloneError = null
                        scope.launch {
                            val destination = File(workspace, safeName)
                            val result = withContext(Dispatchers.IO) {
                                cloneGitHubRepository(token, repositoryUrl, repositoryBranch, destination, context.cacheDir)
                            }
                            cloneBusy = false
                            if (result.startsWith("Cloned")) {
                                try {
                                    withContext(Dispatchers.IO) {
                                        File(destination, ".pyspace_venv").writeText(safeVenv)
                                        File(destination, ".pyspace_python_version").writeText(selectedPythonVersion)
                                        File(destination, ".pyspace_python_path").writeText(selectedRuntime.guestExecutable)
                                        val ignore = File(destination, ".gitignore")
                                        if (!ignore.exists()) ignore.writeText(defaultPythonGitIgnore())
                                    }
                                    val clonedProject = PyProject(safeName, destination)
                                    if (buildVenv) {
                                        viewModel.buildVirtualEnv(clonedProject) { onCreated() }
                                    } else {
                                        viewModel.refresh()
                                        onCreated()
                                    }
                                } catch (error: Exception) {
                                    cloneError = "Repository was cloned, but project setup failed: ${error.message ?: "unknown error"}"
                                    viewModel.refresh()
                                }
                            } else {
                                cloneError = result
                            }
                        }
                    }
                }
            },
            enabled = valid && !mutationBusy && !cloneBusy && (!cloneFromGit || repositoryUrl.isNotBlank()),
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(15.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(IdeTheme.ACCENT),
                contentColor = Color(IdeTheme.ON_ACCENT),
                disabledContainerColor = Color(IdeTheme.LINE)
            )
        ) {
            if (mutationBusy || cloneBusy) {
                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color(IdeTheme.ON_ACCENT))
                Spacer(Modifier.width(10.dp))
                Text(if (cloneBusy) "Cloning repository…" else "Preparing project…", fontWeight = FontWeight.Bold)
            } else {
                Text(if (cloneFromGit) "Clone project" else "Create project", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
        TextButton(onClick = onCancel, modifier = Modifier.fillMaxWidth(), enabled = !mutationBusy && !cloneBusy) {
            Text("Cancel", color = Color(IdeTheme.DIM))
        }
        Spacer(Modifier.height(12.dp))
    }
}
