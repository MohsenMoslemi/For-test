package com.codespace.ide.ide.editor

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File
import com.codespace.ide.ide.codeintel.PythonDefinitionLocation
import com.codespace.ide.ide.codeintel.PythonHoverDoc
import com.codespace.ide.ide.codeintel.PythonLspController

/**
 * Owns the asynchronous hover/documentation lifecycle for one editor tab.
 * The editor remains the owner of its live document and Compose layout state;
 * this workflow only resolves a tap against the supplied snapshot and publishes
 * the resulting information-card state.
 */
class EditorHoverDocumentationWorkflow(
    private val scope: CoroutineScope
) {
    var documentation by mutableStateOf<PythonHoverDoc?>(null)
        private set
    var definition by mutableStateOf<PythonDefinitionLocation?>(null)
        private set
    var anchorInField by mutableStateOf<Offset?>(null)
        private set
    var anchorOffset by mutableStateOf<Int?>(null)
        private set
    var expanded by mutableStateOf(false)
        private set

    private var job: Job? = null
    val activeJob: Job? get() = job

    fun dismissAnchor() {
        job?.cancel()
        anchorInField = null
    }

    fun clearPresentation() {
        job?.cancel()
        documentation = null
        definition = null
        anchorInField = null
        expanded = false
    }

    fun close() = clearPresentation()

    fun expand() {
        if (documentation != null || definition != null) expanded = true
    }

    fun clearForNavigation() {
        clearPresentation()
    }

    fun show(
        enabled: Boolean,
        isPythonLanguage: Boolean,
        file: File,
        source: String,
        currentSource: () -> String,
        pressPosition: Offset,
        fieldCoordinates: LayoutCoordinates?,
        gestureCoordinates: LayoutCoordinates?,
        layout: TextLayoutResult?,
        displayText: String,
        foldedDocument: FoldedEditorDocument,
        controller: PythonLspController?,
        density: Density
    ): Boolean {
        if (!enabled || !isPythonLanguage) return false
        clearPresentation()
        if (!file.name.endsWith(".py", ignoreCase = true)) return false
        val fieldCoords = fieldCoordinates ?: return false
        val gestureCoords = gestureCoordinates ?: return false
        val textLayout = layout ?: return false
        if (!sameDisplay(textLayout.layoutInput.text.text, displayText) || source.isBlank()) return false

        val hit = EditorHoverPosition.resolve(
            pressPosition = pressPosition,
            fieldCoordinates = fieldCoords,
            gestureCoordinates = gestureCoords,
            layout = textLayout,
            displayTextLength = displayText.length,
            textPaddingPx = with(density) { 8.dp.toPx() },
            lineRightSlopPx = with(density) { 4.dp.toPx() }
        ) ?: return false
        val sourceOffset = foldedDocument.toSourceOffset(hit.displayOffset)
        val target = EditorHoverTargetResolver.resolve(source, sourceOffset) ?: return false
        val offlineDocumentation = EditorHoverResolver.offlineDocumentation(source, target, controller)
        if (controller == null && offlineDocumentation == null) return false

        // Publish the local documentation immediately. Previously the bubble and
        // its anchor waited for definition lookup to finish as well; a slow or
        // failed LSP definition request could therefore make a valid info affordance
        // appear late or not at all.
        anchorInField = hit.fieldPosition
        anchorOffset = sourceOffset
        documentation = offlineDocumentation
        definition = null
        expanded = false

        job = scope.launch {
            if (currentSource() != source) return@launch
            val result = runCatching {
                EditorHoverResolver.resolve(file, source, target, controller, offlineDocumentation)
            }.getOrNull() ?: return@launch
            if (currentSource() != source) return@launch
            // Keep the immediate local result if the asynchronous provider has no
            // additional documentation; publish definition independently of UI timing.
            documentation = result.documentation ?: documentation
            definition = result.definition
        }
        return true
    }
}
