package com.codespace.ide.ide.filetree

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ide.editor.EditorSession
import com.codespace.ide.ide.terminal.TermBridge
import com.codespace.ide.ide.theme.IdeTheme

@Composable
internal fun GitSheet(session: EditorSession, bridge: TermBridge, onDismiss: () -> Unit) {
    var msg by remember { mutableStateOf("") }
    var cloneUrl by remember { mutableStateOf("") }
    val dir = session.project.dir.name
    fun g(cmd: String) {
        bridge.run("cd " + guestProjectPath(session.project) + " && $cmd")
    }
    IdeAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Git — ${session.project.name}", fontSize = 15.sp) },
        text = {
            Column(Modifier.fillMaxWidth()) {
                GitButton("Status") { g("git status") }
                GitButton("Log (last 10)") { g("git log --oneline -15") }
                GitButton("Init repo here") { g("git init && git status") }
                OutlinedTextField(
                    value = msg, onValueChange = { msg = it },
                    label = { Text("commit message") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                )
                GitButton("Add all + commit", enabled = msg.isNotBlank()) {
                    g("git add -A && git commit -m \"${msg.replace("\"", "'")}\"")
                    msg = ""
                }
                GitButton("Pull") { g("git pull") }
                GitButton("Push") { g("git push") }
                OutlinedTextField(
                    value = cloneUrl, onValueChange = { cloneUrl = it },
                    label = { Text("clone URL (runs in project dir)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                )
                GitButton("Clone URL here", enabled = cloneUrl.isNotBlank()) { g("git clone $cloneUrl") }
                Text(
                    "Output appears in the terminal panel.",
                    color = Color(IdeTheme.DIM), fontSize = 11.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
internal fun GitButton(label: String, enabled: Boolean = true, onClick: () -> Unit) {
    TextButton(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
        Text(label, fontSize = 13.sp, modifier = Modifier.fillMaxWidth())
    }
}
