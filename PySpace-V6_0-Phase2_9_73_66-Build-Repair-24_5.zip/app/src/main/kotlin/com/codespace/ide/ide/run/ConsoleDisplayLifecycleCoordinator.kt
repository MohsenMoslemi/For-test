package com.codespace.ide.ide.run

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.codespace.ide.ide.display.FrameDisplay
import com.codespace.ide.ide.display.VncDisplay
import com.codespace.ide.ide.runtimeui.RuntimeUiViewModel

/**
 * Owns the display side-effects associated with a Console GUI run.
 *
 * The IDE shell supplies the existing display/runtime owners; this coordinator
 * does not create a second display, viewer, or generation counter. RuntimeUiViewModel
 * remains the source of truth for display-operation freshness.
 */
internal class ConsoleDisplayLifecycleCoordinator(
    private val scope: CoroutineScope,
    private val runtimeUi: RuntimeUiViewModel,
    private val displayRun: DisplayRunCoordinator,
    private val display: VncDisplay,
    private val frameDisplay: FrameDisplay,
    private val setConsoleTitle: (String) -> Unit,
) {
    /** Starts the persistent Xvnc server and attaches its viewer only if still current. */
    fun startDisplay(title: String) {
        val generation = runtimeUi.beginDisplayOperation()
        display.resetViewer()
        runtimeUi.setDisplayOpen(true)
        scope.launch {
            val result = try {
                displayRun.start(
                    shouldContinue = { runtimeUi.isCurrentDisplayOperation(generation) },
                    ensureDisplay = { display.ensureUp(connectViewer = false) },
                    connectViewer = { display.connect() },
                )
            } catch (cancel: CancellationException) {
                throw cancel
            } catch (_: Throwable) {
                DisplayStartResult.FAILED
            }
            if (result == DisplayStartResult.FAILED &&
                runtimeUi.isCurrentDisplayOperation(generation)
            ) {
                runtimeUi.setDisplayOpen(false)
                setConsoleTitle("$title — no display (see Settings › Display)")
            }
        }
    }

    /** Starts the lightweight frame viewer and opens it after the first frame arrives. */
    fun startFrameDisplay(kind: String) {
        val generation = runtimeUi.beginDisplayOperation()
        runtimeUi.setFrameMode(true)
        frameDisplay.kind = kind
        frameDisplay.start()
        scope.launch {
            var waited = 0
            while (waited < 30_000 &&
                runtimeUi.isCurrentDisplayOperation(generation) &&
                !frameDisplay.hasFrame
            ) {
                delay(100)
                waited += 100
            }
            if (runtimeUi.isCurrentDisplayOperation(generation) && frameDisplay.hasFrame) {
                runtimeUi.setDisplayOpen(true)
            }
        }
    }
}
