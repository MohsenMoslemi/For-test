package com.codespace.ide.ide.files

import java.io.File

/**
 * Detect Python virtual environments by their on-disk structure, not by a
 * conventional folder name. PEP 405 environments contain pyvenv.cfg at the
 * environment root; this also covers user-defined names such as "python-env".
 */
fun isPythonVirtualEnvironment(directory: File): Boolean {
    if (!directory.isDirectory) return false
    return try {
        val marker = File(directory, "pyvenv.cfg")
        if (marker.isFile) return true
        // Defensive fallback for environments whose marker was removed or
        // created by a non-standard tool. Require both interpreter and activate.
        val unixPython = File(directory, "bin/python")
        val unixActivate = File(directory, "bin/activate")
        val windowsPython = File(directory, "Scripts/python.exe")
        (unixPython.exists() && unixActivate.isFile) || windowsPython.isFile
    } catch (_: SecurityException) {
        false
    }
}

/** Managed/generated trees excluded from automatic recursive background work. */
fun isHiddenTreeDir(name: String): Boolean {
    if (name == ".pyspace_venv" || name == ".venv" || name == "venv" ||
        name == "__pycache__" || name == ".git" || name == ".hg" || name == ".svn" ||
        name == "node_modules" || name == ".npm" || name == ".yarn" ||
        name == ".pnpm-store" || name == ".cache" || name == ".gradle" ||
        name == ".pytest_cache" || name == ".mypy_cache" || name == ".ruff_cache" ||
        name == ".tox" || name == ".nox" || name == ".next" || name == ".turbo" ||
        name == ".dart_tool" || name == "build" || name == "dist" || name == "target") {
        return true
    }
    return name.endsWith(".egg-info")
}

/** Dynamic form used whenever the actual filesystem entry is available. */
fun isManagedTreeDirectory(directory: File): Boolean =
    isHiddenTreeDir(directory.name) || isPythonVirtualEnvironment(directory)

/** Whether an entry should be visible in the tree and file pickers. */
fun isVisibleTreeEntry(parent: File, name: String, showHidden: Boolean): Boolean {
    if (showHidden) return true
    if (name.startsWith(".")) return false
    // Hide any PEP 405 environment regardless of the name chosen by its owner.
    return !isPythonVirtualEnvironment(File(parent, name))
}

/** Compatibility overload for callers without a parent path. */
fun isVisibleTreeEntry(name: String, showHidden: Boolean): Boolean =
    showHidden || !name.startsWith(".") &&
        name.lowercase() !in setOf("venv", "env", ".venv", ".env")

fun deleteRecursivelySafe(f: File): Boolean {
    return try {
        f.deleteRecursively()
    } catch (_: Exception) {
        false
    }
}

fun renameFile(f: File, rawName: String): File? {
    val name = rawName.trim()
    if (name.isEmpty() || name.contains('/')) return null
    return try {
        val to = File(f.parentFile, name)
        if (to.exists()) return null
        if (f.renameTo(to)) to else null
    } catch (_: Exception) {
        null
    }
}

fun safeReadText(f: File, maxChars: Int = 300_000): String {
    return try {
        if (!f.isFile || f.length() > maxChars) return ""
        f.readText()
    } catch (_: Exception) {
        ""
    }
}

fun safeWriteText(f: File, text: String): Boolean {
    return try {
        f.parentFile?.mkdirs()
        f.writeText(text)
        true
    } catch (_: Exception) {
        false
    }
}
