package com.codespace.ide.ide

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.layout.LayoutCoordinates
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.codespace.ide.ide.editor.OpenTab
import com.codespace.ide.ide.editor.EditorDiagnosticCard
import com.codespace.ide.ide.editor.lineColAt
import com.codespace.ide.ide.codeintel.PythonSyntaxDiagnostic
import com.codespace.ide.ide.codeintel.PythonLspController
import com.codespace.ide.ide.codeintel.PythonQuickFixes

/**
 * Owns the diagnostic card's source-validation and repair actions.
 * The editor remains the single owner of the live TextFieldValue and accepts
 * edits only through [onFieldChange].
 */
@Composable
internal fun EditorDiagnosticActions(
    tab: OpenTab,
    diagnostic: PythonSyntaxDiagnostic,
    field: TextFieldValue,
    scope: CoroutineScope,
    tabWidth: Int,
    pythonLspController: PythonLspController?,
    syntaxValidatedSource: String?,
    onFieldChange: (TextFieldValue) -> Unit,
    onSyntaxEditingLineChange: (Int?) -> Unit,
    reportCursor: (Int, Int) -> Unit,
    toast: (String) -> Unit,
    onDismiss: () -> Unit,
    onPositioned: (LayoutCoordinates) -> Unit
) {
    val sourceIsValidated = syntaxValidatedSource == field.text
    val fix = remember(field.text, diagnostic, sourceIsValidated) {
        if (sourceIsValidated) PythonQuickFixes.apply(field.text, diagnostic) else null
    }
    val isWarning = diagnostic.kind.equals("Warning", ignoreCase = true)
    val diagnosticCode = diagnostic.code.orEmpty().uppercase()
    val canReformatLine = isWarning && sourceIsValidated &&
        (diagnosticCode.startsWith("E") || diagnosticCode.startsWith("W"))

    EditorDiagnosticCard(
        diagnostic = diagnostic,
        canFix = fix != null,
        canReformatLine = canReformatLine,
        onFix = {
            val current = fix
            if (current != null && tab.text == field.text && syntaxValidatedSource == field.text) {
                tab.applyEdit(current.text, field.selection.start, field.selection.end)
                onFieldChange(
                    TextFieldValue(
                        current.text,
                        TextRange(current.selection.coerceIn(0, current.text.length))
                    )
                )
                onSyntaxEditingLineChange(null)
            }
        },
        onReformatLine = {
            val base = field.text
            val caret = field.selection.start
            if (tab.text == base && syntaxValidatedSource == base) {
                scope.launch {
                    // Prefer the language-server formatter, then apply the local
                    // cleanup pass to the diagnostic line only.
                    val serverFormatted = runCatching {
                        pythonLspController?.formatText(tab.file, base, tabWidth)
                    }.getOrNull()
                    val sameLineCount = serverFormatted != null &&
                        serverFormatted.count { it == '\n' } == base.count { it == '\n' }
                    // E303 concerns blank-line count, so line-count changes are valid.
                    val formatterSource = if (
                        serverFormatted != null && (sameLineCount || diagnosticCode == "E303")
                    ) serverFormatted else base
                    val originalPosition = lineColAt(base, caret)
                    val formatterLines = formatterSource.split('\n')
                    val formatterLine = formatterLines.getOrNull(originalPosition[0] - 1)
                    if (formatterLine == null) return@launch
                    val mappedCaret = formatterLines.take(originalPosition[0] - 1)
                        .sumOf { it.length + 1 } +
                        originalPosition[1].coerceIn(0, formatterLine.length)
                    val locallyFormatted = withContext(Dispatchers.Default) {
                        reformat(formatterSource, mappedCaret, tabWidth, rebuild = false)
                    }
                    val current = if (diagnosticCode == "E303") {
                        retainFormattedBlankLinesBeforeDiagnostic(
                            base, locallyFormatted.text, diagnostic.line, caret
                        )
                    } else {
                        retainOnlyFormattedLine(
                            base, locallyFormatted.text, diagnostic.line, locallyFormatted.caret
                        )
                    }
                    if (current == null) {
                        toast("This line does not need reformatting")
                        return@launch
                    }
                    // Never apply a result calculated for a buffer that has changed.
                    if (tab.text != base || field.text != base || syntaxValidatedSource != base) {
                        toast("Code changed; run Reformat line again")
                        return@launch
                    }
                    tab.applyEdit(current.text, field.selection.start, field.selection.end)
                    onFieldChange(
                        TextFieldValue(
                            current.text,
                            TextRange(current.caret.coerceIn(0, current.text.length))
                        )
                    )
                    onSyntaxEditingLineChange(null)
                    val lc = lineColAt(current.text, current.caret)
                    reportCursor(lc[0], lc[1])
                    toast("Reformatted line ${diagnostic.line}")
                }
            }
        },
        onDismiss = onDismiss,
        onPositioned = onPositioned
    )
}
