package com.codespace.ide.ide

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom
import java.util.concurrent.CountDownLatch
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import com.codespace.ide.ProotManager
import com.codespace.ide.ide.run.RunOrchestrator

// ---------------------------------------------------------------------------
// Run hub: ONE list of everything the IDE has started, whether it came from the Run button / Console
// or from a command typed in the Terminal. Both sides see the same state (Stop, Display, Browser,
// "already running" warnings) because they share these records.
// ---------------------------------------------------------------------------

class RunInfo(
    val id: String,
    /** "Console" or "Terminal". */
    val source: String,
    var cwd: String,
    var title: String,
    /**
     * What makes two runs "the same program": the absolute guest path of the script (or the command line),
     * plus "web:<project>" for a web server of a project, so `flask run` in the Terminal and the Run
     * button's Flask server are recognised as the same thing.
     */
    val keys: Set<String>
) {
    @Volatile var pid: Int = 0
    @Volatile var pgid: Int = 0
    @Volatile var running: Boolean = true
    @Volatile var usesDisplay: Boolean = false
    @Volatile var webUrl: String? = null
    val startedAt: Long = System.currentTimeMillis()
}

class RunHub {
    private val lock = Any()
    private val list = ArrayList<RunInfo>()
    private var counter = 0
    private val listeners = java.util.concurrent.CopyOnWriteArrayList<() -> Unit>()

    /**
     * Set by the IDE screen. The background service uses it for the notification's
     * "Stop all" action, because a Console run is a PTY session (no pid) that only
     * the screen knows how to close.
     */
    @Volatile var stopAllHandler: (() -> Unit)? = null

    /**
     * Monotonic change token for UI observers. Kept as a Flow so this process-wide
     * runtime registry has no dependency on Jetpack Compose.
     */
    private val _version = MutableStateFlow(0)
    val version: StateFlow<Int> = _version.asStateFlow()

    fun newId(): String = synchronized(lock) { "r" + (++counter) }

    /** App-scoped observers (the foreground service manager). */
    fun addListener(l: () -> Unit) {
        listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }

    fun touch() {
        // Keep observer callbacks serialized on Main. StateFlow itself is
        // thread-safe, but callbacks may update Android-facing service state.
        val publish = Runnable {
            _version.value = _version.value + 1
            for (listener in listeners) {
                try {
                    listener()
                } catch (_: Exception) {
                    // One observer must not prevent the remaining observers.
                }
            }
        }
        if (Looper.myLooper() == Looper.getMainLooper()) publish.run()
        else mainHandler.post(publish)
    }

    private companion object {
        val mainHandler = Handler(Looper.getMainLooper())
    }

    fun add(info: RunInfo) {
        synchronized(lock) {
            list.add(info)
            // Keep the list short: finished runs only matter for a moment.
            while (list.size > 30) {
                val i = list.indexOfFirst { !it.running }
                if (i < 0) break
                list.removeAt(i)
            }
        }
        touch()
    }

    fun get(id: String): RunInfo? = synchronized(lock) { list.lastOrNull { it.id == id } }

    fun finish(id: String) {
        val r = get(id) ?: return
        if (r.running) {
            r.running = false
            touch()
        }
    }

    fun running(): List<RunInfo> = synchronized(lock) { list.filter { it.running } }

    /** A RUNNING run of the same program (other than [exceptId]), newest first. */
    fun findConflict(keys: Set<String>, exceptId: String? = null): RunInfo? = synchronized(lock) {
        list.lastOrNull { r -> r.running && r.id != exceptId && r.keys.any { it in keys } }
    }

    /**
     * Dispatches Stop All to the live IDE host when one is attached.
     * Returns false when there is no UI owner; the foreground service must
     * then use RunOrchestrator's process-scoped fallback for every run type.
     */
    fun requestStopAll(): Boolean {
        val handler = stopAllHandler ?: return false
        if (Looper.myLooper() == Looper.getMainLooper()) {
            return try {
                handler()
                true
            } catch (_: Exception) {
                false
            }
        }
        onMainThread {
            try {
                handler()
            } catch (_: Exception) {
                // The caller is off Main and cannot synchronously observe the
                // callback result. Keep this path best-effort and non-crashing.
            }
        }
        return true
    }
}

/** What the guest shell needs to talk to the IDE (read by ProotManager when it builds the shell). */
interface IdeShellEnv {
    val token: String
    /** Blocks briefly until the bridge listens; null if it could not start. */
    fun url(): String?
}

/** Implemented by the IDE screen: reacts to what the guest tells the bridge. Called on server threads. */
interface IdeBridgeHandler {
    fun prepare(cwd: String, argv: List<String>): JSONObject
    fun start(id: String, pid: Int, pgid: Int, cwd: String, argv: List<String>)
    fun port(id: String, host: String, port: Int)
    fun done(id: String, code: Int)
    fun stop(id: String)
}

/**
 * Loopback control server for guest -> IDE messages (JSON over minimal HTTP, token-protected so no other
 * app on the phone can talk to it). Also installs the guest scripts into the guest /tmp/ide.
 */
class IdeBridge(private val guestTmpHost: File) : IdeShellEnv {
    @Volatile var handler: IdeBridgeHandler? = null
    override val token: String = run {
        val b = ByteArray(16)
        SecureRandom().nextBytes(b)
        b.joinToString("") { "%02x".format(it) }
    }
    @Volatile private var port = 0
    private val ready = CountDownLatch(1)
    private val lifecycleLock = Any()
    private val started = AtomicBoolean(false)
    private val stopped = AtomicBoolean(false)
    private val activeConnections = ConcurrentHashMap.newKeySet<Socket>()
    private var server: ServerSocket? = null
    // The bridge is reachable only through loopback + a random token. Keep its
    // worker count and pending connections bounded nevertheless.
    private val pool = ThreadPoolExecutor(
        2,
        2,
        0L,
        TimeUnit.MILLISECONDS,
        ArrayBlockingQueue(32),
        { runnable ->
            Thread(runnable, "ide-bridge-worker").apply { isDaemon = true }
        },
        ThreadPoolExecutor.AbortPolicy(),
    )

    override fun url(): String? {
        if (stopped.get()) return null
        try {
            ready.await(1500, TimeUnit.MILLISECONDS)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
            return null
        }
        return if (!stopped.get() && port > 0) "http://127.0.0.1:$port" else null
    }

    /** Starts listening on a background thread (safe to call from the UI thread). */
    fun startAsync() {
        if (stopped.get() || !started.compareAndSet(false, true)) return
        Thread {
            try {
                try {
                    installGuestFiles()
                } catch (_: Exception) {
                    // Keep the control bridge available even if optional guest
                    // helper refresh fails; the guest may already have the files.
                }
                if (stopped.get()) return@Thread
                val socket = ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"))
                val accepted = synchronized(lifecycleLock) {
                    if (stopped.get()) false else {
                        server = socket
                        port = socket.localPort
                        true
                    }
                }
                if (!accepted) {
                    try { socket.close() } catch (_: Exception) { }
                    return@Thread
                }
                ready.countDown()
                while (!stopped.get() && !socket.isClosed) {
                    val connection = socket.accept()
                    if (stopped.get()) {
                        try { connection.close() } catch (_: Exception) { }
                        break
                    }
                    activeConnections.add(connection)
                    try {
                        pool.execute { serve(connection) }
                    } catch (_: RejectedExecutionException) {
                        activeConnections.remove(connection)
                        try { connection.close() } catch (_: Exception) { }
                    }
                }
            } catch (_: Exception) {
                // Closing the listening socket is the normal stop signal.
            } finally {
                ready.countDown()
            }
        }.also { it.isDaemon = true; it.name = "ide-bridge" }.start()
    }

    /** Permanently closes this host's bridge and every accepted connection. */
    fun stop() {
        if (!stopped.compareAndSet(false, true)) return
        handler = null
        val listening = synchronized(lifecycleLock) {
            val current = server
            server = null
            port = 0
            current
        }
        try { listening?.close() } catch (_: Exception) { }
        activeConnections.toList().forEach { connection ->
            try { connection.close() } catch (_: Exception) { }
        }
        activeConnections.clear()
        pool.shutdownNow()
        ready.countDown()
    }

    private fun installGuestFiles() {
        val dir = File(guestTmpHost, "ide")
        val py = File(dir, "py")
        py.mkdirs()
        File(dir, "ide_run.py").writeText(IDE_RUN_PY)
        File(dir, "shell-init.sh").writeText(IDE_SHELL_INIT_SH)
        File(py, "ide_run_hook.py").writeText(IDE_RUN_HOOK_PY)
        File(py, "sitecustomize.py").writeText(IDE_RUN_SITECUSTOMIZE_PY)
        File(dir, "pystartup.py").writeText(IDE_PYSTARTUP_PY)
        File(dir, "ide_kernel.py").writeText(IDE_KERNEL_PY)
    }

    private fun readLine(ins: InputStream): String? {
        val b = ByteArrayOutputStream()
        while (true) {
            val c = ins.read()
            if (c < 0) return if (b.size() == 0) null else b.toString("UTF-8")
            if (c == '\n'.code) return b.toString("UTF-8").trimEnd('\r')
            if (b.size() > 8192) return null
            b.write(c)
        }
    }

    private fun serve(c: Socket) {
        try {
            if (stopped.get()) return
            c.soTimeout = 8000
            val ins = java.io.BufferedInputStream(c.getInputStream())
            val first = readLine(ins) ?: return
            val parts = first.split(" ")
            if (parts.size < 2) return
            var len = 0
            var tok = ""
            while (true) {
                val h = readLine(ins) ?: return
                if (h.isEmpty()) break
                val i = h.indexOf(':')
                if (i > 0) {
                    val k = h.substring(0, i).trim().lowercase()
                    val v = h.substring(i + 1).trim()
                    if (k == "content-length") len = v.toIntOrNull() ?: 0
                    if (k == "x-ide-token") tok = v
                }
            }
            if (len < 0 || len > 1_000_000) return
            val body = ByteArray(len)
            var off = 0
            while (off < len) {
                val n = ins.read(body, off, len - off)
                if (n < 0) break
                off += n
            }
            val out = c.getOutputStream()
            if (tok != token) {
                respond(out, 403, "{\"ok\":false}")
                return
            }
            val path = parts[1]
            if (stopped.get()) return
            val h = handler
            val json = try {
                if (body.isEmpty()) JSONObject() else JSONObject(String(body, Charsets.UTF_8))
            } catch (_: Exception) {
                JSONObject()
            }
            val resp: String = when {
                path == "/ping" -> "{\"ok\":true}"
                h == null -> "{\"ok\":false}"
                path == "/run/prepare" -> {
                    val argvArr = json.optJSONArray("argv") ?: JSONArray()
                    val argv = (0 until argvArr.length()).map { argvArr.optString(it) }
                    h.prepare(json.optString("cwd", "/"), argv).toString()
                }
                path == "/run/start" -> {
                    val argvArr = json.optJSONArray("argv") ?: JSONArray()
                    val argv = (0 until argvArr.length()).map { argvArr.optString(it) }
                    h.start(
                        json.optString("id"), json.optInt("pid"), json.optInt("pgid"),
                        json.optString("cwd", "/"), argv
                    )
                    "{\"ok\":true}"
                }
                path == "/run/port" -> {
                    h.port(json.optString("id"), json.optString("host"), json.optInt("port"))
                    "{\"ok\":true}"
                }
                path == "/run/done" -> {
                    h.done(json.optString("id"), json.optInt("code"))
                    "{\"ok\":true}"
                }
                path == "/run/stop" -> {
                    h.stop(json.optString("id"))
                    "{\"ok\":true}"
                }
                else -> "{\"ok\":false}"
            }
            respond(out, 200, resp)
        } catch (_: Exception) {
        } finally {
            activeConnections.remove(c)
            try {
                c.close()
            } catch (_: Exception) {
            }
        }
    }

    private fun respond(out: java.io.OutputStream, code: Int, body: String) {
        val b = body.toByteArray(Charsets.UTF_8)
        val head = "HTTP/1.0 $code ${if (code == 200) "OK" else "Forbidden"}\r\n" +
            "Content-Type: application/json\r\nContent-Length: ${b.size}\r\nConnection: close\r\n\r\n"
        out.write(head.toByteArray(Charsets.US_ASCII))
        out.write(b)
        out.flush()
    }
}

/** Runs [block] on the main thread (posts if called from another thread). */
internal fun onMainThread(block: () -> Unit) {
    if (Looper.myLooper() == Looper.getMainLooper()) block() else Handler(Looper.getMainLooper()).post(block)
}
