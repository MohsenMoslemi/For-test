package com.codespace.ide.ide.learn



fun mainTemplate(name: String): String {
    return "def main():\n" +
    "    print(\"Hello from $name!\")\n" +
    "\n" +
    "\n" +
    "if __name__ == \"__main__\":\n" +
    "    main()\n"
}

/** Bundled Python lessons (static content, samples open in the editor). */
data class Lesson(val title: String, val subtitle: String, val fileName: String, val code: String)

fun builtinLessons(): List<Lesson> {
    return listOf(
        Lesson(
            "Variables & Types",
            "str, int, float, bool, None",
            "lesson_01_variables.py",
            "name = \"pyspace\"\nversion = 1.0\nawesome = True\nnothing = None\n\n" +
            "print(name, type(name))\nprint(version, type(version))\nprint(awesome, nothing)\n"
        ),
        Lesson(
            "Loops & Conditions",
            "for, while, if / elif / else",
            "lesson_02_loops.py",
            "for i in range(5):\n    if i % 2 == 0:\n        print(f\"{i} is even\")\n    else:\n        print(f\"{i} is odd\")\n\n" +
            "n = 3\nwhile n > 0:\n    print(\"countdown:\", n)\n    n -= 1\n"
        ),
        Lesson(
            "Functions",
            "def, defaults, return",
            "lesson_03_functions.py",
            "def greet(who=\"world\"):\n    return f\"Hello, {who}!\"\n\n\n" +
            "def add(a, b=10):\n    return a + b\n\n\n" +
            "print(greet())\nprint(greet(\"pyspace\"))\nprint(add(5), add(5, 7))\n"
        ),
        Lesson(
            "Lists & Dicts",
            "comprehensions, slicing, mapping",
            "lesson_04_collections.py",
            "squares = [x * x for x in range(10)]\nprint(squares)\nprint(squares[2:5])\n\n" +
            "user = {\"name\": \"ada\", \"langs\": [\"python\", \"kotlin\"]}\n" +
            "for k, v in user.items():\n    print(k, \"->\", v)\n"
        ),
        Lesson(
            "Files & Errors",
            "open, with, try / except",
            "lesson_05_files.py",
            "from pathlib import Path\n\n" +
            "Path(\"notes.txt\").write_text(\"hello pyspace\\n\")\n\n" +
            "try:\n    print(Path(\"notes.txt\").read_text())\n    print(Path(\"missing.txt\").read_text())\n" +
            "except FileNotFoundError as e:\n    print(\"oops:\", e)\n"
        ),
        Lesson(
            "Virtualenv & pip",
            "isolate deps per project",
            "lesson_06_venv.py",
            "# In the Terminal panel:\n#   python3 -m venv .venv\n#   source .venv/bin/activate\n#   pip install requests\n#\n" +
            "import sys\nprint(sys.prefix)\n"
        )
    )
}
