package com.codespace.ide.ide.codeintel

import com.codespace.ide.runtime.RuntimeDispatchers
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.launch

/** Owns the app-native Python type-checking session independently of pylsp. */
internal class PythonNativeDiagnosticsSession(
    private val scope: CoroutineScope,
    private val dispatchers: RuntimeDispatchers,
    private val onDiagnosticsChanged: (path: String, source: String) -> Unit,
) : AutoCloseable {
    private val jobs = ConcurrentHashMap<String, Job>()
    private val diagnosticsByPath = ConcurrentHashMap<String, List<PythonSyntaxDiagnostic>>()
    private val sourceByPath = ConcurrentHashMap<String, String>()
    @Volatile private var closed = false

    fun schedule(file: File, source: String, maxSourceChars: Int) {
        val path = file.absolutePath
        sourceByPath[path] = source
        jobs.remove(path)?.cancel()
        if (closed || source.length > maxSourceChars || !file.extension.equals("py", ignoreCase = true)) {
            diagnosticsByPath.remove(path)
            onDiagnosticsChanged(path, source)
            return
        }
        val job = scope.launch(dispatchers.cpu) {
            val ownJob = currentCoroutineContext()[Job]
            try {
                delay(DEBOUNCE_MS)
                val diagnostics = KotlinPythonTypeChecker.analyze(source)
                if (!closed && sourceByPath[path] == source) {
                    diagnosticsByPath[path] = diagnostics
                    onDiagnosticsChanged(path, source)
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                // A conservative checker fails silently rather than emitting guessed diagnostics.
            } finally {
                if (ownJob != null) jobs.remove(path, ownJob)
            }
        }
        jobs[path] = job
    }

    fun diagnosticsFor(path: String): List<PythonSyntaxDiagnostic> = diagnosticsByPath[path].orEmpty()

    fun remove(path: String) {
        jobs.remove(path)?.cancel()
        sourceByPath.remove(path)
        diagnosticsByPath.remove(path)
    }

    fun clear() {
        jobs.values.forEach { it.cancel() }
        jobs.clear()
        sourceByPath.clear()
        diagnosticsByPath.clear()
    }

    override fun close() {
        closed = true
        clear()
    }

    private companion object {
        const val DEBOUNCE_MS = 320L
    }
}
