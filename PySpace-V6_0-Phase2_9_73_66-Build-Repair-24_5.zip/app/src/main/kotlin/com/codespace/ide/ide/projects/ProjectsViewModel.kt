package com.codespace.ide.ide.projects

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope

import java.io.File
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import com.codespace.ide.ide.PythonRuntimeCatalog

private const val PROJECT_DELETE_UNDO_WINDOW_MS = 5_000L

/** Immutable UI state for the workspace/project overview. */
data class ProjectsUiState(
    val projects: List<PyProject> = emptyList(),
    val sortMode: Int = 0, // 0 alphabetic, 1 created date, 2 last opened
    val projectCreatedAt: Map<String, Long> = emptyMap(),
    val projectLastOpenedAt: Map<String, Long> = emptyMap(),
    val pythonFileCounts: Map<String, Int> = emptyMap(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val busyProjects: Set<String> = emptySet(),
    /** Projects whose Python virtual environment is actively being built. */
    val venvBuildingProjects: Set<String> = emptySet(),
    val mutationBusy: Boolean = false,
    val mutationError: String? = null,
    val mutationProgress: String? = null,
    val mutationProgressFraction: Float? = null,
    val runtimeInstallStates: Map<String, RuntimeInstallUiState> = emptyMap(),
    val backupRestoreBusy: Boolean = false,
    val backupRestoreMessage: String? = null,
    val backupRestoreError: String? = null,
    val backupRestoreProgress: BackupProgress? = null,
    /** Projects temporarily staged for deletion and still eligible for Undo. */
    val pendingDeletions: Map<String, PendingProjectDeletionUi> = emptyMap(),
    /** One-shot paths whose project deletion has just become permanent. */
    val completedDeletionEvents: List<String> = emptyList(),
)

data class PendingProjectDeletionUi(
    val entry: ProjectDeletionManager.Entry,
    val remainingSeconds: Int,
)

data class RuntimeInstallUiState(
    /** downloading, installing, installed, error, or removing */
    val status: String = "preparing",
    val message: String = "Preparing…",
    val fraction: Float? = null,
    val error: String? = null,
)

/**
 * Owns workspace reads for the IDE home screen. File traversal is delegated to
 * the repository and never runs in a Composable or on the main thread.
 */
class ProjectsViewModel(
    private val workspace: File,
    private val repository: ProjectRepository,
    private val backupManager: ProjectBackupManager,
    private val metadataPrefs: android.content.SharedPreferences,
) : ViewModel() {
    private val _state = MutableStateFlow(ProjectsUiState(isLoading = true, sortMode = metadataPrefs.getInt("projects.sort.mode", 0).coerceIn(0, 2)))
    val state: StateFlow<ProjectsUiState> = _state.asStateFlow()

    private var refreshJob: kotlinx.coroutines.Job? = null
    private var mutationJob: kotlinx.coroutines.Job? = null
    private var backupRestoreJob: kotlinx.coroutines.Job? = null
    private val runtimeInstallJobs = mutableMapOf<String, kotlinx.coroutines.Job>()
    private val deletionManager = ProjectDeletionManager(workspace)
    private val pendingDeletionJobs = mutableMapOf<String, kotlinx.coroutines.Job>()
    private var deletionStageJob: kotlinx.coroutines.Job? = null
    private val deletionMutex = kotlinx.coroutines.sync.Mutex()

    init {
        recoverPendingProjectDeletions()
    }

    fun refreshPythonRuntimeStates() {
        viewModelScope.launch {
            com.codespace.ide.ide.PythonRuntimeCatalog.options.forEach { option ->
                val installed = try { repository.isPythonRuntimeInstalled(option.id) } catch (_: Exception) { false }
                if (runtimeInstallJobs[option.id]?.isActive != true) {
                    updateState { state ->
                        if (installed) {
                            if (state.runtimeInstallStates[option.id]?.status == "installed") state
                            else state.copy(runtimeInstallStates = state.runtimeInstallStates + (option.id to RuntimeInstallUiState(status = "installed", message = "Installed", fraction = 1f)))
                        } else if (state.runtimeInstallStates[option.id]?.status == "installed") {
                            state.copy(runtimeInstallStates = state.runtimeInstallStates - option.id)
                        } else state
                    }
                }
            }
        }
    }

    fun installPythonRuntime(versionId: String) {
        if (runtimeInstallJobs[versionId]?.isActive == true) return
        runtimeInstallJobs[versionId] = viewModelScope.launch {
            updateState { it.copy(runtimeInstallStates = it.runtimeInstallStates + (versionId to RuntimeInstallUiState(status = "preparing", message = "Preparing download…"))) }
            try {
                repository.ensurePythonRuntime(versionId) { message, fraction ->
                    updateState { state ->
                        val phase = when {
                            message.startsWith("Downloading", ignoreCase = true) -> "downloading"
                            message.startsWith("Verifying", ignoreCase = true) || message.startsWith("Installing", ignoreCase = true) -> "installing"
                            else -> "preparing"
                        }
                        state.copy(runtimeInstallStates = state.runtimeInstallStates + (versionId to RuntimeInstallUiState(status = phase, message = message, fraction = fraction)))
                    }
                }
                updateState { it.copy(runtimeInstallStates = it.runtimeInstallStates + (versionId to RuntimeInstallUiState(status = "installed", message = "Installed", fraction = 1f))) }
            } catch (cancelled: CancellationException) {
                updateState { it.copy(runtimeInstallStates = it.runtimeInstallStates - versionId) }
                throw cancelled
            } catch (error: Exception) {
                updateState { it.copy(runtimeInstallStates = it.runtimeInstallStates + (versionId to RuntimeInstallUiState(status = "error", message = "Install", error = error.message ?: "Installation failed"))) }
            } finally {
                runtimeInstallJobs.remove(versionId)
            }
        }
    }

    fun cancelPythonRuntimeDownload(versionId: String) {
        val state = _state.value.runtimeInstallStates[versionId] ?: return
        if (state.status == "downloading" || state.status == "preparing") {
            runtimeInstallJobs[versionId]?.cancel(CancellationException("Python download cancelled by user"))
        }
    }

    fun removePythonRuntime(versionId: String) {
        if (runtimeInstallJobs[versionId]?.isActive == true || _state.value.mutationBusy) return
        runtimeInstallJobs[versionId] = viewModelScope.launch {
            updateState { it.copy(runtimeInstallStates = it.runtimeInstallStates + (versionId to RuntimeInstallUiState(status = "installing", message = "Removing…"))) }
            try {
                repository.removePythonRuntime(workspace, versionId)
                updateState { it.copy(runtimeInstallStates = it.runtimeInstallStates - versionId) }
            } catch (error: Exception) {
                updateState { it.copy(runtimeInstallStates = it.runtimeInstallStates + (versionId to RuntimeInstallUiState(status = "error", message = "Remove", error = error.message ?: "Removal failed"))) }
            }
        }
    }

    fun createProject(
        name: String,
        venvName: String,
        buildVenv: Boolean,
        pythonVersionId: String,
        onCreated: (PyProject) -> Unit = {},
    ) {
        if (_state.value.mutationBusy || _state.value.backupRestoreBusy) return
        mutationJob = viewModelScope.launch {
            updateState { it.copy(mutationBusy = true, mutationError = null, mutationProgress = "Preparing Python runtime…", mutationProgressFraction = null) }
            var createdProject: PyProject? = null
            try {
                repository.ensurePythonRuntime(pythonVersionId) { message, fraction ->
                    updateState { it.copy(mutationProgress = message, mutationProgressFraction = fraction) }
                }
                updateState { it.copy(mutationProgress = "Creating project…", mutationProgressFraction = null) }
                val created = repository.createProject(workspace, name, venvName, pythonVersionId)
                    ?: throw IllegalStateException("Project could not be created. Check the name or whether it already exists.")
                createdProject = created
                metadataPrefs.edit().putLong("created:${created.dir.absolutePath}", System.currentTimeMillis()).apply()
                if (buildVenv) {
                    updateState {
                        it.copy(
                            mutationProgress = "Building Python ${com.codespace.ide.ide.PythonRuntimeCatalog.require(pythonVersionId).version} virtual environment…",
                            mutationProgressFraction = null,
                            busyProjects = it.busyProjects + created.dir.absolutePath,
                            venvBuildingProjects = it.venvBuildingProjects + created.dir.absolutePath
                        )
                    }
                }
                refresh()
                onCreated(created)
                if (buildVenv) buildVenvInternal(created)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                updateState { it.copy(mutationError = error.message ?: "Project operation failed") }
            } finally {
                if (createdProject != null) {
                    updateState {
                        it.copy(
                            busyProjects = it.busyProjects - createdProject.dir.absolutePath,
                            venvBuildingProjects = it.venvBuildingProjects - createdProject.dir.absolutePath
                        )
                    }
                    refresh()
                }
                updateState { it.copy(mutationBusy = false, mutationProgress = null, mutationProgressFraction = null) }
            }
        }
    }

    fun renameProject(project: PyProject, newName: String, onRenamed: (PyProject) -> Unit = {}) {
        runProjectMutation(project) {
            val renamed = repository.renameProject(project, newName)
                ?: throw IllegalStateException("Rename failed. The name may be invalid or already in use.")
            refresh()
            onRenamed(renamed)
        }
    }

    /** Stage a confirmed project deletion and expose a five-second Undo window. */
    fun deleteProject(project: PyProject) {
        val key = project.dir.absolutePath
        if (_state.value.pendingDeletions.containsKey(key) || deletionStageJob?.isActive == true || _state.value.mutationBusy || _state.value.backupRestoreBusy) return
        deletionStageJob = viewModelScope.launch {
            updateState { it.copy(mutationBusy = true, mutationError = null) }
            try {
                val entry = withContext(kotlinx.coroutines.Dispatchers.IO) {
                    deletionManager.stage(project, System.currentTimeMillis() + PROJECT_DELETE_UNDO_WINDOW_MS)
                }
                updateState { state ->
                    state.copy(pendingDeletions = state.pendingDeletions + (key to PendingProjectDeletionUi(entry, 5)))
                }
                refresh()
                startPendingDeletionTimer(key, entry)
            } catch (error: Exception) {
                updateState { it.copy(mutationError = error.message ?: "Project could not be staged for deletion.") }
            } finally {
                updateState { it.copy(mutationBusy = false) }
                deletionStageJob = null
            }
        }
    }

    fun undoProjectDeletion(originalPath: String) {
        val pending = _state.value.pendingDeletions[originalPath] ?: return
        viewModelScope.launch {
            deletionMutex.lock()
            try {
                if (_state.value.pendingDeletions[originalPath]?.entry?.id != pending.entry.id) return@launch
                pendingDeletionJobs.remove(originalPath)?.cancel()
                if (System.currentTimeMillis() >= pending.entry.deadlineAtMillis) {
                    withContext(kotlinx.coroutines.Dispatchers.IO) { deletionManager.finalizeDeletion(pending.entry) }
                    updateState { state ->
                        state.copy(
                            pendingDeletions = state.pendingDeletions - originalPath,
                            completedDeletionEvents = state.completedDeletionEvents + originalPath
                        )
                    }
                    refresh()
                    return@launch
                }
                val restored = withContext(kotlinx.coroutines.Dispatchers.IO) { deletionManager.restore(pending.entry) }
                updateState { state ->
                    state.copy(pendingDeletions = state.pendingDeletions - originalPath)
                }
                refresh()
                if (restored.dir.absolutePath != originalPath) {
                    updateState { it.copy(mutationError = "Project restored as ${restored.name} because its original location is now occupied.") }
                }
            } catch (error: Exception) {
                updateState { it.copy(mutationError = error.message ?: "Could not undo project deletion.") }
            } finally {
                deletionMutex.unlock()
            }
        }
    }

    /** Finalize all staged deletions when leaving Projects or opening another project. */
    fun commitPendingProjectDeletions(onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            // A screen transition can race the filesystem rename. Wait until a
            // confirmed deletion has either been staged or safely rejected.
            deletionStageJob?.join()
            deletionMutex.lock()
            try {
                val pending = _state.value.pendingDeletions.toMap()
                val completed = mutableListOf<String>()
                for ((path, item) in pending) {
                    pendingDeletionJobs.remove(path)?.cancel()
                    try {
                        withContext(kotlinx.coroutines.Dispatchers.IO) { deletionManager.finalizeDeletion(item.entry) }
                        completed += path
                    } catch (error: Exception) {
                        updateState { it.copy(mutationError = error.message ?: "Could not permanently delete ${item.entry.projectName}.") }
                    }
                }
                if (completed.isNotEmpty()) {
                    updateState { state ->
                        state.copy(
                            pendingDeletions = state.pendingDeletions - completed.toSet(),
                            completedDeletionEvents = state.completedDeletionEvents + completed
                        )
                    }
                    refresh()
                }
            } finally {
                deletionMutex.unlock()
                onComplete()
            }
        }
    }

    fun consumeCompletedDeletionEvents() {
        updateState { it.copy(completedDeletionEvents = emptyList()) }
    }

    private fun recoverPendingProjectDeletions() {
        viewModelScope.launch {
            val entries = withContext(kotlinx.coroutines.Dispatchers.IO) { deletionManager.loadPending() }
            val now = System.currentTimeMillis()
            for (entry in entries) {
                val key = entry.originalPath
                if (entry.deadlineAtMillis <= now) {
                    try {
                        withContext(kotlinx.coroutines.Dispatchers.IO) { deletionManager.finalizeDeletion(entry) }
                        updateState { it.copy(completedDeletionEvents = it.completedDeletionEvents + key) }
                    } catch (error: Exception) {
                        updateState { it.copy(mutationError = error.message ?: "Could not finish a pending project deletion.") }
                    }
                } else {
                    val remaining = ((entry.deadlineAtMillis - now + 999L) / 1000L).toInt().coerceAtLeast(1)
                    updateState { state ->
                        state.copy(pendingDeletions = state.pendingDeletions + (key to PendingProjectDeletionUi(entry, remaining)))
                    }
                    startPendingDeletionTimer(key, entry)
                }
            }
            refresh()
        }
    }

    private fun startPendingDeletionTimer(key: String, entry: ProjectDeletionManager.Entry) {
        pendingDeletionJobs.remove(key)?.cancel()
        pendingDeletionJobs[key] = viewModelScope.launch {
            while (true) {
                val remainingMs = entry.deadlineAtMillis - System.currentTimeMillis()
                val seconds = ((remainingMs.coerceAtLeast(0L) + 999L) / 1000L).toInt()
                updateState { state ->
                    val current = state.pendingDeletions[key]
                    if (current != null && current.entry.id == entry.id) state.copy(pendingDeletions = state.pendingDeletions + (key to current.copy(remainingSeconds = seconds))) else state
                }
                if (remainingMs <= 0L) break
                kotlinx.coroutines.delay(minOf(1000L, remainingMs))
            }
            val timerJob = kotlinx.coroutines.currentCoroutineContext()[kotlinx.coroutines.Job]
            deletionMutex.lock()
            try {
                if (_state.value.pendingDeletions[key]?.entry?.id == entry.id) {
                    try {
                        withContext(kotlinx.coroutines.Dispatchers.IO) { deletionManager.finalizeDeletion(entry) }
                        updateState { state ->
                            state.copy(
                                pendingDeletions = state.pendingDeletions - key,
                                completedDeletionEvents = state.completedDeletionEvents + key
                            )
                        }
                        refresh()
                    } catch (error: Exception) {
                        updateState { it.copy(mutationError = error.message ?: "Could not permanently delete ${entry.projectName}.") }
                    }
                }
            } finally {
                deletionMutex.unlock()
                if (pendingDeletionJobs[key] === timerJob) pendingDeletionJobs.remove(key)
            }
        }
    }

    fun changeProjectPythonVersion(project: PyProject, versionId: String, onChanged: () -> Unit = {}) {
        runProjectMutation(project) {
            repository.changeProjectPythonVersion(project, versionId)
            refresh()
            onChanged()
        }
    }

    fun saveVenvName(project: PyProject, name: String, onSaved: () -> Unit = {}) {
        runProjectMutation(project) {
            if (!repository.saveVenvName(project, name)) throw IllegalStateException("Could not save the virtualenv name.")
            refresh()
            onSaved()
        }
    }

    fun buildVirtualEnv(project: PyProject, onFinished: (Boolean) -> Unit = {}) {
        runProjectMutation(project) {
            val key = project.dir.absolutePath
            updateState { it.copy(venvBuildingProjects = it.venvBuildingProjects + key) }
            try {
                val message = repository.buildVirtualEnv(project)
                if (message.isNotEmpty()) throw IllegalStateException(message)
                refresh()
                onFinished(true)
            } finally {
                updateState { it.copy(venvBuildingProjects = it.venvBuildingProjects - key) }
            }
        }
    }

    private fun runProjectMutation(project: PyProject, block: suspend () -> Unit) {
        val key = project.dir.absolutePath
        if (_state.value.busyProjects.contains(key) || _state.value.mutationBusy || _state.value.backupRestoreBusy) return
        mutationJob = viewModelScope.launch {
            updateState { it.copy(busyProjects = it.busyProjects + key, mutationBusy = true, mutationError = null) }
            try {
                block()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                updateState { it.copy(mutationError = error.message ?: "Project operation failed") }
            } finally {
                updateState { it.copy(busyProjects = it.busyProjects - key, mutationBusy = false, mutationProgress = null, mutationProgressFraction = null) }
            }
        }
    }

    private suspend fun buildVenvInternal(project: PyProject) {
        val message = repository.buildVirtualEnv(project)
        if (message.isNotEmpty()) throw IllegalStateException(message)
    }

    private inline fun updateState(transform: (ProjectsUiState) -> ProjectsUiState) {
        _state.value = transform(_state.value)
    }

    fun clearMutationError() { updateState { it.copy(mutationError = null) } }

    fun backupWorkspace(destination: Uri) = runBackupOperation("Scanning projects…") { progress, checkCancelled ->
        val count = withContext(kotlinx.coroutines.Dispatchers.IO) {
            backupManager.exportWorkspace(workspace, destination, progress, checkCancelled)
        }
        "Backed up $count project${if (count == 1) "" else "s"}. Virtual environments were excluded."
    }

    fun backupProject(project: PyProject, destination: Uri) = runBackupOperation("Scanning ${project.name}…") { progress, checkCancelled ->
        withContext(kotlinx.coroutines.Dispatchers.IO) {
            backupManager.exportProject(project, destination, progress, checkCancelled)
        }
        "Backup created for ${project.name}. Virtual environment was excluded."
    }

    fun restoreBackup(source: Uri) = runBackupOperation("Inspecting backup…") { progress, checkCancelled ->
        val names = withContext(kotlinx.coroutines.Dispatchers.IO) {
            backupManager.restore(workspace, source, progress, checkCancelled)
        }
        refresh()
        "Restored ${names.size} project${if (names.size == 1) "" else "s"}: ${names.joinToString(", ")}"
    }

    private fun runBackupOperation(
        initialMessage: String,
        operation: suspend ((BackupProgress) -> Unit, () -> Unit) -> String,
    ) {
        if (_state.value.mutationBusy || _state.value.backupRestoreBusy) return
        backupRestoreJob = viewModelScope.launch {
            updateState { it.copy(backupRestoreBusy = true, backupRestoreMessage = initialMessage, backupRestoreError = null, backupRestoreProgress = null) }
            val operationJob = kotlinx.coroutines.currentCoroutineContext()[kotlinx.coroutines.Job]
            val reportProgress: (BackupProgress) -> Unit = { progress ->
                updateState { it.copy(backupRestoreProgress = progress, backupRestoreMessage = progress.phase) }
            }
            val checkCancelled: () -> Unit = { operationJob?.ensureActive() }
            try {
                val result = operation(reportProgress, checkCancelled)
                updateState { it.copy(backupRestoreMessage = result, backupRestoreProgress = null) }
            } catch (cancelled: CancellationException) {
                updateState { it.copy(backupRestoreMessage = "Operation cancelled. Incomplete temporary data was cleaned up.", backupRestoreProgress = null) }
            } catch (error: Exception) {
                updateState { it.copy(backupRestoreError = error.message ?: "Backup operation failed", backupRestoreMessage = null, backupRestoreProgress = null) }
            } finally {
                updateState { it.copy(backupRestoreBusy = false) }
                backupRestoreJob = null
            }
        }
    }

    fun cancelBackupRestore() { backupRestoreJob?.cancel() }

    fun clearBackupRestoreMessage() { updateState { it.copy(backupRestoreMessage = null, backupRestoreError = null, backupRestoreProgress = null) } }


    fun setSortMode(mode: Int) {
        val safe = mode.coerceIn(0, 2)
        metadataPrefs.edit().putInt("projects.sort.mode", safe).apply()
        updateState { it.copy(sortMode = safe) }
    }

    fun markProjectOpened(project: PyProject) {
        val key = project.dir.absolutePath
        val now = System.currentTimeMillis()
        metadataPrefs.edit().putLong("opened:$key", now).apply()
        updateState { it.copy(projectLastOpenedAt = it.projectLastOpenedAt + (key to now)) }
    }

    fun refresh() {
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch {
            updateState { it.copy(isLoading = true, error = null) }
            try {
                val activeProjects = repository.getProjects(workspace)
                val pendingSnapshot = _state.value.pendingDeletions
                val projects = (activeProjects + pendingSnapshot.values.map { it.entry.project })
                    .distinctBy { it.dir.absolutePath }
                val createdAt = LinkedHashMap<String, Long>(projects.size)
                val openedAt = LinkedHashMap<String, Long>(projects.size)
                val metadataEdit = metadataPrefs.edit()
                for (project in projects) {
                    val key = project.dir.absolutePath
                    val createdKey = "created:$key"
                    val created = metadataPrefs.getLong(createdKey, 0L).takeIf { it > 0L } ?: project.dir.lastModified().takeIf { it > 0L } ?: System.currentTimeMillis()
                    if (!metadataPrefs.contains(createdKey)) metadataEdit.putLong(createdKey, created)
                    createdAt[key] = created
                    val opened = metadataPrefs.getLong("opened:$key", 0L)
                    if (opened > 0L) openedAt[key] = opened
                }
                metadataEdit.apply()
                // Keep traversal concurrency bounded: large workspaces on
                // low-memory phones should not spawn one IO task per project.
                val countMap = LinkedHashMap<String, Int>(projects.size)
                for (project in projects) {
                    countMap[project.dir.absolutePath] = repository.countPythonFiles(project)
                }
                updateState { previous ->
                    val committedVisibleProjects = (activeProjects + previous.pendingDeletions.values.map { it.entry.project })
                        .distinctBy { it.dir.absolutePath }
                    ProjectsUiState(
                        projects = committedVisibleProjects,
                        sortMode = previous.sortMode,
                        projectCreatedAt = createdAt,
                        projectLastOpenedAt = openedAt,
                        pythonFileCounts = countMap,
                        isLoading = false,
                        busyProjects = previous.busyProjects,
                        venvBuildingProjects = previous.venvBuildingProjects,
                        mutationBusy = previous.mutationBusy,
                        mutationError = previous.mutationError,
                        mutationProgress = previous.mutationProgress,
                        mutationProgressFraction = previous.mutationProgressFraction,
                        runtimeInstallStates = previous.runtimeInstallStates,
                        backupRestoreBusy = previous.backupRestoreBusy,
                        backupRestoreMessage = previous.backupRestoreMessage,
                        backupRestoreError = previous.backupRestoreError,
                        backupRestoreProgress = previous.backupRestoreProgress,
                        pendingDeletions = previous.pendingDeletions,
                        completedDeletionEvents = previous.completedDeletionEvents,
                    )
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                updateState { it.copy(isLoading = false, error = error.message ?: "Unable to load projects") }
            }
        }
    }

    class Factory(
        private val workspace: File,
        private val context: Context,
        private val repository: ProjectRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (!modelClass.isAssignableFrom(ProjectsViewModel::class.java)) {
                throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
            }
            val prefs = context.applicationContext.getSharedPreferences("pyspace_project_metadata", Context.MODE_PRIVATE)
            return ProjectsViewModel(workspace, repository, ProjectBackupManager(context.applicationContext.contentResolver), prefs) as T
        }
    }
}
