package com.codespace.ide.ide.codeintel
import com.codespace.ide.ide.JSON

/** Offline documentation card resolved from Python built-ins, common module references,
 * and symbols declared in the current source file. It never imports or executes user code. */
data class PythonHoverDoc(
    val name: String,
    val kind: String,
    val signature: String,
    val summary: String,
    val details: String = "",
)

object PythonHoverDocumentation {
    private data class Entry(val signature: String, val summary: String, val details: String = "")

    private val builtins = mapOf(
        "print" to Entry("print(*objects, sep=' ', end='\\n', file=None, flush=False)", "Print objects to the text stream, separated by sep and followed by end."),
        "input" to Entry("input([prompt])", "Read a line from standard input and return it as a string."),
        "len" to Entry("len(obj)", "Return the number of items in a sequence or collection."),
        "range" to Entry("range(stop)  |  range(start, stop[, step])", "Return an immutable sequence of integers, commonly used in loops."),
        "enumerate" to Entry("enumerate(iterable, start=0)", "Yield pairs containing a count and the corresponding item."),
        "zip" to Entry("zip(*iterables, strict=False)", "Iterate over tuples containing items from each input iterable."),
        "open" to Entry("open(file, mode='r', encoding=None, ...)", "Open a file and return a file object.", "Common modes: 'r' read, 'w' write, 'a' append, 'b' binary."),
        "int" to Entry("int(x=0, base=10)", "Convert a number or string to an integer."),
        "float" to Entry("float(x=0)", "Convert a number or string to a floating-point number."),
        "str" to Entry("str(object='')", "Return the string representation of an object."),
        "bool" to Entry("bool(x)", "Convert a value to True or False using its truth value."),
        "list" to Entry("list(iterable=())", "Create a mutable list."),
        "tuple" to Entry("tuple(iterable=())", "Create an immutable tuple."),
        "dict" to Entry("dict(**mapping)", "Create a dictionary of key-value pairs."),
        "set" to Entry("set(iterable=())", "Create a set of distinct hashable items."),
        "sum" to Entry("sum(iterable, start=0)", "Return the sum of an iterable of numbers."),
        "min" to Entry("min(iterable, *, key=None)", "Return the smallest item in an iterable or among arguments."),
        "max" to Entry("max(iterable, *, key=None)", "Return the largest item in an iterable or among arguments."),
        "sorted" to Entry("sorted(iterable, *, key=None, reverse=False)", "Return a new sorted list from the items in an iterable."),
        "reversed" to Entry("reversed(sequence)", "Return a reverse iterator over a sequence."),
        "abs" to Entry("abs(number)", "Return the absolute value of a number."),
        "round" to Entry("round(number, ndigits=None)", "Round a number to the given number of decimal digits."),
        "pow" to Entry("pow(base, exp[, mod])", "Return base raised to exp; optionally apply a modulus."),
        "divmod" to Entry("divmod(a, b)", "Return the quotient and remainder of integer division."),
        "type" to Entry("type(object)", "Return the type of an object."),
        "isinstance" to Entry("isinstance(object, classinfo)", "Check whether an object is an instance of a class or type tuple."),
        "issubclass" to Entry("issubclass(class, classinfo)", "Check whether a class is a subclass of another class."),
        "any" to Entry("any(iterable)", "Return True if at least one item in the iterable is true."),
        "all" to Entry("all(iterable)", "Return True if every item in the iterable is true."),
        "map" to Entry("map(function, iterable, *iterables)", "Apply a function to each item and return an iterator."),
        "filter" to Entry("filter(function, iterable)", "Yield items for which the function returns true."),
        "iter" to Entry("iter(object)", "Return an iterator for an iterable object."),
        "next" to Entry("next(iterator[, default])", "Retrieve the next item from an iterator."),
        "enumerate" to Entry("enumerate(iterable, start=0)", "Yield index and item pairs from an iterable."),
        "getattr" to Entry("getattr(object, name[, default])", "Get a named attribute from an object."),
        "setattr" to Entry("setattr(object, name, value)", "Set a named attribute on an object."),
        "hasattr" to Entry("hasattr(object, name)", "Return whether an object has a named attribute."),
        "dir" to Entry("dir([object])", "Return names in the current scope or attributes of an object."),
        "help" to Entry("help([object])", "Display the interactive help system."),
        "repr" to Entry("repr(object)", "Return a developer-oriented string representation of an object."),
        "format" to Entry("format(value[, format_spec])", "Format a value using its format specification."),
        "chr" to Entry("chr(codepoint)", "Return the Unicode character for an integer code point."),
        "ord" to Entry("ord(character)", "Return the Unicode code point of a one-character string."),
        "hash" to Entry("hash(object)", "Return the hash value of an object, if it is hashable."),
        "id" to Entry("id(object)", "Return the identity of an object."),
        "hex" to Entry("hex(number)", "Convert an integer to a hexadecimal string."),
        "bin" to Entry("bin(number)", "Convert an integer to a binary string."),
        "oct" to Entry("oct(number)", "Convert an integer to an octal string."),
        "breakpoint" to Entry("breakpoint(*args, **kwargs)", "Enter the configured debugger at this point."),
        "property" to Entry("property(fget=None, fset=None, fdel=None, doc=None)", "Create a managed attribute on a class."),
        "super" to Entry("super([type[, object-or-type]])", "Return a proxy for method calls in a class hierarchy."),
    )

    private val moduleDocs = mapOf(
        "math.sqrt" to Entry("math.sqrt(x)", "Return the square root of x."),
        "math.sin" to Entry("math.sin(x)", "Return the sine of x radians."),
        "math.cos" to Entry("math.cos(x)", "Return the cosine of x radians."),
        "math.floor" to Entry("math.floor(x)", "Return the greatest integer less than or equal to x."),
        "math.ceil" to Entry("math.ceil(x)", "Return the smallest integer greater than or equal to x."),
        "random.randint" to Entry("random.randint(a, b)", "Return a random integer N such that a <= N <= b."),
        "random.choice" to Entry("random.choice(sequence)", "Return a random element from a non-empty sequence."),
        "random.random" to Entry("random.random()", "Return the next random float in the range [0.0, 1.0)."),
        "json.dumps" to Entry("json.dumps(obj, ...) ", "Serialize an object to a JSON-formatted string."),
        "json.loads" to Entry("json.loads(s)", "Deserialize a JSON document from a string."),
        "json.dump" to Entry("json.dump(obj, fp, ...)", "Serialize an object as JSON into a file-like object."),
        "json.load" to Entry("json.load(fp)", "Deserialize JSON from a file-like object."),
        "os.getcwd" to Entry("os.getcwd()", "Return the current working directory."),
        "os.listdir" to Entry("os.listdir(path='.')", "Return the names of entries in a directory."),
        "os.makedirs" to Entry("os.makedirs(name, exist_ok=False)", "Create a directory and any missing parent directories."),
        "os.remove" to Entry("os.remove(path)", "Remove a file."),
        "os.path.join" to Entry("os.path.join(path, *paths)", "Join path components using the platform-specific separator."),
        "os.path.exists" to Entry("os.path.exists(path)", "Return True if the path exists."),
        "time.sleep" to Entry("time.sleep(seconds)", "Suspend execution of the calling thread for the given number of seconds."),
        "pathlib.Path" to Entry("Path(*pathsegments)", "Represent a filesystem path with an object-oriented interface."),
        "numpy.array" to Entry("numpy.array(object, dtype=None, ...)", "Create an array from a sequence or array-like object."),
        "numpy.arange" to Entry("numpy.arange([start,] stop[, step], dtype=None)", "Return evenly spaced values within a given interval."),
        "numpy.zeros" to Entry("numpy.zeros(shape, dtype=float)", "Return a new array filled with zeros."),
        "numpy.ones" to Entry("numpy.ones(shape, dtype=float)", "Return a new array filled with ones."),
        "numpy.mean" to Entry("numpy.mean(a, axis=None, ...)", "Compute the arithmetic mean along the specified axis."),
        "numpy.reshape" to Entry("numpy.reshape(a, newshape)", "Give an array a new shape without changing its data."),
        "pandas.DataFrame" to Entry("pandas.DataFrame(data=None, index=None, columns=None)", "Create a two-dimensional labeled data structure."),
        "pandas.Series" to Entry("pandas.Series(data=None, index=None, dtype=None)", "Create a one-dimensional labeled array."),
        "pandas.read_csv" to Entry("pandas.read_csv(filepath_or_buffer, ...)", "Read a CSV file into a DataFrame."),
        "pandas.read_excel" to Entry("pandas.read_excel(io, sheet_name=0, ...)", "Read an Excel file into a DataFrame."),
        "matplotlib.pyplot.plot" to Entry("pyplot.plot(x, y, ...) ", "Plot y versus x as lines and/or markers."),
        "matplotlib.pyplot.imshow" to Entry("pyplot.imshow(X, ...) ", "Display image data on axes."),
        "matplotlib.pyplot.show" to Entry("pyplot.show()", "Display all open figures."),
        "cv2.imread" to Entry("cv2.imread(filename, flags=cv2.IMREAD_COLOR)", "Load an image from a file."),
        "cv2.imshow" to Entry("cv2.imshow(winname, mat)", "Display an image in a window."),
        "cv2.VideoCapture" to Entry("cv2.VideoCapture(source)", "Open a video file or capture device."),
        "cv2.cvtColor" to Entry("cv2.cvtColor(src, code)", "Convert an image from one color space to another."),
        "pygame.init" to Entry("pygame.init()", "Initialize the imported and initialized pygame modules."),
        "pygame.quit" to Entry("pygame.quit()", "Uninitialize all pygame modules."),
        "pygame.display.set_mode" to Entry("pygame.display.set_mode(size, flags=0)", "Create a display surface with the requested dimensions."),
        "requests.get" to Entry("requests.get(url, params=None, **kwargs)", "Send an HTTP GET request."),
        "requests.post" to Entry("requests.post(url, data=None, json=None, **kwargs)", "Send an HTTP POST request."),
        "flask.Flask" to Entry("Flask(import_name, ...)", "Create a Flask application instance."),
        "flask.route" to Entry("app.route(rule, **options)", "Register a view function for a URL rule."),
    )

    private val moduleAliases = listOf(
        Regex("(?m)^\\s*import\\s+([A-Za-z_][\\w.]*)\\s+as\\s+([A-Za-z_]\\w*)"),
        Regex("(?m)^\\s*import\\s+([A-Za-z_][\\w.]*)\\s*$"),
    )
    private val fromAliases = Regex("(?m)^\\s*from\\s+([A-Za-z_][\\w.]*)\\s+import\\s+([A-Za-z_]\\w*)(?:\\s+as\\s+([A-Za-z_]\\w*))?")
    private val functionPattern = Regex("(?m)^([ \\t]*)(?:async[ \\t]+)?def[ \\t]+([A-Za-z_]\\w*)[ \\t]*(\\([^\\n)]{0,240}\\))")
    private val classPattern = Regex("(?m)^([ \\t]*)class[ \\t]+([A-Za-z_]\\w*)[ \\t]*(\\([^\\n)]{0,180}\\))?")

    fun resolveAt(source: String, offset: Int, installedPackages: Set<String>? = null): PythonHoverDoc? {
        if (source.length > 250_000 || source.isEmpty()) return null
        val caret = offset.coerceIn(0, source.length)
        if (PythonCompletion.isInsideStringOrComment(source, caret)) return null

        var probe = caret
        if (probe >= source.length || !isIdentifier(source.getOrNull(probe))) probe--
        if (probe < 0 || !isIdentifier(source[probe])) return null
        var start = probe
        var end = probe + 1
        while (start > 0 && isIdentifier(source[start - 1])) start--
        while (end < source.length && isIdentifier(source[end])) end++
        val name = source.substring(start, end)

        var owner = ""
        if (start > 0 && source[start - 1] == '.') {
            var ownerStart = start - 2
            while (ownerStart >= 0 && (isIdentifier(source[ownerStart]) || source[ownerStart] == '.')) ownerStart--
            owner = source.substring(ownerStart + 1, start - 1)
        }

        val aliases = linkedMapOf<String, String>()
        moduleAliases[0].findAll(source).take(100).forEach { m -> aliases[m.groupValues[2]] = m.groupValues[1] }
        moduleAliases[1].findAll(source).take(100).forEach { m ->
            val full = m.groupValues[1]
            aliases.putIfAbsent(full.substringBefore('.'), full.substringBefore('.'))
        }
        fromAliases.findAll(source).take(100).forEach { m ->
            val imported = m.groupValues[2]
            aliases[m.groupValues[3].ifBlank { imported }] = "${m.groupValues[1]}.$imported"
        }
        val resolvedOwner = aliases[owner] ?: owner
        val qualified = if (resolvedOwner.isNotBlank()) "$resolvedOwner.$name" else name

        // Definitions in the open file take precedence over library names.
        functionPattern.findAll(source).take(500).firstOrNull { it.groupValues[2] == name }?.let { match ->
            val signature = match.groupValues[3].trimEnd().let { if (it.endsWith(')')) it else "$it)" }
            val doc = findFollowingDocstring(source, nextLineStart(source, match.range.last + 1), match.groupValues[1].length)
            return PythonHoverDoc(name, "FUNCTION", "$name$signature", doc.ifBlank { "Function defined in this file." })
        }
        classPattern.findAll(source).take(300).firstOrNull { it.groupValues[2] == name }?.let { match ->
            val args = match.groupValues[3]
            val signature = if (args.isBlank()) "class $name" else "class $name$args"
            val doc = findFollowingDocstring(source, nextLineStart(source, match.range.last + 1), match.groupValues[1].length)
            return PythonHoverDoc(name, "CLASS", signature, doc.ifBlank { "Class defined in this file." })
        }

        val importedQualifiedName = if (resolvedOwner.isBlank()) aliases[name] else null
        val optionalModule = when {
            qualified.startsWith("numpy.") || importedQualifiedName?.startsWith("numpy.") == true || importedQualifiedName == "numpy" -> "numpy"
            qualified.startsWith("pandas.") || importedQualifiedName?.startsWith("pandas.") == true || importedQualifiedName == "pandas" -> "pandas"
            qualified.startsWith("matplotlib.") || importedQualifiedName?.startsWith("matplotlib.") == true -> "matplotlib"
            qualified.startsWith("cv2.") || importedQualifiedName == "cv2" -> "cv2"
            qualified.startsWith("pygame.") || importedQualifiedName == "pygame" -> "pygame"
            qualified.startsWith("requests.") || importedQualifiedName == "requests" -> "requests"
            qualified.startsWith("flask.") || importedQualifiedName == "flask" -> "flask"
            else -> null
        }
        if (optionalModule != null && installedPackages != null &&
            !PythonEnvironmentRegistry.moduleAvailableFromPackages(optionalModule, installedPackages)
        ) return null
        val entry = moduleDocs[qualified]
            ?: moduleDocs["$owner.$name"]
            ?: importedQualifiedName?.let { moduleDocs[it] }
            ?: builtins[name]
        if (entry != null) {
            val isModuleMember = qualified in moduleDocs || "$owner.$name" in moduleDocs ||
                (importedQualifiedName?.let { it in moduleDocs } == true)
            val kind = if (isModuleMember) "METHOD" else "BUILTIN"
            return PythonHoverDoc(name, kind, entry.signature, entry.summary, entry.details)
        }

        val moduleName = importedQualifiedName?.takeIf { !it.contains('.') }
        if (moduleName != null) {
            val moduleSummary = when (moduleName) {
                "math" -> "Mathematical functions and constants."
                "numpy" -> "Numerical computing with multidimensional arrays."
                "pandas" -> "Data analysis tools and labeled data structures."
                "cv2" -> "OpenCV computer-vision and image-processing module."
                "pygame" -> "Modules for multimedia and game development."
                "json" -> "Encode and decode JSON data."
                "os" -> "Portable operating-system interfaces."
                "sys" -> "Interpreter and runtime-specific facilities."
                "time" -> "Time access and conversions."
                "random" -> "Generate pseudo-random values."
                "requests" -> "HTTP library for sending network requests."
                "flask" -> "Lightweight web application framework."
                else -> "Imported Python module."
            }
            return PythonHoverDoc(name, "MODULE", moduleName, moduleSummary)
        }
        return null
    }

    private fun nextLineStart(source: String, from: Int): Int {
        val newline = source.indexOf('\n', from.coerceIn(0, source.length))
        return if (newline < 0) source.length else newline + 1
    }

    private fun findFollowingDocstring(source: String, from: Int, definitionIndent: Int): String {
        val rest = source.substring(from.coerceIn(0, source.length))
        val lines = rest.lineSequence().take(8).toList()
        for (line in lines) {
            if (line.isBlank()) continue
            val indent = line.takeWhile { it == ' ' || it == '\t' }.length
            if (indent <= definitionIndent) return ""
            val content = line.trim()
            val quote = when {
                content.startsWith("\"\"\"") -> "\"\"\""
                content.startsWith("'''") -> "'''"
                content.startsWith('"') -> "\""
                content.startsWith('\'') -> "'"
                else -> return ""
            }
            val after = content.removePrefix(quote)
            val closing = after.indexOf(quote)
            return (if (closing >= 0) after.substring(0, closing) else after).trim()
        }
        return ""
    }

    private fun isIdentifier(char: Char?): Boolean = char != null && (char == '_' || char.isLetterOrDigit())
}
