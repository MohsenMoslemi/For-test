package com.codespace.ide.ide

import android.content.Context
import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import android.content.SharedPreferences
import com.codespace.ide.ide.run.RunOrchestrator
import com.codespace.ide.ide.terminal.TermController
import kotlinx.coroutines.delay
import com.codespace.ide.ide.runtimeui.RuntimeUiViewModel

/**
 * Owns the IDE-root background observers that reconcile external runtime
 * activity with the Activity-scoped presentation state. It deliberately
 * receives narrow ports/callbacks: it cannot launch processes, mutate editor
 * sessions, or own the run registry.
 */
@Composable
internal fun IdeRootRuntimeEffects(
    hubVersion: Int,
    context: Context,
    notificationPermission: ManagedActivityResultLauncher<String, Boolean>,
    notificationPreferences: SharedPreferences,
    runOrchestrator: RunOrchestrator,
    consoleRunId: Int,
    consoleLive: Boolean,
    consoleRunning: Boolean,
    consoleController: TermController,
    runtimeUiViewModel: RuntimeUiViewModel,
    endTerminalRun: (String) -> Unit,
) {
    // Ask only after a run starts, and persist the one-time prompt decision.
    LaunchedEffect(hubVersion) {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            runOrchestrator.running().isNotEmpty() &&
            !notificationPreferences.getBoolean("asked", false) &&
            context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            notificationPreferences.edit().putBoolean("asked", true).apply()
            try {
                notificationPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            } catch (_: Exception) {
            }
        }
    }

    // Observe the rendered Console transcript; never send input or restart it.
    LaunchedEffect(consoleRunId, consoleLive, consoleRunning) {
        if (!consoleLive || !consoleRunning) return@LaunchedEffect
        while (true) {
            try {
                val tail = consoleController.transcriptTail?.invoke()
                val found = tail?.let { latestServingUrl(it) }
                if (!found.isNullOrBlank() && found != runtimeUiViewModel.state.value.webLiveUrl) {
                    runtimeUiViewModel.setWebLiveUrl(found)
                }
            } catch (_: Exception) {
            }
            delay(if (runtimeUiViewModel.state.value.webLiveUrl != null) 5000 else 750)
        }
    }

    // Reconcile terminal processes whose PTY vanished without delivering done.
    LaunchedEffect(Unit) {
        while (true) {
            delay(3000)
            for (run in runOrchestrator.running()) {
                if (run.source == "Console" || run.pid <= 1) continue
                val dead = try {
                    android.system.Os.kill(run.pid, 0)
                    false
                } catch (error: android.system.ErrnoException) {
                    error.errno == android.system.OsConstants.ESRCH
                } catch (_: Exception) {
                    false
                }
                if (dead) endTerminalRun(run.id)
            }
        }
    }
}
