package com.codespace.ide.ide.editor

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.text.input.TextFieldValue
import com.codespace.ide.ide.codeintel.PythonCompletion
import com.codespace.ide.ide.codeintel.PythonCompletionItem
import com.codespace.ide.ide.codeintel.PythonLspController
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Owns the edit-driven completion request lifecycle for one editor buffer.
 * The editor supplies state and setters; request sequencing and stale-result
 * checks stay together here so UI composition does not own LSP orchestration.
 */
@Composable
internal fun EditorCompletionEffect(
    file: File,
    field: TextFieldValue,
    isPythonLanguage: Boolean,
    showCompletionPopup: Boolean,
    editorLanguage: String,
    completionEditVersion: Int,
    completionTriggerCaret: Int,
    lastLspCompletionEditVersion: Int,
    environmentRevision: Long,
    lastLspCompletionEnvironmentRevision: Long,
    currentItems: List<PythonCompletionItem>,
    controller: PythonLspController?,
    onItemsChanged: (List<PythonCompletionItem>) -> Unit,
    onRangeChanged: (Pair<Int, Int>) -> Unit,
    onLastEditVersionChanged: (Int) -> Unit,
    onLastEnvironmentRevisionChanged: (Long) -> Unit
) {
    val latestField = rememberUpdatedState(field)
    LaunchedEffect(
        file.absolutePath, completionEditVersion, environmentRevision,
        field.selection.start, showCompletionPopup, editorLanguage
    ) {
        if (!isPythonLanguage || !showCompletionPopup) {
            onItemsChanged(emptyList())
            return@LaunchedEffect
        }
        onItemsChanged(currentItems.filterNot { it.autoImportStatement != null })
        val requestedText = field.text
        val cursor = field.selection.start.coerceIn(0, requestedText.length)
        if (!field.selection.collapsed || requestedText.isBlank()) {
            onItemsChanged(emptyList())
            return@LaunchedEffect
        }

        var tokenStart = cursor
        while (tokenStart > 0 && (requestedText[tokenStart - 1].isLetterOrDigit() || requestedText[tokenStart - 1] == '_')) tokenStart--
        var tokenEnd = cursor
        while (tokenEnd < requestedText.length && (requestedText[tokenEnd].isLetterOrDigit() || requestedText[tokenEnd] == '_')) tokenEnd++

        if (PythonCompletion.isInsideStringOrComment(requestedText, cursor)) {
            onItemsChanged(emptyList())
            return@LaunchedEffect
        }

        val hasNewTextEdit = completionEditVersion > lastLspCompletionEditVersion
        val environmentChanged = environmentRevision != lastLspCompletionEnvironmentRevision
        if (!hasNewTextEdit || cursor != completionTriggerCaret) {
            if (hasNewTextEdit) onLastEditVersionChanged(completionEditVersion)
            onItemsChanged(emptyList())
            onRangeChanged(cursor to cursor)
            return@LaunchedEffect
        }

        if (hasNewTextEdit) delay(90)
        val afterDebounce = latestField.value
        if (afterDebounce.text != requestedText || !afterDebounce.selection.collapsed || afterDebounce.selection.start != cursor) {
            return@LaunchedEffect
        }
        // This effect is keyed by the selection and edit generation; Compose
        // cancels it when either changes, preventing a stale response winning.
        val installedPackages = controller?.installedPackagesSnapshot()
        val exactAutoImports = withContext(Dispatchers.Default) {
            PythonCompletion.autoImportSuggestionsForIdentifier(
                source = requestedText,
                tokenStart = tokenStart,
                tokenEnd = tokenEnd,
                installedPackages = installedPackages,
                projectRoot = controller?.projectRoot
            )
        }

        val isImportCompletion = EditorCompletionCandidates.isImportContext(requestedText, cursor)
        val localResult = withContext(Dispatchers.Default) {
            PythonCompletion.complete(requestedText, cursor, installedPackages, controller?.projectRoot)
        }
        val lspResult = if (isImportCompletion) null else controller?.complete(file, requestedText, cursor)
        val result = when {
            isImportCompletion -> localResult
            lspResult == null -> localResult
            localResult == null -> lspResult
            else -> lspResult.copy(items = EditorCompletionCandidates.mergeRanked(lspResult.items + localResult.items))
        }
        val explicitMemberContext = requestedText.substring(0, cursor).trimEnd().endsWith('.')
        val candidatePrefix = requestedText.substring(tokenStart, cursor)
        val filteredItems = EditorCompletionCandidates.filterForContext(
            result?.items.orEmpty(), candidatePrefix, explicitMemberContext
        )
        val finalField = latestField.value
        if (finalField.text != requestedText || !finalField.selection.collapsed || finalField.selection.start != cursor) {
            return@LaunchedEffect
        }
        if (result != null) {
            onRangeChanged(
                if (exactAutoImports.isNotEmpty()) tokenStart to tokenEnd
                else result.replaceStart to result.replaceEnd
            )
            onItemsChanged(EditorCompletionCandidates.mergeRanked(filteredItems + exactAutoImports))
        } else {
            onItemsChanged(exactAutoImports)
            if (exactAutoImports.isNotEmpty()) onRangeChanged(tokenStart to tokenEnd)
        }
        if (hasNewTextEdit) onLastEditVersionChanged(completionEditVersion)
        if (environmentChanged) onLastEnvironmentRevisionChanged(environmentRevision)
    }
}
