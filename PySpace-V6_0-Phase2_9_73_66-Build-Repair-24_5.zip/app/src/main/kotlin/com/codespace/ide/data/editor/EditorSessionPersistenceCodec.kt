package com.codespace.ide.data.editor

import com.codespace.ide.domain.editor.model.EditorSessionSnapshot
import org.json.JSONArray
import org.json.JSONObject
import com.codespace.ide.ide.JSON

/** JSON persistence adapter for editor session snapshots. */
object EditorSessionPersistenceCodec {
    fun encode(snapshot: EditorSessionSnapshot): String {
        val tabs = JSONArray()
        snapshot.tabs.forEach { tab ->
            tabs.put(JSONObject()
                .put("p", tab.path)
                .put("y", tab.scrollY)
                .put("x", tab.scrollX)
                .put("s", tab.selectionStart)
                .put("e", tab.selectionEnd)
                .put("v", tab.hasView))
        }
        return JSONObject().put("active", snapshot.activeIndex).put("tabs", tabs).toString()
    }
}
