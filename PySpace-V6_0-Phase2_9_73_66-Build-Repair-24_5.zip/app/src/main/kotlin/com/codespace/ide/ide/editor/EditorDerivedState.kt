package com.codespace.ide.ide.editor

import com.codespace.ide.ide.codeintel.PythonSyntaxDiagnostic

/**
 * Pure derived-state helpers used by PyEditor. Keeping these calculations
 * outside the composable makes their invariants independently verifiable.
 */
internal object EditorDerivedState {
    /**
     * Builds an immutable prefix index where entry i is the first visual row
     * of logical display line i. A null result means wrapping is disabled.
     */
    fun visualRowPrefix(lineRows: List<Int>): IntArray? {
        if (lineRows.isEmpty()) return null
        return IntArray(lineRows.size + 1).also { prefix ->
            for (index in lineRows.indices) {
                prefix[index + 1] = prefix[index] + lineRows[index].coerceAtLeast(1)
            }
        }
    }

    /** Resolves a display-line index to its first visual row in O(1). */
    fun firstVisualRow(displayLineIndex: Int, prefix: IntArray?): Int {
        if (prefix == null) return displayLineIndex.coerceAtLeast(0)
        return prefix[displayLineIndex.coerceIn(0, prefix.lastIndex)]
    }

    /**
     * Diagnostics are hidden for non-Python files. While the buffer differs
     * from the validated source, only diagnostics on the actively edited line
     * are suppressed; diagnostics on other lines remain visible.
     */
    fun visibleDiagnostics(
        isPythonLanguage: Boolean,
        validatedSource: String?,
        currentSource: String,
        editingLine: Int?,
        diagnostics: List<PythonSyntaxDiagnostic>
    ): List<PythonSyntaxDiagnostic> {
        if (!isPythonLanguage) return emptyList()
        if (validatedSource == currentSource) return diagnostics
        return diagnostics.filterNot { it.line == editingLine }
    }

    fun diagnosticOnLine(
        diagnostics: List<PythonSyntaxDiagnostic>,
        zeroBasedLine: Int
    ): PythonSyntaxDiagnostic? = diagnostics.firstOrNull { it.line == zeroBasedLine }
}
