package com.codespace.ide.ide.camera

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.util.Size
import androidx.activity.result.ActivityResultLauncher
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.UseCase
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.lifecycle.LifecycleOwner
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import kotlin.text.Charsets
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.OutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------------------
// Phone camera → Python bridge.
//
// The guest (PRoot Ubuntu) shares the host network namespace, so a localhost
// HTTP server started by the app is reachable from guest Python as
// http://127.0.0.1:PORT — no JNI, no extra dependencies, no changes to the
// PTY/run pipeline. CameraX produces YUV frames, they are JPEG-encoded once,
// and Python pulls them (single-frame mailbox: old frames are dropped, never
// queued) via /frame.jpg, /stream.mjpg (real cv2.VideoCapture URL) or the
// bundled phone_camera helper module.
//
// Privacy rules (enforced here, not in the UI):
// - No permission → no camera, ever. Every start path checks first.
// - One session at a time; duplicate starts are ignored.
// - Camera stops on: run end, UI stop, Python close(), app background.
// - The HTTP server binds 127.0.0.1 only (never 0.0.0.0).
// ---------------------------------------------------------------------------

/** Fixed-first localhost port range; falls back to an ephemeral port. */
private const val CAM_PORT_FIRST = 18080
private const val CAM_PORT_LAST = 18089
private const val CAM_JPEG_QUALITY = 60
private const val CAM_TARGET_W = 640
private const val CAM_TARGET_H = 480
/** No frame for this long while bound → ERROR (revoked permission, busy…). */
private const val CAM_FRAME_TIMEOUT_MS = 5000L

enum class CamState {
    IDLE, NEEDS_PERMISSION, DENIED, CONNECTING, READY, STREAMING, STOPPED, ERROR
}

/** Human status line for every state (UI shows state + this, never color alone). */
fun camStateTitle(s: CamState): String = when (s) {
    CamState.IDLE -> "Idle — camera not started"
    CamState.NEEDS_PERMISSION -> "Waiting for permission"
    CamState.DENIED -> "Permission denied"
    CamState.CONNECTING -> "Connecting…"
    CamState.READY -> "Ready — waiting for first frame"
    CamState.STREAMING -> "Streaming frames"
    CamState.STOPPED -> "Stopped — resources released"
    CamState.ERROR -> "Error"
}

class PhoneCamera(
    private val context: Context,
    private val appScope: CoroutineScope
) {
    private val appCtx: Context = context.applicationContext

    var state by androidx.compose.runtime.mutableStateOf(CamState.IDLE)
    var statusMsg by androidx.compose.runtime.mutableStateOf("Camera has not been started yet.")
    var front by androidx.compose.runtime.mutableStateOf(false)
    var frameW by androidx.compose.runtime.mutableStateOf(0)
    var frameH by androidx.compose.runtime.mutableStateOf(0)
    var rotationDeg by androidx.compose.runtime.mutableStateOf(0)
    var fps by androidx.compose.runtime.mutableStateOf(0)
    var clients by androidx.compose.runtime.mutableStateOf(0)
    var hasFront by androidx.compose.runtime.mutableStateOf(false)
    var lastError by androidx.compose.runtime.mutableStateOf<String?>(null)
    /** Bumped on every fresh frame (UI preview polls this, max ~2/s). */
    var frameVersion by androidx.compose.runtime.mutableStateOf(0)
    /** Guest dir holding the cv2 adapter (null = could not be installed). */
    var shimDir by androidx.compose.runtime.mutableStateOf<String?>(null)
    /** Every analyzer invocation, even ones that yield no frame (diagnostics). */
    var analyzerCalls by androidx.compose.runtime.mutableStateOf(0)

    /** Latest JPEG frame (single mailbox — old frames are dropped). */
    @Volatile var latestJpeg: ByteArray? = null
    @Volatile private var lastFrameMs = 0L
    @Volatile private var bindMs = 0L
    @Volatile private var sessionStartMs = 0L
    @Volatile private var serverPort = -1
    @Volatile private var serverSocket: ServerSocket? = null
    @Volatile private var provider: ProcessCameraProvider? = null
    @Volatile private var runGen = 0

    private var analyzerExec: java.util.concurrent.ExecutorService? = null
    // GPU viewfinder (CameraX Preview) shares the SAME session as the frame
    // analysis: the tab gets a smooth hardware-composited preview while
    // Python keeps receiving the CPU frames in parallel. Display-only — it
    // never touches the bridge.
    private var analysisUse: ImageAnalysis? = null
    private var boundSelector: CameraSelector? = null
    private var boundOwner: LifecycleOwner? = null
    @Volatile private var surfaceProvider: Preview.SurfaceProvider? = null
    // Encode scratch buffers, reused every frame (the analyzer is single-
    // threaded): avoids an IntArray + stream alloc per frame, i.e. less GC
    // stutter in the stream.
    private var packedReuse: IntArray? = null
    private var outReuse: IntArray? = null
    private var bosReuse: ByteArrayOutputStream? = null
    private var askedOnce = false
    private var pendingFront = false
    private var uiOwner: LifecycleOwner? = null
    private var uiActivity: Activity? = null
    private val clientCount = AtomicInteger(0)
    private var fpsWinStart = 0L
    private var fpsWinCount = 0

    val url: String? get() = serverPort.takeIf { it > 0 }?.let { "http://127.0.0.1:$it" }
    val serverUp: Boolean get() = serverPort > 0

    fun sessionSeconds(): Long {
        val s = sessionStartMs
        if (s <= 0L) return 0L
        return ((System.currentTimeMillis() - s) / 1000L).coerceAtLeast(0L)
    }

    // ---------------- permission ----------------

    fun hasPermission(): Boolean {
        return try {
            appCtx.checkSelfPermission(Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        } catch (_: Exception) {
            false
        }
    }

    private fun shouldShowRationale(): Boolean {
        return try {
            uiActivity?.shouldShowRequestPermissionRationale(Manifest.permission.CAMERA) == true
        } catch (_: Exception) {
            false
        }
    }

    /** Called from composition so guest-triggered starts have an owner. */
    fun attachUi(owner: LifecycleOwner?, activity: Activity?) {
        if (owner != null) uiOwner = owner
        if (activity != null) uiActivity = activity
    }

    fun refreshPermissionState() {
        if (state == CamState.NEEDS_PERMISSION || state == CamState.DENIED) {
            if (hasPermission()) {
                state = CamState.IDLE
                statusMsg = "Permission granted — press Start."
                lastError = null
            }
        }
    }

    fun onPermissionResult(granted: Boolean) {
        if (granted) {
            state = CamState.IDLE
            statusMsg = "Permission granted — starting camera…"
            lastError = null
            startInternal(pendingFront)
        } else {
            state = CamState.DENIED
            lastError = "Camera permission denied."
            statusMsg = if (!shouldShowRationale() && askedOnce) {
                "Permission denied permanently — enable it in Android Settings, then retry."
            } else {
                "Permission denied — press Start to ask again."
            }
        }
    }

    /** UI Start button (or retry). Never touches the camera without permission. */
    fun startFromUi(wantFront: Boolean, launcher: ActivityResultLauncher<String>) {
        pendingFront = wantFront
        if (hasPermission()) {
            startInternal(wantFront)
            return
        }
        askedOnce = true
        state = CamState.NEEDS_PERMISSION
        statusMsg = "Camera permission is needed — showing the system dialog…"
        try {
            launcher.launch(Manifest.permission.CAMERA)
        } catch (t: Throwable) {
            state = CamState.ERROR
            lastError = "Could not ask for permission: ${t.message}"
            statusMsg = lastError ?: "Error"
        }
    }

    /**
     * Run-button path: permission is already granted (checked by the caller)
     * and an active session is left untouched. Starts the last-used facing.
     */
    fun autoStartForRun() {
        if (!hasPermission()) return
        if (state == CamState.CONNECTING || state == CamState.READY ||
            state == CamState.STREAMING
        ) {
            return
        }
        startInternal(front)
    }

    // ---------------- camera session (single) ----------------

    @Synchronized
    private fun startInternal(wantFront: Boolean) {
        val busy = state == CamState.CONNECTING || state == CamState.READY ||
            state == CamState.STREAMING
        // Same camera already flowing: ignore the duplicate start.
        if (busy && front == wantFront && state != CamState.CONNECTING) {
            return // one session at a time; ignore duplicate starts
        }
        // Fresh (re)start: kill anything in flight and drop the old binding
        // first. This also makes a facing switch DURING connect work (guest
        // VideoCapture(1) while back is still opening used to be ignored).
        if (busy) stopRun("Switching camera…")
        if (!hasPermission()) {
            state = CamState.NEEDS_PERMISSION
            statusMsg = "Grant the camera permission first."
            return
        }
        val owner = uiOwner
        if (owner == null) {
            state = CamState.ERROR
            lastError = "No UI owner yet — open the Camera tab once, then retry."
            statusMsg = lastError ?: "Error"
            return
        }
        front = wantFront
        state = CamState.CONNECTING
        statusMsg = if (wantFront) "Opening front camera…" else "Opening back camera…"
        lastError = null
        val gen = ++runGen
        appScope.launch(Dispatchers.IO) {
            try {
                val p = ProcessCameraProvider.getInstance(appCtx).get()
                if (gen != runGen) return@launch
                provider = p
                try {
                    hasFront = p.hasCamera(
                        CameraSelector.Builder()
                            .requireLensFacing(CameraSelector.LENS_FACING_FRONT).build()
                    )
                } catch (_: Exception) {
                }
                val sel = CameraSelector.Builder().requireLensFacing(
                    if (wantFront) CameraSelector.LENS_FACING_FRONT
                    else CameraSelector.LENS_FACING_BACK
                ).build()
                if (!p.hasCamera(sel)) {
                    throw IllegalStateException(
                        if (wantFront) "This device has no front camera."
                        else "This device has no back camera."
                    )
                }
                withContext(Dispatchers.Main) {
                    if (gen != runGen) return@withContext
                    bindLocked(p, sel, owner, gen)
                }
            } catch (t: Throwable) {
                if (gen != runGen) return@launch
                val m = shortErr(t)
                lastError = m
                state = CamState.ERROR
                statusMsg = m
            }
        }
        watchFrames(gen)
    }

    private fun bindLocked(
        p: ProcessCameraProvider,
        sel: CameraSelector,
        owner: LifecycleOwner,
        gen: Int
    ) {
        try {
            p.unbindAll()
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                // RGBA, not YUV: hand-rolled YUV stride math silently drops
                // every frame on devices whose planes are padded differently.
                // RGBA_8888 + Bitmap is the boring, compatible path.
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .setTargetResolution(Size(CAM_TARGET_W, CAM_TARGET_H))
                .build()
            val exec = Executors.newSingleThreadExecutor()
            analyzerExec = exec
            fpsWinStart = System.currentTimeMillis()
            fpsWinCount = 0
            analysis.setAnalyzer(exec) { image -> onFrame(image, gen) }
            analysisUse = analysis
            boundSelector = sel
            boundOwner = owner
            bindUseCasesLocked()
            sessionStartMs = System.currentTimeMillis()
            bindMs = sessionStartMs
            lastFrameMs = 0L
            state = CamState.READY
            statusMsg = "Camera open — waiting for first frame…"
            ensureServer()
        } catch (t: Throwable) {
            val m = shortErr(t)
            lastError = m
            state = CamState.ERROR
            statusMsg = m
        }
    }

    /**
     * (Re)binds the session use-cases: analysis always, Preview only while
     * the tab's viewfinder surface is attached. Caller: Main thread.
     */
    private fun bindUseCasesLocked() {
        val p = provider ?: return
        val sel = boundSelector ?: return
        val owner = boundOwner ?: return
        val an = analysisUse ?: return
        try {
            p.unbindAll()
            val cases = mutableListOf<UseCase>(an)
            val sp = surfaceProvider
            if (sp != null) {
                try {
                    val pv = Preview.Builder().build()
                    pv.setSurfaceProvider(sp)
                    cases.add(pv)
                } catch (_: Exception) {
                    // Stale surface (view gone): analysis continues alone.
                    surfaceProvider = null
                }
            }
            p.bindToLifecycle(owner, sel, *cases.toTypedArray())
        } catch (t: Throwable) {
            val m = shortErr(t)
            lastError = m
            state = CamState.ERROR
            statusMsg = m
        }
    }

    /**
     * Attaches/detaches the GPU viewfinder (called by the tab's PreviewView).
     * Rebinds the live session so preview + analysis share one camera open.
     */
    fun setPreviewProvider(sp: Preview.SurfaceProvider?) {
        surfaceProvider = sp
        val active = state == CamState.CONNECTING || state == CamState.READY ||
            state == CamState.STREAMING
        if (!active || provider == null) return
        appScope.launch(Dispatchers.Main) {
            try {
                bindUseCasesLocked()
            } catch (_: Exception) {
            }
        }
    }

    // ---- demand-driven pipeline -------------------------------------------
    // The camera delivers ~30 fps, but Python usually consumes far fewer. Doing
    // convert + rotate + JPEG for EVERY frame burned CPU the user's program
    // needed (and queued old frames). Now: the analyzer only keeps cheap stats,
    // and copies the raw RGBA frame (one memcpy) while somebody is reading; the
    // JPEG is made on request, from the newest raw frame, by native Bitmap code.
    private val rawLock = Any()
    private val encLock = Any()
    private var rawBuf: ByteArray? = null
    private var rawW = 0
    private var rawH = 0
    private var rawRowBytes = 0
    private var rawRot = 0
    private var rawMirror = false
    @Volatile private var rawVersion = 0
    @Volatile private var demandUntilMs = 0L
    private var jpgCache: ByteArray? = null
    private var jpgCacheVer = -1

    private fun onFrame(image: ImageProxy, gen: Int) {
        try {
            if (gen != runGen) return
            analyzerCalls++
            val w = image.width
            val h = image.height
            if (w <= 0 || h <= 0 || w > 4096 || h > 4096) return
            val now = System.currentTimeMillis()
            lastFrameMs = now
            fpsWinCount++
            if (now - fpsWinStart >= 1000L) {
                fps = fpsWinCount
                fpsWinCount = 0
                fpsWinStart = now
            }
            if (state == CamState.READY || state == CamState.CONNECTING) {
                state = CamState.STREAMING
                statusMsg = "Streaming to Python (localhost)."
            }
            // Nobody reading right now: nothing else to do (no copy, no encode).
            if (now > demandUntilMs) return
            val planes = image.planes
            if (planes.isEmpty()) return
            // RGBA_8888 single plane; rowStride is bytes (may exceed w*4).
            val buf = planes[0].buffer
            val rowBytes = planes[0].rowStride
            if (rowBytes < w * 4) return
            val rot = try {
                image.imageInfo.rotationDegrees
            } catch (_: Exception) {
                0
            }
            synchronized(rawLock) {
                val need = rowBytes * h
                var rb = rawBuf
                if (rb == null || rb.size < need) {
                    rb = ByteArray(need)
                    rawBuf = rb
                }
                buf.rewind()
                buf.get(rb, 0, minOf(need, buf.remaining()))
                rawW = w
                rawH = h
                rawRowBytes = rowBytes
                rawRot = rot
                rawMirror = front
                rawVersion++
            }
            frameVersion++
        } catch (_: Exception) {
        } finally {
            try {
                image.close()
            } catch (_: Exception) {
            }
        }
    }

    /** Raw frame -> upright JPEG (cached per frame version). Native Bitmap ops only. */
    private fun encodeLatest(): Pair<Int, ByteArray>? {
        return synchronized(encLock) {
            var snap: Bitmap? = null
            var rot = 0
            var mirror = false
            var ver = 0
            synchronized(rawLock) {
                val b = rawBuf
                ver = rawVersion
                if (b == null || ver <= 0) return null
                val cached = jpgCache
                if (jpgCacheVer == ver && cached != null) return ver to cached
                val stride = rawRowBytes / 4
                val tmp = Bitmap.createBitmap(stride, rawH, Bitmap.Config.ARGB_8888)
                // RGBA bytes are exactly Bitmap's native ARGB_8888 memory layout.
                tmp.copyPixelsFromBuffer(java.nio.ByteBuffer.wrap(b, 0, rawRowBytes * rawH))
                snap = if (stride != rawW) {
                    val c = Bitmap.createBitmap(tmp, 0, 0, rawW, rawH)
                    if (c !== tmp) tmp.recycle()
                    c
                } else {
                    tmp
                }
                rot = rawRot
                mirror = rawMirror
            }
            val bmp = snap ?: return null
            try {
                val step = (maxOf(bmp.width, bmp.height) + 639) / 640
                val m = android.graphics.Matrix()
                var changed = false
                if (step > 1) {
                    m.postScale(1f / step, 1f / step)
                    changed = true
                }
                if (rot != 0) {
                    m.postRotate(rot.toFloat())
                    changed = true
                }
                if (mirror) {
                    m.postScale(-1f, 1f)
                    changed = true
                }
                val out = if (changed) {
                    Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                } else {
                    bmp
                }
                val bos = ByteArrayOutputStream(out.width * out.height / 5)
                val ok = out.compress(Bitmap.CompressFormat.JPEG, CAM_JPEG_QUALITY, bos)
                if (frameW != out.width || frameH != out.height) {
                    frameW = out.width
                    frameH = out.height
                }
                if (rotationDeg != rot) rotationDeg = rot
                if (out !== bmp) out.recycle()
                if (!ok) return null
                val jpg = bos.toByteArray()
                if (jpg.isEmpty()) return null
                jpgCache = jpg
                jpgCacheVer = ver
                latestJpeg = jpg
                return ver to jpg
            } finally {
                try {
                    bmp.recycle()
                } catch (_: Exception) {
                }
            }
        }
    }

    /**
     * A JPEG of a frame NEWER than [after] (version from a previous call), waiting up to
     * [waitMs] for the camera. Marks "somebody is reading" so the analyzer keeps copying.
     * After an idle period the old raw frame is treated as stale.
     */
    private fun awaitJpeg(after: Int, waitMs: Long): Pair<Int, ByteArray>? {
        val t0 = System.currentTimeMillis()
        val wasIdle = t0 > demandUntilMs
        demandUntilMs = t0 + waitMs + 3000L
        val minVer = if (wasIdle) maxOf(after, rawVersion) else after
        while (true) {
            if (rawVersion > minVer && rawVersion > 0) {
                val r = encodeLatest()
                if (r != null) return r
            }
            if (System.currentTimeMillis() - t0 >= waitMs) return null
            try {
                Thread.sleep(3)
            } catch (_: InterruptedException) {
                return null
            }
        }
    }

    private fun watchFrames(gen: Int) {
        appScope.launch(Dispatchers.IO) {
            while (gen == runGen) {
                delay(2000)
                if (gen != runGen) return@launch
                val s = state
                if (s == CamState.READY || s == CamState.STREAMING) {
                    val last = lastFrameMs
                    if (last > 0L && System.currentTimeMillis() - last > CAM_FRAME_TIMEOUT_MS) {
                        lastError = "Frames stopped — permission may have been revoked " +
                            "or the camera is busy elsewhere. Retry to reconnect."
                        state = CamState.ERROR
                        statusMsg = lastError ?: "Error"
                        try {
                            withContext(Dispatchers.Main) {
                                try {
                                    provider?.unbindAll()
                                } catch (_: Exception) {
                                }
                            }
                        } catch (_: Exception) {
                        }
                        return@launch
                    }
                    // Bound but the device never delivered a single frame:
                    // say so instead of sitting in READY forever.
                    if (last == 0L && System.currentTimeMillis() - bindMs > 8000L) {
                        lastError = "Camera opened but delivered no frames " +
                            "(analyzer calls: $analyzerCalls). Tap Retry; if it " +
                            "repeats, this device's camera needs a different path."
                        state = CamState.ERROR
                        statusMsg = lastError ?: "Error"
                        return@launch
                    }
                } else if (s != CamState.CONNECTING) {
                    return@launch
                }
            }
        }
    }

    /** Ends the camera session but keeps the bridge server (instant restart). */
    fun stopRun(reason: String) {
        runGen++
        val p = provider
        provider = null
        analysisUse = null
        boundSelector = null
        try {
            analyzerExec?.shutdownNow()
        } catch (_: Exception) {
        }
        analyzerExec = null
        if (p != null) {
            appScope.launch(Dispatchers.Main) {
                try {
                    p.unbindAll()
                } catch (_: Exception) {
                }
            }
        }
        latestJpeg = null
        synchronized(rawLock) { rawVersion = 0 }
        jpgCacheVer = -1
        fps = 0
        analyzerCalls = 0
        frameVersion = 0
        sessionStartMs = 0L
        bindMs = 0L
        lastFrameMs = 0L
        if (state == CamState.CONNECTING || state == CamState.READY ||
            state == CamState.STREAMING || state == CamState.ERROR
        ) {
            state = CamState.STOPPED
            statusMsg = reason
        }
    }

    /** Full stop: camera + bridge server (app background / project leave). */
    fun stopAll(reason: String) {
        stopRun(reason)
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
        serverSocket = null
        serverPort = -1
        clients = 0
        clientCount.set(0)
        try {
            camPortFile().delete()
        } catch (_: Exception) {
        }
    }

    // ---------------- localhost bridge server ----------------

    /** Starts the 127.0.0.1 server (no permission needed — no camera touched). */
    @Synchronized
    fun ensureServer(): Int {
        if (serverPort > 0 && serverSocket != null) return serverPort
        var port = -1
        var sock: ServerSocket? = null
        try {
            val loop = InetAddress.getByName("127.0.0.1")
            for (p in CAM_PORT_FIRST..CAM_PORT_LAST) {
                try {
                    sock = ServerSocket(p, 8, loop)
                    port = p
                    break
                } catch (_: Exception) {
                    sock = null
                }
            }
            if (sock == null) {
                sock = ServerSocket(0, 8, loop)
                port = sock.localPort
            }
        } catch (t: Throwable) {
            lastError = "Bridge server failed: ${shortErr(t)}"
            return -1
        }
        serverSocket = sock
        serverPort = port
        writePortFile()
        ensureCameraShim()
        val s = sock ?: return -1
        Thread({
            try {
                while (!s.isClosed) {
                    val c = try {
                        s.accept()
                    } catch (_: Exception) {
                        break
                    }
                    clientCount.incrementAndGet()
                    clients = clientCount.get()
                    Thread({ serveClient(c) }, "cam-client").also {
                        it.isDaemon = true
                        it.start()
                    }
                }
            } catch (_: Exception) {
            }
        }, "cam-accept").also { it.isDaemon = true; it.start() }
        return port
    }

    private fun serveClient(c: Socket) {
        try {
            c.soTimeout = 15000
            val inp = c.getInputStream().bufferedReader(Charsets.US_ASCII)
            val out = c.getOutputStream()
            val reqLine = try {
                inp.readLine() ?: return
            } catch (_: Exception) {
                return
            }
            val parts = reqLine.split(" ")
            if (parts.size < 2) return
            val method = parts[0].uppercase()
            val rawPath = parts[1]
            // Drain headers (we need none; POSTs carry no body).
            try {
                while (true) {
                    val h = inp.readLine() ?: break
                    if (h.isEmpty()) break
                }
            } catch (_: Exception) {
            }
            val path = rawPath.substringBefore("?")
            val query = if ("?" in rawPath) rawPath.substringAfter("?", "") else ""
            when {
                method == "GET" && path == "/health" ->
                    respond(out, 200, "ok", "text/plain")
                method == "GET" && path == "/info" ->
                    respond(out, 200, infoJson(), "application/json")
                method == "GET" && (path == "/frame.jpg" || path == "/frame") -> {
                    // ?after=<version>&wait=<ms>: returns a frame NEWER than `after` (long-poll),
                    // so a reader always gets the newest picture and nothing ever queues.
                    val after = queryParam(query, "after")?.toIntOrNull() ?: -1
                    val waitMs = (queryParam(query, "wait")?.toLongOrNull() ?: 2000L).coerceIn(0L, 8000L)
                    val r = if (state == CamState.STREAMING || state == CamState.READY) {
                        awaitJpeg(after, waitMs)
                    } else {
                        null
                    }
                    if (r != null) {
                        respondBytes(out, 200, r.second, "image/jpeg", "X-Frame-Version: ${r.first}\r\n")
                    } else {
                        respond(out, 503, infoJson(), "application/json")
                    }
                }
                method == "GET" && (path == "/stream.mjpg" || path == "/stream") -> {
                    // Small send buffer: a slow reader must not queue seconds of
                    // old frames in the kernel (the loop below always sends the newest).
                    try { c.sendBufferSize = 48 * 1024 } catch (_: Exception) { }
                    serveMjpeg(out)
                }
                method == "POST" && path == "/start" -> {
                    val facing = queryParam(query, "facing")?.lowercase() ?: "back"
                    handleGuestStart(out, facing == "front")
                }
                method == "POST" && path == "/stop" -> {
                    stopRun("Stopped from Python.")
                    respond(out, 200, infoJson(), "application/json")
                }
                else -> respond(out, 404, "{\"error\":\"unknown endpoint\"}", "application/json")
            }
            try {
                out.flush()
            } catch (_: Exception) {
            }
        } catch (_: Exception) {
        } finally {
            clientCount.decrementAndGet()
            clients = clientCount.get().coerceAtLeast(0)
            try {
                c.close()
            } catch (_: Exception) {
            }
        }
    }

    private fun serveMjpeg(out: OutputStream) {
        try {
            val head = "HTTP/1.0 200 OK\r\n" +
                "Content-Type: multipart/x-mixed-replace; boundary=frame\r\n" +
                "Cache-Control: no-cache\r\n\r\n"
            out.write(head.toByteArray(Charsets.US_ASCII))
            out.flush()
            var sentVer = -1
            var idleLoops = 0
            while (true) {
                val r = if (state == CamState.STREAMING || state == CamState.READY) {
                    awaitJpeg(sentVer, 100L)
                } else {
                    null
                }
                if (r != null) {
                    sentVer = r.first
                    idleLoops = 0
                    val jpg = r.second
                    val part = "--frame\r\nContent-Type: image/jpeg\r\n" +
                        "Content-Length: ${jpg.size}\r\n\r\n"
                    out.write(part.toByteArray(Charsets.US_ASCII))
                    out.write(jpg)
                    out.write("\r\n".toByteArray(Charsets.US_ASCII))
                    out.flush()
                } else {
                    // No fresh frame: wait, don't resend stale data.
                    if (++idleLoops > 600) break
                    try {
                        Thread.sleep(30)
                    } catch (_: InterruptedException) {
                        break
                    }
                }
            }
        } catch (_: Exception) {
            // client went away — normal
        }
    }

    private fun handleGuestStart(out: OutputStream, wantFront: Boolean) {
        if (!hasPermission()) {
            respond(out, 403, infoJson(), "application/json")
            return
        }
        if (uiOwner == null) {
            respond(
                out, 409,
                "{\"error\":\"NO_UI_OWNER\"," +
                    "\"hint\":\"Open the Camera tab once, then retry.\"}",
                "application/json"
            )
            return
        }
        pendingFront = wantFront
        if (state == CamState.STREAMING || state == CamState.READY ||
            state == CamState.CONNECTING
        ) {
            if (front == wantFront) {
                respond(out, 200, infoJson(), "application/json")
                return
            }
            // Facing switch = clean restart of the single session.
            stopRun("Switching camera…")
        }
        startInternal(wantFront)
        // Wait briefly so open() returns the real state, not "connecting".
        var waited = 0
        while (waited < 30 && state == CamState.CONNECTING) {
            try {
                Thread.sleep(100)
            } catch (_: InterruptedException) {
                break
            }
            waited++
        }
        respond(out, 200, infoJson(), "application/json")
    }

    private fun infoJson(): String {
        fun esc(s: String) = s.replace("\\", "\\\\").replace("\"", "\\\"")
            .replace("\n", " ").take(220)
        return "{" +
            "\"state\":\"${state.name}\"," +
            "\"title\":\"${esc(camStateTitle(state))}\"," +
            "\"message\":\"${esc(statusMsg)}\"," +
            "\"facing\":\"${if (front) "front" else "back"}\"," +
            "\"width\":$frameW,\"height\":$frameH,\"rotation\":$rotationDeg," +
            "\"fps\":$fps,\"clients\":${clientCount.get()}," +
            "\"session_sec\":${sessionSeconds()}," +
            "\"has_front\":$hasFront," +
            "\"has_permission\":${hasPermission()}," +
            "\"error\":" + (if (lastError != null) "\"${esc(lastError!!)}\"" else "null") +
            "}"
    }

    private fun respond(out: OutputStream, code: Int, body: String, type: String) {
        respondBytes(out, code, body.toByteArray(Charsets.UTF_8), type)
    }

    private fun respondBytes(out: OutputStream, code: Int, body: ByteArray, type: String, extra: String = "") {
        val status = when (code) {
            200 -> "OK"
            403 -> "Forbidden"
            404 -> "Not Found"
            409 -> "Conflict"
            else -> "Unavailable"
        }
        val head = "HTTP/1.0 $code $status\r\nContent-Type: $type\r\n" +
            "Content-Length: ${body.size}\r\nCache-Control: no-cache\r\n" + extra +
            "Connection: close\r\n\r\n"
        out.write(head.toByteArray(Charsets.US_ASCII))
        out.write(body)
    }

    private fun queryParam(query: String, key: String): String? {
        for (part in query.split("&")) {
            val k = part.substringBefore("=").trim()
            if (k.equals(key, ignoreCase = true)) {
                return try {
                    URLDecoder.decode(part.substringAfter("=", ""), "UTF-8")
                } catch (_: Exception) {
                    part.substringAfter("=", "")
                }
            }
        }
        return null
    }

    // Guest /tmp is the host proot-ubuntu-tmp dir (same name as ProotManager).
    // Lets plain `python3 script.py` in the terminal use the camera without
    // the Run button: the helper reads this file when the env var is absent.
    private fun camPortFile(): File {
        return File(File(appCtx.filesDir, "proot-ubuntu-tmp"), "phone_camera.url")
    }

    // Guest path of the cv2 adapter (host file written below).
    private fun shimFile(): File {
        return File(File(appCtx.filesDir, "ubuntu-rootfs/opt/ide-camera"), "sitecustomize.py")
    }

    /**
     * Writes the cv2 adapter once (version-gated). It makes
     * cv2.VideoCapture(0/1) open the real phone camera instead of the
     * nonexistent /dev/video0 — release()/read()/isOpened() all stay real.
     * Loaded only in camera runs (see cameraRunPrefix); other runs and plain
     * terminal interpreters never see it unless the user exports PYTHONPATH.
     *
     * Tries /opt first, then /tmp (the app-owned proot tmp, always
     * writable). Returns the guest dir, or null when NEITHER worked — the
     * caller must surface that instead of failing silently.
     */
    private fun ensureCameraShim(): String? {
        val wrote = writeShimFile(shimFile()) ||
            writeShimFile(tmpShimFile())
        val dir = when {
            isShimOk(shimFile()) -> "/opt/ide-camera"
            isShimOk(tmpShimFile()) -> "/tmp/ide-camera"
            else -> null
        }
        if (!wrote || dir == null) {
            lastError = "Could not install the cv2 adapter " +
                "(VideoCapture(0) will not work). Tap Retry."
            if (state == CamState.IDLE || state == CamState.STOPPED) {
                statusMsg = lastError ?: "Error"
            }
        }
        shimDir = dir
        return dir
    }

    private fun tmpShimFile(): File {
        return File(File(appCtx.filesDir, "proot-ubuntu-tmp/ide-camera"), "sitecustomize.py")
    }

    private fun isShimOk(f: File): Boolean {
        return try {
            f.isFile && f.readText().contains(PHONE_CAMERA_SHIM_VERSION)
        } catch (_: Exception) {
            false
        }
    }

    private fun writeShimFile(f: File): Boolean {
        return try {
            if (isShimOk(f)) return true
            f.parentFile?.mkdirs()
            f.writeText(PHONE_CAMERA_SITECUSTOMIZE_SOURCE)
            isShimOk(f)
        } catch (_: Exception) {
            false
        }
    }

    private fun writePortFile() {
        try {
            val f = camPortFile()
            f.parentFile?.mkdirs()
            val u = url ?: return
            f.writeText(u + "\n")
        } catch (_: Exception) {
        }
    }

    /** ABGR int (little-endian RGBA bytes) → ARGB int. */
    private fun swapRB(p: Int): Int {
        val a = p and 0xFF000000.toInt()
        val r = p and 0xFF
        val g = (p ushr 8) and 0xFF
        val b = (p ushr 16) and 0xFF
        return a or b or (g shl 8) or (r shl 16)
    }

    private fun shortErr(t: Throwable): String {        val base = (t.message ?: t.javaClass.simpleName).trim().take(160)
        return if (base.isEmpty()) t.javaClass.simpleName else base
    }
}

// ---------------------------------------------------------------------------
// Run integration is handled by domain/camera source policy and CameraRunCommandFactory.
// Added ONLY when camera markers are found — other runs are byte-identical.
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Bundled Python side: the cv2.VideoCapture adapter (sitecustomize).
// Written into the project on demand (Copy stays host-side: project.dir is a
// host path). Pure stdlib except read(), which needs numpy+opencv.
// ---------------------------------------------------------------------------

private const val PHONE_CAMERA_SHIM_VERSION = "ide-camera-shim-v4"

val PHONE_CAMERA_SITECUSTOMIZE_SOURCE = """
# ide-camera-shim-v4 — cv2.VideoCapture(0/1) opens the REAL phone camera.
# Auto-loaded only when PYTHONPATH includes /opt/ide-camera (camera runs).
# Anything else (URLs, other indexes) behaves exactly like stock OpenCV.
import os as _os
import com.codespace.ide.ProotManager
import com.codespace.ide.ide.run.CameraRunCommandFactory


def _cam_base():
    u = (_os.environ.get("PHONE_CAMERA_URL") or "").strip().rstrip("/")
    if u:
        return u
    try:
        with open("/tmp/phone_camera.url") as _f:
            u = _f.read().strip().rstrip("/")
            if u:
                return u
    except OSError:
        pass
    return None


def _cam_post(path):
    import urllib.request as _req
    base = _cam_base()
    if base is None:
        return None
    try:
        _r = _req.Request(base + path, data=b"", method="POST")
        with _req.urlopen(_r, timeout=15) as _resp:
            return _resp.status
    except Exception:
        return None


try:
    import cv2 as _cv2mod
    _RealVC = _cv2mod.VideoCapture


    class VideoCapture(_RealVC):
        # 0 = back camera, 1 = front camera (starts it if needed).
        # Phone-camera reads are PULL requests to the IDE: each read() asks for
        # "a frame newer than the last one" and gets the NEWEST picture. Nothing
        # queues, so a slow loop never sees old frames, and the IDE only converts
        # and encodes the frames that are really read (idle = zero cost).
        def __init__(self, src=0, *args, **kwargs):
            self._pull = False
            if isinstance(src, bool):
                super().__init__(src, *args, **kwargs)
                return
            base = None
            if isinstance(src, int) and src in (0, 1):
                _cam_post("/start?facing=" + ("front" if src == 1 else "back"))
                base = _cam_base()
            elif isinstance(src, str) and "/stream.mjpg" in src:
                base = src.split("/stream.mjpg")[0]
            if base is not None:
                super().__init__()
                self._pull_init(base)
                return
            super().__init__(src, *args, **kwargs)

        def _pull_init(self, base):
            self._pull = True
            self._base = base
            self._after = -1
            self._w = 0
            self._h = 0
            self._grabbed = None
            self._pending = self._fetch(6.0)
            self._open = self._pending is not None

        def _fetch(self, timeout=3.0):
            import urllib.request
            import numpy as np
            url = "%s/frame.jpg?after=%d&wait=%d" % (self._base, self._after, int(timeout * 1000))
            try:
                with urllib.request.urlopen(url, timeout=timeout + 2.0) as r:
                    ver = int(r.headers.get("X-Frame-Version", "-1"))
                    data = r.read()
            except Exception:
                return None
            if ver >= 0:
                self._after = ver
            fr = _cv2mod.imdecode(np.frombuffer(data, np.uint8), _cv2mod.IMREAD_COLOR)
            if fr is not None:
                self._h, self._w = fr.shape[0], fr.shape[1]
            return fr

        def _next(self):
            if self._pending is not None:
                fr = self._pending
                self._pending = None
                return fr
            if not self._open:
                return None
            return self._fetch(3.0)

        def isOpened(self):
            if self._pull:
                return bool(self._open)
            return super().isOpened()

        def read(self, *args, **kwargs):
            if not self._pull:
                return super().read(*args, **kwargs)
            fr = self._next()
            if fr is None:
                return False, None
            return True, fr

        def grab(self):
            if not self._pull:
                return super().grab()
            self._grabbed = self._next()
            return self._grabbed is not None

        def retrieve(self, *args, **kwargs):
            if not self._pull:
                return super().retrieve(*args, **kwargs)
            return (self._grabbed is not None), self._grabbed

        def get(self, prop):
            if not self._pull:
                return super().get(prop)
            if prop == _cv2mod.CAP_PROP_FRAME_WIDTH:
                return float(self._w)
            if prop == _cv2mod.CAP_PROP_FRAME_HEIGHT:
                return float(self._h)
            if prop == _cv2mod.CAP_PROP_FPS:
                return 30.0
            return 0.0

        def set(self, prop, value):
            if not self._pull:
                return super().set(prop, value)
            return True

        def release(self):
            if self._pull:
                self._open = False
                self._pending = None
                return None
            return super().release()


    _cv2mod.VideoCapture = VideoCapture
except Exception:
    pass

# Chain to the frame-view shim (imshow without X11) when this run uses it.
try:
    import ide_view_shim as _ide_view_shim
except Exception:
    pass
"""
