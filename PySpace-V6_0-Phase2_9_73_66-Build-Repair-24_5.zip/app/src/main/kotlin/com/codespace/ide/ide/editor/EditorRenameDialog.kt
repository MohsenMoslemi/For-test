package com.codespace.ide.ide.editor

import java.io.File
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ide.IdeAlertDialog
import com.codespace.ide.ide.theme.IdeTheme
import com.codespace.ide.ide.codeintel.PythonReferenceOccurrence
import com.codespace.ide.ide.codeintel.PythonReferenceKind

/** Presentation-only dialog for reviewing and confirming a project-wide symbol rename. */
@Composable
internal fun EditorRenameDialog(
    title: String,
    value: String,
    onValueChange: (String) -> Unit,
    originalName: String,
    projectRoot: File?,
    occurrences: List<PythonReferenceOccurrence>,
    previewMessage: String,
    resultMessage: String,
    busy: Boolean,
    progress: Float,
    progressStage: String,
    canCancel: Boolean,
    canConfirm: Boolean,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
    onCancel: () -> Unit
) {
    IdeAlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = Color(IdeTheme.TEXT)) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    singleLine = true,
                    enabled = !busy,
                    label = { Text("New name") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = {})
                )
                Spacer(Modifier.height(10.dp))
                Text(if (busy) progressStage else previewMessage, color = Color(IdeTheme.DIM), fontSize = 11.sp)
                if (busy) {
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { progress.coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(IdeTheme.ACCENT),
                        trackColor = Color(IdeTheme.LINE)
                    )
                    Text("${(progress * 100).toInt()}%", modifier = Modifier.align(Alignment.End), color = Color(IdeTheme.DIM), fontSize = 10.sp)
                }
                if (occurrences.isNotEmpty()) {
                    val callCount = occurrences.count { it.kind == com.codespace.ide.ide.codeintel.PythonReferenceKind.CALL }
                    val importCount = occurrences.count { it.kind == com.codespace.ide.ide.codeintel.PythonReferenceKind.IMPORT }
                    val definitionCount = occurrences.count { it.kind == com.codespace.ide.ide.codeintel.PythonReferenceKind.DEFINITION }
                    val otherCount = occurrences.count { it.kind == com.codespace.ide.ide.codeintel.PythonReferenceKind.OTHER }
                    Text(
                        text = buildString {
                            append("Calls: $callCount  ·  Imports: $importCount  ·  Definition: $definitionCount")
                            if (otherCount > 0) append("  ·  Other: $otherCount")
                            append("\nTotal rename locations: ${occurrences.size}")
                        },
                        color = Color(IdeTheme.TEXT), fontSize = 11.sp, lineHeight = 16.sp
                    )
                    Spacer(Modifier.height(6.dp))
                    LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 230.dp)) {
                        items(occurrences) { occurrence ->
                            Column(modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                                val displayPath = runCatching {
                                    val root = requireNotNull(projectRoot).canonicalFile
                                    val target = occurrence.file.canonicalFile
                                    val relative = target.relativeTo(root).invariantSeparatorsPath
                                    require(relative != ".." && !relative.startsWith("../"))
                                    "/${root.name}/${relative.trimStart('/')}"
                                }.getOrDefault("/${occurrence.file.name}")
                                Text("$displayPath:${occurrence.line}", color = Color(IdeTheme.ACCENT), fontSize = 11.sp, maxLines = 1)
                                Text(occurrence.snippet.ifBlank { originalName }, color = Color(IdeTheme.TEXT), fontSize = 11.sp, maxLines = 2)
                            }
                            HorizontalDivider(color = Color(IdeTheme.LINE))
                        }
                    }
                }
                if (resultMessage.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(resultMessage, color = Color(IdeTheme.WARN), fontSize = 11.sp)
                }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && canConfirm, onClick = onConfirm) {
                Text(if (busy) "Refactoring…" else "Refactor", fontSize = 13.sp, color = Color(IdeTheme.ACCENT))
            }
        },
        dismissButton = {
            TextButton(enabled = if (busy) canCancel else true, onClick = onCancel) {
                Text(if (busy) "Cancel operation" else "Cancel", color = Color(IdeTheme.DIM))
            }
        }
    )
}
