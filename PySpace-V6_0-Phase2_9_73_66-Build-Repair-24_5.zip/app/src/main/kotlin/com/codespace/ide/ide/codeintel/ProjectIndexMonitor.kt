package com.codespace.ide.ide.codeintel

import android.os.FileObserver
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Live, project-scoped Python workspace index monitor.
 *
 * It maintains a lightweight symbol-oriented snapshot for every Python source
 * file and updates only files whose content or identity changed. Directory
 * observers catch changes made by the editor, terminal, Python processes and
 * external file managers. All disk work runs on a dedicated serial worker.
 */
class ProjectIndexMonitor(private val root: File) : AutoCloseable {
    data class Activity(val time: Long, val message: String, val kind: String)
    data class State(
        val status: Status = Status.IDLE,
        val scannedFiles: Int = 0,
        val totalFiles: Int = 0,
        val indexedFiles: Int = 0,
        val addedFiles: Int = 0,
        val updatedFiles: Int = 0,
        val removedFiles: Int = 0,
        val reusedFiles: Int = 0,
        val currentFile: String = "",
        val lastCompletedAt: Long = 0L,
        val message: String = "Waiting to index",
        val activities: List<Activity> = emptyList(),
        val error: String? = null
    )
    enum class Status { IDLE, INDEXING, READY, ERROR }
    private data class Snapshot(val hash: String, val bytes: Long, val modified: Long, val lines: Int, val definitions: Int, val imports: Int)

    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "PySpace-ProjectIndex").apply { isDaemon = true } }
    private val handler = Handler(Looper.getMainLooper())
    private val closed = AtomicBoolean(false)
    private val scheduled = AtomicBoolean(false)
    private val observers = ArrayList<FileObserver>()
    private val snapshots = LinkedHashMap<String, Snapshot>()
    private val mutableState = MutableStateFlow(State())
    val state: StateFlow<State> = mutableState.asStateFlow()
    @Volatile private var started = false

    fun start() {
        if (closed.get() || started) return
        started = true
        worker.execute {
            attachObservers()
            scan(full = true, reason = "Project opened")
        }
    }

    fun rebuild() {
        if (closed.get()) return
        worker.execute { scan(full = true, reason = "Manual rebuild") }
    }

    private fun onFsEvent(event: Int, relative: String?) {
        if (closed.get()) return
        val name = relative?.takeIf { it.isNotBlank() } ?: "project structure"
        val structural = event and (FileObserver.CREATE or FileObserver.DELETE or FileObserver.MOVED_FROM or FileObserver.MOVED_TO or FileObserver.DELETE_SELF or FileObserver.MOVE_SELF) != 0
        handler.removeCallbacks(refreshRunnable)
        pendingLabel = name
        pendingStructural = pendingStructural || structural
        handler.postDelayed(refreshRunnable, 450L)
    }

    @Volatile private var pendingLabel = "project files"
    @Volatile private var pendingStructural = false
    private val refreshRunnable = Runnable {
        if (!closed.get() && scheduled.compareAndSet(false, true)) {
            val label = pendingLabel
            val structural = pendingStructural
            pendingStructural = false
            worker.execute {
                try {
                    if (structural) attachObservers()
                    scan(full = false, reason = "Change detected: $label")
                } finally { scheduled.set(false) }
            }
        }
    }

    @Synchronized private fun attachObservers() {
        if (closed.get()) return
        observers.forEach { runCatching { it.stopWatching() } }
        observers.clear()
        if (!root.isDirectory) return
        val stack = ArrayDeque<File>()
        val visited = HashSet<String>()
        stack.add(root)
        while (stack.isNotEmpty() && observers.size < MAX_DIRECTORIES) {
            val dir = stack.removeLast()
            val canonical = runCatching { dir.canonicalPath }.getOrDefault(dir.absolutePath)
            if (!visited.add(canonical)) continue
            runCatching {
                val observer = object : FileObserver(dir.absolutePath, MASK) {
                    override fun onEvent(event: Int, path: String?) {
                        if (event and MASK != 0) onFsEvent(event, path)
                    }
                }
                observer.startWatching()
                observers.add(observer)
            }
            val children = runCatching { dir.listFiles() }.getOrNull() ?: continue
            children.filter { it.isDirectory && !it.name.startsWith(".") && it.name !in EXCLUDED && !isSymlink(it) }
                .forEach { stack.add(it) }
        }
    }

    private fun scan(full: Boolean, reason: String) {
        if (closed.get()) return
        val old = LinkedHashMap(snapshots)
        val candidates = ArrayList<File>()
        var directoriesVisited = 0
        val stack = ArrayDeque<File>()
        stack.add(root)
        while (stack.isNotEmpty() && candidates.size < MAX_FILES) {
            if (closed.get()) return
            val dir = stack.removeLast()
            directoriesVisited++
            val children = runCatching { dir.listFiles() }.getOrNull() ?: continue
            for (child in children) {
                if (child.isDirectory) {
                    if (!child.name.startsWith(".") && child.name !in EXCLUDED && !isSymlink(child)) stack.add(child)
                } else if (child.isFile && (child.extension.equals("py", true) || child.extension.equals("pyi", true))) {
                    if (child.length() <= MAX_FILE_BYTES) candidates.add(child)
                }
            }
        }
        val total = candidates.size
        val next = LinkedHashMap<String, Snapshot>(total)
        val activities = mutableState.value.activities.toMutableList()
        var added = 0; var updated = 0; var reused = 0; var processed = 0
        updateState { it.copy(status = Status.INDEXING, scannedFiles = 0, totalFiles = total,
            indexedFiles = old.size, addedFiles = 0, updatedFiles = 0, removedFiles = 0,
            reusedFiles = 0, currentFile = "", message = reason, error = null) }
        val engineResult = try {
            kotlinx.coroutines.runBlocking {
                WorkspacePythonReferenceIndex.refreshWorkspace(root, onProgress = { done, count, current ->
                    updateState { currentState ->
                        val log = Activity(System.currentTimeMillis(), "Scanning $current", "progress")
                        currentState.copy(status = Status.INDEXING, scannedFiles = done, totalFiles = count,
                            currentFile = current, message = "Indexing $current",
                            activities = (listOf(log) + currentState.activities).take(80))
                    }
                })
            }
        } catch (t: Throwable) {
            updateState { it.copy(status = Status.ERROR, message = "Indexing failed", error = t.message ?: "Unknown indexing error") }
            return
        }
        if (!engineResult.complete) {
            updateState { it.copy(status = Status.ERROR, indexedFiles = engineResult.filesIndexed,
                reusedFiles = engineResult.filesReused, message = "Indexing incomplete", error = engineResult.reason) }
            return
        }
        candidates.forEachIndexed { index, file ->
            if (closed.get()) return
            val path = runCatching { file.canonicalPath }.getOrDefault(file.absolutePath)
            val length = file.length()
            val modified = file.lastModified()
            val previous = old[path]
            val snapshot = if (!full && previous != null && previous.bytes == length && previous.modified == modified) {
                reused++
                previous
            } else {
                val source = runCatching { file.readText(Charsets.UTF_8) }.getOrNull()
                if (source == null) {
                    updateState { it.copy(currentFile = file.name, message = "Unable to read ${file.name}") }
                    return@forEachIndexed
                }
                val hash = sha256(source)
                if (previous != null && previous.hash == hash) {
                    reused++
                    previous.copy(bytes = length, modified = modified)
                } else {
                    if (previous == null) added++ else updated++
                    val defCount = DEF_REGEX.findAll(source).count()
                    val importCount = IMPORT_REGEX.findAll(source).count()
                    Snapshot(hash, length, modified, source.count { it == '\n' } + if (source.isEmpty()) 0 else 1, defCount, importCount)
                }
            }
            next[path] = snapshot
            processed++
            if (index % 8 == 0 || index == total - 1) {
                updateState { it.copy(scannedFiles = processed, totalFiles = total, indexedFiles = next.size,
                    addedFiles = added, updatedFiles = updated, reusedFiles = reused,
                    currentFile = file.name, message = "Indexing ${file.name}") }
            }
        }
        val removed = old.keys.count { it !in next }
        snapshots.clear(); snapshots.putAll(next)
        if (added + updated + removed > 0) {
            activities.add(0, Activity(System.currentTimeMillis(), "$reason · +$added  ~${updated}  −$removed", "change"))
        } else if (activities.isEmpty() || full) {
            activities.add(0, Activity(System.currentTimeMillis(), "${next.size} Python files checked; no changes", "info"))
        }
        activities.add(0, Activity(System.currentTimeMillis(), "Indexed ${next.size} Python files", "success"))
        updateState { it.copy(status = Status.READY, scannedFiles = processed, totalFiles = total,
            indexedFiles = next.size, addedFiles = added, updatedFiles = updated, removedFiles = removed,
            reusedFiles = reused, currentFile = "", lastCompletedAt = System.currentTimeMillis(),
            message = "Indexing completed", activities = activities.take(80), error = null) }
    }

    private inline fun updateState(transform: (State) -> State) { mutableState.value = transform(mutableState.value) }
    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    private fun isSymlink(file: File): Boolean = runCatching { java.nio.file.Files.isSymbolicLink(file.toPath()) }.getOrDefault(false)

    @Synchronized override fun close() {
        if (!closed.compareAndSet(false, true)) return
        handler.removeCallbacksAndMessages(null)
        observers.forEach { runCatching { it.stopWatching() } }
        observers.clear()
        worker.shutdownNow()
    }

    companion object {
        private const val MAX_DIRECTORIES = 1200
        private const val MAX_FILES = 12000
        private const val MAX_FILE_BYTES = 1024L * 1024L
        private val EXCLUDED = setOf(".git", ".venv", "venv", "env", "__pycache__", "node_modules", "build", "dist", ".tox", ".mypy_cache", ".pytest_cache", ".ruff_cache", "site-packages", ".gradle", ".idea")
        private val DEF_REGEX = Regex("(?m)^\\s*(?:async\\s+)?def\\s+[A-Za-z_][A-Za-z0-9_]*|^\\s*class\\s+[A-Za-z_][A-Za-z0-9_]*")
        private val IMPORT_REGEX = Regex("(?m)^\\s*(?:from\\s+[^\\n]+\\s+import|import\\s+[^\\n]+)")
        private val MASK = FileObserver.CREATE or FileObserver.DELETE or FileObserver.MOVED_FROM or FileObserver.MOVED_TO or FileObserver.CLOSE_WRITE or FileObserver.ATTRIB or FileObserver.DELETE_SELF or FileObserver.MOVE_SELF
    }
}
