package com.codespace.ide.ide.editor

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue

/** Applies one-shot commands from toolbars, symbol bars, structure and search panels. */
@Composable
fun EditorExternalEditEffects(
    tab: OpenTab,
    field: TextFieldValue,
    onFieldChange: (TextFieldValue) -> Unit,
    tabWidth: Int,
    editorCommand: Pair<String, String>?,
    onEditorCommandConsumed: (Pair<String, String>) -> Unit,
    insertRequest: String?,
    onInsertConsumed: () -> Unit,
    jumpRequest: Pair<String, Int>?,
    onJumpConsumed: () -> Unit,
    onFlashLineChange: (Int?) -> Unit,
    reportCursor: (line: Int, column: Int, center: Boolean) -> Unit,
) {
    LaunchedEffect(editorCommand, tab.file.absolutePath) {
        val command = editorCommand ?: return@LaunchedEffect
        if (command.first != tab.file.absolutePath) {
            onEditorCommandConsumed(command)
            return@LaunchedEffect
        }
        val snapshot = when (command.second) {
            "undo" -> tab.undo(field.selection.start, field.selection.end)
            "redo" -> tab.redo(field.selection.start, field.selection.end)
            else -> null
        }
        if (snapshot != null) {
            val start = snapshot.selectionStart.coerceIn(0, snapshot.text.length)
            val end = snapshot.selectionEnd.coerceIn(0, snapshot.text.length)
            onFieldChange(TextFieldValue(snapshot.text, TextRange(start, end)))
            val location = lineColAt(snapshot.text, start)
            onFlashLineChange(null)
            reportCursor(location[0], location[1], false)
        }
        onEditorCommandConsumed(command)
    }

    LaunchedEffect(insertRequest, tab.file.absolutePath) {
        val requested = insertRequest ?: return@LaunchedEffect
        val insertion = if (requested == "TAB") " ".repeat(tabWidth) else requested
        val cursor = field.selection.start.coerceIn(0, field.text.length)
        val updated = field.text.substring(0, cursor) + insertion + field.text.substring(cursor)
        tab.applyEdit(updated, field.selection.start, field.selection.end)
        val newCursor = cursor + insertion.length
        onFieldChange(TextFieldValue(updated, TextRange(newCursor)))
        reportCursor(lineColAt(updated, newCursor)[0], 0, false)
        onInsertConsumed()
    }

    LaunchedEffect(jumpRequest, tab.file.absolutePath) {
        val request = jumpRequest ?: return@LaunchedEffect
        if (request.first != tab.file.absolutePath) return@LaunchedEffect
        val offset = offsetOfLineEnd(tab.text, request.second).coerceIn(0, field.text.length)
        val updated = TextFieldValue(field.text, TextRange(offset))
        onFieldChange(updated)
        val location = lineColAt(updated.text, offset)
        onFlashLineChange(location[0])
        reportCursor(location[0], location[1], true)
        onJumpConsumed()
    }
}
