package com.codespace.ide.ide.codeintel

import android.content.Context
import com.codespace.ide.ProotManager
import com.codespace.ide.runtime.RuntimeAssetCipher
import java.io.File
import java.util.zip.ZipInputStream

/** Provisions the encrypted, universal debugpy wheel into the persistent Ubuntu rootfs. */
object PythonDebugRuntimeInstaller {
    private const val ASSET = "runtime/dbg.psr"
    private const val VERSION = "1.8.22"
    private const val READY = ".debugpy-$VERSION-ready"

    /** Must be called on an IO dispatcher. Idempotent and serialized against concurrent starts. */
    @Synchronized
    fun ensureInstalled(context: Context, proot: ProotManager): Boolean {
        val rootfs = File(context.filesDir, "ubuntu-rootfs")
        val base = File(rootfs, "opt/pyspace-debugger")
        val site = File(base, "site-packages")
        val marker = File(base, READY)
        if (marker.isFile && File(site, "debugpy/__init__.py").isFile) return true

        val staging = File(base, "site-packages.installing")
        val wheel = File(base, "debugpy-$VERSION.whl.part")
        return try {
            if (!base.exists() && !base.mkdirs()) return false
            marker.delete()
            staging.deleteRecursively()
            wheel.delete()
            RuntimeAssetCipher.openAsset(context, ASSET).use { input ->
                wheel.outputStream().buffered().use { output -> input.copyTo(output) }
            }
            if (!wheel.isFile || wheel.length() < 1_000_000L) throw IllegalStateException("Invalid bundled debugpy wheel")
            if (!staging.mkdirs()) throw IllegalStateException("Cannot create debugger staging directory")
            ZipInputStream(wheel.inputStream().buffered()).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    val name = entry.name.replace('\\', '/')
                    if (name.startsWith("/") || name.split('/').any { it == ".." }) {
                        throw IllegalStateException("Unsafe debugpy wheel entry")
                    }
                    val out = File(staging, name)
                    if (entry.isDirectory) {
                        if (!out.isDirectory && !out.mkdirs()) throw IllegalStateException("Cannot create debugger package directory")
                    } else {
                        out.parentFile?.let { if (!it.isDirectory && !it.mkdirs()) throw IllegalStateException("Cannot create debugger package parent") }
                        out.outputStream().buffered().use { target -> zip.copyTo(target) }
                    }
                    zip.closeEntry()
                }
            }
            if (!File(staging, "debugpy/__init__.py").isFile ||
                !File(staging, "debugpy-${VERSION}.dist-info/METADATA").isFile) {
                throw IllegalStateException("Bundled debugpy package is incomplete")
            }
            site.deleteRecursively()
            if (!staging.renameTo(site)) throw IllegalStateException("Cannot activate debugger package")
            wheel.delete()
            marker.writeText("debugpy=$VERSION\nsource=dbg.psr\n")
            // Verify against the project's selected interpreter without installing into its venv.
            val verify = proot.runOnce(
                "PYTHONPATH=/opt/pyspace-debugger/site-packages \"${'$'}{PYSPACE_DEBUG_PYTHON:-/usr/bin/python3}\" -c 'import debugpy; print(debugpy.__version__)'",
                timeoutSec = 20
            )
            // The system interpreter check is only a provisioning sanity check; project compatibility
            // is checked again with that project's own interpreter at launch.
            if (!verify.contains("1.8.22") || !verify.contains("[exit=0]") || !marker.isFile) {
                marker.delete()
                false
            } else true
        } catch (_: Exception) {
            wheel.delete()
            staging.deleteRecursively()
            marker.delete()
            false
        }
    }
}
