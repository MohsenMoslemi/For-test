package com.codespace.ide.data.notebook

import com.codespace.ide.domain.notebook.contract.NotebookParser
import com.codespace.ide.domain.notebook.factory.NotebookSnapshotFactory
import com.codespace.ide.domain.notebook.model.NbCellSnapshot
import com.codespace.ide.domain.notebook.model.NbDocSnapshot
import com.codespace.ide.domain.notebook.model.NbOutputSnapshot
import org.json.JSONArray
import org.json.JSONObject
import com.codespace.ide.ide.JSON

/** nbformat JSON input adapter. No Compose, Android UI, or mutable UI models are created here. */
class JsonNotebookParser : NotebookParser {
    override fun parse(source: String): NbDocSnapshot? {
        if (source.isBlank()) return emptyNotebook()
        val root = try {
            JSONObject(source)
        } catch (_: Exception) {
            return null
        }
        val cellsJson = root.optJSONArray("cells") ?: return null
        val cells = ArrayList<NbCellSnapshot>(cellsJson.length())
        val minor = root.optInt("nbformat_minor", 5)
        var anyId = false

        for (index in 0 until cellsJson.length()) {
            val cell = cellsJson.optJSONObject(index) ?: continue
            val type = cell.optString("cell_type", "code")
            val extra = JSONObject()
            val keys = cell.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                if (key != "cell_type" && key != "source" && key != "outputs" &&
                    key != "execution_count" && key != "id"
                ) {
                    extra.put(key, cell.get(key))
                }
            }

            val rawId = cell.optString("id", "")
            if (rawId.isNotEmpty()) anyId = true
            val outputs = ArrayList<NbOutputSnapshot>()
            val outputsJson = cell.optJSONArray("outputs")
            if (type == "code" && outputsJson != null) {
                for (outputIndex in 0 until outputsJson.length()) {
                    val output = outputsJson.optJSONObject(outputIndex) ?: continue
                    when (output.optString("output_type")) {
                        "stream" -> outputs.add(
                            NbOutputSnapshot(
                                kind = "stream",
                                name = output.optString("name", "stdout"),
                                text = joinLines(output.opt("text")),
                                data = emptyMap(), ename = "", evalue = "", execCount = null,
                            )
                        )
                        "error" -> {
                            val traceback = output.optJSONArray("traceback") ?: JSONArray()
                            val text = buildString {
                                for (i in 0 until traceback.length()) append(traceback.optString(i)).append('\n')
                            }.trimEnd('\n')
                            outputs.add(
                                NbOutputSnapshot(
                                    kind = "error", name = "stdout", text = text, data = emptyMap(),
                                    ename = output.optString("ename"), evalue = output.optString("evalue"), execCount = null,
                                )
                            )
                        }
                        "display_data", "execute_result" -> {
                            val dataJson = output.optJSONObject("data") ?: JSONObject()
                            val data = LinkedHashMap<String, String>()
                            val dataKeys = dataJson.keys()
                            while (dataKeys.hasNext()) {
                                val key = dataKeys.next()
                                data[key] = joinLines(dataJson.get(key))
                            }
                            val count = if (output.has("execution_count") && !output.isNull("execution_count")) {
                                output.optInt("execution_count")
                            } else null
                            outputs.add(
                                NbOutputSnapshot(
                                    kind = if (output.optString("output_type") == "execute_result") "result" else "display",
                                    name = "stdout", text = "", data = data, ename = "", evalue = "", execCount = count,
                                )
                            )
                        }
                    }
                }
            }

            val executionCount = if (cell.has("execution_count") && !cell.isNull("execution_count")) {
                cell.optInt("execution_count")
            } else null
            cells.add(
                NbCellSnapshot(
                    id = rawId.ifEmpty(NotebookSnapshotFactory::newCellId),
                    type = type,
                    source = joinLines(cell.opt("source")),
                    execCount = executionCount,
                    extraJson = extra.toString(),
                    outputs = outputs,
                )
            )
        }

        if (cells.isEmpty()) {
            cells.add(NotebookSnapshotFactory.emptyNotebook().cells.first())
        }
        val metadata = root.optJSONObject("metadata") ?: JSONObject()
        return NbDocSnapshot(cells, metadata.toString(), root.optInt("nbformat", 4), minor, anyId || minor >= 5)
    }

    private fun emptyNotebook(): NbDocSnapshot = NotebookSnapshotFactory.emptyNotebook()

    private fun joinLines(value: Any?): String = when (value) {
        is JSONArray -> buildString {
            for (index in 0 until value.length()) append(value.optString(index))
        }
        null, JSONObject.NULL -> ""
        else -> value.toString()
    }


}
