package com.codespace.ide.ide.filetree

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import com.codespace.ide.ide.codeintel.CodeIntelligenceViewModel
import com.codespace.ide.ide.codeintel.TextSearchOptions
import com.codespace.ide.ide.editor.EditorSession
import com.codespace.ide.ide.codeintel.CODE_SEARCH_MEMBERS
import com.codespace.ide.ide.codeintel.CODE_SEARCH_SYMBOLS
import com.codespace.ide.ide.codeintel.CODE_SEARCH_TEXT
import com.codespace.ide.ide.theme.IdeTheme

/** Drawer search: Symbols / Members / Text modes with match-count groups.
 *  Tapping any hit opens the file at that line (with a flash highlight). */
@Composable
internal fun SearchTab(
    session: EditorSession,
    viewModel: CodeIntelligenceViewModel,
    onJumpToLine: (File, Int) -> Unit
) {
    var q by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(CODE_SEARCH_TEXT) }
    var matchCase by remember { mutableStateOf(false) }
    var wholeWord by remember { mutableStateOf(false) }
    var useRegex by remember { mutableStateOf(false) }
    val dir = session.project.dir
    val tick = session.treeVersion
    val searchState by viewModel.search.collectAsState()
    androidx.compose.runtime.DisposableEffect(viewModel) {
        onDispose { viewModel.clearSearch() }
    }
    LaunchedEffect(q, mode, matchCase, wholeWord, useRegex, dir, tick) {
        viewModel.search(
            root = dir,
            query = q,
            mode = mode,
            options = TextSearchOptions(matchCase, wholeWord, useRegex),
        )
    }
    val textHits = searchState.textHits
    val symHits = searchState.symbolHits
    val badPattern = searchState.invalidPattern
    CompositionLocalProvider(LocalContentColor provides Color(IdeTheme.TEXT)) {
    Column(Modifier.fillMaxSize()) {
        Text(
            "Search", fontWeight = FontWeight.Bold, fontSize = 15.sp,
            color = Color(IdeTheme.TEXT),
            modifier = Modifier.padding(start = 16.dp, top = 12.dp, end = 12.dp)
        )
        OutlinedTextField(
            value = q, onValueChange = { q = it },
            placeholder = { Text("Search…") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
        )
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SearchChip("‹›", "Symbols", mode == CODE_SEARCH_SYMBOLS) { mode = CODE_SEARCH_SYMBOLS }
            SearchChip("▦", "Members", mode == CODE_SEARCH_MEMBERS) { mode = CODE_SEARCH_MEMBERS }
            SearchChip("❏", "Text", mode == CODE_SEARCH_TEXT) { mode = CODE_SEARCH_TEXT }
        }
        if (mode == CODE_SEARCH_TEXT) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SearchChip("Aa", "", matchCase) { matchCase = !matchCase }
                SearchChip("\\b", "", wholeWord) { wholeWord = !wholeWord }
                SearchChip(".*", "", useRegex) { useRegex = !useRegex }
            }
        } else {
            Spacer(Modifier.height(8.dp))
        }
        if (q.length < 2) {
            Text(
                "Type at least 2 characters to search.",
                color = Color(IdeTheme.DIM), fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().padding(24.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        } else if (mode == CODE_SEARCH_TEXT) {
            if (searchState.searching) {
                androidx.compose.material3.CircularProgressIndicator(
                    modifier = Modifier.padding(24.dp).size(22.dp), strokeWidth = 2.dp
                )
            } else if (badPattern) {
                Text(
                    "Bad pattern.", color = Color(IdeTheme.ERROR), fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            } else if (textHits.isEmpty()) {
                Text(
                    "No matches.", color = Color(IdeTheme.DIM), fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    textHits.forEach { (f, ms) ->
                        item(key = f.absolutePath) {
                            Row(
                                Modifier.fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                FileBadge(f, isDirectory = false)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    f.name, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f), maxLines = 1
                                )
                                CountCircle(ms.size)
                            }
                        }
                        ms.forEach { m ->
                            item(key = f.absolutePath + ":" + m.line) {
                                Row(
                                    Modifier
                                    .fillMaxWidth()
                                    .clickable { onJumpToLine(f, m.line) }
                                    .padding(start = 16.dp, end = 12.dp, top = 5.dp, bottom = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        m.line.toString(), color = Color(IdeTheme.DIM),
                                        fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                                        modifier = Modifier.width(36.dp), maxLines = 1
                                    )
                                    MatchText(m.text, m.start, m.end)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (searchState.searching) {
                androidx.compose.material3.CircularProgressIndicator(
                    modifier = Modifier.padding(24.dp).size(22.dp), strokeWidth = 2.dp
                )
            } else if (symHits.isEmpty()) {
                Text(
                    "No matches.", color = Color(IdeTheme.DIM), fontSize = 12.sp,
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    symHits.forEach { (f, ss) ->
                        item(key = f.absolutePath) {
                            Row(
                                Modifier.fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                FileBadge(f, isDirectory = false)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    f.name, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f), maxLines = 1
                                )
                                CountCircle(ss.size)
                            }
                        }
                        ss.forEach { s ->
                            item(key = f.absolutePath + ":" + s.line + ":" + s.name) {
                                Row(
                                    Modifier
                                    .fillMaxWidth()
                                    .clickable { onJumpToLine(f, s.line) }
                                    .padding(start = 16.dp, end = 12.dp, top = 5.dp, bottom = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    LetterBadge(
                                        s.kind.toString(),
                                        when (s.kind) {
                                            'C' -> 0xFFFF9E57
                                            'm' -> 0xFFB39DDB
                                            else -> IdeTheme.TEAL
                                        }
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        s.name, fontSize = 13.sp,
                                        modifier = Modifier.weight(1f), maxLines = 1
                                    )
                                    if (s.detail.isNotEmpty()) {
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            s.detail, color = Color(IdeTheme.DIM),
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace, maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    }
}

/** Rounded filter chip (mode + toggle chips in the Search tab). */
@Composable
internal fun SearchChip(glyph: String, label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
        .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
        .background(if (selected) Color(IdeTheme.VIOLET) else Color(IdeTheme.CARD))
        .clickable(onClick = onClick)
        .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (glyph.isNotEmpty()) {
            Text(
                glyph, fontSize = 12.sp,
                color = if (selected) Color(IdeTheme.ON_VIOLET) else Color(IdeTheme.DIM)
            )
            if (label.isNotEmpty()) Spacer(Modifier.width(6.dp))
        }
        if (label.isNotEmpty()) {
            Text(
                label, fontSize = 13.sp, maxLines = 1,
                color = if (selected) Color(IdeTheme.ON_VIOLET) else Color(IdeTheme.TEXT)
            )
        }
    }
}

/** Dark count circle for grouped search results. */
@Composable
internal fun CountCircle(n: Int) {
    Box(
        Modifier
        .size(22.dp)
        .clip(androidx.compose.foundation.shape.RoundedCornerShape(11.dp))
        .background(Color(IdeTheme.CARD)),
        contentAlignment = Alignment.Center
    ) {
        Text(n.toString(), color = Color(IdeTheme.DIM), fontSize = 11.sp)
    }
}

/** One result line with the matched span tinted. */
@Composable
internal fun MatchText(text: String, start: Int, end: Int) {
    val s = start.coerceIn(0, text.length)
    val e = end.coerceIn(s, text.length)
    val ann = remember(text, s, e) {
        androidx.compose.ui.text.AnnotatedString.Builder().apply {
            append(text.substring(0, s))
            pushStyle(
                androidx.compose.ui.text.SpanStyle(color = Color(IdeTheme.LILAC))
            )
            append(text.substring(s, e))
            pop()
            append(text.substring(e))
        }.toAnnotatedString()
    }
    Text(ann, fontSize = 12.sp, fontFamily = FontFamily.Monospace, maxLines = 1)
}
