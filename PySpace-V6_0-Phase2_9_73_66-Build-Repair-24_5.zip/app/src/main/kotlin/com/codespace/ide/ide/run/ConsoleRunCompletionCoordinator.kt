package com.codespace.ide.ide.run

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.codespace.ide.ide.RunInfo
import com.codespace.ide.ide.camera.PhoneCamera
import com.codespace.ide.ide.runtimeui.RuntimeUiViewModel
import com.codespace.ide.ide.terminal.ConsoleState

/**
 * Applies the ordered side-effects for a Console process that exits by itself.
 * Stop/Rerun invalidation remains owned by the shell/run orchestrator; this
 * collaborator only handles the terminal completion callback.
 */
internal class ConsoleRunCompletionCoordinator(
    private val scope: CoroutineScope,
    private val console: ConsoleState,
    private val currentRun: () -> RunInfo?,
    private val finishRun: (String) -> Unit,
    private val camera: PhoneCamera,
    private val runtimeUi: RuntimeUiViewModel,
    private val command: () -> String?,
    private val generation: () -> Int,
    private val isFrameMode: () -> Boolean,
) {
    fun onProcessDone() {
        // Fires only for a natural process exit; explicit Stop closes the
        // terminal session first and suppresses this callback.
        console.running = false
        currentRun()?.let { finishRun(it.id) }
        try {
            camera.stopRun("Run ended — camera released.")
        } catch (_: Exception) {
        }
        runtimeUi.setWebLiveUrl(null)

        if (command()?.contains("DISPLAY=:1") == true) {
            val completedGeneration = generation()
            scope.launch {
                delay(1_500)
                if (!console.running && generation() == completedGeneration && !isFrameMode()) {
                    runtimeUi.setDisplayOpen(false)
                }
            }
        }
    }
}
