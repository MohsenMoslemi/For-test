package com.codespace.ide.domain.notebook.contract

import com.codespace.ide.domain.notebook.model.NbDocSnapshot

/** Parses nbformat input into an immutable, presentation-independent document. */
interface NotebookParser {
    fun parse(source: String): NbDocSnapshot?
}
