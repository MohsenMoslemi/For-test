package com.codespace.ide

import com.codespace.ide.ide.IdeAlertDialog
import com.codespace.ide.ide.settings.IdePrefs
import com.codespace.ide.ide.theme.IdeTheme
import com.codespace.ide.runtime.RuntimeDispatchers
import com.codespace.ide.di.AppDependencies

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Bundle
import android.os.SystemClock
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitLongPressOrCancellation
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.darkColorScheme
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateOffsetAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.layout.positionInWindow
import kotlin.math.abs
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.offset
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalTextToolbar
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.codespace.ide.ui.install.InstallViewModel
import com.codespace.ide.ide.terminal.TerminalCallbacks
import com.codespace.ide.ide.terminal.TerminalLaunchConfig
import com.codespace.ide.ide.terminal.TerminalViewModel
import com.codespace.ide.ide.terminal.TerminalRepository
import com.codespace.ide.memory.MemoryRuntimePolicy
import org.koin.core.context.GlobalContext
import com.codespace.ide.ide.terminal.TerminalScreenState
import com.codespace.ide.application.editor.usecase.SerializeEditorSessionUseCase
import com.codespace.ide.domain.packages.PackageManagerRepository
import com.codespace.ide.ide.RunHub
import com.codespace.ide.ide.codeintel.CodeIntelligenceRepository
import com.codespace.ide.ide.explorer.FileExplorerRepository
import com.codespace.ide.ide.notebook.NotebookRepository
import com.codespace.ide.ide.projects.ProjectRepository
import com.codespace.ide.ide.run.ProjectWebResolverRepository
import com.codespace.ide.ide.run.RunOrchestrator
import com.codespace.ide.ide.settings.SettingsRepository
import com.codespace.ide.runtime.RuntimeTaskScope

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        IdeTheme.setTheme(IdePrefs(this).themeId)
        window.statusBarColor = Color(IdeTheme.BG).toArgb()
        window.navigationBarColor = Color(IdeTheme.BG).toArgb()
        @Suppress("DEPRECATION")
        val currentFlags = window.decorView.systemUiVisibility
        val lightBarFlags = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = if (IdeTheme.isDark) {
            currentFlags and lightBarFlags.inv()
        } else {
            currentFlags or lightBarFlags
        }
        // Resolve the process graph once, outside Compose. The UI receives a
        // typed dependency bundle instead of reaching into Koin during recomposition.
        val koin = GlobalContext.get()
        val dependencies = AppDependencies(
            ubuntuManager = koin.get<UbuntuManager>(),
            prootManager = koin.get<ProotManager>(),
            runtimeDispatchers = koin.get<RuntimeDispatchers>(),
            notebookRepository = koin.get<com.codespace.ide.ide.notebook.NotebookRepository>(),
            projectRepository = koin.get<com.codespace.ide.ide.projects.ProjectRepository>(),
            settingsRepository = koin.get<com.codespace.ide.ide.settings.SettingsRepository>(),
            runHub = koin.get<com.codespace.ide.ide.RunHub>(),
            runOrchestrator = koin.get<com.codespace.ide.ide.run.RunOrchestrator>(),
            projectWebResolver = koin.get<com.codespace.ide.ide.run.ProjectWebResolverRepository>(),
            runtimeTaskScope = koin.get<com.codespace.ide.runtime.RuntimeTaskScope>(),
            fileExplorerRepository = koin.get<com.codespace.ide.ide.explorer.FileExplorerRepository>(),
            codeIntelligenceRepository = koin.get<com.codespace.ide.ide.codeintel.CodeIntelligenceRepository>(),
            serializeEditorSession = koin.get<com.codespace.ide.application.editor.usecase.SerializeEditorSessionUseCase>(),
            packageManagerRepository = koin.get<com.codespace.ide.domain.packages.PackageManagerRepository>(),
        )
        setContent { UbuntuTerminalApp(dependencies) }
    }
}


