package com.codespace.ide.domain.notebook.contract

import com.codespace.ide.domain.notebook.model.NbDocSnapshot

/** Domain boundary for encoding an immutable notebook document. */
interface NotebookSerializer {
    fun serialize(snapshot: NbDocSnapshot): String
}
