package com.codespace.ide.domain.notebook.model

import java.util.ArrayDeque

/**
 * UI-independent FIFO queue for notebook cell execution.
 *
 * The queue stores stable cell identifiers rather than Compose-backed cell
 * objects. Presentation state (queued/running flags and cell rendering) stays
 * in the notebook presentation layer, while ordering and capacity policy can
 * be exercised independently.
 */
class NotebookExecutionQueue(private val capacity: Int = DEFAULT_CAPACITY) {
    private val cellIds = ArrayDeque<String>()
    private val queuedIds = HashSet<String>()

    val size: Int get() = cellIds.size
    val isEmpty: Boolean get() = cellIds.isEmpty()

    /** Returns false only when capacity is exhausted. Duplicate IDs are ignored. */
    fun enqueue(cellId: String): Boolean {
        if (cellId in queuedIds) return true
        if (cellIds.size >= capacity) return false
        cellIds.addLast(cellId)
        queuedIds.add(cellId)
        return true
    }

    fun poll(): String? {
        val id = cellIds.pollFirst() ?: return null
        queuedIds.remove(id)
        return id
    }

    fun remove(cellId: String): Boolean {
        if (!queuedIds.remove(cellId)) return false
        cellIds.remove(cellId)
        return true
    }

    /** Clears the queue and returns IDs in their former FIFO order. */
    fun clear(): List<String> {
        val removed = cellIds.toList()
        cellIds.clear()
        queuedIds.clear()
        return removed
    }

    companion object {
        const val DEFAULT_CAPACITY = 500
    }
}
