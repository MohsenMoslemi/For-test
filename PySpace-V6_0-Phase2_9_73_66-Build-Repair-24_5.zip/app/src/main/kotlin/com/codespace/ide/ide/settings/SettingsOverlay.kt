package com.codespace.ide.ide.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ProotManager
import com.codespace.ide.domain.packages.PackageManagerRepository
import com.codespace.ide.UbuntuManager
import com.codespace.ide.ide.display.VncDisplay
import com.codespace.ide.ide.projects.ProjectsViewModel
import com.codespace.ide.ide.terminal.TermBridge
import com.codespace.ide.ide.terminal.TermController
import com.codespace.ide.ide.theme.IdeTheme

/** Complete Settings redesign: dashboard cards and dedicated, consistent detail pages. */
@Composable
fun SettingsOverlay(
    settingsViewModel: SettingsViewModel,
    projectsViewModel: ProjectsViewModel,
    ubuntu: com.codespace.ide.UbuntuManager,
    proot: ProotManager,
    packageManagerRepository: PackageManagerRepository,
    bridge: TermBridge,
    display: VncDisplay,
    onClose: () -> Unit
) {
    var section by remember { mutableStateOf<String?>(null) }
    val settings by settingsViewModel.state.collectAsState()
    LaunchedEffect(settingsViewModel, projectsViewModel) {
        settingsViewModel.refresh()
        projectsViewModel.refreshPythonRuntimeStates()
    }
    val runtimeState by projectsViewModel.state.collectAsState()
    val settingsContext = LocalContext.current.applicationContext
    val interpreterRuntimeInUse = IdePrefs(settingsContext).interpreterPythonVersionId
    BackHandler { if (section != null) section = null else onClose() }
    var installCmd by remember { mutableStateOf<String?>(null) }
    var installRunId by remember { mutableStateOf(0) }
    val installCtl = remember { TermController() }
    val categories = listOf(
        Triple("Theme", "◐", "Choose the appearance used throughout PySpace"),
        Triple("Editor", "✎", "Typography, indentation and code display"),
        Triple("Gestures", "⌁", "Touch navigation and editor gestures"),
        Triple("Web preview", "◎", "Choose where running web apps open"),
        Triple("Editor popups", "▣", "Control suggestions, diagnostics and documentation popups"),
        Triple("Display", "▣", "Linux GUI and graphics support"),
        Triple("Packages", "▤", "Manage Python packages for each project"),
        Triple("Environment", "⌘", "Python runtime, interpreters and diagnostics"),
        Triple("Memory & performance", "◉", "Monitor app memory and tune retained caches"),
        Triple("GitHub", "GH", "Connect your GitHub account for all projects"),
        Triple("About", "ⓘ", "App information and build details")
    )
    val accent = Color(IdeTheme.ACCENT)
    CompositionLocalProvider(LocalContentColor provides Color(IdeTheme.TEXT)) {
    Column(Modifier.fillMaxSize().background(Color(IdeTheme.BG)).statusBarsPadding().navigationBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (section != null) {
                Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(Color(IdeTheme.PANEL)).clickable { section = null }, contentAlignment = Alignment.Center) {
                    Text("‹", color = accent, fontSize = 27.sp)
                }
                Spacer(Modifier.width(12.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(if (section == null) "SETTINGS" else "PREFERENCES", color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Text(section ?: "Make it yours", color = Color(IdeTheme.TEXT), fontSize = 23.sp, fontWeight = FontWeight.Bold)
            }
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(Color(IdeTheme.PANEL)).clickable { onClose() }, contentAlignment = Alignment.Center) {
                Text("✕", color = Color(IdeTheme.DIM), fontSize = 16.sp)
            }
        }
        ScreenSlide(dir = if (section == null) -1f else 1f) {
            if (section == null) {
                LazyColumn(
                    Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(11.dp)
                ) {
                    item {
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Color(IdeTheme.PANEL)).padding(18.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(accent.copy(alpha = .16f)), contentAlignment = Alignment.Center) {
                                    Text("P", color = accent, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                                }
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text("PySpace workspace", color = Color(IdeTheme.TEXT), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                    Text("Personalize your development environment", color = Color(IdeTheme.DIM), fontSize = 11.sp)
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Text("Configure your editor, runtime and tools. Changes are applied as you make them.", color = Color(IdeTheme.DIM), fontSize = 12.sp, lineHeight = 18.sp)
                        }
                    }
                    item { SettingsGroupLabel("WORKSPACE") }
                    items(categories.take(5)) { item -> SettingsDashboardItem(item.first, item.second, item.third, accent) { section = item.first } }
                    item { SettingsGroupLabel("RUNTIME & TOOLS") }
                    items(categories.drop(5).take(5)) { item -> SettingsDashboardItem(item.first, item.second, item.third, accent) { section = item.first } }
                    item { SettingsGroupLabel("INFORMATION") }
                    item { SettingsDashboardItem("About", "ⓘ", "App information and build details", accent) { section = "About" } }
                    item { Spacer(Modifier.height(18.dp)) }
                }
            } else if (section == "Packages") {
                Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                    Spacer(Modifier.height(4.dp))
                    SettingsDetailHero(section = "Packages", description = "Install, update and remove Python packages in a selected project environment.", accent = accent)
                    Spacer(Modifier.height(8.dp))
                    if (runtimeState.projects.isEmpty()) {
                        Text("Create a project first to manage its isolated Python packages.", color = Color(IdeTheme.DIM), fontSize = 12.sp)
                    } else {
                        PackagesTab(runtimeState.projects, packageManagerRepository, Modifier.weight(1f))
                    }
                }
            } else {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
                    Spacer(Modifier.height(4.dp))
                    val description = when (section) {
                        "Theme" -> "Choose a coordinated color palette for the entire PySpace interface. Changes apply immediately and are saved automatically."
                        "Editor" -> "Fine-tune the code editing experience and customize the Python symbol shortcut bar."
                        "Editor popups" -> "Choose which contextual editor popups appear while writing code."
                        "Gestures" -> "Control how the editor responds to touch."
                        "Web preview" -> "Set the default destination for your web projects."
                        "Display" -> "Configure graphical applications and Linux display support."
                        "Environment" -> "Manage Python interpreters, verify the runtime and repair essential tools."
                        "Memory & performance" -> "Monitor memory use and control how much temporary IDE data is retained."
                        "GitHub" -> "Manage the app-wide GitHub account used for cloning, importing and publishing projects."
                        else -> "About PySpace and this installation."
                    }
                    SettingsDetailHero(section = section ?: "Settings", description = description, accent = accent)
                    Spacer(Modifier.height(12.dp))
                    when (section) {
                        "Theme" -> ThemeSettingsCard(settings.themeId, settingsViewModel::setThemeId)
                        "Editor" -> {
                            EditorSettingsCard(settings, settingsViewModel)
                            Spacer(Modifier.height(14.dp))
                            EditorSymbolBarSettingsCard(settings, settingsViewModel)
                        }
                        "Editor popups" -> EditorPopupSettingsCard(settings, settingsViewModel)
                        "Gestures" -> GesturesCard(settings, settingsViewModel)
                        "Web preview" -> WebSettingsCard(settings, settingsViewModel)
                        "Display" -> DisplayCard(display, proot, installCmd, installRunId, installCtl) {
                            installCmd = "echo \"installing, please wait....\"; export DEBIAN_FRONTEND=noninteractive; dpkg --configure -a 2>&1; for i in $(seq 1 60); do fuser /var/lib/apt/lists/lock /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock >/dev/null 2>&1 || break; echo \"Waiting for apt lock… (\$i)\"; sleep 5; done; apt-get update && apt-get install -y --no-install-recommends -o Dpkg::Options::=\"--force-confdef\" -o Dpkg::Options::=\"--force-confold\" $GUI_APT_PKGS; echo INSTALL-EXIT:\$?"
                            installRunId++
                        }
                        "Environment" -> {
                            PythonRuntimeSettingsCard(runtimeState, interpreterRuntimeInUse, projectsViewModel::refreshPythonRuntimeStates, projectsViewModel::installPythonRuntime, projectsViewModel::removePythonRuntime, projectsViewModel::cancelPythonRuntimeDownload)
                            Spacer(Modifier.height(14.dp))
                            EnvironmentCard(ubuntu = ubuntu, proot = proot)
                        }
                        "Memory & performance" -> MemorySettingsCard()
                        "GitHub" -> GitHubAccountSettingsCard()
                        "About" -> AboutCard()
                    }
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
    }
}
