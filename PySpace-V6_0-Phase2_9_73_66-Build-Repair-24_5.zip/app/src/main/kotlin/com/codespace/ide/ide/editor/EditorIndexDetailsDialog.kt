package com.codespace.ide.ide.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.codespace.ide.ide.codeintel.ProjectIndexMonitor
import com.codespace.ide.ide.codeintel.PythonEnvironmentIndexMonitor
import com.codespace.ide.ide.theme.IdeTheme

/** Presentation-only details for the project symbol and Python environment indexes. */
@Composable
internal fun EditorIndexDetailsDialog(
    visible: Boolean,
    onDismiss: () -> Unit,
    projectName: String,
    indexState: ProjectIndexMonitor.State,
    indexMonitor: ProjectIndexMonitor,
    environmentIndexState: PythonEnvironmentIndexMonitor.State,
    environmentIndexMonitor: PythonEnvironmentIndexMonitor,
    indexPanelTab: Int,
    onSelectedTabChange: (Int) -> Unit,
    environmentPackageFilter: String,
    onPackageFilterChange: (String) -> Unit
) {
    if (!visible) return
        Dialog(onDismissRequest = { onDismiss() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            androidx.compose.material3.Card(
                modifier = Modifier.fillMaxWidth(0.94f).fillMaxHeight(0.78f),
                shape = RoundedCornerShape(20.dp),
                colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = Color(IdeTheme.PANEL))
            ) {
                Column(Modifier.fillMaxSize().padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Code intelligence indexes", color = Color(IdeTheme.TEXT), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text(projectName, color = Color(IdeTheme.DIM), fontSize = 12.sp)
                        }
                        TextButton(onClick = { onDismiss() }) { Text("Close") }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(11.dp)).background(Color(IdeTheme.CARD)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        androidx.compose.material3.TextButton(
                            onClick = { onSelectedTabChange(0) },
                            modifier = Modifier.weight(1f),
                            colors = androidx.compose.material3.ButtonDefaults.textButtonColors(contentColor = Color(if (indexPanelTab == 0) IdeTheme.ACCENT else IdeTheme.DIM))
                        ) { Text("Project", fontWeight = if (indexPanelTab == 0) FontWeight.Bold else FontWeight.Normal) }
                        androidx.compose.material3.TextButton(
                            onClick = { onSelectedTabChange(1) },
                            modifier = Modifier.weight(1f),
                            colors = androidx.compose.material3.ButtonDefaults.textButtonColors(contentColor = Color(if (indexPanelTab == 1) IdeTheme.ACCENT else IdeTheme.DIM))
                        ) { Text("Python Environment", fontWeight = if (indexPanelTab == 1) FontWeight.Bold else FontWeight.Normal) }
                    }
                    Spacer(Modifier.height(12.dp))
                    if (indexPanelTab == 0) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        if (indexState.status == com.codespace.ide.ide.codeintel.ProjectIndexMonitor.Status.INDEXING || indexState.status == com.codespace.ide.ide.codeintel.ProjectIndexMonitor.Status.IDLE) {
                            androidx.compose.material3.CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.5.dp)
                        } else {
                            Text(if (indexState.status == com.codespace.ide.ide.codeintel.ProjectIndexMonitor.Status.READY) "✓" else "!", color = Color(if (indexState.status == com.codespace.ide.ide.codeintel.ProjectIndexMonitor.Status.READY) 0xFF35B66A else IdeTheme.ERROR), fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text(indexState.message, color = Color(IdeTheme.TEXT), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text(if (indexState.status == com.codespace.ide.ide.codeintel.ProjectIndexMonitor.Status.INDEXING) "${indexState.scannedFiles} of ${indexState.totalFiles} Python files" else "${indexState.indexedFiles} Python files indexed", color = Color(IdeTheme.DIM), fontSize = 11.sp)
                        }
                    }
                    if (indexState.status == com.codespace.ide.ide.codeintel.ProjectIndexMonitor.Status.INDEXING && indexState.totalFiles > 0) {
                        Spacer(Modifier.height(10.dp))
                        LinearProgressIndicator(progress = { (indexState.scannedFiles.toFloat() / indexState.totalFiles.toFloat()).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    }
                    if (indexState.currentFile.isNotBlank()) {
                        Spacer(Modifier.height(7.dp))
                        Text("Processing: ${indexState.currentFile}", color = Color(IdeTheme.ACCENT), fontSize = 11.sp, maxLines = 1)
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IndexMetric("Added", indexState.addedFiles.toString(), Color(0xFF35B66A), Modifier.weight(1f))
                        IndexMetric("Updated", indexState.updatedFiles.toString(), Color(IdeTheme.ACCENT), Modifier.weight(1f))
                        IndexMetric("Removed", indexState.removedFiles.toString(), Color(IdeTheme.ERROR), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(14.dp))
                    Text("Activity", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        items(indexState.activities) { activity ->
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(9.dp)).background(Color(IdeTheme.CARD)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(when (activity.kind) { "success" -> "✓"; "change" -> "↻"; else -> "•" }, color = Color(if (activity.kind == "success") 0xFF35B66A else IdeTheme.ACCENT), fontSize = 14.sp)
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(activity.message, color = Color(IdeTheme.TEXT), fontSize = 11.sp)
                                    Text(java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(activity.time)), color = Color(IdeTheme.DIM), fontSize = 9.sp)
                                }
                            }
                        }
                        if (indexState.activities.isEmpty()) item { Text("No indexing activity yet", color = Color(IdeTheme.DIM), fontSize = 12.sp) }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Cache reused: ${indexState.reusedFiles}", color = Color(IdeTheme.DIM), fontSize = 10.sp)
                        androidx.compose.material3.Button(onClick = { indexMonitor.rebuild() }, enabled = indexState.status != com.codespace.ide.ide.codeintel.ProjectIndexMonitor.Status.INDEXING) { Text("Rebuild index") }
                    }
                    } else {
                        val filteredPackages = environmentIndexState.packages.filter {
                            environmentPackageFilter.isBlank() || it.name.contains(environmentPackageFilter, ignoreCase = true)
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                            if (environmentIndexState.status == com.codespace.ide.ide.codeintel.PythonEnvironmentIndexMonitor.Status.SCANNING) {
                                androidx.compose.material3.CircularProgressIndicator(Modifier.size(21.dp), strokeWidth = 2.3.dp)
                            } else {
                                Text(if (environmentIndexState.status == com.codespace.ide.ide.codeintel.PythonEnvironmentIndexMonitor.Status.READY) "✓" else if (environmentIndexState.status == com.codespace.ide.ide.codeintel.PythonEnvironmentIndexMonitor.Status.ERROR) "!" else "•",
                                    color = Color(if (environmentIndexState.status == com.codespace.ide.ide.codeintel.PythonEnvironmentIndexMonitor.Status.ERROR) IdeTheme.ERROR else 0xFF35B66A), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            }
                            Column(Modifier.weight(1f)) {
                                Text(environmentIndexState.message, color = Color(IdeTheme.TEXT), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text("${environmentIndexState.interpreter} · Python ${environmentIndexState.pythonVersion}", color = Color(IdeTheme.DIM), fontSize = 10.sp, maxLines = 1)
                            }
                            androidx.compose.material3.OutlinedButton(onClick = { environmentIndexMonitor.refreshNow() }, enabled = environmentIndexState.status != com.codespace.ide.ide.codeintel.PythonEnvironmentIndexMonitor.Status.SCANNING) { Text("Refresh") }
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            IndexMetric("Packages", environmentIndexState.packageCount.toString(), Color(IdeTheme.ACCENT), Modifier.weight(1f))
                            IndexMetric("Added", environmentIndexState.added.size.toString(), Color(0xFF35B66A), Modifier.weight(1f))
                            IndexMetric("Removed", environmentIndexState.removed.size.toString(), Color(IdeTheme.ERROR), Modifier.weight(1f))
                            IndexMetric("Upgraded", environmentIndexState.updated.size.toString(), Color(0xFFFFB74D), Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("pip ${environmentIndexState.pipVersion} · ${if (environmentIndexState.liveWatchAvailable) "Live monitoring active" else "Manual refresh available"}", color = Color(IdeTheme.DIM), fontSize = 10.sp)
                        if (!environmentIndexState.error.isNullOrBlank()) {
                            Spacer(Modifier.height(5.dp))
                            Text(environmentIndexState.error.orEmpty(), color = Color(IdeTheme.ERROR), fontSize = 10.sp, maxLines = 3)
                        }
                        if (environmentIndexState.added.isNotEmpty() || environmentIndexState.removed.isNotEmpty() || environmentIndexState.updated.isNotEmpty()) {
                            Spacer(Modifier.height(8.dp))
                            Text("Latest package changes", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            val changes = buildList {
                                environmentIndexState.added.take(5).forEach { add("+ ${it.name} ${it.version}") }
                                environmentIndexState.removed.take(5).forEach { add("− ${it.name} ${it.version}") }
                                environmentIndexState.updated.take(5).forEach { add("↻ ${it.first.name}: ${it.first.version} → ${it.second.version}") }
                            }
                            changes.take(8).forEach { line -> Text(line, color = Color(IdeTheme.DIM), fontSize = 10.sp, maxLines = 1) }
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = environmentPackageFilter,
                            onValueChange = { onPackageFilterChange(it) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text("Find installed package") }
                        )
                        Spacer(Modifier.height(7.dp))
                        Text("Installed distributions (${filteredPackages.size})", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            items(filteredPackages, key = { it.name }) { pkg ->
                                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(IdeTheme.CARD)).padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(pkg.name, color = Color(IdeTheme.TEXT), fontSize = 11.sp, modifier = Modifier.weight(1f), maxLines = 1)
                                    Text(pkg.version, color = Color(IdeTheme.ACCENT), fontSize = 10.sp)
                                }
                            }
                            if (filteredPackages.isEmpty()) item {
                                Text(if (environmentIndexState.status == com.codespace.ide.ide.codeintel.PythonEnvironmentIndexMonitor.Status.SCANNING) "Reading installed packages…" else "No matching packages",
                                    color = Color(IdeTheme.DIM), fontSize = 11.sp, modifier = Modifier.padding(8.dp))
                            }
                        }
                    }
                }
            }
        }
    
}
