package com.codespace.ide.ide.display

/**
 * In-guest mini window manager for the embedded display (Xvnc :1).
 *
 * Without any window manager every toolkit puts its window wherever it likes: pygame centers an
 * 800x600 window on a narrower screen (negative x, so the left of the game is cut off), Tk and Kivy
 * stick to the top-left corner. This manager (pure ctypes + libX11, already in the guest) centers every
 * top-level window, adds no decorations, and publishes the bounding box of all windows to
 * /tmp/ide-wm.win so the viewer can zoom to the window. It is written to the guest /tmp and
 * started together with Xvnc; if anything about it fails the display simply behaves as before.
 */
const val DISPLAY_WM_VERSION = "wm1"

val DISPLAY_WM_SOURCE = """# ide-wm-v1: a tiny window manager for the IDE's embedded display (Xvnc :1).
# - centers every top-level window inside the screen (no more negative/top-left positions)
# - no decorations, no reparenting (windows stay exactly as the app made them)
# - writes the bounding box of all managed windows to ide-wm.win ("x y w h") so the
#   viewer can zoom to the window instead of showing a mostly empty big screen
# Pure ctypes + libX11 (already in the guest because Tk/SDL/Qt need it).
import ctypes, os, sys
from ctypes import c_int, c_uint, c_long, c_ulong, c_void_p, c_char_p, Structure, Union, byref, CFUNCTYPE

D = os.environ.get("IDE_WM_DIR", "/tmp")
WIN_FILE = os.path.join(D, "ide-wm.win")
READY_FILE = os.path.join(D, "ide-wm.ready")

try:
    x11 = ctypes.CDLL("libX11.so.6")
except OSError:
    sys.exit(3)


class XMapRequestEvent(Structure):
    _fields_ = [("type", c_int), ("serial", c_ulong), ("send_event", c_int), ("display", c_void_p),
                ("parent", c_ulong), ("window", c_ulong)]


class XConfigureRequestEvent(Structure):
    _fields_ = [("type", c_int), ("serial", c_ulong), ("send_event", c_int), ("display", c_void_p),
                ("parent", c_ulong), ("window", c_ulong), ("x", c_int), ("y", c_int),
                ("width", c_int), ("height", c_int), ("border_width", c_int),
                ("above", c_ulong), ("detail", c_int), ("value_mask", c_ulong)]


class XUnmapEvent(Structure):
    _fields_ = [("type", c_int), ("serial", c_ulong), ("send_event", c_int), ("display", c_void_p),
                ("event", c_ulong), ("window", c_ulong), ("from_configure", c_int)]


class XEvent(Union):
    _fields_ = [("type", c_int), ("xmaprequest", XMapRequestEvent),
                ("xconfigurerequest", XConfigureRequestEvent), ("xunmap", XUnmapEvent),
                ("pad", c_long * 24)]


class XWindowAttributes(Structure):
    _fields_ = [("x", c_int), ("y", c_int), ("width", c_int), ("height", c_int),
                ("border_width", c_int), ("depth", c_int), ("visual", c_void_p), ("root", c_ulong),
                ("klass", c_int), ("bit_gravity", c_int), ("win_gravity", c_int),
                ("backing_store", c_int), ("backing_planes", c_ulong), ("backing_pixel", c_ulong),
                ("save_under", c_int), ("colormap", c_ulong), ("map_installed", c_int),
                ("map_state", c_int), ("all_event_masks", c_long), ("your_event_mask", c_long),
                ("do_not_propagate_mask", c_long), ("override_redirect", c_int), ("screen", c_void_p)]


class XWindowChanges(Structure):
    _fields_ = [("x", c_int), ("y", c_int), ("width", c_int), ("height", c_int),
                ("border_width", c_int), ("sibling", c_ulong), ("stack_mode", c_int)]


x11.XOpenDisplay.restype = c_void_p
x11.XOpenDisplay.argtypes = [c_char_p]
x11.XDefaultRootWindow.restype = c_ulong
x11.XDefaultRootWindow.argtypes = [c_void_p]
x11.XDefaultScreen.restype = c_int
x11.XDefaultScreen.argtypes = [c_void_p]
x11.XDisplayWidth.restype = c_int
x11.XDisplayWidth.argtypes = [c_void_p, c_int]
x11.XDisplayHeight.restype = c_int
x11.XDisplayHeight.argtypes = [c_void_p, c_int]
x11.XSelectInput.argtypes = [c_void_p, c_ulong, c_long]
x11.XSync.argtypes = [c_void_p, c_int]
x11.XNextEvent.argtypes = [c_void_p, c_void_p]
x11.XMapWindow.argtypes = [c_void_p, c_ulong]
x11.XRaiseWindow.argtypes = [c_void_p, c_ulong]
x11.XMoveResizeWindow.argtypes = [c_void_p, c_ulong, c_int, c_int, c_uint, c_uint]
x11.XConfigureWindow.argtypes = [c_void_p, c_ulong, c_uint, c_void_p]
x11.XGetWindowAttributes.restype = c_int
x11.XGetWindowAttributes.argtypes = [c_void_p, c_ulong, c_void_p]
x11.XSetErrorHandler.restype = c_void_p
x11.XSetErrorHandler.argtypes = [c_void_p]

_errors = [0]
_ERRFUNC = CFUNCTYPE(c_int, c_void_p, c_void_p)


def _on_error(dpy, ev):
    _errors[0] += 1  # windows disappear all the time (BadWindow); never die for that
    return 0


_handler = _ERRFUNC(_on_error)  # keep a reference or it gets garbage collected
x11.XSetErrorHandler(ctypes.cast(_handler, c_void_p))

dpy = x11.XOpenDisplay(None)
if not dpy:
    sys.exit(4)
screen = x11.XDefaultScreen(dpy)
root = x11.XDefaultRootWindow(dpy)
RW = x11.XDisplayWidth(dpy, screen)
RH = x11.XDisplayHeight(dpy, screen)

SubstructureNotifyMask = 1 << 19
SubstructureRedirectMask = 1 << 20
CWWidth, CWHeight = 4, 8
MapRequest, ConfigureRequest, UnmapNotify, DestroyNotify = 20, 23, 18, 17

x11.XSelectInput(dpy, root, SubstructureRedirectMask | SubstructureNotifyMask)
x11.XSync(dpy, 0)
if _errors[0]:
    sys.exit(2)  # another window manager is already running

managed = {}


def publish():
    if managed:
        x0 = min(v[0] for v in managed.values())
        y0 = min(v[1] for v in managed.values())
        x1 = max(v[0] + v[2] for v in managed.values())
        y1 = max(v[1] + v[3] for v in managed.values())
        text = "%d %d %d %d\n" % (x0, y0, x1 - x0, y1 - y0)
    else:
        text = "0 0 0 0\n"
    try:
        tmp = WIN_FILE + ".tmp"
        with open(tmp, "w") as f:
            f.write(text)
        os.replace(tmp, WIN_FILE)
    except OSError:
        pass


def place(win, w, h):
    w = max(1, min(w, RW))
    h = max(1, min(h, RH))
    x = (RW - w) // 2
    y = (RH - h) // 2
    x11.XMoveResizeWindow(dpy, win, x, y, w, h)
    managed[win] = [x, y, w, h]


def on_map_request(win):
    attrs = XWindowAttributes()
    if not x11.XGetWindowAttributes(dpy, win, byref(attrs)):
        return
    if not attrs.override_redirect:
        place(win, attrs.width, attrs.height)
    x11.XMapWindow(dpy, win)
    x11.XRaiseWindow(dpy, win)
    publish()


def on_configure_request(ev):
    win = ev.window
    mask = ev.value_mask
    if win in managed:
        _, _, w, h = managed[win]
        if mask & CWWidth:
            w = ev.width
        if mask & CWHeight:
            h = ev.height
        place(win, w, h)
        publish()
    else:
        ch = XWindowChanges(ev.x, ev.y, ev.width, ev.height, ev.border_width, ev.above, ev.detail)
        x11.XConfigureWindow(dpy, win, mask & 0x7F, byref(ch))


try:
    with open(READY_FILE, "w") as f:
        f.write("1\n")
except OSError:
    pass
publish()

xev = XEvent()
while True:
    x11.XNextEvent(dpy, byref(xev))  # blocks; exits when the display goes away
    try:
        t = xev.type
        if t == MapRequest:
            on_map_request(xev.xmaprequest.window)
        elif t == ConfigureRequest:
            on_configure_request(xev.xconfigurerequest)
        elif t == UnmapNotify or t == DestroyNotify:
            if xev.xunmap.window in managed:
                del managed[xev.xunmap.window]
                publish()
    except Exception:
        pass
"""
