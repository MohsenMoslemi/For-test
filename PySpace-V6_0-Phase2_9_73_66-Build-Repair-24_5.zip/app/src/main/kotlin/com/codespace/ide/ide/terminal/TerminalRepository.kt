package com.codespace.ide.ide.terminal

import com.codespace.ide.ProotManager
import com.codespace.ide.TerminalSession
import java.util.concurrent.atomic.AtomicLong

/** Immutable launch request. It contains guest paths only; PRoot remains the
 * single authority for host binds, environment and runtime arguments. */
data class TerminalLaunchConfig(
    val runCommand: String? = null,
    val workDir: String? = null,
    val promptVenv: String? = null,
    val rows: Int = TerminalSession.DEFAULT_ROWS,
    val cols: Int = TerminalSession.DEFAULT_COLS,
)

/** Events emitted by a PTY session. Output/exit/error arrive on worker threads. */
interface TerminalCallbacks {
    fun onOutput(text: String)
    fun onExit(code: Int)
    fun onError(error: Throwable)
}

/**
 * Owns the native PTY session and its process-group lifetime.
 *
 * All blocking PTY creation is invoked by the ViewModel on Dispatchers.IO.
 * A generation token prevents a slow start from resurrecting a session after
 * Stop/Restart/Dispose. Only one session can be current at a time.
 */
class TerminalRepository(private val proot: ProotManager) {
    private val lock = Any()
    private val generation = AtomicLong(0L)
    @Volatile private var active: TerminalSession? = null

    val currentSession: TerminalSession?
        get() = active

    fun start(config: TerminalLaunchConfig, callbacks: TerminalCallbacks): TerminalSession? {
        val token = generation.incrementAndGet()
        val session = TerminalSession(
            proot = proot,
            onOutput = callbacks::onOutput,
            onExit = { code ->
                clearIfCurrent(token, null)
                callbacks.onExit(code)
            },
            onError = { error ->
                clearIfCurrent(token, null)
                callbacks.onError(error)
            },
        )

        synchronized(lock) {
            if (token != generation.get()) return null
            active?.close()
            active = session
        }

        try {
            session.start(
                rows = config.rows,
                cols = config.cols,
                runCommand = config.runCommand,
                workDir = config.workDir,
                promptVenv = config.promptVenv,
            )
        } catch (error: Throwable) {
            clearIfCurrent(token, session)
            session.close()
            throw error
        }

        // start() reports native failures through onError. Do not publish a
        // dead session as successfully started.
        if (token != generation.get() || !session.isAlive()) {
            clearIfCurrent(token, session)
            session.close()
            return null
        }
        return session
    }

    private fun clearIfCurrent(token: Long, expected: TerminalSession?) {
        synchronized(lock) {
            if (token != generation.get()) return
            if (expected == null || active === expected) active = null
        }
    }

    fun send(text: String): Boolean = active?.send(text) ?: false

    fun resize(rows: Int, cols: Int): Boolean = active?.resize(rows, cols) ?: false

    fun isAlive(): Boolean = active?.isAlive() == true

    /** Invalidates in-flight starts before killing the whole PTY process group. */
    fun stop() {
        generation.incrementAndGet()
        val old = synchronized(lock) {
            val previous = active
            active = null
            previous
        }
        old?.close()
    }
}
