package com.codespace.ide.application.notebook.usecase

import com.codespace.ide.domain.notebook.contract.NotebookSerializer
import com.codespace.ide.domain.notebook.model.NbDocSnapshot

/** Serializes a detached notebook snapshot without depending on UI or runtime state. */
class SerializeNotebookUseCase(
    private val serializer: NotebookSerializer,
) {
    operator fun invoke(snapshot: NbDocSnapshot): String = serializer.serialize(snapshot)
}
