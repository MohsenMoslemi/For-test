package com.codespace.ide.ide.editor

import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue

/**
 * Presentation-owned editing value for one open document.
 *
 * OpenTab remains the sole source of truth for document text and dirty/history
 * state. This holder owns only Compose's live TextFieldValue (selection and IME
 * composition included), which cannot safely live in the domain/document model.
 * The explicit bridge methods make external document replacement and selection
 * requests pass through one boundary instead of duplicating synchronization
 * policy throughout PyEditor.
 */
class EditorTextInputState(tab: OpenTab) {
    val value: MutableState<TextFieldValue> = mutableStateOf(initialValue(tab))

    fun applyDocumentText(documentText: String): Boolean {
        val current = value.value
        if (current.text == documentText) return false
        val start = current.selection.start.coerceIn(0, documentText.length)
        val end = current.selection.end.coerceIn(0, documentText.length)
        value.value = TextFieldValue(documentText, TextRange(start, end))
        return true
    }

    fun applySelection(range: IntRange): Boolean {
        val current = value.value
        if (range.first < 0 || range.last >= current.text.length) return false
        value.value = TextFieldValue(current.text, TextRange(range.first, range.last + 1))
        return true
    }

    fun placeCaret(sourceText: String, offset: Int) {
        value.value = TextFieldValue(sourceText, TextRange(offset.coerceIn(0, sourceText.length)))
    }

    companion object {
        private fun initialValue(tab: OpenTab): TextFieldValue {
            val length = tab.text.length
            val start = if (tab.selStart in 0..length) tab.selStart else length
            val end = if (tab.selEnd in 0..length) tab.selEnd else start
            return TextFieldValue(tab.text, TextRange(start, end))
        }
    }
}
