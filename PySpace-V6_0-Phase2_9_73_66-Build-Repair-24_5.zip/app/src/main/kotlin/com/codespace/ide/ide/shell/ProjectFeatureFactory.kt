package com.codespace.ide.ide.shell

import androidx.lifecycle.ViewModelProvider
import com.codespace.ide.runtime.RuntimeDispatchers
import com.codespace.ide.ide.codeintel.CodeIntelligenceRepository
import com.codespace.ide.ide.codeintel.CodeIntelligenceViewModel
import com.codespace.ide.ide.editor.EditorSession
import com.codespace.ide.ide.editor.EditorViewModel
import com.codespace.ide.ide.editor.FileEditorRepository
import com.codespace.ide.ide.explorer.FileExplorerRepository
import com.codespace.ide.ide.explorer.FileExplorerViewModel
import com.codespace.ide.ide.notebook.NotebookRepository
import com.codespace.ide.ide.projects.PyProject
import com.codespace.ide.ide.settings.IdePrefs

/** Creates and wires the ViewModel set owned by one project feature registry. */
internal class ProjectFeatureFactory(
    private val registry: ProjectFeatureRegistry,
    private val storeProvider: ProjectViewModelStoreProvider?,
    private val prefs: IdePrefs,
    private val runtimeDispatchers: RuntimeDispatchers,
    private val fileExplorerRepository: FileExplorerRepository,
    private val codeIntelligenceRepository: CodeIntelligenceRepository,
    private val notebookRepository: NotebookRepository,
) {
    fun editorFor(project: PyProject): EditorViewModel {
        val path = project.dir.absolutePath
        val projectStore = storeProvider?.storeFor(path)
        val editor = registry.editors.getOrPut(path) {
            val session = EditorSession(project)
            val repository = FileEditorRepository(runtimeDispatchers, session.project.dir)
            val viewModel = if (projectStore != null) {
                ViewModelProvider(projectStore, EditorViewModel.Factory(session, runtimeDispatchers, repository))
                    .get(EditorViewModel::class.java)
            } else {
                EditorViewModel(session, runtimeDispatchers, repository)
            }
            viewModel.restoreFrom(prefs.sessionJson(path))
            viewModel
        }

        editor.session.onPathRemoved = { removedPath -> notebookRepository.releaseUnder(removedPath, project) }

        if (registry.fileExplorers[path] == null) {
            registry.fileExplorers[path] = if (projectStore != null) {
                ViewModelProvider(projectStore, FileExplorerViewModel.Factory(fileExplorerRepository))
                    .get(FileExplorerViewModel::class.java)
            } else FileExplorerViewModel(fileExplorerRepository)
        }
        if (registry.codeIntelligence[path] == null) {
            registry.codeIntelligence[path] = if (projectStore != null) {
                ViewModelProvider(projectStore, CodeIntelligenceViewModel.Factory(runtimeDispatchers, codeIntelligenceRepository))
                    .get(CodeIntelligenceViewModel::class.java)
            } else CodeIntelligenceViewModel(runtimeDispatchers, codeIntelligenceRepository)
        }
        return editor
    }
}

/** Narrow adapter so feature construction does not depend on the Activity registry implementation. */
internal fun interface ProjectViewModelStoreProvider {
    fun storeFor(projectPath: String): androidx.lifecycle.ViewModelStore?
}
