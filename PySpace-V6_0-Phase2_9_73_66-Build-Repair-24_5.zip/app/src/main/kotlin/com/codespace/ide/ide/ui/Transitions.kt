package com.codespace.ide.ide.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import kotlin.math.abs

/**
 * Slide-and-settle page transition (enter): the incoming page glides in
 * from the side and rests. dir = +1 forward (from right), -1 back.
 * Hand-rolled on animation-core (offset + fade): enter-only by design, so
 * the outgoing page is never composed twice.
 */
@Composable
fun ScreenSlide(dir: Float, content: @Composable () -> Unit) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wPx = with(LocalDensity.current) { maxWidth.toPx() }
        val slide = remember(dir) { Animatable(dir) }
        LaunchedEffect(dir) {
            slide.snapTo(dir)
            slide.animateTo(
                0f,
                tween(durationMillis = 300, easing = FastOutSlowInEasing)
            )
        }
        Box(
            Modifier.fillMaxSize()
            .graphicsLayer {
                translationX = slide.value * wPx
                alpha = (1f - abs(slide.value) * 0.4f).coerceIn(0f, 1f)
            }
        ) {
            content()
        }
    }
}

/**
 * Overlay transition (enter AND exit): a fullscreen layer above live
 * content rises + fades in, and sinks back out on close. The layer stays
 * composed until the exit finishes, then drops out.
 */
@Composable
fun OverlaySlideUp(visible: Boolean, content: @Composable () -> Unit) {
    val vis = remember { Animatable(0f) }
    LaunchedEffect(visible) {
        vis.animateTo(
            if (visible) 1f else 0f,
            tween(durationMillis = 300, easing = FastOutSlowInEasing)
        )
    }
    if (vis.value > 0.01f) {
        val hopPx = with(LocalDensity.current) { 96.dp.toPx() }
        Box(
            Modifier.fillMaxSize()
            .graphicsLayer {
                translationY = (1f - vis.value) * hopPx
                alpha = vis.value.coerceIn(0f, 1f)
            }
        ) {
            content()
        }
    }
}

// -------------------------------- Settings ---------------------------------
