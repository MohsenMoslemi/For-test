package com.codespace.ide.ide.editor

import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.unit.Velocity

/**
 * Per-document scroll state and axis arbitration for the editor surface.
 * The session restores the tab's saved offsets and keeps the vertical and
 * horizontal scroll states shared by the text, gutter, caret and zoom flows.
 */
data class EditorScrollSession(
    val horizontal: ScrollState,
    val vertical: ScrollState,
    val restoreView: Boolean,
    val panFree: Boolean,
    val axisLink: NestedScrollConnection
)

@Composable
fun rememberEditorScrollSession(
    filePath: String,
    savedScrollX: Int,
    savedScrollY: Int,
    hasSavedView: Boolean,
    pan2D: Boolean,
    wordWrap: Boolean
): EditorScrollSession {
    val horizontal = rememberScrollState(savedScrollX)
    val vertical = rememberScrollState(savedScrollY)
    val axisLink = remember(filePath) {
        object : NestedScrollConnection {
            override fun onPreScroll(
                available: Offset,
                source: NestedScrollSource
            ): Offset {
                if (source != NestedScrollSource.UserInput) return Offset.Zero
                return if (kotlin.math.abs(available.x) >= kotlin.math.abs(available.y)) {
                    Offset(0f, available.y)
                } else {
                    Offset(available.x, 0f)
                }
            }

            override suspend fun onPreFling(available: Velocity): Velocity =
                if (kotlin.math.abs(available.x) >= kotlin.math.abs(available.y)) {
                    Velocity(0f, available.y)
                } else {
                    Velocity(available.x, 0f)
                }
        }
    }
    return EditorScrollSession(
        horizontal = horizontal,
        vertical = vertical,
        restoreView = remember(filePath) { hasSavedView },
        panFree = pan2D && !wordWrap,
        axisLink = axisLink
    )
}
