package com.codespace.ide.ide.projects

import android.os.FileObserver
import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.concurrent.Executors

/** Recursively watches the active project and emits one debounced change signal. */
class ProjectRecoveryWatcher(
    private val projectRoot: File,
    private val onChanged: () -> Unit,
) : AutoCloseable {
    private val handler = Handler(Looper.getMainLooper())
    private val observers = LinkedHashMap<String, FileObserver>()
    private val worker = Executors.newSingleThreadExecutor { runnable -> Thread(runnable, "PySpace-Recovery-Watcher").apply { isDaemon = true } }
    @Volatile private var closed = false
    private val notifyRunnable = Runnable {
        if (!closed) {
            worker.execute {
                refreshObservers()
                if (!closed) handler.post { if (!closed) onChanged() }
            }
        }
    }

    @Synchronized
    fun start() {
        if (!closed) worker.execute { refreshObservers() }
    }

    @Synchronized
    private fun refreshObservers() {
        if (closed || !projectRoot.isDirectory) return
        val directories = projectRoot.walkTopDown().filter { it.isDirectory }.map {
            try { it.canonicalPath } catch (_: Exception) { it.absolutePath }
        }.toSet()
        (observers.keys - directories).forEach { path -> observers.remove(path)?.stopWatching() }
        (directories - observers.keys).forEach { path ->
            val observer = object : FileObserver(path, EVENTS) {
                override fun onEvent(event: Int, relativePath: String?) {
                    if (closed) return
                    handler.removeCallbacks(notifyRunnable)
                    handler.postDelayed(notifyRunnable, DEBOUNCE_MS)
                }
            }
            try { observer.startWatching(); observers[path] = observer } catch (_: Exception) { observer.stopWatching() }
        }
    }

    @Synchronized
    override fun close() {
        if (closed) return
        closed = true
        handler.removeCallbacks(notifyRunnable)
        observers.values.forEach { try { it.stopWatching() } catch (_: Exception) { } }
        observers.clear()
        worker.shutdownNow()
    }

    companion object {
        private const val DEBOUNCE_MS = 900L
        private val EVENTS = FileObserver.CREATE or FileObserver.DELETE or FileObserver.MOVED_FROM or
            FileObserver.MOVED_TO or FileObserver.CLOSE_WRITE or FileObserver.MODIFY or FileObserver.ATTRIB
    }
}
