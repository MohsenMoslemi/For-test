package com.codespace.ide.ide.explorer

import android.os.FileObserver
import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import com.codespace.ide.ide.codeintel.ProjectIndexMonitor
import com.codespace.ide.ide.codeintel.PythonProjectSymbolIndex
import com.codespace.ide.ide.codeintel.WorkspacePythonReferenceIndex

/** Watches project directories so changes made by terminal/Python are reflected
 * in the explorer without requiring a manual refresh. */
class ProjectFileWatcher(
    private val root: File,
    private val includeHidden: Boolean = false,
    private val onChanged: (structureChanged: Boolean) -> Unit,
) : AutoCloseable {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val pending = AtomicBoolean(false)
    private val structureDirty = AtomicBoolean(false)
    @Volatile private var closed = false
    private val observers = ArrayList<FileObserver>()

    fun start() {
        Thread({ rebuildObservers() }, "PySpace-TreeWatch").start()
    }

    private fun scheduleRefresh(structureChanged: Boolean) {
        if (closed) return
        // FileObserver also receives edits made by the terminal and Python
        // processes. Invalidate semantic snapshots immediately so the next
        // completion/reference request cannot reuse stale project data.
        // The live ProjectIndexMonitor incrementally refreshes the shared
        // WorkspacePythonReferenceIndex cache. Do not discard that cache here;
        // doing so would turn every small filesystem event into a full reindex.
        PythonProjectSymbolIndex.invalidate(root)
        if (structureChanged) structureDirty.set(true)
        if (!pending.compareAndSet(false, true)) return
        mainHandler.postDelayed({
            Thread({
                val rebuild = structureDirty.getAndSet(false)
                if (rebuild) rebuildObservers()
                pending.set(false)
                if (!closed) mainHandler.post { if (!closed) onChanged(rebuild) }
                if (structureDirty.get()) scheduleRefresh(true)
            }, "PySpace-TreeRefresh").start()
        }, 320L)
    }

    @Synchronized
    private fun rebuildObservers() {
        if (closed) return
        observers.forEach { try { it.stopWatching() } catch (_: Exception) {} }
        observers.clear()
        if (!root.isDirectory) return
        val stack = ArrayDeque<File>()
        val seen = HashSet<String>()
        stack.add(root)
        while (stack.isNotEmpty() && observers.size < MAX_WATCHED_DIRECTORIES) {
            val dir = stack.removeLast()
            val canonical = try { dir.canonicalPath } catch (_: Exception) { dir.absolutePath }
            if (!seen.add(canonical)) continue
            try {
                val observer = object : FileObserver(dir.absolutePath, WATCH_MASK) {
                    override fun onEvent(event: Int, path: String?) {
                        val structureMask = FileObserver.CREATE or FileObserver.DELETE or
                            FileObserver.MOVED_FROM or FileObserver.MOVED_TO or
                            FileObserver.DELETE_SELF or FileObserver.MOVE_SELF
                        val contentMask = FileObserver.CLOSE_WRITE or FileObserver.ATTRIB
                        when {
                            event and structureMask != 0 -> scheduleRefresh(true)
                            event and contentMask != 0 -> scheduleRefresh(false)
                        }
                    }
                }
                observer.startWatching()
                observers += observer
            } catch (_: Exception) {}
            // Hidden mode may show managed folders as rows, but must never
            // recursively watch their potentially enormous contents.
            val children = try {
                dir.listFiles { _, name -> isVisibleTreeEntry(dir, name, includeHidden) }
            } catch (_: Exception) { null } ?: continue
            children.asSequence()
                .filter { it.isDirectory && !isSymbolicLink(it) && !isManagedTreeDirectory(it) }
                .forEach { stack.add(it) }
        }
    }

    @Synchronized
    override fun close() {
        closed = true
        mainHandler.removeCallbacksAndMessages(null)
        observers.forEach { try { it.stopWatching() } catch (_: Exception) {} }
        observers.clear()
    }

    private fun isSymbolicLink(file: File): Boolean = try {
        java.nio.file.Files.isSymbolicLink(file.toPath())
    } catch (_: Exception) { false }

    private companion object {
        const val MAX_WATCHED_DIRECTORIES = 1000
        const val WATCH_MASK = FileObserver.CREATE or FileObserver.DELETE or FileObserver.MOVED_FROM or
            FileObserver.MOVED_TO or FileObserver.CLOSE_WRITE or FileObserver.ATTRIB or
            FileObserver.DELETE_SELF or FileObserver.MOVE_SELF
    }
}
