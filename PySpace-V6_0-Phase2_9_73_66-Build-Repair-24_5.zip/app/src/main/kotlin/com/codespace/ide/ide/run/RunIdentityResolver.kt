package com.codespace.ide.ide.run

import java.io.File

/**
 * Pure run-identity rules shared by Console and Terminal preparation.
 *
 * Keeping canonical script paths, conflict keys and Terminal labels here avoids
 * subtle differences between the Run button and commands typed in a shell.
 * This class deliberately does not inspect files, start processes, touch Android
 * APIs or own any runtime resource.
 */
object RunIdentityResolver {
    private val webLaunchers = setOf(
        "flask", "uvicorn", "gunicorn", "hypercorn", "daphne", "streamlit", "fastapi"
    )

    /** Script operand in `python [options] script.py`; -m and -c are not files. */
    fun scriptArgument(argv: List<String>): String? {
        var index = 1
        while (index < argv.size) {
            val arg = argv[index]
            if (arg == "-m" || arg == "-c") return null
            if (arg == "-W" || arg == "-X") {
                index += 2
                continue
            }
            if (arg.startsWith("-")) {
                index++
                continue
            }
            return if (arg.endsWith(".py")) arg else null
        }
        return null
    }

    /** Resolves a shell script operand to the normalized guest-absolute path. */
    fun resolveGuestScript(cwd: String, script: String): String =
        File(if (script.startsWith("/")) script else "$cwd/$script").normalize().path

    fun consoleScriptKey(projectGuestPath: String, relativeScriptPath: String): String =
        try {
            File(projectGuestPath, relativeScriptPath).normalize().path
        } catch (_: Exception) {
            projectGuestPath.trimEnd('/') + "/" + relativeScriptPath
        }

    fun consoleConflictKeys(
        projectGuestPath: String,
        relativeScriptPath: String,
        webLike: Boolean,
    ): Set<String> = linkedSetOf(consoleScriptKey(projectGuestPath, relativeScriptPath)).also {
        if (webLike) it += "web:$projectGuestPath"
    }

    fun terminalConflictKeys(
        scriptGuestPath: String?,
        argv: List<String>,
        webRoot: String,
        webLike: Boolean,
    ): Set<String> = linkedSetOf(scriptGuestPath ?: argv.joinToString(" ")).also {
        if (webLike) it += "web:$webRoot"
    }

    /** `flask run`, `uvicorn app:app`, `python -m flask ...`, Django runserver. */
    fun isWebLauncher(argv: List<String>): Boolean {
        if (argv.isEmpty()) return false
        if (File(argv[0]).name in webLaunchers) return true
        if (argv.contains("runserver")) return true
        val moduleIndex = argv.indexOf("-m")
        return moduleIndex >= 0 && moduleIndex + 1 < argv.size &&
            argv[moduleIndex + 1] in webLaunchers
    }

    fun terminalTitle(script: String?, argv: List<String>, guiFramework: String?): String {
        val executable = argv.firstOrNull().orEmpty()
        val base = script?.let { File(it).name }
            ?: argv.drop(1).take(3).joinToString(" ").ifBlank { File(executable).name }
        return base + (guiFramework?.let { " — $it" } ?: "")
    }
}
