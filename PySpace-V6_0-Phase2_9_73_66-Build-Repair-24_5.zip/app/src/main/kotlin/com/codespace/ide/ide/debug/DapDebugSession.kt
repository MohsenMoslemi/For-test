package com.codespace.ide.ide.debug

import com.codespace.ide.ProotManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.ServerSocket
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import com.codespace.ide.ide.projects.PyProject

/** DAP breakpoint metadata. Empty condition/hitCondition/logMessage means a normal breakpoint. */
data class DapBreakpoint(
    val line: Int,
    val enabled: Boolean = true,
    val condition: String = "",
    val hitCondition: String = "",
    val logMessage: String = ""
)

/** Strict DAP 1.0 client for debugpy. All blocking calls belong on Dispatchers.IO. */
class DapDebugSession private constructor(
    private val process: Process,
    private val socket: Socket,
    private val onEvent: (JSONObject) -> Unit,
    private val onOutput: (String) -> Unit
) : AutoCloseable {
    private val input = BufferedInputStream(socket.getInputStream())
    private val output = BufferedOutputStream(socket.getOutputStream())
    private val processInput = process.outputStream.bufferedWriter()
    private val sequence = AtomicInteger(1)
    private val pending = ConcurrentHashMap<Int, Pending>()
    private val initializedLatch = CountDownLatch(1)
    @Volatile private var closed = false
    // debugpy may close the socket immediately after its terminal lifecycle event.
    // That EOF is expected and must not be surfaced as a transport failure.
    @Volatile private var terminationSeen = false
    @Volatile var lastError: String? = null
        private set

    private data class Pending(
        val latch: CountDownLatch = CountDownLatch(1),
        @Volatile var response: JSONObject? = null,
        @Volatile var failure: String? = null
    )

    init {
        Thread({ readLoop() }, "PySpace-DAP-Reader").apply { isDaemon = true; start() }
        Thread({
            try { process.inputStream.bufferedReader().useLines { lines -> lines.forEach { onOutput(it + "\n") } } }
            catch (_: Exception) { }
        }, "PySpace-Debug-Process-Output").apply { isDaemon = true; start() }
        Thread({
            try { process.errorStream.bufferedReader().useLines { lines -> lines.forEach { onOutput("[debugpy] $it\n") } } }
            catch (_: Exception) { }
        }, "PySpace-Debug-Process-Error").apply { isDaemon = true; start() }
    }

    private fun readLoop() {
        try {
            while (!closed) {
                var contentLength = -1
                while (true) {
                    val line = readAsciiLine() ?: throw IllegalStateException("DAP connection closed")
                    if (line.isEmpty()) break
                    if (line.startsWith("Content-Length:", true)) contentLength = line.substringAfter(':').trim().toIntOrNull() ?: -1
                }
                if (contentLength !in 1..8_388_608) throw IllegalStateException("Invalid DAP message length")
                val body = ByteArray(contentLength)
                var offset = 0
                while (offset < body.size) {
                    val count = input.read(body, offset, body.size - offset)
                    if (count < 0) throw IllegalStateException("Truncated DAP message")
                    offset += count
                }
                val message = JSONObject(String(body, StandardCharsets.UTF_8))
                when (message.optString("type")) {
                    "response" -> {
                        val id = message.optInt("request_seq", -1)
                        pending[id]?.let { it.response = message; it.latch.countDown() }
                    }
                    "event" -> {
                        val eventName = message.optString("event")
                        if (eventName == "initialized") initializedLatch.countDown()
                        if (eventName == "terminated" || eventName == "exited") terminationSeen = true
                        onEvent(message)
                    }
                }
            }
        } catch (t: Throwable) {
            if (!closed && terminationSeen) {
                // Release any in-flight request waiters without misclassifying a normal exit.
                pending.values.forEach { it.failure = "Debuggee terminated"; it.latch.countDown() }
            } else if (!closed) {
                lastError = t.message ?: "DAP transport failed"
                pending.values.forEach { it.failure = lastError; it.latch.countDown() }
                onEvent(JSONObject().put("type", "event").put("event", "pyspaceTransportError")
                    .put("body", JSONObject().put("message", lastError)))
            }
        }
    }

    private fun readAsciiLine(): String? {
        val bytes = ByteArrayOutputStream()
        while (true) {
            val b = input.read()
            if (b < 0) return if (bytes.size() == 0) null else throw IllegalStateException("Truncated DAP header")
            if (b == 10) break
            if (b != 13) bytes.write(b)
            if (bytes.size() > 8192) throw IllegalStateException("DAP header too large")
        }
        return bytes.toString("US-ASCII")
    }

    @Synchronized
    private fun send(message: JSONObject) {
        val bytes = message.toString().toByteArray(StandardCharsets.UTF_8)
        output.write("Content-Length: ${bytes.size}\r\n\r\n".toByteArray(StandardCharsets.US_ASCII))
        output.write(bytes)
        output.flush()
    }

    private fun beginRequest(command: String, arguments: JSONObject = JSONObject()): Int {
        check(!closed) { "Debugger is stopped" }
        val id = sequence.getAndIncrement()
        pending[id] = Pending()
        try {
            send(JSONObject().put("seq", id).put("type", "request").put("command", command).put("arguments", arguments))
        } catch (t: Throwable) {
            pending.remove(id)
            throw t
        }
        return id
    }

    private fun awaitResponse(id: Int, command: String, timeoutSeconds: Long = 8): JSONObject {
        val wait = pending[id] ?: throw IllegalStateException("Debugger request is no longer pending: $command")
        if (!wait.latch.await(timeoutSeconds, TimeUnit.SECONDS)) {
            pending.remove(id)
            throw IllegalStateException("Debugger request timed out: $command")
        }
        pending.remove(id)
        wait.failure?.let { throw IllegalStateException("Debugger connection failed during $command: $it") }
        val response = wait.response ?: throw IllegalStateException("Debugger returned an empty response: $command")
        if (!response.optBoolean("success", false)) {
            throw IllegalStateException(response.optString("message", "Debugger request failed: $command"))
        }
        return response.optJSONObject("body") ?: JSONObject()
    }

    fun request(command: String, arguments: JSONObject = JSONObject(), timeoutSeconds: Long = 8): JSONObject =
        awaitResponse(beginRequest(command, arguments), command, timeoutSeconds)

    fun control(command: String, threadId: Int? = null): JSONObject {
        val args = JSONObject()
        if (threadId != null) args.put("threadId", threadId)
        return request(command, args)
    }

    fun setBreakpoints(guestFile: String, breakpoints: List<DapBreakpoint>): JSONArray {
        val payload = JSONArray()
        breakpoints.asSequence().filter { it.enabled && it.line > 0 }.sortedBy { it.line }.forEach { bp ->
            val item = JSONObject().put("line", bp.line)
            if (bp.condition.isNotBlank()) item.put("condition", bp.condition)
            if (bp.hitCondition.isNotBlank()) item.put("hitCondition", bp.hitCondition)
            if (bp.logMessage.isNotBlank()) item.put("logMessage", bp.logMessage)
            payload.put(item)
        }
        return request("setBreakpoints", JSONObject()
            .put("source", JSONObject().put("name", File(guestFile).name).put("path", guestFile))
            .put("breakpoints", payload).put("sourceModified", false))
            .optJSONArray("breakpoints") ?: JSONArray()
    }

    fun setExceptionBreakpoints(filters: Set<String>) {
        request("setExceptionBreakpoints", JSONObject().put("filters", JSONArray().apply {
            filters.forEach { put(it) }
        }))
    }

    fun threads(): JSONArray = request("threads").optJSONArray("threads") ?: JSONArray()
    fun exceptionInfo(threadId: Int): JSONObject = request("exceptionInfo", JSONObject().put("threadId", threadId))

    fun stackTrace(threadId: Int): JSONArray = request("stackTrace", JSONObject().put("threadId", threadId).put("startFrame", 0).put("levels", 100)).optJSONArray("stackFrames") ?: JSONArray()
    fun scopes(frameId: Int): JSONArray = request("scopes", JSONObject().put("frameId", frameId)).optJSONArray("scopes") ?: JSONArray()
    fun variables(reference: Int, start: Int = 0, count: Int = 100): JSONArray = request(
        "variables", JSONObject().put("variablesReference", reference).put("start", start).put("count", count)
    ).optJSONArray("variables") ?: JSONArray()
    @Synchronized
    fun sendProgramInput(text: String): Boolean {
        if (!process.isAlive) return false
        return try {
            processInput.write(text)
            processInput.newLine()
            processInput.flush()
            true
        } catch (_: Exception) { false }
    }

    fun evaluate(expression: String, frameId: Int? = null): JSONObject {
        val args = JSONObject().put("expression", expression).put("context", "watch")
        if (frameId != null) args.put("frameId", frameId)
        return request("evaluate", args, timeoutSeconds = 4)
    }

    /**
     * Close transport/process without waiting for a DAP disconnect response.
     * A graceful disconnect can deadlock restart when the adapter is paused or a
     * request is outstanding. Closing the socket first unblocks the reader and all
     * pending requests; then terminate and reap the debuggee process.
     */
    override fun close() {
        if (closed) return
        closed = true
        pending.values.forEach { it.failure = "Debugger session closed"; it.latch.countDown() }
        pending.clear()
        runCatching { socket.close() }
        runCatching { processInput.close() }
        runCatching { if (process.isAlive) process.destroy() }
        runCatching {
            if (process.isAlive && !process.waitFor(700, TimeUnit.MILLISECONDS)) {
                process.destroyForcibly()
                process.waitFor(700, TimeUnit.MILLISECONDS)
            }
        }
    }

    companion object {
        /** Start debugpy for the project's own interpreter; debugpy is shared and never pip-installed into the venv. */
        fun start(
            proot: ProotManager,
            project: PyProject,
            target: File,
            breakpoints: Map<String, List<DapBreakpoint>>,
            breakOnRaised: Boolean = false,
            onEvent: (JSONObject) -> Unit,
            onOutput: (String) -> Unit
        ): DapDebugSession {
            val projectPath = guestProjectPath(project)
            val relative = target.relativeTo(project.dir).invariantSeparatorsPath
            val guestFile = "$projectPath/$relative"
            val venv = projectVenvGuestPath(project.dir)?.let { "$it/bin/python" }
            val python = venv ?: projectPythonInterpreterGuestPath(project.dir)
            val port = ServerSocket(0).use { it.localPort }
            val safe = { value: String -> "'" + value.replace("'", "'\\''") + "'" }
            val pythonCheck = "import sys,debugpy; print(\"PYSPACE_DEBUGPY=\"+debugpy.__version__); " +
                "assert sys.version_info >= (3,10), \"debugpy requires Python 3.10 or newer\"; " +
                "assert debugpy.__version__ == \"1.8.22\""
            val compatibility = proot.runOnce(
                "PYTHONPATH=/opt/pyspace-debugger/site-packages ${safe(python)} -c ${safe(pythonCheck)}",
                timeoutSec = 20
            )
            if (!compatibility.contains("PYSPACE_DEBUGPY=1.8.22") || !compatibility.contains("[exit=0]")) {
                throw IllegalStateException(
                    compatibility.lineSequence().firstOrNull { it.contains("AssertionError") || it.contains("ModuleNotFoundError") || it.contains("No such file") }
                        ?: "The selected project interpreter cannot load debugpy 1.8.22. Python 3.10 or newer is required."
                )
            }
            val command = "cd ${safe(projectPath)} && " +
                "PYTHONPATH=/opt/pyspace-debugger/site-packages\${PYTHONPATH:+:\$PYTHONPATH} " +
                "exec ${safe(python)} -m debugpy --listen 127.0.0.1:$port --wait-for-client ${safe(guestFile)}"
            val process = proot.startGuestProcess(command)
            var socket: Socket? = null
            val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(20)
            while (System.nanoTime() < deadline && process.isAlive && socket == null) {
                val candidate = Socket()
                try {
                    candidate.connect(java.net.InetSocketAddress("127.0.0.1", port), 250)
                    candidate.soTimeout = 0
                    candidate.tcpNoDelay = true
                    socket = candidate
                } catch (_: Exception) {
                    runCatching { candidate.close() }
                    Thread.sleep(100)
                }
            }
            if (socket == null) {
                runCatching { process.destroyForcibly() }
                val diagnostics = runCatching { process.errorStream.bufferedReader().readText().take(3000) }.getOrNull().orEmpty()
                throw IllegalStateException(
                    diagnostics.ifBlank { "Could not connect to debugpy. Confirm the project's Python is 3.10 or newer." }
                )
            }
            val session = DapDebugSession(process, socket, onEvent, onOutput)
            try {
                session.request("initialize", JSONObject()
                    .put("clientID", "pyspace").put("clientName", "PySpace")
                    .put("adapterID", "python").put("pathFormat", "path")
                    .put("linesStartAt1", true).put("columnsStartAt1", true)
                    .put("supportsVariableType", true).put("supportsVariablePaging", true)
                    .put("supportsConditionalBreakpoints", true).put("supportsHitConditionalBreakpoints", true)
                    .put("supportsLogPoints", true).put("supportsExceptionInfoRequest", true)
                    .put("supportsRunInTerminalRequest", false).put("supportsProgressReporting", false))
                val attachRequest = session.beginRequest("attach", JSONObject()
                    .put("name", "PySpace Debug Session")
                    .put("justMyCode", true).put("redirectOutput", true))
                if (!session.initializedLatch.await(10, TimeUnit.SECONDS)) {
                    throw IllegalStateException("debugpy did not initialize the DAP session")
                }
                val configuredSources = LinkedHashSet<String>()
                configuredSources += guestFile
                configuredSources += breakpoints.keys
                for (sourcePath in configuredSources) {
                    val results = session.setBreakpoints(sourcePath, breakpoints[sourcePath].orEmpty())
                    for (i in 0 until results.length()) {
                        val item = results.optJSONObject(i) ?: continue
                        if (!item.optBoolean("verified", true)) {
                            onOutput("[Breakpoint ${item.optInt("line")}: ${item.optString("message", "not verified")} ]\n")
                        }
                    }
                }
                session.setExceptionBreakpoints(if (breakOnRaised) setOf("raised", "uncaught") else setOf("uncaught"))
                val configurationRequest = session.beginRequest("configurationDone")
                session.awaitResponse(attachRequest, "attach", 15)
                session.awaitResponse(configurationRequest, "configurationDone", 15)
                return session
            } catch (t: Throwable) {
                session.close()
                throw t
            }
        }
    }
}
