package com.codespace.ide.ide.editor

import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue

/** Immutable result of normalizing a BasicTextField input against the shared document. */
data class EditorInputEditResult(
    val value: TextFieldValue,
    val changesDocument: Boolean
)

/**
 * Owns the pure input-normalization decision for the editor surface.
 * It deliberately does not mutate OpenTab or Compose state: the caller commits
 * [EditorInputEditResult] only after applying its existing popup/caret policies.
 */
object EditorInputEditProcessor {
    fun process(
        documentText: String,
        incoming: TextFieldValue,
        tabWidth: Int,
        autoIndent: Boolean
    ): EditorInputEditResult {
        if (incoming.text == documentText) {
            return EditorInputEditResult(incoming, changesDocument = false)
        }
        val (text, caret) = applySmartEdit(
            old = documentText,
            new = incoming.text,
            cursor = incoming.selection.start,
            tabWidth = tabWidth,
            autoIndent = autoIndent
        )
        return EditorInputEditResult(
            value = TextFieldValue(text, TextRange(caret.coerceIn(0, text.length))),
            changesDocument = true
        )
    }
}
