package com.codespace.ide.ide.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.zIndex
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.runtime.Composable
import com.codespace.ide.ide.codeintel.PythonSyntaxDiagnostic
import com.codespace.ide.ide.theme.IdeTheme

/**
 * Draws and hit-tests the editor's pinned line gutter. Document mutation remains
 * in PyEditor and is reported through [onLineTap], keeping this component presentational.
 */
@Composable
internal fun EditorGutterOverlay(
    filePath: String,
    foldedDocument: FoldedEditorDocument,
    rows: GutterRows,
    showLineNumbers: Boolean,
    fontSize: Float,
    codeFontFamily: FontFamily,
    diagnostics: List<PythonSyntaxDiagnostic>,
    breakpointLines: Set<Int>,
    width: Dp,
    textMeasurer: TextMeasurer,
    scrollY: () -> Int,
    viewportHeightPx: () -> Int,
    pinchScale: () -> Float,
    fontRatio: () -> Float,
    pinchPivotY: () -> Float,
    pinchGutterPx: () -> Float,
    horizontalTranslation: Float,
    wordWrap: Boolean,
    foldSlotWidth: Dp,
    onLineTap: (sourceLine: Int, foldChevron: Boolean) -> Unit
) {
    val density = LocalDensity.current
    val errors = diagnostics.asSequence()
        .filter { it.kind.contains("error", ignoreCase = true) || it.kind.equals("Fatal", true) }
        .map { it.line }.toSet()
    val warnings = diagnostics.asSequence()
        .filterNot { it.kind.contains("error", ignoreCase = true) || it.kind.equals("Fatal", true) }
        .map { it.line }.toSet()

    Box(Modifier.fillMaxSize().zIndex(1f)) {
        Box(
            Modifier
                .graphicsLayer { translationX = horizontalTranslation }
                .width(width)
                .fillMaxHeight()
                .drawBehind { drawRect(Color(IdeTheme.BG), size = size) }
        ) {
            LineGutter(
                rows = rows,
                lineNumbers = foldedDocument.visibleSourceLines,
                showLineNumbers = showLineNumbers,
                fontSize = fontSize,
                codeFontFamily = codeFontFamily,
                errorLines = errors,
                warningLines = warnings,
                breakpointLines = breakpointLines,
                foldableLines = foldedDocument.foldableLines,
                collapsedLines = foldedDocument.collapsedLines,
                widthDp = width,
                textMeasurer = textMeasurer,
                scrollY = scrollY,
                viewportHeightPx = viewportHeightPx,
                pinchScale = pinchScale,
                fontRatio = fontRatio,
                pinchPivotY = pinchPivotY,
                pinchGutterPx = pinchGutterPx,
                modifier = Modifier.pointerInput(
                    filePath, foldedDocument, breakpointLines, wordWrap, showLineNumbers, foldSlotWidth
                ) {
                    detectTapGestures { tap ->
                        val topPadding = with(density) { 8.dp.toPx() }
                        val localY = (tap.y - topPadding).coerceAtLeast(0f)
                        val displayIndex = rows.rowAt(localY)
                        val sourceLine = foldedDocument.visibleSourceLines.getOrNull(displayIndex)
                            ?: return@detectTapGestures
                        val foldThreshold = size.width - with(density) { (foldSlotWidth + 4.dp).toPx() }
                        if (tap.x >= foldThreshold) {
                            if (sourceLine in foldedDocument.foldableLines) onLineTap(sourceLine, true)
                        } else {
                            onLineTap(sourceLine, false)
                        }
                    }
                }
            )
        }
    }
}
