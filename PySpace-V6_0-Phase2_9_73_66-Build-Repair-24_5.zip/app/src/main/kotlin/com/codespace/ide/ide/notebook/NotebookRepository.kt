package com.codespace.ide.ide.notebook

import kotlinx.coroutines.CoroutineScope
import com.codespace.ide.runtime.RuntimeDispatchers
import com.codespace.ide.runtime.RuntimeTaskScope
import com.codespace.ide.application.notebook.usecase.SerializeNotebookUseCase
import com.codespace.ide.application.notebook.usecase.ParseNotebookUseCase
import kotlinx.coroutines.withContext
import java.io.File
import java.lang.ref.WeakReference
import com.codespace.ide.ide.editor.OpenTab
import com.codespace.ide.ide.JSON
import com.codespace.ide.ide.NotebookKernelManager
import com.codespace.ide.ide.projects.PyProject

/**
 * Application-scoped notebook data/session boundary. A notebook session and
 * its kernel survive Compose disposal (Raw JSON toggle, tab changes and
 * Activity recreation); the UI only attaches to the existing state holder.
 */
class NotebookRepository(
    private val kernels: NotebookKernelManager,
    private val dispatchers: RuntimeDispatchers = RuntimeDispatchers.Default,
    taskScope: RuntimeTaskScope = RuntimeTaskScope(dispatchers),
    private val serializeNotebookUseCase: SerializeNotebookUseCase,
    private val parseNotebookUseCase: ParseNotebookUseCase,
) {
    private val sessions = NotebookSessionRegistry()
    private val scope: CoroutineScope = taskScope.scope

    suspend fun parse(source: String): NbDoc? {
        val snapshot = withContext(dispatchers.cpu) { parseNotebookUseCase(source) } ?: return null
        // Compose SnapshotStateList/MutableState objects are created only at the presentation boundary.
        return withContext(dispatchers.main) { snapshot.toUiDocument() }
    }

    suspend fun serialize(document: NbDoc): String {
        // Capture Compose-backed mutable state before switching dispatchers.
        // Only the immutable snapshot crosses to the CPU dispatcher.
        val snapshot = com.codespace.ide.ide.snapshotNotebook(document)
        return withContext(dispatchers.cpu) {
            serializeNotebookUseCase(snapshot)
        }
    }

    /** Returns an existing session when available, otherwise creates one. */
    fun sessionFor(file: File, project: PyProject, document: NbDoc, tab: OpenTab): NotebookViewModel {
        val entry = sessions.getOrCreate(
            file = file,
            project = project,
            onExisting = { existing ->
                if (tab.text != existing.lastPersistedText) {
                    existing.viewModel.replaceDocument(document)
                    existing.lastPersistedText = tab.text
                }
            },
            create = {
                val kernel = kernels.kernelFor(file, project)
                val created = NotebookViewModel(document, kernel, scope)
                val unsubscribe = kernel.subscribe { message -> created.onMessage(message) }
                NotebookSessionRegistry.Entry(created, unsubscribe, tab.text)
            },
        )
        val viewModel = entry.viewModel
        // Keep the editor buffer synchronized even while the notebook UI is
        // detached (for example while the user views Raw JSON).
        val tabReference = WeakReference(tab)
        viewModel.setPersistenceHandler { doc, revision ->
            val snapshot = serialize(doc)
            val activeTab = tabReference.get() ?: return@setPersistenceHandler
            if (viewModel.version == revision && !viewModel.isDocumentReplacementPending) {
                // If Raw JSON has been edited since our last write, do not
                // overwrite the user's newer buffer with a stale snapshot.
                sessions.withCurrent(file, project, viewModel) { current ->
                    if (activeTab.text == current.lastPersistedText &&
                        viewModel.version == revision && !viewModel.isDocumentReplacementPending
                    ) {
                        activeTab.replaceText(snapshot)
                        current.lastPersistedText = snapshot
                    }
                }
            }
        }
        return viewModel
    }

    fun existingSession(file: File, project: PyProject, tab: OpenTab): NotebookViewModel? =
        sessions.findMatching(file, project, tab.text)

    /** Release when the underlying notebook file is moved, renamed or deleted. */
    fun release(file: File, project: PyProject) {
        val entry = sessions.remove(file, project)
        entry?.unsubscribe?.invoke()
        entry?.viewModel?.dispose()
        kernels.release(file, project)
    }

    /** Release cached notebook sessions below a file/folder that was moved, renamed or deleted. */
    fun releaseUnder(path: File, project: PyProject) {
        val removed = sessions.removeUnder(path, project)
        removed.forEach { entry ->
            entry.unsubscribe()
            entry.viewModel.dispose()
        }
        kernels.releaseUnder(path, project)
    }

    /** Release every notebook session and kernel owned by a deleted project. */
    fun releaseProject(project: PyProject) {
        val removed = sessions.removeProject(project)
        removed.forEach { entry ->
            entry.unsubscribe()
            entry.viewModel.dispose()
        }
        // The project is gone, so no notebook kernel belonging to it can be reused.
        kernels.releaseProject(project)
    }

    fun shutdownAll() {
        val all = sessions.drain()
        all.forEach {
            it.unsubscribe()
            it.viewModel.dispose()
        }
        kernels.shutdownAll()
    }
}
