package com.codespace.ide.ide.filetree

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import com.codespace.ide.ide.HTML
import com.codespace.ide.ide.JSON
import com.codespace.ide.ide.theme.IdeTheme

/** Four-segment tab bar across the drawer top (Files · Search · Structure · Git). */
@Composable
internal fun DrawerTabBar(selected: Int, onSelect: (Int) -> Unit) {
    val icons = listOf("❏", "⌕", "</>", "⎇")
    Row(
        Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 8.dp)
        .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
        .background(Color(IdeTheme.CARD))
        .padding(4.dp)
    ) {
        icons.forEachIndexed { i, glyph ->
            val sel = i == selected
            Box(
                Modifier
                .weight(1f)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
                .background(if (sel) Color(IdeTheme.VIOLET) else Color.Transparent)
                .clickable { onSelect(i) }
                .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    glyph, fontSize = 15.sp,
                    color = if (sel) Color(IdeTheme.ON_VIOLET) else Color(IdeTheme.DIM)
                )
            }
        }
    }
}

@Composable
internal fun DrawerIconButton(glyph: String, desc: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, modifier = Modifier.size(38.dp)) {
        Text(glyph, fontSize = 17.sp, color = Color(IdeTheme.DIM))
    }
}

/** Compact, modern file-type badge. All labels are derived from the filename;
 *  this composable deliberately performs no filesystem inspection. */
@Composable
internal fun LetterBadge(label: String, argb: Long, size: androidx.compose.ui.unit.Dp = 26.dp) {
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(7.dp))
            .background(Color(argb).copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            fontSize = if (label.length >= 3) 7.sp else 9.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color(argb),
            maxLines = 1
        )
    }
}

/** File and folder badges used consistently across the tree and pickers. */
@Composable
internal fun FileBadge(f: File, isDirectory: Boolean) {
    if (isDirectory) {
        LetterBadge("▰", 0xFFFFC14D)
        return
    }
    val ext = f.extension.lowercase()
    val (label, argb) = when (ext) {
        "py", "pyw", "pyi" -> "PY" to 0xFF62C995
        "js", "mjs", "cjs" -> "JS" to 0xFFF0C64B
        "jsx" -> "JSX" to 0xFFF0C64B
        "ts", "mts", "cts" -> "TS" to 0xFF5599E8
        "tsx" -> "TSX" to 0xFF5599E8
        "html", "htm" -> "HTML" to 0xFFE87945
        "css" -> "CSS" to 0xFF6599E8
        "scss", "sass", "less" -> "CSS" to 0xFFC778A8
        "kt", "kts" -> "KT" to 0xFFB28AF2
        "java" -> "JAVA" to 0xFFE58B55
        "md", "markdown", "mdx" -> "MD" to 0xFF82AAFF
        "txt", "text" -> "TXT" to 0xFFB6C2D2
        "log" -> "LOG" to 0xFF9AA8B8
        "toml" -> "TOML" to 0xFFE6A15B
        "cfg", "ini", "conf" -> "CFG" to 0xFFE6A15B
        "pro" -> "R8" to 0xFF56C7B5
        "db", "sqlite", "sqlite3" -> "DB" to 0xFF56C7B5
        "json" -> "JSON" to 0xFFF2C14D
        "yaml", "yml" -> "YML" to 0xFFE0B65A
        "xml" -> "XML" to 0xFFC792EA
        "sh", "bash", "zsh" -> "SH" to 0xFF7FD6A4
        "c" -> "C" to 0xFF6D9FE8
        "h", "hpp" -> "H" to 0xFF6D9FE8
        "cc", "cpp", "cxx" -> "C++" to 0xFF6D9FE8
        "go" -> "GO" to 0xFF58BFCB
        "rs" -> "RS" to 0xFFD58B57
        "php" -> "PHP" to 0xFF8B9BE8
        "rb" -> "RB" to 0xFFE36D78
        "swift" -> "SW" to 0xFFE58B55
        "dart" -> "DART" to 0xFF55B9D8
        "sql" -> "SQL" to 0xFF6AA9D8
        "gradle" -> "GR" to 0xFF69B88A
        "properties" -> "PROP" to 0xFFB3A17B
        "ipynb" -> "NB" to 0xFFE6A15B
        "pdf" -> "PDF" to 0xFFE56D70
        "png", "jpg", "jpeg", "gif", "webp", "bmp", "ico", "svg" -> "IMG" to 0xFF7FCB9A
        "mp3", "wav", "ogg", "flac", "m4a" -> "AUD" to 0xFFB18AE8
        "mp4", "mkv", "mov", "webm" -> "VID" to 0xFFDB8A65
        "zip", "tar", "gz", "tgz", "bz2", "xz", "7z", "rar" -> "ZIP" to 0xFFE0AD54
        else -> "?" to 0xFF9AA8B8
    }
    LetterBadge(label, argb)
}

/** Build/output/cache dirs render dimmed (still expandable). */
internal fun isDimTreeDir(name: String): Boolean {
    val n = name.lowercase()
    return n == "build" || n == "outputs" || n == "dist" ||
    n == "__pycache__" || n == ".git" || n == "venv" || n == ".venv" ||
    n == ".idea" || n == ".vscode" || n == ".pytest_cache"
}

/** Folder glyph: module green for the project root, package grid for source
 *  dirs, image green for res, cube orange for assets, amber otherwise. */
@Composable
internal fun DirGlyph(f: File, isPkg: Boolean, root: Boolean) {
    val name = f.name.lowercase()
    val (glyph, argb) = when {
        root -> "⌂" to IdeTheme.ACCENT
        isPkg -> "▦" to IdeTheme.LILAC
        name == "res" || name == "drawable" || name == "layout" ||
            name == "values" || name == "mipmap" -> "▧" to 0xFF7FD6A4
        name == "assets" -> "▣" to 0xFFFF9E57
        else -> "▰" to 0xFFFFC14D
    }
    Box(
        Modifier
            .size(26.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(Color(argb).copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
    ) {
        Text(glyph, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(argb))
    }
}

/**
 * True when the row represents [path]: exact file match, or a middle
 * segment of a collapsed chain (whose row file is the deepest dir).
 */
internal fun nodeMatchesPath(node: TreeNode, path: String): Boolean {
    if (node.file.absolutePath == path) return true
    val label = node.label ?: return false
    val base = node.file.absolutePath.removeSuffix(label)
    var cur = base
    for (seg in label.split("/")) {
        cur += seg
        if (cur == path) return true
        cur += "/"
    }
    return false
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
internal fun TreeRow(
    node: TreeNode,
    expanded: Boolean,
    selected: Boolean,
    flash: Boolean = false,
    onToggle: () -> Unit,
    onOpen: (File) -> Unit,
    onLong: () -> Unit
) {
    val isDir = node.isDirectory
    val pulseAlpha = if (flash) {
        val flashTransition = rememberInfiniteTransition(label = "tree-row-flash")
        flashTransition.animateFloat(
            initialValue = 0.12f,
            targetValue = 0.42f,
            animationSpec = infiniteRepeatable(tween(380), RepeatMode.Reverse),
            label = "tree-row-flash-alpha"
        ).value
    } else 0.22f
    val chevron = when {
        !isDir -> null
        expanded -> "▾"
        else -> "▸"
    }
    val dimmed = isDir && isDimTreeDir(node.file.name)
    Row(
        modifier = Modifier
        .fillMaxWidth()
        .padding(start = (6 + node.depth * 12).dp, end = 4.dp, top = 2.dp, bottom = 2.dp)
        .clip(androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
        .background(
            when {
                flash -> Color(IdeTheme.ACCENT).copy(alpha = pulseAlpha)
                selected -> Color(IdeTheme.ACCENT).copy(alpha = 0.14f)
                else -> Color.Transparent
            }
        )
        .combinedClickable(
            onClick = { if (isDir) onToggle() else onOpen(node.file) },
            onLongClick = onLong
        )
        .padding(start = 8.dp, end = 2.dp, top = 7.dp, bottom = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (chevron != null) {
            Text(chevron, fontSize = 11.sp, color = Color(IdeTheme.DIM), modifier = Modifier.width(16.dp))
        } else {
            Spacer(Modifier.width(16.dp))
        }
        if (isDir) DirGlyph(node.file, isPkg = node.isPkg, root = node.depth == 0)
        else FileBadge(node.file, isDirectory = false)
        Spacer(Modifier.width(8.dp))
        Text(
            node.label ?: node.file.name,
            fontSize = 14.sp,
            fontFamily = FontFamily.Monospace,
            color = when {
                selected -> Color(IdeTheme.ACCENT)
                dimmed -> Color(IdeTheme.DIM)
                else -> Color(IdeTheme.TEXT)
            },
            modifier = Modifier.weight(1f),
            maxLines = 1
        )
        TextButton(onClick = onLong, modifier = Modifier.size(30.dp)) {
            Text("⋮", fontSize = 15.sp, color = Color(IdeTheme.DIM))
        }
    }
}

/** One context-menu row: icon glyph, label, optional trailing/check. */
@Composable
internal fun CtxRow(
    glyph: String,
    label: String,
    danger: Boolean = false,
    indent: Boolean = false,
    trailing: String? = null,
    check: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick)
        .padding(
            start = if (indent) 26.dp else 4.dp,
            top = 9.dp, bottom = 9.dp, end = 4.dp
        ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (glyph.isNotEmpty()) {
            Text(
                glyph, fontSize = 15.sp,
                color = if (danger) Color(IdeTheme.ERROR) else Color(IdeTheme.DIM),
                modifier = Modifier.width(28.dp)
            )
        }
        Text(
            label, fontSize = 14.sp,
            color = if (danger) Color(IdeTheme.ERROR) else Color(IdeTheme.TEXT),
            modifier = Modifier.weight(1f)
        )
        when {
            trailing != null -> Text(trailing, fontSize = 13.sp, color = Color(IdeTheme.DIM))
            check -> Text("✓", fontSize = 14.sp, color = Color(IdeTheme.LILAC))
        }
    }
}

/** Breadcrumb chips for the copy/move picker: project › … › dest. */
@Composable
internal fun PickBreadcrumb(root: File, dest: File, onPick: (File) -> Unit) {
    val segs = try {
        root.toURI().relativize(dest.toURI()).path.trim('/').split('/').filter { it.isNotEmpty() }
    } catch (_: Exception) {
        emptyList()
    }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        var acc = root
        Crumb(root.name, current = segs.isEmpty()) { onPick(root) }
        for (s in segs) {
            Text(" › ", color = Color(IdeTheme.DIM), fontSize = 12.sp)
            acc = File(acc, s)
            val here = acc
            Crumb(s, current = here.absolutePath == dest.absolutePath) { onPick(here) }
        }
    }
}

@Composable
internal fun Crumb(label: String, current: Boolean, onClick: () -> Unit) {
    TextButton(onClick = onClick) {
        Text(
            label, fontSize = 12.sp, maxLines = 1,
            color = if (current) Color(IdeTheme.LILAC) else Color(IdeTheme.DIM),
            fontWeight = if (current) FontWeight.Bold else FontWeight.Normal
        )
    }
}
