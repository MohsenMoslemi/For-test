package com.codespace.ide.ide.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ide.theme.IdeTheme

/**
 * Real line geometry of the BasicTextField's current [TextLayoutResult], queried
 * on demand per logical line (no per-line tables are built).
 */
internal class GutterGeometry(
    private val layout: TextLayoutResult,
    private val lineStarts: IntArray
) {
    private fun visualLine(i: Int): Int =
        layout.getLineForOffset(lineStarts[i.coerceIn(0, lineStarts.lastIndex)])

    fun top(i: Int): Float = layout.getLineTop(visualLine(i))
    fun firstHeight(i: Int): Float {
        val v = visualLine(i)
        return (layout.getLineBottom(v) - layout.getLineTop(v)).coerceAtLeast(1f)
    }
    fun baseline(i: Int): Float = layout.getLineBaseline(visualLine(i))
}

/** Row positions for the gutter: real geometry when available, a pitch-based estimate otherwise. */
internal class GutterRows(
    private val geometry: GutterGeometry?,
    val count: Int,
    private val pitchPx: Float,
    private val rowPrefix: IntArray?
) {
    private fun rowsBefore(i: Int): Int {
        val p = rowPrefix
        return if (p != null && i >= 0 && i < p.size) p[i] else i
    }

    fun top(i: Int): Float = geometry?.top(i) ?: (rowsBefore(i) * pitchPx)
    fun height(i: Int): Float = geometry?.firstHeight(i) ?: pitchPx
    /** First-row baseline in text-layout coordinates, NaN when only an estimate is available. */
    fun baseline(i: Int): Float = geometry?.baseline(i) ?: Float.NaN
    fun bottom(): Float = if (count <= 0) 0f else top(count - 1) + height(count - 1)

    /** Last row whose top is at or above [y] (rows are ordered top to bottom). */
    fun rowAt(y: Float): Int {
        if (count <= 0) return 0
        var lo = 0
        var hi = count - 1
        var answer = 0
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (top(mid) <= y) {
                answer = mid
                lo = mid + 1
            } else {
                hi = mid - 1
            }
        }
        return answer
    }
}

/**
 * Line-number / breakpoint / fold gutter, painted on ONE canvas. Only the rows
 * inside (or just next to) the viewport are measured and drawn, so cost per
 * frame is independent of file size and there is no per-line composition.
 * Reading [scrollY] / [pinchScale] inside the draw block re-draws on scroll
 * without recomposing anything.
 */
@Composable
internal fun LineGutter(
    rows: GutterRows,
    lineNumbers: List<Int>,
    showLineNumbers: Boolean,
    fontSize: Float,
    codeFontFamily: FontFamily,
    errorLines: Set<Int>,
    warningLines: Set<Int>,
    breakpointLines: Set<Int>,
    foldableLines: Set<Int>,
    collapsedLines: Set<Int>,
    widthDp: Dp,
    textMeasurer: TextMeasurer,
    scrollY: () -> Int,
    viewportHeightPx: () -> Int,
    pinchScale: () -> Float,
    fontRatio: () -> Float,
    pinchPivotY: () -> Float,
    pinchGutterPx: () -> Float,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val topPaddingPx = with(density) { 8.dp.toPx() }
    val horizontalPaddingPx = with(density) { 4.dp.toPx() }
    // Same three lanes as the editor's width math (marker | number | fold).
    val markerWidthPx = with(density) { maxOf(18f, fontSize * 0.72f * density.fontScale).dp.toPx() }
    val foldWidthPx = with(density) { maxOf(28f, fontSize * 1.05f * density.fontScale).dp.toPx() }
    val widthPx = with(density) { widthDp.toPx() }
    val numberWidthPx = (widthPx - markerWidthPx - foldWidthPx - with(density) { 8.dp.toPx() }).coerceAtLeast(0f)

    val numberStyle = remember(fontSize, codeFontFamily) {
        TextStyle(
            color = Color(IdeTheme.COMMENT),
            fontFamily = codeFontFamily,
            fontSize = (fontSize * 0.9f).sp
        )
    }
    // Layout caches live exactly as long as the metrics they were measured with.
    val numberCache = remember(fontSize, codeFontFamily, density.density, density.fontScale) { HashMap<Int, TextLayoutResult>() }
    val glyphCache = remember(fontSize, density.density, density.fontScale) { HashMap<String, TextLayoutResult>() }
    fun glyph(text: String, sizeSp: Float, color: Color): TextLayoutResult =
        glyphCache.getOrPut(text) {
            textMeasurer.measure(
                text = text,
                style = TextStyle(color = color, fontSize = sizeSp.sp),
                softWrap = false,
                maxLines = 1
            )
        }

    // The gutter is a sibling overlay rather than a child of the code's
    // graphicsLayer. Its measured height must therefore follow the same
    // vertical transform or zoom-in can clip lower rows at the old bounds.
    val previewScale = pinchScale().takeIf { it > 0f } ?: 1f
    val previewPivotY = pinchPivotY()
    val unscaledBottom = rows.bottom() + topPaddingPx
    val previewBottom = if (previewScale != 1f) {
        previewPivotY + (unscaledBottom - previewPivotY) * previewScale
    } else unscaledBottom
    val heightDp = with(density) { previewBottom.coerceAtLeast(1f).toDp() }

    val dens = density
    Canvas(modifier = modifier.width(widthDp).height(heightDp)) {
        val count = lineNumbers.size
        if (count == 0) return@Canvas
        val viewportH = viewportHeightPx().toFloat()
        val sy = scrollY().toFloat()
        // Rows follow the PITCH ratio (sc); glyphs and lane widths follow the FONT ratio (k).
        val sc0 = pinchScale()
        val k = fontRatio().takeIf { it > 0f } ?: 1f
        val pinching = (sc0 != 1f && sc0 > 0f) || k != 1f
        val sc = if (sc0 > 0f) sc0 else 1f
        val py = if (pinching) pinchPivotY() else 0f
        // Visible span in sheet coordinates. While pinching, the code layer is scaled
        // about the pinch centre, so the span that is actually on screen is wider
        // (zoom out) or narrower (zoom in).
        var lo = sy
        var hi = sy + viewportH
        if (pinching) {
            lo = py + (sy - py) / sc
            hi = py + (sy + viewportH - py) / sc
        }
        val margin = rows.height(0) * 2f
        if (numberCache.size > 4000) numberCache.clear()

        // Lane geometry. While pinching the gutter is laid out for the font size that
        // will be committed on release (so its width never jumps when the fingers lift);
        // only the glyphs are scaled, about their own anchor points, to follow the code.
        val markerW = if (pinching) with(dens) { maxOf(18f, fontSize * k * 0.72f * dens.fontScale).dp.toPx() } else markerWidthPx
        val foldW = if (pinching) with(dens) { maxOf(28f, fontSize * k * 1.05f * dens.fontScale).dp.toPx() } else foldWidthPx
        val gutterW = if (pinching) pinchGutterPx() else widthPx
        val laneNumberRight = gutterW - foldW - horizontalPaddingPx

        var i = rows.rowAt(lo - topPaddingPx - margin)
        while (i < count) {
            val rowTop = rows.top(i) + topPaddingPx
            if (rowTop > hi + margin) break
            val rowHeight = rows.height(i)
            val line = lineNumbers[i]
            // On-screen row box (rows scale about the pinch centre like the code does).
            val top = if (pinching) py + (rowTop - py) * sc else rowTop
            val cy = top + rowHeight * (if (pinching) sc else 1f) / 2f

            if (line in breakpointLines) {
                val g = glyph("●", fontSize * 0.72f, Color(IdeTheme.ERROR))
                val cx = horizontalPaddingPx + markerW / 2f
                drawScaledLayout(g, cx - g.size.width / 2f, cy - g.size.height / 2f, k, Offset(cx, cy))
            }

            if (showLineNumbers) {
                val t = numberCache.getOrPut(line) {
                    textMeasurer.measure(
                        text = line.toString(),
                        style = numberStyle,
                        softWrap = false,
                        maxLines = 1
                    )
                }
                val baseline = rows.baseline(i)
                // Sit on the code's own baseline whenever the real layout is known.
                if (baseline.isNaN()) {
                    drawScaledLayout(t, laneNumberRight - t.size.width, cy - t.size.height / 2f, k, Offset(laneNumberRight, cy))
                } else {
                    val baseAbs = topPaddingPx + baseline
                    val by = if (pinching) py + (baseAbs - py) * sc else baseAbs
                    drawScaledLayout(t, laneNumberRight - t.size.width, by - t.firstBaseline, k, Offset(laneNumberRight, by))
                }
            }

            val laneText: String?
            val laneSize: Float
            val laneColor: Color
            when {
                line in foldableLines -> {
                    // Material "chevron_right" / "expand_more", drawn as a vector in the
                    // theme's light text colour so it reads clearly on the dark gutter.
                    val cx = laneNumberRight + foldW / 2f
                    val iconPx = minOf(
                        with(dens) { (fontSize * 1.3f * dens.fontScale).dp.toPx() },
                        rowHeight * 0.95f,
                        foldW
                    ) * k
                    drawFoldIcon(line in collapsedLines, cx, cy, iconPx, Color(IdeTheme.TEXT).copy(alpha = 0.92f))
                    laneText = null
                    laneSize = 0f
                    laneColor = Color.Unspecified
                }
                line in errorLines -> {
                    laneText = "!"
                    laneSize = fontSize * 0.85f
                    laneColor = Color(IdeTheme.ERROR)
                }
                line in warningLines -> {
                    laneText = "!"
                    laneSize = fontSize * 0.85f
                    laneColor = Color(IdeTheme.WARN)
                }
                else -> {
                    laneText = null
                    laneSize = 0f
                    laneColor = Color.Unspecified
                }
            }
            if (laneText != null) {
                val g = glyph(laneText, laneSize, laneColor)
                val cx = laneNumberRight + foldW / 2f
                drawScaledLayout(g, cx - g.size.width / 2f, cy - g.size.height / 2f, k, Offset(cx, cy))
            }
            i++
        }
    }
}

// Official Material icon path data (24 x 24 viewport), filled.
internal val ChevronRightPath: Path by lazy {
    PathParser().parsePathString("M10,6L8.59,7.41 13.17,12l-4.58,4.59L10,18l6,-6z").toPath()
}

internal val ExpandMorePath: Path by lazy {
    PathParser().parsePathString("M16.59,8.59L12,13.17 7.41,8.59 6,10l6,6 6,-6z").toPath()
}

/** Draws the fold affordance centred on ([cx], [cy]) with an edge of [sizePx]. */
internal fun DrawScope.drawFoldIcon(collapsed: Boolean, cx: Float, cy: Float, sizePx: Float, color: Color) {
    if (sizePx <= 0f) return
    withTransform({
        translate(cx - sizePx / 2f, cy - sizePx / 2f)
        scale(sizePx / 24f, sizePx / 24f, Offset.Zero)
    }) {
        drawPath(if (collapsed) ChevronRightPath else ExpandMorePath, color)
    }
}
