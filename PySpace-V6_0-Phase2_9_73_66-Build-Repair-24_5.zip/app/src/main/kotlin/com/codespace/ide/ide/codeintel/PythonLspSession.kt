package com.codespace.ide.ide.codeintel

import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.nio.charset.StandardCharsets
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import org.json.JSONArray
import org.json.JSONObject
import com.codespace.ide.ide.JSON

/**
 * Owns one pylsp process and its JSON-RPC stdio transport.
 * Project lifecycle, document synchronization and diagnostics policy remain
 * with [PythonLspController]; this class is deliberately limited to framing,
 * request correlation, protocol responses and process shutdown.
 */
internal class PythonLspSession(
    private val process: Process,
    private val onNotification: (JSONObject) -> Unit,
) : LspSessionTransport {
    private val input = BufferedInputStream(process.inputStream)
    private val output = process.outputStream
    private val ids = AtomicInteger(1)
    private val pending = ConcurrentHashMap<Int, CompletableFuture<JSONObject>>()
    private val versions = ConcurrentHashMap<String, Int>()
    @Volatile private var ended = false

    override val isAlive: Boolean get() = !ended && process.isAlive

    init {
        Thread({ readLoop() }, "PySpace-LSP-stdout").apply { isDaemon = true; start() }
        Thread({ drainStderr() }, "PySpace-LSP-stderr").apply { isDaemon = true; start() }
    }

    override fun documentVersion(uri: String): Int = versions[uri] ?: 0
    override fun setDocumentVersion(uri: String, version: Int) { versions[uri] = version }
    override fun forgetDocument(uri: String) { versions.remove(uri) }

    @Synchronized
    override fun notify(method: String, params: JSONObject) {
        send(JSONObject().put("jsonrpc", "2.0").put("method", method).put("params", params))
    }

    override fun request(method: String, params: JSONObject, timeoutMs: Long): Any? {
        val id = ids.getAndIncrement()
        val future = CompletableFuture<JSONObject>()
        pending[id] = future
        synchronized(this) {
            send(JSONObject().put("jsonrpc", "2.0").put("id", id).put("method", method).put("params", params))
        }
        val response = try { future.get(timeoutMs, TimeUnit.MILLISECONDS) }
        catch (error: Exception) { pending.remove(id); throw error }
        val rpcError = response.optJSONObject("error")
        if (rpcError != null) throw IllegalStateException(rpcError.optString("message", "LSP request failed"))
        return response.opt("result")
    }

    private fun send(message: JSONObject) {
        val bytes = message.toString().toByteArray(StandardCharsets.UTF_8)
        output.write("Content-Length: ${bytes.size}\r\n\r\n".toByteArray(StandardCharsets.US_ASCII))
        output.write(bytes)
        output.flush()
    }

    private fun readLoop() {
        try {
            while (!ended && process.isAlive) {
                var contentLength = -1
                while (true) {
                    val line = readAsciiLine(input) ?: return
                    if (line.isEmpty()) break
                    val colon = line.indexOf(':')
                    if (colon > 0 && line.substring(0, colon).trim().equals("Content-Length", true)) {
                        contentLength = line.substring(colon + 1).trim().toIntOrNull() ?: -1
                    }
                }
                if (contentLength < 0 || contentLength > MAX_MESSAGE_BYTES) continue
                val payload = ByteArray(contentLength)
                var offset = 0
                while (offset < contentLength) {
                    val count = input.read(payload, offset, contentLength - offset)
                    if (count < 0) throw IllegalStateException("LSP process closed its output")
                    offset += count
                }
                val message = JSONObject(String(payload, StandardCharsets.UTF_8))
                val method = message.optString("method")
                if (method == "textDocument/publishDiagnostics") {
                    message.optJSONObject("params")?.let(onNotification)
                } else if (method.isNotEmpty() && message.has("id") && !message.isNull("id")) {
                    // The server may request client capabilities/configuration while
                    // starting. Answer conservatively instead of leaving its request
                    // unanswered and stalling the JSON-RPC message loop.
                    val id = message.opt("id")
                    val result: Any? = when (method) {
                        "workspace/configuration", "workspace/workspaceFolders" -> JSONArray()
                        "workspace/applyEdit" -> JSONObject().put("applied", false)
                        else -> JSONObject.NULL
                    }
                    synchronized(this) {
                        send(JSONObject().put("jsonrpc", "2.0").put("id", id).put("result", result))
                    }
                } else if (message.has("id") && !message.isNull("id")) {
                    val id = message.optInt("id", -1)
                    pending.remove(id)?.complete(message)
                }
            }
        } catch (_: Exception) {
        } finally {
            ended = true
            pending.values.forEach { it.completeExceptionally(IllegalStateException("LSP process ended")) }
            pending.clear()
        }
    }

    private fun drainStderr() {
        try { process.errorStream.bufferedReader().use { reader -> while (reader.readLine() != null) { /* diagnostics/logs stay off protocol stdout */ } } }
        catch (_: Exception) { }
    }

    override fun close() {
        if (!ended) {
            try { notify("exit", JSONObject()) } catch (_: Exception) { }
        }
        ended = true
        try { output.close() } catch (_: Exception) { }
        try { input.close() } catch (_: Exception) { }
        process.destroy()
        Thread({
            try { if (!process.waitFor(350, TimeUnit.MILLISECONDS)) process.destroyForcibly() }
            catch (_: Exception) { process.destroyForcibly() }
        }, "PySpace-LSP-stop").apply { isDaemon = true; start() }
        pending.values.forEach { it.completeExceptionally(IllegalStateException("LSP session closed")) }
        pending.clear()
    }

    private fun readAsciiLine(input: InputStream): String? {
        val bytes = ByteArrayOutputStream()
        while (true) {
            val value = input.read()
            if (value < 0) return if (bytes.size() == 0) null else String(bytes.toByteArray(), StandardCharsets.US_ASCII)
            if (value == 10) break
            if (value != 13) bytes.write(value)
            if (bytes.size() > 8192) throw IllegalStateException("Oversized LSP header")
        }
        return String(bytes.toByteArray(), StandardCharsets.US_ASCII)
    }

    private companion object {
        const val MAX_MESSAGE_BYTES = 8 * 1024 * 1024
    }
}
