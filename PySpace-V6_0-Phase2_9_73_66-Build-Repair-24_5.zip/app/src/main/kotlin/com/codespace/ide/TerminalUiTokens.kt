package com.codespace.ide

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ide.theme.IdeTheme

internal val TerminalBg get() = Color(IdeTheme.BG)
internal val Accent get() = Color(IdeTheme.ACCENT)
internal val Warn get() = Color(IdeTheme.WARN)
internal val TermText get() = Color(IdeTheme.TEXT)

internal val TermStyle = TextStyle(
    fontFamily = FontFamily.Monospace,
    fontSize = 13.sp,
    lineHeight = 18.sp
)

// Selection handle geometry (touch box). The teardrop tip sits HandleTipY
// below the box top, exactly on the endpoint's line bottom, and the round
// body hangs BELOW the text line (like Android's native handles) so it never
// covers the selected characters. The box is big on purpose: the old 32x44dp
// box with a 14dp dot was easy to miss, and a missed press became a
// long-press that re-anchored the selection somewhere else.
internal val HandleW = 48.dp
internal val HandleH = 56.dp
internal val HandleTipY = 4.dp

/**
 * Invisible IME conduit buffer. The field itself is 1dp and never shows
 * content; every committed char is diffed out and sent straight to the PTY.
 * Backspace on the sentinel becomes a real DEL (0x7f) the same way.
 */
internal const val IME_SENTINEL = "x"

/**
 * UI flush cadence for PTY output: at most ~15 recompositions/sec during a
 * burst, immediate when idle. Bounds per-flush parse work on the Main thread.
 */
internal const val FLUSH_WINDOW_MS = 64L

/**
 * Trailing fast flush: when output arrives less than FLUSH_WINDOW_MS after
 * the previous flush (continuous interaction: typing, TAB completion), do
 * NOT wait for the next 64ms loop tick — flush ~32ms later instead. This is
 * what makes small interactive output (e.g. the TAB-completion prompt)
 * feel immediate. Heavy bursts exceed SMALL_FLUSH_CHARS and stay on the
 * 64ms loop, so bulk output still coalesces instead of recomposing at 30fps.
 */
internal const val TRAILING_FLUSH_MS = 32L
internal const val SMALL_FLUSH_CHARS = 4096L

/**
 * Per-flush parse bound on the Main thread. One huge backlog is split
 * across flushes (leftovers stay queued, nothing is dropped) instead of
 * blocking one frame for hundreds of milliseconds.
 */
internal const val MAX_FLUSH_CHARS = 65536

/**
 * Deliberate clipboard safety cap. Android Binder rejects ~1MB+ clipboard
 * transactions with TransactionTooLargeException (an app crash), so copying
 * is refused above 400k chars (~800KB UTF-16, safe margin included) with a
 * clear message instead of crashing or silently truncating.
 */
internal const val MAX_COPY_CHARS = 400_000
