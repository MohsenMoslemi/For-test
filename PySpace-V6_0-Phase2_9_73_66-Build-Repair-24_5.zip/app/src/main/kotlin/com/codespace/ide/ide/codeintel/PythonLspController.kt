package com.codespace.ide.ide.codeintel

import android.content.Context
import com.codespace.ide.ProotManager
import com.codespace.ide.domain.packages.PackageManagerRepository
import com.codespace.ide.runtime.RuntimeDispatchers
import java.io.File
import java.net.URI
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import com.codespace.ide.ide.JSON
import com.codespace.ide.ide.projects.PyProject

/**
 * Project-scoped Python Language Server controller.
 *
 * The server itself is installed once into Ubuntu from the APK-bundled wheelhouse.
 * Every project gets its own pylsp process so its workspace and selected venv
 * cannot leak into another open project. JSON-RPC is transported over the
 * process stdio using the LSP Content-Length framing (stderr is drained apart).
 */
data class PythonDefinitionLocation(val file: File, val line: Int, val column: Int)
enum class PythonReferenceKind { CALL, IMPORT, DEFINITION, OTHER }
data class PythonReferenceOccurrence(
    val file: File,
    val line: Int,
    val column: Int,
    val snippet: String,
    val kind: PythonReferenceKind = PythonReferenceKind.OTHER,
)

data class PythonSignatureParameter(val label: String, val start: Int, val end: Int, val documentation: String)
data class PythonSignatureInfo(
    val label: String,
    val documentation: String,
    val activeParameter: Int,
    val parameters: List<PythonSignatureParameter>
)

class PythonLspController(
    private val context: Context,
    private val proot: ProotManager,
    private val project: PyProject,
    private val packageManagerRepository: PackageManagerRepository,
    private val dispatchers: RuntimeDispatchers = RuntimeDispatchers.Default,
) : AutoCloseable {
    val projectRoot: File get() = project.dir
    private val scope = CoroutineScope(SupervisorJob() + dispatchers.main)
    private val jobs = ConcurrentHashMap<String, Job>()
    private val mutex = kotlinx.coroutines.sync.Mutex()
    private val importResolutionMutex = kotlinx.coroutines.sync.Mutex()
    private val _results = MutableStateFlow<Map<String, List<PythonSyntaxDiagnostic>>>(emptyMap())
    val results: StateFlow<Map<String, List<PythonSyntaxDiagnostic>>> = _results.asStateFlow()
    private val _lspResults = MutableStateFlow<Map<String, List<PythonSyntaxDiagnostic>>>(emptyMap())
    val lspResults: StateFlow<Map<String, List<PythonSyntaxDiagnostic>>> = _lspResults.asStateFlow()
    private val _validatedSources = MutableStateFlow<Map<String, String>>(emptyMap())
    val validatedSources: StateFlow<Map<String, String>> = _validatedSources.asStateFlow()
    private val documents = LspDocumentRegistry()
    private val workspaceConfiguration = LspWorkspaceConfiguration(project)
    private val documentSynchronizer = LspDocumentSynchronizer(
        documents = documents,
        uriFor = ::uriFor,
        refreshInterpreterSettings = workspaceConfiguration::refreshInterpreterSettings,
        refreshProjectImportRoots = workspaceConfiguration::refreshProjectImportRoots,
    )
    private val importResolutionJobs = ConcurrentHashMap<String, Job>()
    private val nativeDiagnostics = PythonNativeDiagnosticsSession(scope, dispatchers) { path, source ->
        publishCombinedDiagnostics(path, source)
    }
    private val workspaceReferenceResolver = PythonWorkspaceReferenceResolver(
        project = project,
        ioDispatcher = dispatchers.io,
        prepareDocument = ::prepareDocument,
        requestReferences = { file, source, offset, includeDeclaration ->
            references(file, source, offset, includeDeclaration)
        },
        findDefinition = ::definitionLocation,
        refreshImportRoots = { active ->
            mutex.lock()
            try { workspaceConfiguration.refreshProjectImportRoots(active) } finally { mutex.unlock() }
        },
    )
    private val lspDiagnosticsByPath = ConcurrentHashMap<String, List<PythonSyntaxDiagnostic>>()
    @Volatile private var session: LspSessionTransport? = null
    @Volatile private var observedEnvironmentRevision: Long = PythonEnvironmentRegistry.revision(project.dir)
    @Volatile private var closed = false
    @Volatile var lastRenameFailureReason: String = "Rename has not been attempted."
        private set

    // Start the project-scoped server as soon as the editor screen is entered,
    // not on the first keystroke. The runtime installer is separately warmed
    // at app startup, so this path should normally only launch/initialize pylsp.
    init {
        // Load the active project's package inventory independently of the
        // Package Manager screen. Auto-import must never assume that a package
        // exists merely because the inventory has not been read yet.
        scope.launch(dispatchers.io) {
            refreshInstalledPackageInventory()
        }
        scope.launch(dispatchers.io) {
            try {
                mutex.lock()
                try { if (!closed) ensureSession() } finally { mutex.unlock() }
            } catch (_: Exception) {
                // A later editor request may retry if the runtime is not ready.
            }
        }
    }

    private suspend fun refreshInstalledPackageInventory() {
        // The editor can be entered while a new project's venv is still being
        // prepared. Wait briefly for it; all work remains off the main thread.
        repeat(12) {
            if (closed) return
            if (PythonEnvironmentRegistry.installedPackages(project.dir) != null) return
            if (venvPythonReady(project.dir)) {
                try {
                    val installed = packageManagerRepository.listInstalled(project.dir)
                    if (!closed) {
                        PythonEnvironmentRegistry.update(project.dir, installed.map { it.name })
                    }
                } catch (_: Exception) {
                    // Unknown inventory is deliberately kept unknown. The
                    // auto-import catalogue fails closed until a later refresh.
                }
                return
            }
            delay(500)
        }
    }

    /** Current installed-package snapshot for the editor's conservative local fallback. */
    fun installedPackagesSnapshot(): Set<String>? = PythonEnvironmentRegistry.installedPackages(project.dir)

    /** Changes whenever the project's pip environment is refreshed or mutated. */
    fun environmentRevision(): Long = PythonEnvironmentRegistry.revision(project.dir)
    fun environmentProjectKey(): String = PythonEnvironmentRegistry.projectKey(project.dir)

    /** Debounced full-document sync. This is also the source for pylsp diagnostics. */
    fun schedule(project: PyProject, file: File, source: String) {
        if (project.dir.absolutePath != this.project.dir.absolutePath) return
        val path = file.absolutePath
        jobs.remove(path)?.cancel()
        if (closed || !file.extension.equals("py", ignoreCase = true) || source.length > MAX_SOURCE_CHARS) {
            _results.value = _results.value - path
            _validatedSources.value = _validatedSources.value - path
            nativeDiagnostics.remove(path)
            lspDiagnosticsByPath.remove(path)
            _lspResults.value = _lspResults.value - path
            return
        }
        nativeDiagnostics.schedule(file, source, MAX_SOURCE_CHARS)
        val job = scope.launch {
            val ownJob = currentCoroutineContext()[Job]
            delay(DEBOUNCE_MS)
            try {
                withContext(dispatchers.io) {
                    mutex.lock()
                    try {
                        val active = ensureSession() ?: return@withContext
                        syncDocument(active, file, source)
                    } finally {
                        mutex.unlock()
                    }
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                // A failed/absent server must not manufacture diagnostics.
            } finally {
                if (ownJob != null) jobs.remove(path, ownJob)
            }
        }
        jobs[path] = job
    }

    /**
     * Release one closed editor document from the controller's source snapshots
     * and tell pylsp that the document is no longer open. Reopening it performs
     * a fresh didOpen/sync, so this does not affect project files on disk.
     */
    fun closeDocument(file: File) {
        if (closed) return
        val path = file.absolutePath
        jobs.remove(path)?.cancel()
        nativeDiagnostics.remove(path)
        val uri = try { uriFor(file) } catch (_: Exception) { return }
        importResolutionJobs.remove(uri)?.cancel()
        documents.remove(uri)
        lspDiagnosticsByPath.remove(path)
        _results.value = _results.value - path
        _lspResults.value = _lspResults.value - path
        _validatedSources.value = _validatedSources.value - path
        try {
            session?.notify("textDocument/didClose", JSONObject()
                .put("textDocument", JSONObject().put("uri", uri)))
            session?.forgetDocument(uri)
        } catch (_: Exception) { }
    }

    /** Jedi-backed completion; null means the server is unavailable and caller may use fallback. */
    suspend fun complete(file: File, source: String, caret: Int): PythonCompletionResult? = withContext(dispatchers.io) {
        if (closed || source.length > MAX_SOURCE_CHARS || !hasCompletionTrigger(source, caret)) return@withContext null
        val active = prepareDocument(file, source) ?: return@withContext null
        try {
            val pos = positionAt(source, caret)
            val params = JSONObject()
                .put("textDocument", JSONObject().put("uri", uriFor(file)))
                .put("position", JSONObject().put("line", pos.first).put("character", pos.second))
                .put("context", JSONObject().put("triggerKind", if (source.getOrNull(caret - 1) == '.') 2 else 1)
                    .apply { if (source.getOrNull(caret - 1) == '.') put("triggerCharacter", ".") })
            val response = active.request("textDocument/completion", params, REQUEST_TIMEOUT_MS)
            val items = when {
                response is JSONArray -> response
                response is JSONObject -> response.optJSONArray("items") ?: JSONArray()
                else -> JSONArray()
            }
            val prefixStart = identifierStart(source, caret)
            val parsed = ArrayList<PythonCompletionItem>(items.length())
            var replaceStart = prefixStart
            var replaceEnd = caret.coerceIn(0, source.length)
            for (i in 0 until items.length()) {
                val item = items.optJSONObject(i) ?: continue
                val label = item.optString("label")
                if (label.isBlank()) continue
                val textEdit = item.optJSONObject("textEdit")
                val editRange = textEdit?.optJSONObject("range")
                    ?: textEdit?.optJSONObject("replace")
                    ?: textEdit?.optJSONObject("insert")
                if (editRange != null) {
                    val start = editRange.optJSONObject("start")
                    val end = editRange.optJSONObject("end")
                    if (start != null && end != null) {
                        replaceStart = offsetAt(source, start.optInt("line"), start.optInt("character"))
                        replaceEnd = offsetAt(source, end.optInt("line"), end.optInt("character"))
                    }
                }
                val insertText = textEdit?.optString("newText")?.takeIf { it.isNotEmpty() }
                    ?: item.optString("insertText").takeIf { it.isNotEmpty() } ?: label
                val kind = completionKind(item.optInt("kind", 6))
                parsed += PythonCompletionItem(label, kind, item.optString("detail", ""),
                    kind in setOf("function", "member"), i, insertText)
            }
            PythonCompletionResult(
                replaceStart.coerceIn(0, source.length),
                replaceEnd.coerceIn(replaceStart.coerceIn(0, source.length), source.length), parsed)
        } catch (_: Exception) { null }
    }

    /** Jedi-backed hover; null means no hover information or server unavailable. */
    suspend fun hover(file: File, source: String, offset: Int): PythonHoverDoc? = withContext(dispatchers.io) {
        if (closed || source.isEmpty() || source.length > MAX_SOURCE_CHARS) return@withContext null
        val active = prepareDocument(file, source) ?: return@withContext null
        try {
            val pos = positionAt(source, offset)
            val params = JSONObject()
                .put("textDocument", JSONObject().put("uri", uriFor(file)))
                .put("position", JSONObject().put("line", pos.first).put("character", pos.second))
            val response = active.request("textDocument/hover", params, REQUEST_TIMEOUT_MS) as? JSONObject
                ?: return@withContext null
            val contents = response.opt("contents") ?: return@withContext null
            val markdown = hoverText(contents).trim()
            if (markdown.isBlank()) return@withContext null
            val name = identifierAt(source, offset).ifBlank { "Python symbol" }
            val lines = markdown.lines().filter { it.isNotBlank() }
            val codeBlock = Regex("```(?:[A-Za-z0-9_+-]+)?\\s*\\n([\\s\\S]*?)```").find(markdown)
            val signature = codeBlock?.groupValues?.getOrNull(1)?.trim() ?: lines.firstOrNull()?.trim().orEmpty()
            val summary = if (codeBlock != null) markdown.removeRange(codeBlock.range).trim().ifBlank { markdown }
                else lines.drop(1).joinToString("\n").ifBlank { markdown }
            PythonHoverDoc(name, "symbol", signature, summary, markdown)
        } catch (_: Exception) { null }
    }

    private fun syncDocument(active: LspSessionTransport, file: File, source: String, refreshRoots: Boolean = true) {
        documentSynchronizer.sync(active, file, source, refreshRoots)
    }

    /** Prepare/update the document under a short lock, then let JSON-RPC requests run concurrently. */
    private suspend fun prepareDocument(file: File, source: String): LspSessionTransport? = withContext(dispatchers.io) {
        if (closed) return@withContext null
        mutex.lock()
        try {
            val active = ensureSession() ?: return@withContext null
            syncDocument(active, file, source)
            active
        } catch (_: Exception) {
            null
        } finally {
            mutex.unlock()
        }
    }

    /** Exposes additional standard LSP requests for editor actions (definition/references/rename/etc.). */
    suspend fun requestAt(
        file: File,
        source: String,
        method: String,
        offset: Int,
        extra: JSONObject = JSONObject(),
        timeoutMs: Long = REQUEST_TIMEOUT_MS,
    ): Any? = withContext(dispatchers.io) {
        val active = prepareDocument(file, source) ?: return@withContext null
        try {
            val pos = positionAt(source, offset)
            val params = JSONObject()
                .put("textDocument", JSONObject().put("uri", uriFor(file)))
                .put("position", JSONObject().put("line", pos.first).put("character", pos.second))
            val keys = extra.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                params.put(key, extra.get(key))
            }
            active.request(method, params, timeoutMs)
        } catch (_: Exception) { null }
    }

    /**
     * Returns the active Python call signature. Trigger characters are forwarded
     * using the LSP SignatureHelpContext contract; ordinary caret moves use
     * Invoked so the active parameter can be refreshed while typing.
     */
    suspend fun signatureHelp(
        file: File, source: String, offset: Int, triggerCharacter: Char? = null
    ): PythonSignatureInfo? = withContext(dispatchers.io) {
        if (closed || source.length > MAX_SOURCE_CHARS) return@withContext null
        val active = prepareDocument(file, source) ?: return@withContext null
        try {
            val pos = positionAt(source, offset)
            val context = JSONObject()
                .put("triggerKind", if (triggerCharacter == null) 1 else 2)
                .put("isRetrigger", false)
            if (triggerCharacter != null) context.put("triggerCharacter", triggerCharacter.toString())
            val params = JSONObject()
                .put("textDocument", JSONObject().put("uri", uriFor(file)))
                .put("position", JSONObject().put("line", pos.first).put("character", pos.second))
                .put("context", context)
            val response = active.request("textDocument/signatureHelp", params, REQUEST_TIMEOUT_MS) as? JSONObject
                ?: return@withContext null
            val signatures = response.optJSONArray("signatures") ?: return@withContext null
            if (signatures.length() == 0) return@withContext null
            val activeSignatureIndex = response.optInt("activeSignature", 0)
                .coerceIn(0, signatures.length() - 1)
            val signature = signatures.optJSONObject(activeSignatureIndex) ?: return@withContext null
            val label = signature.optString("label").trim()
            if (label.isBlank()) return@withContext null
            val documentation = lspDocumentationText(signature.opt("documentation"))
            val parametersJson = signature.optJSONArray("parameters") ?: JSONArray()
            val parameters = ArrayList<PythonSignatureParameter>(parametersJson.length())
            var parameterSearchFrom = 0
            for (i in 0 until parametersJson.length()) {
                val item = parametersJson.optJSONObject(i) ?: continue
                val rawLabel = item.opt("label")
                val paramLabel: String
                val start: Int
                val end: Int
                if (rawLabel is JSONArray && rawLabel.length() >= 2) {
                    start = rawLabel.optInt(0).coerceIn(0, label.length)
                    end = rawLabel.optInt(1).coerceIn(start, label.length)
                    paramLabel = label.substring(start, end)
                } else {
                    paramLabel = rawLabel?.toString().orEmpty()
                    start = if (paramLabel.isBlank()) -1 else label.indexOf(paramLabel, parameterSearchFrom).takeIf { it >= 0 }
                        ?: label.indexOf(paramLabel)
                    end = if (start >= 0) (start + paramLabel.length).coerceAtMost(label.length) else -1
                    if (end > start) parameterSearchFrom = end
                }
                parameters += PythonSignatureParameter(
                    paramLabel, start, end, lspDocumentationText(item.opt("documentation"))
                )
            }
            val activeParameter = response.optInt("activeParameter", signature.optInt("activeParameter", 0))
                .coerceIn(0, (parameters.size - 1).coerceAtLeast(0))
            PythonSignatureInfo(label, documentation, activeParameter, parameters)
        } catch (_: Exception) { null }
    }

    private fun lspDocumentationText(value: Any?): String = when (value) {
        is JSONObject -> value.optString("value").trim()
        is String -> value.trim()
        else -> ""
    }

    suspend fun definition(file: File, source: String, offset: Int): Any? =
        requestAt(file, source, "textDocument/definition", offset, timeoutMs = WORKSPACE_RENAME_TIMEOUT_MS)

    /** Resolves an LSP Location/LocationLink only when it points inside this project. */
    suspend fun definitionLocation(file: File, source: String, offset: Int): PythonDefinitionLocation? {
        val response = definition(file, source, offset)
        val location = when (response) {
            is JSONArray -> response.optJSONObject(0)
            is JSONObject -> response
            else -> null
        } ?: return null
        val uri = location.optString("targetUri").takeIf { it.isNotBlank() }
            ?: location.optString("uri").takeIf { it.isNotBlank() }
            ?: return null
        val range = location.optJSONObject("targetSelectionRange")
            ?: location.optJSONObject("targetRange")
            ?: location.optJSONObject("range")
            ?: return null
        val start = range.optJSONObject("start") ?: return null
        return try {
            val guestRoot = guestProjectPath(project).trimEnd('/')
            val normalized = URI(uri).normalize().path ?: return null
            if (normalized != guestRoot && !normalized.startsWith("$guestRoot/")) return null
            val relative = normalized.removePrefix("$guestRoot/")
            val target = File(project.dir, relative).canonicalFile
            val root = project.dir.canonicalFile
            val rootPath = root.absolutePath.trimEnd(File.separatorChar)
            if (target.absolutePath != rootPath && !target.absolutePath.startsWith(rootPath + File.separator)) return null
            if (!target.isFile) return null
            PythonDefinitionLocation(
                file = target,
                line = start.optInt("line", 0) + 1,
                column = start.optInt("character", 0),
            )
        } catch (_: Exception) {
            null
        }
    }

    suspend fun references(file: File, source: String, offset: Int, includeDeclaration: Boolean = true): Any? =
        requestAt(file, source, "textDocument/references", offset,
            JSONObject().put("context", JSONObject().put("includeDeclaration", includeDeclaration)),
            WORKSPACE_RENAME_TIMEOUT_MS)

    suspend fun rename(file: File, source: String, offset: Int, newName: String): Any? =
        requestAt(file, source, "textDocument/rename", offset, JSONObject().put("newName", newName),
            WORKSPACE_RENAME_TIMEOUT_MS)


    /** Project-wide semantic and indexed reference aggregation. */
    suspend fun workspaceReferences(
        file: File,
        source: String,
        offset: Int,
        openDocuments: Map<File, String> = emptyMap(),
    ): List<PythonReferenceOccurrence>? = workspaceReferenceResolver.resolve(file, source, offset, openDocuments)


    /** Applies a pylsp WorkspaceEdit with strict project-boundary and size checks. */
    suspend fun renameAndApply(
        file: File,
        source: String,
        offset: Int,
        newName: String,
        openDocuments: Map<File, String> = emptyMap(),
        onProgress: (suspend (stage: String, percent: Int, canCancel: Boolean) -> Unit)? = null,
    ): Map<File, String>? = withContext(dispatchers.io) {
        suspend fun report(stage: String, percent: Int, canCancel: Boolean = true) {
            currentCoroutineContext().ensureActive()
            onProgress?.let { callback -> withContext(dispatchers.main) { callback(stage, percent.coerceIn(0, 100), canCancel) } }
        }
        val operationContext = currentCoroutineContext()
        report("Preparing project index…", 1)
        lastRenameFailureReason = "The new name must be a valid non-keyword Python identifier."
        if (!Regex("[A-Za-z_][A-Za-z0-9_]*").matches(newName) || newName in PYTHON_KEYWORDS) return@withContext null
        lastRenameFailureReason = "Could not open the active document in the Python language server."
        val active = prepareDocument(file, source) ?: return@withContext null
        val root = try { project.dir.canonicalFile } catch (_: Exception) { return@withContext null }
        val rootPath = root.absolutePath.trimEnd(File.separatorChar)
        val guestRoot = guestProjectPath(project).trimEnd('/')
        val openByPath = openDocuments.entries.mapNotNull { (candidate, text) ->
            runCatching { candidate.canonicalFile to text }.getOrNull()
        }.toMap()

        // Do not preload every project document into pylsp: on large projects
        // this creates an unbounded server-side document cache. Keep LSP focused
        // on the active document; the independent project index scans source files
        // incrementally and contributes verified import-bound references later.
        mutex.lock()
        try { workspaceConfiguration.refreshProjectImportRoots(active) } finally { mutex.unlock() }
        report("Project import roots prepared…", 12)
        currentCoroutineContext().ensureActive()
        report("Resolving symbol references…", 18)
        lastRenameFailureReason = "The Python language server did not return a usable rename result."
        report("Resolving symbol references…", 23)
        val response = rename(file, source, offset, newName) as? JSONObject
        lastRenameFailureReason = "The Python language server returned no project-local symbol references."
        // A server may return a valid WorkspaceEdit while its references request
        // is unsupported/empty (or vice versa). Do not abort a valid rename merely
        // because one of the two optional LSP responses is absent.
        val referenceLocations = references(file, source, offset, includeDeclaration = true) as? JSONArray
            ?: JSONArray()
        report("Validating semantic edits…", 28)
        val declaration = definitionLocation(file, source, offset)
        val oldName = identifierAt(source, offset)
        if (oldName.isBlank()) return@withContext null
        val grouped = LinkedHashMap<File, JSONArray>()
        val seenEdits = HashMap<File, MutableSet<String>>()
        fun addWorkspaceEdit(uri: String, edit: JSONObject): Boolean {
            // Jedi can occasionally include library/stub files in a WorkspaceEdit.
            // Those files are outside the user's project and must never be touched,
            // but their presence must not cancel otherwise valid project-local edits.
            val target = workspaceUriFile(uri, root, rootPath, guestRoot) ?: return true
            val range = edit.optJSONObject("range") ?: return false
            val start = range.optJSONObject("start") ?: return false
            val end = range.optJSONObject("end") ?: return false
            val key = "${start.optInt("line", -1)}:${start.optInt("character", -1)}-${end.optInt("line", -1)}:${end.optInt("character", -1)}"
            val keys = seenEdits.getOrPut(target) { LinkedHashSet() }
            if (keys.add(key)) grouped.getOrPut(target) { JSONArray() }.put(edit)
            return true
        }
        val changes = response?.optJSONObject("changes")
        if (changes != null) {
            val keys = changes.keys()
            while (keys.hasNext()) {
                val uri = keys.next()
                val edits = changes.optJSONArray(uri) ?: continue
                for (i in 0 until edits.length()) {
                    val edit = edits.optJSONObject(i) ?: return@withContext null
                    if (!addWorkspaceEdit(uri, edit)) return@withContext null
                }
            }
        }
        val documentChanges = response?.optJSONArray("documentChanges")
        if (documentChanges != null) {
            for (i in 0 until documentChanges.length()) {
                val item = documentChanges.optJSONObject(i) ?: continue
                val document = item.optJSONObject("textDocument") ?: continue
                val uri = document.optString("uri")
                val edits = item.optJSONArray("edits") ?: continue
                for (j in 0 until edits.length()) {
                    val edit = edits.optJSONObject(j) ?: return@withContext null
                    if (!addWorkspaceEdit(uri, edit)) return@withContext null
                }
            }
        }
        // Some pylsp/Jedi versions return a partial WorkspaceEdit for imported
        // names. Merge the workspace-wide references response so imports,
        // usages and the defining declaration are all included.
        run {
            for (i in 0 until referenceLocations.length()) {
                val location = referenceLocations.optJSONObject(i) ?: continue
                val uri = location.optString("uri")
                if (workspaceUriFile(uri, root, rootPath, guestRoot) == null) continue
                val range = location.optJSONObject("range") ?: continue
                val edit = JSONObject().put("range", range)
                    .put("newText", newName)
                if (!addWorkspaceEdit(uri, edit)) return@withContext null
            }
        }
        // Independent project index: tokenize every project Python module and
        // resolve explicit imports back to the defining module. This supplements
        // incomplete Jedi results without doing blind project-wide text replace.
        val indexedDefinition = declaration?.file ?: definitionLocation(file, source, offset)?.file
        if (indexedDefinition != null) {
            val indexResult = WorkspacePythonReferenceIndex.findReferences(
                root = root,
                definingFile = indexedDefinition,
                symbol = oldName,
                openDocuments = openByPath,
                onProgress = { done, total ->
                    val fraction = if (total <= 0) 1f else done.toFloat() / total
                    report("Building project reference index ($done/$total files)…", 30 + (fraction * 35f).toInt())
                },
                checkCancelled = { operationContext.ensureActive() }
            )
            if (!indexResult.complete) {
                lastRenameFailureReason = indexResult.reason
                    ?: "The project reference index could not cover every Python file. No files were changed."
                return@withContext null
            }
            for (hit in indexResult.hits) {
                val target = hit.file.canonicalFile
                if (!target.isFile || !target.path.startsWith(rootPath + File.separator)) continue
                val originalText = openByPath[target]
                    ?: if (target == file.canonicalFile) source
                    else runCatching { target.readText(Charsets.UTF_8) }.getOrNull() ?: continue
                if (hit.offset < 0 || hit.offset + oldName.length > originalText.length) continue
                if (originalText.substring(hit.offset, hit.offset + oldName.length) != oldName) continue
                val startPos = positionAt(originalText, hit.offset)
                val endPos = positionAt(originalText, hit.offset + oldName.length)
                val range = JSONObject()
                    .put("start", JSONObject().put("line", startPos.first).put("character", startPos.second))
                    .put("end", JSONObject().put("line", endPos.first).put("character", endPos.second))
                if (!addWorkspaceEdit(uriFor(target), JSONObject().put("range", range).put("newText", newName))) {
                    lastRenameFailureReason = "The project reference index produced an invalid source range. No files were changed."
                    return@withContext null
                }
            }
        }
        // Never do a spelling-only project-wide replacement. If neither the
        // language server nor the import-aware index can prove a project-local
        // reference set, fail safely rather than corrupt unrelated symbols.
        if (grouped.isEmpty()) {
            lastRenameFailureReason = if (response == null && referenceLocations.length() == 0) {
                "The language server returned neither WorkspaceEdit nor references. The selected symbol may not be supported by the installed Python language server."
            } else {
                "The language server returned edits, but none of them point to files inside this project."
            }
            return@withContext null
        }
        lastRenameFailureReason = "The language server returned references, but their source ranges could not be validated safely."
        declaration?.let { declarationInfo ->
            val declarationFile = runCatching { declarationInfo.file.canonicalFile }.getOrNull()
            if (declarationFile != null) {
                val declarationSource = openByPath[declarationFile]
                    ?: if (declarationFile == file.canonicalFile) source
                    else runCatching { declarationFile.readText(Charsets.UTF_8) }.getOrNull()
                if (declarationSource != null) {
                    val lineIndex = declarationInfo.line - 1
                    val lineStart = offsetAt(declarationSource, lineIndex, 0)
                    val declarationStart = lineStart + declarationInfo.column
                    val declarationEnd = declarationStart + identifierAt(declarationSource, declarationStart).length
                    if (declarationStart >= 0 && declarationEnd > declarationStart &&
                        declarationEnd <= declarationSource.length &&
                        declarationSource.substring(declarationStart, declarationEnd) == oldName) {
                        // Add the declaration only when it is the same semantic identifier.
                        val uri = uriFor(declarationFile)
                        val range = JSONObject()
                            .put("start", JSONObject().put("line", lineIndex).put("character", declarationInfo.column))
                            .put("end", JSONObject().put("line", lineIndex).put("character", declarationInfo.column + (declarationEnd - declarationStart)))
                        if (!addWorkspaceEdit(uri, JSONObject().put("range", range).put("newText", newName))) return@withContext null
                    }
                }
            }
        }
        if (grouped.isEmpty()) {
            lastRenameFailureReason = "The rename result is empty. No files were changed."
            return@withContext null
        }
        lastRenameFailureReason = "The language server returned no safely verifiable identifier occurrences. No files were changed."
        val replacements = LinkedHashMap<File, String>()
        for ((target, edits) in grouped) {
            currentCoroutineContext().ensureActive()
            if (!target.isFile) return@withContext null
            val original = openDocuments.entries.firstOrNull { runCatching { it.key.canonicalFile == target.canonicalFile }.getOrDefault(false) }?.value
                ?: if (target.canonicalFile == file.canonicalFile) source else {
                    try { target.readText(Charsets.UTF_8) } catch (_: Exception) { return@withContext null }
                }
            if (replacements.size % 16 == 0) report("Analyzing edits (${replacements.size}/${grouped.size} files)…", 66 + (replacements.size.toFloat() / grouped.size * 14).toInt())
            data class TextEdit(val start: Int, val end: Int, val text: String)
            val parsed = ArrayList<TextEdit>(edits.length())
            // Verify every proposed range against the same lightweight Python
            // lexer used by the independent index. This rejects offsets inside
            // comments/string literals even if the server returns a plausible
            // spelling and identifier boundary.
            val codeIdentifierOffsets = WorkspacePythonReferenceIndex.identifierOffsets(original, oldName)
            for (i in 0 until edits.length()) {
                val edit = edits.optJSONObject(i) ?: return@withContext null
                val range = edit.optJSONObject("range") ?: return@withContext null
                val start = range.optJSONObject("start") ?: return@withContext null
                val end = range.optJSONObject("end") ?: return@withContext null
                fun offsetAt(line: Int, column: Int): Int {
                    if (line < 0 || column < 0) return -1
                    var currentLine = 0
                    var index = 0
                    while (currentLine < line && index < original.length) {
                        if (original[index++] == '\n') currentLine++
                    }
                    if (currentLine != line) return -1
                    val lineEnd = original.indexOf('\n', index).let { if (it < 0) original.length else it }
                    // LSP character offsets and Kotlin String offsets are both UTF-16.
                    return (index + column).takeIf { it in index..lineEnd && it <= original.length } ?: -1
                }
                val line = start.optInt("line", -1)
                val column = start.optInt("character", -1)
                val a = offsetAt(line, column)
                val b = offsetAt(end.optInt("line", -1), end.optInt("character", -1))
                val replacementText = edit.optString("newText", newName)
                if (replacementText != newName) {
                    lastRenameFailureReason = "The language server proposed an unexpected replacement in ${target.name}; no files were changed."
                    return@withContext null
                }

                // Python identifiers must be renamed as complete identifier tokens.
                // pylsp/Jedi versions can occasionally emit ranges whose character
                // offsets differ from the synchronized document snapshot (for example
                // after CRLF normalization or non-ASCII text). Never apply such a range
                // blindly: first verify its exact source text, then recover only within
                // the same reported line when there is a single unambiguous nearest hit.
                var tokenStart = a
                var tokenEnd = b
                fun isIdentifierPart(ch: Char): Boolean = ch == '_' || ch.isLetterOrDigit()
                val exactSpellingAtRange = a >= 0 && b == a + oldName.length && b <= original.length &&
                    original.substring(a, b) == oldName
                if (exactSpellingAtRange && a !in codeIdentifierOffsets) {
                    lastRenameFailureReason = "A reference in ${target.name} points to text that is not a Python code identifier. No files were changed."
                    return@withContext null
                }
                val exactRangeMatches = exactSpellingAtRange && a in codeIdentifierOffsets &&
                    (a == 0 || !isIdentifierPart(original[a - 1])) &&
                    (b == original.length || !isIdentifierPart(original[b]))
                if (!exactRangeMatches) {
                    if (line < 0 || column < 0) {
                        lastRenameFailureReason = "A reference from the language server had no valid source position in ${target.name}. No files were changed."
                        return@withContext null
                    }
                    var lineStart = 0
                    var currentLine = 0
                    while (currentLine < line && lineStart < original.length) {
                        if (original[lineStart++] == '\n') currentLine++
                    }
                    if (currentLine != line) {
                        lastRenameFailureReason = "A reference in ${target.name} points beyond the current source snapshot. No files were changed."
                        return@withContext null
                    }
                    val lineEnd = original.indexOf('\n', lineStart).let { if (it < 0) original.length else it }
                    val lineTextEnd = if (lineEnd > lineStart && original[lineEnd - 1] == '\r') lineEnd - 1 else lineEnd
                    val hits = ArrayList<Int>()
                    var searchFrom = lineStart
                    while (searchFrom <= lineTextEnd - oldName.length) {
                        val hit = original.indexOf(oldName, searchFrom)
                        if (hit < 0 || hit + oldName.length > lineTextEnd) break
                        if (hit !in codeIdentifierOffsets) { searchFrom = hit + 1; continue }
                        val beforeOk = hit == lineStart || !(original[hit - 1].isLetterOrDigit() || original[hit - 1] == '_')
                        val after = hit + oldName.length
                        val afterOk = after >= lineTextEnd || !(original[after].isLetterOrDigit() || original[after] == '_')
                        if (beforeOk && afterOk) hits += hit
                        searchFrom = hit + 1
                    }
                    if (hits.isEmpty()) {
                        lastRenameFailureReason = "A reference range in ${target.name} could not be matched to a complete identifier. No files were changed."
                        return@withContext null
                    }
                    val expected = (a.takeIf { it >= 0 } ?: (lineStart + column)).coerceAtLeast(lineStart)
                    val ranked = hits.sortedBy { kotlin.math.abs(it - expected) }
                    if (ranked.size > 1 && kotlin.math.abs(ranked[0] - expected) == kotlin.math.abs(ranked[1] - expected)) {
                        lastRenameFailureReason = "A reference in ${target.name} is ambiguous on its source line. No files were changed."
                        return@withContext null
                    }
                    tokenStart = ranked.first()
                    tokenEnd = tokenStart + oldName.length
                }
                val candidate = TextEdit(tokenStart, tokenEnd, replacementText)
                val duplicateIndex = parsed.indexOfFirst { it.start == candidate.start && it.end == candidate.end }
                if (duplicateIndex >= 0) {
                    // WorkspaceEdit and references can report the same token.
                    if (parsed[duplicateIndex].text != candidate.text) {
                        lastRenameFailureReason = "Conflicting rename edits were returned for ${target.name}. No files were changed."
                        return@withContext null
                    }
                } else {
                    parsed += candidate
                }
            }

            if (parsed.isEmpty()) {
                lastRenameFailureReason = "The rename result for ${target.name} contained no verifiable identifier edits. No files were changed."
                return@withContext null
            }

            // After source-token validation, distinct identifier occurrences cannot
            // legitimately overlap. If a server nevertheless reports conflicting
            // ranges, discard the ambiguous file rather than risking unrelated edits.
            val ascending = parsed.sortedWith(compareBy<TextEdit> { it.start }.thenBy { it.end })
            var previousEnd = -1
            var previousStart = -1
            for (edit in ascending) {
                if (edit.start < previousEnd || edit.start == previousStart) {
                    lastRenameFailureReason = "The language server returned conflicting ranges in ${target.name}; no files were changed."
                    return@withContext null
                }
                previousStart = edit.start
                previousEnd = edit.end
            }

            var updated = original
            for (edit in parsed.sortedWith(compareByDescending<TextEdit> { it.start }.thenByDescending { it.end })) {
                // Defensive bounds check against the current intermediate snapshot.
                if (edit.start !in 0..updated.length || edit.end !in edit.start..updated.length) {
                    return@withContext null
                }
                updated = updated.replaceRange(edit.start, edit.end, edit.text)
            }
            replacements[target] = updated
        }
        if (replacements.isEmpty()) {
            lastRenameFailureReason = "The language server returned locations, but none matched the selected identifier in the current project files. No files were changed."
            return@withContext null
        }
        // A previous interrupted operation must be resolved explicitly by the user
        // before another workspace transaction can begin.
        if (WorkspaceRefactorTransaction.pending(root).isNotEmpty()) {
            lastRenameFailureReason = "An interrupted refactor is waiting for recovery. Resolve it before starting another refactor."
            return@withContext null
        }
        report("Preparing safe rollback data…", 84)
        lastRenameFailureReason = "Preparing a crash-recoverable workspace transaction."
        var transaction: File? = null
        var commitCompleted = false
        try {
            ProjectTransactionManager.execute(root, "REFACTOR_RENAME", replacements.keys) {
                currentCoroutineContext().ensureActive()
                // Durable backups and staged outputs are prepared before the first original is replaced.
                // The project-wide lane prevents editor saves and explorer mutations from racing this commit.
                transaction = WorkspaceRefactorTransaction.prepare(root, replacements)
                currentCoroutineContext().ensureActive()
                report("Applying changes…", 90, canCancel = false)
                lastRenameFailureReason = "Applying the workspace refactor."
                withContext(NonCancellable) { WorkspaceRefactorTransaction.complete(root, transaction!!) }
                commitCompleted = true
            }
            report("Refreshing project index…", 96, canCancel = false)
            WorkspacePythonReferenceIndex.invalidate(root)
            PythonProjectSymbolIndex.invalidate(root)

            // Keep pylsp's in-memory documents aligned with the committed
            // workspace snapshot; otherwise later requests could use stale text.
            runCatching {
                val activePath = file.canonicalFile
                val activeText = replacements[activePath] ?: source
                val refreshed = prepareDocument(file, activeText)
                if (refreshed != null) {
                    mutex.lock()
                    try {
                        refreshProjectImportRoots(refreshed)
                        replacements.forEach { (changedFile, updatedText) ->
                            syncDocument(refreshed, changedFile, updatedText, refreshRoots = false)
                        }
                    } finally {
                        mutex.unlock()
                    }
                }
            }
            report("Refactor completed.", 100, canCancel = false)
            lastRenameFailureReason = ""
            replacements
        } catch (cancelled: CancellationException) {
            if (commitCompleted) {
                lastRenameFailureReason = ""
                return@withContext replacements
            }
            transaction?.let { pending ->
                withContext(NonCancellable) {
                    runCatching {
                        ProjectTransactionManager.execute(root, "ROLLBACK_REFACTOR", replacements.keys) {
                            WorkspaceRefactorTransaction.rollback(root, pending)
                        }
                    }.onFailure { rollbackError -> lastRenameFailureReason = "Cancellation cleanup failed; recovery data retained: ${rollbackError.message ?: "rollback failed"}." }
                }
            }
            throw cancelled
        } catch (error: Exception) {
            lastRenameFailureReason = error.message?.takeIf { it.isNotBlank() }
                ?.let { "Could not commit the workspace refactor: $it" }
                ?: "Could not commit the workspace refactor because the filesystem rejected a file update."
            // A normal exception gets an immediate rollback. If rollback itself
            // fails, deliberately retain the durable journal for the next launch.
            transaction?.let { pending ->
                runCatching {
                    ProjectTransactionManager.execute(root, "ROLLBACK_REFACTOR", replacements.keys) {
                        WorkspaceRefactorTransaction.rollback(root, pending)
                    }
                }.onFailure { rollbackError ->
                        lastRenameFailureReason += " Recovery data was retained: ${rollbackError.message ?: "rollback failed"}."
                    }
            }
            null
        }
    }

    private fun workspaceUriFile(uri: String, root: File, rootPath: String, guestRoot: String): File? = try {
        val path = URI(uri).normalize().path ?: return null
        val relative = when {
            path == guestRoot -> ""
            path.startsWith("$guestRoot/") -> path.removePrefix(guestRoot).trimStart('/')
            path == rootPath -> ""
            path.startsWith(rootPath + File.separator) -> path.removePrefix(rootPath).trimStart(File.separatorChar)
            else -> return null
        }
        if (relative.isBlank()) return null
        val target = File(root, relative).canonicalFile
        if (!target.absolutePath.startsWith(rootPath + File.separator) || target == root) null else target
    } catch (_: Exception) { null }

    suspend fun codeActions(file: File, source: String, startOffset: Int, endOffset: Int): Any? {
        val start = positionAt(source, startOffset)
        val end = positionAt(source, endOffset)
        val range = JSONObject()
            .put("start", JSONObject().put("line", start.first).put("character", start.second))
            .put("end", JSONObject().put("line", end.first).put("character", end.second))
        return requestAt(file, source, "textDocument/codeAction", startOffset,
            JSONObject().put("range", range).put("context", JSONObject().put("diagnostics", JSONArray())))
    }

    suspend fun documentSymbols(file: File, source: String): Any? =
        requestDocument(file, source, "textDocument/documentSymbol")

    suspend fun formatting(file: File, source: String, tabSize: Int = 4, insertSpaces: Boolean = true): Any? =
        requestDocument(file, source, "textDocument/formatting",
            JSONObject().put("options", JSONObject().put("tabSize", tabSize).put("insertSpaces", insertSpaces)))

    /** Apply the language server's formatter edits to the exact unsaved buffer. */
    suspend fun formatText(file: File, source: String, tabSize: Int = 4): String? {
        val response = formatting(file, source, tabSize, true) as? JSONArray ?: return null
        if (response.length() == 0) return source
        data class Edit(val start: Int, val end: Int, val text: String)
        val edits = ArrayList<Edit>(response.length())
        for (i in 0 until response.length()) {
            val item = response.optJSONObject(i) ?: continue
            val range = item.optJSONObject("range") ?: continue
            val start = range.optJSONObject("start") ?: continue
            val end = range.optJSONObject("end") ?: continue
            val a = offsetAt(source, start.optInt("line"), start.optInt("character"))
            val b = offsetAt(source, end.optInt("line"), end.optInt("character"))
            if (b < a) continue
            edits += Edit(a, b, item.optString("newText"))
        }
        if (edits.isEmpty()) return null
        // LSP text edits are applied from the end so earlier offsets stay valid.
        var output = source
        edits.sortedByDescending { it.start }.forEach { edit ->
            output = output.substring(0, edit.start) + edit.text + output.substring(edit.end)
        }
        return output
    }

    /** Document-scoped LSP request helper (formatting, document symbols, etc.). */
    suspend fun requestDocument(file: File, source: String, method: String, extra: JSONObject = JSONObject()): Any? = withContext(dispatchers.io) {
        val active = prepareDocument(file, source) ?: return@withContext null
        try {
            val params = JSONObject().put("textDocument", JSONObject().put("uri", uriFor(file)))
            val keys = extra.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                params.put(key, extra.get(key))
            }
            active.request(method, params, REQUEST_TIMEOUT_MS)
        } catch (_: Exception) { null }
    }

    private fun hasCompletionTrigger(source: String, caret: Int): Boolean {
        val cursor = caret.coerceIn(0, source.length)
        if (cursor == 0 || source.isBlank()) return false
        var start = cursor
        while (start > 0 && (source[start - 1].isLetterOrDigit() || source[start - 1] == '_')) start--
        return start < cursor || source.getOrNull(cursor - 1) == '.'
    }

    private fun ensureSession(): LspSessionTransport? {
        if (closed) return null
        val currentEnvironmentRevision = PythonEnvironmentRegistry.revision(project.dir)
        if (currentEnvironmentRevision != observedEnvironmentRevision) {
            // A pip install/uninstall changed the selected venv. A fresh pylsp
            // process is the reliable way to discard Jedi's environment caches.
            session?.close()
            session = null
            documents.clear()
            workspaceConfiguration.reset()
            _results.value = emptyMap()
            _lspResults.value = emptyMap()
            _validatedSources.value = emptyMap()
            nativeDiagnostics.clear()
            lspDiagnosticsByPath.clear()
            importResolutionJobs.values.forEach { it.cancel() }
            importResolutionJobs.clear()
            observedEnvironmentRevision = currentEnvironmentRevision
        }
        session?.takeIf { it.isAlive }?.let { return it }
        if (!ensureInstalled() || closed) return null
        val guestProject = guestProjectPath(project)
        val command = "exec /opt/pyspace-lsp/venv/bin/pylsp"
        session?.close()
        val process = proot.startGuestProcess(command, guestProject)
        val created = PythonLspSession(process) { params -> publishDiagnostics(params) }
        documents.clear()
        try {
            val settings = workspaceConfiguration.initialSettings()
            val capabilities = JSONObject()
                .put("textDocument", JSONObject()
                    .put("completion", JSONObject().put("completionItem", JSONObject().put("snippetSupport", false)))
                    .put("hover", JSONObject().put("contentFormat", JSONArray().put("markdown").put("plaintext")))
                    .put("signatureHelp", JSONObject()
                        .put("contextSupport", true)
                        .put("signatureInformation", JSONObject()
                            .put("documentationFormat", JSONArray().put("markdown").put("plaintext"))))
                    .put("publishDiagnostics", JSONObject().put("relatedInformation", true)))
                .put("workspace", JSONObject().put("workspaceFolders", true))
            val rootUri = guestUri(guestProject)
            val init = JSONObject()
                .put("processId", android.os.Process.myPid())
                .put("rootUri", rootUri)
                .put("rootPath", guestProject)
                .put("workspaceFolders", JSONArray().put(JSONObject().put("uri", rootUri).put("name", project.name)))
                .put("capabilities", capabilities)
                .put("initializationOptions", settings)
                .put("trace", "off")
                .put("settings", settings)
            created.request("initialize", init, 45_000L)
            created.notify("initialized", JSONObject())
            created.notify("workspace/didChangeConfiguration", JSONObject().put("settings", settings))
            if (closed) {
                created.close()
                return null
            }
            session = created
            return created
        } catch (error: Exception) {
            created.close()
            throw error
        }
    }

    private fun ensureInstalled(): Boolean =
        PythonLspRuntimeInstaller.ensureInstalled(context, proot)


    private fun publishDiagnostics(params: JSONObject) {
        val mapped = LspDiagnosticMapper.map(params)
        val uri = mapped.uri
        val file = documents.file(uri) ?: return
        val source = documents.source(uri) ?: return
        val publishedVersion = mapped.version
        val currentVersion = documents.version(uri) ?: -1
        if (publishedVersion >= 0 && currentVersion >= 0 && publishedVersion != currentVersion) return
        val diagnostics = mapped.diagnostics
        // Do not show Pyflakes' F401 result until the selected project interpreter
        // has checked whether the imported top-level module actually exists.
        // Otherwise an absent dependency is incorrectly presented as merely unused.
        setLspDiagnostics(file.absolutePath, diagnostics.filterNot(::isUnusedImportDiagnostic))
        publishCombinedDiagnostics(file.absolutePath, source)
        _validatedSources.value = _validatedSources.value + (file.absolutePath to source)

        importResolutionJobs.remove(uri)?.cancel()
        val job = scope.launch(dispatchers.io) {
            try {
                delay(180L)
                val missing = importResolutionMutex.withLock { resolveMissingImports(source) }
                if (documents.source(uri) != source || documents.version(uri) != currentVersion || closed) return@launch
                val missingLines = missing?.map { it.line }?.toSet().orEmpty()
                val combined = if (missing == null) {
                    diagnostics
                } else {
                    diagnostics.filterNot { diagnostic ->
                        isUnusedImportDiagnostic(diagnostic) && diagnostic.line in missingLines
                    } + missing
                }
                setLspDiagnostics(file.absolutePath, combined)
                publishCombinedDiagnostics(file.absolutePath, source)
                _validatedSources.value = _validatedSources.value + (file.absolutePath to source)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                // If the selected interpreter cannot be queried, retain pylsp's
                // original diagnostics rather than guessing that a package is absent.
                if (documents.source(uri) == source && documents.version(uri) == currentVersion && !closed) {
                    setLspDiagnostics(file.absolutePath, diagnostics)
                    publishCombinedDiagnostics(file.absolutePath, source)
                }
            } finally {
                val completedJob = currentCoroutineContext()[Job]
                if (completedJob != null) importResolutionJobs.remove(uri, completedJob)
            }
        }
        importResolutionJobs[uri] = job
    }

    private fun setLspDiagnostics(path: String, diagnostics: List<PythonSyntaxDiagnostic>) {
        lspDiagnosticsByPath[path] = diagnostics
        _lspResults.value = _lspResults.value + (path to diagnostics)
    }

    private fun publishCombinedDiagnostics(path: String, source: String) {
        if (closed) return
        val lsp = lspDiagnosticsByPath[path].orEmpty()
        val types = nativeDiagnostics.diagnosticsFor(path)
        // Preserve all existing LSP results; Kotlin diagnostics are additive and
        // carry a private code namespace so they can be replaced independently.
        val merged = lsp.filterNot { it.code?.startsWith("PYSPACE-TYPE-") == true } + types
        _results.value = _results.value + (path to merged)
        _validatedSources.value = _validatedSources.value + (path to source)
    }

    private fun isUnusedImportDiagnostic(diagnostic: PythonSyntaxDiagnostic): Boolean =
        diagnostic.code.equals("F401", ignoreCase = true) ||
            diagnostic.message.contains("imported but unused", ignoreCase = true) ||
            diagnostic.message.contains("imported but not used", ignoreCase = true)

    /**
     * Checks imports with the exact interpreter selected for this project.
     * The editor buffer is parsed with ast; user code is never executed. Only
     * importlib.util.find_spec is used to test top-level module availability.
     * A null result means the environment could not be checked reliably.
     */
    private val importResolver = LspImportResolver(proot, project, workspaceConfiguration)

    private fun resolveMissingImports(source: String): List<PythonSyntaxDiagnostic>? =
        importResolver.resolve(source)

    private fun uriFor(file: File): String {
        val root = project.dir.canonicalFile
        val target = file.canonicalFile
        val relative = try { target.relativeTo(root).path } catch (_: Exception) { file.name }
        val guest = guestProjectPath(project).trimEnd('/') + "/" + relative.replace(File.separatorChar, '/')
        return guestUri(guest)
    }

    private fun guestUri(path: String): String = URI("file", null, if (path.startsWith('/')) path else "/$path", null).toASCIIString()

    override fun close() {
        closed = true
        jobs.values.forEach { it.cancel() }
        jobs.clear()
        nativeDiagnostics.close()
        lspDiagnosticsByPath.clear()
        // These maps hold complete editor source strings. They are useful only
        // while this project controller is alive; retaining them after the
        // editor leaves the project needlessly pins every opened Python file.
        documents.clear()
        _results.value = emptyMap()
        _lspResults.value = emptyMap()
        _validatedSources.value = emptyMap()
        importResolutionJobs.values.forEach { it.cancel() }
        importResolutionJobs.clear()
        session?.close()
        session = null
        workspaceConfiguration.reset()
        scope.cancel()
    }


    companion object {
        const val TYPE_CHECK_DEBOUNCE_MS = 320L
        private val PYTHON_KEYWORDS = setOf(
            "False", "None", "True", "and", "as", "assert", "async", "await", "break", "class",
            "continue", "def", "del", "elif", "else", "except", "finally", "for", "from", "global",
            "if", "import", "in", "is", "lambda", "nonlocal", "not", "or", "pass", "raise",
            "return", "try", "while", "with", "yield"
        )
        private const val DEBOUNCE_MS = 160L
        private const val REQUEST_TIMEOUT_MS = 4_000L
        private const val WORKSPACE_RENAME_TIMEOUT_MS = 20_000L
        private const val MAX_SOURCE_CHARS = 250_000


        private fun positionAt(source: String, rawOffset: Int): Pair<Int, Int> {
            val offset = rawOffset.coerceIn(0, source.length)
            var line = 0
            var lineStart = 0
            for (i in 0 until offset) if (source[i] == '\n') { line++; lineStart = i + 1 }
            return line to (offset - lineStart)
        }

        private fun offsetAt(source: String, rawLine: Int, rawCharacter: Int): Int {
            val line = rawLine.coerceAtLeast(0)
            var start = 0
            repeat(line) {
                val next = source.indexOf('\n', start)
                if (next < 0) return source.length
                start = next + 1
            }
            val end = source.indexOf('\n', start).let { if (it < 0) source.length else it }
            return (start + rawCharacter.coerceAtLeast(0)).coerceAtMost(end)
        }

        private fun identifierStart(source: String, rawOffset: Int): Int {
            var index = rawOffset.coerceIn(0, source.length)
            while (index > 0 && (source[index - 1].isLetterOrDigit() || source[index - 1] == '_')) index--
            return index
        }

        private fun identifierAt(source: String, rawOffset: Int): String {
            if (source.isEmpty()) return ""
            var index = rawOffset.coerceIn(0, source.length - 1)
            if (!(source[index].isLetterOrDigit() || source[index] == '_') && index > 0) index--
            if (!(source[index].isLetterOrDigit() || source[index] == '_')) return ""
            var start = index
            var end = index + 1
            while (start > 0 && (source[start - 1].isLetterOrDigit() || source[start - 1] == '_')) start--
            while (end < source.length && (source[end].isLetterOrDigit() || source[end] == '_')) end++
            return source.substring(start, end)
        }

        private fun completionKind(kind: Int): String = when (kind) {
            2 -> "member"; 3 -> "function"; 4 -> "function"; 5 -> "attribute"; 6 -> "variable"
            7 -> "class"; 8 -> "class"; 9 -> "module"; 10 -> "attribute"; 14 -> "keyword"
            15 -> "snippet"; 20 -> "operator"; else -> "variable"
        }

        private fun hoverText(contents: Any): String = when (contents) {
            is String -> contents
            is JSONObject -> contents.optString("value", contents.toString())
            is JSONArray -> buildString {
                for (i in 0 until contents.length()) {
                    if (isNotEmpty()) append('\n')
                    val item = contents.opt(i)
                    append(when (item) {
                        is JSONObject -> item.optString("value", item.toString())
                        else -> item?.toString().orEmpty()
                    })
                }
            }
            else -> contents.toString()
        }
    }
}
