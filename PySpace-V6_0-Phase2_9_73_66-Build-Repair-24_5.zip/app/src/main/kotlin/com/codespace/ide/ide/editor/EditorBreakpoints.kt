package com.codespace.ide.ide.editor

import androidx.compose.runtime.mutableStateMapOf
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

/** Full breakpoint metadata shared by the editor gutter and DAP debugger. */
data class EditorBreakpoint(
    val line: Int,
    val enabled: Boolean = true,
    val condition: String = "",
    val hitCondition: String = "",
    val logMessage: String = ""
)

/** Shared, project-file-scoped breakpoint store. */
object EditorBreakpointStore {
    private val entries = mutableStateMapOf<String, Map<Int, EditorBreakpoint>>()
    private val _revision = MutableStateFlow(0L)
    /** Non-Compose change signal for runtime observers such as the DAP controller. */
    val revision: StateFlow<Long> = _revision.asStateFlow()
    private fun changed() { _revision.value = _revision.value + 1L }
    private fun key(file: File): String = file.absolutePath
    fun lines(file: File?): Set<Int> = file?.let { entries[key(it)].orEmpty().keys } ?: emptySet()
    fun all(file: File?): List<EditorBreakpoint> = file?.let { entries[key(it)].orEmpty().values.sortedBy(EditorBreakpoint::line) } ?: emptyList()
    fun forProject(root: File): Map<File, List<EditorBreakpoint>> {
        val prefix = root.absolutePath.trimEnd(File.separatorChar) + File.separator
        return entries.entries.asSequence().filter { it.key.startsWith(prefix) && it.value.isNotEmpty() }
            .associate { File(it.key) to it.value.values.sortedBy(EditorBreakpoint::line) }
    }
    fun toggle(file: File, line: Int) {
        if (line < 1) return
        val path = key(file); val current = entries[path].orEmpty().toMutableMap()
        if (line in current) current.remove(line) else current[line] = EditorBreakpoint(line)
        if (current.isEmpty()) entries.remove(path) else entries[path] = current
        changed()
    }
    fun add(file: File, line: Int) {
        if (line < 1) return
        val path = key(file); val current = entries[path].orEmpty()
        if (line !in current) { entries[path] = current + (line to EditorBreakpoint(line)); changed() }
    }
    fun remove(file: File, line: Int) {
        val path = key(file); val updated = entries[path].orEmpty() - line
        if (updated.isEmpty()) entries.remove(path) else entries[path] = updated
        changed()
    }
    fun update(file: File, breakpoint: EditorBreakpoint) {
        if (breakpoint.line < 1) return
        entries[key(file)] = entries[key(file)].orEmpty() + (breakpoint.line to breakpoint)
        changed()
    }
    fun encode(file: File): String = org.json.JSONArray().apply {
        all(file).forEach { bp -> put(org.json.JSONObject().put("line", bp.line).put("enabled", bp.enabled)
            .put("condition", bp.condition).put("hitCondition", bp.hitCondition).put("logMessage", bp.logMessage)) }
    }.toString()
    fun restore(file: File, encoded: String) {
        runCatching {
            val array = org.json.JSONArray(encoded)
            val restored = LinkedHashMap<Int, EditorBreakpoint>()
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val line = item.optInt("line", -1)
                if (line > 0) restored[line] = EditorBreakpoint(line, item.optBoolean("enabled", true),
                    item.optString("condition"), item.optString("hitCondition"), item.optString("logMessage"))
            }
            if (restored.isEmpty()) entries.remove(key(file)) else entries[key(file)] = restored
            changed()
        }
    }
}
