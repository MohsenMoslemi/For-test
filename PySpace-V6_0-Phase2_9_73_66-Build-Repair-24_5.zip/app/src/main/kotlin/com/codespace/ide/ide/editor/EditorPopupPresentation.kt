package com.codespace.ide.ide.editor

import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.TextUnit

/** Pinch preview transform shared by code rendering and popup anchor geometry. */
internal data class EditorPopupPreviewTransform(
    val scaleX: Float,
    val scaleY: Float,
    val pivotX: Float,
    val pivotY: Float,
    val gutterVisible: Boolean,
    val gutterWidthPx: Float,
    val textPaddingPx: Float,
    val previewGutterPx: Float
)

internal data class EditorPopupAnchors(
    val layoutFresh: Boolean,
    val sized: Boolean,
    val caret: Rect?,
    val documentation: Rect?
)

internal data class EditorPopupPlan(
    val completionShown: Boolean,
    val documentationShown: Boolean,
    val documentationBubbleShown: Boolean,
    val diagnosticShown: Boolean,
    val signatureShown: Boolean,
    val specs: List<PopupSlotSpec?>
)

/**
 * Keeps popup anchor math and card-placement policy out of PyEditor. This is
 * deliberately a presentation calculator: live Compose state and popup
 * contents remain owned by the editor screen.
 */
internal object EditorPopupPresentation {
    fun resolveAnchors(
        layout: TextLayoutResult?,
        foldedDocument: FoldedEditorDocument,
        expectedFontSize: TextUnit,
        field: TextFieldValue,
        documentationWanted: Boolean,
        documentationOffset: Int?,
        viewportWidthPx: Int,
        viewportHeightPx: Int,
        gutterWidthPx: Float,
        sheetShiftX: Float,
        sheetShiftY: Float,
        preview: EditorPopupPreviewTransform,
        caretMemo: AnchorMemo,
        documentationMemo: AnchorMemo
    ): EditorPopupAnchors {
        val sized = viewportWidthPx > 0 && viewportHeightPx > 0
        val layoutMatches = layout != null &&
            layout.layoutInput.text.text == foldedDocument.displayText
        // TextLayoutResult may lag one frame after a font or document change.
        val fresh = layoutMatches && layout!!.layoutInput.style.fontSize == expectedFontSize

        fun mapPreviewRect(rect: Rect): Rect {
            val sx = preview.scaleX
            val sy = preview.scaleY
            if ((sx == 1f && sy == 1f) || sx <= 0f || sy <= 0f) return rect
            val h = preview.pivotX
            val py = preview.pivotY
            val tx = if (preview.gutterVisible && h <= preview.gutterWidthPx + preview.textPaddingPx) {
                (preview.previewGutterPx + preview.textPaddingPx) - h -
                    (preview.gutterWidthPx + preview.textPaddingPx - h) * sx
            } else 0f
            fun mapX(x: Float) = h + (x - h) * sx + tx
            fun mapY(y: Float) = py + (y - py) * sy
            return Rect(mapX(rect.left), mapY(rect.top), mapX(rect.right), mapY(rect.bottom))
        }

        fun resolveMemo(memo: AnchorMemo, wanted: Boolean, current: Rect?): Rect? {
            if (!wanted) {
                memo.rect = null
                return null
            }
            if (current != null) {
                memo.rect = current
                memo.shiftX = sheetShiftX
                memo.shiftY = sheetShiftY
                return current
            }
            val previous = memo.rect ?: return null
            return previous.translate(
                -(sheetShiftX - memo.shiftX),
                -(sheetShiftY - memo.shiftY)
            )
        }

        val caretWanted = sized && field.selection.collapsed &&
            field.selection.start in 0..field.text.length
        val caretCurrent = if (fresh && caretWanted) {
            val cursor = layout!!.getCursorRect(
                foldedDocument.toDisplayOffset(field.selection.start)
            )
            mapPreviewRect(
                Rect(
                    gutterWidthPx + preview.textPaddingPx + cursor.left,
                    preview.textPaddingPx + cursor.top,
                    gutterWidthPx + preview.textPaddingPx + cursor.right,
                    preview.textPaddingPx + cursor.bottom
                )
            )
        } else null
        val caret = resolveMemo(caretMemo, caretWanted, caretCurrent)

        val docWanted = sized && documentationWanted && documentationOffset != null
        val docCurrent = if (fresh && docWanted) {
            val displayOffset = foldedDocument.toDisplayOffset(
                documentationOffset!!.coerceIn(0, field.text.length)
            )
            val cursor = layout!!.getCursorRect(displayOffset)
            mapPreviewRect(
                Rect(
                    gutterWidthPx + preview.textPaddingPx + cursor.left,
                    preview.textPaddingPx + cursor.top,
                    gutterWidthPx + preview.textPaddingPx + cursor.left,
                    preview.textPaddingPx + cursor.bottom
                )
            )
        } else null
        val documentation = resolveMemo(documentationMemo, docWanted, docCurrent)

        return EditorPopupAnchors(fresh, sized, caret, documentation)
    }

    fun createPlan(
        caretAnchor: Rect?,
        documentationAnchor: Rect?,
        completionRequested: Boolean,
        documentationRequested: Boolean,
        hasDocumentation: Boolean,
        hasDefinition: Boolean,
        documentationExpanded: Boolean,
        diagnosticRequested: Boolean,
        diagnosticDismissed: Boolean,
        hasDiagnostic: Boolean,
        signatureRequested: Boolean,
        completionWidthPx: Float,
        completionHeightPx: Float,
        documentationWidthPx: Float,
        documentationHeightPx: Float,
        diagnosticWidthPx: Float,
        diagnosticHeightPx: Float,
        signatureWidthPx: Float,
        signatureHeightPx: Float
    ): EditorPopupPlan {
        val completion = completionRequested && caretAnchor != null
        val documentationAvailable = documentationRequested && documentationAnchor != null
        val definitionOnly = !hasDocumentation && hasDefinition
        val documentation = documentationAvailable && (documentationExpanded || definitionOnly)
        val bubble = documentationAvailable && hasDocumentation && !documentationExpanded
        // An expanded documentation card takes precedence over diagnostics.
        val diagnostic = diagnosticRequested && hasDiagnostic && caretAnchor != null &&
            !documentation && !diagnosticDismissed
        val signature = signatureRequested && caretAnchor != null && !documentation

        val specs = listOf(
            if (completion) PopupSlotSpec(
                caretAnchor!!, completionWidthPx, completionHeightPx, true, true
            ) else null,
            if (documentation) PopupSlotSpec(
                documentationAnchor!!, documentationWidthPx, documentationHeightPx,
                false, true, shrinkable = false, order = listOf(1, 0, 2, 3)
            ) else null,
            if (diagnostic) PopupSlotSpec(
                caretAnchor!!, diagnosticWidthPx, diagnosticHeightPx, false, false
            ) else null,
            if (signature) PopupSlotSpec(
                caretAnchor!!, signatureWidthPx, signatureHeightPx, false, false,
                shrinkable = false, order = listOf(1, 0, 2, 3)
            ) else null
        )
        return EditorPopupPlan(completion, documentation, bubble, diagnostic, signature, specs)
    }
}
