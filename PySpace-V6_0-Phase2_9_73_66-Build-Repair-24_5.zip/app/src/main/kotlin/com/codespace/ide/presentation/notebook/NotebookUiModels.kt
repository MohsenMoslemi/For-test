package com.codespace.ide.presentation.notebook

import com.codespace.ide.domain.notebook.factory.NotebookSnapshotFactory

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject
import com.codespace.ide.ide.JSON

// ---------------------------------------------------------------------------
// Notebook document model (nbformat 4) used by the native notebook editor. Reads and writes standard
// .ipynb files, keeps every field it does not understand, so a notebook that is opened and saved here
// stays a valid Jupyter notebook.
// ---------------------------------------------------------------------------

class NbOutput(
    /** "stream" | "display" | "result" | "error" */
    val kind: String,
    val name: String = "stdout",
    var text: String = "",
    val data: Map<String, String> = emptyMap(),
    val ename: String = "",
    val evalue: String = "",
    val execCount: Int? = null
)

class NbCell(
    val id: String,
    type: String,
    source: String,
    execCount: Int?,
    outs: List<NbOutput>,
    /** Everything else of the original cell (metadata, ...): written back unchanged. */
    val extra: JSONObject = JSONObject()
) {
    var type by mutableStateOf(type)
    var source by mutableStateOf(source)
    var execCount by mutableStateOf(execCount)
    var running by mutableStateOf(false)
    var queued by mutableStateOf(false)
    var outputRevision by mutableStateOf(0)
        private set
    val outputs = mutableStateListOf<NbOutput>().also { it.addAll(outs) }

    /** Notify the cell UI when an existing output object's plain text changes. */
    fun notifyOutputChanged() {
        outputRevision++
    }
}

class NbDoc(
    val cells: androidx.compose.runtime.snapshots.SnapshotStateList<NbCell>,
    var meta: JSONObject,
    var nbformat: Int,
    var minor: Int,
    /** nbformat >= 4.5 cells carry an id. */
    var useIds: Boolean
)

/** Domain-generated stable identifier, exposed here for UI cell creation. */
fun newCellId(): String = NotebookSnapshotFactory.newCellId()

/** Creates a new nbformat 4.5 document for the native editor. */
fun newNotebook(): NbDoc = NotebookSnapshotFactory.emptyNotebook().toUiDocument()

/** Compatibility aliases: immutable snapshot contracts live in the domain layer. */
typealias NbOutputSnapshot = com.codespace.ide.domain.notebook.model.NbOutputSnapshot
typealias NbCellSnapshot = com.codespace.ide.domain.notebook.model.NbCellSnapshot
typealias NbDocSnapshot = com.codespace.ide.domain.notebook.model.NbDocSnapshot

/** Builds Compose-observable notebook objects from an immutable domain snapshot on Main. */
fun NbDocSnapshot.toUiDocument(): NbDoc {
    val uiCells = mutableStateListOf<NbCell>()
    cells.forEach { cell ->
        val outputs = cell.outputs.map { output ->
            NbOutput(
                kind = output.kind,
                name = output.name,
                text = output.text,
                data = LinkedHashMap(output.data),
                ename = output.ename,
                evalue = output.evalue,
                execCount = output.execCount,
            )
        }
        uiCells.add(
            NbCell(
                id = cell.id,
                type = cell.type,
                source = cell.source,
                execCount = cell.execCount,
                outs = outputs,
                extra = JSONObject(cell.extraJson),
            )
        )
    }
    return NbDoc(uiCells, JSONObject(metadataJson), nbformat, minor, useIds)
}

/**
 * Copies all Compose-backed and mutable notebook state while still on the
 * caller/UI thread. The returned graph contains only immutable Kotlin values
 * and JSON strings, so it is safe to serialize on Dispatchers.Default.
 */
fun snapshotNotebook(doc: NbDoc): NbDocSnapshot {
    val cells = doc.cells.map { cell ->
        NbCellSnapshot(
            id = cell.id,
            type = cell.type,
            source = cell.source,
            execCount = cell.execCount,
            extraJson = cell.extra.toString(),
            outputs = cell.outputs.map { output ->
                NbOutputSnapshot(
                    kind = output.kind,
                    name = output.name,
                    text = output.text,
                    data = LinkedHashMap(output.data),
                    ename = output.ename,
                    evalue = output.evalue,
                    execCount = output.execCount,
                )
            },
        )
    }
    return NbDocSnapshot(cells, doc.meta.toString(), doc.nbformat, doc.minor, doc.useIds)
}

