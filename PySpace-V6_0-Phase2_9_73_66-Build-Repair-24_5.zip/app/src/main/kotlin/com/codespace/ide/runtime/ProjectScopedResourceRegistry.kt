package com.codespace.ide.runtime

import java.io.File

/**
 * Owns one closeable resource per canonical project directory.
 *
 * Access and eviction are serialized so a resource cannot be recreated between
 * a deletion check and its removal. Resource close callbacks run outside the
 * registry lock to avoid deadlocks with work being cancelled by close().
 */
class ProjectScopedResourceRegistry<T : AutoCloseable>(
    private val create: (File) -> T,
) {
    private val lock = Any()
    private val resources = LinkedHashMap<String, T>()

    fun get(projectDirectory: File): T {
        val key = keyOf(projectDirectory)
        return synchronized(lock) {
            resources[key] ?: create(projectDirectory.canonicalOrAbsolute()).also {
                resources[key] = it
            }
        }
    }

    fun remove(projectDirectory: File): Boolean {
        val removed = synchronized(lock) { resources.remove(keyOf(projectDirectory)) }
        closeSafely(removed)
        return removed != null
    }

    fun closeAll() {
        val detached = synchronized(lock) {
            resources.values.toList().also { resources.clear() }
        }
        detached.forEach(::closeSafely)
    }

    fun size(): Int = synchronized(lock) { resources.size }

    private fun keyOf(directory: File): String = directory.canonicalOrAbsolute().path

    private fun File.canonicalOrAbsolute(): File =
        runCatching { canonicalFile }.getOrDefault(absoluteFile)

    private fun closeSafely(resource: T?) {
        if (resource != null) runCatching { resource.close() }
    }
}
