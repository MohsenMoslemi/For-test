package com.codespace.ide.ide.editor

import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.Density

/**
 * Snapshot of the geometry shared by the code surface, caret navigation and gutter.
 * The State properties are live views for coroutines that outlive a composition pass.
 */
internal data class EditorTextLayoutGeometry(
    val displayLineStarts: IntArray,
    val lineRows: List<Int>,
    val lineRowsNow: State<List<Int>>,
    val gutterGeometry: GutterGeometry?,
    val visualRowPrefix: IntArray?,
    val gutterRows: GutterRows,
    val gutterRowsNow: State<GutterRows>,
    val fallbackPitchPx: Float
)

/**
 * Owns the measurement/cache boundary for wrapped visual rows and the gutter's
 * alignment with the actual BasicTextField layout. No document or Compose editing
 * state is mutated here; callers provide immutable snapshots and retain ownership
 * of field/scroll/IME state.
 */
@Composable
internal fun rememberEditorTextLayoutGeometry(
    foldedDocument: FoldedEditorDocument,
    textLayout: TextLayoutResult?,
    fieldWidthPx: Int,
    wordWrap: Boolean,
    style: TextStyle,
    fontSize: Float,
    lineHeight: Float,
    textMeasurer: TextMeasurer,
    fontMetricsCache: EditorFontMetricsCache,
    density: Density
): EditorTextLayoutGeometry {
    val displayLineStarts = remember(foldedDocument) {
        lineStartOffsets(foldedDocument.displayText)
    }
    val rowCache = remember(style, fieldWidthPx) { EditorLineRowCache() }
    val lineRows = remember(
        foldedDocument.displayText,
        displayLineStarts,
        fieldWidthPx,
        wordWrap,
        style
    ) {
        if (!wordWrap || fieldWidthPx <= 0) emptyList()
        else rowCache.measureRows(
            source = foldedDocument.displayText,
            lineStarts = displayLineStarts,
            fieldWidthPx = fieldWidthPx,
            textMeasurer = textMeasurer,
            style = style
        )
    }
    val lineRowsNow = rememberUpdatedState(lineRows)

    // Reject TextLayoutResult snapshots measured against an older document/font.
    val gutterPitchHolder = remember { FloatArray(1) }
    val gutterGeometry = remember(
        foldedDocument,
        textLayout,
        fontSize,
        lineHeight,
        density.density,
        density.fontScale
    ) {
        val layout = textLayout
        val inputStyle = layout?.layoutInput?.style
        if (
            layout == null || inputStyle == null ||
            !sameDisplay(layout.layoutInput.text.text, foldedDocument.displayText) ||
            inputStyle.fontSize != fontSize.sp ||
            inputStyle.lineHeight != lineHeight.sp
        ) {
            null
        } else {
            GutterGeometry(layout, displayLineStarts).also {
                gutterPitchHolder[0] = it.firstHeight(0)
            }
        }
    }

    val visualRowPrefix = remember(lineRows) {
        EditorDerivedState.visualRowPrefix(lineRows)
    }
    val fallbackPitchPx = fontMetricsCache.measure(fontSize, textMeasurer, style)[0].let { exact ->
        gutterPitchHolder[0].let { measured ->
            if (measured > 0f && kotlin.math.abs(measured - exact) <= 0.5f) measured else exact
        }
    }
    val gutterRows = remember(
        gutterGeometry,
        foldedDocument,
        visualRowPrefix,
        fallbackPitchPx
    ) {
        GutterRows(
            geometry = gutterGeometry,
            count = foldedDocument.visibleSourceLines.size,
            pitchPx = fallbackPitchPx,
            rowPrefix = visualRowPrefix
        )
    }

    return EditorTextLayoutGeometry(
        displayLineStarts = displayLineStarts,
        lineRows = lineRows,
        lineRowsNow = lineRowsNow,
        gutterGeometry = gutterGeometry,
        visualRowPrefix = visualRowPrefix,
        gutterRows = gutterRows,
        gutterRowsNow = rememberUpdatedState(gutterRows),
        fallbackPitchPx = fallbackPitchPx
    )
}
