package com.codespace.ide.ide.debug

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.codespace.ide.ProotManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import com.codespace.ide.ide.editor.EditorBreakpoint
import com.codespace.ide.ide.editor.EditorBreakpointStore
import com.codespace.ide.ide.codeintel.PythonDebugRuntimeInstaller
import com.codespace.ide.ide.projects.PyProject

/** One row of the variables tree (scope headers have depth 0, their variables depth 1+). */
data class DebugVariableItem(
    val name: String,
    val value: String,
    val type: String,
    val reference: Int = 0,
    val depth: Int = 0,
    val path: String,
    val parentPath: String? = null,
    val isScope: Boolean = false
)

/** Immutable presentation snapshot published by the debugger runtime. */
data class DebugUiState(
    val status: String = "Stopped",
    val starting: Boolean = false,
    val targetFile: File? = null,
    val output: String = "Select a Python file, configure breakpoints, then start debugging.\n",
    val stackFrames: List<JSONObject> = emptyList(),
    val threads: List<JSONObject> = emptyList(),
    val variables: List<DebugVariableItem> = emptyList(),
    val expandedVariables: Set<String> = emptySet(),
    val selectedFrameId: Int? = null,
    val threadId: Int? = null,
    val watches: List<String> = emptyList(),
    val watchValues: Map<String, String> = emptyMap(),
    val breakOnRaised: Boolean = false,
)

/**
 * Owns the whole debugger for ONE project: the DAP session, the debuggee process,
 * every piece of observable debugger state and all lifecycle transitions
 * (start / stop / restart).
 *
 * It deliberately lives outside of Compose. It is created and held by IdeRoot (the same
 * level that holds the console and terminal state), so closing the bottom panel,
 * switching panel tabs or recomposing never touches a running debug session. The
 * Debug panel is only a view that renders this object's state and forwards clicks.
 *
 * Threading: every state mutation happens on the Main thread (the internal scope is
 * Main.immediate); blocking DAP / process work runs on Dispatchers.IO.
 *
 * Lifecycle rule: each launch/stop bumps [generation]. Anything that completes for an
 * older generation (late DAP events, late output, a start that finished after Stop)
 * is discarded and its resources are closed instead of leaking.
 */
class DebugController(
    appContext: Context,
    private val proot: ProotManager,
    val project: PyProject,
    private val openLocation: (File, Int) -> Unit
) {
    private val context: Context = appContext.applicationContext
    private val prefs = context.getSharedPreferences("pyspace_debugger", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val projectKey = project.dir.absolutePath

    /** Main-thread confined. */
    @Volatile private var generation = 0L
    private var syncJob: Job? = null
    // Invalidates stale frame/variable and watch responses without restarting the DAP session.
    private var inspectionRevision = 0L
    private var watchRevision = 0L
    private val outputHandler = Handler(Looper.getMainLooper())
    private val outputBuffer = DebugOutputBuffer()
    private val outputScheduleLock = Any()
    private var outputFlushScheduled = false
    private val outputFlush = Runnable { flushOutput() }

    // ---------------------------------------------------------------- state

    var session: DapDebugSession? = null
        private set

    private val _uiState = MutableStateFlow(DebugUiState())
    val uiState: StateFlow<DebugUiState> = _uiState.asStateFlow()

    // Compatibility accessors keep the controller's transition logic concise while all
    // observable state is published as one immutable StateFlow snapshot.
    var status: String
        get() = _uiState.value.status
        private set(value) { _uiState.value = _uiState.value.copy(status = value) }
    var starting: Boolean
        get() = _uiState.value.starting
        private set(value) { _uiState.value = _uiState.value.copy(starting = value) }
    var targetFile: File?
        get() = _uiState.value.targetFile
        private set(value) { _uiState.value = _uiState.value.copy(targetFile = value) }
    var output: String
        get() = _uiState.value.output
        private set(value) { _uiState.value = _uiState.value.copy(output = value) }
    var stackFrames: List<JSONObject>
        get() = _uiState.value.stackFrames
        private set(value) { _uiState.value = _uiState.value.copy(stackFrames = value) }
    var threads: List<JSONObject>
        get() = _uiState.value.threads
        private set(value) { _uiState.value = _uiState.value.copy(threads = value) }
    var variables: List<DebugVariableItem>
        get() = _uiState.value.variables
        private set(value) { _uiState.value = _uiState.value.copy(variables = value) }
    var expandedVariables: Set<String>
        get() = _uiState.value.expandedVariables
        private set(value) { _uiState.value = _uiState.value.copy(expandedVariables = value) }
    var selectedFrameId: Int?
        get() = _uiState.value.selectedFrameId
        private set(value) { _uiState.value = _uiState.value.copy(selectedFrameId = value) }
    var threadId: Int?
        get() = _uiState.value.threadId
        private set(value) { _uiState.value = _uiState.value.copy(threadId = value) }
    var watches: List<String>
        get() = _uiState.value.watches
        private set(value) { _uiState.value = _uiState.value.copy(watches = value) }
    var watchValues: Map<String, String>
        get() = _uiState.value.watchValues
        private set(value) { _uiState.value = _uiState.value.copy(watchValues = value) }
    var breakOnRaised: Boolean
        get() = _uiState.value.breakOnRaised
        private set(value) { _uiState.value = _uiState.value.copy(breakOnRaised = value) }

    /**
     * Always read live from the controller. (The old panel captured a `val running`
     * in a composition snapshot, so a Restart that re-entered start() later saw a stale
     * `true` and returned silently.)
     */
    val isActive: Boolean
        get() = session != null && status != "Stopped" && status != "Error"

    init {
        restoreProjectBreakpoints()
        watches = runCatching {
            val array = JSONArray(prefs.getString("watches:$projectKey", "[]"))
            (0 until array.length()).mapNotNull { array.optString(it).takeIf { v -> v.isNotBlank() } }.distinct().take(20)
        }.getOrDefault(emptyList())
        breakOnRaised = prefs.getBoolean("breakOnRaised:$projectKey", false)
    }

    // -------------------------------------------------------------- helpers

    /** Coalesces bursts of DAP stdout/stderr into at most one StateFlow update per 50ms. */
    fun append(text: String) {
        if (text.isEmpty()) return
        outputBuffer.append(text)
        synchronized(outputScheduleLock) {
            if (!outputFlushScheduled) {
                outputFlushScheduled = true
                outputHandler.postDelayed(outputFlush, 50L)
            }
        }
    }

    private fun flushOutput() {
        synchronized(outputScheduleLock) { outputFlushScheduled = false }
        val chunk = outputBuffer.drain()
        if (chunk.isEmpty()) return
        output = (output + chunk).takeLast(100_000)
    }

    fun clearOutput() {
        outputHandler.removeCallbacks(outputFlush)
        outputBuffer.clear()
        synchronized(outputScheduleLock) { outputFlushScheduled = false }
        output = ""
    }

    private fun relative(file: File): String =
        runCatching { file.relativeTo(project.dir).invariantSeparatorsPath }.getOrDefault(file.name)

    private fun guestRoot(): String = guestProjectPath(project).trimEnd('/') + "/"

    private fun guestPathFor(file: File): String = guestRoot() + relative(file)

    private fun toDap(items: List<EditorBreakpoint>): List<DapBreakpoint> =
        items.map { DapBreakpoint(it.line, it.enabled, it.condition, it.hitCondition, it.logMessage) }

    private fun openGuestSource(sourcePath: String, line: Int) {
        val root = guestRoot()
        if (!sourcePath.startsWith(root)) return
        val local = File(project.dir, sourcePath.removePrefix(root))
        if (local.isFile) openLocation(local, line)
    }

    private fun closeAsync(old: DapDebugSession) {
        scope.launch(Dispatchers.IO) { runCatching { old.close() } }
    }

    private fun clearRuntimeState() {
        stackFrames = emptyList()
        threads = emptyList()
        variables = emptyList()
        selectedFrameId = null
        threadId = null
        watchValues = emptyMap()
        expandedVariables = emptySet()
    }

    // ---------------------------------------------------------- persistence

    fun persistBreakpoints(file: File?) {
        if (file != null) prefs.edit().putString("breakpoints:${file.absolutePath}", EditorBreakpointStore.encode(file)).apply()
    }

    private fun persistWatches(values: List<String>) {
        prefs.edit().putString("watches:$projectKey", JSONArray(values).toString()).apply()
    }

    private fun restoreProjectBreakpoints() {
        val prefix = "breakpoints:"
        val rootPrefix = project.dir.absolutePath.trimEnd(File.separatorChar) + File.separator
        prefs.all.keys.filter { it.startsWith(prefix) }.forEach { prefKey ->
            val path = prefKey.removePrefix(prefix)
            val file = File(path)
            if (path.startsWith(rootPrefix) && file.isFile && EditorBreakpointStore.all(file).isEmpty()) {
                prefs.getString(prefKey, null)?.let { EditorBreakpointStore.restore(file, it) }
            }
        }
    }

    // ------------------------------------------------------------ lifecycle

    /** Starts a fresh session. Ignored while one is starting or alive. */
    fun start(file: File?) {
        val target = file?.takeIf { it.isFile && it.extension.equals("py", true) } ?: return
        if (starting || isActive) return
        launchSession(target, restarting = false)
    }

    /**
     * Stops the debuggee and releases the session. Also cancels a start that is still in
     * flight: its result is discarded and closed as soon as it arrives.
     */
    fun stop() {
        val active = session
        if (active == null && !starting) return
        generation++
        inspectionRevision++
        watchRevision++
        syncJob?.cancel(); syncJob = null
        session = null
        starting = false
        status = "Stopped"
        targetFile = null
        clearRuntimeState()
        active?.let(::closeAsync)
    }

    /**
     * Restart = close the old session completely, THEN launch a new one, as one
     * generation-guarded sequence. It does not go through start()'s "already running"
     * guard, so it cannot be refused by stale state.
     */
    fun restart(fallbackFile: File?) {
        if (starting) return
        val target = (targetFile ?: fallbackFile)?.takeIf { it.isFile && it.extension.equals("py", true) } ?: return
        launchSession(target, restarting = true)
    }

    /** Releases everything when the owning project/IDE goes away. */
    fun dispose() {
        outputHandler.removeCallbacks(outputFlush)
        flushOutput()
        val active = session
        generation++
        inspectionRevision++
        watchRevision++
        syncJob?.cancel(); syncJob = null
        session = null
        starting = false
        if (active != null) {
            Thread({ runCatching { active.close() } }, "PySpace-Debug-Dispose").apply { isDaemon = true; start() }
        }
    }

    private fun launchSession(file: File, restarting: Boolean) {
        val previous = session
        val gen = ++generation
        inspectionRevision++
        watchRevision++
        syncJob?.cancel(); syncJob = null
        session = null
        starting = true
        status = if (restarting) "Restarting" else "Starting"
        targetFile = file
        clearRuntimeState()
        restoreProjectBreakpoints()
        val targetBps = EditorBreakpointStore.forProject(project.dir)
            .mapKeys { (source, _) -> guestPathFor(source) }
            .mapValues { (_, items) -> toDap(items) }
        clearOutput()
        output = if (restarting) "Restarting debugger…\n" else ""
        append("Preparing offline debugger…\n")

        scope.launch {
            try {
                // 1) The old debuggee/transport must be fully gone before the replacement starts.
                if (previous != null) withContext(Dispatchers.IO) { runCatching { previous.close() } }
                if (gen != generation) return@launch

                // 2) Offline debugpy runtime.
                val installed = withContext(Dispatchers.IO) {
                    com.codespace.ide.ide.codeintel.PythonDebugRuntimeInstaller.ensureInstalled(context, proot)
                }
                if (!installed) throw IllegalStateException("Could not provision the bundled offline debugpy runtime.")
                if (gen != generation) return@launch
                append("debugpy 1.8.22 ready. Starting DAP session…\n")

                // 3) New DAP session. Events can arrive before start() returns.
                val earlyStoppedThread = AtomicInteger(-1)
                val earlyTerminated = AtomicBoolean(false)
                val raised = breakOnRaised
                val started = withContext(Dispatchers.IO) {
                    DapDebugSession.start(
                        proot, project, file, targetBps, raised,
                        onEvent = { event ->
                            scope.launch { handleEvent(gen, event, earlyStoppedThread, earlyTerminated) }
                        },
                        // append() is thread-safe and batches UI publication; avoid creating
                        // one Main coroutine per process-output line during large output bursts.
                        onOutput = { text -> if (gen == generation) append(text) }
                    )
                }
                if (gen != generation) {
                    // Stopped/restarted/disposed while connecting: never leak the debuggee.
                    closeAsync(started)
                    return@launch
                }
                session = started
                starting = false
                status = when {
                    earlyStoppedThread.get() > 0 -> "Paused"
                    earlyTerminated.get() -> "Stopped"
                    else -> "Running"
                }
                append("DAP connected. ${targetBps.values.sumOf { list -> list.count { it.enabled } }} enabled project breakpoint(s).\n")
                startBreakpointSync(started, file, gen)
                earlyStoppedThread.get().takeIf { it > 0 }?.let { refreshStoppedState(started, it, gen = gen) }
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                if (gen == generation) {
                    starting = false
                    status = "Error"
                    append("\n[Debugger start failed: ${t.message}]\n")
                    targetFile = null
                }
            }
        }
    }

    private fun handleEvent(gen: Long, event: JSONObject, earlyStopped: AtomicInteger, earlyTerminated: AtomicBoolean) {
        // Late events from a closed/replaced session must not touch the new one.
        if (gen != generation) return
        when (event.optString("event")) {
            "initialized" -> append("[DAP initialized]\n")
            "thread" -> event.optJSONObject("body")?.optInt("threadId", -1)?.takeIf { it > 0 }?.let { threadId = it }
            "stopped" -> {
                val body = event.optJSONObject("body") ?: JSONObject()
                val thread = body.optInt("threadId", -1)
                if (thread > 0) {
                    earlyStopped.set(thread)
                    threadId = thread
                    session?.let { refreshStoppedState(it, thread, gen = gen) }
                }
                append("[Execution paused: ${body.optString("reason", "breakpoint")} ]\n")
            }
            "continued" -> {
                status = "Running"; stackFrames = emptyList(); variables = emptyList(); watchValues = emptyMap()
                append("[Running]\n")
            }
            "terminated", "exited" -> {
                earlyTerminated.set(true)
                inspectionRevision++
                watchRevision++
                status = "Stopped"; stackFrames = emptyList(); variables = emptyList()
                append("[Program finished]\n")
            }
            "output" -> event.optJSONObject("body")?.optString("output")?.let { append(it) }
            "breakpoint" -> event.optJSONObject("body")?.optJSONObject("breakpoint")?.let { bp ->
                append("[Breakpoint ${bp.optString("reason")}: line ${bp.optInt("line")} ${bp.optString("message")}]\n")
            }
            "pyspaceTransportError" -> {
                status = "Error"
                append("[DAP transport: ${event.optJSONObject("body")?.optString("message")} ]\n")
            }
        }
    }

    /** Keeps the live session in sync with gutter/panel breakpoint edits, panel open or not. */
    private fun startBreakpointSync(active: DapDebugSession, target: File, gen: Long) {
        syncJob?.cancel()
        syncJob = scope.launch {
            var previous: Map<File, List<EditorBreakpoint>> = emptyMap()
            EditorBreakpointStore.revision.collectLatest { _ ->
                if (gen != generation || active !== session) return@collectLatest
                val current = EditorBreakpointStore.forProject(project.dir)
                val sources = (previous.keys + current.keys + target).toSet()
                try {
                    withContext(Dispatchers.IO) {
                        for (sourceFile in sources) {
                            active.setBreakpoints(guestPathFor(sourceFile), toDap(current[sourceFile].orEmpty()))
                        }
                    }
                    previous = current
                    current.keys.forEach { persistBreakpoints(it) }
                    persistBreakpoints(target)
                } catch (t: Throwable) {
                    if (t is CancellationException) throw t
                    append("\n[Project breakpoint update failed: ${t.message}]\n")
                }
            }
        }
    }

    // ------------------------------------------------------------- stepping

    fun control(command: String) {
        val active = session ?: return
        val thread = threadId
        scope.launch(Dispatchers.IO) {
            try { active.control(command, thread) }
            catch (t: Throwable) { withContext(Dispatchers.Main.immediate) { append("\n[$command: ${t.message}]\n") } }
        }
    }

    fun showExceptionInfo() {
        val active = session ?: return
        val thread = threadId ?: return
        scope.launch(Dispatchers.IO) {
            val info = runCatching { active.exceptionInfo(thread) }.getOrNull()
            withContext(Dispatchers.Main.immediate) {
                append("[Exception: ${info?.optString("exceptionId")} · ${info?.optString("description")} ]\n")
            }
        }
    }

    fun updateBreakOnRaised(enabled: Boolean) {
        breakOnRaised = enabled
        prefs.edit().putBoolean("breakOnRaised:$projectKey", enabled).apply()
        val active = session ?: return
        scope.launch(Dispatchers.IO) {
            try { active.setExceptionBreakpoints(if (enabled) setOf("raised", "uncaught") else setOf("uncaught")) }
            catch (t: Throwable) { withContext(Dispatchers.Main.immediate) { append("[Exception breakpoint update failed: ${t.message}]\n") } }
        }
    }

    fun sendProgramInput(text: String, onDone: (Boolean) -> Unit = {}) {
        val active = session ?: return
        scope.launch(Dispatchers.IO) {
            val sent = active.sendProgramInput(text)
            withContext(Dispatchers.Main.immediate) {
                if (!sent) append("\n[Could not send program input.]\n")
                onDone(sent)
            }
        }
    }

    // ------------------------------------------------- paused-state inspection

    fun selectThread(id: Int) {
        if (id <= 0) return
        val active = session ?: return
        threadId = id
        refreshStoppedState(active, id)
    }

    fun selectFrame(frame: JSONObject) {
        val thread = threadId ?: return
        val id = frame.optInt("id", -1)
        selectedFrameId = id
        session?.let { refreshStoppedState(it, thread, id) }
        openGuestSource(frame.optJSONObject("source")?.optString("path").orEmpty(), frame.optInt("line"))
    }

    private fun refreshStoppedState(active: DapDebugSession, thread: Int, frameId: Int? = null, gen: Long = generation) {
        val revision = ++inspectionRevision
        scope.launch(Dispatchers.IO) {
            try {
                val threadsJson = active.threads()
                val newThreads = (0 until threadsJson.length()).mapNotNull { threadsJson.optJSONObject(it) }
                val framesJson = active.stackTrace(thread)
                val frames = (0 until framesJson.length()).mapNotNull { framesJson.optJSONObject(it) }
                val frame = frames.firstOrNull { it.optInt("id") == frameId } ?: frames.firstOrNull()
                val frameKey = frame?.optInt("id", -1) ?: -1
                val rows = ArrayList<DebugVariableItem>()
                if (frameKey >= 0) {
                    val scopes = active.scopes(frameKey)
                    for (i in 0 until scopes.length()) {
                        val sc = scopes.optJSONObject(i) ?: continue
                        val ref = sc.optInt("variablesReference", 0)
                        if (ref <= 0) continue
                        val scopeName = sc.optString("name", "Scope")
                        val scopePath = "scope:$frameKey:$i:$scopeName"
                        rows += DebugVariableItem(scopeName, "", "scope", -1, 0, scopePath, null, true)
                        val entries = active.variables(ref, 0, 150)
                        for (j in 0 until minOf(entries.length(), 150)) {
                            val item = entries.optJSONObject(j) ?: continue
                            val variableName = item.optString("name", "<unnamed>")
                            rows += DebugVariableItem(
                                variableName,
                                item.optString("value").take(4000),
                                item.optString("type"),
                                item.optInt("variablesReference"),
                                1,
                                "$scopePath/var:$j:$variableName",
                                scopePath
                            )
                        }
                    }
                }
                withContext(Dispatchers.Main.immediate) {
                    if (gen != generation || revision != inspectionRevision || active !== session || threadId != thread) return@withContext
                    threads = newThreads
                    stackFrames = frames
                    selectedFrameId = frameKey.takeIf { it >= 0 }
                    variables = rows
                    expandedVariables = emptySet()
                    status = "Paused"
                    frame?.let { openGuestSource(it.optJSONObject("source")?.optString("path").orEmpty(), it.optInt("line", 1)) }
                    refreshWatches(active, frameKey.takeIf { it >= 0 })
                }
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                withContext(Dispatchers.Main.immediate) {
                    if (gen == generation && revision == inspectionRevision && active === session && threadId == thread) append("\n[Could not inspect paused frame: ${t.message}]\n")
                }
            }
        }
    }

    fun toggleVariable(item: DebugVariableItem) {
        if (item.path in expandedVariables) {
            expandedVariables = expandedVariables - item.path
            return
        }
        expandedVariables = expandedVariables + item.path
        // Scope children come with the frame snapshot; only fetch lazily for nested references.
        if (item.reference <= 0 || variables.any { it.parentPath == item.path }) return
        val active = session ?: return
        val gen = generation
        val revision = inspectionRevision
        val frameAtRequest = selectedFrameId
        scope.launch(Dispatchers.IO) {
            val children = runCatching { active.variables(item.reference, 0, 100) }.getOrNull() ?: return@launch
            val mapped = (0 until minOf(children.length(), 100)).mapNotNull { i ->
                children.optJSONObject(i)?.let { child ->
                    val childName = child.optString("name", "<unnamed>")
                    DebugVariableItem(
                        childName,
                        child.optString("value").take(4000),
                        child.optString("type"),
                        child.optInt("variablesReference"),
                        item.depth + 1,
                        "${item.path}/var:$i:$childName",
                        item.path
                    )
                }
            }
            withContext(Dispatchers.Main.immediate) {
                if (gen != generation || revision != inspectionRevision || active !== session ||
                    frameAtRequest != selectedFrameId || item.path !in expandedVariables) return@withContext
                // Replace only this parent's cached children.
                variables = variables.filterNot { it.parentPath == item.path } + mapped
            }
        }
    }

    // -------------------------------------------------------------- watches

    fun addWatch(expression: String) {
        val value = expression.trim()
        if (value.isEmpty() || value in watches || watches.size >= 20) return
        val updated = watches + value
        watches = updated
        persistWatches(updated)
        if (status == "Paused") session?.let { refreshWatches(it, selectedFrameId, updated) }
    }

    fun removeWatch(expression: String) {
        val updated = watches - expression
        watches = updated
        watchValues = watchValues - expression
        watchRevision++
        persistWatches(updated)
    }

    fun refreshWatches() {
        session?.let { refreshWatches(it, selectedFrameId) }
    }

    private fun refreshWatches(active: DapDebugSession, frameId: Int?, expressions: List<String> = watches) {
        if (expressions.isEmpty()) { watchRevision++; watchValues = emptyMap(); return }
        val gen = generation
        val revision = ++watchRevision
        val requestedFrame = frameId
        val requestedExpressions = expressions.toList()
        scope.launch(Dispatchers.IO) {
            val result = LinkedHashMap<String, String>()
            requestedExpressions.forEach { expression ->
                result[expression] = runCatching {
                    val value = active.evaluate(expression, frameId)
                    value.optString("result", "<no value>") + value.optString("type").takeIf { it.isNotBlank() }?.let { " · $it" }.orEmpty()
                }.getOrElse { "<error: ${it.message ?: "evaluation failed"}>" }.take(2000)
            }
            withContext(Dispatchers.Main.immediate) {
                if (gen == generation && revision == watchRevision && active === session &&
                    requestedFrame == selectedFrameId && requestedExpressions == watches) watchValues = result
            }
        }
    }
}
