package com.codespace.ide.ide.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ide.theme.IdeTheme
import java.io.File

/** Navigation strip for open documents. Saving/closing policy remains owned by the host. */
@Composable
fun EditorTabStrip(
    session: EditorSession,
    onCloseTab: (index: Int, tab: OpenTab) -> Unit,
) {
    if (session.tabs.isEmpty()) return

    // A plain horizontally-scrollable row avoids TabRow's transient index/measurement
    // mismatch when tabs are added or closed in the same frame.
    val safeActive = session.activeIndex.coerceIn(0, session.tabs.size - 1)
    Row(
        Modifier
            .fillMaxWidth()
            .background(Color(IdeTheme.PANEL))
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 4.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        session.tabs.forEachIndexed { index, tab ->
            val selected = index == safeActive
            Row(
                Modifier
                    .padding(end = 4.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (selected) Color(IdeTheme.ACCENT).copy(alpha = 0.16f)
                        else Color.Transparent
                    )
                    .clickable { session.activeIndex = index }
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    tab.name + if (tab.dirty) " •" else "",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    color = if (selected) Color(IdeTheme.ACCENT) else Color(IdeTheme.TEXT)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    "✕",
                    fontSize = 11.sp,
                    color = Color(IdeTheme.DIM),
                    modifier = Modifier.clickable { onCloseTab(index, tab) }
                )
            }
        }
    }
}

/** Project-relative path navigation for the active Python document. */
@Composable
fun EditorBreadcrumb(
    session: EditorSession,
    activeFile: File,
    onRevealPath: (File) -> Unit,
) {
    val rootPath = session.project.dir.absoluteFile.absolutePath.trimEnd('/')
    val activePath = activeFile.absoluteFile.absolutePath
    val relativePath = when {
        activePath == rootPath -> ""
        activePath.startsWith(rootPath + "/") -> activePath.removePrefix(rootPath + "/")
        else -> ""
    }
    val breadcrumbFiles = androidx.compose.runtime.remember(rootPath, relativePath) {
        buildList {
            add(File(rootPath))
            var current = File(rootPath)
            relativePath.split('/').filter { it.isNotBlank() }.forEach { part ->
                current = File(current, part)
                add(current)
            }
        }
    }
    if (breadcrumbFiles.size <= 1) return

    Row(
        Modifier
            .fillMaxWidth()
            .background(Color(IdeTheme.PANEL))
            .horizontalScroll(rememberScrollState())
            .padding(start = 12.dp, end = 10.dp, top = 3.dp, bottom = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        breadcrumbFiles.forEachIndexed { index, crumb ->
            if (index > 0) {
                Text(">", color = Color(IdeTheme.DIM), fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 5.dp))
            }
            val isCurrent = index == breadcrumbFiles.lastIndex
            Text(
                text = if (index == 0) session.project.dir.name else crumb.name,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Normal,
                color = Color(if (isCurrent) IdeTheme.ACCENT else IdeTheme.DIM),
                maxLines = 1,
                modifier = Modifier
                    .clip(RoundedCornerShape(5.dp))
                    .clickable { onRevealPath(crumb) }
                    .padding(horizontal = 3.dp, vertical = 3.dp)
            )
        }
    }
}
