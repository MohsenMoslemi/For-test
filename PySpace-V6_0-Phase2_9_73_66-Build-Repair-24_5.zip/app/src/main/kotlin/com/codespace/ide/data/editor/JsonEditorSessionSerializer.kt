package com.codespace.ide.data.editor

import com.codespace.ide.domain.editor.contract.EditorSessionSerializer
import com.codespace.ide.domain.editor.model.EditorSessionSnapshot

class JsonEditorSessionSerializer : EditorSessionSerializer {
    override fun serialize(snapshot: EditorSessionSnapshot): String =
        EditorSessionPersistenceCodec.encode(snapshot)
}
