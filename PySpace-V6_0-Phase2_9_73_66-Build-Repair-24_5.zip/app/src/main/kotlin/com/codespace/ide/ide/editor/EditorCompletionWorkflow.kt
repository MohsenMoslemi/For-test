package com.codespace.ide.ide.editor

import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import com.codespace.ide.ide.codeintel.PythonCompletionItem

/**
 * Coordinates accepting a completion and committing it as one undoable edit.
 * Text construction remains in [EditorCompletionApplier]; this class owns the
 * editor-facing transaction boundary and returns the updated field value.
 */
internal class EditorCompletionWorkflow {
    fun apply(
        tab: OpenTab,
        source: String,
        selection: TextRange,
        replaceRange: Pair<Int, Int>,
        item: PythonCompletionItem,
        onFieldChange: (TextFieldValue) -> Unit,
        onCompletionDismiss: () -> Unit,
        onCursor: (Int, Int) -> Unit
    ) {
        val result = EditorCompletionApplier.apply(
            source = source,
            replaceStart = replaceRange.first,
            replaceEnd = replaceRange.second,
            item = item
        )
        // Import insertion and symbol insertion remain a single history entry.
        tab.applyEdit(result.text, selection.start, selection.end)
        onFieldChange(
            TextFieldValue(result.text, TextRange(result.caret.coerceIn(0, result.text.length)))
        )
        onCompletionDismiss()
        val lineColumn = lineColAt(result.text, result.caret)
        onCursor(lineColumn[0], lineColumn[1])
    }
}
