package com.codespace.ide.ide.shell

import com.codespace.ide.ide.IdeScreen
import com.codespace.ide.ide.PyProject
import java.io.File

/** Immutable result of resolving the last-project launch marker against disk. */
internal data class IdeLaunchRestoreState(
    val lastProjectPath: String,
    val missingProject: PyProject?,
    val restoredScreen: IdeScreen?,
) {
    companion object {
        fun resolve(lastProjectPath: String): IdeLaunchRestoreState {
            if (lastProjectPath.isBlank()) {
                return IdeLaunchRestoreState(lastProjectPath, null, null)
            }
            return try {
                val directory = File(lastProjectPath)
                if (directory.isDirectory) {
                    IdeLaunchRestoreState(
                        lastProjectPath = lastProjectPath,
                        missingProject = null,
                        restoredScreen = IdeScreen.Editor(PyProject(directory.name, directory)),
                    )
                } else {
                    val missing = PyProject(directory.name, directory)
                    IdeLaunchRestoreState(lastProjectPath, missing, null)
                }
            } catch (_: Exception) {
                IdeLaunchRestoreState(lastProjectPath, null, null)
            }
        }
    }
}
