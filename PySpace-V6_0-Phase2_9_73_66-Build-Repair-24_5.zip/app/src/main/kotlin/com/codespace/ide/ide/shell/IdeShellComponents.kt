package com.codespace.ide.ide.shell

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ide.PanelTab
import com.codespace.ide.ide.theme.IdeTheme

@Composable
internal fun WorkspacePreparingScreen(error: String? = null, onRetry: (() -> Unit)? = null) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(IdeTheme.BG))
            .verticalScroll(rememberScrollState())
            .padding(vertical = 28.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (error == null) {
                CircularProgressIndicator(
                    color = Color(IdeTheme.ACCENT),
                    strokeWidth = 2.5.dp
                )
                Text(
                    text = "Preparing private workspace…",
                    modifier = Modifier.padding(top = 16.dp),
                    color = Color(IdeTheme.DIM),
                    fontSize = 13.sp
                )
            } else {
                Text(
                    text = "Project migration could not be completed",
                    color = Color(IdeTheme.TEXT),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = error,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(IdeTheme.CARD))
                        .padding(12.dp),
                    color = Color(IdeTheme.DIM),
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
                TextButton(onClick = { onRetry?.invoke() }, modifier = Modifier.padding(top = 10.dp)) {
                    Text("Retry", color = Color(IdeTheme.ACCENT))
                }
                Text(
                    text = "Your original project files have not been deleted.",
                    modifier = Modifier.padding(top = 6.dp),
                    color = Color(IdeTheme.DIM),
                    fontSize = 11.sp
                )
            }
        }
    }
}

/** Slim warning + one-tap venv build above the terminal surface. */
@Composable
internal fun VenvBanner(venvName: String, busy: Boolean, msg: String?, onBuild: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Color(IdeTheme.WARNING_SURFACE))
        .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("⚠", fontSize = 14.sp, color = Color(IdeTheme.WARN))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(
                if (busy) "Building project venv ‘$venvName’…" else "Project venv ‘$venvName’ not built",
                fontSize = 12.sp, fontWeight = FontWeight.Bold,
                color = Color(IdeTheme.TEXT)
            )
            Text(
                if (busy) "Preparing the isolated environment. The terminal will activate it automatically when ready."
                else "python/pip fall back to system until built.",
                fontSize = 11.sp, color = Color(IdeTheme.DIM)
            )
            if (msg != null) {
                Text(msg, fontSize = 11.sp, color = Color(IdeTheme.ERROR))
            }
        }
        if (busy) {
            CircularProgressIndicator(
                Modifier.size(18.dp), strokeWidth = 2.dp,
                color = Color(IdeTheme.ACCENT)
            )
        } else {
            TextButton(onClick = onBuild) {
                Text("Build", fontSize = 13.sp, color = Color(IdeTheme.ACCENT))
            }
        }
    }
}

@Composable
internal fun PanelChrome(
    tab: PanelTab,
    problemErrorCount: Int,
    problemWarningCount: Int,
    maximized: Boolean,
    compact: Boolean,
    onTab: (PanelTab) -> Unit,
    onToggleMax: () -> Unit,
    onClose: () -> Unit,
    onDrag: (dyPx: Float) -> Unit
) {
    // Drag handle (resize). Tapping a tab while compact opens the panel;
    // dragging up on the handle does the same.
    Box(
        Modifier
        .fillMaxWidth()
        .height(if (compact) 10.dp else 20.dp)
        .pointerInput(compact) {
            detectVerticalDragGestures { _, dragAmount ->
                if (compact && dragAmount < -4f) onTab(tab) else onDrag(dragAmount)
            }
        },
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
            .width(44.dp)
            .height(4.dp)
            .background(Color(IdeTheme.LINE), RoundedCornerShape(2.dp))
        )
    }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PanelTabButton("▤", "Console", tab == PanelTab.Console, null, null, Modifier.weight(1f)) { onTab(PanelTab.Console) }
        PanelTabButton("⚠", "Problems", tab == PanelTab.Problems, problemErrorCount, problemWarningCount, Modifier.weight(1f)) { onTab(PanelTab.Problems) }
        PanelTabButton(">_", "Terminal", tab == PanelTab.Terminal, null, null, Modifier.weight(1f)) { onTab(PanelTab.Terminal) }
        PanelTabButton("◉", "Debug", tab == PanelTab.Debug, null, null, Modifier.weight(1f)) { onTab(PanelTab.Debug) }
        PanelTabButton("✓", "Tests", tab == PanelTab.Test, null, null, Modifier.weight(1f)) { onTab(PanelTab.Test) }
        PanelTabButton("", "Camera", tab == PanelTab.Camera, null, null, Modifier.weight(1f), iconRes = com.codespace.ide.R.drawable.ic_camera_material) { onTab(PanelTab.Camera) }
        if (!compact) {
            TextButton(onClick = onToggleMax, modifier = Modifier.width(40.dp)) {
                Text(if (maximized) "⤓" else "⤢", fontSize = 14.sp, color = Color(IdeTheme.DIM))
            }
            TextButton(onClick = onClose, modifier = Modifier.width(40.dp)) {
                Text("✕", fontSize = 13.sp, color = Color(IdeTheme.DIM))
            }
        }
    }
}

/** Icon-over-label toolbar item (reference bottom-bar style). */
@Composable
internal fun PanelTabButton(
    glyph: String,
    label: String,
    selected: Boolean,
    errorBadge: Int?,
    warningBadge: Int?,
    modifier: Modifier = Modifier,
    iconRes: Int? = null,
    onClick: () -> Unit
) {
    val fg = if (selected) Color(IdeTheme.ACCENT) else Color(IdeTheme.DIM)
    Column(
        modifier
        .clip(RoundedCornerShape(10.dp))
        .clickable(onClick = onClick)
        .padding(vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (iconRes != null) {
                Image(painterResource(iconRes), contentDescription = label, modifier = Modifier.size(20.dp).offset(y = 2.dp),
                    colorFilter = androidx.compose.ui.graphics.ColorFilter.tint(fg))
            } else {
                Text(
                    glyph, fontSize = 19.sp,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                    color = fg
                )
            }
            if (warningBadge != null && warningBadge > 0) {
                Box(
                    Modifier.align(Alignment.TopStart).padding(end = 14.dp)
                        .background(Color(IdeTheme.WARN), RoundedCornerShape(7.dp))
                        .padding(horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("$warningBadge", fontSize = 9.sp, color = Color(IdeTheme.ON_ACCENT), fontWeight = FontWeight.Bold)
                }
            }
            if (errorBadge != null && errorBadge > 0) {
                Box(
                    Modifier.align(Alignment.TopEnd).padding(start = 14.dp)
                        .background(Color(IdeTheme.ERROR), RoundedCornerShape(7.dp))
                        .padding(horizontal = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("$errorBadge", fontSize = 9.sp, color = Color(IdeTheme.ON_ERROR), fontWeight = FontWeight.Bold)
                }
            }
        }
        Text(
            label, fontSize = 10.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            color = fg
        )
    }
}

/** A Run pressed in the Console while the same program already runs elsewhere (asks what to do). */
