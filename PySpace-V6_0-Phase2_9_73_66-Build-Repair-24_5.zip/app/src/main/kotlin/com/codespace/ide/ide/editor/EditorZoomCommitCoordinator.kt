package com.codespace.ide.ide.editor

import androidx.compose.foundation.ScrollState
import kotlinx.coroutines.CoroutineScope

/**
 * Owns the dependency boundary for committing a pinch-zoom preview into the
 * real editor font/layout. It binds the one per-surface zoom session, scroll
 * pair, geometry providers and font callback; callers provide only the start
 * and target font sizes when a gesture finishes.
 *
 * The actual frame animation and bounded recovery remain in
 * [launchEditorZoomCommit], keeping timing policy independently testable.
 */
internal class EditorZoomCommitCoordinator(
    private val scope: CoroutineScope,
    private val session: EditorZoomSessionState,
    private val verticalScroll: ScrollState,
    private val horizontalScroll: ScrollState,
    private val fontMetricsFor: (Float) -> FloatArray,
    private val currentGutterPx: () -> Float,
    private val gutterPxForFont: (Float) -> Float,
    private val textPaddingPx: () -> Float,
    private val wordWrap: () -> Boolean,
    private val onFontSizeChange: (Float) -> Unit
) {
    fun commit(startFont: Float, targetFont: Float) {
        launchEditorZoomCommit(
            scope = scope,
            anchor = session.anchor,
            verticalScroll = verticalScroll,
            horizontalScroll = horizontalScroll,
            startFont = startFont,
            targetFont = targetFont,
            currentScaleY = session.scaleY.value,
            currentScaleX = session.scaleX.value,
            fontMetricsFor = fontMetricsFor,
            currentGutterPx = currentGutterPx,
            gutterPxForFont = gutterPxForFont,
            textPaddingPx = textPaddingPx(),
            wordWrap = wordWrap(),
            onFontSizeChange = onFontSizeChange,
            pinchScaleY = session.scaleY,
            pinchScaleX = session.scaleX,
            pinchTargetFont = session.targetFont,
            pinchGestureActive = session.gestureActive,
            zoomCommitInProgress = session.commitInProgress,
            commitShiftX = session.commitShiftX,
            commitShiftY = session.commitShiftY
        )
    }
}
