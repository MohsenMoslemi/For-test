package com.codespace.ide.ide.projects

import com.codespace.ide.ProotManager
import com.codespace.ide.UbuntuManager
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.InternalCoroutinesApi
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import com.codespace.ide.ide.PythonRuntimeCatalog

/** Downloads and installs portable CPython builds into the app's private runtime. */
class PythonRuntimeInstaller(
    private val ubuntu: UbuntuManager,
    private val proot: ProotManager,
) {
    private val installMutex = Mutex()

    suspend fun ensureInstalled(versionId: String, onProgress: (message: String, fraction: Float?) -> Unit = { _, _ -> }) =
        installMutex.withLock { ensureInstalledLocked(versionId, onProgress) }

    private suspend fun ensureInstalledLocked(
        versionId: String,
        onProgress: (message: String, fraction: Float?) -> Unit = { _, _ -> },
    ) {
        val option = PythonRuntimeCatalog.require(versionId)
        if (option.isBundled) {
            onProgress("Checking bundled Python ${option.version}…", null)
            val output = proot.runOnce("/usr/bin/python3 --version 2>&1")
            check(output.contains("Python 3.12.")) {
                "The bundled Python runtime is unavailable or has an unexpected version. $output"
            }
            return
        }

        val root = ubuntu.rootfsDir
        val target = File(root, "opt/pyspace-python/${option.version}")
        val marker = File(target, ".pyspace-runtime-ready")
        val executable = File(target, "bin/python${option.version.substringBeforeLast('.')}")
        if (executable.isFile) {
            val probe = proot.runOnce("${q(option.guestExecutable)} --version 2>&1")
            if (probe.contains("Python ${option.version}") && probe.contains("[exit=0]")) {
                if (!marker.isFile) {
                    marker.parentFile?.mkdirs()
                    marker.writeText("${option.version}\n")
                }
                onProgress("Python ${option.version} is already installed.", 1f)
                return
            }
            marker.delete()
        }

        val freeBytes = android.os.StatFs(root.absolutePath).availableBytes
        check(freeBytes >= 128L * 1024L * 1024L) {
            "Not enough free storage to install Python ${option.version}. Please free at least 128 MB and retry."
        }

        val downloads = File(root, "opt/pyspace-python/downloads")
        if (!downloads.exists() && !downloads.mkdirs()) {
            throw IllegalStateException("Could not prepare Python runtime storage.")
        }
        val archive = File(downloads, option.archiveName)
        val expectedHash = option.sha256
            ?: throw IllegalStateException("No verified SHA-256 is configured for Python ${option.version}.")

        if (!archive.isFile || sha256(archive) != expectedHash) {
            if (archive.exists()) archive.delete()
            val part = File(downloads, option.archiveName + ".part")
            if (part.exists()) part.delete()
            try {
                var lastProgressBytes = 0L
                onProgress("Downloading Python ${option.version}…", 0f)
                download(option.downloadUrl, part) { received, total ->
                    if (received - lastProgressBytes >= 512L * 1024L || (total > 0L && received >= total)) {
                        lastProgressBytes = received
                        val fraction = if (total > 0L) (received.toFloat() / total.toFloat()).coerceIn(0f, 1f) else null
                        val receivedMb = received / (1024f * 1024f)
                        val totalText = if (total > 0L) " / ${"%.1f".format(java.util.Locale.US, total / (1024f * 1024f))} MB" else " MB"
                        onProgress("Downloading Python ${option.version}: ${"%.1f".format(java.util.Locale.US, receivedMb)}$totalText", fraction)
                    }
                }
                currentCoroutineContext().ensureActive()
                onProgress("Verifying Python ${option.version} download…", null)
                check(sha256(part).equals(expectedHash, ignoreCase = true)) {
                    "Python ${option.version} download failed its SHA-256 integrity check. Please retry."
                }
                if (!part.renameTo(archive)) {
                    part.copyTo(archive, overwrite = true)
                    part.delete()
                }
            } catch (error: Throwable) {
                part.delete()
                currentCoroutineContext().ensureActive()
                throw error
            }
        }

        currentCoroutineContext().ensureActive()
        onProgress("Installing Python ${option.version}…", null)
        val guestArchive = "/opt/pyspace-python/downloads/${option.archiveName}"
        val staging = "/opt/pyspace-python/.${option.version}.installing"
        val guestTarget = "/opt/pyspace-python/${option.version}"
        val binaryName = "python${option.version.substringBeforeLast('.')}"
        val command = "set -eu; " +
            "mkdir -p /opt/pyspace-python; " +
            "rm -rf ${q(staging)}; mkdir -p ${q(staging)}; " +
            "tar -xzf ${q(guestArchive)} -C ${q(staging)}; " +
            "test -x ${q("$staging/python/bin/$binaryName")}; " +
            "${q("$staging/python/bin/$binaryName")} -c 'import venv,ensurepip,ssl,sqlite3; print(\"runtime-check-ok\")'; " +
            "if [ -e ${q(guestTarget)} ]; then mv ${q(guestTarget)} ${q("$guestTarget.previous")}; fi; " +
            "if ! mv ${q("$staging/python")} ${q(guestTarget)}; then " +
            "if [ -e ${q("$guestTarget.previous")} ]; then mv ${q("$guestTarget.previous")} ${q(guestTarget)}; fi; exit 1; fi; " +
            "rmdir ${q(staging)} 2>/dev/null || true; " +
            "if ! ( printf '%s\\n' ${q(option.version)} > ${q("$guestTarget/.pyspace-runtime-ready")} && ${q("$guestTarget/bin/$binaryName")} --version ); then " +
            "rm -rf ${q(guestTarget)}; if [ -e ${q("$guestTarget.previous")} ]; then mv ${q("$guestTarget.previous")} ${q(guestTarget)}; fi; exit 1; fi; " +
            "rm -rf ${q("$guestTarget.previous")}; echo PYSPACE_PYTHON_READY_${option.version}"
        val output = proot.runOnce(command, timeoutSec = 600L)
        check(output.contains("PYSPACE_PYTHON_READY_${option.version}") && output.contains("[exit=0]")) {
            "Could not install Python ${option.version}. " + output.lineSequence().filter { it.isNotBlank() }.toList().takeLast(5).joinToString(" / ").take(500)
        }
        archive.delete()
        onProgress("Python ${option.version} is ready.", 1f)
    }

    @OptIn(InternalCoroutinesApi::class)
    private suspend fun download(url: String, destination: File, onBytes: (Long, Long) -> Unit) {
        val connection = open(url)
        val job = currentCoroutineContext()[Job]
        // Disconnect the active socket immediately when the user cancels the download.
        val cancellationHandle = job?.invokeOnCompletion(onCancelling = true, invokeImmediately = true) { cause ->
            if (cause != null) connection.disconnect()
        }
        try {
            check(connection.responseCode == HttpURLConnection.HTTP_OK) {
                "Download server returned HTTP ${connection.responseCode}."
            }
            val total = connection.contentLengthLong
            var received = 0L
            BufferedInputStream(connection.inputStream).use { input ->
                BufferedOutputStream(FileOutputStream(destination)).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val count = input.read(buffer)
                        if (count < 0) break
                        output.write(buffer, 0, count)
                        received += count
                        onBytes(received, total)
                    }
                    output.flush()
                }
            }
            if (total > 0L) check(received == total) { "Python download was incomplete ($received/$total bytes)." }
        } finally {
            cancellationHandle?.dispose()
            connection.disconnect()
        }
    }

    private fun open(url: String): HttpURLConnection {
        return (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 25_000
            readTimeout = 45_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "PySpace-Android/1.0")
            setRequestProperty("Accept", "application/octet-stream")
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buffer = ByteArray(128 * 1024)
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                digest.update(buffer, 0, count)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }

    private fun q(value: String): String = "'" + value.replace("'", "'\\''") + "'"
}
