package com.codespace.ide.ide.codeintel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.codespace.ide.runtime.RuntimeDispatchers
import java.io.File
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

const val CODE_SEARCH_SYMBOLS = 0
const val CODE_SEARCH_MEMBERS = 1
const val CODE_SEARCH_TEXT = 2

data class CodeSearchUiState(
    val textHits: Map<File, List<TextHit>> = emptyMap(),
    val symbolHits: Map<File, List<OutlineItem>> = emptyMap(),
    val searching: Boolean = false,
    val invalidPattern: Boolean = false,
    val query: String = "",
    val mode: Int = CODE_SEARCH_TEXT,
)

data class CodeOutlineUiState(
    val filePath: String? = null,
    val items: List<OutlineItem> = emptyList(),
    val loading: Boolean = false,
)

/** Per-project coordinator for outline and project-wide source search. */
class CodeIntelligenceViewModel(
    private val dispatchers: RuntimeDispatchers,
    private val repository: CodeIntelligenceRepository,
) : ViewModel() {
    private val _search = MutableStateFlow(CodeSearchUiState())
    val search: StateFlow<CodeSearchUiState> = _search.asStateFlow()
    private val _outline = MutableStateFlow(CodeOutlineUiState())
    val outline: StateFlow<CodeOutlineUiState> = _outline.asStateFlow()
    private var searchJob: Job? = null
    private var outlineJob: Job? = null
    private var requestId = 0L
    private var outlineRequestId = 0L

    fun search(root: File, query: String, mode: Int, options: TextSearchOptions = TextSearchOptions()) {
        val request = ++requestId
        searchJob?.cancel()
        if (query.length < 2) {
            _search.value = CodeSearchUiState(query = query, mode = mode)
            return
        }
        _search.value = CodeSearchUiState(query = query, mode = mode, searching = true)
        searchJob = viewModelScope.launch {
            try {
                delay(250)
                if (request != requestId) return@launch
                when (mode) {
                    CODE_SEARCH_TEXT -> {
                        val result = withContext(dispatchers.io) {
                            repository.searchText(root, query, options)
                        }
                        if (request == requestId) {
                            _search.value = CodeSearchUiState(
                                textHits = result.hits,
                                searching = false,
                                invalidPattern = result.invalidPattern,
                                query = query,
                                mode = mode,
                            )
                        }
                    }
                    CODE_SEARCH_SYMBOLS, CODE_SEARCH_MEMBERS -> {
                        val hits = withContext(dispatchers.io) {
                            repository.searchSymbols(root, query, membersOnly = mode == CODE_SEARCH_MEMBERS)
                        }
                        if (request == requestId) {
                            _search.value = CodeSearchUiState(symbolHits = hits, query = query, mode = mode)
                        }
                    }
                    else -> _search.value = CodeSearchUiState(query = query, mode = mode)
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                if (request == requestId) {
                    _search.value = CodeSearchUiState(query = query, mode = mode)
                }
            }
        }
    }

    fun clearSearch() {
        requestId++
        searchJob?.cancel()
        _search.value = CodeSearchUiState()
    }

    fun analyze(file: File?, text: String?) {
        if (file == null || text == null) {
            outlineRequestId++
            outlineJob?.cancel()
            outlineJob = null
            _outline.value = CodeOutlineUiState()
            return
        }
        val path = file.absolutePath
        val request = ++outlineRequestId
        outlineJob?.cancel()
        _outline.value = CodeOutlineUiState(filePath = path, loading = true)
        outlineJob = viewModelScope.launch {
            try {
                // Coalesce rapid keystrokes: only parse the settled document.
                delay(140)
                if (request != outlineRequestId) return@launch
                val items = withContext(dispatchers.cpu) {
                    repository.outline(file.name, text)
                }
                if (request == outlineRequestId) {
                    _outline.value = CodeOutlineUiState(filePath = path, items = items)
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                if (request == outlineRequestId) {
                    _outline.value = CodeOutlineUiState(filePath = path)
                }
            }
        }
    }

    override fun onCleared() {
        requestId++
        outlineRequestId++
        searchJob?.cancel()
        outlineJob?.cancel()
        searchJob = null
        outlineJob = null
        super.onCleared()
    }

    class Factory(
        private val dispatchers: RuntimeDispatchers,
        private val repository: CodeIntelligenceRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (!modelClass.isAssignableFrom(CodeIntelligenceViewModel::class.java)) {
                throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
            }
            return CodeIntelligenceViewModel(dispatchers, repository) as T
        }
    }
}
