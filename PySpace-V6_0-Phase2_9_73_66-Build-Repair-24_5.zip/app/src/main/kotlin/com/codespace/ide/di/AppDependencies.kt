package com.codespace.ide.di

import com.codespace.ide.ProotManager
import com.codespace.ide.UbuntuManager
import com.codespace.ide.application.editor.usecase.SerializeEditorSessionUseCase
import com.codespace.ide.domain.packages.PackageManagerRepository
import com.codespace.ide.ide.RunHub
import com.codespace.ide.ide.codeintel.CodeIntelligenceRepository
import com.codespace.ide.ide.explorer.FileExplorerRepository
import com.codespace.ide.ide.notebook.NotebookRepository
import com.codespace.ide.ide.projects.ProjectRepository
import com.codespace.ide.ide.settings.SettingsRepository
import com.codespace.ide.ide.run.ProjectWebResolverRepository
import com.codespace.ide.ide.run.RunOrchestrator
import com.codespace.ide.runtime.RuntimeDispatchers
import com.codespace.ide.runtime.RuntimeTaskScope
import com.codespace.ide.MainActivity

/**
 * Typed dependencies required by the main application UI.
 *
 * Koin is resolved once by MainActivity, at the Android composition root.
 * Composables and feature coordinators receive explicit dependencies and do
 * not use the global service locator themselves.
 */
data class AppDependencies(
    val ubuntuManager: UbuntuManager,
    val prootManager: ProotManager,
    val runtimeDispatchers: RuntimeDispatchers,
    val notebookRepository: NotebookRepository,
    val projectRepository: ProjectRepository,
    val settingsRepository: SettingsRepository,
    val runHub: RunHub,
    val runOrchestrator: RunOrchestrator,
    val projectWebResolver: ProjectWebResolverRepository,
    val runtimeTaskScope: RuntimeTaskScope,
    val fileExplorerRepository: FileExplorerRepository,
    val codeIntelligenceRepository: CodeIntelligenceRepository,
    val serializeEditorSession: SerializeEditorSessionUseCase,
    val packageManagerRepository: PackageManagerRepository,
)
