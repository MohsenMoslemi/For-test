package com.codespace.ide.ide.terminal

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ProotManager
import com.codespace.ide.TerminalScreen
import com.codespace.ide.ide.theme.IdeTheme


private data class TerminalTabEntry(val id: Long, val revision: Int = 0)

/**
 * Independent interactive PTY tabs for a single workspace context.
 * Every tab owns its own TerminalScreen composition, emulator, transcript,
 * input state and PTY. Inactive tabs stay composed (and therefore keep their
 * shell alive), but are marked invisible so they cannot own the IME/focus.
 */
@Composable
fun TerminalTabs(
    root: ProotManager,
    visible: Boolean,
    workDir: String?,
    autoActivate: String? = null,
    bridge: TermBridge? = null,
    title: String? = null,
    showRestart: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val tabs = remember {
        mutableStateListOf(TerminalTabEntry(1L))
    }
    var nextId by remember { mutableStateOf(2L) }
    var selectedId by remember { mutableStateOf(1L) }
    var confirmRestart by remember { mutableStateOf(false) }

    Column(modifier.fillMaxSize().background(Color(IdeTheme.BG))) {
        Row(
            Modifier.fillMaxWidth().padding(start = 8.dp, end = 5.dp, top = 1.dp, bottom = 1.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            if (title != null) {
                Text(title, color = Color(IdeTheme.TEXT), fontSize = 13.sp,
                    modifier = Modifier.padding(start = 4.dp, end = 5.dp))
            }
            Row(
                Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                tabs.forEach { tab ->
                    val selected = tab.id == selectedId
                    Row(
                        Modifier.clip(RoundedCornerShape(7.dp))
                            .background(Color(if (selected) IdeTheme.CARD else IdeTheme.PANEL)),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Session ${tab.id}",
                            color = Color(if (selected) IdeTheme.ACCENT else IdeTheme.DIM),
                            fontSize = 10.sp,
                            modifier = Modifier.clickable { selectedId = tab.id }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                        if (tabs.size > 1) {
                            Text(
                                "×", color = Color(IdeTheme.DIM), fontSize = 13.sp,
                                modifier = Modifier.clickable {
                                    val removedIndex = tabs.indexOfFirst { it.id == tab.id }
                                    tabs.removeAll { it.id == tab.id }
                                    if (selectedId == tab.id) {
                                        selectedId = tabs.getOrNull((removedIndex - 1).coerceAtLeast(0))?.id
                                            ?: tabs.first().id
                                    }
                                }.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }
            Text(
                "+", color = Color(IdeTheme.ACCENT), fontSize = 20.sp,
                modifier = Modifier.clickable {
                    val id = nextId++
                    tabs.add(TerminalTabEntry(id))
                    selectedId = id
                }.padding(horizontal = 8.dp, vertical = 1.dp)
            )
            if (showRestart) {
                Text("Restart", color = Color(IdeTheme.ACCENT), fontSize = 10.sp,
                    modifier = Modifier.clickable { confirmRestart = true }.padding(horizontal = 6.dp, vertical = 4.dp))
            }
        }

        Box(Modifier.fillMaxWidth().weight(1f)) {
            tabs.forEach { tab ->
                val active = visible && tab.id == selectedId
                key(tab.id, tab.revision) {
                    Box(
                        Modifier.fillMaxSize()
                            .offset { IntOffset(0, if (active) 0 else 100000) }
                    ) {
                        TerminalScreen(
                            root = root,
                            bridge = if (active) bridge else null,
                            showTopBar = false,
                            visible = active,
                            autoActivate = autoActivate,
                            workDir = workDir,
                            showKeyboardToggle = false,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }
    }
    if (confirmRestart) {
        IdeAlertDialog(
            onDismissRequest = { confirmRestart = false },
            title = { Text("Restart terminal?") },
            text = { Text("The current shell process and its visible transcript will be cleared. Files and installed Ubuntu packages will not be affected.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmRestart = false
                    val index = tabs.indexOfFirst { it.id == selectedId }
                    if (index >= 0) tabs[index] = tabs[index].copy(revision = tabs[index].revision + 1)
                }) { Text("Restart") }
            },
            dismissButton = { TextButton(onClick = { confirmRestart = false }) { Text("Cancel") } },
            containerColor = Color(IdeTheme.PANEL),
            titleContentColor = Color(IdeTheme.TEXT),
            textContentColor = Color(IdeTheme.DIM)
        )
    }
}
