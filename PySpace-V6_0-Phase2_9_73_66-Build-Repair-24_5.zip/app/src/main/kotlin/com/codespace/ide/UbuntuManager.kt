package com.codespace.ide

import android.content.Context
import android.os.SystemClock
import com.codespace.ide.ide.projects.LEGACY_WORKSPACE_DIR_NAME
import com.codespace.ide.ide.projects.WORKSPACE_DIR_NAME
import com.codespace.ide.runtime.RuntimeAssetCipher
import com.codespace.ide.runtime.RuntimeDispatchers
import kotlinx.coroutines.withContext
import org.tukaani.xz.XZInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.FilterInputStream
import java.nio.charset.StandardCharsets
import java.util.zip.ZipFile

class UbuntuManager(
    private val context: Context,
    private val dispatchers: RuntimeDispatchers = RuntimeDispatchers.Default,
) {
    val rootfsDir: File
        get() = File(context.filesDir, "ubuntu-rootfs")

    private val archiveName = "runtime/system.psr"
    private val marker = File(rootfsDir, ".pyspace_ready")

    companion object {
        /**
         * Runtime content version. Bump when the bundled rootfs gains
         * tooling (python/pip/venv, …): devices installed from an older
         * asset keep their old marker, fail this check, and are routed
         * back to the installer instead of running forever without pip.
         */
        const val RUNTIME_VERSION = "pyspace-runtime-v2"

        /**
         * Shell twin of [applyPythonLayoutFix] for live (already installed)
         * devices: run via runOnce, then verify with `pip --version`.
         */
        fun pythonLayoutFixScript(): String {
            return "mkdir -p /usr/local/lib/python3.12/dist-packages; " +
                "for p in /usr/local/lib/python3.12/site-packages/pip " +
                "/usr/local/lib/python3.12/site-packages/pip-*.dist-info; do " +
                "b=\$(basename \"\$p\"); " +
                "if [ -e \"\$p\" ] && [ ! -e /usr/local/lib/python3.12/dist-packages/\"\$b\" ]; then " +
                "ln -s \"\$p\" /usr/local/lib/python3.12/dist-packages/\"\$b\"; fi; done; " +
                "if [ -e /usr/local/lib/python3.12/ensurepip ] && " +
                "[ ! -e /usr/lib/python3.12/ensurepip ]; then " +
                "ln -s /usr/local/lib/python3.12/ensurepip /usr/lib/python3.12/ensurepip; fi; " +
                "python3 -c \"import pip, ensurepip, venv; print('py-stack-ok')\" 2>&1"
        }
    }

    /**
     * The bundled image lays the Python stack out upstream-style
     * (site-packages + a stray ensurepip dir), but its interpreter is the
     * Ubuntu build, which only searches Debian locations (dist-packages +
     * stdlib). Result: 944 pip files present yet unimportable, and venv
     * creation broken. Symlinking both layouts covers either interpreter
     * without moving (or risking) a single byte. Idempotent: safe to rerun.
     */
    private fun applyPythonLayoutFix(root: File) {
        try {
            val dist = File(root, "usr/local/lib/python3.12/dist-packages")
            dist.mkdirs()
            val site = File(root, "usr/local/lib/python3.12/site-packages")
            val cands = mutableListOf(File(site, "pip"))
            try {
                site.listFiles()
                    ?.filter { it.name.startsWith("pip-") && it.name.endsWith(".dist-info") }
                    ?.let { cands.addAll(it) }
            } catch (_: Exception) {
            }
            // NOTE: link targets are GUEST paths (the rootfs is mounted at
            // / for PRoot); host absolute paths would dangle in the guest.
            val rootPath = root.canonicalPath
            fun guestLink(src: File, dst: File) {
                val rel = try {
                    src.canonicalPath.removePrefix("$rootPath/")
                } catch (_: Exception) {
                    return
                }
                android.system.Os.symlink("/$rel", dst.absolutePath)
            }
            for (src in cands) {
                try {
                    if (!src.exists()) continue
                    val dst = File(dist, src.name)
                    if (dst.exists() || isSymlink(dst)) continue
                    guestLink(src, dst)
                } catch (_: Exception) {
                }
            }
            try {
                val src = File(root, "usr/local/lib/python3.12/ensurepip")
                val dst = File(root, "usr/lib/python3.12/ensurepip")
                if (src.exists() && !dst.exists() && !isSymlink(dst)) {
                    guestLink(src, dst)
                }
            } catch (_: Exception) {
            }
        } catch (_: Exception) {
        }
    }

    private fun isSymlink(f: File): Boolean {
        return try {
            java.nio.file.Files.isSymbolicLink(f.toPath())
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Ubuntu's /etc/bash.bashrc sudo-hint probes `$(groups)`; the Android
     * process GIDs (inet 3003, every_app 9997, per-app 2xxxx/5xxxx) have
     * no names in the guest's /etc/group, so groups(1) leaks one
     * "cannot find name for group ID" line per GID onto every new shell —
     * four junk lines above the first prompt. The substitution only
     * reads stdout; silence stderr. Idempotent (the patched form no
     * longer matches the pattern). Called from install() for fresh
     * rootfses and on startup for live installs, since the tarball
     * overwrites the file on every update.
     */
    fun suppressGroupNoise() {
        try {
            val f = File(rootfsDir, "etc/bash.bashrc")
            if (!f.isFile) return
            val text = f.readText()
            val patched = text.replace(
                "\$(groups)",
                "\$(groups 2>/dev/null)"
            )
            if (patched != text) f.writeText(patched)
        } catch (_: Exception) {
        }
    }

    fun isInstalled(): Boolean {
        if (!marker.isFile || !File(rootfsDir, "bin").isDirectory) return false
        return try {
            marker.readText().trim() == RUNTIME_VERSION
        } catch (_: Exception) {
            false
        }
    }

    /** True when a rootfs exists but predates the current runtime. */
    fun needsUpdate(): Boolean {
        return rootfsDir.exists() && !isInstalled()
    }

    suspend fun install(onProgress: (String) -> Unit) = withContext(dispatchers.io) {
        if (isInstalled()) {
            onProgress("Python runtime is already installed.")
            return@withContext
        }

        onProgress("@progress:0.01|Checking installation package|")
        val temp = File(context.filesDir, "ubuntu-rootfs.installing")
        if (temp.exists()) temp.deleteRecursively()
        temp.mkdirs()

        val assetDescriptor = try { context.assets.openFd(archiveName) } catch (_: Exception) { null }
        var apkZip: ZipFile? = null
        var totalCompressedBytes = assetDescriptor?.length ?: -1L
        val raw = if (assetDescriptor != null) {
            assetDescriptor.createInputStream()
        } else {
            // openFd is unavailable for APK-compressed assets. Read the exact
            // asset entry from the APK so its uncompressed entry size can still
            // drive a real percentage and ETA during XZ extraction.
            try {
                apkZip = ZipFile(context.applicationInfo.sourceDir)
                val entry = apkZip?.getEntry("assets/$archiveName")
                if (entry != null && entry.size > 0L) {
                    totalCompressedBytes = entry.size
                    apkZip!!.getInputStream(entry)
                } else {
                    apkZip?.close()
                    apkZip = null
                    context.assets.open(archiveName)
                }
            } catch (_: Exception) {
                try { apkZip?.close() } catch (_: Exception) { }
                apkZip = null
                context.assets.open(archiveName)
            }
        }
        val startedAt = SystemClock.elapsedRealtime()
        var lastProgressAt = 0L
        var lastProgressBytes = 0L
        var compressedBytes = 0L
        val counted = object : FilterInputStream(raw) {
            private fun report(read: Int) {
                if (read <= 0) return
                compressedBytes += read
                val now = SystemClock.elapsedRealtime()
                if (totalCompressedBytes > 0 && (now - lastProgressAt >= 700L || compressedBytes - lastProgressBytes >= 1024L * 1024L)) {
                    val fraction = (compressedBytes.toDouble() / totalCompressedBytes.toDouble()).toFloat().coerceIn(0f, 0.88f)
                    val elapsed = (now - startedAt).coerceAtLeast(1L)
                    val eta = if (fraction > 0.01f) ((elapsed * (1f - fraction) / fraction) / 1000f).toLong().coerceAtLeast(0L) else -1L
                    onProgress("@progress:$fraction|Unpacking Python runtime|$eta")
                    lastProgressAt = now
                    lastProgressBytes = compressedBytes
                }
            }
            override fun read(): Int {
                val value = super.read()
                if (value >= 0) report(1)
                return value
            }
            override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
                val count = super.read(buffer, offset, length)
                report(count)
                return count
            }
        }
        try {
            XZInputStream(BufferedInputStream(RuntimeAssetCipher.decrypt(counted), 64 * 1024)).use { xz ->
                extractTar(xz, temp, onProgress)
            }
        } finally {
            try { assetDescriptor?.close() } catch (_: Exception) { }
            try { apkZip?.close() } catch (_: Exception) { }
        }
        onProgress("@progress:0.89|Finalizing Python runtime|")
        File(temp, ".pyspace_ready").writeText("$RUNTIME_VERSION\n")
        // Preserve user projects across reinstall/upgrade: the workspace
        // lives inside the rootfs, which is otherwise fully replaced. Reads
        // the current location (/files/projects) first, then the older
        // root/projects and root/pyspace layouts; restores under the
        // current location (completing any pending migration).
        val keepSrc = listOf(
            File(rootfsDir, "files/$WORKSPACE_DIR_NAME"),
            File(rootfsDir, "root/$WORKSPACE_DIR_NAME"),
            File(rootfsDir, "root/$LEGACY_WORKSPACE_DIR_NAME")
        ).firstOrNull { it.isDirectory }
        val stash = File(context.filesDir, "workspace.keep")
        var stashed = false
        try {
            if (keepSrc != null) {
                if (stash.exists()) stash.deleteRecursively()
                if (keepSrc.renameTo(stash)) {
                    stashed = true
                } else {
                    copyRecursively(keepSrc, stash)
                    stashed = stash.isDirectory
                }
            }
        } catch (_: Exception) {
        }
        // User-selected portable Python versions are app-managed tools, not
        // disposable Ubuntu system packages. Keep them across a rootfs repair
        // or runtime refresh just like project files.
        val pythonRuntimesSrc = File(rootfsDir, "opt/pyspace-python")
        val pythonRuntimesStash = File(context.filesDir, "python-runtimes.keep")
        var pythonRuntimesStashed = false
        try {
            if (pythonRuntimesSrc.isDirectory) {
                if (pythonRuntimesStash.exists()) pythonRuntimesStash.deleteRecursively()
                if (pythonRuntimesSrc.renameTo(pythonRuntimesStash)) {
                    pythonRuntimesStashed = true
                } else {
                    copyRecursively(pythonRuntimesSrc, pythonRuntimesStash)
                    pythonRuntimesStashed = pythonRuntimesStash.isDirectory
                }
            } else if (pythonRuntimesStash.isDirectory) {
                // Recover a previous stash left behind by an interrupted refresh.
                pythonRuntimesStashed = true
            }
        } catch (_: Exception) {
        }
        if (rootfsDir.exists()) rootfsDir.deleteRecursively()
        if (!temp.renameTo(rootfsDir)) {
            copyRecursively(temp, rootfsDir)
            temp.deleteRecursively()
        }
        // Fresh installs need the Debian python layout too (not just
        // repaired devices): make the bundled pip/ensurepip importable.
        applyPythonLayoutFix(rootfsDir)
        // Fresh image carries Ubuntu's stock sudo-hint probe; silence the
        // group-name stderr noise it would leak on Android GIDs.
        suppressGroupNoise()
        onProgress("@progress:0.91|Restoring your projects|")
        if (stashed) {
            try {
                val back = File(rootfsDir, "files/$WORKSPACE_DIR_NAME")
                back.parentFile?.mkdirs()
                if (back.exists()) back.deleteRecursively()
                if (!stash.renameTo(back)) {
                    copyRecursively(stash, back)
                    stash.deleteRecursively()
                }
            } catch (_: Exception) {
            }
        }
        if (pythonRuntimesStashed) {
            try {
                val back = File(rootfsDir, "opt/pyspace-python")
                back.parentFile?.mkdirs()
                if (back.exists()) back.deleteRecursively()
                if (!pythonRuntimesStash.renameTo(back)) {
                    copyRecursively(pythonRuntimesStash, back)
                    pythonRuntimesStash.deleteRecursively()
                }
            } catch (_: Exception) {
            }
        }
        onProgress("@progress:0.92|Python runtime extracted|")
        onProgress("Python runtime extraction complete.")
    }

    /**
     * Rebuilds the bundled base image in a staging directory. The current
     * installation is never deleted until the new image has been extracted
     * and passed structural validation. A previous image is retained until
     * the caller has completed a post-restore health check.
     */
    suspend fun restoreClean(onProgress: (String) -> Unit) = withContext(dispatchers.io) {
        val staging = File(context.filesDir, "system-files.staging")
        val previous = File(context.filesDir, "system-files.previous")
        val runtimesStash = File(context.filesDir, "python-runtimes.recovery")
        onProgress("Preparing a clean system image…")
        if (staging.exists()) staging.deleteRecursively()
        if (!staging.mkdirs()) error("Cannot create recovery staging directory.")
        try {
            onProgress("Extracting bundled system files…")
            RuntimeAssetCipher.openAsset(context, archiveName).use { input ->
                XZInputStream(BufferedInputStream(input, 64 * 1024)).use { xz ->
                    extractTar(xz, staging, onProgress)
                }
            }
            onProgress("Validating extracted system…")
            require(File(staging, "bin").isDirectory) { "System validation failed: /bin is missing." }
            require(File(staging, "etc/os-release").isFile) { "System validation failed: /etc/os-release is missing." }
            require(File(staging, "usr/bin/python3.12").exists() || File(staging, "usr/bin/python3").exists()) {
                "System validation failed: Python interpreter is missing."
            }
            // Preserve Python versions explicitly installed through PySpace.
            val oldRuntimes = File(rootfsDir, "opt/pyspace-python")
            if (oldRuntimes.isDirectory) {
                if (runtimesStash.exists()) runtimesStash.deleteRecursively()
                copyRecursively(oldRuntimes, runtimesStash)
                val newRuntimes = File(staging, "opt/pyspace-python")
                if (newRuntimes.exists()) newRuntimes.deleteRecursively()
                copyRecursively(runtimesStash, newRuntimes)
            }
            applyPythonLayoutFix(staging)
            File(staging, ".pyspace_ready").writeText("$RUNTIME_VERSION\n")
            onProgress("Switching system image safely…")
            if (previous.exists()) previous.deleteRecursively()
            val hadCurrent = rootfsDir.exists()
            if (hadCurrent && !rootfsDir.renameTo(previous)) {
                error("Could not preserve the current system for rollback.")
            }
            if (!staging.renameTo(rootfsDir)) {
                if (hadCurrent) previous.renameTo(rootfsDir)
                error("Could not activate the recovered system. The previous system was restored.")
            }
            try {
                suppressGroupNoise()
                require(isInstalled()) { "The recovered system marker could not be verified." }
            } catch (t: Throwable) {
                rootfsDir.deleteRecursively()
                if (hadCurrent && !previous.renameTo(rootfsDir)) {
                    error("Recovery failed and automatic rollback could not complete. Previous image is retained at ${previous.absolutePath}.")
                }
                throw t
            }
            if (runtimesStash.exists()) runtimesStash.deleteRecursively()
            onProgress("Clean system image installed. Previous image retained for safety.")
        } catch (t: Throwable) {
            if (staging.exists()) staging.deleteRecursively()
            if (runtimesStash.exists()) runtimesStash.deleteRecursively()
            throw t
        }
    }

    /** Restore the retained pre-recovery image if the post-install check fails. */
    suspend fun rollbackRecovery() = withContext(dispatchers.io) {
        val previous = File(context.filesDir, "system-files.previous")
        val failed = File(context.filesDir, "system-files.failed")
        require(previous.isDirectory) { "No previous system backup is available." }
        if (failed.exists()) failed.deleteRecursively()
        if (rootfsDir.exists() && !rootfsDir.renameTo(failed)) {
            error("Could not move the newly installed system aside.")
        }
        if (!previous.renameTo(rootfsDir)) {
            if (failed.exists()) failed.renameTo(rootfsDir)
            error("Could not restore the previous system. The new image was put back.")
        }
        failed.deleteRecursively()
    }

    /** Call only after a successful post-restore launch and health check. */
    suspend fun finalizeRecovery() = withContext(dispatchers.io) {
        val previous = File(context.filesDir, "system-files.previous")
        if (previous.exists()) previous.deleteRecursively()
    }

    private fun extractTar(input: InputStream, dest: File, onProgress: (String) -> Unit) {
        val header = ByteArray(512)
        var files = 0
        var pendingLongName: String? = null
        var pendingLongLink: String? = null

        while (true) {
            readFully(input, header)
            if (header.all { it.toInt() == 0 }) break

            val rawName = tarString(header, 0, 100)
            val prefix = tarString(header, 345, 155)
            val headerPath = if (prefix.isNotEmpty()) "$prefix/$rawName" else rawName
            val mode = tarOctal(header, 100)
            val size = tarOctal(header, 124)
            val type = header[156].toInt().toChar()
            val rawLinkName = tarString(header, 157, 100)

            // GNU tar stores names/links longer than 100 bytes in special metadata
            // records immediately before the real entry. Preserve those values for
            // the next header instead of extracting the metadata as a normal file.
            if (type == 'L' || type == 'K') {
                val data = ByteArray(size.toInt())
                readFully(input, data)
                val value = String(data, StandardCharsets.UTF_8).trimEnd('\u0000', '\n')
                if (type == 'L') pendingLongName = value
                else pendingLongLink = value

                val padding = (512 - (size % 512)) % 512
                if (padding > 0) skipExactly(input, padding)
                continue
            }

            val path = pendingLongName ?: headerPath
            val linkName = pendingLongLink ?: rawLinkName
            pendingLongName = null
            pendingLongLink = null

            val out = safeResolve(dest, path)
            when (type) {
                '5', '\u0000' -> {
                    if (type == '\u0000' && size > 0) {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { copyExactly(input, it, size) }
                        applyMode(out, mode)
                    } else {
                        out.mkdirs()
                        applyMode(out, mode)
                    }
                }
                '0' -> {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { copyExactly(input, it, size) }
                    applyMode(out, mode)
                }
                '2' -> {
                    out.parentFile?.mkdirs()
                    // Remove any previous file/symlink (incl. broken symlink).
                    if (out.exists() || out.isSymbolicLinkCompat()) {
                        try {
                            out.delete()
                        } catch (_: Exception) {
                            android.system.Os.remove(out.absolutePath)
                        }
                    }
                    // If parent was a symlink to a dir, mkdirs above is a no-op — ok.
                    try {
                        android.system.Os.symlink(linkName, out.absolutePath)
                    } catch (e: android.system.ErrnoException) {
                        // EEXIST race: force remove once and retry.
                        try {
                            android.system.Os.remove(out.absolutePath)
                        } catch (_: Exception) { }
                        android.system.Os.symlink(linkName, out.absolutePath)
                    }
                }
                '1' -> {
                    out.parentFile?.mkdirs()
                    val target = safeResolve(dest, linkName)
                    if (target.isFile) {
                        FileOutputStream(out).use { target.inputStream().copyTo(it) }
                        applyMode(out, mode)
                    }
                }
                else -> {
                    skipExactly(input, size)
                }
            }

            val padding = (512 - (size % 512)) % 512
            if (padding > 0) skipExactly(input, padding)

            files++
            if (files % 250 == 0) onProgress("Unpacking runtime files… $files")
        }
    }

    private fun safeResolve(root: File, relative: String): File {
        // GNU tar archives commonly contain a first entry for the root directory ("./").
        // After removing the leading "./", that entry becomes empty and must resolve to
        // the extraction root itself rather than being rejected.
        val clean = relative.removePrefix("./").trimStart('/')
        val result = if (clean.isEmpty()) root else File(root, clean)
        val rootPath = root.canonicalPath
        val resultPath = result.canonicalPath
        require(resultPath == rootPath || resultPath.startsWith("$rootPath${File.separator}")) {
            "Unsafe tar path: $relative"
        }
        return result
    }

    private fun tarString(buf: ByteArray, off: Int, len: Int): String {
        var end = off
        val max = off + len
        while (end < max && buf[end].toInt() != 0) end++
        return String(buf, off, end - off, StandardCharsets.UTF_8).trim()
    }

    private fun tarOctal(buf: ByteArray, off: Int): Long {
        var i = off
        var value = 0L
        while (i < off + 12 && (buf[i] == 0.toByte() || buf[i] == ' '.code.toByte())) i++
        while (i < off + 12) {
            val c = buf[i].toInt()
            if (c !in '0'.code..'7'.code) break
            value = (value shl 3) + (c - '0'.code)
            i++
        }
        return value
    }

    private fun readFully(input: InputStream, buf: ByteArray) {
        var pos = 0
        while (pos < buf.size) {
            val n = input.read(buf, pos, buf.size - pos)
            if (n < 0) throw IllegalStateException("Unexpected end of tar archive")
            pos += n
        }
    }

    private fun copyExactly(input: InputStream, out: FileOutputStream, size: Long) {
        var left = size
        val buffer = ByteArray(64 * 1024)
        while (left > 0) {
            val n = input.read(buffer, 0, minOf(buffer.size.toLong(), left).toInt())
            if (n < 0) throw IllegalStateException("Unexpected end of tar file")
            out.write(buffer, 0, n)
            left -= n
        }
    }

    private fun skipExactly(input: InputStream, size: Long) {
        var left = size
        while (left > 0) {
            val n = input.skip(left)
            if (n > 0) {
                left -= n
            } else {
                if (input.read() < 0) throw IllegalStateException("Unexpected end of tar file")
                left--
            }
        }
    }

    private fun applyMode(file: File, mode: Long) {
        val executable = (mode and 0b001001001L) != 0L
        if (executable) file.setExecutable(true, false)
        file.setReadable(true, false)
        if (!file.isDirectory) file.setWritable(true, true)
    }

    private fun copyRecursively(from: File, to: File) {
        if (from.isDirectory) {
            to.mkdirs()
            from.listFiles()?.forEach { copyRecursively(it, File(to, it.name)) }
        } else {
            to.parentFile?.mkdirs()
            from.copyTo(to, overwrite = true)
        }
    }

    private fun File.isSymbolicLinkCompat(): Boolean {
        // BUGFIX: old version always returned false, so broken symlinks were
        // never deleted before Os.symlink() -> EEXIST failure on re-install.
        try {
            val st = android.system.Os.lstat(absolutePath)
            if ((st.st_mode and android.system.OsConstants.S_IFMT) ==
                android.system.OsConstants.S_IFLNK
            ) {
                return true
            }
        } catch (_: Exception) {
            // lstat throws ENOENT when path does not exist at all.
        }
        // Fallback via NIO (handles edge cases on newer Android runtimes).
        return try {
            java.nio.file.Files.isSymbolicLink(toPath())
        } catch (_: Exception) {
            false
        }
    }
}
