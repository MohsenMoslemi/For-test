package com.codespace.ide.ide.shell

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.codespace.ide.ide.RunInfo
import com.codespace.ide.ide.camera.PhoneCamera
import com.codespace.ide.ide.run.RunOrchestrator
import com.codespace.ide.ide.runtimeui.RuntimeUiViewModel

/** Owns the lifecycle of guest processes started from interactive Terminal tabs. */
internal class TerminalRunLifecycleCoordinator(
    private val runOrchestrator: RunOrchestrator,
    private val runTaskScope: CoroutineScope,
    private val isConsoleLive: () -> Boolean,
    private val isConsoleRunning: () -> Boolean,
    private val stopConsole: () -> Unit,
    private val displayOwner: () -> String?,
    private val clearDisplayOwner: () -> Unit,
    private val frameMode: () -> Boolean,
    private val ideScope: CoroutineScope,
    private val runtimeUiViewModel: RuntimeUiViewModel,
    private val phoneCamera: PhoneCamera,
) {
    fun killRunGroup(info: RunInfo) {
        runOrchestrator.stopTerminal(info, runTaskScope)
    }

    fun stopRun(info: RunInfo) {
        if (info.source == "Console") stopConsole() else killRunGroup(info)
    }

    fun stopAllRuns() {
        if (isConsoleLive() && isConsoleRunning()) stopConsole()
        runOrchestrator.stopAllTerminal(runTaskScope)
    }

    /** Called when the guest helper reports completion or its process disappears. */
    fun endTerminalRun(id: String) {
        val info = runOrchestrator.get(id) ?: return
        if (!info.running) return
        runOrchestrator.finish(id)
        if (displayOwner() == id) {
            clearDisplayOwner()
            if (!frameMode()) {
                ideScope.launch {
                    delay(1500)
                    if (runOrchestrator.running().none { it.usesDisplay }) {
                        runtimeUiViewModel.setDisplayOpen(false)
                    }
                }
            }
        }
        try {
            phoneCamera.stopRun("Run ended — camera released.")
        } catch (_: Exception) {
        }
    }
}
