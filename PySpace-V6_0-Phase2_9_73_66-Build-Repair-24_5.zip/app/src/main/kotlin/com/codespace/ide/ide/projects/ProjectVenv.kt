package com.codespace.ide.ide.projects

import java.io.File

/** Effective venv dir name: saved choice, else detected (.venv/venv), else default. */
fun projectVenvName(dir: File): String {
    try {
        val saved = File(dir, ".pyspace_venv").takeIf { it.isFile }?.readText()?.trim()
        if (!saved.isNullOrEmpty()) return saved
    } catch (_: Exception) {
    }
    for (cand in listOf(".venv", "venv", "env")) {
        try {
            // pyvenv.cfg / activate are real files; bin/python is a symlink to a GUEST path and so
            // looks "missing" from the Android side (that made a venv called "venv" invisible).
            if (venvPythonReady(dir, cand) || File(File(dir, cand), "bin/python").isFile) return cand
        } catch (_: Exception) {
        }
    }
    return ".venv"
}

/**
 * Host-side existence that is honest about guest-absolute symlinks: a venv's
 * bin/python links to /usr/bin/python3, which dangles on the HOST (it only
 * resolves inside the guest) — so isFile() lies. A symlink that exists at
 * all still proves the entry is really there.
 */
fun guestAwareExists(f: File): Boolean {
    if (f.exists()) return true
    return try {
        java.nio.file.Files.isSymbolicLink(f.toPath())
    } catch (_: Exception) {
        false
    }
}

fun venvPythonReady(dir: File, venv: String = projectVenvName(dir)): Boolean {
    return try {
        // pyvenv.cfg / activate are REAL files (never guest-absolute
        // symlinks), so the host can trust them — unlike bin/python.
        val vd = File(dir, venv)
        File(vd, "pyvenv.cfg").isFile || File(vd, "bin/activate").isFile
    } catch (_: Exception) {
        false
    }
}

/**
 * Shell prefix that activates the project venv when it is a real
 * virtualenv, else empty (system python3). For runOnce (sh) and the
 * interactive shell alike: `. ./.venv/bin/activate && ...`.
 */
fun venvPrefix(dir: File): String {
    val v = projectVenvName(dir)
    return if (venvPythonReady(dir, v)) ". ./$v/bin/activate && " else ""
}

/** Pip binary: venv's when real, else system pip. */
fun pipBin(dir: File): String {
    val v = projectVenvName(dir)
    return try {
        val p = File(File(dir, v), "bin/pip")
        if (guestAwareExists(p)) "./$v/bin/pip" else "pip"
    } catch (_: Exception) {
        "pip"
    }
}

/** Python binary: project venv when built, otherwise the project's selected base interpreter. */
fun projectPythonBin(dir: File): String {
    val v = projectVenvName(dir)
    return try {
        val p = File(File(dir, v), "bin/python")
        if (guestAwareExists(p)) "./$v/bin/python" else projectPythonInterpreterGuestPath(dir)
    } catch (_: Exception) {
        projectPythonInterpreterGuestPath(dir)
    }
}


/**
 * Guest path of the project venv for shell activation
 * (`/files/projects/<proj>/<venv>`), or null when no real venv exists yet.
 */
fun projectVenvGuestPath(dir: File): String? {
    return try {
        if (!venvPythonReady(dir)) null
        else {
            val ws = dir.parentFile?.name?.takeIf { it.isNotBlank() } ?: WORKSPACE_DIR_NAME
            "/files/$ws/${dir.name}/${projectVenvName(dir)}"
        }
    } catch (_: Exception) {
        null
    }
}
