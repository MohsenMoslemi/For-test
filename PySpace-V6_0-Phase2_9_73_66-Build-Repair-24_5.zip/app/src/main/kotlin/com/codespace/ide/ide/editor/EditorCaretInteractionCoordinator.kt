package com.codespace.ide.ide.editor

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * Coordinates caret-driven viewport movement without owning editor state.
 * The snapshot provider is intentionally live: long-running scroll jobs always
 * observe the latest layout, selection, folded document and viewport geometry.
 */
internal class EditorCaretInteractionCoordinator(
    private val scope: CoroutineScope,
    private val snapshot: () -> EditorCaretNavigationSnapshot,
    private val onReport: (Int, Int) -> Unit
) {
    suspend fun reveal(line: Int, column: Int, center: Boolean = false) {
        EditorCaretNavigation.reveal(snapshot(), line, center)
    }

    suspend fun center() {
        EditorCaretNavigation.center(snapshot())
    }

    fun ensureVisible(line: Int, column: Int, center: Boolean = false) {
        scope.launch { reveal(line, column, center) }
    }

    fun report(
        line: Int,
        column: Int,
        center: Boolean = false,
        reveal: Boolean = true
    ) {
        onReport(line, column)
        if (reveal) ensureVisible(line, column, center)
    }
}
