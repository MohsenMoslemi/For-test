package com.codespace.ide

/**
 * JNI bridge to the prebuilt native PTY layer (libptybridge.so, shipped in
 * app/src/main/jniLibs/arm64-v8a/ like the prebuilt PRoot runtime).
 *
 * Native sources live in <project>/native/pty_bridge.c (outside src/main so
 * the CodeAssist builder ignores them); the .so needs no build-system
 * changes because the jniLibs source set already packages it.
 *
 * All calls are blocking and thread-safe; call off the main thread.
 * Failures are never silent: open() returns null and lastError() explains.
 */
internal object PtyNative {

    init {
        try {
            System.loadLibrary("ptybridge")
        } catch (t: UnsatisfiedLinkError) {
            throw UnsatisfiedLinkError(
                "PTY native library (libptybridge.so) failed to load: " +
                    (t.message ?: "unknown error")
            )
        }
    }

    /**
     * Spawns argv/envp attached to a fresh PTY (see pty_bridge.c).
     * @return intArrayOf(masterFd, childPid) or null on failure.
     */
    external fun open(
        argv: Array<String>,
        envp: Array<String>,
        rows: Int,
        cols: Int
    ): IntArray?

    /**
     * Reads from the PTY master.
     * @return bytes read (>0), 0 = no data yet (keep looping), -1 = EOF/error.
     */
    external fun readFd(fd: Int, buf: ByteArray, len: Int): Int

    /** Writes the full buffer; returns bytes written or -1 on error. */
    external fun writeFd(fd: Int, buf: ByteArray, len: Int): Int

    /** Applies TIOCSWINSZ; returns 0 on success, -1 on error. */
    external fun setWinSize(fd: Int, rows: Int, cols: Int): Int

    /** Blocking waitpid; returns exit code (or 128+signal), -1 on error. */
    external fun waitPid(pid: Int): Int

    external fun closeFd(fd: Int): Int

    external fun killPid(pid: Int, sig: Int): Int

    /**
     * Signals a whole process group (negative-pid kill). Our spawned child
     * setsid()s, so its PID is its PGID: this reaches PRoot, python, uvicorn
     * workers, everything. Stopping a server MUST use this — killPid alone
     * orphans the server and leaves its port bound. Returns 0 / -1.
     */
    external fun killProcessGroup(pgid: Int, sig: Int): Int

    /** True while the child exists (kill(pid, 0) probe). */
    external fun alive(pid: Int): Boolean

    /** Human-readable message for the last native failure. */
    external fun lastError(): String
}
