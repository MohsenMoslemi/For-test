package com.codespace.ide.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import com.codespace.ide.MainActivity
import com.codespace.ide.R
import com.codespace.ide.ide.RunHub
import com.codespace.ide.ide.RunInfo
import com.codespace.ide.ide.run.RunOrchestrator
import com.codespace.ide.runtime.RuntimeTaskScope
import org.koin.core.context.GlobalContext

/**
 * One generic foreground service for EVERY long-running thing the IDE starts
 * (Flask/Django/FastAPI/Streamlit servers, plain scripts, GUI/display runs...).
 * It is project-agnostic: it only watches [RunHub], so future run types get the
 * same background protection and notification for free.
 *
 * The service shares the app process: its job is to keep that process (and the
 * PRoot/Python children living in it) alive while the user switches apps, and to
 * show an ongoing notification. Stopping happens automatically when RunHub is empty.
 */
class RunForegroundService : Service() {
    private val hub: RunHub by lazy { GlobalContext.get().get<RunHub>() }
    private val runOrchestrator: RunOrchestrator by lazy { GlobalContext.get().get<RunOrchestrator>() }
    private val runtimeTaskScope: RuntimeTaskScope by lazy { GlobalContext.get().get<RuntimeTaskScope>() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onDestroy() {
        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_ALL -> {
                if (!hub.requestStopAll()) {
                    runOrchestrator.stopAllWithoutUi(runtimeTaskScope.scope)
                }
                if (hub.running().isEmpty()) {
                    stopSelf()
                    return START_NOT_STICKY
                }
            }
            ACTION_UPDATE -> Unit
        }
        if (!refresh()) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    /** Returns false when there is nothing left to keep alive. */
    private fun refresh(): Boolean {
        val runs = hub.running()
        if (runs.isEmpty()) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            return false
        }
        val notification = buildNotification(runs)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        return true
    }

    private fun buildNotification(runs: List<RunInfo>): Notification {
        val title = if (runs.size == 1) {
            getString(R.string.run_notification_one)
        } else {
            getString(R.string.run_notification_many, runs.size)
        }
        val summary = runs.take(3).joinToString(" · ") { it.title }
        val details = runs.joinToString("\n") { "• " + it.title + (it.webUrl?.let { u -> "  ($u)" } ?: "") }
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            ),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopAll = PendingIntent.getService(
            this,
            1,
            Intent(this, RunForegroundService::class.java).setAction(ACTION_STOP_ALL),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle(title)
            .setContentText(summary)
            .setStyle(Notification.BigTextStyle().bigText(details))
            .setContentIntent(open)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_delete),
                    getString(R.string.run_notification_stop_all),
                    stopAll
                ).build()
            )
            .build()
    }

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java) ?: return
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.run_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.run_channel_desc)
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    companion object {
        const val ACTION_UPDATE = "com.codespace.ide.action.RUN_UPDATE"
        const val ACTION_STOP_ALL = "com.codespace.ide.action.RUN_STOP_ALL"
        private const val CHANNEL_ID = "ide_running_runs"
        private const val NOTIFICATION_ID = 4101
    }
}
