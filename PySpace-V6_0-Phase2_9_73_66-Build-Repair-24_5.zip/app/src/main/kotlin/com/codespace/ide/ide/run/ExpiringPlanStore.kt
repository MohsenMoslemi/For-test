package com.codespace.ide.ide.run

/**
 * Small, thread-safe handoff store for plans created by an asynchronous prepare
 * callback and consumed by a later start callback.
 *
 * Entries are one-shot, expire after [ttlMillis], and the store has a hard size
 * limit so abandoned guest preparations cannot retain project/UI objects forever.
 * Closing the store rejects future writes and releases all retained plans.
 */
class ExpiringPlanStore<T>(
    private val ttlMillis: Long = DEFAULT_TTL_MILLIS,
    private val maxEntries: Int = DEFAULT_MAX_ENTRIES,
    private val nowMillis: () -> Long = { System.nanoTime() / 1_000_000L },
) {
    private data class Entry<T>(val value: T, val createdAt: Long)

    private val lock = Any()
    private val entries = LinkedHashMap<String, Entry<T>>()
    private var closed = false

    init {
        require(ttlMillis > 0L) { "ttlMillis must be positive" }
        require(maxEntries > 0) { "maxEntries must be positive" }
    }

    /** Returns false when the store has already been closed. */
    fun put(id: String, value: T): Boolean = synchronized(lock) {
        if (closed || id.isBlank()) return@synchronized false
        pruneExpiredLocked(nowMillis())
        entries.remove(id)
        while (entries.size >= maxEntries) {
            val oldest = entries.entries.iterator()
            if (!oldest.hasNext()) break
            oldest.next()
            oldest.remove()
        }
        entries[id] = Entry(value, nowMillis())
        true
    }

    /** Removes and returns a still-live plan. A plan can be consumed only once. */
    fun take(id: String): T? = synchronized(lock) {
        if (closed) return@synchronized null
        val now = nowMillis()
        pruneExpiredLocked(now)
        val entry = entries.remove(id) ?: return@synchronized null
        if (now - entry.createdAt >= ttlMillis) null else entry.value
    }

    /** Releases all retained plans but keeps the store available for a new host. */
    fun clear() = synchronized(lock) {
        entries.clear()
    }

    /** Permanently closes the store and releases all retained plans. */
    fun close() = synchronized(lock) {
        closed = true
        entries.clear()
    }


    private fun pruneExpiredLocked(now: Long) {
        val iterator = entries.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next().value
            if (now - entry.createdAt >= ttlMillis) iterator.remove()
        }
    }

    companion object {
        const val DEFAULT_TTL_MILLIS = 900_000L
        const val DEFAULT_MAX_ENTRIES = 64
    }
}
