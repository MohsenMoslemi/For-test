package com.codespace.ide.ide.editor

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.text.input.TextFieldValue

/** Synchronizes externally-owned document/selection changes into BasicTextField's local value. */
@Composable
fun EditorDocumentSyncEffects(
    filePath: String,
    documentText: String,
    onFieldChange: (TextFieldValue) -> Unit,
    onExternalDocumentApplied: () -> Unit,
    externalSelectionRequest: IntRange?,
    onExternalSelectionConsumed: () -> Unit,
    inputState: EditorTextInputState
) {
    LaunchedEffect(documentText, filePath) {
        if (inputState.applyDocumentText(documentText)) {
            onFieldChange(inputState.value.value)
            onExternalDocumentApplied()
        }
    }

    LaunchedEffect(externalSelectionRequest, filePath) {
        val range = externalSelectionRequest ?: return@LaunchedEffect
        if (inputState.applySelection(range)) {
            onFieldChange(inputState.value.value)
        }
        onExternalSelectionConsumed()
    }
}
