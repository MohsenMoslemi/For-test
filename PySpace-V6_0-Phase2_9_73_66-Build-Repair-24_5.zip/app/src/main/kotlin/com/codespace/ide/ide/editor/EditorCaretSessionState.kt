package com.codespace.ide.ide.editor

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Presentation-session state for caret interaction within one open editor tab.
 *
 * This holder deliberately does not own TextField selection, document text,
 * scroll state, or cursor callbacks. It groups the small set of UI flags that
 * must move together when a real caret interaction is reported, while keeping
 * the state scoped to the tab's composition identity.
 */
internal class EditorCaretSessionState(
    initialLine: Int,
    initialColumn: Int,
    initiallyInteracted: Boolean
) {
    var line by mutableStateOf(initialLine)
        private set

    var column by mutableStateOf(initialColumn)
        private set

    var hasInteracted by mutableStateOf(initiallyInteracted)
        private set

    var firstTapPending by mutableStateOf(false)

    var flashLine by mutableStateOf<Int?>(null)
        private set

    fun report(line: Int, column: Int) {
        this.line = line
        this.column = column
        hasInteracted = true
        firstTapPending = false
    }

    fun markFirstTapPending(pending: Boolean) {
        firstTapPending = pending
    }

    fun flash(line: Int?) {
        flashLine = line
    }
}
