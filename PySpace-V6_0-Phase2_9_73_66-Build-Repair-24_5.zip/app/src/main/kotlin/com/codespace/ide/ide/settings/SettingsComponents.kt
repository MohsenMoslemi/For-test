package com.codespace.ide.ide.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ide.theme.IdeTheme

@Composable
internal fun SettingsDetailHero(section: String, description: String, accent: Color) {
    val glyph = when (section) {
        "Editor" -> "✎"
        "Gestures" -> "⌁"
        "Web preview" -> "◎"
        "Display" -> "▣"
        "Environment" -> "⌘"
        "Memory & performance" -> "◉"
        "GitHub" -> "GH"
        "About" -> "ⓘ"
        else -> "P"
    }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(Color(IdeTheme.PANEL)).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(15.dp)).background(accent.copy(alpha = .15f)), contentAlignment = Alignment.Center) {
            Text(glyph, color = accent, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(section.uppercase(), color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Text(description, color = Color(IdeTheme.TEXT), fontSize = 13.sp, lineHeight = 19.sp)
        }
    }
}

@Composable
internal fun SettingsGroupLabel(title: String) {
    Text(title, color = Color(IdeTheme.DIM), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp, modifier = Modifier.padding(start = 4.dp, top = 8.dp, bottom = 1.dp))
}

@Composable
internal fun SettingsDashboardItem(title: String, glyph: String, subtitle: String, accent: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Color(IdeTheme.CARD)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(43.dp).clip(RoundedCornerShape(14.dp)).background(accent.copy(alpha = .13f)), contentAlignment = Alignment.Center) {
            Text(glyph, color = accent, fontSize = if (glyph == "Py") 14.sp else 20.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = Color(IdeTheme.TEXT), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Color(IdeTheme.DIM), fontSize = 11.sp)
        }
        Text("›", color = accent, fontSize = 25.sp)
    }
}

/** Retained for any settings sub-pages that reuse a row. */
@Composable
internal fun SettingsRow(glyph: String, tint: Long, title: String, subtitle: String, onClick: () -> Unit) {
    SettingsDashboardItem(title, glyph, subtitle, Color(tint), onClick)
}

@Composable
internal fun SettingStepper(label: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, fontSize = 13.sp, color = Color(IdeTheme.TEXT))
            Text(value, color = Color(IdeTheme.DIM), fontSize = 11.sp)
        }
        TextButton(onClick = onMinus) { Text("−", fontSize = 18.sp) }
        TextButton(onClick = onPlus) { Text("+", fontSize = 18.sp) }
    }
}

@Composable
internal fun SettingSwitch(label: String, checked: Boolean, subtitle: String? = null, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, fontSize = 13.sp, color = if (enabled) Color(IdeTheme.TEXT) else Color(IdeTheme.DIM))
            if (subtitle != null) {
                Text(subtitle, color = Color(IdeTheme.DIM), fontSize = 11.sp)
            }
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}
