package com.codespace.ide.ide.editor

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.Composable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.codespace.ide.ide.theme.IdeTheme

/**
 * Owns the editor's viewport-space surface policy: fixed gutter divider,
 * viewport measurement, axis arbitration and the shared two-axis scroll
 * surface. Gesture modifiers are injected in a fixed order so their pointer
 * coordinate space remains outside the moving scroll content.
 *
 * Document state and gesture decisions remain in PyEditor; this layer only
 * composes the stable surface interaction pipeline around its content.
 */
@Composable
internal fun Modifier.editorSurfaceInteraction(
    gutterVisible: Boolean,
    effectiveGutterPx: Float,
    onViewportSizeChanged: (IntSize) -> Unit,
    onViewportPositioned: (LayoutCoordinates) -> Unit,
    panFree: Boolean,
    axisLink: NestedScrollConnection,
    verticalScroll: ScrollState,
    horizontalScroll: ScrollState,
    wordWrap: Boolean,
    pinchZoom: @Composable (Modifier) -> Modifier,
    tapObserver: (Modifier) -> Modifier
): Modifier = this
    // The divider is drawn in viewport space, never in the scrolling sheet.
    .drawWithContent {
        drawContent()
        if (gutterVisible) {
            val width = 1.dp.toPx()
            val x = (effectiveGutterPx - width).coerceIn(0f, (size.width - width).coerceAtLeast(0f))
            drawRect(
                color = Color(com.codespace.ide.ide.theme.IdeTheme.DIM).copy(alpha = 0.45f),
                topLeft = Offset(x, 0f),
                size = Size(width, size.height)
            )
        }
    }
    .onSizeChanged(onViewportSizeChanged)
    .onGloballyPositioned(onViewportPositioned)
    // Observe taps in the same fixed viewport coordinate space captured above.
    // Keeping this before scroll/pan modifiers prevents the pointer position from
    // being interpreted in scrolled content coordinates when resolving a word.
    .then(tapObserver(Modifier))
    .then(if (!panFree) Modifier.nestedScroll(axisLink) else Modifier)
    // Must precede scroll modifiers: the custom gesture tracks the fixed viewport.
    .twoAxisPan(verticalScroll, horizontalScroll, panFree)
    .verticalScroll(verticalScroll, enabled = !panFree)
    // Horizontal panning belongs to the whole surface, not just the code row.
    .then(if (wordWrap) Modifier else Modifier.horizontalScroll(horizontalScroll, enabled = !panFree))
    .then(pinchZoom(Modifier))
