package com.codespace.ide.ide.packages

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.codespace.ide.domain.packages.InstalledPythonPackage
import com.codespace.ide.domain.packages.PackageCommandResult
import com.codespace.ide.domain.packages.PackageManagerRepository
import com.codespace.ide.domain.packages.PythonPackageSpec
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import com.codespace.ide.ide.codeintel.PythonEnvironmentRegistry
import com.codespace.ide.ide.projects.PyProject

/** Immutable presentation state for one project's pip environment. */
data class PackageManagerUiState(
    val installed: List<InstalledPythonPackage> = emptyList(),
    val packageInput: String = "",
    val isLoading: Boolean = false,
    val isBusy: Boolean = false,
    val output: String = "",
    val error: String? = null,
)

/**
 * Activity-owned ViewModel. Its work survives switching between the Home
 * Packages tab and the in-editor package sheet, both of which use the same
 * activity ViewModelStore key for a given project path.
 */
class PackageManagerViewModel(
    private val project: PyProject,
    private val repository: PackageManagerRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(PackageManagerUiState())
    val state: StateFlow<PackageManagerUiState> = _state.asStateFlow()

    init {
        refresh()
    }

    fun setPackageInput(value: String) {
        _state.value = _state.value.copy(packageInput = value, error = null)
    }

    fun refresh() {
        if (_state.value.isBusy || _state.value.isLoading) return
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            try {
                val packages = repository.listInstalled(project.dir)
                PythonEnvironmentRegistry.update(project.dir, packages.map { it.name })
                _state.value = _state.value.copy(installed = packages, isLoading = false)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                _state.value = _state.value.copy(
                    isLoading = false,
                    error = error.message ?: "Unable to load installed packages.",
                )
            }
        }
    }

    fun installInput() {
        val requirement = _state.value.packageInput.trim()
        if (!PythonPackageSpec.isSafeRequirement(requirement)) {
            _state.value = _state.value.copy(
                error = "Invalid package requirement. Use a name such as requests or numpy==2.1.0."
            )
            return
        }
        perform("Installing $requirement…", clearInputOnSuccess = true) {
            repository.install(project.dir, requirement)
        }
    }

    fun installPopular(packageName: String) {
        if (!PythonPackageSpec.isSafePackageName(packageName)) return
        perform("Installing $packageName…") { repository.install(project.dir, packageName) }
    }

    fun uninstall(packageName: String) {
        if (packageName.equals("pip", ignoreCase = true)) {
            _state.value = _state.value.copy(
                error = "pip is required by the virtual environment and cannot be removed."
            )
            return
        }
        perform("Uninstalling $packageName…") { repository.uninstall(project.dir, packageName) }
    }

    private fun perform(
        label: String,
        clearInputOnSuccess: Boolean = false,
        operation: suspend () -> PackageCommandResult,
    ) {
        if (_state.value.isBusy || _state.value.isLoading) return
        viewModelScope.launch {
            _state.value = _state.value.copy(
                isBusy = true,
                output = label,
                error = null,
            )
            try {
                val result = operation()
                _state.value = _state.value.copy(
                    output = result.output.ifBlank { if (result.success) "Operation completed." else "Operation failed." },
                    error = if (result.success) null else "pip exited with code ${result.exitCode ?: "unknown"}.",
                    packageInput = if (result.success && clearInputOnSuccess) "" else _state.value.packageInput,
                )
                if (result.success) {
                    // pip has changed site-packages: invalidate Jedi immediately,
                    // then publish the authoritative package inventory.
                    PythonEnvironmentRegistry.invalidate(project.dir)
                    val refreshed = repository.listInstalled(project.dir)
                    PythonEnvironmentRegistry.update(project.dir, refreshed.map { it.name })
                    _state.value = _state.value.copy(installed = refreshed)
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                _state.value = _state.value.copy(
                    error = error.message ?: "Package operation failed.",
                    output = error.message ?: "Package operation failed.",
                )
            } finally {
                _state.value = _state.value.copy(isBusy = false)
            }
        }
    }

    class Factory(
        private val project: PyProject,
        private val repository: PackageManagerRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (!modelClass.isAssignableFrom(PackageManagerViewModel::class.java)) {
                throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
            }
            return PackageManagerViewModel(project, repository) as T
        }
    }
}
