package com.codespace.ide.ide.github

import android.util.Base64
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeParseException
import java.nio.file.Files
import java.nio.file.FileSystems
import java.nio.file.PathMatcher
import java.nio.file.Paths
import java.util.zip.ZipInputStream
import org.json.JSONArray
import org.json.JSONObject

// Snapshot publishing: .gitignore evaluation, file collection, branch ensure and push.
// Pure I/O layer: no Compose, no UI state.

/** Never publish common credential/private-key files by default. */
internal fun isSensitiveGitPath(path: String): Boolean {
    val name = path.substringAfterLast('/').lowercase()
    return name == ".env" || (name.startsWith(".env.") && name != ".env.example") || name == ".npmrc" ||
        name == ".pyspace_venv" || name == ".pyspace_python_version" || name == ".pyspace_python_path" ||
        name == "id_rsa" || name == "id_ed25519" || name.endsWith(".pem") ||
        name.endsWith(".key") || name.endsWith(".p12") || name.endsWith(".pfx") ||
        name.endsWith(".keystore") || name.endsWith(".jks")
}

internal data class GhIgnoreRule(
    val pattern: String,
    val negated: Boolean,
    val directoryOnly: Boolean,
    val matcher: PathMatcher?
)

/** A compact .gitignore evaluator used by snapshot publishing. */
internal class GhGitIgnoreMatcher(root: File) {
    private val rules: List<GhIgnoreRule> = try {
        File(root, ".gitignore").takeIf { it.isFile }?.readLines()?.mapNotNull { raw ->
            var line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) return@mapNotNull null
            val negated = line.startsWith("!")
            if (negated) line = line.substring(1)
            line = line.removePrefix("/")
            val directoryOnly = line.endsWith("/")
            line = line.trimEnd('/')
            if (line.isBlank()) return@mapNotNull null
            val matcher = try { FileSystems.getDefault().getPathMatcher("glob:$line") } catch (_: Exception) { null }
            GhIgnoreRule(line, negated, directoryOnly, matcher)
        } ?: emptyList()
    } catch (_: Exception) { emptyList() }

    fun isIgnored(relativePath: String, isDirectory: Boolean): Boolean {
        val path = relativePath.trim('/').replace('\\', '/')
        if (path.isBlank()) return false
        var ignored = false
        for (rule in rules) {
            val parts = path.split('/').filter { it.isNotBlank() }
            val candidatePaths = if (rule.directoryOnly) {
                if (isDirectory) (1..parts.size).map { parts.take(it).joinToString("/") }
                else if (parts.size > 1) (1 until parts.size).map { parts.take(it).joinToString("/") }
                else emptyList()
            } else {
                (1..parts.size).map { parts.take(it).joinToString("/") }
            }
            val matches = candidatePaths.any { candidate ->
                val matcher = rule.matcher ?: return@any false
                try {
                    if (!rule.pattern.contains('/')) {
                        candidate.substringAfterLast('/').let { matcher.matches(Paths.get(it)) }
                    } else matcher.matches(Paths.get(candidate))
                } catch (_: Exception) { false }
            }
            if (matches) ignored = !rule.negated
        }
        return ignored
    }
}

internal data class GhFileCollection(
    val files: List<Pair<String, ByteArray>>,
    val complete: Boolean,
    val preservedDirectories: Set<String>,
    val gitIgnoreMatcher: GhGitIgnoreMatcher,
)

/** Collect project files without following managed trees or publishing secrets. */
internal fun collectPushFiles(
    root: File,
    capFiles: Int = 300,
    capBytesPerFile: Long = 5L * 1024 * 1024,
    capTotal: Long = 100L * 1024 * 1024
): GhFileCollection {
    val out = mutableListOf<Pair<String, ByteArray>>()
    val preservedDirectories = LinkedHashSet<String>()
    val ignoreMatcher = GhGitIgnoreMatcher(root)
    var total = 0L
    var complete = true
    try {
        root.walkTopDown()
            .onEnter { directory ->
                val relativeDirectory = if (directory == root) "" else root.toURI().relativize(directory.toURI()).path.trim('/')
                if (directory != root && Files.isSymbolicLink(directory.toPath())) {
                    complete = false
                    false
                } else if (relativeDirectory.isNotBlank() && ignoreMatcher.isIgnored(relativeDirectory, true)) {
                    false
                } else if (directory != root && isManagedTreeDirectory(directory)) {
                    val rel = root.toURI().relativize(directory.toURI()).path.trim('/')
                    if (rel.isNotBlank()) preservedDirectories += rel
                    false
                } else if (out.size >= capFiles) {
                    complete = false
                    false
                } else true
            }
            .forEach { file ->
                if (out.size >= capFiles) {
                    complete = false
                    return@forEach
                }
                if (Files.isSymbolicLink(file.toPath())) {
                    complete = false
                    return@forEach
                }
                if (!file.isFile) return@forEach
                val len = try { file.length() } catch (_: Exception) { -1L }
                if (len < 0 || len > capBytesPerFile || total + len > capTotal) {
                    complete = false
                    return@forEach
                }
                val rel = try {
                    root.toURI().relativize(file.toURI()).path.trim('/')
                } catch (_: Exception) { "" }
                if (rel.isEmpty()) {
                    complete = false
                    return@forEach
                }
                // Respect .gitignore before the final sensitive-file safety net.
                if (ignoreMatcher.isIgnored(rel, false)) return@forEach
                if (isSensitiveGitPath(rel)) return@forEach
                val bytes = try { file.readBytes() } catch (_: Exception) {
                    complete = false
                    return@forEach
                }
                total += bytes.size
                out.add(rel to bytes)
            }
    } catch (_: Exception) {
        complete = false
    }
    return GhFileCollection(out, complete, preservedDirectories, ignoreMatcher)
}

/** Resolve an existing branch or initialize an empty repository and create it. */
internal fun ghEnsureBranch(token: String, target: String, branch: String): Pair<String?, String?> {
    if (!isValidGitBranchName(branch)) return null to "Invalid branch name."
    val requested = ghRequest("GET", "$GH_API/repos/$target/git/ref/heads/${ghRefPath(branch)}", token)
    if (requested.code == 200) {
        val sha = try { JSONObject(requested.body).optJSONObject("object")?.optString("sha", "") ?: "" }
            catch (_: Exception) { "" }
        return if (sha.isNotBlank()) sha to null else null to "GitHub returned an invalid branch reference."
    }
    if (requested.code != 404) return null to ghErr(requested)

    val repoResponse = ghRequest("GET", "$GH_API/repos/$target", token)
    if (repoResponse.code != 200) return null to ghErr(repoResponse)
    val defaultBranch = try {
        JSONObject(repoResponse.body).optString("default_branch", "main").ifBlank { "main" }
    } catch (_: Exception) { "main" }

    var seedSha: String? = null
    val defaultRef = ghRequest(
        "GET", "$GH_API/repos/$target/git/ref/heads/${ghRefPath(defaultBranch)}", token
    )
    if (defaultRef.code == 200) {
        seedSha = try { JSONObject(defaultRef.body).optJSONObject("object")?.optString("sha", "") }
            catch (_: Exception) { null }
    } else if (defaultRef.code == 404) {
        // GitHub does not allow POST /git/refs on a repository with no commits.
        // Create a temporary file through the Contents API to establish its
        // default branch. The first PySpace snapshot removes this marker.
        val marker = Base64.encodeToString(
            "Temporary initialization marker; removed by the first PySpace publish.\n".toByteArray(),
            Base64.NO_WRAP
        )
        val initBody = JSONObject()
            .put("message", "Initialize repository for PySpace")
            .put("content", marker)
            .toString()
        val initialized = ghRequest(
            "PUT", "$GH_API/repos/$target/contents/.pyspace-init", token, initBody
        )
        if (initialized.code != 201 && initialized.code != 200) return null to ghErr(initialized)
        seedSha = try { JSONObject(initialized.body).optJSONObject("commit")?.optString("sha", "") }
            catch (_: Exception) { "" }
    } else return null to ghErr(defaultRef)

    if (seedSha.isNullOrBlank()) return null to "Could not initialize the repository's first commit."
    if (branch == defaultBranch) return seedSha to null

    val createBody = JSONObject().put("ref", "refs/heads/$branch").put("sha", seedSha).toString()
    val created = ghRequest("POST", "$GH_API/repos/$target/git/refs", token, createBody)
    if (created.code == 201) return seedSha to null
    if (created.code == 422) {
        val raced = ghRequest("GET", "$GH_API/repos/$target/git/ref/heads/${ghRefPath(branch)}", token)
        if (raced.code == 200) {
            val sha = try { JSONObject(raced.body).optJSONObject("object")?.optString("sha", "") ?: "" }
                catch (_: Exception) { "" }
            if (sha.isNotBlank()) return sha to null
        }
    }
    return null to ghErr(created)
}

/** Pushes project files as ONE snapshot commit (Git Data API: blobs, tree,
 *  commit, ref). Handles brand-new repos (creates the branch) and existing
 *  ones (fast-forwards it). Returns a human result line. Never throws. */
internal fun ghPushSnapshot(
    token: String,
    target: String,
    branch: String,
    message: String,
    files: List<Pair<String, ByteArray>>,
    preservedRemoteDirectories: Set<String> = emptySet(),
    allowRemoteDeletions: Boolean = true,
    gitIgnoreMatcher: GhGitIgnoreMatcher? = null
): String {
    if (target.count { it == '/' } != 1) return "Pick a repository first (tap one above)."
    if (branch.isBlank()) return "Branch is empty."
    if (message.isBlank()) return "Write a commit message first."
    if (files.isEmpty()) return "No files to push."
    try {
        // 1. Resolve the selected branch. Empty GitHub repositories must be
        // initialized through the Contents API before Git refs can be created.
        val (resolvedCommit, branchError) = ghEnsureBranch(token, target, branch)
        if (branchError != null) return branchError
        val baseCommit = resolvedCommit ?: return "Could not resolve the target branch."
        val cGet = ghRequest("GET", "$GH_API/repos/$target/git/commits/$baseCommit", token)
        if (cGet.code != 200) return ghErr(cGet)
        val baseTree = try {
            JSONObject(cGet.body).optJSONObject("tree")?.optString("sha", "")
                ?.takeIf { it.isNotBlank() }
        } catch (_: Exception) { null }
        if (baseTree == null) return "GitHub returned a commit without a valid tree."
        // 2. Build a path manifest from the current remote tree. Files removed
        // locally are represented by null-SHA tree entries, so a publish is a
        // real snapshot sync rather than an append-only upload.
        val entries = JSONArray()
        run {
            val remoteTree = ghRequest("GET", "$GH_API/repos/$target/git/trees/$baseTree?recursive=1", token)
            if (remoteTree.code != 200) return ghErr(remoteTree)
            val localPaths = files.mapTo(HashSet()) { it.first }
            try {
                val parsed = JSONObject(remoteTree.body)
                if (allowRemoteDeletions && !parsed.optBoolean("truncated", false)) {
                    val tree = parsed.optJSONArray("tree") ?: JSONArray()
                    for (i in 0 until tree.length()) {
                        val item = tree.optJSONObject(i) ?: continue
                        if (item.optString("type") != "blob") continue
                        val path = item.optString("path")
                        val firstSegment = path.substringBefore('/')
                        val intentionallyExcluded = preservedRemoteDirectories.any { excluded ->
                            path == excluded || path.startsWith(excluded.trimEnd('/') + "/")
                        } || path.split('/').any { isHiddenTreeDir(it) }
                        if (path.isNotBlank() && path !in localPaths && !intentionallyExcluded &&
                            gitIgnoreMatcher?.isIgnored(path, false) != true) {
                            entries.put(JSONObject().put("path", path).put("mode", item.optString("mode", "100644"))
                                .put("type", "blob").put("sha", JSONObject.NULL))
                        }
                    }
                }
            } catch (_: Exception) {
                return "Could not compare the remote repository tree. No changes were pushed."
            }
        }
        // 3. Upload local blobs.
        for ((path, bytes) in files) {
            val b64 = try {
                Base64.encodeToString(bytes, Base64.NO_WRAP)
            } catch (_: Exception) {
                return "Encoding failed: $path"
            }
            val bBody = try {
                JSONObject().put("content", b64).put("encoding", "base64").toString()
            } catch (_: Exception) {
                return "Encoding failed: $path"
            }
            val bPost = ghRequest("POST", "$GH_API/repos/$target/git/blobs", token, bBody)
            if (bPost.code != 201) return ghErr(bPost)
            val sha = try {
                JSONObject(bPost.body).optString("sha", "")
            } catch (_: Exception) {
                ""
            }
            if (sha.isBlank()) return "GitHub rejected a file ($path)."
            entries.put(
                JSONObject().put("path", path).put("mode", "100644")
                .put("type", "blob").put("sha", sha)
            )
        }
        // 4. Tree.
        val treeBody = try {
            JSONObject().put("tree", entries).put("base_tree", baseTree).toString()
        } catch (_: Exception) {
            return "Tree build failed."
        }
        val tPost = ghRequest("POST", "$GH_API/repos/$target/git/trees", token, treeBody)
        if (tPost.code != 201) return ghErr(tPost)
        val treeSha = try {
            JSONObject(tPost.body).optString("sha", "")
        } catch (_: Exception) {
            ""
        }
        if (treeSha.isBlank()) return "GitHub rejected the file tree."
        // 5. Commit.
        val commitBody = try {
            JSONObject().put("message", message).put("tree", treeSha)
            .put("parents", JSONArray().put(baseCommit))
            .toString()
        } catch (_: Exception) {
            return "Commit build failed."
        }
        val cPost = ghRequest("POST", "$GH_API/repos/$target/git/commits", token, commitBody)
        if (cPost.code != 201) return ghErr(cPost)
        val commitSha = try {
            JSONObject(cPost.body).optString("sha", "")
        } catch (_: Exception) {
            ""
        }
        if (commitSha.isBlank()) return "GitHub rejected the commit."
        // 6. Move (or create) the branch ref.
        val refBody = try {
            JSONObject().put("sha", commitSha).put("force", false).toString()
        } catch (_: Exception) {
            return "Ref build failed."
        }
        val uPatch = ghRequest(
            "PATCH", "$GH_API/repos/$target/git/refs/heads/${ghRefPath(branch)}", token, refBody
        )
        if (uPatch.code != 200) return ghErr(uPatch)
        return if (allowRemoteDeletions) "Published ${files.size} files to $target@$branch ✓"
            else "Published ${files.size} files to $target@$branch ✓ (remote-only files preserved because the local scan was bounded)"
    } catch (_: Exception) {
        return "Push failed (network?)."
    }
}
