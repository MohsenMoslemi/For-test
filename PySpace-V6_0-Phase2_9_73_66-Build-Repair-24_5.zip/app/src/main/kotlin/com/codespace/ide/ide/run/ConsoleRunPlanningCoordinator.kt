package com.codespace.ide.ide.run

/** Immutable result of the source/identity planning phase for one Console run. */
data class ConsoleRunPlan(
    val sourceAnalysis: RunSourceAnalysis,
    val conflictKeys: Set<String>,
)

/**
 * Owns the deterministic, side-effect-free planning policy for Console launches.
 * File reading, asynchronous project scans, Android permissions, Compose state,
 * and process publication intentionally remain with their respective adapters.
 */
class ConsoleRunPlanningCoordinator {
    fun plan(
        fileName: String,
        sourceSnapshot: String,
        forceGui: Boolean,
        projectGuestPath: String,
        relativeScriptPath: String,
    ): ConsoleRunPlan {
        val analysis = RunSourceAnalyzer.analyze(fileName, sourceSnapshot, forceGui)
        val keys = RunIdentityResolver.consoleConflictKeys(
            projectGuestPath = projectGuestPath,
            relativeScriptPath = relativeScriptPath,
            webLike = analysis.isWebLike,
        )
        return ConsoleRunPlan(analysis, keys)
    }
}
