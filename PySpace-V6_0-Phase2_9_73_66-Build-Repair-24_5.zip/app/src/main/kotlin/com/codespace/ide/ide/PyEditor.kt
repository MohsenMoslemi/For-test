package com.codespace.ide.ide

import java.io.File

import androidx.compose.animation.core.AnimationState
import androidx.compose.animation.core.DecayAnimationSpec
import androidx.compose.animation.core.animateDecay
import androidx.compose.animation.core.exponentialDecay
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.relocation.BringIntoViewResponder
import androidx.compose.foundation.relocation.bringIntoViewResponder
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.Layout
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.ui.layout.Measurable
import androidx.compose.ui.layout.Placeable
import androidx.compose.ui.layout.layoutId
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.input.nestedscroll.NestedScrollDispatcher
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.isShiftPressed
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.zIndex
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalTextToolbar
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.Dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.nestedscroll.nestedScroll
import kotlin.math.abs
import com.codespace.ide.ide.codeintel.PythonCompletionItem
import com.codespace.ide.ide.codeintel.PythonLspController
import com.codespace.ide.ide.codeintel.PythonSyntaxDiagnostic
import com.codespace.ide.ide.editor.EditorBreakpointStore
import com.codespace.ide.ide.editor.EditorCaretInteractionCoordinator
import com.codespace.ide.ide.editor.EditorCaretNavigationSnapshot
import com.codespace.ide.ide.editor.EditorCaretSessionState
import com.codespace.ide.ide.editor.EditorCompletionSessionState
import com.codespace.ide.ide.editor.EditorCompletionWorkflow
import com.codespace.ide.ide.editor.EditorDerivedState
import com.codespace.ide.ide.editor.EditorDiagnosticsSessionState
import com.codespace.ide.ide.editor.EditorFontMetricsCache
import com.codespace.ide.ide.editor.EditorGutterLayout
import com.codespace.ide.ide.editor.EditorHoverDocumentationWorkflow
import com.codespace.ide.ide.editor.EditorPinchZoomCoordinator
import com.codespace.ide.ide.editor.EditorSelectionToolbarState
import com.codespace.ide.ide.editor.EditorSession
import com.codespace.ide.ide.editor.EditorSurfaceCoordinatesState
import com.codespace.ide.ide.editor.EditorTextInputState
import com.codespace.ide.ide.editor.EditorZoomCommitCoordinator
import com.codespace.ide.ide.editor.EditorZoomGeometry
import com.codespace.ide.ide.editor.FoldedEditorDocument
import com.codespace.ide.ide.editor.OpenTab
import com.codespace.ide.ide.editor.ZoomAnchor
import com.codespace.ide.ide.editor.lineColAt
import com.codespace.ide.ide.editor.EditorCodeIntelligenceEffects
import com.codespace.ide.ide.editor.EditorDocumentSyncEffects
import com.codespace.ide.ide.editor.EditorExternalEditEffects
import com.codespace.ide.ide.editor.EditorImeCaretEffects
import com.codespace.ide.ide.editor.EditorRenameWorkflow
import com.codespace.ide.ide.editor.EditorSessionLifecycle
import com.codespace.ide.ide.editor.EditorZoomAnchorEffects
import com.codespace.ide.ide.editor.IdeEditor
import com.codespace.ide.ide.editor.rememberEditorScrollSession
import com.codespace.ide.ide.editor.rememberEditorSyntaxPresentation
import com.codespace.ide.ide.editor.rememberEditorTextLayoutGeometry
import com.codespace.ide.ide.editor.rememberEditorViewportSessionState
import com.codespace.ide.ide.editor.rememberEditorZoomSessionState
import com.codespace.ide.ide.codeintel.PythonDefinitionLocation
import com.codespace.ide.ide.codeintel.PythonEnvironmentRegistry
import com.codespace.ide.ide.codeintel.PythonImportAnalysis
import com.codespace.ide.ide.theme.IdeTheme

// ---------------------------------------------------------------------------
// Professional Python editor. This environment's TextFieldValue is the
// String-based one (androidx.compose.ui.text.input), so Python colors are
// applied through a VisualTransformation (pure function of the plain text),
// never by stuffing spans into the editing model. Line numbers = one Text
// sharing the editor's ScrollState and exact line height, so the gutter can
// never desync and needs no native canvas.
// ---------------------------------------------------------------------------

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PyEditor(
    tab: OpenTab,
    session: EditorSession,
    fontSize: Float,
    codeFontFamily: FontFamily = FontFamily.Monospace,
    tabWidth: Int,
    autoIndent: Boolean,
    showLines: Boolean,
    wordWrap: Boolean,
    /**
     * Two-axis scrolling (touch): when on, a drag in any direction scrolls
     * both axes at once; when off, strokes lock to their dominant axis.
     * Takes effect only while word wrap is off — with wrap on there is no
     * horizontal range, so there is nothing to unlock. Independent of the
     * always-on fixed gutter / full-area scrolling.
     */
    pan2D: Boolean = false,
    /**
     * Pinch-to-zoom the code font: two fingers change [fontSize] through
     * [onFontSizeChange]. Single-finger gestures are never consumed, so
     * scrolling, taps, selection and typing stay untouched.
     */
    pinchZoom: Boolean = false,
    /**
     * False while another screen (settings, browser, display) covers the
     * editor: focus is dropped so no keyboard / caret handle stays on top.
     */
    active: Boolean = true,
    /** Visibility controls only affect popup presentation, not analysis itself. */
    showDiagnosticPopup: Boolean = true,
    showCompletionPopup: Boolean = true,
    showDocumentationPopup: Boolean = true,
    onFontSizeChange: (Float) -> Unit = {},
    onCursor: (line: Int, col: Int) -> Unit,
    insertRequest: String? = null,
    onInsertConsumed: () -> Unit = {},
    /** Bumped by the top-bar menu: reformat the whole file (see [reformat]). */
    reformatRequest: Int = 0,
    /** Called once the request was handled, so a later tab switch never repeats it. */
    onReformatConsumed: () -> Unit = {},
    /** Bumped by the status-line position chip: glide the caret to the middle of the editor. */
    centerCaretRequest: Int = 0,
    onCenterCaretConsumed: () -> Unit = {},
    /** Bumped by the editor menu to normalize safe module-level imports. */
    fixImportsRequest: Int = 0,
    onFixImportsConsumed: () -> Unit = {},
    analyzeImports: suspend (String) -> com.codespace.ide.ide.codeintel.PythonImportAnalysis = {
        com.codespace.ide.ide.codeintel.PythonImportAnalysis(false)
    },
    /** Touch-accessible undo/redo command targeted at a specific file path. */
    editorCommand: Pair<String, String>? = null,
    externalSelectionRequest: IntRange? = null,
    onExternalSelectionConsumed: () -> Unit = {},
    onEditorCommandConsumed: (Pair<String, String>) -> Unit = {},
    /**
     * Jump request from structure/search panels: file path + 1-based line.
     * Applies only to the matching file; consumed exactly once.
     */
    jumpRequest: Pair<String, Int>? = null,
    onJumpConsumed: () -> Unit = {},
    onFocusChange: (Boolean) -> Unit = {},
    /**
     * Reports whether a text range is currently selected. Read-only signal
     * for the file-tree swipe (which stands down while true); editing,
     * cursor and selection behavior are untouched.
     */
    onSelectionChange: (Boolean) -> Unit = {},
    /** Python language-server diagnostics for this buffer; used for underlines and gutter markers. */
    syntaxDiagnostics: List<PythonSyntaxDiagnostic> = emptyList(),
    /** Exact source that the displayed diagnostics were validated against. */
    syntaxValidatedSource: String? = null,
    /** Project-scoped real Python Language Server. */
    pythonLspController: PythonLspController? = null,
    onGoToDefinition: (com.codespace.ide.ide.codeintel.PythonDefinitionLocation) -> Unit = {},
    onBreakpointToggle: (Int) -> Unit = {},
    /**
     * Clearance below the last line, inside the scroll range, so the final
     * lines can rest fully above the bottom panel instead of hiding behind
     * it. Defaults to the closed panel bar + margin.
     */
    bottomInset: Dp = 72.dp,
    modifier: Modifier = Modifier
) {
    val editorLanguage = remember(tab.file.absolutePath) { EditorLanguageRegistry.languageFor(tab.file) }
    val isPythonLanguage = editorLanguage == EditorLanguage.PYTHON
    val environmentRevisions = com.codespace.ide.ide.codeintel.PythonEnvironmentRegistry
        .revisionMap.collectAsState().value
    val environmentRevision = if (isPythonLanguage) {
        pythonLspController?.let { environmentRevisions[it.environmentProjectKey()] ?: 0L } ?: 0L
    } else 0L
    // Scroll state, tab restoration and axis arbitration have one per-tab
    // owner. All editor workflows consume these same ScrollState instances.
    val scrollSession = rememberEditorScrollSession(
        filePath = tab.file.absolutePath,
        savedScrollX = tab.scrollX,
        savedScrollY = tab.scrollY,
        hasSavedView = tab.hasView,
        pan2D = pan2D,
        wordWrap = wordWrap
    )
    val hScroll = scrollSession.horizontal
    val vScroll = scrollSession.vertical
    val restoreView = scrollSession.restoreView
    val panFree = scrollSession.panFree
    val axisLink = scrollSession.axisLink
    val textMeasurer = rememberTextMeasurer()
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    // The tab owns document text; this presentation holder owns only the live
    // TextFieldValue required by Compose (selection/IME composition included).
    val textInputState = remember(tab.file.absolutePath) { EditorTextInputState(tab) }
    var field by textInputState.value
    // While typing, hide only diagnostics belonging to the line being edited.
    // Other lines keep their last validated underlines until the new source is
    // checked by CPython. A matching validated source restores the full result.
    val diagnosticsSession = remember(tab.file.absolutePath) { EditorDiagnosticsSessionState() }
    val collapsedFoldKeys = tab.collapsedFoldKeys
    val foldedDocument = remember(tab.file.absolutePath, tab.text, collapsedFoldKeys) {
        FoldedEditorDocument.build(tab.text, collapsedFoldKeys)
    }
    val foldedDocumentNow by rememberUpdatedState(foldedDocument)
    val breakpointLines = EditorBreakpointStore.lines(tab.file)

    // OpenTab is the shared document model; BasicTextField owns selection/IME state.
    // This bridge applies edits initiated outside the editor and one-shot selections.
    EditorDocumentSyncEffects(
        filePath = tab.file.absolutePath,
        documentText = tab.text,
        onFieldChange = { field = it },
        onExternalDocumentApplied = { diagnosticsSession.editingLine = null },
        externalSelectionRequest = externalSelectionRequest,
        onExternalSelectionConsumed = onExternalSelectionConsumed,
        inputState = textInputState
    )
    val syntaxPresentation = rememberEditorSyntaxPresentation(
        file = tab.file,
        isPythonLanguage = isPythonLanguage,
        validatedSource = syntaxValidatedSource,
        currentSource = field.text,
        editingLine = diagnosticsSession.editingLine,
        diagnostics = syntaxDiagnostics,
        flashLine = caretSession.flashLine,
        language = editorLanguage,
        foldedDocument = foldedDocument,
        wordWrap = wordWrap,
        themeId = IdeTheme.themeId
    )
    val visibleSyntaxDiagnostics = syntaxPresentation.visibleDiagnostics
    // Keep the diagnostic card tied to the current caret line, not to a stale
    // pointer coordinate. Diagnostics are line-oriented in the LSP contract;
    // showing the matching line is reliable even when the diagnostic range is
    // zero-width (common for parser errors at end-of-line).
    val cursorLine = remember(field.text, field.selection.start) {
        lineColAt(field.text, field.selection.start)[0]
    }
    val cursorDiagnostic = EditorDerivedState.diagnosticOnLine(visibleSyntaxDiagnostics, cursorLine)
    // Completion results, replacement range and request generations share one
    // per-document presentation owner. LSP analysis itself remains in CodeIntelligence.
    val completionSession = remember(tab.file.absolutePath) { EditorCompletionSessionState() }
    var completionItems by completionSession.items
    var completionRange by completionSession.replaceRange
    var completionEditVersion by completionSession.editVersion
    var completionTriggerCaret by completionSession.triggerCaret
    var lastLspCompletionEditVersion by completionSession.lastLspEditVersion
    var lastLspCompletionEnvironmentRevision by completionSession.lastLspEnvironmentRevision
    var signatureInfo by completionSession.signature

    // Completion and signature-help request lifecycles are coordinated in a
    // dedicated code-intelligence boundary. The editor remains the owner of
    // buffer state and popup presentation state.
    EditorCodeIntelligenceEffects(
        file = tab.file,
        field = field,
        isPythonLanguage = isPythonLanguage,
        showCompletionPopup = showCompletionPopup,
        editorLanguage = editorLanguage.name,
        completionEditVersion = completionEditVersion,
        completionTriggerCaret = completionTriggerCaret,
        lastLspCompletionEditVersion = lastLspCompletionEditVersion,
        environmentRevision = environmentRevision,
        lastLspCompletionEnvironmentRevision = lastLspCompletionEnvironmentRevision,
        completionItems = completionItems,
        controller = pythonLspController,
        onCompletionItemsChanged = { completionItems = it },
        onCompletionRangeChanged = { completionRange = it },
        onLastEditVersionChanged = { lastLspCompletionEditVersion = it },
        onLastEnvironmentRevisionChanged = { lastLspCompletionEnvironmentRevision = it },
        onSignatureInfoChanged = { signatureInfo = it }
    )

    // Keeps caret/selection updates from dismissing a docs card during the
    // same tap that opened it. Long-press is deliberately left to TextField.
    var hoverTapInProgress by remember(tab.file.absolutePath) { mutableStateOf(false) }
    // Hover resolution and information-card lifecycle are isolated from the
    // editor surface. The source/layout snapshots are supplied at request time;
    // PyEditor remains the sole owner of the live document and coordinates.
    val hoverWorkflow = remember(tab.file.absolutePath) { EditorHoverDocumentationWorkflow(scope) }
    val hoverDoc = hoverWorkflow.documentation
    val hoverDefinition = hoverWorkflow.definition
    val hoverAnchorInField = hoverWorkflow.anchorInField
    val hoverAnchorOffset = hoverWorkflow.anchorOffset
    val docExpanded = hoverWorkflow.expanded
    val closeDoc: () -> Unit = { hoverWorkflow.close() }
    // Diagnostic card dismissed with its × (shown again when the caret reaches another diagnostic).
    LaunchedEffect(cursorLine) { diagnosticsSession.clearDismissal() }
    // Last known bounds of every popup card / the "i" bubble, to keep taps ON them from being
    // treated as a tap on the code underneath (which would open hover docs for that word).
    // All measured surface and popup geometry shares one per-document owner.
    // This prevents independent coordinate caches from drifting across tab changes.
    val surfaceCoordinates = remember(tab.file.absolutePath) { EditorSurfaceCoordinatesState() }
    val popupHitCoords = surfaceCoordinates.popupHitCoordinates
    val caretMemo = surfaceCoordinates.caretAnchor
    val docMemo = surfaceCoordinates.documentationAnchor
    fun tapIsOnPopup(pos: Offset, gc: LayoutCoordinates): Boolean =
        surfaceCoordinates.isTapOnPopup(pos, gc, with(density) { 6.dp.toPx() })
    LaunchedEffect(showDocumentationPopup) {
        if (!showDocumentationPopup) {
            hoverWorkflow.clearPresentation()
        }
    }
    val fieldCoordinates by rememberUpdatedState(surfaceCoordinates.field)
    val gestureCoordinates by rememberUpdatedState(surfaceCoordinates.gesture)

    // Package/interpreter changes invalidate both parts of the unified
    // information card so stale documentation or navigation cannot survive.
    LaunchedEffect(environmentRevision) {
        hoverWorkflow.clearPresentation()
    }

    // Caret-follow state lives BEFORE its first use (local declarations
    // cannot be forward-referenced): every cursor event funnels through
    // reportCursor below.
    // Per-tab caret interaction flags are grouped in a presentation state
    // holder; document selection and scroll ownership remain in this composable.
    val initialCaretPosition = remember(tab.file.absolutePath) {
        if (tab.selStart in 0..tab.text.length) lineColAt(tab.text, tab.selStart)
        else intArrayOf(tab.text.count { it == '\n' } + 1, tab.text.substringAfterLast('\n', "").length)
    }
    val caretSession = remember(tab.file.absolutePath) {
        EditorCaretSessionState(
            initialLine = initialCaretPosition[0],
            initialColumn = initialCaretPosition[1],
            initiallyInteracted = restoreView && tab.selStart in 0..tab.text.length
        )
    }
    EditorSessionLifecycle(
        tab = tab,
        field = field,
        verticalScroll = vScroll,
        horizontalScroll = hScroll,
        hoverJob = hoverWorkflow.activeJob,
        onSelectionChange = onSelectionChange
    )
    val lineH = fontSize * 1.42f
    val lineHPx = with(density) { lineH.sp.toPx() }
    val bottomInsetPx = with(density) { bottomInset.toPx() }
    // The caret's drop handle hangs ~26 dp below the caret and is only shown while it fits above
    // the bottom clearance (handleVisible). The caret reveal must therefore keep this much room
    // under the caret, otherwise a caret scrolled "just into view" - which is exactly where the
    // keyboard's smaller viewport leaves it - never gets its handle.
    val caretHandleReachPx = with(density) { 26.dp.toPx() }
    val caretHandleMarginPx = with(density) { 6.dp.toPx() }
    // One per-document owner supplies the measured viewport and text-layout
    // snapshot to caret, zoom, popup, gutter and content sizing workflows.
    val viewportSession = rememberEditorViewportSessionState(tab.file.absolutePath)
    val viewportPx = viewportSession.heightPx
    val viewportW = viewportSession.widthPx
    val fieldW = viewportSession.fieldWidthPx
    val textLayout = viewportSession.textLayout
    val imeVisible = WindowInsets.isImeVisible
    // The editor is hosted inside IdeEditor, whose parent applies
    // Modifier.imePadding(). Therefore this viewport is already measured
    // above the software keyboard when the IME is visible. Do not subtract
    // WindowInsets.ime again: doing so double-counts the keyboard and makes
    // caret-follow and completion-popup placement jump upward.
    val style = TextStyle(
        fontFamily = codeFontFamily,
        fontSize = fontSize.sp,
        lineHeight = lineH.sp,
        color = Color(IdeTheme.TEXT)
    )
    // REAL geometry of the committed text at a given font size: [0] = row pitch
    // (px), [1] = glyph advance (px). Android rounds the line height to whole
    // pixels, so the pitch ratio between two font sizes is NOT the font ratio;
    // scaling the preview by the font ratio is what made the code "pop" by a
    // few pixels per row (growing towards the bottom of the screen) when the
    // fingers lifted. The preview is continuous while the fingers move; on
    // release it eases to the exact ratio of these values, and the commit /
    // scroll re-anchor use them too.
    val fontMetricsCache = remember(codeFontFamily, density.density, density.fontScale) {
        EditorFontMetricsCache()
    }
    val fontMetricsFor: (Float) -> FloatArray = { f ->
        fontMetricsCache.measure(f, textMeasurer, style)
    }
    // Word-wrap measurement and gutter alignment share one geometry snapshot.
    // The helper owns only measurement/cache policy; PyEditor keeps the live field,
    // scroll, gesture and IME state.
    val textLayoutGeometry = rememberEditorTextLayoutGeometry(
        foldedDocument = foldedDocument,
        textLayout = textLayout,
        fieldWidthPx = fieldW,
        wordWrap = wordWrap,
        style = style,
        fontSize = fontSize,
        lineHeight = lineH,
        textMeasurer = textMeasurer,
        fontMetricsCache = fontMetricsCache,
        density = density
    )
    val lineRowsNow by textLayoutGeometry.lineRowsNow
    val visualRowPrefix = textLayoutGeometry.visualRowPrefix
    val gutterRows = textLayoutGeometry.gutterRows
    // Live views for the pinch loop (which must NOT restart on every font
    // tick — a mid-pinch update would kill the gesture in flight).
    val fontNow by rememberUpdatedState(fontSize)
    val fontChangeNow by rememberUpdatedState(onFontSizeChange)
    // ---- Smooth pinch zoom ------------------------------------------------
    // Re-laying out the whole file (text + one gutter row per line) on every
    // finger movement is what made zooming feel stepped. While two fingers
    // are down the content is only SCALED on the GPU (graphicsLayer, no
    // recomposition / relayout); the real font size is committed once, when
    // the fingers lift, and the scroll position is re-anchored so the spot
    // under the fingers stays under the fingers.
    // Vertical (row pitch) and horizontal (glyph advance) preview ratios.
    val zoomSession = rememberEditorZoomSessionState()
    val pinchScaleState = zoomSession.scaleY
    var pinchScale by pinchScaleState
    val pinchScaleXState = zoomSession.scaleX
    var pinchScaleX by pinchScaleXState
    // Font size the preview is heading for (0 = none); drives the gutter's glyph scale.
    val pinchTargetFontState = zoomSession.targetFont
    var pinchTargetFont by pinchTargetFontState
    var pinchPivot by zoomSession.pivot
    // Native Android text-selection handles are positioned by the text system,
    // not by our temporary graphicsLayer transform. Hide them for the duration
    // of the live transform and until the committed text layout has settled.
    val pinchGestureActiveState = zoomSession.gestureActive
    var pinchGestureActive by pinchGestureActiveState
    val zoomCommitInProgressState = zoomSession.commitInProgress
    var zoomCommitInProgress by zoomCommitInProgressState
    // Visual compensation for the 1-2 frames between "new font laid out" and
    // "scroll offsets re-anchored": the whole sheet is translated by the offset
    // the scroll will move by, so the content never visibly jumps.
    val commitShiftXState = zoomSession.commitShiftX
    var commitShiftX by commitShiftXState
    val commitShiftYState = zoomSession.commitShiftY
    var commitShiftY by commitShiftYState
    // These are read IN COMPOSITION and handed to the layers as plain values.
    // A graphicsLayer {} lambda that reads state is re-run by a separate
    // observer, which can lag one frame behind the composition that applies the
    // new font size: that frame showed the new layout scaled AGAIN by the old
    // preview ratio (the one-frame "flash" on release). A value captured in
    // composition changes atomically with the font size.
    val layerScaleY = zoomSession.layerScaleY
    val layerScaleX = zoomSession.layerScaleX
    // Glyphs follow the font ratio while rows follow the measured pitch ratio.
    val layerFontRatio = zoomSession.layerFontRatio(fontSize)
    val sheetShiftX = zoomSession.sheetShiftX
    val sheetShiftY = zoomSession.sheetShiftY
    // Gutter width (px) the committed font size will produce; shown live so the
    // gutter never changes width when the fingers lift.
    var pinchGutterPx by zoomSession.gutterWidthPx
    val zoomAnchor = zoomSession.anchor
    /** Visual row where logical line [ln] starts (0-based). */
    fun topRowOf(ln: Int): Int {
        val displayIndex = foldedDocumentNow.displayLineIndexForSourceLine(ln)
        return EditorDerivedState.firstVisualRow(displayIndex, visualRowPrefix)
    }
    // Live views for the caret-reveal coroutine (it outlives recompositions).
    val fieldNow by rememberUpdatedState(field)
    val layoutNow by rememberUpdatedState(textLayout)
    // The gutter layout owner keeps committed and pinch-preview geometry identical.
    val gutterVisible = showLines || foldedDocument.foldableLines.isNotEmpty() || breakpointLines.isNotEmpty()
    val gutterLayout = EditorGutterLayout.calculate(
        fontSize = fontSize,
        density = density,
        showLineNumbers = showLines,
        gutterVisible = gutterVisible,
        lastVisibleSourceLine = foldedDocument.visibleSourceLines.lastOrNull() ?: 1,
        layerScaleX = layerScaleX,
        layerScaleY = layerScaleY,
        zoomAnchorPending = zoomAnchor.pending,
        pinchGutterWidthPx = pinchGutterPx
    )
    val gutterFoldSlotDp = gutterLayout.foldSlotDp
    val gutterDp = gutterLayout.widthDp
    val gutterPx = gutterLayout.widthPx
    val effectiveGutterPx = gutterLayout.effectiveWidthPx
    val effectiveGutterDp = gutterLayout.effectiveWidthDp
    val textPadPx = gutterLayout.textPaddingPx
    val gutterPxForFont = gutterLayout.widthPxForFont
    val gutterPxNow by rememberUpdatedState(gutterPx)
    val gutterPxForFontNow by rememberUpdatedState(gutterPxForFont)
    val textPaddingNow by rememberUpdatedState(textPadPx)
    val wordWrapNow by rememberUpdatedState(wordWrap)
    // Word wrap: the text REFLOWS with the font size, which a GPU scale cannot show, so the
    // font is committed live on every pinch step. Right after each new layout the scroll is
    // moved so the visual line that was at the viewport top stays there.
    val reanchorWrap: (TextLayoutResult) -> Unit = { l ->
        if (zoomAnchor.wrapLive && zoomAnchor.wrapValid && l.layoutInput.style.fontSize == fontNow.sp) {
            val len = l.layoutInput.text.length
            val line = l.getLineForOffset(zoomAnchor.wrapOffset.coerceIn(0, len))
            val top = l.getLineTop(line)
            val h = (l.getLineBottom(line) - top).coerceAtLeast(1f)
            val target = EditorZoomGeometry.wrappedAnchorScrollTarget(
                textPaddingPx = textPadPx,
                lineTop = top,
                lineBottom = top + h,
                lineFraction = zoomAnchor.wrapFrac
            )
            val delta = target - vScroll.value
            if (abs(delta) >= 0.5f) vScroll.dispatchRawDelta(delta)
        }
    }
    val reanchorWrapNow by rememberUpdatedState(reanchorWrap)
    // ZoomAnchor effects are grouped with the zoom presentation adapter; the
    // commit animation and gesture remain owned by this surface coordinator.
    EditorZoomAnchorEffects(
        fontSize = fontSize,
        verticalScroll = vScroll,
        horizontalScroll = hScroll,
        wordWrap = wordWrap,
        textLayout = textLayout,
        pinchGestureActive = pinchGestureActive,
        anchor = zoomAnchor,
        onCommitSettled = {
            commitShiftX = 0f
            commitShiftY = 0f
            // Only now does the TextField expose final caret geometry again.
            zoomCommitInProgress = false
        },
        onWrappedLayoutChanged = reanchorWrapNow
    )
    // Finger lifted: ease the preview to the EXACT geometry the committed font
    // will have (a few percent at most, over ~90 ms), then commit the font size,
    // the compensation shift and the layer reset in one snapshot.
    // Commit hand-off dependencies are bound once to a project/tab-scoped
    // coordinator. PyEditor supplies only the two font endpoints at gesture end.
    val zoomCommitCoordinator = remember(scope, zoomSession, vScroll, hScroll) {
        EditorZoomCommitCoordinator(
            scope = scope,
            session = zoomSession,
            verticalScroll = vScroll,
            horizontalScroll = hScroll,
            fontMetricsFor = fontMetricsFor,
            currentGutterPx = { gutterPxNow },
            gutterPxForFont = { gutterPxForFontNow(it) },
            textPaddingPx = { textPaddingNow },
            wordWrap = { wordWrapNow },
            onFontSizeChange = { fontChangeNow(it) }
        )
    }
    val beginZoomCommitNow by rememberUpdatedState<(Float, Float) -> Unit> { start, target ->
        zoomCommitCoordinator.commit(start, target)
    }
    // Pointer recognition is intentionally thin: the coordinator below owns
    // the wrapped/unwrapped zoom lifecycle and its commit hand-off rules.
    val pinchZoomCoordinator = EditorPinchZoomCoordinator(
        scope = scope,
        session = zoomSession,
        anchor = zoomAnchor,
        verticalScroll = vScroll,
        horizontalScroll = hScroll,
        currentFontSize = { fontNow },
        currentLayout = { layoutNow },
        currentDisplayText = { foldedDocumentNow.displayText },
        textPaddingPx = textPadPx,
        currentGutterPx = { gutterPxNow },
        gutterPxForFont = { gutterPxForFontNow(it) },
        changeFontSize = { fontChangeNow(it) },
        commitZoom = { start, target -> beginZoomCommitNow(start, target) }
    )
    // Caret navigation is a separate workflow. Live State handles keep its
    // coroutines aligned with the latest layout, selection and folded document.
    val caretNavigationSnapshot = EditorCaretNavigationSnapshot(
        layout = rememberUpdatedState(textLayout),
        field = rememberUpdatedState(field),
        document = rememberUpdatedState(foldedDocument),
        lineRows = textLayoutGeometry.lineRowsNow,
        visualRowPrefix = visualRowPrefix,
        caretLine = caretSession.line,
        viewportHeight = viewportPx.toFloat(),
        viewportWidth = viewportW,
        bottomInset = bottomInsetPx,
        lineHeight = lineHPx,
        textPadding = textPadPx,
        gutterWidth = gutterPx,
        handleReach = caretHandleReachPx,
        handleMargin = caretHandleMarginPx,
        wordWrap = wordWrap,
        density = density,
        verticalScroll = vScroll,
        horizontalScroll = hScroll
    )
    // The coordinator owns the caret-to-viewport workflow, while the mutable
    // caret flags and document remain in this composable. Both providers are
    // refreshed every composition so in-flight scroll jobs never capture stale
    // layout geometry or callbacks.
    val latestCaretSnapshot by rememberUpdatedState(caretNavigationSnapshot)
    val latestCaretReport by rememberUpdatedState<(Int, Int) -> Unit> { ln, col ->
        caretSession.report(ln, col)
        onCursor(ln, col)
    }
    val caretCoordinator = remember(scope) {
        EditorCaretInteractionCoordinator(
            scope = scope,
            snapshot = { latestCaretSnapshot },
            onReport = { ln, col -> latestCaretReport(ln, col) }
        )
    }
    LaunchedEffect(centerCaretRequest) {
        if (centerCaretRequest != 0) {
            caretCoordinator.center()
            onCenterCaretConsumed()
        }
    }

    fun reportCursor(ln: Int, col: Int, center: Boolean = false, reveal: Boolean = true) {
        caretCoordinator.report(ln, col, center, reveal)
    }

    EditorExternalEditEffects(
        tab = tab,
        field = field,
        onFieldChange = { field = it },
        tabWidth = tabWidth,
        editorCommand = editorCommand,
        onEditorCommandConsumed = onEditorCommandConsumed,
        insertRequest = insertRequest,
        onInsertConsumed = onInsertConsumed,
        jumpRequest = jumpRequest,
        onJumpConsumed = onJumpConsumed,
        onFlashLineChange = { caretSession.flash(it) },
        reportCursor = { line, column, center -> reportCursor(line, column, center = center) }
    )

    val completionWorkflow = remember { EditorCompletionWorkflow() }
    fun applyCompletion(item: PythonCompletionItem) {
        completionWorkflow.apply(
            tab = tab,
            source = field.text,
            selection = field.selection,
            replaceRange = completionRange,
            item = item,
            onFieldChange = { field = it },
            onCompletionDismiss = { completionItems = emptyList() },
            onCursor = { line, column -> reportCursor(line, column) }
        )
    }

    fun showHoverDocumentation(pressPosition: Offset): Boolean = hoverWorkflow.show(
        enabled = showDocumentationPopup,
        isPythonLanguage = isPythonLanguage,
        file = tab.file,
        source = field.text,
        currentSource = { fieldNow.text },
        pressPosition = pressPosition,
        fieldCoordinates = fieldCoordinates,
        gestureCoordinates = gestureCoordinates,
        layout = textLayout,
        displayText = foldedDocument.displayText,
        foldedDocument = foldedDocument,
        controller = pythonLspController,
        density = density
    )
    // The surface pointerInput coroutine can outlive several recompositions
    // (scroll, resize, font zoom and layout updates do not change its keys).
    // Always dispatch hover using the latest document/layout/coordinate snapshot.
    val latestShowHoverDocumentation = rememberUpdatedState<(Offset) -> Boolean> { position ->
        showHoverDocumentation(position)
    }

    EditorImeCaretEffects(
        active = active,
        imeVisible = imeVisible,
        firstTapPending = caretSession.firstTapPending,
        hasCaretInteraction = caretSession.hasInteracted,
        caretLine = caretSession.line,
        caretColumn = caretSession.column,
        focusManager = androidx.compose.ui.platform.LocalFocusManager.current,
        pinCaretToView = { line, column -> caretCoordinator.reveal(line, column) }
    )
    // Formatting and import-fix orchestration is a separate workflow. The editor
    // remains the single owner of the live document and applies accepted edits here.
    EditorFormattingWorkflow(
        tab = tab,
        field = field,
        onFieldChange = { field = it },
        tabWidth = tabWidth,
        isPythonLanguage = isPythonLanguage,
        reformatRequest = reformatRequest,
        onReformatConsumed = onReformatConsumed,
        fixImportsRequest = fixImportsRequest,
        onFixImportsConsumed = onFixImportsConsumed,
        analyzeImports = analyzeImports,
        pythonLspController = pythonLspController,
        syntaxDiagnostics = syntaxDiagnostics,
        syntaxValidatedSource = syntaxValidatedSource,
        reportCursor = { line, column -> reportCursor(line, column) }
    )
    // Syntax tokenization, diagnostic filtering and visual transformation share
    // one per-document presentation owner.
    val colors = syntaxPresentation.colors
    // Tap-anywhere-to-type: the field is only as tall as its text, so taps
    // on the gutter, below the last line or right of short lines never reach
    // it. This covers the whole editor body; taps ON the text still hit the
    // field first (child-first dispatch), so cursor placement is unchanged.
    val focusRequester = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    var fieldHasFocus by remember(tab.file.absolutePath) { mutableStateOf(false) }
    // Live snapshots for the first-tap fallback running in a pointer coroutine.
    val latestFieldValue by rememberUpdatedState(field)
    val latestFieldHasFocus by rememberUpdatedState(fieldHasFocus)
    val latestTextLayout by rememberUpdatedState(textLayout)
    val latestFieldCoordinates by rememberUpdatedState(fieldCoordinates)
    val latestGestureCoordinates by rememberUpdatedState(gestureCoordinates)

    // Keep the editor surface painted across the complete area assigned by
    // IdeEditor. The scroll content below is explicitly given a viewport-sized
    // minimum (minus bottomInset, which is appended after it), so short files
    // no longer make the editable surface collapse to just a few text lines.
    val editorContentMinHeight = with(density) {
        (viewportPx.toFloat() - bottomInsetPx).coerceAtLeast(0f).toDp()
    }

    Column(
        modifier
        .fillMaxSize()
        .background(Color(IdeTheme.BG))
        // Fixed hairline between the gutter and the code. It is drawn by a modifier that sits
        // OUTSIDE (before) the scroll modifiers, i.e. in viewport space: it never scrolls,
        // pans or scales with the content, always spans the full editor height, and only
        // follows the gutter's own edge (a value captured in composition, so it changes in
        // the same frame as the gutter width).
        .editorSurfaceInteraction(
            gutterVisible = gutterVisible,
            effectiveGutterPx = effectiveGutterPx,
            onViewportSizeChanged = { size ->
                viewportSession.updateViewport(width = size.width, height = size.height)
            },
            onViewportPositioned = {
                surfaceCoordinates.viewport = it
                // The tap observer and hover resolver measure pointer positions
                // in this fixed viewport coordinate space. Keep this reference
                // live; leaving it null silently disables both the info bubble
                // and the documentation/Go To Definition card.
                surfaceCoordinates.gesture = it
            },
            panFree = panFree,
            axisLink = axisLink,
            verticalScroll = vScroll,
            horizontalScroll = hScroll,
            wordWrap = wordWrap,
            pinchZoom = { base ->
                base.editorPinchZoomGesture(
            enabled = pinchZoom,
            currentFontSize = { fontNow },
            currentWordWrap = { wordWrapNow },
            canStartPinch = { !zoomAnchor.settling },
            onPinchStart = pinchZoomCoordinator::onStart,
            onPinchUpdate = pinchZoomCoordinator::onUpdate,
            onPinchEnd = pinchZoomCoordinator::onEnd
        )
            },
            tapObserver = { base ->
                base.editorTapObserver(
            filePath = tab.file.absolutePath,
            fieldText = field.text,
            scope = scope,
            density = density,
            latestFieldValue = { latestFieldValue },
            latestFieldHasFocus = { latestFieldHasFocus },
            latestTextLayout = { latestTextLayout },
            latestFieldCoordinates = { latestFieldCoordinates },
            latestGestureCoordinates = { latestGestureCoordinates },
            foldedDocument = { foldedDocumentNow },
            setFirstTapPending = { caretSession.markFirstTapPending(it) },
            setHoverTapInProgress = { hoverTapInProgress = it },
            tapIsOnPopup = ::tapIsOnPopup,
            placeCaret = { sourceText, offset ->
                textInputState.placeCaret(sourceText, offset)
            },
            reportCursor = { line, column -> reportCursor(line, column) },
            showHoverDocumentation = { position -> latestShowHoverDocumentation.value(position) }
        )
            }
        )

    ) {
        Box(
            modifier = Modifier
                // Never narrower than the viewport, so popups placed inside
                // the visible lane are always inside this Box (hit-testable).
                .widthIn(min = with(density) { viewportW.toDp() })
                .holdViewportOnBringIntoView { Offset(hScroll.value.toFloat(), vScroll.value.toFloat()) }
                // Between the new layout and the scroll re-anchor the sheet is shifted by
                // the offset the scroll is about to move by (zero outside that window).
                .then(
                    if (sheetShiftX != 0f || sheetShiftY != 0f) {
                        Modifier.graphicsLayer {
                            translationX = sheetShiftX
                            translationY = sheetShiftY
                        }
                    } else Modifier
                )
        ) {
            // Shared by the BasicTextField's CompositionLocalProvider and the
            // overlay sibling below the code row. Keep it at Box scope so the
            // toolbar state is visible to both without leaking outside editor.
            val selectionToolbar = remember { EditorSelectionToolbarState() }
            EditorRenameWorkflow(
                tab = tab,
                session = session,
                field = field,
                onFieldChange = { field = it },
                isPythonLanguage = isPythonLanguage,
                pythonLspController = pythonLspController,
                selectionToolbar = selectionToolbar,
                scope = scope
            )
            EditorCodeInputLayer(
                field = field,
                onFieldChange = { field = it },
                tab = tab,
                tabWidth = tabWidth,
                autoIndent = autoIndent,
                isPythonLanguage = isPythonLanguage,
                onFlashLineClear = { caretSession.flash(null) },
                hoverTapInProgress = hoverTapInProgress,
                hoverDoc = hoverDoc?.name,
                hoverWorkflow = hoverWorkflow,
                completionItems = completionItems,
                onCompletionItemsChange = { completionItems = it },
                completionRange = completionRange,
                onCompletionRangeChange = { completionRange = it },
                onCompletionEdit = { completionSession.markEdit() },
                onCompletionTriggerCaret = { completionTriggerCaret = it },
                onSyntaxEditingLineChange = { diagnosticsSession.editingLine = it },
                reportCursor = { line, column -> reportCursor(line, column) },
                style = style,
                colors = colors,
                focusRequester = focusRequester,
                showCompletionPopup = showCompletionPopup,
                applyCompletion = ::applyCompletion,
                onTextLayout = { viewportSession.textLayout = it; reanchorWrapNow(it) },
                onFieldFocusChange = { fieldHasFocus = it },
                onFocusChange = onFocusChange,
                onFieldCoordinates = { surfaceCoordinates.field = it },
                editorContentMinHeight = editorContentMinHeight,
                onFieldWidthChange = viewportSession::updateFieldWidth,
                selectionToolbar = selectionToolbar,
                active = active,
                pinchGestureActive = pinchGestureActive,
                zoomCommitInProgress = zoomCommitInProgress,
                textLayout = textLayout,
                foldedDocument = foldedDocumentNow,
                viewportW = viewportW,
                viewportPx = viewportPx,
                gutterPx = gutterPx,
                textPadPx = textPadPx,
                bottomInsetPx = bottomInsetPx,
                hScroll = hScroll,
                vScroll = vScroll,
                gutterVisible = gutterVisible,
                gutterDp = gutterDp,
                pinchPivot = pinchPivot,
                layerScaleX = layerScaleX,
                layerScaleY = layerScaleY,
                pinchGutterPx = pinchGutterPx,
                density = density
            )

            EditorPopupAndGutterLayers(
                tab = tab,
                foldedDocument = foldedDocument,
                field = field,
                onFieldChange = { field = it },
                fontSize = fontSize,
                textLayout = textLayout,
                hoverDoc = hoverDoc,
                hoverDefinition = hoverDefinition,
                hoverAnchorInField = hoverAnchorInField,
                hoverAnchorOffset = hoverAnchorOffset,
                viewportW = viewportW,
                viewportPx = viewportPx,
                gutterPx = gutterPx,
                sheetShiftX = sheetShiftX,
                sheetShiftY = sheetShiftY,
                layerScaleX = layerScaleX,
                layerScaleY = layerScaleY,
                pinchPivot = pinchPivot,
                gutterVisible = gutterVisible,
                textPadPx = textPadPx,
                pinchGutterPx = pinchGutterPx,
                caretMemo = caretMemo,
                docMemo = docMemo,
                cursorDiagnostic = cursorDiagnostic,
                signatureInfo = signatureInfo,
                completionItems = completionItems,
                density = density,
                bottomInsetPx = bottomInsetPx,
                lineHPx = lineHPx,
                showCompletionPopup = showCompletionPopup,
                showDocumentationPopup = showDocumentationPopup,
                docExpanded = docExpanded,
                showDiagnosticPopup = showDiagnosticPopup,
                dismissedDiag = diagnosticsSession.dismissedDiagnostic,
                effectiveGutterPx = effectiveGutterPx,
                hScroll = hScroll,
                vScroll = vScroll,
                pinchGestureActive = pinchGestureActive,
                zoomCommitInProgress = zoomCommitInProgress,
                zoomAnchor = zoomAnchor,
                popupHitCoords = popupHitCoords,
                applyCompletion = ::applyCompletion,
                onCompletionDismiss = { completionItems = emptyList() },
                hoverWorkflow = hoverWorkflow,
                onGoToDefinition = onGoToDefinition,
                onCloseDocumentation = closeDoc,
                scope = scope,
                tabWidth = tabWidth,
                pythonLspController = pythonLspController,
                syntaxValidatedSource = syntaxValidatedSource,
                onSyntaxEditingLineChange = { diagnosticsSession.editingLine = it },
                reportCursor = { line, column, reveal -> reportCursor(line, column, reveal = reveal) },
                onDiagnosticDismiss = { diagnosticsSession.dismissedDiagnostic = it },
                onSignatureDismiss = { signatureInfo = null },
                gutterRows = gutterRows,
                showLines = showLines,
                codeFontFamily = codeFontFamily,
                visibleSyntaxDiagnostics = visibleSyntaxDiagnostics,
                breakpointLines = breakpointLines,
                effectiveGutterDp = effectiveGutterDp,
                textMeasurer = textMeasurer,
                wordWrap = wordWrap,
                layerFontRatio = layerFontRatio,
                gutterFoldSlotDp = gutterFoldSlotDp,
                onBreakpointToggle = onBreakpointToggle,
                onExpandDocumentation = { hoverWorkflow.expand() }
            )

        }
        // Clearance inside the scroll range: the last line can rest fully
        // above the bottom panel.
        Spacer(Modifier.height(bottomInset))
    }
}
