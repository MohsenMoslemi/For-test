package com.codespace.ide.memory

import android.content.Context
import android.os.Debug
import android.content.ComponentCallbacks2
import java.lang.ref.WeakReference
import java.util.concurrent.CopyOnWriteArrayList

/** User-selectable memory policy. Low-memory mode reduces retained UI history, not program output. */
enum class MemoryProfile(val id: String, val title: String) {
    BALANCED("balanced", "Balanced"),
    LOW_MEMORY("low_memory", "Low memory");

    companion object {
        fun fromId(value: String?): MemoryProfile = values().firstOrNull { it.id == value } ?: BALANCED
    }
}

/** Components with disposable in-memory caches or bounded histories can join this registry. */
interface MemoryTrimmable {
    /** Drop retained data above the currently active policy limits. */
    fun trimToPolicy()
    /** Drop recomputable caches; must not delete user data or stop active work. */
    fun clearTemporaryCaches()
}

/** Weak ownership prevents the registry itself from keeping UI/runtime objects alive. */
object MemoryTrimRegistry {
    private val participants = CopyOnWriteArrayList<WeakReference<MemoryTrimmable>>()

    fun register(participant: MemoryTrimmable) {
        participants.removeAll { it.get() == null }
        if (participants.none { it.get() === participant }) {
            participants += WeakReference(participant)
        }
    }

    fun trimToPolicy() {
        for (reference in participants) {
            val participant = reference.get()
            if (participant == null) participants.remove(reference)
            else try { participant.trimToPolicy() } catch (_: Exception) { }
        }
    }

    fun clearTemporaryCaches() {
        for (reference in participants) {
            val participant = reference.get()
            if (participant == null) participants.remove(reference)
            else try { participant.clearTemporaryCaches() } catch (_: Exception) { }
        }
    }
}

data class MemoryUsageSnapshot(
    val processPssMb: Int,
    val javaHeapUsedMb: Int,
    val javaHeapMaxMb: Int,
)

/**
 * Process-wide policy for app-owned retained memory. This deliberately does not
 * manage Python/Ubuntu processes, notebook kernels, project files or user output.
 */
object MemoryRuntimePolicy {
    private const val PREFS = "pyspace_memory"
    private const val KEY_PROFILE = "profile"
    private const val KEY_AUTO_TRIM = "auto_trim"

    @Volatile private var currentProfile: MemoryProfile = MemoryProfile.BALANCED
    @Volatile private var autoTrim: Boolean = true
    @Volatile private var underPressure: Boolean = false
    @Volatile private var initialized: Boolean = false

    fun initialize(context: Context) {
        if (initialized) return
        synchronized(this) {
            if (initialized) return
            val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            currentProfile = MemoryProfile.fromId(prefs.getString(KEY_PROFILE, MemoryProfile.BALANCED.id))
            autoTrim = prefs.getBoolean(KEY_AUTO_TRIM, true)
            initialized = true
        }
    }

    fun profile(): MemoryProfile = currentProfile
    fun isAutomaticTrimmingEnabled(): Boolean = autoTrim
    fun isUnderMemoryPressure(): Boolean = underPressure

    fun setProfile(context: Context, profile: MemoryProfile) {
        initialize(context)
        currentProfile = profile
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_PROFILE, profile.id).apply()
        MemoryTrimRegistry.trimToPolicy()
    }

    fun setAutomaticTrimming(context: Context, enabled: Boolean) {
        initialize(context)
        autoTrim = enabled
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_AUTO_TRIM, enabled).apply()
        if (!enabled) underPressure = false
        MemoryTrimRegistry.trimToPolicy()
    }

    /** Called by Application.onTrimMemory; only app-owned caches/histories are touched. */
    fun onTrimMemory(level: Int) {
        if (!autoTrim) return
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            underPressure = true
            MemoryTrimRegistry.trimToPolicy()
        }
    }

    /** Restore the user's selected profile when the app becomes visible again. */
    fun onForeground() {
        if (underPressure) {
            underPressure = false
            MemoryTrimRegistry.trimToPolicy()
        }
    }

    fun terminalScrollbackLimit(): Int = when {
        underPressure -> 2_000
        currentProfile == MemoryProfile.LOW_MEMORY -> 4_000
        else -> 12_000
    }

    fun terminalStyledCacheLimit(): Int = when {
        underPressure -> 64
        currentProfile == MemoryProfile.LOW_MEMORY -> 128
        else -> 384
    }

    /** Bound the transient PTY-to-Compose queue with backpressure, never by dropping output. */
    fun terminalPendingCharsLimit(): Int = when {
        underPressure -> 32 * 1024
        currentProfile == MemoryProfile.LOW_MEMORY -> 64 * 1024
        else -> 256 * 1024
    }

    /** Maximum decoded image edge for file previews, notebook outputs and live GUI frames. */
    fun imageMaxEdge(): Int = when {
        underPressure -> 768
        currentProfile == MemoryProfile.LOW_MEMORY -> 1_280
        else -> 2_048
    }

    /** Per-open-document undo/redo budget; older snapshots are evicted first. */
    fun editorHistoryMaxEntries(): Int = when {
        underPressure -> 8
        currentProfile == MemoryProfile.LOW_MEMORY -> 20
        else -> 40
    }

    fun editorHistoryMaxChars(): Int = when {
        underPressure -> 128 * 1024
        currentProfile == MemoryProfile.LOW_MEMORY -> 512 * 1024
        else -> 1_500_000
    }

    fun usageSnapshot(): MemoryUsageSnapshot {
        val runtime = Runtime.getRuntime()
        val used = runtime.totalMemory() - runtime.freeMemory()
        return MemoryUsageSnapshot(
            processPssMb = (Debug.getPss() / 1024L).toInt(),
            javaHeapUsedMb = (used / (1024L * 1024L)).toInt(),
            javaHeapMaxMb = (runtime.maxMemory() / (1024L * 1024L)).toInt(),
        )
    }
}
