package com.codespace.ide.ide.editor

/** Pure scroll-target calculations shared by caret reveal and caret centering. */
internal object EditorCaretViewport {
    fun revealVerticalTarget(
        current: Int,
        max: Int,
        caretTop: Float,
        caretBottom: Float,
        visibleHeight: Float,
        lineHeight: Float,
        handleReach: Float,
        handleMargin: Float,
        center: Boolean
    ): Int {
        val visibleTop = current.toFloat()
        val visibleBottom = visibleTop + visibleHeight
        val needBottom = caretBottom + handleReach
        var target = current
        if (caretTop < visibleTop || needBottom > visibleBottom) {
            target = if (center) (caretTop - (visibleHeight - lineHeight) / 3f).toInt()
            else if (caretTop < visibleTop) (caretTop - lineHeight).toInt()
            else (needBottom + handleMargin - visibleHeight).toInt()
        }
        return target.coerceIn(0, max)
    }

    fun revealHorizontalTarget(
        current: Int,
        max: Int,
        caretX: Float,
        gutter: Float,
        viewportWidth: Float,
        margin: Float
    ): Int {
        var target = current
        val laneLeft = current + gutter
        val laneRight = current + viewportWidth
        if (caretX < laneLeft) target = (caretX - gutter - margin).toInt()
        else if (caretX + 2f > laneRight) target = (caretX + margin - viewportWidth).toInt()
        return target.coerceIn(0, max)
    }

    fun centeredVerticalTarget(
        caretTop: Float,
        caretBottom: Float,
        visibleHeight: Float,
        max: Int
    ): Int = (((caretTop + caretBottom) / 2f) - visibleHeight / 2f).toInt().coerceIn(0, max)

    fun centeredHorizontalTarget(
        current: Int,
        max: Int,
        caretX: Float,
        gutter: Float,
        viewportWidth: Float,
        margin: Float
    ): Int {
        val laneLeft = current + gutter
        val laneRight = current + viewportWidth
        return if (caretX < laneLeft + margin || caretX > laneRight - margin) {
            (caretX - gutter - (viewportWidth - gutter) / 2f).toInt().coerceIn(0, max)
        } else current
    }
}
