package com.codespace.ide.ide.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ide.EditorSymbolCatalog
import com.codespace.ide.ide.theme.IdeTheme

@Composable
internal fun IndexMetric(label: String, value: String, tint: Color, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(10.dp)).background(Color(IdeTheme.CARD)).padding(10.dp)) {
        Text(value, color = tint, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Color(IdeTheme.DIM), fontSize = 10.sp)
    }
}

// ------------------------------- File tree ---------------------------------

/** Small floppy-disk icon for the top bar's Save button (drawn, so no icon library is needed). */
@Composable
internal fun SaveGlyph(tint: Color) {
    androidx.compose.foundation.Canvas(Modifier.size(19.dp)) {
        val w = size.width
        val h = size.height
        val sw = w * 0.09f
        val body = androidx.compose.ui.graphics.Path().apply {
            moveTo(w * 0.10f, h * 0.10f)
            lineTo(w * 0.72f, h * 0.10f)
            lineTo(w * 0.90f, h * 0.28f)
            lineTo(w * 0.90f, h * 0.90f)
            lineTo(w * 0.10f, h * 0.90f)
            close()
        }
        drawPath(
            body, tint,
            style = androidx.compose.ui.graphics.drawscope.Stroke(
                width = sw, join = androidx.compose.ui.graphics.StrokeJoin.Round
            )
        )
        // label (top) and the shutter slot (bottom)
        drawRect(
            tint,
            topLeft = androidx.compose.ui.geometry.Offset(w * 0.28f, h * 0.10f),
            size = androidx.compose.ui.geometry.Size(w * 0.34f, h * 0.24f)
        )
        drawRoundRect(
            tint,
            topLeft = androidx.compose.ui.geometry.Offset(w * 0.27f, h * 0.55f),
            size = androidx.compose.ui.geometry.Size(w * 0.46f, h * 0.35f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.04f),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = sw)
        )
    }
}

/**
 * Compact Python punctuation/indentation row shown above the soft keyboard.
 * Each key owns a stable touch target; the visible label may differ from the
 * inserted token (for example TAB inserts a real tab request).
 */
@Composable
internal fun PySymbolBar(
    symbols: List<String>,
    onInsert: (String) -> Unit
) {
    val ordered = EditorSymbolCatalog.normalize(symbols)
    val pinned = ordered.take(EditorSymbolCatalog.PINNED_COUNT)
    val scrollable = ordered.drop(EditorSymbolCatalog.PINNED_COUNT)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(IdeTheme.PANEL))
            .padding(horizontal = 5.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // The pinned group is deliberately outside the horizontal scroll container.
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
            pinned.forEach { symbol -> PySymbolKey(symbol, onInsert) }
        }
        Box(
            Modifier
                .padding(horizontal = 6.dp)
                .width(1.dp)
                .height(25.dp)
                .background(Color(IdeTheme.LINE))
        )
        // Only the overflow group scrolls; the pinned keys never move.
        Row(
            modifier = Modifier
                .weight(1f)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            scrollable.forEach { symbol -> PySymbolKey(symbol, onInsert) }
        }
    }
}

@Composable
internal fun PySymbolKey(symbol: String, onInsert: (String) -> Unit) {
    val label = if (symbol == "TAB") "⇥" else symbol
    Box(
        modifier = Modifier
            .width(if (symbol == "TAB") 48.dp else 38.dp)
            .height(34.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(Color(IdeTheme.BG))
            .clickable { onInsert(symbol) },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = Color(IdeTheme.TEXT),
            fontSize = if (symbol.length > 2) 12.sp else 15.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
