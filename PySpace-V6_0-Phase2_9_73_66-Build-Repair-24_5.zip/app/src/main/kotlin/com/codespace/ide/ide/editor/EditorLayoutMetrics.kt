package com.codespace.ide.ide.editor

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Bounded cache for the editor's measured glyph advance and visual line pitch.
 * Kept outside PyEditor so its rendering code does not own cache policy.
 */
internal class EditorFontMetricsCache(private val maxEntries: Int = 96) {
    private val values = LinkedHashMap<Float, FloatArray>(32, 0.75f, true)

    fun measure(fontSize: Float, textMeasurer: TextMeasurer, baseStyle: TextStyle): FloatArray {
        values[fontSize]?.let { return it }
        val measured = textMeasurer.measure(
            text = "MMMMMMMMMM\nM\nM",
            style = baseStyle.copy(fontSize = fontSize.sp, lineHeight = (fontSize * 1.42f).sp),
            softWrap = false
        )
        val pitch = (measured.getLineTop(2) - measured.getLineTop(1)).coerceAtLeast(1f)
        val advance = (measured.getLineRight(0) / 10f).coerceAtLeast(0.5f)
        val result = floatArrayOf(pitch, advance)
        values[fontSize] = result
        while (values.size > maxEntries.coerceAtLeast(1)) {
            val oldest = values.entries.iterator()
            if (!oldest.hasNext()) break
            oldest.next()
            oldest.remove()
        }
        return result
    }
}

/** Access-ordered cache; limits retained wrapped-line measurements per editor surface. */
internal class EditorLineRowCache(maxEntries: Int = 8192) : LinkedHashMap<String, Int>(256, 0.75f, true) {
    private val capacity = maxEntries.coerceAtLeast(1)

    override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Int>?): Boolean =
        size > capacity

    fun measureRows(
        source: String,
        lineStarts: IntArray,
        fieldWidthPx: Int,
        textMeasurer: TextMeasurer,
        style: TextStyle
    ): List<Int> = List(lineStarts.size) { index ->
        val start = lineStarts[index]
        val end = if (index + 1 < lineStarts.size) lineStarts[index + 1] - 1 else source.length
        val line = source.substring(start, end)
        this[line] ?: textMeasurer.measure(
            text = glueLeadingIndent(AnnotatedString(line)),
            style = style,
            constraints = Constraints(maxWidth = fieldWidthPx)
        ).lineCount.coerceAtLeast(1).also { this[line] = it }
    }
}

/** Canonical gutter lane width used by committed and pinch-preview layouts. */
internal fun editorGutterWidthDp(
    fontSize: Float,
    fontScale: Float,
    showLineNumbers: Boolean,
    gutterVisible: Boolean,
    lastVisibleSourceLine: Int
): Dp {
    val markerDp = maxOf(18f, fontSize * 0.72f * fontScale)
    val foldDp = maxOf(28f, fontSize * 1.05f * fontScale)
    val numberDp = if (showLineNumbers) {
        maxOf(2, lastVisibleSourceLine.coerceAtLeast(1).toString().length) *
            (fontSize * 0.62f * fontScale) + 8f
    } else 0f
    return when {
        showLineNumbers -> (markerDp + numberDp + foldDp + 8f).coerceAtLeast(68f).dp
        gutterVisible -> (markerDp + foldDp + 8f).coerceAtLeast(56f).dp
        else -> 0.dp
    }
}
