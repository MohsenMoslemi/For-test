package com.codespace.ide.ide

import android.graphics.BitmapFactory
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import com.codespace.ide.memory.MemoryRuntimePolicy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.codespace.ide.ide.theme.IdeTheme

// ---------------------------------------------------------------------------
// Non-text tab content: a zoomable image viewer, and an info view for
// everything the IDE cannot render (archives, binaries, oversized files).
// Read-only by construction: neither viewer can modify or truncate files.
// ---------------------------------------------------------------------------

/** Longest bitmap edge decoded for display (memory safety on big photos). */
private val MAX_BITMAP_EDGE: Int get() = MemoryRuntimePolicy.imageMaxEdge()

private data class LoadedBitmap(
    val bitmap: androidx.compose.ui.graphics.ImageBitmap?,
    val width: Int,
    val height: Int,
    val error: String?
)

/** Decodes bounds always; pixels only within the memory cap. IO thread. */
private fun decodeForView(file: File): LoadedBitmap {
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        try {
            file.inputStream().use { BitmapFactory.decodeStream(it, null, bounds) }
        } catch (_: Exception) {
        }
        val w = bounds.outWidth
        val h = bounds.outHeight
        if (w <= 0 || h <= 0) {
            return LoadedBitmap(null, 0, 0, "Not a decodable image")
        }
        var sample = 1
        while (w / sample > MAX_BITMAP_EDGE || h / sample > MAX_BITMAP_EDGE) {
            sample *= 2
        }
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = try {
            file.inputStream().use { BitmapFactory.decodeStream(it, null, opts) }
        } catch (_: OutOfMemoryError) {
            null
        } catch (_: Exception) {
            null
        }
        if (bmp == null) {
            LoadedBitmap(null, w, h, "Couldn't decode pixels")
        } else {
            LoadedBitmap(bmp.asImageBitmap(), w, h, null)
        }
    } catch (_: OutOfMemoryError) {
        LoadedBitmap(null, 0, 0, "Image too large for memory")
    } catch (t: Exception) {
        LoadedBitmap(null, 0, 0, t.message ?: "Decode failed")
    }
}

private fun fileModified(file: File): String {
    return try {
        SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(file.lastModified()))
    } catch (_: Exception) {
        "?"
    }
}

/**
 * Image tab: pinch-zoom + pan, zoom buttons, full metadata. Anything the
 * decoder chokes on becomes an inline error — never a crash.
 */
@Composable
fun ImageViewerTab(file: File, detected: DetectedFile, modifier: Modifier = Modifier) {
    val loadKey = try {
        file.absolutePath + ":" + file.lastModified() + ":" + file.length()
    } catch (_: Exception) {
        file.absolutePath
    }
    var loaded by remember(loadKey) { mutableStateOf<LoadedBitmap?>(null) }
    var scale by remember(loadKey) { mutableStateOf(1f) }
    var offset by remember(loadKey) { mutableStateOf(Offset.Zero) }
    LaunchedEffect(loadKey) {
        loaded = withContext(Dispatchers.IO) { decodeForView(file) }
    }
    val zoomState = rememberTransformableState { zoomChange, panChange, _ ->
        scale = (scale * zoomChange).coerceIn(1f, 8f)
        offset = if (scale <= 1f) Offset.Zero else offset + panChange
    }
    fun zoomBy(f: Float) {
        scale = (scale * f).coerceIn(1f, 8f)
        if (scale <= 1f) offset = Offset.Zero
    }

    Column(modifier.fillMaxSize()) {
        // Metadata header.
        val snap = loaded
        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
            Text(
                file.name, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                color = Color(IdeTheme.TEXT), maxLines = 1
            )
            Spacer(Modifier.height(2.dp))
            val dims = if (snap != null && snap.width > 0) "${snap.width}×${snap.height} · " else ""
            Text(
                detected.format + " · " + dims + humanBytes(detected.size) + " · " + fileModified(file),
                color = Color(IdeTheme.DIM), fontSize = 11.sp,
                fontFamily = FontFamily.Monospace, maxLines = 2
            )
        }
        // Zoomable surface.
        Box(
            Modifier.weight(1f).fillMaxWidth().clipToBounds(),
            contentAlignment = Alignment.Center
        ) {
            when {
                snap == null -> CircularProgressIndicator(
                    color = Color(IdeTheme.ACCENT), strokeWidth = 2.dp,
                    modifier = Modifier.size(28.dp)
                )
                snap.bitmap != null -> Image(
                    bitmap = snap.bitmap,
                    contentDescription = file.name,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                        .transformable(zoomState)
                        .graphicsLayer(
                            scaleX = scale,
                            scaleY = scale,
                            translationX = offset.x,
                            translationY = offset.y
                        )
                )
                else -> Text(
                    "Couldn't display this image\n(${snap.error ?: "decode failed"})",
                    color = Color(IdeTheme.ERROR), fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(24.dp)
                )
            }
        }
        // Zoom controls.
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            TextButton(onClick = { zoomBy(1f / 1.25f) }) {
                Text("−", fontSize = 16.sp, color = Color(IdeTheme.TEXT))
            }
            Text(
                "${(scale * 100).toInt()}%", fontSize = 12.sp,
                fontFamily = FontFamily.Monospace, color = Color(IdeTheme.DIM),
                modifier = Modifier.width(56.dp), textAlign = TextAlign.Center
            )
            TextButton(onClick = { zoomBy(1.25f) }) {
                Text("+", fontSize = 16.sp, color = Color(IdeTheme.TEXT))
            }
            TextButton(onClick = { scale = 1f; offset = Offset.Zero }) {
                Text("Reset", fontSize = 12.sp, color = Color(IdeTheme.ACCENT))
            }
        }
    }
}

/**
 * Info tab for archives, binaries, oversized/long-line files: kind, size,
 * location — and an honest "not editable here" note instead of an error or
 * a crash. Read-only: no buffer, no save path exists.
 */
@Composable
fun UnsupportedFileView(
    file: File,
    detected: DetectedFile,
    projectDir: File,
    modifier: Modifier = Modifier
) {
    val rel = try {
        projectDir.toURI().relativize(file.toURI()).path.ifEmpty { file.name }
    } catch (_: Exception) {
        file.name
    }
    val glyph = when (detected.content) {
        FileContent.ARCHIVE -> "▦"
        FileContent.IMAGE -> "◈"
        else -> if (detected.tooLarge || detected.longLine) "▤" else "⬢"
    }
    val note = when {
        detected.tooLarge -> "Too large to open safely " +
            "(over ${humanBytes(MAX_EDIT_BYTES)}). " +
            "It is left untouched — edit it on a computer."
        detected.longLine -> "One line is over ${MAX_EDIT_LINE} characters, " +
            "which the phone editor cannot lay out. Left untouched."
        else -> "This format can't be edited in the IDE. " +
            "It is left untouched."
    }
    Column(
        modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(glyph, color = Color(IdeTheme.ACCENT), fontSize = 44.sp)
        Spacer(Modifier.height(10.dp))
        Text(
            file.name, fontWeight = FontWeight.Bold, fontSize = 16.sp,
            color = Color(IdeTheme.TEXT), textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(4.dp))
        Text(
            detected.format + " · " + humanBytes(detected.size),
            color = Color(IdeTheme.DIM), fontSize = 12.sp,
            fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(2.dp))
        Text(
            rel + " · modified " + fileModified(file),
            color = Color(IdeTheme.DIM), fontSize = 11.sp,
            fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))
        Text(
            note, color = Color(IdeTheme.WARN), fontSize = 12.sp,
            textAlign = TextAlign.Center
        )
    }
}
