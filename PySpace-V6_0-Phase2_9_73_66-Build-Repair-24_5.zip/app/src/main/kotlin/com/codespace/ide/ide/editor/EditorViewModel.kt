package com.codespace.ide.ide.editor

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope


import java.io.File
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import com.codespace.ide.runtime.RuntimeDispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** UI state for asynchronous editor document operations. */
data class EditorUiState(
    val openingPath: String? = null,
    val savingPaths: Set<String> = emptySet(),
    val error: String? = null,
)

/**
 * Coordinates document I/O for one project editor session. UI state remains
 * on Main; all file inspection and persistence is delegated to the repository.
 */
class EditorViewModel(
    val session: EditorSession,
    private val dispatchers: RuntimeDispatchers,
    private val repository: EditorRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(EditorUiState())
    val state: StateFlow<EditorUiState> = _state.asStateFlow()

    private val openJobs = LinkedHashMap<String, Job>()
    private val saveMutexes = HashMap<String, Mutex>()
    private val activeSaveCounts = HashMap<String, Int>()
    private var restoreStarted = false
    private var userOpenVersion = 0
    private var latestRequestedPath: String? = null

    fun openFile(file: File) {
        userOpenVersion++
        val path = file.absolutePath
        latestRequestedPath = path
        val existing = session.tabs.indexOfFirst { it.file.absolutePath == path }
        if (existing >= 0) {
            session.activeIndex = existing
            return
        }
        if (openJobs[path]?.isActive == true) return
        _state.value = _state.value.copy(openingPath = path, error = null)
        openJobs[path] = viewModelScope.launch {
            try {
                val document = repository.load(file)
                // A tab may have been opened through another action while the
                // disk read was in flight. Reuse it rather than duplicating it.
                val current = session.tabs.indexOfFirst { it.file.absolutePath == path }
                val shouldActivate = latestRequestedPath == path
                if (current >= 0) {
                    if (shouldActivate) session.activeIndex = current
                } else {
                    session.openLoadedTab(
                        document.file, document.detected, document.text,
                        activate = shouldActivate,
                    )
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                _state.value = _state.value.copy(error = error.message ?: "Unable to open file")
            } finally {
                openJobs.remove(path)
                if (_state.value.openingPath == path) {
                    _state.value = _state.value.copy(openingPath = null)
                }
            }
        }
    }

    fun save(tab: OpenTab, onComplete: ((Boolean) -> Unit)? = null) {
        if (!tab.editable || !tab.dirty) {
            onComplete?.invoke(true)
            return
        }
        val path = tab.file.absolutePath
        val snapshot = tab.text
        beginSaving(path)
        _state.value = _state.value.copy(error = null)
        viewModelScope.launch {
            var success = false
            try {
                val result = saveDocument(tab, snapshot)
                result.fold(
                    onSuccess = {
                        tab.markSaved(snapshot)
                        success = true
                    },
                    onFailure = { failure ->
                        _state.value = _state.value.copy(error = failure.message ?: "Unable to save file")
                    },
                )
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                _state.value = _state.value.copy(error = error.message ?: "Unable to save file")
            } finally {
                endSaving(path)
                onComplete?.invoke(success)
            }
        }
    }

    /** Persists dirty documents under a path before a rename, move or delete. */
    fun saveTabsUnder(file: File, onComplete: (Boolean) -> Unit) {
        val prefix = file.absolutePath
        val affected = session.tabs.filter {
            val path = it.file.absolutePath
            path == prefix || path.startsWith(prefix + "/")
        }.toList()
        viewModelScope.launch {
            var allSaved = true
            for (tab in affected) {
                if (!tab.dirty || !tab.editable) continue
                val snapshot = tab.text
                val path = tab.file.absolutePath
                beginSaving(path)
                try {
                    saveDocument(tab, snapshot).fold(
                        onSuccess = { tab.markSaved(snapshot) },
                        onFailure = { failure ->
                            allSaved = false
                            _state.value = _state.value.copy(error = failure.message ?: "Unable to save ${tab.name}")
                        },
                    )
                    if (tab.dirty) allSaved = false
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: Exception) {
                    allSaved = false
                    _state.value = _state.value.copy(error = error.message ?: "Unable to save ${tab.name}")
                } finally {
                    endSaving(path)
                }
            }
            onComplete(allSaved)
        }
    }

    /** Save every dirty editable buffer and report failure explicitly to callers that must not proceed (for example, test execution). */
    fun saveDirtyDocuments(onComplete: (Boolean, Int, String?) -> Unit) {
        val dirtyTabs = session.tabs.filter { it.dirty && it.editable }.toList()
        if (dirtyTabs.isEmpty()) {
            onComplete(true, 0, null)
            return
        }
        viewModelScope.launch {
            var savedCount = 0
            var failureMessage: String? = null
            for (tab in dirtyTabs) {
                if (!tab.dirty || !tab.editable) continue
                val snapshot = tab.text
                val path = tab.file.absolutePath
                beginSaving(path)
                try {
                    val result = saveDocument(tab, snapshot)
                    result.fold(
                        onSuccess = {
                            tab.markSaved(snapshot)
                            savedCount++
                            if (tab.dirty && failureMessage == null) {
                                failureMessage = "${tab.name} changed while it was being saved. Run the tests again after saving."
                            }
                        },
                        onFailure = { error ->
                            if (failureMessage == null) failureMessage = "Unable to save ${tab.name}: ${error.message ?: "Unknown error"}"
                        },
                    )
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: Exception) {
                    if (failureMessage == null) failureMessage = "Unable to save ${tab.name}: ${error.message ?: "Unknown error"}"
                } finally {
                    endSaving(path)
                }
                if (failureMessage != null) break
            }
            val allClean = dirtyTabs.none { it.dirty }
            if (!allClean && failureMessage == null) failureMessage = "Some files changed while saving. Run the tests again after saving."
            val success = failureMessage == null && allClean
            if (!success) _state.value = _state.value.copy(error = failureMessage)
            onComplete(success, savedCount, failureMessage)
        }
    }

    fun saveAll(onComplete: ((Int) -> Unit)? = null) {
        val dirtyTabs = session.tabs.filter { it.dirty && it.editable }.toList()
        if (dirtyTabs.isEmpty()) {
            onComplete?.invoke(0)
            return
        }
        viewModelScope.launch {
            var savedCount = 0
            var allSucceeded = true
            for (tab in dirtyTabs) {
                val snapshot = tab.text
                val path = tab.file.absolutePath
                beginSaving(path)
                try {
                    saveDocument(tab, snapshot).fold(
                        onSuccess = { tab.markSaved(snapshot); savedCount++ },
                        onFailure = { failure ->
                            allSucceeded = false
                            _state.value = _state.value.copy(error = failure.message ?: "Unable to save ${tab.name}")
                        },
                    )
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: Exception) {
                    allSucceeded = false
                    _state.value = _state.value.copy(error = error.message ?: "Unable to save ${tab.name}")
                } finally {
                    endSaving(path)
                }
            }
            if (allSucceeded && dirtyTabs.none { it.dirty }) {
                onComplete?.invoke(savedCount)
            } else if (allSucceeded) {
                _state.value = _state.value.copy(error = "Files changed while saving. Save again to finish.")
            }
        }
    }

    /** Restores previously open tabs without blocking the first editor frame. */
    fun restoreFrom(json: String) {
        if (restoreStarted || json.isBlank()) return
        restoreStarted = true
        val versionAtStart = userOpenVersion
        viewModelScope.launch {
            try {
                val root = org.json.JSONObject(json)
                val array = root.optJSONArray("tabs") ?: return@launch
                val savedActive = root.optInt("active", -1)
                var restoredActivePath: String? = null
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    val file = File(item.optString("p"))
                    val exists = withContext(dispatchers.io) { file.isFile }
                    if (!exists) continue
                    try {
                        val document = repository.load(file)
                        val tab = session.openLoadedTab(
                            document.file, document.detected, document.text, activate = false
                        )
                        tab.scrollY = item.optInt("y", 0)
                        tab.scrollX = item.optInt("x", 0)
                        tab.selStart = item.optInt("s", -1)
                        tab.selEnd = item.optInt("e", -1)
                        tab.hasView = item.optBoolean("v", false)
                        if (index == savedActive) restoredActivePath = file.absolutePath
                    } catch (cancelled: CancellationException) {
                        throw cancelled
                    } catch (_: Exception) {
                        // One missing/unreadable document must not block the
                        // remaining tabs from being restored.
                    }
                }
                // Do not let a slow restore steal focus from a file the user
                // opened after entering the project.
                if (userOpenVersion == versionAtStart) {
                    val activePath = restoredActivePath
                    if (activePath != null) {
                        session.activeIndex = session.tabs.indexOfFirst { it.file.absolutePath == activePath }
                            .coerceAtLeast(0)
                    } else if (session.tabs.isNotEmpty()) {
                        session.activeIndex = 0
                    }
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                _state.value = _state.value.copy(error = error.message ?: "Unable to restore editor session")
            }
        }
    }



    private fun beginSaving(path: String) {
        val count = (activeSaveCounts[path] ?: 0) + 1
        activeSaveCounts[path] = count
        _state.value = _state.value.copy(savingPaths = _state.value.savingPaths + path)
    }

    private fun endSaving(path: String) {
        val count = (activeSaveCounts[path] ?: 1) - 1
        if (count <= 0) {
            activeSaveCounts.remove(path)
            _state.value = _state.value.copy(savingPaths = _state.value.savingPaths - path)
        } else {
            activeSaveCounts[path] = count
        }
    }

    private suspend fun saveDocument(tab: OpenTab, snapshot: String): Result<Unit> {
        val path = tab.file.absolutePath
        val mutex = synchronized(saveMutexes) { saveMutexes.getOrPut(path) { Mutex() } }
        return mutex.withLock { repository.save(tab.file, snapshot) }
    }

    override fun onCleared() {
        // viewModelScope is cancelled by ViewModel, but clearing these
        // registries also releases references to paths, mutexes and jobs
        // immediately when a project store is removed.
        openJobs.values.forEach { it.cancel() }
        openJobs.clear()
        synchronized(saveMutexes) { saveMutexes.clear() }
        activeSaveCounts.clear()
        latestRequestedPath = null
        super.onCleared()
    }

    class Factory(
        private val session: EditorSession,
        private val dispatchers: RuntimeDispatchers,
        private val repository: EditorRepository,
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (!modelClass.isAssignableFrom(EditorViewModel::class.java)) {
                throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
            }
            return EditorViewModel(session, dispatchers, repository) as T
        }
    }
}
