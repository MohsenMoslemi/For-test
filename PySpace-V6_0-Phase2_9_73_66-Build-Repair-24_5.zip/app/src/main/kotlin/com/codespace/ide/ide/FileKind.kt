package com.codespace.ide.ide

import java.io.File

/**
 * Real file-kind detection, driven by CONTENT (magic bytes + text
 * heuristics), never by extension alone. A text file renamed to `.xyz`
 * still opens as text; a `.png` containing garbage still routes to the
 * info view instead of crashing the text editor.
 *
 * Pure Kotlin + java.io: unit-testable, no Compose/Android, and it performs
 * exactly one bounded read (never more than [MAX_EDIT_BYTES]).
 */
enum class FileContent { TEXT, IMAGE, ARCHIVE, BINARY }

/** Largest file the text editor will load (matches safeReadText's cap). */
const val MAX_EDIT_BYTES = 300_000L

/** Longest single line the text editor will load (layout safety). */
const val MAX_EDIT_LINE = 64_000

/** Head bytes sniffed for magic numbers (covers TAR's ustar at 257). */
private const val SNIFF_BYTES = 512

data class DetectedFile(
    val content: FileContent,
    /** Human label, e.g. "PNG image", "ZIP archive", "Text", "Binary file". */
    val format: String,
    val size: Long,
    val imageWidth: Int = 0,
    val imageHeight: Int = 0,
    /** Charset the text editor must load with ("UTF-8", "UTF-16LE", ...). */
    val charset: String = "UTF-8",
    /** Over [MAX_EDIT_BYTES]: never loaded, info view only. */
    val tooLarge: Boolean = false,
    /** One line over [MAX_EDIT_LINE]: never loaded, info view only. */
    val longLine: Boolean = false
) {
    /** True only when the text editor may safely load this file. */
    val viewableText: Boolean
        get() = content == FileContent.TEXT && !tooLarge && !longLine
}

private fun startsWith(h: ByteArray, vararg magic: Byte): Boolean {
    if (h.size < magic.size) return false
    for (i in magic.indices) {
        if (h[i] != magic[i]) return false
    }
    return true
}

private fun asciiAt(h: ByteArray, off: Int, text: String): Boolean {
    if (off < 0 || off + text.length > h.size) return false
    for (i in text.indices) {
        if (h[off + i] != text[i].code.toByte()) return false
    }
    return true
}

private fun be32(h: ByteArray, off: Int): Int {
    if (off < 0 || off + 4 > h.size) return 0
    return ((h[off].toInt() and 0xFF) shl 24) or
        ((h[off + 1].toInt() and 0xFF) shl 16) or
        ((h[off + 2].toInt() and 0xFF) shl 8) or
        (h[off + 3].toInt() and 0xFF)
}

private fun le16(h: ByteArray, off: Int): Int {
    if (off < 0 || off + 2 > h.size) return 0
    return (h[off].toInt() and 0xFF) or ((h[off + 1].toInt() and 0xFF) shl 8)
}

private fun le32(h: ByteArray, off: Int): Int {
    if (off < 0 || off + 4 > h.size) return 0
    return (h[off].toInt() and 0xFF) or
        ((h[off + 1].toInt() and 0xFF) shl 8) or
        ((h[off + 2].toInt() and 0xFF) shl 16) or
        ((h[off + 3].toInt() and 0xFF) shl 24)
}

/**
 * Magic-number match: (content, format, width, height). Width/height are
 * parsed only where they sit at fixed offsets (PNG/GIF/BMP); the image
 * viewer reads exact bounds for everything else.
 */
private fun matchMagic(h: ByteArray, ext: String): DetectedFile? {
    if (startsWith(h, 0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)) {
        return DetectedFile(FileContent.IMAGE, "PNG image", 0, be32(h, 16), be32(h, 20))
    }
    if (startsWith(h, 0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte())) {
        return DetectedFile(FileContent.IMAGE, "JPEG image", 0)
    }
    if (asciiAt(h, 0, "GIF87a") || asciiAt(h, 0, "GIF89a")) {
        val animated = asciiAt(h, 0, "GIF89a")
        return DetectedFile(
            FileContent.IMAGE, if (animated) "GIF image (animated)" else "GIF image",
            0, le16(h, 6), le16(h, 8)
        )
    }
    if (asciiAt(h, 0, "RIFF") && asciiAt(h, 8, "WEBP")) {
        return DetectedFile(FileContent.IMAGE, "WebP image", 0)
    }
    if (asciiAt(h, 0, "BM")) {
        return DetectedFile(FileContent.IMAGE, "BMP image", 0, le32(h, 18), le32(h, 22))
    }
    if (startsWith(h, 0x00, 0x00, 0x01, 0x00) || startsWith(h, 0x00, 0x00, 0x02, 0x00)) {
        return DetectedFile(FileContent.IMAGE, "Icon", 0)
    }
    if (asciiAt(h, 0, "II*\u0000") || asciiAt(h, 0, "MM\u0000*")) {
        return DetectedFile(FileContent.IMAGE, "TIFF image", 0)
    }
    if (asciiAt(h, 0, "qoif")) {
        return DetectedFile(FileContent.IMAGE, "QOI image", 0, be32(h, 4), be32(h, 8))
    }
    if (asciiAt(h, 0, "%PDF-")) {
        return DetectedFile(FileContent.BINARY, "PDF document", 0)
    }
    if (startsWith(h, 0x50, 0x4B, 0x03, 0x04) ||
        startsWith(h, 0x50, 0x4B, 0x05, 0x06) ||
        startsWith(h, 0x50, 0x4B, 0x07, 0x08)
    ) {
        val zipLabel = when (ext) {
            "xlsx", "xlsm", "docx", "pptx", "odt", "ods" -> "Office document"
            "apk" -> "Android package"
            "jar" -> "Java archive"
            "aar" -> "Android library"
            else -> "ZIP archive"
        }
        return DetectedFile(FileContent.ARCHIVE, zipLabel, 0)
    }
    if (startsWith(h, 0x1F.toByte(), 0x8B.toByte())) {
        return DetectedFile(FileContent.ARCHIVE, "GZIP archive", 0)
    }
    if (asciiAt(h, 0, "BZh")) {
        return DetectedFile(FileContent.ARCHIVE, "BZIP2 archive", 0)
    }
    if (startsWith(h, 0xFD.toByte(), 0x37, 0x7A, 0x58, 0x5A, 0x00)) {
        return DetectedFile(FileContent.ARCHIVE, "XZ archive", 0)
    }
    if (startsWith(h, 0x37, 0x7A, 0xBC.toByte(), 0xAF.toByte(), 0x27, 0x1C)) {
        return DetectedFile(FileContent.ARCHIVE, "7-Zip archive", 0)
    }
    if (asciiAt(h, 0, "Rar!\u001A\u0007")) {
        return DetectedFile(FileContent.ARCHIVE, "RAR archive", 0)
    }
    if (asciiAt(h, 257, "ustar")) {
        return DetectedFile(FileContent.ARCHIVE, "TAR archive", 0)
    }
    if (asciiAt(h, 0, "SQLite format 3\u0000")) {
        return DetectedFile(FileContent.BINARY, "SQLite database", 0)
    }
    if (startsWith(h, 0x7F, 0x45, 0x4C, 0x46)) {
        return DetectedFile(FileContent.BINARY, "Linux executable", 0)
    }
    if (startsWith(h, 0xCA.toByte(), 0xFE.toByte(), 0xBA.toByte(), 0xBE.toByte())) {
        return DetectedFile(FileContent.BINARY, "Java class", 0)
    }
    if (asciiAt(h, 0, "dex\n")) {
        return DetectedFile(FileContent.BINARY, "Dalvik executable", 0)
    }
    if (startsWith(h, 0x00, 0x61, 0x73, 0x6D)) {
        return DetectedFile(FileContent.BINARY, "WebAssembly module", 0)
    }
    if (startsWith(h, 0x00, 0x01, 0x00, 0x00) || asciiAt(h, 0, "OTTO") || asciiAt(h, 0, "true")) {
        return DetectedFile(FileContent.BINARY, "Font", 0)
    }
    if (asciiAt(h, 0, "ID3") || startsWith(h, 0xFF.toByte(), 0xFB.toByte()) ||
        startsWith(h, 0xFF.toByte(), 0xF3.toByte()) || startsWith(h, 0xFF.toByte(), 0xF2.toByte())
    ) {
        return DetectedFile(FileContent.BINARY, "MP3 audio", 0)
    }
    if (asciiAt(h, 0, "RIFF") && asciiAt(h, 8, "WAVE")) {
        return DetectedFile(FileContent.BINARY, "WAV audio", 0)
    }
    if (asciiAt(h, 0, "OggS")) {
        return DetectedFile(FileContent.BINARY, "OGG media", 0)
    }
    if (h.size >= 12 && asciiAt(h, 4, "ftyp")) {
        return DetectedFile(FileContent.BINARY, "MP4 video", 0)
    }
    return null
}

/** UTF-16 signal: BOM, or NULs alternating with ASCII (no BOM). */
private fun utf16Charset(h: ByteArray): String? {
    if (h.size >= 2 && h[0] == 0xFF.toByte() && h[1] == 0xFE.toByte()) return "UTF-16LE"
    if (h.size >= 2 && h[0] == 0xFE.toByte() && h[1] == 0xFF.toByte()) return "UTF-16BE"
    var nul = 0
    var evenAscii = 0
    var oddAscii = 0
    val n = h.size.coerceAtMost(4096)
    for (i in 0 until n) {
        val b = h[i].toInt() and 0xFF
        if (b == 0) {
            nul++
        } else if (b in 0x20..0x7E || b == 0x0A || b == 0x0D || b == 0x09) {
            if (i % 2 == 0) evenAscii++ else oddAscii++
        }
    }
    if (nul > 4) {
        val total = evenAscii + oddAscii
        if (total > 0 && (evenAscii * 10 >= total * 7 || oddAscii * 10 >= total * 7)) {
            return if (evenAscii >= oddAscii) "UTF-16LE" else "UTF-16BE"
        }
    }
    return null
}

private fun maxLineLength(text: String): Int {
    var best = 0
    var cur = 0
    for (c in text) {
        if (c == '\n') {
            if (cur > best) best = cur
            cur = 0
        } else {
            cur++
        }
    }
    if (cur > best) best = cur
    return best
}

/**
 * Detects [file]'s real kind. Missing files open as empty text (preserves
 * the "new file" flow); anything unsafe for the text widget routes to an
 * info view instead of crashing it.
 */
fun detectFile(file: File): DetectedFile {
    return try {
        if (!file.exists()) {
            return DetectedFile(FileContent.TEXT, "New file", 0)
        }
        if (!file.isFile) {
            return DetectedFile(FileContent.BINARY, "Not a file", 0)
        }
        val size = try {
            file.length()
        } catch (_: Exception) {
            0L
        }
        if (size <= 0L) {
            return DetectedFile(FileContent.TEXT, "Empty file", 0)
        }
        val ext = try {
            file.extension.lowercase()
        } catch (_: Exception) {
            ""
        }
        val head = try {
            file.inputStream().use { it.readNBytes(SNIFF_BYTES) }
        } catch (_: Exception) {
            ByteArray(0)
        }
        val magic = if (head.isNotEmpty()) matchMagic(head, ext) else null
        if (size > MAX_EDIT_BYTES) {
            // Never load: label from magic when known, else generic.
            if (magic != null) return magic.copy(size = size, tooLarge = true)
            return DetectedFile(FileContent.BINARY, "Large file", size, tooLarge = true)
        }
        val bytes = try {
            file.readBytes()
        } catch (_: Exception) {
            return DetectedFile(FileContent.BINARY, "Unreadable file", size)
        }
        if (magic != null) return magic.copy(size = size)
        // NUL bytes mean binary — unless the file is really UTF-16 text.
        var hasNul = false
        for (b in bytes) {
            if (b == 0.toByte()) {
                hasNul = true
                break
            }
        }
        if (hasNul) {
            val u16 = utf16Charset(bytes)
            if (u16 != null) {
                val text = try {
                    String(bytes, charset(u16))
                } catch (_: Exception) {
                    ""
                }
                return DetectedFile(
                    FileContent.TEXT, "UTF-16 text", size, charset = u16,
                    longLine = maxLineLength(text) > MAX_EDIT_LINE
                )
            }
            return DetectedFile(
                FileContent.BINARY,
                if (ext.isEmpty()) "Binary file" else ext.uppercase() + " file",
                size
            )
        }
        val text = String(bytes, Charsets.UTF_8)
        // Control-character ratio: real text stays well under 2%.
        var bad = 0
        for (c in text) {
            val v = c.code
            if ((v < 0x20 && c != '\n' && c != '\r' && c != '\t') || v == 0x7F) {
                bad++
            }
        }
        if (text.isNotEmpty() && bad * 50 > text.length) {
            return DetectedFile(
                FileContent.BINARY,
                if (ext.isEmpty()) "Binary file" else ext.uppercase() + " file",
                size
            )
        }
        val bom = text.startsWith("\uFEFF")
        return DetectedFile(
            FileContent.TEXT, if (bom) "UTF-8 text" else "Text", size,
            longLine = maxLineLength(text) > MAX_EDIT_LINE
        )
    } catch (_: Exception) {
        // Detection itself must never crash an open: unknown becomes info.
        DetectedFile(FileContent.BINARY, "Unknown file", 0)
    }
}

/**
 * Loads a detected-TEXT file with its detected charset. Only ever called
 * when [DetectedFile.viewableText] is true, so the read is already bounded.
 * Anything unexpected yields "" (never throws, never loads binary).
 */
fun readDetectedText(file: File, detected: DetectedFile, maxChars: Int = 300_000): String {
    return try {
        if (detected.content != FileContent.TEXT || detected.tooLarge || detected.longLine) return ""
        if (!file.isFile || file.length() > MAX_EDIT_BYTES) return ""
        val cs = try {
            charset(detected.charset)
        } catch (_: Exception) {
            Charsets.UTF_8
        }
        file.readText(cs).take(maxChars)
    } catch (_: Exception) {
        ""
    }
}

/** Human size: "512 B", "1.2 KB", "3.4 MB". */
fun humanBytes(n: Long): String {
    if (n < 0) return "?"
    if (n < 1024) return "$n B"
    val kb = n / 1024.0
    if (kb < 1024) return "%.1f KB".format(kb)
    val mb = kb / 1024.0
    if (mb < 1024) return "%.1f MB".format(mb)
    return "%.2f GB".format(mb / 1024.0)
}
