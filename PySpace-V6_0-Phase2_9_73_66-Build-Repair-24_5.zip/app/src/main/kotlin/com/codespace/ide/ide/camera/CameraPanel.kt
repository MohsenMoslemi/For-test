package com.codespace.ide.ide.camera

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import com.codespace.ide.ide.theme.IdeTheme

// ---------------------------------------------------------------------------
// Camera tab. One live viewfinder (the real GPU preview), a Back/Front switch,
// Start/Stop, and a short "how to use it" snippet. Technical numbers live in a
// collapsed "Details" section. Every state shown here comes from the real
// CameraX session; the Start button only asks.
// ---------------------------------------------------------------------------

private fun camDot(s: CamState): Long = when (s) {
    CamState.IDLE -> IdeTheme.DIM
    CamState.NEEDS_PERMISSION -> IdeTheme.WARN
    CamState.DENIED -> IdeTheme.ERROR
    CamState.CONNECTING -> IdeTheme.WARN
    CamState.READY -> IdeTheme.TEAL
    CamState.STREAMING -> IdeTheme.ACCENT
    CamState.STOPPED -> IdeTheme.DIM
    CamState.ERROR -> IdeTheme.ERROR
}

@Composable
fun CameraPanel(
    cam: PhoneCamera,
    hasProject: Boolean,
    onStartRequest: (Boolean) -> Unit,
    onStop: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    LaunchedEffect(Unit) {
        try {
            cam.refreshPermissionState()
        } catch (_: Exception) {
        }
    }
    var wantFront by remember(cam.front) { mutableStateOf(cam.front) }
    var details by remember { mutableStateOf(false) }
    // Session clock: only ticks while this tab is composed and the camera is live.
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(cam.state) {
        while (cam.state == CamState.STREAMING || cam.state == CamState.READY) {
            delay(1000)
            tick++
        }
    }

    val s = cam.state
    val busy = s == CamState.CONNECTING
    val live = s == CamState.READY || s == CamState.STREAMING
    val canStart = s == CamState.IDLE || s == CamState.STOPPED ||
        s == CamState.ERROR || s == CamState.DENIED || s == CamState.NEEDS_PERMISSION

    Column(
        modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) { }
    ) {
        // ---- viewfinder (the one real preview) ----
        Box(
            Modifier.fillMaxWidth().height(260.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.Black)
                .border(1.dp, Color(IdeTheme.LINE), RoundedCornerShape(16.dp))
        ) {
            if (live) {
                AndroidView(
                    factory = { ctx ->
                        androidx.camera.view.PreviewView(ctx).apply {
                            scaleType = androidx.camera.view.PreviewView.ScaleType.FILL_CENTER
                        }
                    },
                    update = { v ->
                        try {
                            cam.setPreviewProvider(v.surfaceProvider)
                        } catch (_: Exception) {
                        }
                    },
                    onRelease = { cam.setPreviewProvider(null) },
                    modifier = Modifier.fillMaxSize()
                )
                Row(
                    Modifier.align(Alignment.TopStart).padding(10.dp)
                        .background(Color(IdeTheme.SCRIM), RoundedCornerShape(20.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("●", fontSize = 12.sp, color = Color(camDot(s)))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        (if (cam.front) "Front" else "Back") +
                            (if (s == CamState.STREAMING && cam.fps > 0) " · ${cam.fps} fps" else ""),
                        fontSize = 11.sp, color = Color(IdeTheme.ON_VIOLET)
                    )
                }
            } else {
                Column(
                    Modifier.align(Alignment.Center).padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (busy) {
                        CircularProgressIndicator(
                            Modifier.size(22.dp), strokeWidth = 2.dp, color = Color(IdeTheme.ACCENT)
                        )
                        Spacer(Modifier.height(10.dp))
                    }
                    Text(
                        camStateTitle(s), fontSize = 14.sp, fontWeight = FontWeight.Bold,
                        color = Color(IdeTheme.TEXT)
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (cam.lastError != null && s == CamState.ERROR) cam.lastError!! else cam.statusMsg,
                        fontSize = 12.sp,
                        color = Color(if (s == CamState.ERROR) IdeTheme.ERROR else IdeTheme.DIM)
                    )
                }
            }
        }
        if (s == CamState.DENIED) {
            TextButton(onClick = onOpenSettings, modifier = Modifier.fillMaxWidth()) {
                Text("Open Android Settings to allow the camera", color = Color(IdeTheme.ACCENT), fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(12.dp))

        // ---- controls: Back / Front + Start / Stop ----
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                    .background(Color(IdeTheme.CARD))
                    .border(1.dp, Color(IdeTheme.LINE), RoundedCornerShape(12.dp))
                    .padding(3.dp)
            ) {
                FacingChip("Back", !wantFront, Modifier.weight(1f)) {
                    wantFront = false
                    if (live) {
                        onStop()
                        onStartRequest(false)
                    }
                }
                FacingChip("Front", wantFront, Modifier.weight(1f)) {
                    wantFront = true
                    if (live) {
                        onStop()
                        onStartRequest(true)
                    }
                }
            }
            if (live) {
                Button(
                    onClick = onStop,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(IdeTheme.CARD), contentColor = Color(IdeTheme.ERROR)
                    ),
                    modifier = Modifier.weight(1f)
                ) { Text("■  Stop", fontWeight = FontWeight.Bold) }
            } else {
                Button(
                    enabled = canStart && !busy && hasProject,
                    onClick = { onStartRequest(wantFront) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(IdeTheme.ACCENT), contentColor = Color(IdeTheme.ON_ACCENT)
                    ),
                    modifier = Modifier.weight(1f)
                ) { Text(if (s == CamState.ERROR) "↻  Retry" else "▶  Start", fontWeight = FontWeight.Bold) }
            }
        }
        if (!hasProject) {
            Text(
                "Open a project to use the camera.",
                fontSize = 11.sp, color = Color(IdeTheme.DIM),
                modifier = Modifier.padding(top = 6.dp, start = 4.dp)
            )
        }
        if (!cam.hasFront && s != CamState.IDLE && s != CamState.STOPPED) {
            Text(
                "Front camera not detected on this device.",
                fontSize = 11.sp, color = Color(IdeTheme.DIM),
                modifier = Modifier.padding(top = 6.dp, start = 4.dp)
            )
        }
        Spacer(Modifier.height(14.dp))

        // ---- how to use it ----
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                .background(Color(IdeTheme.CARD))
                .padding(14.dp)
        ) {
            Text("Use it in your code", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(IdeTheme.TEXT))
            Spacer(Modifier.height(8.dp))
            Text(
                "import cv2\ncap = cv2.VideoCapture(0)   # 0 = back, 1 = front\nok, frame = cap.read()",
                fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                color = Color(IdeTheme.STRING),
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                    .background(Color(IdeTheme.BG)).padding(10.dp)
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "The camera starts by itself when your program runs. This tab is only for checking the picture.",
                fontSize = 11.sp, color = Color(IdeTheme.DIM)
            )
        }
        Spacer(Modifier.height(10.dp))

        // ---- details (collapsed) ----
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                .clickable { details = !details }
                .padding(horizontal = 6.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Details", fontSize = 12.sp, color = Color(IdeTheme.DIM), modifier = Modifier.weight(1f))
            Text(if (details) "▴" else "▾", fontSize = 12.sp, color = Color(IdeTheme.DIM))
        }
        if (details) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                    .background(Color(IdeTheme.CARD)).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                InfoRow("Status", camStateTitle(s))
                InfoRow("Resolution", if (live && cam.frameW > 0) "${cam.frameW}×${cam.frameH}" else "—")
                InfoRow("Camera FPS", if (s == CamState.STREAMING) "${cam.fps}" else "—")
                InfoRow("Python readers", if (cam.serverUp) "${cam.clients}" else "bridge down")
                InfoRow("Session", if (live) "${cam.sessionSeconds()}s" else "—")
                if (tick < 0) Text("") // keeps the 1 s clock observed
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun FacingChip(
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier.clip(RoundedCornerShape(10.dp))
            .background(if (selected) Color(IdeTheme.ACCENT) else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label, fontSize = 13.sp, fontWeight = FontWeight.Bold,
            color = Color(if (selected) IdeTheme.ON_ACCENT else IdeTheme.TEXT)
        )
    }
}

@Composable
private fun InfoRow(k: String, v: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(k, fontSize = 12.sp, color = Color(IdeTheme.DIM), modifier = Modifier.weight(1f))
        Text(v, fontSize = 12.sp, color = Color(IdeTheme.TEXT))
    }
}
