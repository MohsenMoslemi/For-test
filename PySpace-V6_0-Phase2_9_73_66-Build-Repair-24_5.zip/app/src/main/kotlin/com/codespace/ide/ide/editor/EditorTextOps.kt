package com.codespace.ide.ide.editor

import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.AnnotatedString
import com.codespace.ide.ide.codeintel.PythonSyntaxDiagnostic
import com.codespace.ide.ide.dedentTarget
import com.codespace.ide.ide.enterPlan
import com.codespace.ide.ide.smartBackspace
import kotlin.math.abs

/**
 * Applies editor smart behavior to a raw text change. The edit is recognised relative to the CURSOR
 * (exact even when the typed character equals its neighbour) and only for keystroke-sized changes,
 * so pasted text is never touched:
 *  - Tab becomes spaces;
 *  - Enter: block/bracket aware indentation (see [enterPlan]);
 *  - ':' typed on else/elif/except/finally: the line lines up with its if/try (see [dedentTarget]);
 *  - Backspace inside indentation removes one whole level (see [smartBackspace]).
 * Returns the adjusted full text and the adjusted cursor offset.
 */
fun applySmartEdit(old: String, new: String, cursor: Int, tabWidth: Int, autoIndent: Boolean): Pair<String, Int> {
    var text = new
    var cur = cursor.coerceIn(0, text.length)
    var hadTab = false
    if (text.contains('\t')) {
        hadTab = true
        val spaces = " ".repeat(tabWidth)
        var shift = 0
        val b = StringBuilder(text.length + 8)
        text.forEachIndexed { idx, c ->
            if (c == '\t') {
                b.append(spaces)
                if (idx < cur) shift += spaces.length - 1
            } else {
                b.append(c)
            }
        }
        text = b.toString()
        cur = (cur + shift).coerceIn(0, text.length)
    }
    if (!autoIndent || hadTab) return text to cur
    val tab = tabWidth.coerceAtLeast(1)
    if (text.length == old.length + 1 && cur >= 1) {
        val i = cur - 1
        if (old.regionMatches(0, text, 0, i) && old.regionMatches(i, text, i + 1, old.length - i)) {
            val ch = text[i]
            if (ch == '\n') {
                val plan = enterPlan(text.substring(0, i), text.substring(i + 1), tab)
                val sb = StringBuilder(text.length + plan.indent.length * 2 + 4)
                sb.append(plan.prefix).append('\n').append(plan.indent)
                val nc = sb.length
                if (plan.split) sb.append('\n').append(plan.closeIndent)
                sb.append(text, i + 1, text.length)
                return sb.toString() to nc
            }
            if (ch == ':') {
                val r = dedentTarget(text, cur, tab)
                if (r != null) {
                    val nt = text.substring(0, r.lineStart) + " ".repeat(r.newIndent) +
                        text.substring(r.lineStart + r.oldLead)
                    return nt to (cur - (r.oldLead - r.newIndent)).coerceIn(0, nt.length)
                }
            }
        }
    } else if (text.length == old.length - 1) {
        val r = smartBackspace(old, text, cur, tab)
        if (r != null) return r
    }
    return text to cur
}

/** Line (1-based) and column (0-based) of [offset]: scans only, never
 *  allocates a substring — this runs on every keystroke. */
internal fun lineColAt(text: String, offset: Int): IntArray {
    val off = offset.coerceIn(0, text.length)
    var line = 1
    var lineStart = 0
    for (i in 0 until off) {
        if (text[i] == '\n') {
            line++
            lineStart = i + 1
        }
    }
    return intArrayOf(line, off - lineStart)
}

/** [start, end) offsets of 1-based line [ln] (end excludes '\n'), or null. */
internal fun lineRangeOf(text: String, ln: Int): IntRange? {
    if (ln < 1) return null
    var start = 0
    if (ln > 1) {
        var line = 1
        var found = false
        for (i in text.indices) {
            if (text[i] == '\n') {
                line++
                if (line == ln) {
                    start = i + 1
                    found = true
                    break
                }
            }
        }
        if (!found) return null
    }
    var end = text.length
    for (i in start until text.length) {
        if (text[i] == '\n') {
            end = i
            break
        }
    }
    if (start > end) return null
    return start..end
}

/** Buffer offset at the end of a 1-based line [ln], before its newline. */
internal fun offsetOfLineEnd(text: String, ln: Int): Int {
    val line = lineRangeOf(text, ln) ?: return text.length
    return line.last.coerceIn(0, text.length)
}

/** Returns the innermost unmatched call parenthesis at the caret, ignoring
 * comments and quoted strings. LSP remains authoritative for the signature;
 * this lightweight lexical gate prevents cards appearing in unrelated text. */
internal fun findPythonCallContext(source: String, rawCaret: Int): Int? {
    val caret = rawCaret.coerceIn(0, source.length)
    val stack = ArrayList<Int>()
    var quote: Char? = null
    var triple = false
    var escaped = false
    var comment = false
    var i = 0
    while (i < caret) {
        val c = source[i]
        if (comment) { if (c == '\n') comment = false; i++; continue }
        if (quote != null) {
            if (escaped) { escaped = false; i++; continue }
            if (c == '\\') { escaped = true; i++; continue }
            if (triple && i + 2 < caret && source[i] == quote && source[i + 1] == quote && source[i + 2] == quote) {
                quote = null; triple = false; i += 3; continue
            }
            if (!triple && c == quote) quote = null
            i++; continue
        }
        if (c == '#') { comment = true; i++; continue }
        if ((c == '\'' || c == '"') ) {
            quote = c
            triple = i + 2 < caret && source[i + 1] == c && source[i + 2] == c
            i += if (triple) 3 else 1
            continue
        }
        when (c) {
            '(' -> stack.add(i)
            ')' -> if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex)
        }
        i++
    }
    val open = stack.lastOrNull() ?: return null
    var before = open - 1
    while (before >= 0 && source[before].isWhitespace()) before--
    if (before < 0) return null
    val c = source[before]
    if (!(c.isLetterOrDigit() || c == '_' || c in ")]")) return null
    return open
}

/** Returns the complete visible source line for a diagnostic. CPython's
 *  offsets can point at a missing token or the end-of-line, which produced
 *  zero-width/one-character ranges on mobile. Highlighting the whole line is
 *  both reliable and makes the diagnostic visible at a glance. */
internal fun syntaxDiagnosticRange(text: String, diagnostic: PythonSyntaxDiagnostic): IntRange? {
    val line = lineRangeOf(text, diagnostic.line) ?: return null
    val start = line.first
    val endExclusive = if (line.last < text.length && text[line.last] == '\n') {
        line.last
    } else (line.last + 1).coerceAtMost(text.length)
    return if (endExclusive > start) start until endExclusive else null
}

internal fun findNearestRenamedToken(source: String, name: String, expectedOffset: Int): Int {
    if (name.isEmpty() || source.isEmpty()) return expectedOffset.coerceIn(0, source.length)
    var from = 0
    var best = -1
    var bestDistance = Int.MAX_VALUE
    while (from <= source.length - name.length) {
        val found = source.indexOf(name, from)
        if (found < 0) break
        val beforeOk = found == 0 || !(source[found - 1].isLetterOrDigit() || source[found - 1] == '_')
        val after = found + name.length
        val afterOk = after == source.length || !(source[after].isLetterOrDigit() || source[after] == '_')
        if (beforeOk && afterOk) {
            val distance = kotlin.math.abs(found - expectedOffset)
            if (distance < bestDistance) {
                best = found
                bestDistance = distance
            }
        }
        from = found + 1
    }
    return if (best >= 0) (best + name.length).coerceIn(0, source.length)
    else expectedOffset.coerceIn(0, source.length)
}

internal const val NBSP = '\u00A0'

/** Replaces the leading spaces of every line by no-break spaces (same length, same spans). */
internal fun glueLeadingIndent(a: AnnotatedString): AnnotatedString {
    val t = a.text
    var sb: StringBuilder? = null
    var atIndent = true
    for (i in t.indices) {
        val c = t[i]
        if (c == '\n') atIndent = true
        else if (atIndent && c == ' ') {
            if (sb == null) sb = StringBuilder(t)
            sb.setCharAt(i, NBSP)
        } else atIndent = false
    }
    return if (sb == null) a else AnnotatedString(sb.toString(), a.spanStyles, a.paragraphStyles)
}

/** Equality of two display strings, treating the glue no-break spaces as plain spaces. */
internal fun sameDisplay(a: String, b: String): Boolean {
    if (a.length != b.length) return false
    if (a == b) return true
    for (i in a.indices) {
        val x = a[i]
        val y = b[i]
        if (x != y && !((x == NBSP && y == ' ') || (x == ' ' && y == NBSP))) return false
    }
    return true
}

/** Offsets at which each logical line of [text] starts (always at least one entry). */
internal fun lineStartOffsets(text: String): IntArray {
    var count = 1
    var i = text.indexOf('\n')
    while (i >= 0) {
        count++
        i = text.indexOf('\n', i + 1)
    }
    val starts = IntArray(count)
    var k = 1
    i = text.indexOf('\n')
    while (i >= 0) {
        starts[k++] = i + 1
        i = text.indexOf('\n', i + 1)
    }
    return starts
}
