package com.codespace.ide.ide.editor

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.focus.FocusManager
import kotlinx.coroutines.delay

/** Coordinates focus loss and caret reveal with the animated software-keyboard inset. */
@Composable
fun EditorImeCaretEffects(
    active: Boolean,
    imeVisible: Boolean,
    firstTapPending: Boolean,
    hasCaretInteraction: Boolean,
    caretLine: Int,
    caretColumn: Int,
    focusManager: FocusManager,
    pinCaretToView: suspend (Int, Int) -> Unit,
) {
    val firstImePin = remember { booleanArrayOf(true) }

    LaunchedEffect(active, focusManager) {
        if (!active) {
            try { focusManager.clearFocus(force = true) } catch (_: Exception) { }
        }
    }

    LaunchedEffect(imeVisible) {
        // The initial hidden pass must not move a restored document to its caret.
        if (firstImePin[0]) {
            firstImePin[0] = false
            if (!imeVisible) return@LaunchedEffect
        }
        if (imeVisible) {
            // Let the first tap place the caret before following it.
            if (firstTapPending) {
                delay(120)
                if (firstTapPending) return@LaunchedEffect
            }
            if (!hasCaretInteraction) return@LaunchedEffect
            delay(100)
            if (firstTapPending || !hasCaretInteraction) return@LaunchedEffect
            // Sequential passes track the keyboard's animated inset without
            // launching competing scroll animations.
            pinCaretToView(caretLine, caretColumn)
            delay(150)
            pinCaretToView(caretLine, caretColumn)
            delay(250)
            pinCaretToView(caretLine, caretColumn)
        } else if (hasCaretInteraction && !firstTapPending) {
            pinCaretToView(caretLine, caretColumn)
        }
    }
}
