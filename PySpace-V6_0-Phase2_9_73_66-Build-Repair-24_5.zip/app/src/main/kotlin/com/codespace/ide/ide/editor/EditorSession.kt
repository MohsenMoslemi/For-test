package com.codespace.ide.ide.editor

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.codespace.ide.domain.editor.model.EditorDocumentBuffer
import com.codespace.ide.ide.DetectedFile
import com.codespace.ide.ide.FileContent
import com.codespace.ide.ide.detectFile
import com.codespace.ide.ide.files.safeWriteText
import com.codespace.ide.ide.projects.PyProject
import com.codespace.ide.ide.readDetectedText
import java.io.File
import com.codespace.ide.domain.editor.model.EditorTextSnapshot
import com.codespace.ide.ide.JSON

/**
 * One open editor tab with in-memory buffer + dirty tracking.
 *
 * The file's real kind is detected from CONTENT at open time (never from
 * the extension alone): only safe text is ever loaded into the editable
 * buffer. Anything else (image, archive, binary, oversized) shows a viewer
 * instead — and save()/reload() refuse to touch it, so closing such a tab
 * can never truncate the file to zero bytes.
 */
class OpenTab(
    val file: File,
    preparedDetected: DetectedFile? = null,
    initialText: String? = null,
) {
    val detected: DetectedFile = preparedDetected ?: try {
        detectFile(file)
    } catch (_: Exception) {
        DetectedFile(FileContent.BINARY, "Unknown file", 0)
    }

    /** True only when the text editor may load and save this file. */
    val editable: Boolean get() = detected.viewableText

    private val documentBuffer = EditorDocumentBuffer(
        initialText ?: if (editable) readDetectedText(file, detected) else "",
    )
    var text by mutableStateOf(documentBuffer.text)
        private set
    private val editHistory = EditorEditHistory()

    /** Fold state belongs to the open document, so switching tabs does not reopen every block. */
    var collapsedFoldKeys by mutableStateOf(emptySet<String>())

    val canUndo: Boolean get() = editHistory.canUndo
    val canRedo: Boolean get() = editHistory.canRedo

    /** Apply a user-visible edit and retain the previous buffer/caret for undo. */
    fun applyEdit(newText: String, selectionStart: Int, selectionEnd: Int = selectionStart) {
        if (!editable || newText == text) return
        editHistory.record(EditorTextSnapshot(text, selectionStart, selectionEnd))
        documentBuffer.replace(newText)
        text = newText
    }

    /** Apply a non-history replacement (undo/redo or trusted synchronization). */
    fun replaceText(newText: String) {
        if (!editable) return
        documentBuffer.replace(newText)
        text = newText
    }

    fun undo(selectionStart: Int, selectionEnd: Int): EditorTextSnapshot? {
        if (!editable) return null
        val result = editHistory.undo(EditorTextSnapshot(text, selectionStart, selectionEnd)) ?: return null
        documentBuffer.replace(result.text)
        text = result.text
        return result
    }

    fun redo(selectionStart: Int, selectionEnd: Int): EditorTextSnapshot? {
        if (!editable) return null
        val result = editHistory.redo(EditorTextSnapshot(text, selectionStart, selectionEnd)) ?: return null
        documentBuffer.replace(result.text)
        text = result.text
        return result
    }

    val name: String get() = file.name
    val dirty: Boolean get() = documentBuffer.isDirty

    // Where the user left this tab: restored when the tab is shown again
    // (tab switch, leaving/re-entering the project, app restart). Plain vars:
    // the editor writes them continuously and nothing observes them.
    var scrollY: Int = 0
    var scrollX: Int = 0
    var selStart: Int = -1
    var selEnd: Int = -1
    /** True once the user has actually been in this tab's editor. */
    var hasView: Boolean = false

    /** Marks only the exact snapshot written to disk as saved. If the user typed
     * during the write, the newer buffer remains dirty. */
    internal fun markSaved(snapshot: String) {
        documentBuffer.markSaved(snapshot)
    }

    fun reload() {
        if (!editable) return
        val loadedText = readDetectedText(file, detected)
        documentBuffer.resetFromDisk(loadedText)
        text = loadedText
        editHistory.clear()
    }
}

/** Compatibility aliases for immutable domain persistence models. */
typealias EditorTabSessionSnapshot = com.codespace.ide.domain.editor.model.EditorTabSessionSnapshot
typealias EditorSessionSnapshot = com.codespace.ide.domain.editor.model.EditorSessionSnapshot

/** Per-project editor session: tabs, selection, file-tree expansion. */
class EditorSession(val project: PyProject) {
    /** Called when a tab is closed from the editor UI; feature sessions may remain cached. */
    var onTabClosed: ((OpenTab) -> Unit)? = null
    /** Called when an underlying file/folder is moved, renamed or deleted, even if no tab is open. */
    var onPathRemoved: ((File) -> Unit)? = null

    // Observable collections: tab open/close and tree expand/collapse must
    // recompose their readers (plain lists/maps would silently go stale).
    val tabs = mutableStateListOf<OpenTab>()
    var activeIndex by mutableStateOf(-1)
    val expanded = mutableStateMapOf<String, Boolean>()
    var treeVersion by mutableStateOf(0)
    /** Changes only when filesystem contents change; expansion/sort does not recount files. */
    var treeContentVersion by mutableStateOf(0)
    /** 0 = sort by name, 1 = sort by type then name. */
    var sortMode by mutableStateOf(0)
    /** Reveal hidden folders (.venv, .git, …). Off by default for speed. */
    var showHidden by mutableStateOf(false)
    /** Tree view: 0 = Project (smart structure), 1 = All files (raw, incl. hidden). */
    var treeViewMode by mutableStateOf(0)
    /** Cursor jump request from structure/search panels: file path + 1-based line. */
    var jumpRequest by mutableStateOf<Pair<String, Int>?>(null)
    /** Breadcrumb request to reveal and briefly highlight a project-tree path. */
    var treeRevealRequest by mutableStateOf<Pair<String, Int>?>(null)
    private var treeRevealSequence = 0

    fun revealTreePath(file: File) {
        treeRevealSequence += 1
        treeRevealRequest = file.absoluteFile.absolutePath to treeRevealSequence
    }

    init {
        // The project root node starts expanded (tree = root + children).
        try {
            expanded[project.dir.absolutePath] = true
        } catch (_: Exception) {
        }
    }

    val active: OpenTab? get() = tabs.getOrNull(activeIndex)

    /** Adds a document whose content was already inspected on a worker thread. */
    fun openLoadedTab(file: File, detected: DetectedFile, text: String, activate: Boolean = true): OpenTab {
        val existing = tabs.indexOfFirst { it.file.absolutePath == file.absolutePath }
        if (existing >= 0) {
            if (activate) activeIndex = existing
            return tabs[existing]
        }
        val tab = OpenTab(file, detected, text)
        tabs.add(tab)
        if (activate) activeIndex = tabs.lastIndex
        return tab
    }

    fun closeTab(i: Int) {
        if (i !in tabs.indices) return
        val closed = tabs.removeAt(i)
        try { onTabClosed?.invoke(closed) } catch (_: Exception) { }
        activeIndex = when {
            tabs.isEmpty() -> -1
            i < activeIndex -> activeIndex - 1
            i == activeIndex -> (i - 1).coerceAtLeast(0)
            else -> activeIndex
        }
    }

    /** Closes every tab. Callers decide what happens to unsaved changes first (dialog). */
    fun closeAllTabs() {
        val closed = tabs.toList()
        tabs.clear()
        closed.forEach { tab ->
            try { onTabClosed?.invoke(tab) } catch (_: Exception) { }
        }
        activeIndex = -1
    }

    /** Removes tabs after their dirty buffers have been persisted asynchronously. */
    fun removeTabsUnder(file: File) {
        val p = file.absolutePath
        try { onPathRemoved?.invoke(file) } catch (_: Exception) { }
        val activePath = active?.file?.absolutePath
        val previousIndex = activeIndex
        for (i in tabs.indices.reversed()) {
            val tp = tabs[i].file.absolutePath
            if (tp == p || tp.startsWith(p + "/")) {
                val removed = tabs.removeAt(i)
                try { onTabClosed?.invoke(removed) } catch (_: Exception) { }
            }
        }
        val preserved = activePath?.let { path -> tabs.indexOfFirst { it.file.absolutePath == path } } ?: -1
        activeIndex = when {
            tabs.isEmpty() -> -1
            preserved >= 0 -> preserved
            else -> previousIndex.coerceIn(0, tabs.lastIndex)
        }
    }

    fun refreshTree(contentChanged: Boolean = true) {
        treeVersion++
        if (contentChanged) treeContentVersion++
    }

    /** Capture Compose-owned tab metadata on Main without doing JSON work. */
    fun persistenceSnapshot(): EditorSessionSnapshot = EditorSessionSnapshot(
        activeIndex = activeIndex,
        tabs = tabs.map { tab ->
            EditorTabSessionSnapshot(
                path = tab.file.absolutePath,
                scrollY = tab.scrollY,
                scrollX = tab.scrollX,
                selectionStart = tab.selStart,
                selectionEnd = tab.selEnd,
                hasView = tab.hasView,
            )
        },
    )

}
