package com.codespace.ide.ide.editor

import androidx.compose.runtime.Stable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.LayoutCoordinates

/**
 * Per-document geometry registry for the editor surface.
 *
 * Compose owns the live layout coordinates; popup anchors and hit-test entries
 * are kept beside them so every overlay uses the same coordinate lifetime.
 * This holder deliberately contains no document, selection, or scroll state.
 */
@Stable
internal class EditorSurfaceCoordinatesState {
    var viewport: LayoutCoordinates? by mutableStateOf(null)
    var field: LayoutCoordinates? by mutableStateOf(null)
    var editorBox: LayoutCoordinates? by mutableStateOf(null)
    var gesture: LayoutCoordinates? by mutableStateOf(null)

    val popupHitCoordinates = HashMap<Int, LayoutCoordinates>()
    val caretAnchor = AnchorMemo()
    val documentationAnchor = AnchorMemo()

    fun isTapOnPopup(position: Offset, host: LayoutCoordinates, slopPx: Float): Boolean =
        EditorPopupHitTester.contains(
            position = position,
            host = host,
            popupCoordinates = popupHitCoordinates.values,
            slopPx = slopPx
        )

    fun clearInvalidPopupCoordinates() {
        popupHitCoordinates.entries.removeAll { !it.value.isAttached }
    }
}
