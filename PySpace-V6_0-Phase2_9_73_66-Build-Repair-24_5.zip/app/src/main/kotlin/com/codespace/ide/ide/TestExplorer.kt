package com.codespace.ide.ide

import android.content.Context
import android.util.Base64
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ProotManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import com.codespace.ide.ide.projects.PyProject
import com.codespace.ide.ide.testing.TestControllerRegistry
import com.codespace.ide.ide.testing.TestSnapshot
import com.codespace.ide.ide.testing.TestStatus
import com.codespace.ide.ide.theme.IdeTheme

@Composable
fun TestView(proot: ProotManager, project: PyProject?, modifier: Modifier = Modifier,
    onOpenLocation: ((String, Int) -> Unit)? = null,
    onSaveBeforeRun: (((Boolean, String?) -> Unit) -> Unit)? = null) {
    val controller = remember(project?.dir?.absolutePath) { project?.let { TestControllerRegistry.get(it) } }
    val state = controller?.state?.collectAsState()?.value ?: TestSnapshot(output = "Open a project to run tests.")
    val expandedFiles = controller?.expandedFiles?.collectAsState()?.value.orEmpty()
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val clipboard = LocalClipboardManager.current
    val outputScroll = rememberScrollState()
    val runnerScript = remember { runCatching { context.assets.open("pyspace_test_runner.py").bufferedReader().use { it.readText() } }.getOrDefault("") }
    var query by remember { mutableStateOf("") }
    var statusFilter by remember { mutableStateOf("All") }
    var page by remember { mutableStateOf("Tests") }
    var expandedId by remember { mutableStateOf<String?>(null) }
    var settingsOpen by remember { mutableStateOf(false) }
    var showHistoryClear by remember { mutableStateOf(false) }
    var savingBeforeRun by remember { mutableStateOf(false) }

    fun runTests(targetIds: List<String> = emptyList()) {
        val targetProject = project ?: return
        if (state.running || state.discovering || savingBeforeRun) return
        if (onSaveBeforeRun == null) {
            controller?.run(proot, targetProject, runnerScript, targetIds)
            return
        }
        savingBeforeRun = true
        onSaveBeforeRun { saved, error ->
            savingBeforeRun = false
            if (saved) controller?.run(proot, targetProject, runnerScript, targetIds)
            else Toast.makeText(context, error?.takeIf { it.isNotBlank() } ?: "Tests were not started because editor files could not be saved.", Toast.LENGTH_LONG).show()
        }
    }

    LaunchedEffect(Unit) { focusManager.clearFocus(force = true); keyboardController?.hide() }
    LaunchedEffect(project?.dir?.absolutePath) {
        if (project != null && controller != null) {
            val prefs = context.getSharedPreferences("pyspace_test_explorer_v2", Context.MODE_PRIVATE)
            val legacy = context.getSharedPreferences("pyspace_test_history", Context.MODE_PRIVATE)
                .getString("${project.dir.absolutePath}:history", "").orEmpty().split("\n").filter { it.isNotBlank() }
            controller.restore(prefs.getString(project.dir.absolutePath, "").orEmpty(), legacy)
            if (controller.snapshot.cases.isEmpty() && !controller.snapshot.discovering && runnerScript.isNotBlank()) controller.discover(proot, project, runnerScript)
        }
    }
    LaunchedEffect(state) {
        if (project != null && controller != null) context.getSharedPreferences("pyspace_test_explorer_v2", Context.MODE_PRIVATE)
            .edit().putString(project.dir.absolutePath, controller.serialize()).apply()
    }
    // Persist the last immutable controller snapshot synchronously at the UI
    // boundary before the panel/project leaves composition. The controller may
    // be evicted in the same navigation event that disposes this panel.
    DisposableEffect(project?.dir?.absolutePath, controller) {
        onDispose {
            if (project != null && controller != null) {
                context.getSharedPreferences("pyspace_test_explorer_v2", Context.MODE_PRIVATE)
                    .edit().putString(project.dir.absolutePath, controller.serialize()).apply()
            }
        }
    }
    LaunchedEffect(state.output) { if (state.running) outputScroll.animateScrollTo(outputScroll.maxValue) }

    val panelInputModifier = Modifier
        .pointerInput(Unit) {
            awaitPointerEventScope {
                while (true) {
                    val event = awaitPointerEvent(PointerEventPass.Initial)
                    if (event.changes.any { it.pressed && !it.previousPressed }) {
                        // Clear stale editor/search focus first; an actual TextField can request it again in Main pass.
                        focusManager.clearFocus(force = true)
                        keyboardController?.hide()
                    }
                }
            }
        }
        .pointerInput(Unit) {
            awaitPointerEventScope {
                while (true) {
                    val event = awaitPointerEvent(PointerEventPass.Final)
                    event.changes.forEach { change -> if (change.pressed) change.consume() }
                }
            }
        }

    Column(modifier.fillMaxSize().then(panelInputModifier).background(Color(IdeTheme.PANEL)).padding(9.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("TESTS", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(state.detectedFramework.ifBlank { state.framework }.uppercase(Locale.ROOT), color = Color(IdeTheme.DIM), fontSize = 8.sp)
            Spacer(Modifier.weight(1f))
            TextButton(enabled = project != null && !state.running && !state.discovering && !savingBeforeRun && runnerScript.isNotBlank(), onClick = { project?.let { controller?.discover(proot, it, runnerScript) } }, contentPadding = PaddingValues(horizontal = 5.dp)) { Text("↻", fontSize = 15.sp) }
            TextButton(onClick = { settingsOpen = true }, contentPadding = PaddingValues(horizontal = 5.dp)) { Text("⚙", fontSize = 15.sp) }
            if (state.running) TextButton(onClick = { controller?.stop() }, contentPadding = PaddingValues(horizontal = 6.dp)) { Text("■ Stop", color = Color(IdeTheme.ERROR), fontSize = 10.sp) }
            else Button(enabled = project != null && !state.running && !state.discovering && !savingBeforeRun && runnerScript.isNotBlank(), onClick = { runTests() }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(IdeTheme.ACCENT))) { Text("▶ Run All", fontSize = 10.sp) }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            val passed = state.cases.count { it.status == TestStatus.PASSED }
            val failed = state.cases.count { it.status == TestStatus.FAILED || it.status == TestStatus.XPASSED }
            val skipped = state.cases.count { it.status == TestStatus.SKIPPED }
            val xfailed = state.cases.count { it.status == TestStatus.XFAILED }
            SummaryPill("${state.cases.size} Total", IdeTheme.DIM.toInt()); SummaryPill("$passed Passed", 0xFF4CAF50.toInt())
            SummaryPill("$failed Failed", IdeTheme.ERROR.toInt()); SummaryPill("$skipped Skipped", 0xFFFFB74D.toInt())
            if (xfailed > 0) SummaryPill("$xfailed XFail", 0xFFFFB74D.toInt())
            if (state.coveragePercent.isNotBlank()) SummaryPill("Cov ${state.coveragePercent}", 0xFF64B5F6.toInt())
        }
        if (state.running || state.discovering || savingBeforeRun) {
            if (savingBeforeRun) Text("Saving modified files before running tests…", color = Color(IdeTheme.DIM), fontSize = 9.sp)
            LinearProgressIndicator(Modifier.fillMaxWidth(), color = Color(IdeTheme.ACCENT))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf("Tests", "Coverage", "Insights", "Output", "History").forEach { item ->
                FilterChip(selected = page == item, onClick = { page = item }, label = { Text(item, fontSize = 10.sp) })
            }
            Spacer(Modifier.weight(1f))
            if (state.cases.any { it.status == TestStatus.FAILED || it.status == TestStatus.XPASSED } && !state.running && !savingBeforeRun) TextButton(onClick = { runTests(state.cases.filter { t -> t.status == TestStatus.FAILED || t.status == TestStatus.XPASSED }.map { t -> t.id }) }, contentPadding = PaddingValues(horizontal = 4.dp)) { Text("Run Failed", color = Color(IdeTheme.ERROR), fontSize = 9.sp) }
        }

        when (page) {
            "Tests" -> {
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    BasicTextField(value = query, onValueChange = { query = it }, singleLine = true,
                        modifier = Modifier.weight(1f).background(Color(IdeTheme.CARD), RoundedCornerShape(6.dp)).padding(horizontal = 9.dp, vertical = 7.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color(IdeTheme.TEXT), fontSize = 11.sp),
                        decorationBox = { inner -> if (query.isEmpty()) Text("Search tests…", color = Color(IdeTheme.DIM), fontSize = 11.sp); inner() })
                    TextButton(onClick = { controller?.selectAll(state.cases.filter { matchesTest(it, query, statusFilter) }.map { it.id }.toSet(), true) }, contentPadding = PaddingValues(horizontal = 4.dp)) { Text("Select", fontSize = 9.sp) }
                    TextButton(onClick = { controller?.selectAll(state.cases.map { it.id }.toSet(), false) }, contentPadding = PaddingValues(horizontal = 4.dp)) { Text("Clear", fontSize = 9.sp) }
                }
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("All", "Failed", "Passed", "Skipped", "Not run").forEach { item ->
                        FilterChip(selected = statusFilter == item, onClick = { statusFilter = item }, label = { Text(item, fontSize = 9.sp) })
                    }
                }
                val visible = state.cases.filter { matchesTest(it, query, statusFilter) }
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${visible.size} shown", color = Color(IdeTheme.DIM), fontSize = 9.sp)
                    Spacer(Modifier.weight(1f))
                    val selected = state.cases.filter { it.selected }
                    TextButton(enabled = selected.isNotEmpty() && !state.running && !savingBeforeRun, onClick = { runTests(selected.map { t -> t.id }) }, contentPadding = PaddingValues(horizontal = 5.dp)) { Text("▶ Run Selected (${selected.size})", color = Color(IdeTheme.ACCENT), fontSize = 9.sp) }
                    TextButton(enabled = !state.running, onClick = { controller?.clearResults() }, contentPadding = PaddingValues(horizontal = 5.dp)) { Text("Clear Results", fontSize = 9.sp) }
                }
                if (visible.isEmpty()) {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(if (state.discovering) "Discovering tests…" else if (state.cases.isEmpty()) state.output else "No tests match this filter.", color = Color(IdeTheme.DIM), fontSize = 11.sp)
                    }
                } else {
                    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                        visible.groupBy { it.file.ifBlank { "(unknown file)" } }.forEach { (file, fileCases) ->
                            val isFileExpanded = expandedFiles.contains(file)
                            val passedInFile = fileCases.count { it.status == TestStatus.PASSED }
                            val failedInFile = fileCases.count { it.status == TestStatus.FAILED || it.status == TestStatus.XPASSED }
                            val skippedInFile = fileCases.count { it.status == TestStatus.SKIPPED }
                            val xfailedInFile = fileCases.count { it.status == TestStatus.XFAILED }
                            item(key = "file:$file") {
                                Row(
                                    Modifier.fillMaxWidth()
                                        .padding(top = 5.dp, bottom = 3.dp)
                                        .background(Color(IdeTheme.CARD), RoundedCornerShape(7.dp))
                                        .clickable { controller?.toggleFile(file) }
                                        .padding(start = 9.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(if (isFileExpanded) "▾" else "▸", color = Color(IdeTheme.ACCENT), fontSize = 14.sp)
                                    Spacer(Modifier.width(7.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(file, color = Color(IdeTheme.TEXT), fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                        Text(
                                            buildString {
                                                append("${fileCases.size} tests")
                                                if (passedInFile > 0) append("  ·  $passedInFile passed")
                                                if (failedInFile > 0) append("  ·  $failedInFile failed")
                                                if (skippedInFile > 0) append("  ·  $skippedInFile skipped")
                                                if (xfailedInFile > 0) append("  ·  $xfailedInFile xfailed")
                                            },
                                            color = Color(IdeTheme.DIM), fontSize = 8.sp, maxLines = 1
                                        )
                                    }
                                    TextButton(
                                        enabled = !state.running && !savingBeforeRun,
                                        onClick = { runTests(fileCases.map { t -> t.id }) },
                                        contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp)
                                    ) { Text("Run file", fontSize = 8.sp) }
                                }
                            }
                            if (isFileExpanded) {
                                fileCases.groupBy { it.className.ifBlank { "Functions / module" } }.forEach { (className, classCases) ->
                                    item(key = "class:$file:$className") {
                                        Row(Modifier.fillMaxWidth().padding(start = 12.dp, top = 2.dp, bottom = 1.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Text(className, color = Color(IdeTheme.DIM), fontSize = 9.sp, modifier = Modifier.weight(1f))
                                            TextButton(enabled = !state.running && !savingBeforeRun, onClick = { runTests(classCases.map { t -> t.id }) }, contentPadding = PaddingValues(horizontal = 3.dp, vertical = 0.dp)) { Text("Run class", fontSize = 8.sp) }
                                        }
                                    }
                                    items(classCases, key = { it.id }) { test ->
                                        val color = statusColor(test.status)
                                        Column(Modifier.fillMaxWidth().padding(start = 14.dp, bottom = 3.dp).background(Color(IdeTheme.CARD), RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 4.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Checkbox(checked = test.selected, onCheckedChange = { controller?.toggleSelection(test.id) }, modifier = Modifier.size(27.dp), enabled = !state.running)
                                                Text(statusGlyph(test.status), color = Color(color), fontSize = 13.sp)
                                                Spacer(Modifier.width(6.dp))
                                                Column(Modifier.weight(1f).clickable { expandedId = if (expandedId == test.id) null else test.id }) {
                                                    Text(test.label, color = Color(IdeTheme.TEXT), fontSize = 11.sp, maxLines = 1)
                                                    Text(buildString { if (test.className.isNotBlank()) append(test.className); if (test.line > 0) append(" · L${test.line}") }, color = Color(IdeTheme.DIM), fontSize = 8.sp, maxLines = 1)
                                                }
                                                if (test.duration.isNotBlank()) Text(test.duration, color = Color(IdeTheme.DIM), fontSize = 8.sp)
                                                TextButton(enabled = !state.running && !savingBeforeRun && project != null, onClick = { runTests(listOf(test.id)) }, contentPadding = PaddingValues(horizontal = 3.dp, vertical = 0.dp)) { Text("▶", color = Color(IdeTheme.ACCENT), fontSize = 11.sp) }
                                            }
                                            if (expandedId == test.id) {
                                                if (test.detail.isNotBlank()) Text(test.detail.take(7000), color = Color(IdeTheme.ERROR), fontFamily = FontFamily.Monospace, fontSize = 9.sp, lineHeight = 12.sp, modifier = Modifier.padding(start = 34.dp, top = 3.dp))
                                                Row(Modifier.fillMaxWidth().padding(start = 30.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    if (test.file.isNotBlank() && test.line > 0) Text("Open ${test.file}:${test.line}", color = Color(IdeTheme.ACCENT), fontSize = 9.sp, modifier = Modifier.clickable { onOpenLocation?.invoke(test.file, test.line) })
                                                    if (test.detail.isNotBlank()) Text("Copy details", color = Color(IdeTheme.ACCENT), fontSize = 9.sp, modifier = Modifier.clickable { clipboard.setText(AnnotatedString(test.detail)) })
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            "Coverage" -> {
                LaunchedEffect(project?.dir?.absolutePath, page) {
                    if (page == "Coverage" && project != null) controller?.loadCoverage(proot, project)
                }
                var coverageQuery by remember { mutableStateOf("") }
                var lowCoverageOnly by remember { mutableStateOf(false) }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("COVERAGE EXPLORER", color = Color(IdeTheme.DIM), fontWeight = FontWeight.SemiBold, fontSize = 10.sp)
                        Text(state.coverageMessage, color = Color(IdeTheme.DIM), fontSize = 8.sp)
                    }
                    TextButton(enabled = !state.coverageLoading && !state.running && project != null, onClick = { project?.let { controller?.loadCoverage(proot, it, force = true) } }, contentPadding = PaddingValues(horizontal = 5.dp)) {
                        Text(if (state.coverageLoading) "Loading…" else "↻ Refresh", fontSize = 9.sp)
                    }
                }
                if (state.coverageFiles.isNotEmpty()) {
                    val totalStatements = state.coverageFiles.sumOf { it.statements }
                    val totalCovered = state.coverageFiles.sumOf { it.covered }
                    val overall = if (totalStatements > 0) totalCovered * 100.0 / totalStatements else 0.0
                    Row(Modifier.fillMaxWidth().background(Color(IdeTheme.CARD), RoundedCornerShape(7.dp)).padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${String.format(Locale.US, "%.1f", overall)}%", color = Color(IdeTheme.TEXT), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text("Overall statement coverage", color = Color(IdeTheme.DIM), fontSize = 8.sp)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("$totalCovered / $totalStatements lines", color = Color(IdeTheme.TEXT), fontSize = 9.sp)
                            Text("${state.coverageFiles.count { it.percent < 50.0 }} files below 50%", color = Color(IdeTheme.DIM), fontSize = 8.sp)
                        }
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        BasicTextField(value = coverageQuery, onValueChange = { coverageQuery = it }, singleLine = true,
                            modifier = Modifier.weight(1f).background(Color(IdeTheme.CARD), RoundedCornerShape(6.dp)).padding(horizontal = 9.dp, vertical = 7.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(color = Color(IdeTheme.TEXT), fontSize = 10.sp),
                            decorationBox = { inner -> if (coverageQuery.isEmpty()) Text("Filter files…", color = Color(IdeTheme.DIM), fontSize = 10.sp); inner() })
                        FilterChip(selected = lowCoverageOnly, onClick = { lowCoverageOnly = !lowCoverageOnly }, label = { Text("< 50%", fontSize = 9.sp) })
                    }
                    val shownCoverage = state.coverageFiles.filter { file ->
                        (coverageQuery.isBlank() || file.path.contains(coverageQuery, true)) && (!lowCoverageOnly || file.percent < 50.0)
                    }
                    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                        items(shownCoverage, key = { it.path }) { file ->
                            val tint = when { file.percent >= 80.0 -> 0xFF4CAF50.toInt(); file.percent >= 50.0 -> 0xFFFFB74D.toInt(); else -> IdeTheme.ERROR.toInt() }
                            Column(Modifier.fillMaxWidth().padding(vertical = 3.dp).background(Color(IdeTheme.CARD), RoundedCornerShape(7.dp)).padding(8.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(file.path, color = Color(IdeTheme.TEXT), fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 2)
                                        Text("${file.covered}/${file.statements} statements · ${file.missingLines.size} uncovered", color = Color(IdeTheme.DIM), fontSize = 8.sp)
                                    }
                                    Text("${String.format(Locale.US, "%.1f", file.percent)}%", color = Color(tint), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(Modifier.height(5.dp))
                                LinearProgressIndicator(progress = { (file.percent / 100.0).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(5.dp), color = Color(tint), trackColor = Color(IdeTheme.BG))
                                if (file.missingLines.isNotEmpty()) {
                                    Text("UNCOVERED LINES · tap a line to open it", color = Color(IdeTheme.DIM), fontSize = 8.sp, modifier = Modifier.padding(top = 6.dp, bottom = 2.dp))
                                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                        file.missingLines.take(250).forEach { line ->
                                            Text("L$line", color = Color(IdeTheme.ERROR), fontSize = 9.sp,
                                                modifier = Modifier.background(Color(IdeTheme.BG), RoundedCornerShape(4.dp)).clickable { onOpenLocation?.invoke(file.path, line) }.padding(horizontal = 6.dp, vertical = 4.dp))
                                        }
                                        if (file.missingLines.size > 250) Text("+${file.missingLines.size - 250} more", color = Color(IdeTheme.DIM), fontSize = 8.sp)
                                    }
                                } else Text("All executable statements covered", color = Color(0xFF4CAF50), fontSize = 8.sp, modifier = Modifier.padding(top = 5.dp))
                            }
                        }
                        if (shownCoverage.isEmpty()) item { Text("No files match this filter.", color = Color(IdeTheme.DIM), fontSize = 10.sp, modifier = Modifier.padding(12.dp)) }
                    }
                } else {
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(if (state.coverageLoading) "Reading coverage report…" else state.coverageMessage, color = Color(IdeTheme.DIM), fontSize = 10.sp)
                    }
                }
            }
            "Insights" -> {
                Column(Modifier.weight(1f).fillMaxWidth()) {
                    Text("RUN COMPARISON", color = Color(IdeTheme.DIM), fontWeight = FontWeight.SemiBold, fontSize = 10.sp)
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        InsightMetric("${state.analyticsCounts.regressions}", "Regressions", IdeTheme.ERROR.toInt())
                        InsightMetric("${state.analyticsCounts.fixed}", "Fixed", 0xFF4CAF50.toInt())
                        InsightMetric("${state.analyticsCounts.new}", "New", 0xFF64B5F6.toInt())
                        InsightMetric("${state.analyticsCounts.unchanged}", "Unchanged", IdeTheme.DIM.toInt())
                    }
                    Text("Run #${state.analyticsRunNumber} · compared per test with its previous recorded result", color = Color(IdeTheme.DIM), fontSize = 8.sp)
                    val importantChanges = state.analyticsChanges.filter { it.change == "REGRESSION" || it.change == "FIXED" || it.change == "NEW" }
                    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(top = 5.dp)) {
                        if (importantChanges.isEmpty()) item {
                            Text(if (state.analyticsRunNumber == 0) "Run tests to build a comparison baseline." else "No new, fixed, or regressed tests in the latest run.",
                                color = Color(IdeTheme.DIM), fontSize = 10.sp, modifier = Modifier.padding(10.dp))
                        }
                        items(importantChanges, key = { "change:${it.id}" }) { change ->
                            val tint = when (change.change) { "REGRESSION" -> IdeTheme.ERROR.toInt(); "FIXED" -> 0xFF4CAF50.toInt(); else -> 0xFF64B5F6.toInt() }
                            Column(Modifier.fillMaxWidth().padding(vertical = 3.dp).background(Color(IdeTheme.CARD), RoundedCornerShape(6.dp)).clickable { if (change.line > 0) onOpenLocation?.invoke(change.file, change.line) }.padding(8.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(change.change, color = Color(tint), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.width(6.dp))
                                    Text(change.name, color = Color(IdeTheme.TEXT), fontSize = 10.sp, modifier = Modifier.weight(1f), maxLines = 1)
                                    Text(change.status, color = Color(tint), fontSize = 8.sp)
                                }
                                Text("${change.file}${if (change.line > 0) ":${change.line}" else ""}" + if (change.previousStatus.isNotBlank()) " · was ${change.previousStatus}" else " · first recorded run",
                                    color = Color(IdeTheme.DIM), fontSize = 8.sp)
                            }
                        }
                    }
                    Divider(color = Color(IdeTheme.DIM).copy(alpha = 0.25f), thickness = 1.dp)
                    Row(Modifier.fillMaxWidth().padding(top = 7.dp, bottom = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("FLAKY TESTS", color = Color(IdeTheme.DIM), fontWeight = FontWeight.SemiBold, fontSize = 10.sp)
                        Spacer(Modifier.weight(1f))
                        Text("${state.flakyTests.size} detected", color = if (state.flakyTests.isEmpty()) Color(IdeTheme.DIM) else Color(0xFFFFB74D), fontSize = 8.sp)
                    }
                    if (state.flakyTests.isEmpty()) {
                        Text("${state.analyticsMessage} A test is flagged only after mixed pass/fail outcomes are observed.", color = Color(IdeTheme.DIM), fontSize = 8.sp, modifier = Modifier.padding(vertical = 5.dp))
                    } else {
                        LazyColumn(Modifier.heightIn(max = 150.dp).fillMaxWidth()) {
                            items(state.flakyTests, key = { "flaky:${it.id}" }) { flaky ->
                                Column(Modifier.fillMaxWidth().padding(vertical = 2.dp).background(Color(IdeTheme.CARD), RoundedCornerShape(5.dp)).clickable { if (flaky.line > 0) onOpenLocation?.invoke(flaky.file, flaky.line) }.padding(7.dp)) {
                                    Text(flaky.name, color = Color(IdeTheme.TEXT), fontSize = 9.sp, maxLines = 1)
                                    Text("${flaky.file} · ${flaky.passed} passed / ${flaky.failed} failed in ${flaky.runs} recorded outcomes", color = Color(0xFFFFB74D), fontSize = 8.sp)
                                }
                            }
                        }
                    }
                }
            }
            "Output" -> {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("LIVE OUTPUT", color = Color(IdeTheme.DIM), fontWeight = FontWeight.SemiBold, fontSize = 10.sp)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { clipboard.setText(AnnotatedString(state.output)) }, contentPadding = PaddingValues(horizontal = 5.dp)) { Text("Copy", fontSize = 9.sp) }
                    TextButton(onClick = { controller?.clearResults() }, enabled = !state.running, contentPadding = PaddingValues(horizontal = 5.dp)) { Text("Clear", fontSize = 9.sp) }
                }
                Box(Modifier.weight(1f).fillMaxWidth().background(Color(IdeTheme.CARD), RoundedCornerShape(6.dp)).verticalScroll(outputScroll).padding(8.dp)) {
                    Text(state.output, color = Color(IdeTheme.TEXT), fontFamily = FontFamily.Monospace, fontSize = 9.sp, lineHeight = 12.sp)
                }
            }
            else -> {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("RUN HISTORY", color = Color(IdeTheme.DIM), fontWeight = FontWeight.SemiBold, fontSize = 10.sp)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { showHistoryClear = true }, contentPadding = PaddingValues(horizontal = 5.dp)) { Text("Clear history", fontSize = 9.sp) }
                }
                LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                    items(state.history) { entry -> Text(entry, color = Color(IdeTheme.TEXT), fontSize = 10.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Color(IdeTheme.CARD), RoundedCornerShape(5.dp)).padding(8.dp)) }
                    if (state.history.isEmpty()) item { Text("No test runs recorded yet.", color = Color(IdeTheme.DIM), fontSize = 11.sp, modifier = Modifier.padding(12.dp)) }
                }
                if (state.reportPath.isNotBlank()) Text("JUnit: ${state.reportPath}", color = Color(IdeTheme.DIM), fontSize = 8.sp, modifier = Modifier.clickable { clipboard.setText(AnnotatedString(state.reportPath)) })
                if (state.htmlReportPath.isNotBlank()) Text("HTML report: ${state.htmlReportPath}", color = Color(IdeTheme.DIM), fontSize = 8.sp, modifier = Modifier.clickable { clipboard.setText(AnnotatedString(state.htmlReportPath)) })
                if (state.jsonReportPath.isNotBlank()) Text("JSON report: ${state.jsonReportPath}", color = Color(IdeTheme.DIM), fontSize = 8.sp, modifier = Modifier.clickable { clipboard.setText(AnnotatedString(state.jsonReportPath)) })
                if (state.coveragePercent.isNotBlank() && project != null) Text("HTML coverage: ${guestProjectPath(project)}/htmlcov/index.html", color = Color(IdeTheme.DIM), fontSize = 8.sp, modifier = Modifier.clickable { clipboard.setText(AnnotatedString("${guestProjectPath(project)}/htmlcov/index.html")) })
            }
        }
        if (state.lastRun.isNotBlank()) {
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Last run: ${state.lastRun}  ${state.totalDuration}", color = Color(IdeTheme.DIM), fontSize = 8.sp)
                Spacer(Modifier.weight(1f))
                if (state.reportPath.isNotBlank()) Text("Copy report path", color = Color(IdeTheme.ACCENT), fontSize = 8.sp, modifier = Modifier.clickable { clipboard.setText(AnnotatedString(state.reportPath)) })
            }
        }
    }

    if (settingsOpen) TestSettingsDialog(state, onDismiss = { settingsOpen = false }, onApply = { framework, keyword, marker, failFast, coverage ->
        val frameworkChanged = framework != state.framework
        controller?.updateOptions(framework, keyword, marker, failFast, coverage)
        settingsOpen = false
        if (frameworkChanged && project != null && runnerScript.isNotBlank()) controller?.discover(proot, project, runnerScript)
    })
    if (showHistoryClear) AlertDialog(onDismissRequest = { showHistoryClear = false }, title = { Text("Clear test history?") },
        text = { Text("This removes the saved run-history entries for this project.") }, confirmButton = {
            TextButton(onClick = { controller?.let { it.clearHistory() }; showHistoryClear = false }) { Text("Clear") }
        }, dismissButton = { TextButton(onClick = { showHistoryClear = false }) { Text("Cancel") } })
}

@Composable
private fun TestSettingsDialog(state: TestSnapshot, onDismiss: () -> Unit, onApply: (String, String, String, Boolean, Boolean) -> Unit) {
    var framework by remember(state.framework) { mutableStateOf(state.framework) }
    var keyword by remember(state.keyword) { mutableStateOf(state.keyword) }
    var marker by remember(state.marker) { mutableStateOf(state.marker) }
    var failFast by remember(state.failFast) { mutableStateOf(state.failFast) }
    var coverage by remember(state.coverageEnabled) { mutableStateOf(state.coverageEnabled) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Test configuration") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Framework", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { listOf("auto", "pytest", "unittest").forEach { value -> FilterChip(selected = framework == value, onClick = { framework = value }, label = { Text(value, fontSize = 10.sp) }) } }
            OutlinedTextField(value = keyword, onValueChange = { keyword = it }, label = { Text("Keyword expression (-k)") }, singleLine = true)
            OutlinedTextField(value = marker, onValueChange = { marker = it }, label = { Text("Pytest marker (-m)") }, singleLine = true)
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(failFast, { failFast = it }); Text("Stop after first failure", fontSize = 11.sp) }
            Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(coverage, { coverage = it }); Text("Generate code coverage (requires coverage.py)", fontSize = 11.sp) }
            Text("The selected project's Python environment is used. Pytest and coverage are optional; PySpace will not install packages automatically.", color = Color(IdeTheme.DIM), fontSize = 9.sp)
        }
    }, confirmButton = { TextButton(onClick = { onApply(framework, keyword, marker, failFast, coverage) }) { Text("Apply") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
private fun androidx.compose.foundation.layout.RowScope.InsightMetric(value: String, label: String, tint: Int) {
    Column(Modifier.weight(1f).background(Color(IdeTheme.CARD), RoundedCornerShape(6.dp)).padding(horizontal = 5.dp, vertical = 7.dp)) {
        Text(value, color = Color(tint), fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Color(IdeTheme.DIM), fontSize = 7.sp, maxLines = 1)
    }
}

private fun statusGlyph(status: TestStatus) = when (status) { TestStatus.PASSED -> "✓"; TestStatus.FAILED -> "✕"; TestStatus.SKIPPED -> "↷"; TestStatus.XFAILED -> "×"; TestStatus.XPASSED -> "!"; TestStatus.RUNNING -> "◌"; else -> "○" }
private fun statusColor(status: TestStatus): Int = when (status) { TestStatus.PASSED -> 0xFF4CAF50.toInt(); TestStatus.FAILED, TestStatus.XPASSED -> IdeTheme.ERROR.toInt(); TestStatus.SKIPPED, TestStatus.XFAILED -> 0xFFFFB74D.toInt(); TestStatus.RUNNING -> IdeTheme.ACCENT.toInt(); else -> IdeTheme.DIM.toInt() }
@Composable private fun SummaryPill(text: String, color: Int) { Text(text, color = Color(color), fontSize = 8.sp, modifier = Modifier.background(Color(IdeTheme.CARD), RoundedCornerShape(20.dp)).padding(horizontal = 6.dp, vertical = 4.dp), maxLines = 1) }
