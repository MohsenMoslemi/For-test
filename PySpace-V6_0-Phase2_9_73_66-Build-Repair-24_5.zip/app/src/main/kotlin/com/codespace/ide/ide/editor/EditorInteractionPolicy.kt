package com.codespace.ide.ide.editor

import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.input.TextFieldValue
import kotlin.math.max

/** Deterministic interaction decisions shared by the editor presentation. */
object EditorInteractionPolicy {
    /**
     * Selection handles are platform overlays, so they are shown only when every
     * required anchor (and the insertion-handle reach) remains inside the code lane.
     * A stale/missing layout fails closed.
     */
    fun shouldShowSelectionHandles(
        active: Boolean,
        pinchGestureActive: Boolean,
        zoomCommitInProgress: Boolean,
        layout: TextLayoutResult?,
        field: TextFieldValue,
        foldedDocument: FoldedEditorDocument,
        viewportWidthPx: Int,
        viewportHeightPx: Int,
        gutterWidthPx: Float,
        textPaddingPx: Float,
        handleReachPx: Float,
        bottomInsetPx: Float,
        horizontalScrollPx: Int,
        verticalScrollPx: Int
    ): Boolean {
        if (!active || pinchGestureActive || zoomCommitInProgress) return false
        val currentLayout = layout ?: return false
        if (!sameDisplay(currentLayout.layoutInput.text.text, foldedDocument.displayText) ||
            viewportWidthPx <= 0 || viewportHeightPx <= 0
        ) return false

        fun anchorIsVisible(sourceOffset: Int): Boolean {
            val rect = currentLayout.getCursorRect(
                foldedDocument.toDisplayOffset(sourceOffset.coerceIn(0, field.text.length))
            )
            val x = gutterWidthPx + textPaddingPx + rect.left
            val top = textPaddingPx + rect.top
            val bottom = textPaddingPx + rect.bottom + handleReachPx
            return x >= horizontalScrollPx + gutterWidthPx &&
                x <= horizontalScrollPx + viewportWidthPx &&
                top >= verticalScrollPx &&
                bottom <= verticalScrollPx + viewportHeightPx - bottomInsetPx
        }

        return if (field.selection.collapsed) {
            anchorIsVisible(field.selection.start)
        } else {
            anchorIsVisible(field.selection.start) && anchorIsVisible(field.selection.end)
        }
    }

    data class FoldToggleResult(
        val collapsedKeys: Set<String>,
        /** Non-null only when collapsing would hide an active selection endpoint. */
        val caretOffsetAfterCollapse: Int? = null,
        val collapsed: Boolean
    )

    /**
     * Applies the fold-key policy without mutating OpenTab or the TextFieldValue.
     * The caller commits the returned key set and, if requested, moves the caret.
     */
    fun toggleFold(
        currentKeys: Set<String>,
        region: EditorFoldRegion,
        selectionStartLine: Int,
        selectionEndLine: Int,
        sourceLength: Int
    ): FoldToggleResult {
        val willCollapse = region.key !in currentKeys
        val nextKeys = if (willCollapse) currentKeys + region.key else currentKeys - region.key
        val startHidden = selectionStartLine > region.headerLine && selectionStartLine <= region.endLine
        val endHidden = selectionEndLine > region.headerLine && selectionEndLine <= region.endLine
        val caret = if (willCollapse && (startHidden || endHidden)) {
            region.headerEnd.coerceIn(0, max(0, sourceLength))
        } else null
        return FoldToggleResult(nextKeys, caret, willCollapse)
    }
}
