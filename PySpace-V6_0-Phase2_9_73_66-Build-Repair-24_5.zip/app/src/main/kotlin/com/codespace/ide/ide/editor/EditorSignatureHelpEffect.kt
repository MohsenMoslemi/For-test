package com.codespace.ide.ide.editor

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import com.codespace.ide.ide.codeintel.PythonLspController
import com.codespace.ide.ide.codeintel.PythonSignatureInfo
import java.io.File
import kotlinx.coroutines.delay

/** Owns the debounced signature-help request lifecycle for the active editor buffer. */
@Composable
internal fun EditorSignatureHelpEffect(
    file: File,
    source: String,
    caret: Int,
    selectionCollapsed: Boolean,
    isPythonLanguage: Boolean,
    controller: PythonLspController?,
    onResult: (PythonSignatureInfo?) -> Unit
) {
    LaunchedEffect(file.absolutePath, source, caret, selectionCollapsed, isPythonLanguage, controller) {
        onResult(null)
        if (!isPythonLanguage || !selectionCollapsed) return@LaunchedEffect

        val safeCaret = caret.coerceIn(0, source.length)
        findPythonCallContext(source, safeCaret) ?: return@LaunchedEffect
        val trigger = source.getOrNull(safeCaret - 1)?.takeIf { it == '(' || it == ',' }
        delay(110)

        val info = controller?.signatureHelp(file, source, safeCaret, trigger)
        onResult(info)
    }
}
