package com.codespace.ide.ide.editor

import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import com.codespace.ide.ide.codeintel.PythonCompletionItem
import com.codespace.ide.ide.codeintel.PythonSignatureInfo

/** Per-document transient completion/signature-help presentation state. */
class EditorCompletionSessionState {
    val items: MutableState<List<PythonCompletionItem>> = mutableStateOf(emptyList())
    val replaceRange: MutableState<Pair<Int, Int>> = mutableStateOf(0 to 0)
    val editVersion: MutableState<Int> = mutableStateOf(0)
    val triggerCaret: MutableState<Int> = mutableStateOf(-1)
    val lastLspEditVersion: MutableState<Int> = mutableStateOf(0)
    val lastLspEnvironmentRevision: MutableState<Long> = mutableStateOf(0L)
    val signature: MutableState<PythonSignatureInfo?> = mutableStateOf(null)

    fun dismissCompletion() {
        items.value = emptyList()
    }

    fun markEdit() {
        editVersion.value += 1
    }
}
