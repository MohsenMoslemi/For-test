package com.codespace.ide.ide.home

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import kotlinx.coroutines.launch
import com.codespace.ide.ide.PythonRuntimeCatalog
import com.codespace.ide.ide.projects.BackupProgress
import com.codespace.ide.ide.projects.PendingProjectDeletionUi
import com.codespace.ide.ide.projects.ProjectsViewModel
import com.codespace.ide.ide.projects.PyProject
import com.codespace.ide.ide.projects.RuntimeInstallUiState
import com.codespace.ide.ide.theme.IdeTheme

internal fun formatBackupBytes(value: Long): String {
    if (value < 1024L) return "$value B"
    val kb = value / 1024.0
    if (kb < 1024.0) return String.format(java.util.Locale.US, "%.1f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024.0) return String.format(java.util.Locale.US, "%.1f MB", mb)
    return String.format(java.util.Locale.US, "%.2f GB", mb / 1024.0)
}

@Composable
internal fun ProjectsTab(
    projects: List<PyProject>,
    sortMode: Int,
    projectCreatedAt: Map<String, Long>,
    projectLastOpenedAt: Map<String, Long>,
    loading: Boolean,
    pythonFileCounts: Map<String, Int>,
    loadError: String?,
    mutationError: String?,
    mutationBusy: Boolean,
    backupRestoreBusy: Boolean,
    backupRestoreMessage: String?,
    backupRestoreError: String?,
    backupRestoreProgress: BackupProgress?,
    busyProjects: Set<String>,
    runtimeInstallStates: Map<String, com.codespace.ide.ide.projects.RuntimeInstallUiState>,
    venvBuildingProjects: Set<String>,
    pendingDeletions: Map<String, com.codespace.ide.ide.projects.PendingProjectDeletionUi>,
    projectsViewModel: ProjectsViewModel,
    onNewProject: () -> Unit,
    onOpen: (PyProject) -> Unit,
    onProjectGone: (File) -> Unit = {}
) {
    var menuFor by remember { mutableStateOf<PyProject?>(null) }
    var sortMenuExpanded by remember { mutableStateOf(false) }
    var renameFor by remember { mutableStateOf<PyProject?>(null) }
    var renameText by remember { mutableStateOf("") }
    var venvFor by remember { mutableStateOf<PyProject?>(null) }
    var venvText by remember { mutableStateOf("") }
    var pythonVersionFor by remember { mutableStateOf<PyProject?>(null) }
    var pythonVersionChoice by remember { mutableStateOf(com.codespace.ide.ide.PythonRuntimeCatalog.DEFAULT_ID) }
    var confirmDel by remember { mutableStateOf<PyProject?>(null) }
    var backupProjectPending by remember { mutableStateOf<PyProject?>(null) }
    val workspaceBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) projectsViewModel.backupWorkspace(uri)
    }
    val projectBackupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val project = backupProjectPending
        backupProjectPending = null
        if (uri != null && project != null) projectsViewModel.backupProject(project, uri)
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) projectsViewModel.restoreBackup(uri)
    }
    LaunchedEffect(Unit) { projectsViewModel.refreshPythonRuntimeStates() }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("My projects", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    "${(projects.size - pendingDeletions.size).coerceAtLeast(0)} project${if ((projects.size - pendingDeletions.size) == 1) "" else "s"} in workspace",
                    color = Color(IdeTheme.DIM), fontSize = 12.sp
                )
            }
            Box {
                TextButton(onClick = { sortMenuExpanded = true }) {
                    Text("⇅ " + listOf("Name", "Created", "Last opened").getOrElse(sortMode) { "Name" }, color = Color(IdeTheme.ACCENT), fontSize = 12.sp)
                }
                DropdownMenu(expanded = sortMenuExpanded, onDismissRequest = { sortMenuExpanded = false }) {
                    listOf("Alphabetical", "Date created", "Last opened").forEachIndexed { index, label ->
                        DropdownMenuItem(
                            text = { Text(label, color = if (sortMode == index) Color(IdeTheme.ACCENT) else Color(IdeTheme.TEXT)) },
                            onClick = { projectsViewModel.setSortMode(index); sortMenuExpanded = false }
                        )
                    }
                }
            }
            TextButton(
                enabled = !mutationBusy && pendingDeletions.isEmpty() && projects.isNotEmpty(),
                onClick = { workspaceBackupLauncher.launch("PySpace-Projects-Backup.zip") }
            ) { Text("Backup", color = Color(IdeTheme.ACCENT), fontSize = 11.sp, fontWeight = FontWeight.Medium) }
            TextButton(
                enabled = !mutationBusy,
                onClick = { restoreLauncher.launch(arrayOf("*/*")) }
            ) { Text("Import", color = Color(IdeTheme.ACCENT), fontSize = 11.sp, fontWeight = FontWeight.Medium) }
            Button(
                enabled = !mutationBusy,
                onClick = onNewProject,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(IdeTheme.ACCENT), contentColor = Color(IdeTheme.ON_ACCENT)
                )
            ) { Text("+ New", fontWeight = FontWeight.Bold) }
        }
        Spacer(Modifier.height(10.dp))
        if (loadError != null) {
            Text(
                "Could not fully refresh projects: $loadError",
                color = Color(IdeTheme.ERROR), fontSize = 11.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
        if (mutationError != null) {
            Text(
                mutationError,
                color = Color(IdeTheme.ERROR), fontSize = 11.sp,
                modifier = Modifier.padding(bottom = 8.dp).clickable { projectsViewModel.clearMutationError() }
            )
        }
        if (backupRestoreBusy || backupRestoreMessage != null || backupRestoreError != null) {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.PANEL))) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (backupRestoreBusy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color(IdeTheme.ACCENT))
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)) {
                        Text(backupRestoreMessage ?: backupRestoreError ?: "Working…", color = if (backupRestoreError != null) Color(IdeTheme.ERROR) else Color(IdeTheme.TEXT), fontSize = 11.sp)
                        backupRestoreProgress?.let { progress ->
                            Spacer(Modifier.height(7.dp))
                            val fileLine = if (progress.totalFiles != null) "${progress.filesProcessed} / ${progress.totalFiles} files" else "${progress.filesProcessed} files processed"
                            Text(fileLine, color = Color(IdeTheme.DIM), fontSize = 10.sp)
                            if (progress.totalBytes != null && progress.totalBytes > 0L) {
                                Text("${formatBackupBytes(progress.bytesProcessed)} / ${formatBackupBytes(progress.totalBytes)}", color = Color(IdeTheme.DIM), fontSize = 10.sp)
                            } else if (progress.bytesProcessed > 0L) {
                                Text("${formatBackupBytes(progress.bytesProcessed)} processed", color = Color(IdeTheme.DIM), fontSize = 10.sp)
                            }
                            progress.currentFile?.let { fileName ->
                                Text(fileName, color = Color(IdeTheme.DIM), fontSize = 9.sp, maxLines = 1)
                            }
                            Spacer(Modifier.height(5.dp))
                            val fraction = progress.fraction
                            if (fraction != null) {
                                LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth(), color = Color(IdeTheme.ACCENT), trackColor = Color(IdeTheme.LINE))
                                Text("${(fraction * 100).toInt()}%", color = Color(IdeTheme.ACCENT), fontSize = 10.sp)
                            } else {
                                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Color(IdeTheme.ACCENT), trackColor = Color(IdeTheme.LINE))
                            }
                        }
                        if (backupRestoreError != null) Text("The existing projects were not overwritten.", color = Color(IdeTheme.DIM), fontSize = 10.sp)
                    }
                    if (backupRestoreBusy) TextButton(onClick = { projectsViewModel.cancelBackupRestore() }) { Text("Cancel", color = Color(IdeTheme.ERROR)) }
                    else TextButton(onClick = { projectsViewModel.clearBackupRestoreMessage() }) { Text("OK") }
                }
            }
        }
        if (projects.isEmpty() && loading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Color(IdeTheme.ACCENT))
            }
        } else if (projects.isEmpty()) {
            Column(
                Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("◈", color = Color(IdeTheme.ACCENT), fontSize = 40.sp)
                Spacer(Modifier.height(8.dp))
                Text("No projects yet", color = Color(IdeTheme.TEXT), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text("Create one — a main.py starter is included.", color = Color(IdeTheme.DIM), fontSize = 12.sp)
            }
        } else {
            val sortedProjects = remember(projects, sortMode, projectCreatedAt, projectLastOpenedAt) {
                when (sortMode) {
                    1 -> projects.sortedWith(compareByDescending<PyProject> { projectCreatedAt[it.dir.absolutePath] ?: it.dir.lastModified() }.thenBy { it.name.lowercase() })
                    2 -> projects.sortedWith(compareByDescending<PyProject> { projectLastOpenedAt[it.dir.absolutePath] ?: 0L }.thenBy { it.name.lowercase() })
                    else -> projects.sortedBy { it.name.lowercase() }
                }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(sortedProjects, key = { it.dir.absolutePath }) { p ->
                    val pendingDeletion = pendingDeletions[p.dir.absolutePath]
                    val n = pythonFileCounts[p.dir.absolutePath] ?: 0
                    val venvBusy = venvBuildingProjects.contains(p.dir.absolutePath)
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.CARD)),
                        modifier = Modifier.fillMaxWidth().then(
                            if (pendingDeletion == null) Modifier.clickable { onOpen(p) } else Modifier
                        )
                    ) {
                        if (pendingDeletion != null) {
                            Row(
                                Modifier.fillMaxWidth().padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    Modifier.size(44.dp).clip(RoundedCornerShape(12.dp))
                                        .background(Color(IdeTheme.DIM).copy(alpha = 0.12f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(p.name.firstOrNull()?.uppercase() ?: "P", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color(IdeTheme.DIM))
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(IdeTheme.DIM))
                                    Text("Project scheduled for deletion", color = Color(IdeTheme.DIM), fontSize = 11.sp)
                                }
                                TextButton(onClick = { projectsViewModel.undoProjectDeletion(p.dir.absolutePath) }) {
                                    Text("Undo · ${pendingDeletion.remainingSeconds}s", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        } else Row(
                            Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(IdeTheme.ACCENT).copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    p.name.firstOrNull()?.uppercase() ?: "P",
                                    fontWeight = FontWeight.Bold, fontSize = 20.sp,
                                    color = Color(IdeTheme.ACCENT)
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text(
                                    projectPythonVersionTitle(p.dir),
                                    color = Color(IdeTheme.ACCENT), fontSize = 10.sp, fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    "$n python file${if (n == 1) "" else "s"} • tap to open",
                                    color = Color(IdeTheme.DIM), fontSize = 11.sp
                                )
                                val vv = projectVenvName(p.dir)
                                val ready = venvPythonReady(p.dir, vv)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        when {
                                            venvBusy -> "Preparing Python environment…"
                                            ready -> "venv $vv ✓"
                                            else -> "venv $vv (not built)"
                                        },
                                        color = if (ready && !venvBusy) Color(IdeTheme.ACCENT) else Color(IdeTheme.DIM),
                                        fontSize = 11.sp,
                                        modifier = Modifier.weight(1f, fill = false)
                                    )
                                    if (venvBusy) {
                                        Spacer(Modifier.width(7.dp))
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(14.dp),
                                            strokeWidth = 2.dp,
                                            color = Color(IdeTheme.ACCENT)
                                        )
                                    }
                                }
                                if (venvBusy) {
                                    Spacer(Modifier.height(6.dp))
                                    LinearProgressIndicator(
                                        modifier = Modifier.fillMaxWidth(),
                                        color = Color(IdeTheme.ACCENT),
                                        trackColor = Color(IdeTheme.LINE)
                                    )
                                }
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                TextButton(
                                    enabled = !mutationBusy && !venvBusy,
                                    onClick = { backupProjectPending = p; projectBackupLauncher.launch("PySpace-${p.name}-Backup.zip") }
                                ) { Text("Backup", color = Color(IdeTheme.ACCENT), fontSize = 10.sp, fontWeight = FontWeight.Medium) }
                            }
                            Column {
                                TextButton(onClick = { menuFor = p }) {
                                    Text("⋮", fontSize = 18.sp, color = Color(IdeTheme.DIM))
                                }
                                DropdownMenu(
                                    expanded = menuFor == p,
                                    onDismissRequest = { menuFor = null }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("Open") },
                                        onClick = { menuFor = null; onOpen(p) }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Rename") },
                                        onClick = {
                                            menuFor = null
                                            renameFor = p
                                            renameText = p.name
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Python version…") },
                                        onClick = {
                                            menuFor = null
                                            pythonVersionFor = p
                                            pythonVersionChoice = com.codespace.ide.ide.projectPythonVersionId(p.dir)
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Virtualenv…") },
                                        onClick = {
                                            menuFor = null
                                            venvFor = p
                                            venvText = projectVenvName(p.dir)
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Delete") },
                                        onClick = { menuFor = null; confirmDel = p }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if (pythonVersionFor != null) {
        val targetProject = pythonVersionFor!!
        IdeAlertDialog(
            onDismissRequest = { pythonVersionFor = null },
            title = { Text("Change Python — ${targetProject.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Choose the interpreter for this project. Other projects will not be affected.", color = Color(IdeTheme.DIM), fontSize = 12.sp)
                    com.codespace.ide.ide.PythonRuntimeCatalog.options.forEach { option ->
                        val selected = pythonVersionChoice == option.id
                        val available = option.isBundled || runtimeInstallStates[option.id]?.status == "installed"
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                                .background(if (selected) Color(IdeTheme.ACCENT).copy(alpha = .12f) else Color.Transparent)
                                .clickable(enabled = available) { pythonVersionChoice = option.id }.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(option.title, color = Color(IdeTheme.TEXT), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text(option.description, color = Color(IdeTheme.DIM), fontSize = 10.sp)
                                if (!available) Text("Not installed · install it in Settings → Python first", color = Color(IdeTheme.WARN), fontSize = 9.sp)
                            }
                            Text(if (selected) "✓" else if (available) "○" else "—", color = if (available) Color(IdeTheme.ACCENT) else Color(IdeTheme.DIM), fontSize = 18.sp)
                        }
                    }
                    if (venvPythonReady(targetProject.dir)) {
                        Text("The existing virtual environment will be rebuilt safely. Installed packages inside it will need to be reinstalled. If rebuilding fails, the old environment will be restored.", color = Color(IdeTheme.WARN), fontSize = 11.sp)
                    } else {
                        Text("The project has no built virtual environment. Only its interpreter setting will change.", color = Color(IdeTheme.DIM), fontSize = 11.sp)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !busyProjects.contains(targetProject.dir.absolutePath) && (com.codespace.ide.ide.PythonRuntimeCatalog.require(pythonVersionChoice).isBundled || runtimeInstallStates[pythonVersionChoice]?.status == "installed"),
                    onClick = {
                        projectsViewModel.changeProjectPythonVersion(targetProject, pythonVersionChoice) { pythonVersionFor = null }
                    }
                ) { Text("Apply", color = Color(IdeTheme.ACCENT)) }
            },
            dismissButton = { TextButton(onClick = { pythonVersionFor = null }) { Text("Cancel") } },
            containerColor = Color(IdeTheme.PANEL),
            titleContentColor = Color(IdeTheme.TEXT),
            textContentColor = Color(IdeTheme.DIM)
        )
    }
    if (venvFor != null) {
        IdeAlertDialog(
            onDismissRequest = { venvFor = null },
            title = { Text("Virtualenv — ${venvFor!!.name}") },
            text = {
                Column {
                    OutlinedTextField(
                        value = venvText, onValueChange = { venvText = it },
                        label = { Text("venv dir name") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (venvPythonReady(venvFor!!.dir)) "Status: real virtualenv ✓" else "Status: plain dir (not built yet)",
                        color = Color(IdeTheme.DIM), fontSize = 12.sp
                    )
                    TextButton(onClick = {
                        projectsViewModel.buildVirtualEnv(venvFor!!) { venvFor = null }
                    }, enabled = !busyProjects.contains(venvFor!!.dir.absolutePath)) {
                        Text("(Re)build virtualenv now", color = Color(IdeTheme.ACCENT))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val p = venvFor!!
                    projectsViewModel.saveVenvName(p, venvText) { venvFor = null }
                }, enabled = !busyProjects.contains(venvFor!!.dir.absolutePath)) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { venvFor = null }) { Text("Cancel") } }
        )
    }
    if (renameFor != null) {
        IdeAlertDialog(
            onDismissRequest = { renameFor = null },
            title = { Text("Rename project") },
            text = {
                OutlinedTextField(
                    value = renameText, onValueChange = { renameText = it },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val r = renameFor!!
                    projectsViewModel.renameProject(r, renameText) {
                        onProjectGone(r.dir)
                        renameFor = null
                    }
                }, enabled = !busyProjects.contains(renameFor!!.dir.absolutePath)) { Text("Rename") }
            },
            dismissButton = { TextButton(onClick = { renameFor = null }) { Text("Cancel") } }
        )
    }
    if (confirmDel != null) {
        IdeAlertDialog(
            onDismissRequest = { confirmDel = null },
            title = { Text("Delete project?") },
            text = { Text("\"${confirmDel!!.name}\" and all its files will be removed.") },
            confirmButton = {
                TextButton(onClick = {
                    val gone = confirmDel!!
                    projectsViewModel.deleteProject(gone)
                    confirmDel = null
                }, enabled = !busyProjects.contains(confirmDel!!.dir.absolutePath)) {
                    Text("Delete", color = Color(IdeTheme.ERROR))
                }
            },
            dismissButton = { TextButton(onClick = { confirmDel = null }) { Text("Cancel") } }
        )
    }
}

// ------------------------------- Packages ----------------------------------
