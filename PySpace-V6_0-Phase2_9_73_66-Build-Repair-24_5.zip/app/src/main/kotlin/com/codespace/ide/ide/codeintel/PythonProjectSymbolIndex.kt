package com.codespace.ide.ide.codeintel

import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.nio.file.Files
import java.util.ArrayDeque
import com.codespace.ide.memory.MemoryTrimRegistry
import com.codespace.ide.memory.MemoryTrimmable

/** Fast, non-executing index of importable symbols in the active Python project. */
object PythonProjectSymbolIndex : MemoryTrimmable {
    data class Symbol(val name: String, val module: String, val fileName: String, val callable: Boolean)
    data class Module(val name: String, val fileName: String)
    data class Snapshot(val symbols: List<Symbol>, val modules: List<Module>)

    private data class CacheEntry(val createdAt: Long, val snapshot: Snapshot)
    private val cache = ConcurrentHashMap<String, CacheEntry>()
    private const val CACHE_TTL_MS = 15_000L
    private const val MAX_FILES = 1400
    private const val MAX_CACHE_ENTRIES = 6
    private const val MAX_FILE_BYTES = 384 * 1024L
    private val ignored = setOf(".git", ".venv", "venv", "env", "__pycache__", "build", "dist", "node_modules", ".pytest_cache", ".mypy_cache", ".idea", ".gradle")
    private val declaration = Regex("^([ \\t]*)(?:async[ \\t]+def|def|class)[ \\t]+([A-Za-z_][A-Za-z0-9_]*)")
    private val assignment = Regex("^([ \\t]*)([A-Za-z_][A-Za-z0-9_]*)[ \\t]*(?::[^=]+)?=(?!=)")

    init { MemoryTrimRegistry.register(this) }

    fun snapshot(projectRoot: File?): Snapshot {
        if (projectRoot == null) return Snapshot(emptyList(), emptyList())
        val root = try { projectRoot.canonicalFile } catch (_: Exception) { projectRoot.absoluteFile }
        if (!root.isDirectory) return Snapshot(emptyList(), emptyList())
        val key = root.absolutePath
        val now = System.currentTimeMillis()
        cache[key]?.takeIf { now - it.createdAt < CACHE_TTL_MS }?.let { return it.snapshot }
        val built = build(root)
        cache[key] = CacheEntry(now, built)
        if (cache.size > MAX_CACHE_ENTRIES) {
            cache.entries.removeIf { now - it.value.createdAt > CACHE_TTL_MS * 4 }
            if (cache.size > MAX_CACHE_ENTRIES) {
                val oldest = cache.entries.sortedBy { it.value.createdAt }
                    .take(cache.size - MAX_CACHE_ENTRIES)
                oldest.forEach { cache.remove(it.key, it.value) }
            }
        }
        return built
    }

    private fun build(root: File): Snapshot {
        val roots = listOf(root, File(root, "src"), File(root, "lib")).filter { it.isDirectory }
        val files = LinkedHashMap<String, Pair<File, String>>()
        val modules = LinkedHashMap<String, Module>()
        val symbols = LinkedHashMap<String, Symbol>()
        var visited = 0
        for (sourceRoot in roots) {
            val queue = ArrayDeque<File>()
            queue.add(sourceRoot)
            while (queue.isNotEmpty() && visited < MAX_FILES) {
                val dir = queue.removeFirst()
                val children = try { dir.listFiles()?.sortedBy { it.name } ?: emptyList() } catch (_: Exception) { emptyList() }
                for (child in children) {
                    if (visited >= MAX_FILES) break
                    if (child.isDirectory) {
                        if (!Files.isSymbolicLink(child.toPath()) && child.name !in ignored &&
                            !(sourceRoot == root && child.name in setOf("src", "lib")) && !child.name.startsWith(".")) queue.add(child)
                    } else if (child.isFile && !Files.isSymbolicLink(child.toPath()) && child.extension.equals("py", true) && child.length() <= MAX_FILE_BYTES) {
                        visited++
                        val rel = try { child.canonicalFile.relativeTo(sourceRoot.canonicalFile).invariantSeparatorsPath } catch (_: Exception) { continue }
                        if (rel.startsWith("../")) continue
                        val parts = rel.removeSuffix(".py").split('/').filter { it.isNotBlank() }
                        if (parts.isEmpty() || parts.any { it in ignored || it.startsWith(".") }) continue
                        val moduleParts = if (parts.last() == "__init__") parts.dropLast(1) else parts
                        if (moduleParts.isEmpty()) continue
                        val module = moduleParts.joinToString(".")
                        modules.putIfAbsent(module, Module(module, child.name))
                        files[module] = child to rel
                    }
                }
            }
        }
        for ((module, pair) in files) {
            val file = pair.first
            val lines = try { file.readLines(Charsets.UTF_8).take(12000) } catch (_: Exception) { continue }
            for (line in lines) {
                val match = declaration.find(line)
                if (match != null) {
                    if (match.groupValues[1].isNotEmpty()) continue
                    val name = match.groupValues[2]
                    if (!name.startsWith("_") && name !in setOf("main")) {
                        val callable = Regex("^(?:async[ \\t]+def|def|class)").containsMatchIn(line)
                        symbols.putIfAbsent("$module:$name", Symbol(name, module, file.name, callable))
                    }
                    continue
                }
                val assign = assignment.find(line) ?: continue
                if (assign.groupValues[1].isNotEmpty()) continue
                val name = assign.groupValues[2]
                if (!name.startsWith("_") && name !in setOf("__all__")) symbols.putIfAbsent("$module:$name", Symbol(name, module, file.name, false))
            }
        }
        return Snapshot(symbols.values.toList(), modules.values.toList())
    }

    override fun trimToPolicy() {
        // Symbol snapshots are cheap to rebuild and can retain many declarations.
        cache.clear()
    }

    override fun clearTemporaryCaches() {
        cache.clear()
    }

    fun invalidate(projectRoot: File?) {
        if (projectRoot == null) return
        val key = try { projectRoot.canonicalPath } catch (_: Exception) { projectRoot.absolutePath }
        cache.remove(key)
    }
}
