package com.codespace.ide.ide.gui


/**
 * One graphical output family. [importRoots] decide that a file may draw
 * something; [needs] (optional) narrows that to files that actually DO (a
 * script that only `savefig`s must not pop a display up).
 *
 * Adding a toolkit = one line here. Everything else (display, env, window
 * sizing) is shared by [guiLaunchPrefix].
 */
private data class GuiFramework(
    val framework: String,
    val importRoots: List<String>,
    val pipHint: String,
    val needs: Regex? = null
)

private val GUI_FRAMEWORKS = listOf(
    GuiFramework("kivy", listOf("kivy"), "pip install kivy"),
    GuiFramework("tkinter", listOf("tkinter", "Tkinter"), "python3-tk (in the GUI installer below)"),
    GuiFramework("turtle", listOf("turtle"), "python3-tk (in the GUI installer below)"),
    GuiFramework("PyQt5", listOf("PyQt5"), "pip install PyQt5"),
    GuiFramework("PyQt6", listOf("PyQt6"), "pip install PyQt6"),
    GuiFramework("PySide2", listOf("PySide2"), "pip install PySide2"),
    GuiFramework("PySide6", listOf("PySide6"), "pip install PySide6"),
    GuiFramework("pygame", listOf("pygame"), "pip install pygame"),
    GuiFramework("wxPython", listOf("wx"), "pip install wxPython"),
    GuiFramework("customtkinter", listOf("customtkinter"), "pip install customtkinter"),
    GuiFramework("ttkbootstrap", listOf("ttkbootstrap"), "pip install ttkbootstrap"),
    GuiFramework("PySimpleGUI", listOf("PySimpleGUI", "FreeSimpleGUI"), "pip install PySimpleGUI"),
    GuiFramework("flet", listOf("flet"), "pip install flet"),
    GuiFramework("dearpygui", listOf("dearpygui"), "pip install dearpygui"),
    GuiFramework("pyglet", listOf("pyglet"), "pip install pyglet"),
    GuiFramework("arcade", listOf("arcade"), "pip install arcade"),
    GuiFramework("ursina", listOf("ursina"), "pip install ursina"),
    GuiFramework("panda3d", listOf("panda3d", "direct"), "pip install panda3d"),
    GuiFramework("pyqtgraph", listOf("pyqtgraph"), "pip install pyqtgraph PyQt5"),
    GuiFramework("vispy", listOf("vispy"), "pip install vispy PyQt5"),
    GuiFramework("toga", listOf("toga"), "pip install toga"),
    GuiFramework("easygui", listOf("easygui"), "pip install easygui"),
    // Plots: only files that really show something (plt.show(), animations,
    // interactive mode). Without a display matplotlib silently falls back
    // to the non-interactive Agg backend, which is why live charts never
    // appeared even though savefig() worked.
    GuiFramework(
        "matplotlib",
        listOf("matplotlib", "pylab", "seaborn", "mpl_toolkits"),
        "pip install matplotlib",
        Regex("""\b(show|pause|ion|waitforbuttonpress|ginput|FuncAnimation|ArtistAnimation)\s*\(""")
    ),
    GuiFramework(
        "opencv", listOf("cv2"), "pip install opencv-python",
        Regex("""\bimshow\s*\(""")
    )
)

/**
 * Programs that only show pictures/plots (cv2.imshow, matplotlib) can skip
 * X11/VNC entirely: a Python shim sends JPEG frames to the IDE (see
 * FrameView.kt). Anything that needs real windows or widgets keeps the X11
 * display: other toolkits in the same file, animations, trackbars, ROI
 * selection, matplotlib widgets/events.
 */
private val FRAME_BLOCKERS = Regex(
    """\b(FuncAnimation|ArtistAnimation|ginput|waitforbuttonpress|mpl_connect|""" +
    """createTrackbar|getTrackbarPos|selectROI|selectROIs)\b|matplotlib\.widgets"""
)

fun frameViewEligible(gui: GuiApp, source: String?): Boolean {
    if (gui.framework != "opencv" && gui.framework != "matplotlib") return false
    val text = (source ?: "").take(200_000)
    if (text.isBlank() || FRAME_BLOCKERS.containsMatchIn(text)) return false
    for (raw in text.lineSequence()) {
        val line = raw.trimStart().lowercase()
        val stmt = when {
            line.startsWith("import ") -> line.removePrefix("import ")
            line.startsWith("from ") -> line.removePrefix("from ")
            else -> continue
        }
        for (part in stmt.split(",")) {
            val head = part.trim().split(Regex("[\\s.]"), 2).firstOrNull() ?: continue
            for (fw in GUI_FRAMEWORKS) {
                if (fw.framework == "opencv" || fw.framework == "matplotlib") continue
                if (fw.importRoots.any { it.lowercase() == head }) return false
            }
        }
    }
    return true
}

/** A GUI app file: framework name plus its install hint. */
data class GuiApp(val framework: String, val pipHint: String)

/**
 * Detects graphical-output imports (`import kivy`, `from tkinter import …`,
 * `import matplotlib.pyplot as plt` + `plt.show()`) in the run file.
 * In-memory scan of the editor buffer, same cost class as the web-server
 * detection. Returns null for files that draw nothing.
 */
fun detectGuiFromSource(fileName: String, source: String?): GuiApp? {
    if (fileName.substringAfterLast('.', "").lowercase() != "py") return null
    val text = (source ?: "").take(200_000)
    if (text.isBlank()) return null
    for (raw in text.lineSequence()) {
        val line = raw.trimStart()
        if (line.isEmpty() || line.startsWith("#")) continue
        val lower = line.lowercase()
        val stmt = when {
            lower.startsWith("import ") -> lower.removePrefix("import ")
            lower.startsWith("from ") -> lower.removePrefix("from ")
            else -> continue
        }
        // Each comma part's head (`kivy.app` -> `kivy`, `tkinter as tk` -> `tkinter`).
        for (part in stmt.split(",")) {
            val head = part.trim().split(Regex("[\\s.]"), 2).firstOrNull() ?: continue
            for (fw in GUI_FRAMEWORKS) {
                if (fw.importRoots.any { it.lowercase() == head }) {
                    if (fw.needs != null && !fw.needs.containsMatchIn(text)) continue
                    return GuiApp(fw.framework, fw.pipHint)
                }
            }
        }
    }
    return null
}

/**
 * Python shim loaded into graphical runs (via PYTHONPATH/sitecustomize):
 * Kivy draws text with SDL2_ttf, which neither joins Arabic/Persian letters
 * nor reverses right-to-left text, so "صفحه اول" came out as detached letters
 * in the wrong order. The shim shapes and reorders every Kivy label itself
 * (plain Python, no pip packages), so existing code needs no changes.
 * Bump [GUI_SHIM_VERSION] whenever this text changes.
 */
private const val GUI_SHIM_VERSION = "v1"
private val GUI_SHIM_SOURCE = """# IDE display shim (v1): Persian/Arabic/Hebrew text in toolkits that draw text
# without shaping or bidi (Kivy's SDL2 text provider). Pure Python, no pip
# packages: the joining forms come from the interpreter's own Unicode
# database. Anything unexpected falls through to the untouched behaviour.
import sys
import re
import unicodedata

_RTL_RE = re.compile('[\u0590-\u08ff\ufb1d-\ufdff\ufe70-\ufeff]')
_PRESENTATION_RE = re.compile('[\ufb50-\ufdff\ufe70-\ufefc]')
_TAG_RE = re.compile(
    r'(\[/?(?:b|i|u|s|sub|sup|font|font_family|font_context|font_features|'
    r'size|color|ref|anchor|text_language)(?:=[^\]]*)?\])')
_MIRROR = {'(': ')', ')': '(', '[': ']', ']': '[', '{': '}', '}': '{',
           '<': '>', '>': '<', '\u00ab': '\u00bb', '\u00bb': '\u00ab'}
_ALEF = {'\u0622', '\u0623', '\u0625', '\u0627'}
_LAM = '\u0644'

_ISO, _FIN, _INI, _MED, _LIG = {}, {}, {}, {}, {}


def _build_tables():
    maps = {'isolated': _ISO, 'final': _FIN, 'initial': _INI, 'medial': _MED}
    for cp in list(range(0xFB50, 0xFDFF + 1)) + list(range(0xFE70, 0xFEFC + 1)):
        ch = chr(cp)
        dec = unicodedata.decomposition(ch)
        if not dec.startswith('<'):
            continue
        tag, _, rest = dec[1:].partition('> ')
        if tag not in maps:
            continue
        base = [chr(int(x, 16)) for x in rest.split()]
        if len(base) == 1:
            maps[tag].setdefault(base[0], ch)
        elif len(base) == 2 and base[0] == _LAM and base[1] in _ALEF:
            _LIG.setdefault((base[0], base[1]), {})[tag] = ch


_build_tables()
_DUAL = set(_INI) | set(_MED)      # joins to the NEXT letter
_JOINS_PREV = set(_FIN)            # can join to the PREVIOUS letter


def _transparent(ch):
    return unicodedata.category(ch) == 'Mn'


def _shape_line(s):
    n = len(s)
    out = []
    i = 0
    while i < n:
        c = s[i]
        if c == '\u200c':          # ZWNJ: only breaks joining, draws nothing
            i += 1
            continue
        if c == '\u200d':          # ZWJ
            i += 1
            continue
        if c not in _ISO and c not in _FIN:
            out.append(c)
            i += 1
            continue
        # neighbours (skipping diacritics and joiner controls)
        j = i - 1
        while j >= 0 and (_transparent(s[j]) or s[j] == '\u200d'):
            j -= 1
        prev_c = s[j] if j >= 0 else None
        prev_breaks = j >= 0 and j + 1 <= i - 1 and s[i - 1] == '\u200c'
        k = i + 1
        while k < n and (_transparent(s[k]) or s[k] == '\u200d'):
            k += 1
        next_c = s[k] if k < n else None
        zwnj_before = i > 0 and s[i - 1] == '\u200c'
        zwnj_after = i + 1 < n and s[i + 1] == '\u200c'
        connect_prev = (prev_c in _DUAL and c in _JOINS_PREV
                        and not zwnj_before)
        # lam + alef ligature
        if c == _LAM and next_c in _ALEF and (c, next_c) in _LIG:
            forms = _LIG[(c, next_c)]
            glyph = forms.get('final') if connect_prev else forms.get('isolated')
            if glyph:
                out.append(glyph)
                out.extend(m for m in s[i + 1:k] if _transparent(m))
                i = k + 1
                continue
        connect_next = (c in _DUAL and next_c in _JOINS_PREV
                        and not zwnj_after)
        if connect_prev and connect_next:
            g = _MED.get(c)
        elif connect_prev:
            g = _FIN.get(c)
        elif connect_next:
            g = _INI.get(c)
        else:
            g = _ISO.get(c)
        out.append(g or c)
        i += 1
    return ''.join(out)


def _dir(ch):
    bc = unicodedata.bidirectional(ch)
    if bc in ('R', 'AL'):
        return 'R'
    if bc in ('L', 'EN', 'AN'):
        return 'L'
    return 'O'


def _reorder_line(s):
    if not s:
        return s
    # clusters: a base char with its following combining marks
    clusters = []
    for ch in s:
        if clusters and _transparent(ch):
            clusters[-1] += ch
        else:
            clusters.append(ch)
    dirs = [_dir(c[0]) for c in clusters]
    base = next((d for d in dirs if d != 'O'), 'L')
    if base == 'L' and 'R' not in dirs:
        return s
    # neutrals take the direction of their surroundings, else the base's
    res = list(dirs)
    n = len(res)
    i = 0
    while i < n:
        if res[i] != 'O':
            i += 1
            continue
        j = i
        while j < n and res[j] == 'O':
            j += 1
        left = res[i - 1] if i > 0 else base
        right = res[j] if j < n else base
        d = left if left == right else base
        for t in range(i, j):
            res[t] = d
        i = j
    # runs
    runs = []
    for c, d in zip(clusters, res):
        if runs and runs[-1][0] == d:
            runs[-1][1].append(c)
        else:
            runs.append([d, [c]])
    pieces = []
    for d, cs in runs:
        if d == 'R':
            cs = [_MIRROR.get(c, c) if len(c) == 1 else c for c in reversed(cs)]
        pieces.append(''.join(cs))
    if base == 'R':
        pieces.reverse()
    return ''.join(pieces)


def shape(text):
    # logical-order text -> what a left-to-right glyph painter must draw
    try:
        if not text or not _RTL_RE.search(text):
            return text
        if _PRESENTATION_RE.search(text):
            return text            # already shaped by the program itself
        return '\n'.join(_reorder_line(_shape_line(ln)) for ln in text.split('\n'))
    except Exception:
        return text


def shape_markup(text):
    if '[' in text and _TAG_RE.search(text):
        parts = _TAG_RE.split(text)
        return ''.join(p if (i % 2) else shape(p) for i, p in enumerate(parts))
    return shape(text)


# ---------------------------------------------------------------- kivy hook
def _patch_kivy_text(module):
    base = module.Label
    if getattr(base, '_ide_shaped', False):
        return

    class ShapedLabel(base):
        _ide_shaped = True

        def __init__(self, *a, **kw):
            t = kw.get('text')
            if isinstance(t, str):
                kw['text'] = shape_markup(t)
            super().__init__(*a, **kw)

        def __setattr__(self, name, value):
            if name in ('text', 'label') and isinstance(value, str):
                value = shape_markup(value)
            super().__setattr__(name, value)

    ShapedLabel.__name__ = base.__name__
    ShapedLabel.__qualname__ = base.__qualname__
    module.Label = ShapedLabel


try:
    import importlib.abc
    import importlib.util

    class _KivyTextFinder(importlib.abc.MetaPathFinder):
        _busy = False

        def find_spec(self, name, path, target=None):
            if name != 'kivy.core.text' or self._busy:
                return None
            self._busy = True
            try:
                spec = importlib.util.find_spec(name)
            except Exception:
                spec = None
            finally:
                self._busy = False
            if spec is None or spec.loader is None:
                return None
            loader = spec.loader
            orig = loader.exec_module

            def exec_module(module, _orig=orig):
                _orig(module)
                try:
                    _patch_kivy_text(module)
                except Exception:
                    pass

            try:
                loader.exec_module = exec_module
            except Exception:
                return None
            return spec

    sys.meta_path.insert(0, _KivyTextFinder())
except Exception:
    pass
"""

/**
 * Shell statements that prepare ONE graphical run; they go in front of the
 * python command, inside the same `sh -c`.
 *
 * Order matters and is the point of this function:
 *  1. The program is started FIRST. The display is brought up in parallel by
 *     the IDE, so output starts flowing at once; this prefix only makes the
 *     program wait (briefly, normally not at all) until the display answers,
 *     so a toolkit never races its X server.
 *  2. Common environment every X toolkit needs here (no GPU, no shared
 *     memory, no audio device, no window manager).
 *  3. Per-toolkit extras. A toolkit that needs something special gets it
 *     here, at the moment of the run.
 */
fun guiLaunchPrefix(gui: GuiApp, pythonBin: String, frame: Boolean = false): String {
    val b = StringBuilder()
    if (frame) {
        // Frame-view run: no display server at all. Clean the exchange dir,
        // install the Python shims once, and append them to PYTHONPATH (at the
        // END, so the camera adapter's sitecustomize still comes first and
        // chains to this one).
        val v = VIEW_SHIM_VERSION
        b.append("mkdir -p /tmp/ide-view; rm -f /tmp/ide-view/frame.jpg /tmp/ide-view/frame.tmp /tmp/ide-view/events; ")
        b.append("__vd=/opt/ide-view/$v; ")
        b.append("[ -f \"\$__vd/.ok\" ] || { mkdir -p \"\$__vd\" 2>/dev/null || ")
        b.append("{ __vd=/tmp/ide-view-shim/$v; mkdir -p \"\$__vd\"; }; ")
        b.append("cat > \"\$__vd/ide_view_shim.py\" <<'PYEOF'\n" + VIEW_SHIM_SOURCE + "\nPYEOF\n")
        b.append("cat > \"\$__vd/ide_mpl_backend.py\" <<'PYEOF'\n" + VIEW_MPL_BACKEND_SOURCE + "\nPYEOF\n")
        b.append("printf 'import ide_view_shim\\n' > \"\$__vd/sitecustomize.py\"; touch \"\$__vd/.ok\"; }\n")
        b.append("[ -f /opt/ide-view/$v/.ok ] && __vd=/opt/ide-view/$v || __vd=/tmp/ide-view-shim/$v; ")
        b.append("export IDE_VIEW_DIR=/tmp/ide-view PYTHONPATH=\"\${PYTHONPATH:+\$PYTHONPATH:}\$__vd\"; ")
        if (gui.framework == "matplotlib") b.append("export MPLBACKEND=module://ide_mpl_backend; ")
        return b.toString()
    }
    // 1. Wait for the display (pid file is optional: an Xvnc that an older
    // IDE build left running has none).
    // Never leave the console blank while the display boots.
    b.append("[ -S /tmp/.X11-unix/X1 ] || echo \"[display] starting the display...\"; ")
    b.append(
        "__d=0; until [ -S /tmp/.X11-unix/X1 ] && " +
        "{ [ ! -s /tmp/xvnc.pid ] || kill -0 \"\$(cat /tmp/xvnc.pid)\" 2>/dev/null; }; do " +
        "__d=\$((__d+1)); [ \$__d -gt 200 ] && break; sleep 0.1; done; "
    )
    b.append(
        "[ -S /tmp/.X11-unix/X1 ] || " +
        "echo \"[display] not ready - the window may fail to open\"; "
    )
    // The window manager must own the screen BEFORE the program creates its window, or that
    // window stays where the toolkit put it. Wait (at most ~4 s) only while it is alive but not ready.
    b.append(
        "__w=0; while [ -s /tmp/ide-wm.pid ] && kill -0 \"\$(cat /tmp/ide-wm.pid)\" 2>/dev/null " +
        "&& [ ! -f /tmp/ide-wm.ready ] && [ \$__w -lt 40 ]; do __w=\$((__w+1)); sleep 0.1; done; "
    )
    // 2. Common environment.
    // LIBGL_ALWAYS_SOFTWARE: no GPU, Mesa llvmpipe renders.
    // SDL_VIDEODRIVER/SDL_AUDIODRIVER: SDL toolkits use X, and a dummy audio
    //   device keeps pygame.mixer & co from failing on a phone without ALSA.
    // QT_*: Qt must use xcb, and its MIT-SHM path does not work over Xvnc.
    b.append(
        "export DISPLAY=:1 LIBGL_ALWAYS_SOFTWARE=1 SDL_VIDEODRIVER=x11 " +
        "SDL_AUDIODRIVER=dummy QT_QPA_PLATFORM=xcb QT_X11_NO_MITSHM=1 " +
        "GDK_BACKEND=x11; "
    )
    // 3. Per-toolkit extras.
    when (gui.framework) {
        "kivy" -> {
            // Fill the display with the window (there is no window manager,
            // a default 800x600 window is clipped on a portrait display);
            // 30 fps cap (software GL); Esc must not quit the app (phone
            // Back is sent as Esc).
            b.append(
                "export KCFG_GRAPHICS_BORDERLESS=1 KCFG_GRAPHICS_RESIZABLE=0 " +
                "KCFG_GRAPHICS_POSITION=custom KCFG_GRAPHICS_LEFT=0 " +
                "KCFG_GRAPHICS_TOP=0 KCFG_GRAPHICS_FULLSCREEN=0 " +
                "KCFG_GRAPHICS_MAXFPS=30 KCFG_KIVY_EXIT_ON_ESCAPE=0; "
            )
            b.append(
                "{ read -r __g < /tmp/ide-app-size; } 2>/dev/null || " +
                "{ read -r __g < /tmp/xvnc-geom; } 2>/dev/null; " +
                "if [ -n \"\$__g\" ]; then " +
                "export KCFG_GRAPHICS_WIDTH=\${__g%x*} KCFG_GRAPHICS_HEIGHT=\${__g#*x}; fi; "
            )
            // Once: make DejaVu (has Arabic/Persian glyphs) Kivy's default
            // font so Persian text is not boxes, unless the user chose one.
            b.append(
                "[ -f \"\$HOME/.kivy/.ide-font\" ] || { python3 - <<'PY'\n" +
                "import configparser, os\n" +
                "f='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'\n" +
                "b='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'\n" +
                "if os.path.exists(f) and os.path.exists(b):\n" +
                "    p=os.path.expanduser('~/.kivy/config.ini')\n" +
                "    os.makedirs(os.path.dirname(p), exist_ok=True)\n" +
                "    c=configparser.ConfigParser(); c.optionxform=str; c.read(p)\n" +
                "    if not c.has_section('kivy'): c.add_section('kivy')\n" +
                "    cur=c.get('kivy','default_font',fallback='')\n" +
                "    if (not cur) or 'Roboto-Regular' in cur:\n" +
                "        c.set('kivy','default_font',repr(['Roboto',f,f,b,b]))\n" +
                "        c.write(open(p,'w'))\n" +
                "PY\n" +
                "mkdir -p \"\$HOME/.kivy\"; touch \"\$HOME/.kivy/.ide-font\"; }\n"
            )
            // Persian/Arabic shaping + bidi for every Kivy label (see shim).
            b.append(
                "[ -f /opt/ide-shim/$GUI_SHIM_VERSION/.ok ] || { " +
                "mkdir -p /opt/ide-shim/$GUI_SHIM_VERSION && " +
                "cat > /opt/ide-shim/$GUI_SHIM_VERSION/sitecustomize.py <<'PYEOF'\n" +
                GUI_SHIM_SOURCE + "\nPYEOF\n" +
                "touch /opt/ide-shim/$GUI_SHIM_VERSION/.ok; }\n" +
                "export PYTHONPATH=/opt/ide-shim/$GUI_SHIM_VERSION\${PYTHONPATH:+:\$PYTHONPATH}; "
            )
        }
        "matplotlib" -> {
            // Pick the Tk backend only when tkinter really exists for THIS
            // python (an explicit matplotlib.use() in the code still wins).
            b.append(
                "if \"$pythonBin\" -c \"import tkinter\" >/dev/null 2>&1; then " +
                "export MPLBACKEND=TkAgg; else " +
                "echo \"[display] python3-tk is missing: install it from " +
                "Settings > GUI libraries so matplotlib can open windows\"; fi; "
            )
        }
    }
    return b.toString()
}
