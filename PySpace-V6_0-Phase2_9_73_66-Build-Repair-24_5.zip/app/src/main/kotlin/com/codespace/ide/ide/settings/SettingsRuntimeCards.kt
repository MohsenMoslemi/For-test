package com.codespace.ide.ide.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ProotManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.codespace.ide.UbuntuManager
import com.codespace.ide.ide.PythonRuntimeCatalog
import com.codespace.ide.ide.PythonRuntimeOption
import com.codespace.ide.ide.display.VncDisplay
import com.codespace.ide.ide.projects.ProjectsUiState
import com.codespace.ide.ide.terminal.TermController
import com.codespace.ide.ide.theme.IdeTheme

/** Python interpreter inventory shared with project creation. */
@Composable
internal fun PythonRuntimeSettingsCard(
    state: com.codespace.ide.ide.projects.ProjectsUiState,
    interpreterRuntimeInUse: String,
    onRefresh: () -> Unit,
    onInstall: (String) -> Unit,
    onRemove: (String) -> Unit,
    onCancelDownload: (String) -> Unit,
) {
    var removeTarget by remember { mutableStateOf<com.codespace.ide.ide.PythonRuntimeOption?>(null) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.CARD)), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text("Python interpreters", fontWeight = FontWeight.Bold, color = Color(IdeTheme.TEXT), fontSize = 15.sp)
                Spacer(Modifier.height(4.dp))
                Text("Manage the Python versions available when creating projects. The bundled interpreter is required by PySpace and cannot be removed.", color = Color(IdeTheme.DIM), fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                TextButton(onClick = onRefresh) { Text("Refresh status", color = Color(IdeTheme.ACCENT)) }
            }
        }
        com.codespace.ide.ide.PythonRuntimeCatalog.options.forEach { option ->
            val runtime = state.runtimeInstallStates[option.id]
            val installed = option.isBundled || runtime?.status == "installed"
            val busy = runtime?.status == "preparing" || runtime?.status == "downloading" || runtime?.status == "installing" || runtime?.status == "removing"
            val downloading = runtime?.status == "downloading" || runtime?.status == "preparing"
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.CARD)), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)).background(Color(IdeTheme.ACCENT).copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                            Text("Py", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Python ${option.version}", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text(if (option.isBundled) "Bundled · Required" else option.description, color = Color(IdeTheme.DIM), fontSize = 11.sp)
                        }
                        when {
                            installed -> Text("Installed", color = Color(IdeTheme.ACCENT), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            busy && downloading -> Text("Downloading…", color = Color(IdeTheme.WARN), fontSize = 11.sp)
                            busy -> Text("Installing…", color = Color(IdeTheme.WARN), fontSize = 11.sp)
                            else -> Button(onClick = { onInstall(option.id) }, colors = ButtonDefaults.buttonColors(containerColor = Color(IdeTheme.ACCENT), contentColor = Color(IdeTheme.ON_ACCENT))) { Text("Install") }
                        }
                    }
                    if (busy) {
                        Spacer(Modifier.height(8.dp))
                        Text(runtime?.message ?: "Working…", color = Color(IdeTheme.DIM), fontSize = 11.sp)
                        runtime?.fraction?.let { LinearProgressIndicator(progress = { it.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = Color(IdeTheme.ACCENT)) }
                            ?: LinearProgressIndicator(Modifier.fillMaxWidth(), color = Color(IdeTheme.ACCENT))
                        if (downloading) {
                            Spacer(Modifier.height(4.dp))
                            TextButton(onClick = { onCancelDownload(option.id) }, modifier = Modifier.fillMaxWidth()) { Text("Cancel download", color = Color(IdeTheme.ERROR)) }
                        } else if (runtime?.status == "installing") {
                            Spacer(Modifier.height(4.dp))
                            TextButton(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth()) { Text("Installing…") }
                        }
                    }
                    if (runtime?.status == "error") {
                        Spacer(Modifier.height(5.dp))
                        Text(runtime.error ?: "Operation failed", color = Color(IdeTheme.WARN), fontSize = 11.sp)
                        TextButton(onClick = { if (runtime.message == "Remove") onRemove(option.id) else onInstall(option.id) }) { Text(if (runtime.message == "Remove") "Retry removal" else "Retry install", color = Color(IdeTheme.ACCENT)) }
                    }
                    if (installed && !option.isBundled) {
                        Spacer(Modifier.height(3.dp))
                        if (option.id == interpreterRuntimeInUse) {
                            Text("In use by the interactive Python interpreter", color = Color(IdeTheme.DIM), fontSize = 10.sp)
                        } else {
                            TextButton(onClick = { removeTarget = option }, enabled = !busy) { Text("Uninstall", color = Color(IdeTheme.WARN), fontSize = 12.sp) }
                        }
                    }
                }
            }
        }
    }
    removeTarget?.let { option ->
        IdeAlertDialog(
            onDismissRequest = { removeTarget = null },
            title = { Text("Remove Python ${option.version}?") },
            text = { Text("The interpreter files will be removed. Projects using this version are protected and must be changed to another interpreter first.") },
            confirmButton = { TextButton(onClick = { onRemove(option.id); removeTarget = null }) { Text("Remove", color = Color(IdeTheme.WARN)) } },
            dismissButton = { TextButton(onClick = { removeTarget = null }) { Text("Cancel") } },
            containerColor = Color(IdeTheme.PANEL),
            titleContentColor = Color(IdeTheme.TEXT),
            textContentColor = Color(IdeTheme.DIM)
        )
    }
}

/** Web preview preference: where a running server's page opens. */
@Composable
internal fun WebSettingsCard(
    settings: IdeSettingsState,
    viewModel: SettingsViewModel,
) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.CARD)), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text("WEB PREVIEW", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.3.sp)
            Spacer(Modifier.height(8.dp))
            Text("Open web pages in", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                "Where the Browser button opens your running web app. The IDE browser has device modes " +
                    "(phone, tablet, laptop, desktop) and a console.",
                color = Color(IdeTheme.DIM), fontSize = 11.sp
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                for ((key, label) in listOf("ask" to "Ask me", "ide" to "IDE browser", "phone" to "Phone browser")) {
                    val on = settings.webOpenMode == key
                    Text(
                        label, fontSize = 12.sp,
                        color = Color(if (on) IdeTheme.ON_ACCENT else IdeTheme.TEXT),
                        modifier = Modifier.clip(RoundedCornerShape(10.dp))
                            .background(Color(if (on) IdeTheme.ACCENT else IdeTheme.PANEL))
                            .clickable { viewModel.setWebOpenMode(key) }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }
    }
}

/** One-shot X11/toolkit libraries for GUI apps (Ubuntu 24.04 ARM64 names). */
internal const val GUI_APT_PKGS =
"tigervnc-standalone-server xfonts-base x11-apps python3-tk fonts-dejavu-core " +
"libsdl2-2.0-0 libsdl2-image-2.0-0 libsdl2-mixer-2.0-0 " +
"libsdl2-ttf-2.0-0 libgl1 libegl1 libmtdev1 libgl1-mesa-dri " +
"libxkbcommon0 libxkbcommon-x11-0 libxcb-cursor0 libxcb-icccm4 " +
"libxcb-image0 libxcb-keysyms1 libxcb-render-util0"

/**
 * Built-in display (Xvnc in guest + in-app viewer): no other app needed.
 * Start here once (or just Run a GUI file), Stop when done. Install runs
 * apt in the terminal panel (fake-root guest, needs guest network).
 */
@Composable
internal fun DisplayCard(
    display: VncDisplay,
    proot: ProotManager,
    installCmd: String?,
    installRunId: Int,
    installCtl: TermController,
    onInstallTap: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var result by remember { mutableStateOf("Not started yet.") }
    var installing by remember { mutableStateOf(false) }

    fun checkLibs() {
        result = "Checking GUI libraries…"
        scope.launch(Dispatchers.IO) {
            val out = try {
                proot.runOnce(
                    "ldconfig -p 2>/dev/null | grep -E 'libGL\\.so|libSDL2|libmtdev\\.so|libtk8\\.' ; " +
                    "command -v Xvnc >/dev/null 2>&1 && echo HAVE-XVNC || echo NO-XVNC"
                )
            } catch (t: Throwable) {
                "ERROR: ${t.message}"
            }
            withContext(Dispatchers.Main) {
                val need = listOf(
                    "libGL.so.1" to "libgl1",
                    "libSDL2-2.0.so" to "libsdl2",
                    "libmtdev.so.1" to "libmtdev1",
                    "libtk8." to "python3-tk"
                )
                val missing = need.filter { !out.contains(it.first) }.map { it.second }
                val missingAll =
                missing + if (out.lines().any { it.trim() == "HAVE-XVNC" }) {
                    emptyList()
                } else {
                    listOf("tigervnc (Xvnc)")
                }
                result = if (missingAll.isEmpty()) {
                    "GUI libraries OK ✓ (GL, SDL2, mtdev, tk, Xvnc present)"
                } else {
                    "Missing: " + missingAll.joinToString(", ") +
                    " — run Install GUI libraries."
                }
            }
        }
    }

    /** Completion watcher: the session calls this on Main when apt exits.
     *  Reads the exit marker from the transcript tail — no polling. */
    installCtl.onDone = {
        val tail = try {
            installCtl.transcriptTail?.invoke()
        } catch (_: Exception) {
            null
        }
        installing = false
        if (tail != null && tail.contains("INSTALL-EXIT:0")) {
            result = "Install finished ✓ — tap Check libraries."
            checkLibs()
        } else {
            result = "Install failed — see the log above."
        }
    }

    Card(colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.CARD)), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text("Display (GUI apps)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                "Built-in Linux display — GUI windows (Kivy, tkinter, Qt, pygame…) " +
                "open right here. No other app needed.",
                color = Color(IdeTheme.DIM), fontSize = 12.sp
            )
            Text("1. Install GUI libraries once (needs guest network).", fontSize = 12.sp)
            Text("2. Just Run a GUI file — the display starts itself.", fontSize = 12.sp)
            Text("3. pip-install your framework, then Run. Tap 🖥 to reopen.", fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Text("Status: " + display.status, color = Color(IdeTheme.DIM), fontSize = 12.sp)
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { checkLibs() }) {
                    Text("Check libraries", color = Color(IdeTheme.ACCENT))
                }
                TextButton(
                    onClick = {
                        installing = true
                        result = "Installing — watch the terminal below."
                        onInstallTap()
                    },
                    enabled = !installing
                ) {
                    Text(
                        "Install GUI libraries",
                        color = if (installing) Color(IdeTheme.DIM)
                        else Color(IdeTheme.ACCENT)
                    )
                }
            }
            Text(
                result,
                color = if (installing || result.startsWith("GUI libraries OK")) {
                    Color(IdeTheme.ACCENT)
                } else {
                    Color(IdeTheme.DIM)
                },
                fontSize = 12.sp
            )
            val cmd = installCmd
            if (cmd != null) {
                Spacer(Modifier.height(8.dp))
                Text("Install terminal", color = Color(IdeTheme.DIM), fontSize = 11.sp)
                Spacer(Modifier.height(4.dp))
                // The REAL terminal surface (same engine as the console):
                // live output as it happens, scrollable, selectable — but
                // read-only, so no prompt interaction and no keyboard ever.
                androidx.compose.runtime.key(installRunId) {
                    com.codespace.ide.TerminalScreen(
                        root = proot,
                        bridge = null,
                        showTopBar = false,
                        runCommand = cmd,
                        controller = installCtl,
                        exitHint = "finished",
                        showExtraKeys = false,
                        readOnly = true,
                        showManualKeyboardButton = false,
                        modifier = Modifier.fillMaxWidth().height(320.dp)
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "tkinter → python3-tk (in the installer) · kivy → pip install kivy · " +
                "pygame → pip install pygame · Qt → pip install PySide6",
                color = Color(IdeTheme.DIM), fontSize = 11.sp
            )
        }
    }
}

/**
 * Environment doctor: proves python3/pip/venv really work inside the guest
 * (stale runtimes predate them), and reinstalls the runtime with projects
 * preserved when they don't. Terminal sessions should be closed first —
 * restart the app after a repair.
 */
@Composable
internal fun EnvironmentCard(
    ubuntu: com.codespace.ide.UbuntuManager,
    proot: ProotManager
) {
    val scope = rememberCoroutineScope()
    var checking by remember { mutableStateOf(false) }
    var repairing by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("Tap Check to verify python, pip and venv.") }
    var recoveryConfirm by remember { mutableStateOf(false) }
    var recoveryBusy by remember { mutableStateOf(false) }
    var recoveryStage by remember { mutableStateOf("") }
    var recoveryError by remember { mutableStateOf<String?>(null) }
    var recoveryPendingCleanup by remember { mutableStateOf(false) }
    var recoveryRollbackAvailable by remember { mutableStateOf(false) }
    var recoveryHealthPassed by remember { mutableStateOf(false) }

    fun check() {
        checking = true
        scope.launch(Dispatchers.IO) {
            val out = try {
                proot.runOnce(
                    "python3 --version 2>&1; pip --version 2>&1; " +
                    "python3 -c \"import venv,ensurepip; print('venv-ok')\" 2>&1"
                )
            } catch (t: Throwable) {
                "ERROR: ${t.message}"
            }
            withContext(Dispatchers.Main) {
                val lines = out.lines()
                val py = lines.firstOrNull { it.startsWith("Python ") } ?: "python3: MISSING"
                val pip = lines.firstOrNull { it.startsWith("pip ") } ?: "pip: MISSING"
                val venv = if (lines.any { it.trim() == "venv-ok" }) "venv: OK" else "venv: MISSING"
                result = "$py\n$pip\n$venv"
                recoveryHealthPassed = py.startsWith("Python ") && pip.startsWith("pip ") && venv == "venv: OK"
                if (recoveryHealthPassed) recoveryPendingCleanup = true
                checking = false
            }
        }
    }

    fun evidence() {
        checking = true
        result = "Collecting on-device evidence…"
        scope.launch(Dispatchers.IO) {
            val out = try {
                proot.runOnce(
                    "echo MARKER:; cat /.pyspace_ready 2>&1; " +
                    "echo SP-PIP:; ls -d /usr/local/lib/python3.12/site-packages/pip 2>&1; " +
                    "echo VENV-MOD:; ls -d /usr/lib/python3.12/venv /usr/lib/python3.12/ensurepip 2>&1; " +
                    "echo PYBIN:; ls -la /usr/bin/python3* 2>&1; " +
                    "echo SYSPATH:; python3 -c \"import sys; print([p for p in sys.path if 'packages' in p])\" 2>&1"
                )
            } catch (t: Throwable) {
                "ERROR: ${t.message}"
            }
            withContext(Dispatchers.Main) {
                result = out.take(900)
                checking = false
            }
        }
    }

    fun pipWorks(): Boolean {
        return try {
            val out = proot.runOnce("pip --version 2>&1")
            out.lines().any { it.startsWith("pip ") }
        } catch (_: Throwable) {
            false
        }
    }

    fun repair() {
        repairing = true
        result = "Trying fast repair (python layout symlinks)…"
        scope.launch(Dispatchers.IO) {
            // Fast path first: the bundled stack is present but invisible
            // to the Ubuntu interpreter — symlinks fix that in seconds, no
            // 400MB reinstall, projects untouched.
            var fixed = try {
                proot.runOnce(
                    com.codespace.ide.UbuntuManager.pythonLayoutFixScript()
                )
                pipWorks()
            } catch (_: Exception) {
                false
            }
            // A repaired layout also unbreaks venv creation (ensurepip).
            if (fixed) {
                try {
                    val v = proot.runOnce(
                        "python3 -c \"import venv,ensurepip; print('venv-ok')\" 2>&1"
                    )
                    fixed = v.lines().any { it.trim() == "venv-ok" }
                } catch (_: Exception) {
                    fixed = false
                }
            }
            var msg: String? = null
            if (!fixed) {
                withContext(Dispatchers.Main) {
                    result = "Fast repair failed — full runtime reinstall…"
                }
                msg = try {
                    ubuntu.install { }
                    "done"
                } catch (t: Throwable) {
                    "ERROR: ${t.message}"
                }
            }
            withContext(Dispatchers.Main) {
                repairing = false
                result = when {
                    fixed -> "Python stack repaired ✓ Restart the app, then Check again."
                    msg == "done" -> "Reinstalled. Restart the app, then Check again."
                    else -> msg ?: "Repair failed."
                }
            }
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.CARD)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(12.dp)) {
            Text("Environment", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(4.dp))
            Text(result, color = Color(IdeTheme.DIM), fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Row {
                Button(
                    enabled = !checking && !repairing,
                    onClick = { check() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(IdeTheme.ACCENT), contentColor = Color(IdeTheme.ON_ACCENT)
                    )
                ) { Text(if (checking) "…" else "Check") }
                Spacer(Modifier.width(8.dp))
                TextButton(enabled = !checking && !repairing, onClick = { repair() }) {
                    Text("Repair pip/runtime", color = Color(IdeTheme.WARN))
                }
                TextButton(enabled = !checking && !repairing, onClick = { evidence() }) {
                    Text("Evidence", color = Color(IdeTheme.DIM))
                }
            }
            if (repairing) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(Modifier.fillMaxWidth(), color = Color(IdeTheme.ACCENT))
            }
            Spacer(Modifier.height(14.dp))
            Divider(color = Color(IdeTheme.DIM).copy(alpha = .18f))
            Spacer(Modifier.height(12.dp))
            Text("System recovery", color = Color(IdeTheme.TEXT), fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Reinstall the original PySpace system image if the environment is damaged. Your projects and app settings are stored separately and will not be erased. Custom Ubuntu packages and system changes will be reset. Python versions installed through PySpace are preserved.", color = Color(IdeTheme.DIM), fontSize = 11.sp, lineHeight = 17.sp)
            Spacer(Modifier.height(10.dp))
            Button(onClick = { recoveryConfirm = true }, enabled = !checking && !repairing && !recoveryBusy,
                colors = ButtonDefaults.buttonColors(containerColor = Color(IdeTheme.WARN), contentColor = Color(IdeTheme.ON_ACCENT)),
                modifier = Modifier.fillMaxWidth()) { Text("Restore clean system") }
            if (recoveryBusy) {
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(Modifier.fillMaxWidth(), color = Color(IdeTheme.ACCENT))
                Text(recoveryStage, color = Color(IdeTheme.DIM), fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                Text("Keep PySpace open. Do not start a terminal, notebook, or Python process during recovery.", color = Color(IdeTheme.WARN), fontSize = 11.sp)
            }
            if (recoveryRollbackAvailable && !recoveryBusy && !recoveryHealthPassed) {
                TextButton(onClick = {
                    recoveryBusy = true
                    scope.launch {
                        try {
                            ubuntu.rollbackRecovery()
                            recoveryRollbackAvailable = false
                            recoveryPendingCleanup = false
                            recoveryStage = "Previous system restored. Restart PySpace and run Check."
                        } catch (t: Throwable) {
                            recoveryError = "Rollback failed: ${t.message}"
                        } finally { recoveryBusy = false }
                    }
                }) { Text("Roll back to previous system", color = Color(IdeTheme.WARN), fontSize = 11.sp) }
            }
            if (recoveryPendingCleanup && recoveryHealthPassed && !recoveryBusy) {
                Text("A copy of the previous system is being kept for rollback safety.", color = Color(IdeTheme.DIM), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                TextButton(onClick = {
                    scope.launch {
                        try {
                            ubuntu.finalizeRecovery()
                            recoveryPendingCleanup = false
                            recoveryRollbackAvailable = false
                            recoveryStage = "Previous system backup removed."
                        } catch (t: Throwable) {
                            recoveryError = "Could not remove previous backup: ${t.message}"
                        }
                    }
                }) { Text("Remove previous system backup", color = Color(IdeTheme.WARN), fontSize = 11.sp) }
            }
            recoveryError?.let { Text(it, color = Color(IdeTheme.WARN), fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)) }
            if (recoveryConfirm) {
                IdeAlertDialog(
                    onDismissRequest = { recoveryConfirm = false },
                    title = { Text("Restore clean system?") },
                    text = { Text("This replaces the current system image with the original bundled image. Projects and PySpace settings remain untouched. Packages installed manually inside the system and other custom system changes will be lost. Close all terminals, running scripts, notebooks and GUI sessions first. The current system is kept temporarily so recovery can roll back if activation fails.") },
                    confirmButton = { TextButton(onClick = {
                        recoveryConfirm = false; recoveryBusy = true; recoveryError = null
                        scope.launch {
                            try {
                                ubuntu.restoreClean { stage -> scope.launch { recoveryStage = stage } }
                                recoveryStage = "Recovery completed. Run Check before removing the safety backup."
                                recoveryPendingCleanup = true
                                recoveryRollbackAvailable = true
                                recoveryHealthPassed = false
                                result = "Clean system restored. Please run Check before using projects."
                            } catch (t: Throwable) {
                                recoveryError = "Recovery failed: ${t.message ?: "Unknown error"}"
                            } finally { recoveryBusy = false }
                        }
                    }) { Text("Restore system", color = Color(IdeTheme.WARN)) } },
                    dismissButton = { TextButton(onClick = { recoveryConfirm = false }) { Text("Cancel") } }
                )
            }
        }
    }
}
