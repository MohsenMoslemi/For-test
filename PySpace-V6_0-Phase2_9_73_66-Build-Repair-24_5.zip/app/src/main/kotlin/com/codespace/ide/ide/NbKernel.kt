package com.codespace.ide.ide

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.system.Os
import android.system.OsConstants
import com.codespace.ide.ProotManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.io.File
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import com.codespace.ide.ide.projects.PyProject

/**
 * Notebook-scoped Python kernel. Each notebook document receives its own
 * interpreter and namespace. It talks JSON-lines over a loopback socket
 * to a small stdlib-only Python process inside the project's PRoot runtime.
 *
 * Blocking process, socket and filesystem operations run on Dispatchers.IO.
 * Socket writes are serialized on one lazy worker. Runtime state is exposed as
 * StateFlow; message callbacks are delivered on the main thread.
 */
class NbKernel(
    private val proot: ProotManager,
    appContext: Context,
    private val project: PyProject
) {
    /** off | starting | idle | busy | dead. Runtime state is UI-framework independent. */
    private val _state = MutableStateFlow("off")
    val state: StateFlow<String> = _state.asStateFlow()
    private val _info = MutableStateFlow("")
    val info: StateFlow<String> = _info.asStateFlow()

    /** Subscribers are invoked on Main; reattached surfaces observe this notebook's kernel. */
    private val messageListeners = CopyOnWriteArrayList<(JSONObject) -> Unit>()
    private data class PendingMessage(val message: JSONObject, val generation: Long)
    private val incomingMessages = ConcurrentLinkedQueue<PendingMessage>()
    private val incomingDrainScheduled = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())

    fun subscribe(listener: (JSONObject) -> Unit): () -> Unit {
        messageListeners.add(listener)
        return { messageListeners.remove(listener) }
    }

    private fun dispatchMessage(message: JSONObject) {
        for (listener in messageListeners) {
            try { listener(message) } catch (_: Exception) { }
        }
    }

    /**
     * Socket readers can receive hundreds of tiny stdout messages in a burst.
     * Posting every line separately starves Compose and makes output appear only
     * after a later tab switch. Queue them off-main, then merge adjacent stream
     * chunks and publish a bounded batch on Main.
     */
    private fun enqueueIncoming(message: JSONObject, generation: Long) {
        incomingMessages.offer(PendingMessage(message, generation))
        scheduleIncomingDrain(INITIAL_DRAIN_DELAY_MS)
    }

    private fun scheduleIncomingDrain(delayMs: Long) {
        if (incomingDrainScheduled.compareAndSet(false, true)) {
            mainHandler.postDelayed({ drainIncomingMessages() }, delayMs)
        }
    }

    private fun drainIncomingMessages() {
        var processed = 0
        while (processed < MAX_MESSAGES_PER_DRAIN) {
            val first = incomingMessages.poll() ?: break
            processed++
            if (!isGenerationCurrent(first.generation)) continue
            val message = first.message
            if (message.optString("type") == "stream") {
                val id = message.optInt("id")
                val name = message.optString("name", "stdout")
                val text = StringBuilder(message.optString("text"))
                while (processed < MAX_MESSAGES_PER_DRAIN && text.length < MAX_STREAM_BATCH_CHARS) {
                    val next = incomingMessages.peek() ?: break
                    if (next.generation != first.generation ||
                        next.message.optString("type") != "stream" ||
                        next.message.optInt("id") != id ||
                        next.message.optString("name", "stdout") != name
                    ) break
                    incomingMessages.poll()
                    processed++
                    val part = next.message.optString("text")
                    val remaining = MAX_STREAM_BATCH_CHARS - text.length
                    text.append(part.take(remaining))
                }
                dispatchMessage(JSONObject()
                    .put("type", "stream")
                    .put("id", id)
                    .put("name", name)
                    .put("text", text.toString()))
            } else {
                when (message.optString("type")) {
                    "ready" -> {
                        _info.value = "Python " + message.optString("python")
                        _state.value = "idle"
                        continue
                    }
                    "started" -> {
                        _state.value = "busy"
                        continue
                    }
                    "done" -> if (state.value == "busy") _state.value = "idle"
                    "dead" -> _state.value = "dead"
                }
                dispatchMessage(message)
            }
        }

        if (incomingMessages.isNotEmpty()) {
            // Yield to input/layout between bounded chunks instead of monopolizing Main.
            mainHandler.postDelayed({ drainIncomingMessages() }, NEXT_DRAIN_DELAY_MS)
        } else {
            incomingDrainScheduled.set(false)
            // Close the enqueue-vs-reset race: a producer may have queued just
            // after the empty check but before the scheduled flag was cleared.
            if (incomingMessages.isNotEmpty()) scheduleIncomingDrain(0L)
        }
    }

    private val tmpHost = File(appContext.applicationContext.filesDir, "proot-ubuntu-tmp")
    // Every notebook now owns a separate process. Use a wide monotonic suffix
    // (plus a process-local sequence) so two notebooks opened together cannot
    // collide on guest log/PID paths.
    private val tag = project.dir.name.replace(Regex("[^A-Za-z0-9_.-]"), "_") + "-" +
        System.nanoTime().toString(16) + "-" + KERNEL_TAG_SEQUENCE.incrementAndGet().toString(16)
    private val pidFile get() = File(tmpHost, "nbk-$tag.pid")
    @Volatile private var socket: Socket? = null
    @Volatile private var out: OutputStream? = null
    @Volatile private var closing = false
    @Volatile private var cancelRequested = false
    private val startLock = Mutex()
    private val lifecycleGeneration = AtomicLong(0L)
    private val writerLock = Any()
    @Volatile private var writer: ExecutorService? = null
    private val idSeq = AtomicInteger(0)

    private fun pythonBin(): String = projectPythonBin(project.dir)

    fun alive(): Boolean {
        val active = socket ?: return false
        return active.isConnected && !active.isClosed && state.value != "dead" && state.value != "off"
    }

    /** Monotonic cell id, owned by the kernel so re-attached editors never reuse an id. */
    fun nextId(): Int = idSeq.incrementAndGet()

    suspend fun ensureStarted(): Boolean {
        if (alive()) return true
        return startLock.withLock {
            if (alive()) true else withContext(NonCancellable) { startKernel() }
        }
    }

    private suspend fun startKernel(): Boolean {
        val generation = lifecycleGeneration.get()
        closing = false
        cancelRequested = false
        publishState("starting", "")
        var connected: Socket? = null
        try {
            val guestPath = guestProjectPath(project)
            val port = withContext(Dispatchers.IO) {
                ServerSocket(0).use { it.localPort }
            }
            val token = ByteArray(16).also { SecureRandom().nextBytes(it) }
                .joinToString("") { "%02x".format(it) }

            // Never let a stale pid file from an earlier attempt be mistaken
            // for the process created by this start operation.
            withContext(Dispatchers.IO) { pidFile.delete() }
            withContext(Dispatchers.IO) {
                proot.runOnce(
                    "cd \"$guestPath\"; nohup ${pythonBin()} /tmp/ide/ide_kernel.py $port $token \"$guestPath\" " +
                        ">/tmp/nbk-$tag.log 2>&1 & echo \$! > /tmp/nbk-$tag.pid; echo STARTED",
                    20L
                )
            }
            if (!isGenerationCurrent(generation)) {
                killPid(readPid(), OsConstants.SIGKILL)
                publishState("off")
                return false
            }

            var waited = 0L
            while (waited < KERNEL_CONNECT_TIMEOUT_MS && !cancelRequested && isGenerationCurrent(generation)) {
                connected = withContext(Dispatchers.IO) { connectLoopback(port) }
                if (connected != null) break
                delay(KERNEL_RETRY_DELAY_MS)
                waited += KERNEL_RETRY_DELAY_MS
            }
            val activeSocket = connected
            if (activeSocket == null || cancelRequested || !isGenerationCurrent(generation)) {
                activeSocket?.closeQuietly()
                killPid(readPid(), OsConstants.SIGKILL)
                publishState(if (cancelRequested || !isGenerationCurrent(generation)) "off" else "dead")
                return false
            }

            socket = activeSocket
            out = activeSocket.getOutputStream()
            sendRaw(JSONObject().put("op", "hello").put("token", token))
            Thread({ readLoop(activeSocket, generation) }, "nb-kernel-$tag").also {
                it.isDaemon = true
                it.start()
            }

            var handshakeWaited = 0L
            while (handshakeWaited < KERNEL_HANDSHAKE_TIMEOUT_MS &&
                state.value == "starting" && isGenerationCurrent(generation) && !cancelRequested
            ) {
                delay(HANDSHAKE_POLL_INTERVAL_MS)
                handshakeWaited += HANDSHAKE_POLL_INTERVAL_MS
            }
            val ready = state.value == "idle" || state.value == "busy"
            if (!ready && isGenerationCurrent(generation)) {
                activeSocket.closeQuietly()
                if (socket === activeSocket) {
                    socket = null
                    out = null
                }
                killPid(readPid(), OsConstants.SIGTERM)
                publishState(if (cancelRequested) "off" else "dead")
            }
            return ready
        } catch (cancelled: CancellationException) {
            cancelRequested = true
            connected?.closeQuietly()
            if (socket === connected) {
                socket = null
                out = null
            }
            killPid(readPid(), OsConstants.SIGTERM)
            publishState("off")
            throw cancelled
        } catch (error: Exception) {
            connected?.closeQuietly()
            if (socket === connected) {
                socket = null
                out = null
            }
            killPid(readPid(), OsConstants.SIGTERM)
            publishState("dead")
            return false
        }
    }

    private fun connectLoopback(port: Int): Socket? {
        val candidate = Socket()
        return try {
            candidate.connect(InetSocketAddress("127.0.0.1", port), SOCKET_CONNECT_TIMEOUT_MS)
            candidate
        } catch (_: Exception) {
            candidate.closeQuietly()
            null
        }
    }

    private fun readLoop(sock: Socket, generation: Long) {
        try {
            val reader = sock.getInputStream().bufferedReader(Charsets.UTF_8)
            while (socket === sock && isGenerationCurrent(generation)) {
                val line = readBoundedLine(reader, MAX_KERNEL_MESSAGE_CHARS) ?: break
                val message = try {
                    JSONObject(line)
                } catch (_: Exception) {
                    continue
                }
                enqueueIncoming(message, generation)
            }
        } catch (_: Exception) {
            // Socket closure is expected during interrupt/restart/shutdown.
        } finally {
            sock.closeQuietly()
            if (!closing && socket === sock && isGenerationCurrent(generation)) {
                socket = null
                out = null
                if (!closing && isGenerationCurrent(generation)) {
                    enqueueIncoming(JSONObject().put("type", "dead"), generation)
                }
            }
        }
    }

    /** Prevent a malformed/accidental huge line from exhausting the phone's heap. */
    private fun readBoundedLine(reader: java.io.BufferedReader, maxChars: Int): String? {
        val result = StringBuilder(1024)
        while (true) {
            val ch = reader.read()
            if (ch == -1) return if (result.isEmpty()) null else result.toString()
            if (ch == '\n'.code) return result.toString()
            if (ch != '\r'.code) {
                if (result.length >= maxChars) throw IllegalStateException("Notebook kernel message exceeded the size limit")
                result.append(ch.toChar())
            }
        }
    }

    private fun sendRaw(message: JSONObject) {
        val stream = out ?: return
        synchronized(writerLock) {
            val executor = writer ?: Executors.newSingleThreadExecutor { runnable ->
                Thread(runnable, "nb-kernel-writer-$tag").apply { isDaemon = true }
            }.also { writer = it }
            try {
                executor.execute {
                    try {
                        stream.write((message.toString() + "\n").toByteArray(Charsets.UTF_8))
                        stream.flush()
                    } catch (_: Exception) {
                        // The read loop will publish the dead state if the peer is gone.
                    }
                }
            } catch (_: RejectedExecutionException) {
                // A shutdown/restart raced with a late UI command; it is safe to drop it.
            }
        }
    }

    fun execute(id: Int, code: String) {
        if (!alive()) {
            enqueueIncoming(JSONObject().put("type", "dead"), lifecycleGeneration.get())
            return
        }
        publishState("busy")
        sendRaw(JSONObject().put("op", "execute").put("id", id).put("code", code))
    }

    /** Cancel one request without affecting any other notebook's interpreter. */
    fun cancel(id: Int) {
        if (!alive()) return
        sendRaw(JSONObject().put("op", "cancel").put("id", id))
    }

    /** Cancel this notebook's startup; no other notebook owns this kernel. */
    fun cancelStartup() {
        if (state.value != "starting") return
        cancelRequested = true
        lifecycleGeneration.incrementAndGet()
        publishState("off")
        killPid(readPid(), OsConstants.SIGKILL)
    }

    fun shutdown() {
        val resetGeneration = lifecycleGeneration.incrementAndGet()
        closing = true
        cancelRequested = true
        // Notify this notebook's session that its interpreter is being reset.
        enqueueIncoming(JSONObject().put("type", "reset"), resetGeneration)
        // A PID left on disk after a normal exit may already have been reused
        // by Android/Linux. Only signal it when the kernel was still active.
        val wasActive = state.value == "starting" || state.value == "idle" || state.value == "busy"
        val pid = if (wasActive) readPid() else 0
        val oldSocket = socket
        sendRaw(JSONObject().put("op", "shutdown"))
        socket = null
        out = null
        publishState("off")
        synchronized(writerLock) {
            writer?.shutdown()
            writer = null
        }
        Thread({
            try {
                Thread.sleep(SHUTDOWN_GRACE_MS)
                oldSocket?.closeQuietly()
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
            }
            // Use the pid captured before restart; never read a possibly newer pid here.
            killPid(pid, OsConstants.SIGTERM)
        }, "nb-kernel-shutdown-$tag").also {
            it.isDaemon = true
            it.start()
        }
    }

    suspend fun restart(): Boolean {
        shutdown()
        delay(RESTART_DELAY_MS)
        return ensureStarted()
    }

    private fun publishState(newState: String, newInfo: String? = null) {
        onMainThread {
            _state.value = newState
            if (newInfo != null) _info.value = newInfo
        }
    }

    private fun isGenerationCurrent(generation: Long): Boolean = lifecycleGeneration.get() == generation

    private fun readPid(): Int = try {
        pidFile.readText().trim().toInt()
    } catch (_: Exception) {
        0
    }

    private fun killPid(pid: Int, signal: Int) {
        if (pid <= 0) return
        try {
            Os.kill(pid, signal)
        } catch (_: Exception) {
        }
    }

    private fun Socket.closeQuietly() {
        try { close() } catch (_: Exception) { }
    }

    private companion object {
        val KERNEL_TAG_SEQUENCE = AtomicLong(0L)
        const val SOCKET_CONNECT_TIMEOUT_MS = 600
        const val KERNEL_CONNECT_TIMEOUT_MS = 40_000L
        // Short retries reduce the perceived cold-start delay on fast phones;
        // the bounded timeout still protects slower/older devices.
        const val KERNEL_RETRY_DELAY_MS = 60L
        const val KERNEL_HANDSHAKE_TIMEOUT_MS = 15_000L
        const val HANDSHAKE_POLL_INTERVAL_MS = 25L
        const val MAX_KERNEL_MESSAGE_CHARS = 16 * 1024 * 1024
        const val SHUTDOWN_GRACE_MS = 700L
        const val RESTART_DELAY_MS = 900L
        const val INITIAL_DRAIN_DELAY_MS = 12L
        const val NEXT_DRAIN_DELAY_MS = 4L
        const val MAX_MESSAGES_PER_DRAIN = 256
        const val MAX_STREAM_BATCH_CHARS = 64 * 1024
    }
}
