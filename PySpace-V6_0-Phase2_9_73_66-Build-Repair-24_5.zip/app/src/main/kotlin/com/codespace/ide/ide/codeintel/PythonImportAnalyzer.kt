package com.codespace.ide.ide.codeintel

import com.codespace.ide.ProotManager
import java.nio.charset.StandardCharsets
import java.util.Base64
import org.json.JSONObject

/** A Pyflakes F401 binding reported against the exact unsaved editor buffer. */
data class PythonUnusedImport(
    val line: Int,
    val column: Int,
    val importedName: String,
)

data class PythonImportAnalysis(
    val available: Boolean,
    val unusedImports: List<PythonUnusedImport> = emptyList(),
    val message: String? = null,
)

/**
 * Runs the bundled Pyflakes installation against the current editor text.
 * The user's file is never written or executed. Only source text is sent to
 * the isolated language-server Python environment over Base64.
 */
object PythonImportAnalyzer {
    private const val PYTHON = "/opt/pyspace-lsp/venv/bin/python"
    private const val MAX_SOURCE_CHARS = 48_000
    private const val TIMEOUT_SECONDS = 12L

    private val script = """
        import base64, json, sys
        try:
            from pyflakes.api import check
            class Capture:
                def __init__(self):
                    self.unused = []
                    self.syntax_errors = []
                def flake(self, message):
                    if type(message).__name__ == 'UnusedImport':
                        args = getattr(message, 'message_args', ())
                        self.unused.append({
                            'line': int(message.lineno),
                            'column': int(message.col),
                            'name': str(args[0]) if args else ''
                        })
                def syntaxError(self, filename, msg, lineno, offset, text):
                    self.syntax_errors.append({'line': lineno, 'message': str(msg)})
                def unexpectedError(self, filename, msg):
                    raise RuntimeError(str(msg))
            source = base64.b64decode(sys.argv[1]).decode('utf-8')
            capture = Capture()
            check(source, '<pyspace-editor-buffer>', capture)
            if capture.syntax_errors:
                print(json.dumps({'ok': False, 'error': 'Python syntax errors prevent unused-import analysis', 'syntax': capture.syntax_errors}, ensure_ascii=False))
            else:
                print(json.dumps({'ok': True, 'unused': capture.unused}, ensure_ascii=False))
        except Exception as error:
            print(json.dumps({'ok': False, 'error': str(error)}, ensure_ascii=False))
    """.trimIndent()

    fun analyze(proot: ProotManager, source: String): PythonImportAnalysis {
        if (source.length > MAX_SOURCE_CHARS) {
            return PythonImportAnalysis(false, message = "Source is too large for import analysis")
        }
        return try {
            val encoded = Base64.getEncoder().encodeToString(source.toByteArray(StandardCharsets.UTF_8))
            val command = "$PYTHON -c ${shellQuote(script)} ${shellQuote(encoded)}"
            val output = proot.runOnce(command, timeoutSec = TIMEOUT_SECONDS)
            val jsonLine = output.lineSequence().map { it.trim() }.lastOrNull {
                it.startsWith("{") && it.endsWith("}")
            } ?: return PythonImportAnalysis(false, message = "Pyflakes did not return a result")
            val json = JSONObject(jsonLine)
            if (!json.optBoolean("ok", false)) {
                return PythonImportAnalysis(false, message = json.optString("error", "Pyflakes analysis failed"))
            }
            val array = json.optJSONArray("unused") ?: return PythonImportAnalysis(true)
            val unused = buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    val line = item.optInt("line", 0)
                    val name = item.optString("name")
                    if (line > 0 && name.isNotBlank()) {
                        add(PythonUnusedImport(line, item.optInt("column", 0), name))
                    }
                }
            }
            PythonImportAnalysis(true, unused)
        } catch (error: Exception) {
            PythonImportAnalysis(false, message = error.message ?: "Pyflakes analysis failed")
        }
    }

    private fun shellQuote(value: String): String = "'" + value.replace("'", "'\\''") + "'"
}
