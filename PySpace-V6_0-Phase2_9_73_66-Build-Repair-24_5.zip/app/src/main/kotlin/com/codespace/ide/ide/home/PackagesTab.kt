package com.codespace.ide.ide.home

import android.content.Context
import android.content.ContextWrapper
import androidx.activity.ComponentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import com.codespace.ide.domain.packages.PackageManagerRepository
import com.codespace.ide.ide.packages.PackageManagerViewModel
import com.codespace.ide.ide.projects.PyProject
import com.codespace.ide.ide.theme.IdeTheme

@Composable
internal fun PackagesTab(projects: List<PyProject>, repository: PackageManagerRepository, modifier: Modifier = Modifier) {
    var target by remember(projects) { mutableStateOf<PyProject?>(projects.firstOrNull()) }
    Column(modifier.fillMaxSize().padding(12.dp)) {
        Text("pip package manager (project venv when built)", color = Color(IdeTheme.DIM), fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            for (p in projects) {
                val sel = target?.dir?.absolutePath == p.dir.absolutePath
                TextButton(
                    onClick = { target = p },
                    modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (sel) Color(IdeTheme.ACCENT).copy(alpha = 0.16f) else Color(IdeTheme.CARD))
                ) {
                    Text(
                        p.name, fontSize = 12.sp,
                        color = if (sel) Color(IdeTheme.ACCENT) else Color(IdeTheme.TEXT)
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        val t = target
        if (t == null) {
            Text("Create a project first.", color = Color(IdeTheme.DIM), fontSize = 12.sp)
        } else {
            androidx.compose.runtime.key(t.dir.absolutePath) {
                ProjectPackagesContent(project = t, repository = repository)
            }
        }
    }
}

/**
 * Graphical package manager for ONE project (no project list): popular
 * one-tap installs + installed rows with uninstall. Shared by the Home
 * Packages tab (per selected chip) and the in-editor ▣ sheet, so both
 * drive the same venv pip as the terminal does.
 */
@Composable
fun ProjectPackagesContent(project: PyProject, repository: PackageManagerRepository) {
    val activity = findComponentActivity(LocalContext.current)
    if (activity == null) {
        Text("Package manager requires an active Android screen.", color = Color(IdeTheme.ERROR), fontSize = 12.sp)
        return
    }

    val projectKey = remember(project.dir.absolutePath) { "package-manager:${project.dir.absolutePath}" }
    val viewModel = remember(activity, projectKey, repository) {
        ViewModelProvider(activity, PackageManagerViewModel.Factory(project, repository))
            .get(projectKey, PackageManagerViewModel::class.java)
    }
    val state by viewModel.state.collectAsState()
    val installedNames = remember(state.installed) { state.installed.map { it.name.lowercase() }.toSet() }
    var selectedSection by remember(project.dir.absolutePath) { mutableStateOf("Discover") }
    var searchQuery by remember(project.dir.absolutePath) { mutableStateOf("") }
    var packageToRemove by remember { mutableStateOf<String?>(null) }

    val venvReady = venvPythonReady(project.dir)
    val popular = remember { popularPackages() }
    val filteredPopular = remember(searchQuery, popular) {
        popular.filter { it.name.contains(searchQuery, true) || it.desc.contains(searchQuery, true) }
    }
    // pip is the environment's package-management tool, not an ordinary
    // project dependency. Never expose it as a removable package.
    val visibleInstalled = remember(state.installed) {
        state.installed.filterNot { it.name.equals("pip", ignoreCase = true) }
    }
    val filteredInstalled = remember(searchQuery, visibleInstalled) {
        visibleInstalled.filter { it.name.contains(searchQuery, true) }
    }
    val fieldColors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color(IdeTheme.TEXT),
        unfocusedTextColor = Color(IdeTheme.TEXT),
        disabledTextColor = Color(IdeTheme.DIM),
        focusedContainerColor = Color(IdeTheme.PANEL),
        unfocusedContainerColor = Color(IdeTheme.PANEL),
        disabledContainerColor = Color(IdeTheme.PANEL),
        cursorColor = Color(IdeTheme.ACCENT),
        focusedBorderColor = Color(IdeTheme.ACCENT),
        unfocusedBorderColor = Color(IdeTheme.LINE),
        focusedLabelColor = Color(IdeTheme.ACCENT),
        unfocusedLabelColor = Color(IdeTheme.DIM),
        focusedPlaceholderColor = Color(IdeTheme.DIM),
        unfocusedPlaceholderColor = Color(IdeTheme.DIM)
    )

    Column(
        Modifier.fillMaxSize()
            .background(Color(IdeTheme.BG))
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        // Compact environment header: it scrolls with the rest of the page.
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(17.dp),
            colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.CARD))
        ) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(38.dp).clip(RoundedCornerShape(12.dp))
                            .background(Color(IdeTheme.ACCENT).copy(alpha = 0.13f)),
                        contentAlignment = Alignment.Center
                    ) { Text("▣", fontSize = 20.sp, color = Color(IdeTheme.ACCENT)) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Python packages", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(IdeTheme.TEXT))
                        Text(project.name, fontSize = 11.sp, color = Color(IdeTheme.DIM))
                    }
                    TextButton(
                        onClick = viewModel::refresh,
                        enabled = !state.isBusy && !state.isLoading
                    ) { Text("↻ Refresh", fontSize = 11.sp, color = Color(IdeTheme.ACCENT)) }
                }
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                        .background(Color(IdeTheme.BG)).padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (venvReady) "●" else "○", color = if (venvReady) Color(IdeTheme.ACCENT) else Color(IdeTheme.WARN), fontSize = 12.sp)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (venvReady) "Environment ready" else "Environment not initialized",
                            fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color(IdeTheme.TEXT)
                        )
                        Text(
                            if (venvReady) "${projectVenvName(project.dir)} · isolated environment"
                            else "Open the project and wait for setup to finish.",
                            fontSize = 9.sp, color = Color(IdeTheme.DIM)
                        )
                    }
                    Text("${visibleInstalled.size} packages", fontSize = 10.sp, color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Text("INSTALL PACKAGE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(IdeTheme.DIM))
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = state.packageInput,
                onValueChange = viewModel::setPackageInput,
                modifier = Modifier.weight(1f),
                placeholder = { Text("requests  ·  numpy==2.1.0", fontSize = 11.sp) },
                singleLine = true,
                enabled = venvReady && !state.isBusy && !state.isLoading,
                shape = RoundedCornerShape(12.dp),
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = Color(IdeTheme.TEXT)),
                colors = fieldColors
            )
            Spacer(Modifier.width(7.dp))
            Button(
                onClick = viewModel::installInput,
                enabled = venvReady && !state.isBusy && !state.isLoading && state.packageInput.isNotBlank(),
                shape = RoundedCornerShape(11.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(IdeTheme.ACCENT),
                    contentColor = Color(IdeTheme.ON_ACCENT),
                    disabledContainerColor = Color(IdeTheme.ACCENT).copy(alpha = 0.25f),
                    disabledContentColor = Color(IdeTheme.DIM)
                ),
                modifier = Modifier.height(52.dp)
            ) { Text("Install", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
        }
        Text(
            "Enter a package name, optionally with a version constraint.",
            fontSize = 9.sp, color = Color(IdeTheme.DIM), modifier = Modifier.padding(start = 2.dp, top = 4.dp)
        )

        Spacer(Modifier.height(12.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(11.dp))
                .background(Color(IdeTheme.CARD)).padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            listOf("Discover", "Installed").forEach { section ->
                val selected = selectedSection == section
                TextButton(
                    onClick = { selectedSection = section; searchQuery = "" },
                    modifier = Modifier.weight(1f).clip(RoundedCornerShape(8.dp))
                        .background(if (selected) Color(IdeTheme.ACCENT).copy(alpha = 0.15f) else Color.Transparent)
                ) {
                    Text(
                        if (section == "Discover") "✦  Discover" else "✓  Installed (${visibleInstalled.size})",
                        color = if (selected) Color(IdeTheme.ACCENT) else Color(IdeTheme.DIM),
                        fontSize = 11.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }
        Spacer(Modifier.height(7.dp))
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text(if (selectedSection == "Discover") "Search packages…" else "Search installed packages…", fontSize = 11.sp) },
            leadingIcon = { Text("⌕", fontSize = 20.sp, color = Color(IdeTheme.DIM)) },
            shape = RoundedCornerShape(11.dp),
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = Color(IdeTheme.TEXT)),
            colors = fieldColors
        )

        if (state.isBusy || state.isLoading) {
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)),
                color = Color(IdeTheme.ACCENT),
                trackColor = Color(IdeTheme.LINE)
            )
            Text(
                if (state.isBusy) "Running pip in this project's environment…" else "Loading installed packages…",
                fontSize = 10.sp, color = Color(IdeTheme.DIM), modifier = Modifier.padding(top = 5.dp)
            )
        }
        state.error?.takeIf { it.isNotBlank() }?.let { message ->
            Card(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.ERROR).copy(alpha = 0.12f)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text(message, color = Color(IdeTheme.ERROR), fontSize = 10.sp, modifier = Modifier.padding(10.dp))
            }
        }
        if (state.output.isNotBlank()) {
            Card(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.PANEL)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("PIP OUTPUT", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(IdeTheme.ACCENT), modifier = Modifier.weight(1f))
                        if (state.isBusy) Text("RUNNING", fontSize = 8.sp, color = Color(IdeTheme.WARN), fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(6.dp))
                    // Keep the operation log bounded on screen while allowing
                    // the user to scroll through the complete retained output.
                    Text(
                        state.output.takeLast(24_000),
                        modifier = Modifier.fillMaxWidth().heightIn(max = 210.dp).verticalScroll(rememberScrollState()),
                        fontSize = 10.sp,
                        lineHeight = 14.sp,
                        color = Color(IdeTheme.TEXT),
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        if (selectedSection == "Discover") {
            Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("POPULAR PACKAGES", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(IdeTheme.DIM), modifier = Modifier.weight(1f))
                Text("${filteredPopular.size} results", fontSize = 9.sp, color = Color(IdeTheme.DIM))
            }
            if (filteredPopular.isEmpty()) {
                Text("No package matches your search.", color = Color(IdeTheme.DIM), fontSize = 11.sp, modifier = Modifier.padding(12.dp))
            }
            filteredPopular.forEach { pkg ->
                val isInstalled = installedNames.contains(pkg.name.lowercase())
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.CARD)),
                    onClick = { if (!isInstalled && !state.isBusy && !state.isLoading && venvReady) viewModel.installPopular(pkg.name) }
                ) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 11.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(33.dp).clip(RoundedCornerShape(9.dp)).background(Color(IdeTheme.BG)),
                            contentAlignment = Alignment.Center
                        ) { Text(pkg.name.take(1).uppercase(), color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(pkg.name, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = Color(IdeTheme.TEXT))
                            Text(pkg.desc, color = Color(IdeTheme.DIM), fontSize = 9.sp)
                        }
                        Text(
                            if (isInstalled) "Installed" else "+ Add",
                            color = if (isInstalled) Color(IdeTheme.ACCENT) else Color(IdeTheme.TEXT),
                            fontSize = 10.sp, fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("YOUR ENVIRONMENT", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(IdeTheme.DIM), modifier = Modifier.weight(1f))
                Text("${filteredInstalled.size} packages", fontSize = 9.sp, color = Color(IdeTheme.DIM))
            }
            if (state.isLoading && state.installed.isEmpty()) {
                Text("Loading installed packages…", color = Color(IdeTheme.DIM), fontSize = 11.sp)
            } else if (filteredInstalled.isEmpty()) {
                Text(
                    if (visibleInstalled.isEmpty()) "No project packages installed yet." else "No installed package matches your search.",
                    color = Color(IdeTheme.DIM), fontSize = 11.sp, modifier = Modifier.padding(12.dp)
                )
            } else {
                filteredInstalled.forEach { pkg ->
                    Card(
                        Modifier.fillMaxWidth().padding(bottom = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.CARD)),
                        shape = RoundedCornerShape(11.dp)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 11.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(pkg.name, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color(IdeTheme.TEXT), fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                                Text("Version ${pkg.version}", color = Color(IdeTheme.DIM), fontSize = 9.sp)
                            }
                            TextButton(
                                enabled = !state.isBusy && !state.isLoading,
                                onClick = { packageToRemove = pkg.name }
                            ) { Text("Remove", color = Color(IdeTheme.ERROR), fontSize = 10.sp) }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
    }

    packageToRemove?.let { name ->
        IdeAlertDialog(
            onDismissRequest = { packageToRemove = null },
            title = { Text("Uninstall $name?") },
            text = { Text("This removes the package from ${project.name}'s virtual environment. Other projects are not affected.") },
            confirmButton = {
                TextButton(onClick = { packageToRemove = null; viewModel.uninstall(name) }) {
                    Text("Uninstall", color = Color(IdeTheme.ERROR))
                }
            },
            dismissButton = { TextButton(onClick = { packageToRemove = null }) { Text("Cancel") }
            }
        )
    }
}

internal fun findComponentActivity(context: Context): ComponentActivity? {
    var current: Context = context
    while (true) {
        if (current is ComponentActivity) return current
        val wrapper = current as? ContextWrapper ?: return null
        val next = wrapper.baseContext
        if (next === current) return null
        current = next
    }
}

// --------------------------------- Learn -----------------------------------
