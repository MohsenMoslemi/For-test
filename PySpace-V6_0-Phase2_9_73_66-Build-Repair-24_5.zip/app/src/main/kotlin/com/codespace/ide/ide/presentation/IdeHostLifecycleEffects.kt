package com.codespace.ide.ide.presentation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberUpdatedState
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.delay

/**
 * Binds IDE persistence and privacy-sensitive camera shutdown to the host
 * Activity lifecycle. It owns scheduling/observer attachment, not the actual
 * persistence implementation or camera runtime.
 */
@Composable
internal fun IdeHostLifecycleEffects(
    lifecycleOwner: LifecycleOwner?,
    markEditorForRestore: Boolean,
    persist: (saveFiles: Boolean, markForRestore: Boolean) -> Unit,
    stopCamera: () -> Unit,
) {
    val currentMarkForRestore = rememberUpdatedState(markEditorForRestore)
    val currentPersist = rememberUpdatedState(persist)
    val currentStopCamera = rememberUpdatedState(stopCamera)

    DisposableEffect(lifecycleOwner) {
        val lifecycle = lifecycleOwner?.lifecycle
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                currentPersist.value(true, currentMarkForRestore.value)
                // Background = camera off (privacy + battery). The user
                // restarts it from the Camera tab on return.
                try {
                    currentStopCamera.value()
                } catch (_: Exception) {
                }
            }
        }
        lifecycle?.addObserver(observer)
        onDispose { lifecycle?.removeObserver(observer) }
    }

    // Cheap safety net between lifecycle events (scroll/caret/tabs only; the
    // files themselves are written only on stop or exit).
    LaunchedEffect(lifecycleOwner) {
        while (true) {
            delay(4_000L)
            currentPersist.value(false, false)
        }
    }
}
