package com.codespace.ide.ide

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ProotManager
import com.codespace.ide.TerminalScreen
import com.codespace.ide.ide.projects.ProjectsUiState
import com.codespace.ide.ide.settings.IdePrefs
import com.codespace.ide.ide.theme.IdeTheme

/** Standalone interactive Python shell. Kept composed while other Home tabs are shown. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InterpreterTab(
    proot: ProotManager,
    prefs: IdePrefs,
    runtimeState: ProjectsUiState,
    visible: Boolean,
    onInstallRuntime: (String) -> Unit,
    onCancelRuntimeInstall: (String) -> Unit,
) {
    var runId by remember { mutableStateOf(1) }
    var selectedVersion by remember { mutableStateOf(prefs.interpreterPythonVersionId) }
    var menuExpanded by remember { mutableStateOf(false) }
    var warningVersion by remember { mutableStateOf<String?>(null) }
    var installPending by remember { mutableStateOf<String?>(null) }
    var installStateObserved by remember { mutableStateOf(false) }
    var runtimeInstallError by remember { mutableStateOf<String?>(null) }
    val runtime = PythonRuntimeCatalog.require(selectedVersion)
    val installStatus = installPending?.let { runtimeState.runtimeInstallStates[it] }

    LaunchedEffect(installPending, installStatus?.status) {
        val id = installPending ?: return@LaunchedEffect
        val state = runtimeState.runtimeInstallStates[id]
        if (state != null) installStateObserved = true
        when (state?.status) {
            "installed" -> {
                selectedVersion = id
                prefs.interpreterPythonVersionId = id
                installPending = null
                installStateObserved = false
                runId++
            }
            "error" -> {
                runtimeInstallError = state.error ?: "Python runtime installation failed."
                installPending = null
                installStateObserved = false
            }
            null -> if (installStateObserved) {
                runtimeInstallError = "Python runtime installation was cancelled. The previous interpreter is still active."
                installPending = null
                installStateObserved = false
            }
        }
    }

    Column(Modifier.fillMaxSize().background(Color(IdeTheme.BG))) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Column(Modifier.weight(1f)) {
                Text("Interactive Python", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(IdeTheme.TEXT))
                Text("Python ${runtime.version} · ${if (runtime.isBundled) "Bundled runtime" else "Standalone runtime"}", fontSize = 11.sp, color = Color(IdeTheme.DIM))
            }
            Box {
                TextButton(onClick = { menuExpanded = true }, enabled = installPending == null) {
                    Text("Python ${runtime.version}  ▾", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.SemiBold)
                }
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                    PythonRuntimeCatalog.options.forEach { option ->
                        val installed = option.isBundled || runtimeState.runtimeInstallStates[option.id]?.status == "installed"
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(option.title, color = Color(IdeTheme.TEXT))
                                    Text(if (installed) "Installed" else "Download required", fontSize = 10.sp, color = Color(IdeTheme.DIM))
                                }
                            },
                            onClick = { menuExpanded = false; if (option.id != selectedVersion) warningVersion = option.id }
                        )
                    }
                }
            }
            TextButton(onClick = { runId++ }, enabled = installPending == null) {
                Text("Restart", color = Color(IdeTheme.ACCENT))
            }
        }
        if (installPending != null) {
            val id = installPending!!
            val state = runtimeState.runtimeInstallStates[id]
            Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp)) {
                Text(state?.message ?: "Preparing Python runtime…", color = Color(IdeTheme.DIM), fontSize = 11.sp)
                state?.fraction?.let { LinearProgressIndicator(progress = { it.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = Color(IdeTheme.ACCENT)) }
                    ?: LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Color(IdeTheme.ACCENT))
                TextButton(
                    onClick = { onCancelRuntimeInstall(id); installPending = null; installStateObserved = false },
                    enabled = state?.status != "installing"
                ) {
                    Text(if (state?.status == "installing") "Installing…" else "Cancel download", color = Color(IdeTheme.ERROR), fontSize = 11.sp)
                }
            }
        }
        runtimeInstallError?.let { message ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(message, color = Color(IdeTheme.ERROR), fontSize = 11.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { runtimeInstallError = null }) { Text("Dismiss") }
            }
        }
        key(runId) {
            val executable = runtime.guestExecutable
            val cmd = "export PYTHONSTARTUP=/tmp/ide/pystartup.py; cd /files 2>/dev/null; exec $executable"
            TerminalScreen(
                root = proot,
                bridge = null,
                showTopBar = false,
                runCommand = cmd,
                controller = null,
                exitHint = "Python exited — tap Restart",
                showExtraKeys = true,
                compactExtraKeys = true,
                visible = visible,
                workDir = "/files",
                showManualKeyboardButton = false,
                modifier = Modifier.weight(1f).fillMaxWidth()
            )
        }
    }

    warningVersion?.let { id ->
        val option = PythonRuntimeCatalog.require(id)
        IdeAlertDialog(
            onDismissRequest = { warningVersion = null },
            title = { Text("Switch Python interpreter?") },
            text = { Text("Switching to Python ${option.version} restarts the interactive interpreter. Anything currently typed in this session, including its variables, definitions and visible terminal history, will be cleared. Save or copy anything you need before continuing.") },
            confirmButton = {
                TextButton(onClick = {
                    warningVersion = null
                    runtimeInstallError = null
                    val installed = option.isBundled || runtimeState.runtimeInstallStates[id]?.status == "installed"
                    if (installed) {
                        selectedVersion = id
                        prefs.interpreterPythonVersionId = id
                        runId++
                    } else {
                        installPending = id
                        installStateObserved = false
                        onInstallRuntime(id)
                    }
                }) { Text(if (option.isBundled || runtimeState.runtimeInstallStates[id]?.status == "installed") "Switch and restart" else "Install and switch") }
            },
            dismissButton = { TextButton(onClick = { warningVersion = null }) { Text("Cancel") } },
            containerColor = Color(IdeTheme.PANEL),
            titleContentColor = Color(IdeTheme.TEXT),
            textContentColor = Color(IdeTheme.DIM)
        )
    }
}

/** Global Ubuntu shell tabs; each tab owns an independent PTY and transcript. */
@Composable
fun GlobalTerminalTab(proot: ProotManager, visible: Boolean) {
    com.codespace.ide.ide.terminal.TerminalTabs(
        root = proot,
        visible = visible,
        workDir = "/files",
        title = "Ubuntu Terminal",
        showRestart = true,
        modifier = Modifier.fillMaxSize()
    )
}

/** Loaded by the interpreter (PYTHONSTARTUP): IDLE-like conveniences. Never raises. */
val IDE_PYSTARTUP_PY = """# IDE interactive Python: Tab completion + persistent history (like IDLE's shell)
try:
    import atexit, os, readline, rlcompleter
    readline.parse_and_bind("tab: complete")
    _hist = os.path.join(os.path.expanduser("~"), ".ide_python_history")
    try:
        readline.read_history_file(_hist)
    except OSError:
        pass
    readline.set_history_length(2000)
    atexit.register(lambda: readline.write_history_file(_hist))
except Exception:
    pass
"""
