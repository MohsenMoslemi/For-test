package com.codespace.ide.ide.editor

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset

/**
 * Owns the two-pointer recognition loop for editor font zoom.
 * Single-finger events are deliberately left unconsumed so text selection,
 * caret placement and scrolling continue to be handled by their native layers.
 * Zoom geometry and document state remain owned by PyEditor and are supplied
 * through the three lifecycle callbacks.
 */
@Composable
internal fun Modifier.editorPinchZoomGesture(
    enabled: Boolean,
    currentFontSize: () -> Float,
    currentWordWrap: () -> Boolean,
    canStartPinch: () -> Boolean,
    onPinchStart: (wrapMode: Boolean, startFont: Float) -> Unit,
    onPinchUpdate: (startFont: Float, targetFont: Float, wrapMode: Boolean) -> Unit,
    onPinchEnd: (pinching: Boolean, wrapMode: Boolean, startFont: Float, targetFont: Float) -> Unit
): Modifier {
    val latestFontSize = rememberUpdatedState(currentFontSize)
    val latestWordWrap = rememberUpdatedState(currentWordWrap)
    val latestCanStart = rememberUpdatedState(canStartPinch)
    val latestStart = rememberUpdatedState(onPinchStart)
    val latestUpdate = rememberUpdatedState(onPinchUpdate)
    val latestEnd = rememberUpdatedState(onPinchEnd)

    return pointerInput(enabled) {
        if (!enabled) return@pointerInput
        awaitEachGesture {
            // The BasicTextField consumes its down event. We still observe it,
            // but never consume a one-finger move or release.
            awaitFirstDown(requireUnconsumed = false)
            var pinching = false
            var startDistance = 0f
            var startFont = 0f
            var targetFont = 0f
            var wrapMode = false
            var finished = false
            try {
                while (!finished) {
                    val event = awaitPointerEvent()
                    val pressed = event.changes.filter { it.pressed }
                    when {
                        pressed.size >= 2 -> {
                            if (!pinching) {
                                // A previous commit may still be settling. In that
                                // short window this gesture passes through untouched.
                                if (latestCanStart.value.invoke()) {
                                    pinching = true
                                    startDistance = (pressed[0].position - pressed[1].position).getDistance()
                                    startFont = latestFontSize.value.invoke()
                                    targetFont = startFont
                                    wrapMode = latestWordWrap.value.invoke()
                                    latestStart.value.invoke(wrapMode, startFont)
                                    pressed[0].consume()
                                    pressed[1].consume()
                                }
                            } else {
                                if (startDistance > 0f) {
                                    val distance = (pressed[0].position - pressed[1].position).getDistance()
                                    if (distance > 0f) {
                                        targetFont = (startFont * (distance / startDistance)).coerceIn(9f, 24f)
                                        latestUpdate.value.invoke(startFont, targetFont, wrapMode)
                                    }
                                }
                                pressed[0].consume()
                                pressed[1].consume()
                            }
                        }
                        pressed.isEmpty() -> finished = true
                        else -> if (pinching) finished = true
                    }
                }
            } finally {
                latestEnd.value.invoke(pinching, wrapMode, startFont, targetFont)
            }
        }
    }
}
