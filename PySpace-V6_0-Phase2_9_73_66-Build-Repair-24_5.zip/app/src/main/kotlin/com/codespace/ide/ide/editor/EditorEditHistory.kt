package com.codespace.ide.ide.editor

import java.util.ArrayDeque
import com.codespace.ide.memory.MemoryRuntimePolicy
import com.codespace.ide.memory.MemoryTrimRegistry
import com.codespace.ide.memory.MemoryTrimmable

// Compatibility alias; the immutable value belongs to the domain model.
typealias EditorTextSnapshot = com.codespace.ide.domain.editor.model.EditorTextSnapshot

/**
 * Memory-bounded snapshot history. This deliberately favors predictable
 * memory use on phones over retaining an unlimited number of large buffers.
 * A new edit invalidates redo, and both stacks share one character budget.
 */
class EditorEditHistory(
    maxEntries: Int = 40,
    maxStoredChars: Int = 1_500_000,
) : MemoryTrimmable {
    private val configuredMaxEntries = maxEntries
    private val configuredMaxStoredChars = maxStoredChars
    private val maxEntries: Int get() = minOf(configuredMaxEntries, MemoryRuntimePolicy.editorHistoryMaxEntries())
    private val maxStoredChars: Int get() = minOf(configuredMaxStoredChars, MemoryRuntimePolicy.editorHistoryMaxChars())
    private val undo = ArrayDeque<EditorTextSnapshot>()
    private val redo = ArrayDeque<EditorTextSnapshot>()
    private var storedChars = 0L

    init { MemoryTrimRegistry.register(this) }

    val canUndo: Boolean get() = undo.isNotEmpty()
    val canRedo: Boolean get() = redo.isNotEmpty()

    fun record(snapshot: EditorTextSnapshot) {
        clearRedo()
        if (snapshot.text.length > maxStoredChars || maxEntries <= 0 || maxStoredChars <= 0) {
            clearUndo()
            return
        }
        undo.addLast(snapshot)
        storedChars += snapshot.text.length
        trimOldest()
    }

    fun undo(current: EditorTextSnapshot): EditorTextSnapshot? {
        if (undo.isEmpty()) return null
        val previous = undo.removeLast()
        storedChars -= previous.text.length
        addBounded(redo, current)
        return previous
    }

    fun redo(current: EditorTextSnapshot): EditorTextSnapshot? {
        if (redo.isEmpty()) return null
        val next = redo.removeLast()
        storedChars -= next.text.length
        addBounded(undo, current)
        return next
    }

    fun clear() {
        undo.clear()
        redo.clear()
        storedChars = 0L
    }

    override fun trimToPolicy() {
        trimOldest()
    }

    override fun clearTemporaryCaches() {
        // Undo/redo is a user-facing editing feature, not a disposable cache.
        // It is reduced under memory pressure but preserved by the manual cache action.
    }

    private fun addBounded(target: ArrayDeque<EditorTextSnapshot>, snapshot: EditorTextSnapshot) {
        if (snapshot.text.length > maxStoredChars) {
            clear()
            return
        }
        target.addLast(snapshot)
        storedChars += snapshot.text.length
        trimOldest()
    }

    private fun trimOldest() {
        while (undo.size + redo.size > maxEntries || storedChars > maxStoredChars) {
            // Prefer dropping the oldest undo state. If none remains, drop
            // the oldest redo state; the newest operation remains usable.
            val removed = when {
                undo.isNotEmpty() -> undo.removeFirst()
                redo.isNotEmpty() -> redo.removeFirst()
                else -> null
            } ?: break
            storedChars -= removed.text.length
        }
    }

    private fun clearRedo() {
        while (redo.isNotEmpty()) storedChars -= redo.removeFirst().text.length
    }

    private fun clearUndo() {
        while (undo.isNotEmpty()) storedChars -= undo.removeFirst().text.length
    }
}
