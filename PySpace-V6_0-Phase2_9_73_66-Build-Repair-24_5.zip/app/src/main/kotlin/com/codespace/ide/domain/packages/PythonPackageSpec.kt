package com.codespace.ide.domain.packages

/** Pure validation and parsing rules shared by the package UI and pip adapter. */
object PythonPackageSpec {
    private val PACKAGE_NAME = Regex("^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
    private val REQUIREMENT = Regex(
        "^[A-Za-z0-9][A-Za-z0-9._-]{0,127}" +
            "(?:\\[[A-Za-z0-9_,.-]{1,100}\\])?" +
            "(?:(?:===|==|~=|!=|<=|>=|<|>)[A-Za-z0-9.*+!_-]{1,64})?$"
    )
    private val FREEZE_LINE = Regex("^([A-Za-z0-9][A-Za-z0-9._-]*)==([^\\s]+)$")

    fun isSafeRequirement(value: String): Boolean = REQUIREMENT.matches(value)

    fun isSafePackageName(value: String): Boolean = PACKAGE_NAME.matches(value)

    fun parseFreeze(raw: String): List<InstalledPythonPackage> {
        val parsed = LinkedHashMap<String, InstalledPythonPackage>()
        for (line in raw.lineSequence()) {
            val match = FREEZE_LINE.matchEntire(line.trim()) ?: continue
            val name = match.groupValues[1]
            val version = match.groupValues[2]
            if (!name.equals("pip", ignoreCase = true)) {
                parsed[name.lowercase()] = InstalledPythonPackage(name, version)
            }
        }
        return parsed.values.sortedBy { it.name.lowercase() }
    }
}
