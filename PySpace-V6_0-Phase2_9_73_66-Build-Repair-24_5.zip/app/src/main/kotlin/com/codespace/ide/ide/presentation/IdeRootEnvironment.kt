package com.codespace.ide.ide.presentation

import android.content.Context
import androidx.activity.ComponentActivity
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.codespace.ide.ide.theme.IdeTheme

/** Owns asynchronous preparation and retry state for the private project workspace. */
class IdeWorkspaceBootstrapState internal constructor(
    val workspace: File?,
    val error: String?,
    private val retryAction: () -> Unit,
) {
    fun retry() = retryAction()
}

@Composable
fun rememberIdeWorkspace(appContext: Context): IdeWorkspaceBootstrapState {
    var workspace by remember(appContext) { mutableStateOf<File?>(null) }
    var errorMessage by remember(appContext) { mutableStateOf<String?>(null) }
    var attempt by remember(appContext) { mutableStateOf(0) }

    LaunchedEffect(appContext, attempt) {
        errorMessage = null
        try {
            workspace = withContext(Dispatchers.IO) { workspaceRoot(appContext) }
        } catch (error: Exception) {
            workspace = null
            errorMessage = error.message ?: "Unable to prepare the private projects directory."
        }
    }

    return remember(workspace, errorMessage) {
        IdeWorkspaceBootstrapState(workspace, errorMessage) { attempt++ }
    }
}

/** Resolves the Activity host without leaking Android context traversal into the root screen. */
@Composable
fun rememberIdeHostActivity(context: Context): ComponentActivity? = remember(context) {
    generateSequence<Context>(context) { current ->
        (current as? android.content.ContextWrapper)?.baseContext
    }.firstOrNull { it is ComponentActivity } as? ComponentActivity
}

/** Applies the selected IDE theme to system bars as a presentation side effect. */
@Composable
fun IdeWindowThemeEffect(activity: ComponentActivity?, themeId: String) {
    SideEffect {
        IdeTheme.setTheme(themeId)
        activity?.window?.let { window ->
            val light = !IdeTheme.isDark
            window.statusBarColor = Color(IdeTheme.BG).toArgb()
            window.navigationBarColor = Color(IdeTheme.BG).toArgb()
            @Suppress("DEPRECATION")
            val currentFlags = window.decorView.systemUiVisibility
            val lightBarFlags = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (light) {
                currentFlags or lightBarFlags
            } else {
                currentFlags and lightBarFlags.inv()
            }
        }
    }
}
