package com.codespace.ide.ide.run

import com.codespace.ide.domain.camera.detectCameraFromSource
import com.codespace.ide.ide.WebServer
import com.codespace.ide.ide.gui.GuiApp

/**
 * Immutable result of inspecting one Python source snapshot before launch.
 * It contains decisions only; it never reads files, asks for Android
 * permissions, starts display/camera resources, builds shell commands or
 * owns a process/PTY.
 */
data class RunSourceAnalysis(
    val gui: GuiApp? = null,
    val useFrame: Boolean = false,
    val wantsCamera: Boolean = false,
    val webServer: WebServer? = null,
) {
    val isWebLike: Boolean get() = webServer != null
}

/**
 * Shared source-based launch analysis for Console and Terminal.
 * Keeping the scan in one place prevents the two launch paths from drifting
 * while leaving project-wide web discovery and Android resource activation
 * with their existing owners.
 */
object RunSourceAnalyzer {

    /**
     * Analyze an already available source snapshot. Callers are responsible
     * for obtaining the text off Main when it comes from disk.
     *
     * [forceGui] is the Console's explicit "Run with display" override. It
     * does not affect Terminal analysis and does not force frame rendering.
     */
    fun analyze(
        fileName: String,
        source: String?,
        forceGui: Boolean = false,
    ): RunSourceAnalysis {
        val gui = try {
            detectGuiFromSource(fileName, source)
                ?: if (forceGui) GuiApp("graphics", "") else null
        } catch (_: Exception) {
            if (forceGui) GuiApp("graphics", "") else null
        }

        val useFrame = try {
            gui != null && !forceGui && frameViewEligible(gui, source)
        } catch (_: Exception) {
            false
        }

        val wantsCamera = try {
            detectCameraFromSource(fileName, source)
        } catch (_: Exception) {
            false
        }

        val webServer = try {
            if (source.isNullOrBlank()) null else detectWebServerFromSource(fileName, source)
        } catch (_: Exception) {
            null
        }

        return RunSourceAnalysis(
            gui = gui,
            useFrame = useFrame,
            wantsCamera = wantsCamera,
            webServer = webServer,
        )
    }
}
