package com.codespace.ide

import android.app.Application
import com.codespace.ide.di.appModule
import com.codespace.ide.ide.CrashLog
import com.codespace.ide.service.RunServiceManager
import com.codespace.ide.memory.MemoryRuntimePolicy
import org.koin.core.context.GlobalContext
import org.koin.core.context.startKoin
import com.codespace.ide.ide.RunHub

/**
 * Application entry point: starts Koin once for the whole process, so state
 * holders (runtime manager, kernels, future ViewModels) can outlive a single
 * Activity/Compose composition.
 */
class UbuntuTerminalApplication : Application() {
    override fun onCreate() {
        super.onCreate()

        // Installed first, unconditionally, in every process this Application runs in - so a
        // crash anywhere below (Koin, the foreground service, a Compose screen...) is still
        // written to disk before the process dies. See CrashViewerActivity.
        CrashLog.install(this)

        // CrashViewerActivity runs in its own ":viewer" process precisely so that whatever is
        // broken below never executes there, and the crash-log screen stays reachable even when
        // the main app cannot start at all. Nothing else in this method may run for that process.
        if (getProcessName().endsWith(":viewer")) return

        MemoryRuntimePolicy.initialize(this)
        registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityCreated(activity: android.app.Activity, state: android.os.Bundle?) = Unit
            override fun onActivityStarted(activity: android.app.Activity) = Unit
            override fun onActivityResumed(activity: android.app.Activity) {
                MemoryRuntimePolicy.onForeground()
            }
            override fun onActivityPaused(activity: android.app.Activity) = Unit
            override fun onActivityStopped(activity: android.app.Activity) = Unit
            override fun onActivitySaveInstanceState(activity: android.app.Activity, outState: android.os.Bundle) = Unit
            override fun onActivityDestroyed(activity: android.app.Activity) = Unit
        })

        startKoin {
            modules(appModule(this@UbuntuTerminalApplication))
        }
        // From now on every RunHub change starts/updates/stops the keep-alive
        // foreground service. Runs themselves are still owned by the IDE screen;
        // this only guarantees the process survives app switches.
        GlobalContext.get().get<RunServiceManager>().start()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (getProcessName().endsWith(":viewer")) return
        MemoryRuntimePolicy.onTrimMemory(level)
    }

    override fun onLowMemory() {
        super.onLowMemory()
        if (getProcessName().endsWith(":viewer")) return
        MemoryRuntimePolicy.onTrimMemory(android.content.ComponentCallbacks2.TRIM_MEMORY_COMPLETE)
    }
}
