package com.codespace.ide.ide.editor

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.layout.Measurable
import androidx.compose.ui.layout.Placeable
import androidx.compose.ui.layout.layoutId
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ide.theme.IdeTheme
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Consume only the scroll remainder after an inner popup scroller has had
 *  the first chance to move. This gives each popup a hard scroll boundary: at
 *  its beginning/end, a drag cannot leak into the editor underneath. */
@Composable
internal fun Modifier.containPopupScroll(): Modifier = nestedScroll(
    remember {
        object : NestedScrollConnection {
            override fun onPostScroll(
                consumed: Offset,
                available: Offset,
                source: NestedScrollSource
            ): Offset = available

            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity = available
        }
    }
)

/** Last good popup anchor (document coordinates) and the sheet shift it was captured under. */
internal class AnchorMemo {
    var rect: Rect? = null
    var shiftX = 0f
    var shiftY = 0f
}

internal class PopupSlotSpec(
    val anchor: Rect,
    val widthPx: Float,
    val heightPx: Float,
    /** true: exactly [heightPx] tall (lists); false: content height up to [heightPx]. */
    val fixedHeight: Boolean,
    /** false: dropped when it cannot be placed without overlapping something. */
    val mustShow: Boolean,
    /** false: always its full height (or not shown) so it never pulses while scrolling. */
    val shrinkable: Boolean = true,
    /** Preferred sides, first choice first (0 below, 1 above, 2 right, 3 left). */
    val order: List<Int> = listOf(0, 1, 2, 3)
)

internal class PopupMemory {
    var side = -1
    /** Anchor position / container size / lock state seen by the previous layout pass. */
    var ax = 0f
    var ay = 0f
    var viewW = 0f
    var viewH = 0f
    var wasLocked = false
    var cross = 0f
    /** Vertical gap to the anchor edge (below: top - anchor.bottom, above: bottom - anchor.top). */
    var dy = 0f
    var height = 0f
}

/**
 * Rectangle for a card on [side] (0 below, 1 above, 2 right, 3 left of the
 * anchor [a]) that stays inside [win] and clear of every rect in
 * [obstacles]. The card may be SHRUNK in height (down to what is free) —
 * it never overlaps anything. Null when that side has no room at all.
 */
internal fun fitPopupSide(
    side: Int, a: Rect, w: Float, hn: Float, gap: Float, win: Rect, obstacles: List<Rect>
): Rect? {
    val minX = win.left + gap
    val maxX = max(minX, win.right - w - gap)
    if (side < 2) {
        // Cards on the same side STACK (caret, first card, second card, …)
        // instead of fighting for the slot next to the caret, so they keep
        // their order while the viewport moves.
        val x = a.left.coerceIn(minX, maxX)
        val xr = x + w
        val obs = ArrayList<Rect>()
        for (o0 in obstacles) {
            val o = o0.inflate(gap / 2f)
            if (o.right > x && o.left < xr) obs.add(o)
        }
        var best: Rect? = null
        if (side == 0) {
            val limit = win.bottom - gap
            val starts = ArrayList<Float>()
            starts.add(a.bottom + gap)
            for (o in obs) if (o.top >= a.bottom) starts.add(o.bottom + gap)
            starts.sort()
            for (t in starts) {
                if (t >= limit) continue
                if (obs.any { it.top <= t && it.bottom > t }) continue
                var end = min(t + hn, limit)
                for (o in obs) if (o.top > t && o.top < end) end = o.top
                if (end - t < 1f) continue
                val r = Rect(x, t, xr, end)
                if (r.height >= hn - 0.5f) return r
                if (best == null || r.height > best.height) best = r
            }
        } else {
            val limit = win.top + gap
            val starts = ArrayList<Float>()
            starts.add(a.top - gap)
            for (o in obs) if (o.bottom <= a.top) starts.add(o.top - gap)
            starts.sortDescending()
            for (bt in starts) {
                if (bt <= limit) continue
                if (obs.any { it.top < bt && it.bottom >= bt }) continue
                var st = max(bt - hn, limit)
                for (o in obs) if (o.bottom < bt && o.bottom > st) st = o.bottom
                if (bt - st < 1f) continue
                val r = Rect(x, st, xr, bt)
                if (r.height >= hn - 0.5f) return r
                if (best == null || r.height > best.height) best = r
            }
        }
        return best
    }
    val h = min(hn, win.height - 2f * gap)
    if (h < 1f) return null
    val minY = win.top + gap
    val y = a.top.coerceIn(minY, max(minY, win.bottom - h - gap))
    val x = if (side == 2) a.right + gap else a.left - gap - w
    if (x < win.left + gap - 0.5f || x + w > win.right - gap + 0.5f) return null
    val r = Rect(x, y, x + w, y + h)
    for (o0 in obstacles) if (r.overlaps(o0.inflate(gap / 2f))) return null
    return r
}

internal fun popupFrozenRect(
    side: Int, cross: Float, dy: Float, a: Rect, w: Float, h: Float, gap: Float
): Rect =
    when (side) {
        0 -> Rect(a.left + cross, a.bottom + dy, a.left + cross + w, a.bottom + dy + h)
        1 -> Rect(a.left + cross, a.top + dy - h, a.left + cross + w, a.top + dy)
        2 -> Rect(a.right + gap, a.top + cross, a.right + gap + w, a.top + cross + h)
        else -> Rect(a.left - gap - w, a.top + cross, a.left - gap, a.top + cross + h)
    }

/**
 * Lays out the editor's cards (slot 0 suggestions, 1 documentation,
 * 2 diagnostics, 3 signature help; children tagged with layoutId), in priority order. A card
 * takes the first side (below, above, right, left of its caret) with room
 * for its full height; otherwise the side with the most room, shrunk to fit
 * (its content scrolls); a card that cannot be placed without touching the
 * caret or an earlier card is not shown. Cards therefore NEVER overlap.
 * While the caret is not fully inside the visible lane the last side and
 * offset are kept, so the card leaves the view together with the caret.
 */
@Composable
internal fun EditorPopupLayer(
    modifier: Modifier,
    specs: List<PopupSlotSpec?>,
    gapPx: Float,
    minHeightPx: Float,
    gutterPx: Float,
    viewportW: Float,
    viewportH: Float,
    scrollX: () -> Int,
    scrollY: () -> Int,
    /** True while a zoom is running / being committed: placement is never re-evaluated then. */
    lockPlacement: Boolean,
    content: @Composable () -> Unit
) {
    val memories = remember { Array(4) { PopupMemory() } }
    Layout(content = content, modifier = modifier) { measurables, constraints ->
        val sx = scrollX().toFloat()
        val sy = scrollY().toFloat()
        // Visible code lane in document coordinates.
        val win = Rect(sx + gutterPx, sy, sx + viewportW, sy + viewportH)
        val availW = (viewportW - gutterPx - 2f * gapPx).coerceAtLeast(1f)
        val availH = (viewportH - 2f * gapPx).coerceAtLeast(1f)
        val bySlot = arrayOfNulls<Measurable>(4)
        for (m in measurables) {
            val slot = m.layoutId as? Int ?: continue
            if (slot in 0..3) bySlot[slot] = m
        }
        val placeables = arrayOfNulls<Placeable>(4)
        val offsets = arrayOfNulls<IntOffset>(4)
        val obstacles = ArrayList<Rect>()
        for (spec in specs) if (spec != null) obstacles.add(spec.anchor)
        for (slot in 0..3) {
            val m = bySlot[slot]
            val spec = specs.getOrNull(slot)
            val mem = memories[slot]
            if (m == null || spec == null) { mem.side = -1; continue }
            val wI = min(spec.widthPx, availW).roundToInt()
            val w = wI.toFloat()
            val capH = min(spec.heightPx, availH)
            val natural = if (spec.fixedHeight) capH
            else min(capH, m.maxIntrinsicHeight(wI).toFloat())
            val a = spec.anchor
            val inView = a.left >= win.left && a.right <= win.right &&
                a.top >= win.top && a.bottom <= win.bottom
            // A card is PLACED ONCE, when it first becomes visible, and from then on keeps that
            // placement relative to its anchor: scrolling never moves it relative to the caret
            // (it leaves the screen together with the caret). Placement is only evaluated again
            // when (a) the container size changes (keyboard / rotation) or (b) the anchor itself
            // moved because of an edit or caret move - never because of a scroll (anchors are in
            // document coordinates) and never because of a zoom (locked, and the first pass after
            // the zoom only records the new anchor).
            val preferSide = mem.side
            if (mem.side >= 0 &&
                (abs(mem.viewW - viewportW) > 1f || abs(mem.viewH - viewportH) > 1f)
            ) mem.side = -1
            val anchorMoved = abs(a.left - mem.ax) > 0.75f || abs(a.top - mem.ay) > 0.75f
            if (mem.side >= 0 && inView && anchorMoved && !lockPlacement && !mem.wasLocked) mem.side = -1
            mem.ax = a.left
            mem.ay = a.top
            mem.wasLocked = lockPlacement
            if (mem.side < 0 && inView) {
                var best: Rect? = null
                var bestSide = -1
                val order = if (preferSide in 0..3) {
                    listOf(preferSide) + spec.order.filter { it != preferSide }
                } else spec.order
                for (side in order) {
                    val r = fitPopupSide(side, a, w, natural, gapPx, win, obstacles) ?: continue
                    if (r.height >= natural - 0.5f) { best = r; bestSide = side; break }
                    if (!spec.shrinkable) continue
                    if (best == null || r.height > best.height) { best = r; bestSide = side }
                }
                val usable = best != null && best.height >= min(natural, minHeightPx)
                if (!usable) { mem.side = -1; continue }
                val r = best!!
                val hI = r.height.roundToInt().coerceAtLeast(1)
                val p = m.measure(
                    if (spec.fixedHeight) Constraints(wI, wI, hI, hI) else Constraints(wI, wI, 0, hI)
                )
                val y = if (bestSide == 1) r.bottom - p.height else r.top
                mem.side = bestSide
                mem.viewW = viewportW
                mem.viewH = viewportH
                mem.cross = if (bestSide < 2) r.left - a.left else y - a.top
                mem.dy = if (bestSide == 0) y - a.bottom else if (bestSide == 1) (y + p.height) - a.top else 0f
                mem.height = r.height
                placeables[slot] = p
                offsets[slot] = IntOffset(r.left.roundToInt(), y.roundToInt())
                obstacles.add(Rect(r.left, y, r.left + p.width, y + p.height))
            } else if (mem.side >= 0 || spec.mustShow) {
                // The caret is leaving the view: keep the last placement
                // relative to it, so the card leaves together with it.
                val hh = if (mem.side >= 0) mem.height else natural
                val hI = hh.roundToInt().coerceAtLeast(1)
                val p = m.measure(
                    if (spec.fixedHeight) Constraints(wI, wI, hI, hI) else Constraints(wI, wI, 0, hI)
                )
                val r = popupFrozenRect(
                    if (mem.side >= 0) mem.side else 0,
                    if (mem.side >= 0) mem.cross else 0f,
                    if (mem.side >= 0) mem.dy else gapPx,
                    a, w, p.height.toFloat(), gapPx
                )
                placeables[slot] = p
                offsets[slot] = IntOffset(r.left.roundToInt(), r.top.roundToInt())
                obstacles.add(r)
            }
        }
        layout(constraints.maxWidth, constraints.maxHeight) {
            for (slot in 0..3) {
                val p = placeables[slot] ?: continue
                val o = offsets[slot] ?: continue
                p.place(o)
            }
        }
    }
}

/** Close "×" shared by every editor popup card (26 dp touch target). */
@Composable
internal fun PopupClose(onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(26.dp)
            .clip(RoundedCornerShape(50))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text("×", color = Color(IdeTheme.TEXT).copy(alpha = 0.75f), fontSize = 18.sp)
    }
}
