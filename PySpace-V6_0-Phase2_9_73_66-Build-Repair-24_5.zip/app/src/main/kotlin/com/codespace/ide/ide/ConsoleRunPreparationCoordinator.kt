package com.codespace.ide.ide

import com.codespace.ide.ide.run.CameraRunCoordinator
import com.codespace.ide.ide.run.ConsoleWebPreparation
import com.codespace.ide.ide.run.ProjectWebResolverRepository
import com.codespace.ide.ide.projects.PyProject
import java.io.File
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Owns the asynchronous, cancellable preparation stages that must complete
 * before a Console run can be committed. It does not own request generations
 * or Compose/run state: the shell supplies the current-generation reader and
 * receives a Main-thread continuation only while that generation is current.
 */
internal class ConsoleRunPreparationCoordinator(
    private val scope: CoroutineScope,
    private val projectWebResolver: ProjectWebResolverRepository,
    private val cameraRunCoordinator: CameraRunCoordinator,
) {
    fun prepareWeb(
        requestId: Long,
        currentRequestId: () -> Long,
        project: PyProject,
        file: File,
        sourceSnapshot: String,
        originalSourceText: String?,
        immediate: WebServer?,
        pythonBin: String,
        onPrepared: (ConsoleWebPreparation) -> Unit,
    ) {
        scope.launch {
            val preparation = try {
                projectWebResolver.prepareConsole(
                    project = project,
                    activeFile = file,
                    sourceSnapshot = sourceSnapshot,
                    originalSourceText = originalSourceText,
                    immediate = immediate,
                    pythonBin = pythonBin,
                )
            } catch (cancel: CancellationException) {
                throw cancel
            } catch (_: Exception) {
                ConsoleWebPreparation(null, immediate)
            }
            withContext(Dispatchers.Main) {
                if (requestId == currentRequestId()) onPrepared(preparation)
            }
        }
    }

    fun prepareCamera(
        requestId: Long,
        currentRequestId: () -> Long,
        requestPermission: () -> Unit,
        onPrepared: (String) -> Unit,
    ) {
        scope.launch {
            val prefix = try {
                cameraRunCoordinator.prepareRun(
                    shouldContinue = { requestId == currentRequestId() },
                    requestPermission = requestPermission,
                )
            } catch (cancel: CancellationException) {
                throw cancel
            } catch (_: Exception) {
                ""
            }
            withContext(Dispatchers.Main) {
                if (requestId == currentRequestId()) onPrepared(prefix)
            }
        }
    }
}
