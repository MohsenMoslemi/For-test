package com.codespace.ide.ide.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.layoutId
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ide.codeintel.PythonCompletionItem
import com.codespace.ide.ide.theme.IdeTheme

/** Presentation-only completion list. Selection and dismissal remain owned by PyEditor. */
@Composable
fun EditorCompletionPopup(
    items: List<PythonCompletionItem>,
    onSelect: (PythonCompletionItem) -> Unit,
    onDismiss: () -> Unit,
    onPositioned: (androidx.compose.ui.layout.LayoutCoordinates) -> Unit
) {
    val popupShape = RoundedCornerShape(12.dp)
    Column(
        modifier = Modifier
            .layoutId(0)
            .onGloballyPositioned(onPositioned)
            .shadow(14.dp, popupShape)
            .clip(popupShape)
            .containPopupScroll()
            .background(Color(IdeTheme.PANEL))
            .border(1.dp, Color(IdeTheme.LINE), popupShape)
            .padding(vertical = 5.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SUGGESTIONS · ${items.size}",
                color = Color(IdeTheme.DIM),
                fontSize = 9.sp,
                letterSpacing = 1.sp,
                modifier = Modifier.weight(1f)
            )
            PopupClose(onDismiss)
        }
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(items) { item ->
                val itemColor = when (item.kind) {
                    "function", "builtin", "member" -> Color(IdeTheme.BUILTIN)
                    "class" -> Color(IdeTheme.WARN)
                    "parameter" -> Color(IdeTheme.TEAL)
                    "module", "import", "auto_import" -> Color(IdeTheme.TEAL)
                    "keyword" -> Color(IdeTheme.VIOLET)
                    else -> Color(IdeTheme.TEXT)
                }
                val marker = when (item.kind) {
                    "function", "builtin", "member" -> "ƒ"
                    "parameter" -> "P"
                    "variable" -> "x"
                    "import" -> "I"
                    "auto_import" -> "+"
                    "class" -> "C"
                    "module" -> "M"
                    "keyword" -> "K"
                    "attribute" -> "·"
                    else -> "v"
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(item) }
                        .heightIn(min = 44.dp)
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(RoundedCornerShape(7.dp))
                            .background(itemColor.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(marker, color = itemColor, fontSize = 13.sp)
                    }
                    Column(modifier = Modifier.weight(1f).padding(start = 9.dp)) {
                        Text(item.name, color = Color(IdeTheme.TEXT), fontSize = 12.sp, maxLines = 1)
                        if (item.detail.isNotBlank()) {
                            Text(item.detail, color = Color(IdeTheme.DIM), fontSize = 9.sp, maxLines = 1)
                        }
                    }
                    Text(
                        item.kind.replace('_', ' ').uppercase(),
                        color = itemColor,
                        fontSize = 8.sp,
                        maxLines = 1
                    )
                }
            }
        }
    }
}
