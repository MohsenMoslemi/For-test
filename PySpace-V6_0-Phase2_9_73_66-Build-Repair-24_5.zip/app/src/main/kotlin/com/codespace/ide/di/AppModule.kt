package com.codespace.ide.di

import android.content.Context
import com.codespace.ide.ProotManager
import com.codespace.ide.UbuntuManager
import com.codespace.ide.ide.NotebookKernelManager
import com.codespace.ide.ide.notebook.NotebookRepository
import com.codespace.ide.ide.explorer.FileExplorerRepository
import com.codespace.ide.ide.explorer.DefaultFileExplorerRepository
import com.codespace.ide.ide.projects.ProjectRepository
import com.codespace.ide.ide.projects.FileProjectRepository
import com.codespace.ide.ide.settings.SettingsRepository
import com.codespace.ide.ide.settings.SharedPreferencesSettingsRepository
import com.codespace.ide.ide.RunHub
import com.codespace.ide.ide.codeintel.CodeIntelligenceRepository
import com.codespace.ide.ide.codeintel.FileCodeIntelligenceRepository
import com.codespace.ide.ide.run.RunOrchestrator
import com.codespace.ide.ide.run.ProjectWebResolverRepository
import com.codespace.ide.service.RunServiceManager
import com.codespace.ide.runtime.RuntimeDispatchers
import com.codespace.ide.runtime.RuntimeTaskScope
import com.codespace.ide.domain.notebook.contract.NotebookSerializer
import com.codespace.ide.domain.notebook.contract.NotebookParser
import com.codespace.ide.application.notebook.usecase.SerializeNotebookUseCase
import com.codespace.ide.application.notebook.usecase.ParseNotebookUseCase
import com.codespace.ide.data.notebook.JsonNotebookSerializer
import com.codespace.ide.data.notebook.JsonNotebookParser
import com.codespace.ide.domain.packages.PackageManagerRepository
import com.codespace.ide.data.packages.ProotPackageManagerRepository
import com.codespace.ide.domain.editor.contract.EditorSessionSerializer
import com.codespace.ide.application.editor.usecase.SerializeEditorSessionUseCase
import com.codespace.ide.data.editor.JsonEditorSessionSerializer
import org.koin.dsl.module
import com.codespace.ide.ide.JSON

/**
 * Process-wide dependency graph.
 *
 * Everything here is an application singleton on purpose: the runtime, the
 * notebook kernels and the run/server service must survive Activity recreation,
 * tab switches and the Raw JSON <-> notebook toggle.
 *
 * We use koin-core (not koin-android) on purpose. koin-android drags in a much
 * newer androidx.activity/lifecycle graph, which pulls Compose 1.9 transitively
 * while this project compiles against Compose 1.7.5; the native builder reads
 * POMs only and misses Compose's Gradle-metadata-only deps (savedstate-compose),
 * which crashes at startup. Passing the Application context here keeps the
 * dependency graph identical to the pre-Koin one.
 */
fun appModule(appContext: Context) = module {
    single { RuntimeDispatchers.Default }
    single { RuntimeTaskScope(get()) }
    single { UbuntuManager(appContext, get()) }
    single { ProotManager(appContext, get()) }
    single { NotebookKernelManager(appContext, get()) }
    single<NotebookSerializer> { JsonNotebookSerializer() }
    single<NotebookParser> { JsonNotebookParser() }
    single { SerializeNotebookUseCase(get()) }
    single { ParseNotebookUseCase(get()) }
    single<PackageManagerRepository> { ProotPackageManagerRepository(get(), get()) }
    single<EditorSessionSerializer> { JsonEditorSessionSerializer() }
    single { SerializeEditorSessionUseCase(get()) }
    single {
        NotebookRepository(
            kernels = get<NotebookKernelManager>(),
            dispatchers = get<RuntimeDispatchers>(),
            taskScope = get<RuntimeTaskScope>(),
            serializeNotebookUseCase = get<SerializeNotebookUseCase>(),
            parseNotebookUseCase = get<ParseNotebookUseCase>(),
        )
    }
    single<FileExplorerRepository> { DefaultFileExplorerRepository(get()) }
    single<ProjectRepository> { FileProjectRepository(get(), get(), get()) }
    single<SettingsRepository> { SharedPreferencesSettingsRepository(appContext) }
    single<CodeIntelligenceRepository> { FileCodeIntelligenceRepository() }
    single { RunHub() }
    single { RunOrchestrator(hub = get<RunHub>()) }
    single { ProjectWebResolverRepository(get()) }
    single { RunServiceManager(appContext, get()) }
}
