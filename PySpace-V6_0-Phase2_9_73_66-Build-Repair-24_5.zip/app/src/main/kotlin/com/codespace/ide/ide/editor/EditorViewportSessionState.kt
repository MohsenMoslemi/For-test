package com.codespace.ide.ide.editor

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.TextLayoutResult

/**
 * Per-document measured viewport snapshot for the editor surface.
 *
 * This is presentation geometry only: it does not own document text, scroll
 * offsets, selection, or IME state. The surface reports measurements here and
 * layout/overlay workflows consume the same snapshot.
 */
@Stable
internal class EditorViewportSessionState {
    var heightPx: Int by mutableStateOf(0)
    var widthPx: Int by mutableStateOf(0)
    var fieldWidthPx: Int by mutableStateOf(0)
    var textLayout: TextLayoutResult? by mutableStateOf(null)

    fun updateViewport(width: Int, height: Int) {
        widthPx = width.coerceAtLeast(0)
        heightPx = height.coerceAtLeast(0)
    }

    fun updateFieldWidth(width: Int) {
        fieldWidthPx = width.coerceAtLeast(0)
    }
}

@Composable
internal fun rememberEditorViewportSessionState(filePath: String): EditorViewportSessionState =
    remember(filePath) { EditorViewportSessionState() }
