package com.codespace.ide.ide.shell
import com.codespace.ide.ide.IdeScreen
import com.codespace.ide.ide.camera.PhoneCamera
import com.codespace.ide.ide.debug.DebugController
import com.codespace.ide.ide.projects.PyProject
import com.codespace.ide.ide.runtimeui.RuntimeUiViewModel
import com.codespace.ide.ide.settings.IdePrefs
import com.codespace.ide.ide.terminal.ConsoleState
import com.codespace.ide.ide.testing.TestControllerRegistry


/**
 * Owns the ordered teardown protocol for intentionally leaving an IDE project.
 * Resource-specific owners still perform their own stop/dispose operations;
 * this coordinator only sequences those operations and clears presentation state.
 */
internal class ProjectExitCoordinator(
    private val sessionPersistence: IdeSessionPersistence,
    private val prefs: IdePrefs,
    private val currentProject: () -> PyProject?,
    private val persistCurrentSession: () -> Unit,
    private val debugControllerForPath: (String) -> DebugController?,
    private val stopConsole: (killDisplay: Boolean) -> Unit,
    private val phoneCamera: PhoneCamera,
    private val console: ConsoleState,
    private val runtimeUiViewModel: RuntimeUiViewModel,
    private val runSessionState: IdeRunSessionState,
    private val panelState: IdePanelState,
    private val navigationState: IdeNavigationState,
) {
    fun leaveProject(persistSession: Boolean = true) {
        // A deliberate exit must not be mistaken for a crash/recents restore.
        sessionPersistence.invalidateRestoreMarker()
        prefs.clearLastProject()
        if (persistSession) persistCurrentSession()

        // Panel/tab changes never invoke this path, so an active debugger remains
        // alive until the owning project is deliberately left.
        currentProject()?.dir?.absolutePath?.let { path ->
            debugControllerForPath(path)?.stop()
            TestControllerRegistry.remove(path)
        }

        stopConsole(true)
        try {
            phoneCamera.stopAll("Left project — camera and bridge stopped.")
        } catch (_: Exception) {
        }

        runSessionState.consoleLive.value = false
        runSessionState.consoleCmd.value = null
        console.running = false
        console.clear()
        runtimeUiViewModel.resetProjectPresentation()
        runSessionState.consoleRunId.value++
        panelState.open.value = false
        prefs.clearLastProject()
        navigationState.screen.value = IdeScreen.Home
    }
}
