package com.codespace.ide.ide.editor

import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.DisposableEffect
import com.codespace.ide.ProotManager
import com.codespace.ide.ide.projects.PyProject
import com.codespace.ide.ide.projects.guestProjectPath
import com.codespace.ide.ide.projects.projectPythonBin
import com.codespace.ide.ide.projects.projectVenvName
import com.codespace.ide.ide.codeintel.ProjectIndexMonitor
import com.codespace.ide.ide.codeintel.PythonEnvironmentIndexMonitor
import kotlinx.coroutines.delay

/** Owns the project-scoped indexing monitors and their Compose lifecycle. */
data class EditorIndexingSession(
    val indexMonitor: ProjectIndexMonitor,
    val indexState: ProjectIndexMonitor.State,
    val environmentIndexMonitor: PythonEnvironmentIndexMonitor,
    val environmentIndexState: PythonEnvironmentIndexMonitor.State,
    val showIndexChip: MutableState<Boolean>
)

@Composable
fun rememberEditorIndexingSession(
    project: PyProject,
    proot: ProotManager
): EditorIndexingSession {
    val projectPath = project.dir.absolutePath
    val indexMonitor = remember(projectPath) { ProjectIndexMonitor(project.dir) }
    val indexState by indexMonitor.state.collectAsState()
    val environmentIndexMonitor = remember(projectPath, proot) {
        PythonEnvironmentIndexMonitor(
            projectRoot = project.dir,
            guestProjectRoot = guestProjectPath(project),
            pythonCommandProvider = { projectPythonBin(project.dir) },
            venvNameProvider = { projectVenvName(project.dir) },
            proot = proot
        )
    }
    val environmentIndexState by environmentIndexMonitor.state.collectAsState()
    val showIndexChip = remember(projectPath) { mutableStateOf(true) }

    LaunchedEffect(indexState.status, indexState.lastCompletedAt) {
        when (indexState.status) {
            ProjectIndexMonitor.Status.IDLE,
            ProjectIndexMonitor.Status.INDEXING -> showIndexChip.value = true
            ProjectIndexMonitor.Status.READY -> {
                showIndexChip.value = true
                delay(850L)
                showIndexChip.value = false
            }
            ProjectIndexMonitor.Status.ERROR -> {
                showIndexChip.value = true
                delay(2200L)
                showIndexChip.value = false
            }
        }
    }

    DisposableEffect(indexMonitor, environmentIndexMonitor) {
        indexMonitor.start()
        environmentIndexMonitor.start()
        onDispose {
            indexMonitor.close()
            environmentIndexMonitor.close()
        }
    }

    return EditorIndexingSession(
        indexMonitor = indexMonitor,
        indexState = indexState,
        environmentIndexMonitor = environmentIndexMonitor,
        environmentIndexState = environmentIndexState,
        showIndexChip = showIndexChip
    )
}
