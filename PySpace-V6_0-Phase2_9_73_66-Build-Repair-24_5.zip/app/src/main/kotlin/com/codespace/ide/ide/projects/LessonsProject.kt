package com.codespace.ide.ide.projects

import java.io.File

internal fun ensureLessonsProject(workspace: File): PyProject {
    val dir = File(workspace, "Lessons")
    try {
        dir.mkdirs()
    } catch (_: Exception) {
    }
    return PyProject("Lessons", dir)
}
