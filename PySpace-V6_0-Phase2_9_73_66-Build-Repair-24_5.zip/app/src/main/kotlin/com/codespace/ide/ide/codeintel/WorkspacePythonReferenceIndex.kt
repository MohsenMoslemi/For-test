package com.codespace.ide.ide.codeintel

import java.io.File
import java.util.concurrent.ConcurrentHashMap
import com.codespace.ide.memory.MemoryTrimRegistry
import com.codespace.ide.memory.MemoryTrimmable

/**
 * Project-local, disk-backed reference index used as an independent supplement
 * to LSP/Jedi. It tokenizes Python source (comments and string literals are
 * excluded), resolves explicit import bindings to project modules, and indexes
 * identifier offsets without loading every source into the LSP process.
 *
 * This deliberately fails closed for files with a competing local binding of
 * the imported name. Dynamic imports, getattr/eval and runtime monkey-patching
 * cannot be resolved statically and remain the language server's responsibility.
 */
internal object WorkspacePythonReferenceIndex : MemoryTrimmable {
    data class Hit(val file: File, val offset: Int, val line: Int, val column: Int, val snippet: String)
    data class Result(
        val hits: List<Hit>,
        val filesScanned: Int,
        val filesSkipped: Int,
        val complete: Boolean = true,
        val reason: String? = null,
        val filesReused: Int = 0,
    )

    private data class Token(val text: String, val start: Int, val end: Int, val line: Int, val column: Int)
    private data class ImportBinding(val module: String, val imported: String?, val local: String, val line: Int, val column: Int, val aliasLine: Int?, val aliasColumn: Int?, val statementStartLine: Int, val statementEndLine: Int)
    private data class SourceFile(
        val file: File, val module: String, val text: String,
        val imports: List<ImportBinding>, val tokens: List<Token>,
        val modified: String, val length: Long, val fromOpenDocument: Boolean,
    )
    private data class ProjectCache(val sources: Map<String, SourceFile>, val touchedAt: Long)
    private val projectCaches = ConcurrentHashMap<String, ProjectCache>()
    private const val MAX_PROJECT_FILES = 5000
    private const val MAX_SOURCE_FILE_BYTES = 512L * 1024L
    private const val MAX_CACHED_SOURCE_BYTES = 12L * 1024L * 1024L
    private const val MAX_CACHED_PROJECTS = 2

    init { MemoryTrimRegistry.register(this) }

    suspend fun findReferences(
        root: File,
        definingFile: File,
        symbol: String,
        openDocuments: Map<File, String>,
        onProgress: suspend (Int, Int) -> Unit = { _, _ -> },
        checkCancelled: () -> Unit = {}
    ): Result {
        val canonicalRoot = root.canonicalFile
        val definition = definingFile.canonicalFile
        val open = openDocuments.entries.mapNotNull { (f, s) -> runCatching { f.canonicalFile to s }.getOrNull() }.toMap()
        val excluded = setOf(
            ".git", ".venv", "venv", "env", "__pycache__", "node_modules", "build", "dist",
            ".tox", ".mypy_cache", ".pytest_cache", ".ruff_cache", "site-packages",
            ".pyspace-refactor-transactions", ".gradle", ".idea"
        )
        val files = ArrayList<File>()
        val stack = java.util.ArrayDeque<File>()
        val visitedDirectories = HashSet<String>()
        stack.add(canonicalRoot)
        var traversalComplete = true
        while (stack.isNotEmpty()) {
            checkCancelled()
            val dir = stack.removeLast()
            val canonicalDir = runCatching { dir.canonicalFile }.getOrNull() ?: continue
            if (!canonicalDir.path.startsWith(canonicalRoot.path + File.separator) && canonicalDir != canonicalRoot) continue
            if (!visitedDirectories.add(canonicalDir.path)) continue
            val listedChildren = canonicalDir.listFiles()
            if (listedChildren == null) {
                if (canonicalDir.exists() && canonicalDir.isDirectory) traversalComplete = false
                if (!traversalComplete) break
                continue
            }
            val children = listedChildren.sortedBy { it.name }
            children.forEach { child ->
                checkCancelled()
                if (java.nio.file.Files.isSymbolicLink(child.toPath())) return@forEach
                if (child.isDirectory) {
                    if (child.name !in excluded && !child.name.startsWith(".")) stack.add(child)
                } else if (child.isFile && (child.extension.equals("py", true) || child.extension.equals("pyi", true))) {
                    if (files.size >= MAX_PROJECT_FILES) {
                        traversalComplete = false
                    } else files.add(child)
                }
            }
            if (!traversalComplete) break
        }
        if (!traversalComplete) {
            return Result(emptyList(), 0, 0, complete = false,
                reason = "Project contains more than $MAX_PROJECT_FILES Python files; reference indexing was stopped to avoid incomplete rename results.")
        }

        val cacheKey = canonicalRoot.absolutePath
        val previous = projectCaches[cacheKey]?.sources.orEmpty()
        val refreshed = LinkedHashMap<String, SourceFile>(files.size)
        val indexed = ArrayList<SourceFile>(files.size)
        var skipped = 0
        var reused = 0
        var retainedBytes = 0L
        files.forEachIndexed { index, f ->
            checkCancelled()
            val canonical = runCatching { f.canonicalFile }.getOrNull()
            if (canonical == null || (!canonical.path.startsWith(canonicalRoot.path + File.separator) && canonical != canonicalRoot)) {
                skipped++; return@forEachIndexed
            }
            val module = moduleName(canonicalRoot, canonical) ?: run { skipped++; return@forEachIndexed }
            val openText = open[canonical]
            val modified = runCatching { java.nio.file.Files.getLastModifiedTime(canonical.toPath()).toString() }.getOrDefault(canonical.lastModified().toString())
            val length = runCatching { canonical.length() }.getOrDefault(-1L)
            if (length < 0L || length > MAX_SOURCE_FILE_BYTES) {
                skipped++
                return@forEachIndexed
            }
            val cached = previous[canonical.path]
            val canReuseDisk = openText == null && cached != null && !cached.fromOpenDocument &&
                cached.modified == modified && cached.length == length
            val canReuseOpen = openText != null && cached != null && cached.text == openText
            val source = if (canReuseDisk || canReuseOpen) {
                reused++
                cached!!
            } else {
                val text = openText ?: runCatching { canonical.readText(Charsets.UTF_8) }.getOrNull()
                    ?: run { skipped++; return@forEachIndexed }
                if (text.toByteArray(Charsets.UTF_8).size.toLong() > MAX_SOURCE_FILE_BYTES) {
                    skipped++
                    return@forEachIndexed
                }
                SourceFile(
                    file = canonical,
                    module = module,
                    text = text,
                    imports = parseImports(text, module, canonical.name == "__init__.py"),
                    tokens = tokenize(text),
                    modified = modified,
                    length = length,
                    fromOpenDocument = openText != null,
                )
            }
            retainedBytes += source.text.length.toLong() * 2L
            if (retainedBytes > MAX_CACHED_SOURCE_BYTES) {
                return Result(emptyList(), indexed.size, skipped, complete = false,
                    reason = "Python source index exceeds the safe in-memory limit; no partial reference results were returned.", filesReused = reused)
            }
            refreshed[canonical.path] = source
            indexed += source
            if (index % 32 == 0 || index == files.lastIndex) onProgress(index + 1, files.size * 2)
        }
        synchronized(projectCaches) {
            projectCaches[cacheKey] = ProjectCache(refreshed, System.currentTimeMillis())
            if (projectCaches.size > MAX_CACHED_PROJECTS) {
                projectCaches.entries.sortedBy { it.value.touchedAt }
                    .take(projectCaches.size - MAX_CACHED_PROJECTS)
                    .forEach { projectCaches.remove(it.key) }
            }
        }
        val definitionModule = indexed.firstOrNull { it.file == definition }?.module
            ?: moduleName(canonicalRoot, definition)
            ?: return Result(
                emptyList(), indexed.size, skipped, complete = false,
                reason = "The selected definition could not be mapped to a project Python module. No complete reference set is available.",
                filesReused = reused,
            )
        val targetModules = resolveImporters(indexed, definitionModule, symbol, canonicalRoot.name)
        val hits = LinkedHashMap<String, Hit>()
        indexed.forEachIndexed { sourceIndex, source ->
            checkCancelled()
            val isDefinitionFile = source.file == definition
            // The defining module's same-spelling locals are not safe to infer
            // from token identity alone; pylsp supplies scoped references there.
            if (isDefinitionFile) return@forEachIndexed
            val bindings = source.imports.filter { binding ->
                binding.imported == symbol && moduleAliases(binding.module, canonicalRoot.name).any(targetModules::contains)
            }
            if (bindings.isEmpty()) return@forEachIndexed
            val directBindings = bindings.filter { it.local == symbol }
            val text = source.text
            val lines = text.split('\n')
            val competing = directBindings.isNotEmpty() && hasCompetingBinding(source.tokens, symbol, true, source.imports)
            val importPositions = HashSet<Pair<Int, Int>>()
            bindings.forEach { binding ->
                importPositions += binding.line to binding.column
                if (binding.local == symbol && binding.aliasLine != null && binding.aliasColumn != null) {
                    importPositions += binding.aliasLine to binding.aliasColumn
                }
            }
            val importStatementLines = bindings.flatMapTo(HashSet()) { it.statementStartLine..it.statementEndLine }
            val tokens = source.tokens
            tokens.asSequence().filterIndexed { tokenIndex, token ->
                if (token.text != symbol) return@filterIndexed false
                // Always include the imported spelling itself, including
                // `from module import old_name as local_alias`; the alias and
                // its subsequent uses must remain untouched.
                val isImportName = (token.line to token.column) in importPositions
                // Do not mistake the module path or an alias on the same import
                // statement for a use of the imported symbol.
                if (token.line in importStatementLines) return@filterIndexed isImportName
                // An attribute such as obj.old_name is a different symbol.
                // Also fail closed for files containing a competing local
                // binding, since a lightweight index cannot prove its scope.
                directBindings.isNotEmpty() && !competing &&
                    !isMemberAttribute(text, token.start) && !isKeywordArgumentLabel(tokens, tokenIndex)
            }.forEach { token ->
                val lineText = lines.getOrNull(token.line).orEmpty().trim()
                val hit = Hit(source.file, token.start, token.line + 1, token.column, lineText)
                hits["${source.file.path}:${token.start}"] = hit
            }
            if (sourceIndex % 32 == 0 || sourceIndex == indexed.lastIndex) {
                onProgress(files.size + sourceIndex + 1, files.size * 2)
            }
        }
        val complete = skipped == 0
        return Result(
            hits.values.sortedWith(compareBy<Hit> { it.file.path }.thenBy { it.offset }),
            indexed.size, skipped, complete = complete,
            reason = if (complete) null else "$skipped Python file(s) could not be indexed safely; results may be incomplete.",
            filesReused = reused
        )
    }

    data class RefreshResult(
        val filesIndexed: Int,
        val filesReused: Int,
        val filesSkipped: Int,
        val complete: Boolean,
        val reason: String? = null,
    )

    /**
     * Warm and incrementally refresh the same source cache consumed by
     * Find References and Rename. This is intentionally independent of a
     * selected symbol, so opening a project can prepare the workspace index.
     */
    suspend fun refreshWorkspace(
        root: File,
        onProgress: suspend (processed: Int, total: Int, currentFile: String) -> Unit = { _, _, _ -> },
        checkCancelled: () -> Unit = {}
    ): RefreshResult {
        val canonicalRoot = runCatching { root.canonicalFile }.getOrElse { root.absoluteFile }
        val excluded = setOf(
            ".git", ".venv", "venv", "env", "__pycache__", "node_modules", "build", "dist",
            ".tox", ".mypy_cache", ".pytest_cache", ".ruff_cache", "site-packages",
            ".pyspace-refactor-transactions", ".gradle", ".idea"
        )
        val files = ArrayList<File>()
        val stack = java.util.ArrayDeque<File>()
        val visited = HashSet<String>()
        stack.add(canonicalRoot)
        while (stack.isNotEmpty()) {
            checkCancelled()
            val dir = stack.removeLast()
            val canonical = runCatching { dir.canonicalFile }.getOrNull() ?: continue
            if (!canonical.path.startsWith(canonicalRoot.path + File.separator) && canonical != canonicalRoot) continue
            if (!visited.add(canonical.path)) continue
            val children = canonical.listFiles() ?: if (canonical.exists() && canonical.isDirectory) {
                return RefreshResult(0, 0, 0, false, "Unable to read directory: ${canonical.name}")
            } else continue
            children.forEach { child ->
                checkCancelled()
                if (java.nio.file.Files.isSymbolicLink(child.toPath())) return@forEach
                if (child.isDirectory && child.name !in excluded && !child.name.startsWith(".")) stack.add(child)
                else if (child.isFile && (child.extension.equals("py", true) || child.extension.equals("pyi", true))) {
                    if (files.size >= MAX_PROJECT_FILES) return RefreshResult(0, 0, 0, false, "Project exceeds the $MAX_PROJECT_FILES Python-file indexing limit.")
                    files.add(child)
                }
            }
        }
        val cacheKey = canonicalRoot.absolutePath
        val previous = projectCaches[cacheKey]?.sources.orEmpty()
        val refreshed = LinkedHashMap<String, SourceFile>(files.size)
        var reused = 0
        var skipped = 0
        var retainedBytes = 0L
        files.forEachIndexed { index, file ->
            checkCancelled()
            val canonical = runCatching { file.canonicalFile }.getOrNull()
            if (canonical == null || (!canonical.path.startsWith(canonicalRoot.path + File.separator) && canonical != canonicalRoot)) {
                skipped++; return@forEachIndexed
            }
            val module = moduleName(canonicalRoot, canonical) ?: run { skipped++; return@forEachIndexed }
            val modified = runCatching { java.nio.file.Files.getLastModifiedTime(canonical.toPath()).toString() }.getOrDefault(canonical.lastModified().toString())
            val length = runCatching { canonical.length() }.getOrDefault(-1L)
            if (length < 0L || length > MAX_SOURCE_FILE_BYTES) { skipped++; return@forEachIndexed }
            val cached = previous[canonical.path]
            val source = if (cached != null && !cached.fromOpenDocument && cached.modified == modified && cached.length == length) {
                reused++
                cached
            } else {
                val text = runCatching { canonical.readText(Charsets.UTF_8) }.getOrNull() ?: run { skipped++; return@forEachIndexed }
                if (text.toByteArray(Charsets.UTF_8).size.toLong() > MAX_SOURCE_FILE_BYTES) { skipped++; return@forEachIndexed }
                SourceFile(canonical, module, text, parseImports(text, module, canonical.name == "__init__.py"), tokenize(text), modified, length, false)
            }
            retainedBytes += source.text.length.toLong() * 2L
            if (retainedBytes > MAX_CACHED_SOURCE_BYTES) {
                return RefreshResult(refreshed.size, reused, skipped, false, "Python source index exceeds the safe in-memory limit.")
            }
            refreshed[canonical.path] = source
            if (index % 8 == 0 || index == files.lastIndex) onProgress(index + 1, files.size, canonical.name)
        }
        synchronized(projectCaches) {
            projectCaches[cacheKey] = ProjectCache(refreshed, System.currentTimeMillis())
            if (projectCaches.size > MAX_CACHED_PROJECTS) {
                projectCaches.entries.sortedBy { it.value.touchedAt }.take(projectCaches.size - MAX_CACHED_PROJECTS)
                    .forEach { projectCaches.remove(it.key) }
            }
        }
        return RefreshResult(refreshed.size, reused, skipped, skipped == 0,
            if (skipped == 0) null else "$skipped Python file(s) could not be indexed safely.")
    }

    /** Drop cached source snapshots for a project after explicit project mutations. */
    fun invalidate(root: File?) {
        if (root == null) return
        val key = runCatching { root.canonicalPath }.getOrDefault(root.absolutePath)
        projectCaches.remove(key)
    }

    override fun trimToPolicy() {
        synchronized(projectCaches) {
            projectCaches.entries.sortedByDescending { it.value.touchedAt }
                .drop(1).forEach { projectCaches.remove(it.key) }
        }
    }

    override fun clearTemporaryCaches() {
        projectCaches.clear()
    }

    private fun resolveImporters(files: List<SourceFile>, definitionModule: String, symbol: String, rootPackageName: String): Set<String> {
        // Follow explicit re-exports to a fixed point. `from .impl import f` in
        // package/__init__.py makes the package itself a valid import target.
        val reverseEdges = HashMap<String, MutableList<String>>()
        files.forEach { file ->
            // Only an import that preserves the original public name is a
            // re-export edge. `from impl import f as local_f` must not make
            // this module appear to export `f` under its old spelling.
            file.imports.asSequence().filter { it.imported == symbol && it.local == symbol }
                .forEach { binding ->
                    val importerAliases = moduleAliases(file.module, rootPackageName)
                    moduleAliases(binding.module, rootPackageName).forEach { targetAlias ->
                        reverseEdges.getOrPut(targetAlias) { ArrayList() }.addAll(importerAliases)
                    }
                }
        }
        val reachable = LinkedHashSet<String>()
        val queue = java.util.ArrayDeque<String>()
        moduleAliases(definitionModule, rootPackageName).forEach { alias ->
            reachable += alias
            queue.add(alias)
        }
        while (queue.isNotEmpty()) {
            val module = queue.removeFirst()
            reverseEdges[module].orEmpty().forEach { importer ->
                if (reachable.add(importer)) queue.add(importer)
            }
        }
        return reachable
    }

    /**
     * A project can be opened at either its package directory or its parent.
     * Treat the root directory name as an optional namespace-package prefix so
     * `from project_pkg.core import item` and `from core import item` resolve to
     * the same project-local module without assuming one sys.path layout.
     */
    private fun moduleAliases(module: String, rootPackageName: String): Set<String> {
        val normalized = module.trim().trim('.')
        if (normalized.isBlank()) return emptySet()
        val aliases = linkedSetOf(normalized)
        val prefix = "$rootPackageName."
        if (normalized.startsWith(prefix)) aliases += normalized.removePrefix(prefix)
        else if (rootPackageName.matches(Regex("[A-Za-z_][A-Za-z0-9_]*"))) aliases += "$prefix$normalized"
        return aliases
    }

    private fun moduleName(root: File, file: File): String? {
        val rel = runCatching { file.relativeTo(root).path }.getOrNull() ?: return null
        val withoutExt = rel.removeSuffix(".${file.extension}")
        val parts = withoutExt.split(File.separatorChar).filter { it.isNotBlank() }
        if (parts.isEmpty() || parts.any { !it.matches(Regex("[A-Za-z_][A-Za-z0-9_]*")) }) return null
        return if (parts.last() == "__init__") parts.dropLast(1).joinToString(".") else parts.joinToString(".")
    }

    private fun parseImports(source: String, currentModule: String, isPackageInit: Boolean): List<ImportBinding> {
        val out = ArrayList<ImportBinding>()
        val lines = source.lines()
        val from = Regex("^\\s*from\\s+([.A-Za-z_][.A-Za-z0-9_]*)\\s+import\\s+([\\s\\S]+?)\\s*$", RegexOption.DOT_MATCHES_ALL)
        val plain = Regex("^\\s*import\\s+(.+?)\\s*$")
        var lineIndex = 0
        while (lineIndex < lines.size) {
            val cleaned = lines[lineIndex].substringBefore('#')
            if (Regex("^\\s*from\\s+[.A-Za-z_][.A-Za-z0-9_]*\\s+import\\b").containsMatchIn(cleaned)) {
                val statementStart = lineIndex
                val statement = StringBuilder()
                var balance = 0
                var lastLine = lineIndex
                var continued: Boolean
                do {
                    val rawPart = lines[lastLine].substringBefore('#').trimEnd()
                    continued = rawPart.endsWith("\\")
                    val part = if (continued) rawPart.dropLast(1) else rawPart
                    if (statement.isNotEmpty()) statement.append('\n')
                    statement.append(part)
                    balance += part.count { it == '(' } - part.count { it == ')' }
                    lastLine++
                } while (lastLine < lines.size && (balance > 0 || continued))
                val fullStatement = statement.toString()
                from.matchEntire(fullStatement)?.let { match ->
                    val rawModule = match.groupValues[1]
                    val module = resolveRelativeModule(rawModule, currentModule, isPackageInit).trimStart('.')
                    val rawNames = match.groupValues[2]
                    val names = rawNames.removeSurrounding("(", ")")
                    val rawNamesStart = match.groups[2]?.range?.first ?: fullStatement.length
                    val namesStart = fullStatement.indexOf(names, rawNamesStart).takeIf { it >= 0 } ?: rawNamesStart
                    var cursor = 0
                    names.split(',').forEach { item ->
                        val leading = item.indexOfFirst { !it.isWhitespace() }.let { if (it < 0) item.length else it }
                        val itemStart = namesStart + cursor + leading
                        val trimmedItem = item.trim()
                        val pieces = trimmedItem.split(Regex("\\s+as\\s+"))
                        val imported = pieces.firstOrNull()?.trim()?.takeIf { it.matches(Regex("[A-Za-z_][A-Za-z0-9_]*")) }
                        if (imported != null) {
                            val alias = pieces.getOrNull(1)?.trim()?.takeIf { it.matches(Regex("[A-Za-z_][A-Za-z0-9_]*")) }
                            val local = alias ?: imported
                            val importedOffset = (itemStart + trimmedItem.indexOf(imported)).coerceIn(0, fullStatement.length)
                            fun lineColumn(offset: Int): Pair<Int, Int> {
                                val safeOffset = offset.coerceIn(0, fullStatement.length)
                                val line = statementStart + fullStatement.substring(0, safeOffset).count { it == '\n' }
                                val previousNewline = fullStatement.lastIndexOf('\n', (safeOffset - 1).coerceAtLeast(0))
                                return line to (safeOffset - previousNewline - 1)
                            }
                            val (itemLine, itemColumn) = lineColumn(importedOffset)
                            val aliasPosition = alias?.let { aliasName ->
                                lineColumn((itemStart + trimmedItem.lastIndexOf(aliasName)).coerceIn(0, fullStatement.length))
                            }
                            out += ImportBinding(module, imported, local, itemLine, itemColumn,
                                aliasPosition?.first, aliasPosition?.second, statementStart, lastLine - 1)
                        }
                        cursor += item.length + 1
                    }
                }
                lineIndex = lastLine
                continue
            }
            plain.matchEntire(cleaned.trim())?.let { match ->
                match.groupValues[1].split(',').forEach { item ->
                    val pieces = item.trim().split(Regex("\\s+as\\s+"))
                    val module = pieces.firstOrNull()?.trim()?.substringBefore('.') ?: return@forEach
                    val alias = pieces.getOrNull(1)?.trim() ?: module
                    if (module.matches(Regex("[A-Za-z_][A-Za-z0-9_]*"))) out += ImportBinding(module, null, alias, lineIndex, 0, null, null, lineIndex, lineIndex)
                }
            }
            lineIndex++
        }
        return out
    }

    private fun resolveRelativeModule(raw: String, currentModule: String, isPackageInit: Boolean): String {
        val level = raw.takeWhile { it == '.' }.length
        if (level == 0) return raw
        val packageName = if (isPackageInit) currentModule else currentModule.substringBeforeLast('.', "")
        val baseParts = packageName.split('.').filter { it.isNotBlank() }.toMutableList()
        repeat((level - 1).coerceAtMost(baseParts.size)) { if (baseParts.isNotEmpty()) baseParts.removeAt(baseParts.lastIndex) }
        val suffix = raw.drop(level)
        if (suffix.isNotBlank()) baseParts += suffix.split('.').filter { it.isNotBlank() }
        return baseParts.joinToString(".")
    }

    /** Source offsets of real code identifiers; comments and string literals are excluded. */
    internal fun identifierOffsets(source: String, name: String): Set<Int> =
        tokenize(source).asSequence().filter { it.text == name }.map { it.start }.toHashSet()

    /** True when the identifier is used as an attribute/member after a dot. */
    private fun isMemberAttribute(source: String, offset: Int): Boolean {
        var index = offset - 1
        while (index >= 0 && source[index].isWhitespace()) index--
        return index >= 0 && source[index] == '.'
    }

    private fun hasCompetingBinding(
        tokens: List<Token>,
        name: String,
        imported: Boolean,
        imports: List<ImportBinding>
    ): Boolean {
        if (!imported) return false
        val validAliasPositions = imports.asSequence()
            .filter { it.local == name && it.aliasLine != null && it.aliasColumn != null }
            .map { it.aliasLine!! to it.aliasColumn!! }.toHashSet()
        for (i in tokens.indices) {
            if (tokens[i].text != name) continue
            if ((tokens[i].line to tokens[i].column) in validAliasPositions) continue
            val prev = tokens.getOrNull(i - 1)?.text
            val next = tokens.getOrNull(i + 1)?.text
            if (prev in setOf("def", "class", "for", "as", "except", "with", "global", "nonlocal")) return true
            if (next in setOf("=", ":=", ":")) {
                // `call(name=value)` is a keyword label, not a local binding;
                // a parameter with a default value inside `def f(name=...)` is.
                if (next == "=" && isKeywordArgumentLabel(tokens, i)) continue
                return true
            }
            if (next == "+" && tokens.getOrNull(i + 2)?.text == "=") return true
            // A same-named function parameter shadows the imported binding.
            // Walk to the matching parameter-list opener rather than staying on
            // the current line; Python permits multi-line function signatures.
            if ((prev == "(" || prev == ",") && isFunctionParameter(tokens, i)) return true
        }
        return false
    }

    private fun isKeywordArgumentLabel(tokens: List<Token>, identifierIndex: Int): Boolean {
        if (tokens.getOrNull(identifierIndex + 1)?.text != "=" ||
            tokens.getOrNull(identifierIndex - 1)?.text !in setOf("(", ",")) return false
        var nestedClosing = 0
        var index = identifierIndex - 1
        while (index >= 0) {
            when (tokens[index].text) {
                ")" -> nestedClosing++
                "(" -> {
                    if (nestedClosing > 0) nestedClosing-- else {
                        val beforeOpen = tokens.getOrNull(index - 1)?.text
                        val beforeName = tokens.getOrNull(index - 2)?.text
                        val looksLikeCallable = beforeOpen?.let {
                            it.matches(Regex("[A-Za-z_][A-Za-z0-9_]*")) || it in setOf(")", "]", "}")
                        } == true
                        return looksLikeCallable && beforeName !in setOf("def", "class")
                    }
                }
                ";" -> if (nestedClosing == 0) return false
            }
            index--
        }
        return false
    }

    private fun isFunctionParameter(tokens: List<Token>, identifierIndex: Int): Boolean {
        var nestedClosing = 0
        var index = identifierIndex - 1
        while (index >= 0) {
            when (tokens[index].text) {
                ")" -> nestedClosing++
                "(" -> {
                    if (nestedClosing > 0) nestedClosing-- else {
                        val beforeOpen = tokens.getOrNull(index - 1)?.text
                        val beforeName = tokens.getOrNull(index - 2)?.text
                        return beforeName == "def" || (beforeOpen == "def" && beforeName == "async")
                    }
                }
                ";", "=" -> if (nestedClosing == 0) return false
            }
            index--
        }
        return false
    }

    /** Lightweight Python lexer: identifiers are emitted only in code, not comments or quoted strings. */
    private fun tokenize(s: String): List<Token> {
        val out = ArrayList<Token>()
        var i = 0; var line = 0; var col = 0
        var quote = '\u0000'; var triple = false; var escaped = false; var comment = false
        while (i < s.length) {
            val c = s[i]
            if (comment) { if (c == '\n') { comment = false; line++; col = 0 } else col++; i++; continue }
            if (quote != '\u0000') {
                if (escaped) escaped = false
                else if (c == '\\') escaped = true
                else if (triple && i + 2 < s.length && s[i] == quote && s[i + 1] == quote && s[i + 2] == quote) { i += 3; col += 3; quote = '\u0000'; triple = false; continue }
                else if (!triple && c == quote) quote = '\u0000'
                if (c == '\n') { line++; col = 0 } else col++
                i++; continue
            }
            if (c == '#') { comment = true; i++; col++; continue }
            if (c == '\'' || c == '"') {
                quote = c; triple = i + 2 < s.length && s[i + 1] == c && s[i + 2] == c
                val n = if (triple) 3 else 1; i += n; col += n; continue
            }
            if (c == '_' || c.isLetter()) {
                val start = i; val startCol = col
                while (i < s.length && (s[i] == '_' || s[i].isLetterOrDigit())) { i++; col++ }
                val identifier = s.substring(start, i)
                val isStringPrefix = identifier.lowercase() in setOf("r", "u", "b", "f", "br", "rb", "fr", "rf") &&
                    i < s.length && (s[i] == '\'' || s[i] == '\"')
                if (isStringPrefix) {
                    val quoteChar = s[i]
                    quote = quoteChar
                    triple = i + 2 < s.length && s[i + 1] == quoteChar && s[i + 2] == quoteChar
                    val count = if (triple) 3 else 1
                    i += count
                    col += count
                } else {
                    out += Token(identifier, start, i, line, startCol)
                }
                continue
            }
            // Keep punctuation as tokens as well. The binding analyzer relies
            // on real delimiters/operators to recognize assignments, parameter
            // lists, member access, and keyword labels. Previously these checks
            // were ineffective because the lexer silently discarded punctuation.
            if (!c.isWhitespace()) out += Token(c.toString(), i, i + 1, line, col)
            if (c == '\n') { line++; col = 0 } else col++
            i++
        }
        return out
    }
}
