package com.codespace.ide.domain.browser

/** Pure URL-entry normalization; WebView navigation remains in the browser adapter. */
object BrowserUrlPolicy {
    fun normalize(raw: String): String {
        val value = raw.trim()
        if (value.isEmpty()) return "about:blank"
        if (value.contains("://") || value.startsWith("about:") ||
            value.startsWith("data:") || value.startsWith("file:")) return value
        return "http://$value"
    }
}
