package com.codespace.ide.domain.editor.model

/** Immutable editor-session data safe to pass across dispatcher boundaries. */
data class EditorTabSessionSnapshot(
    val path: String,
    val scrollY: Int,
    val scrollX: Int,
    val selectionStart: Int,
    val selectionEnd: Int,
    val hasView: Boolean,
)

data class EditorSessionSnapshot(
    val activeIndex: Int,
    val tabs: List<EditorTabSessionSnapshot>,
)
