package com.codespace.ide.ide.editor

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.withFrameNanos
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Coordinates the visual-to-layout hand-off after a pinch gesture.
 *
 * The editor remains the owner of all Compose state. This workflow only
 * sequences the settle animation, font commit, scroll compensation and the
 * bounded recovery path if the corresponding layout effect never arrives.
 */
internal fun launchEditorZoomCommit(
    scope: CoroutineScope,
    anchor: ZoomAnchor,
    verticalScroll: ScrollState,
    horizontalScroll: ScrollState,
    startFont: Float,
    targetFont: Float,
    currentScaleY: Float,
    currentScaleX: Float,
    fontMetricsFor: (Float) -> FloatArray,
    currentGutterPx: () -> Float,
    gutterPxForFont: (Float) -> Float,
    textPaddingPx: Float,
    wordWrap: Boolean,
    onFontSizeChange: (Float) -> Unit,
    pinchScaleY: MutableState<Float>,
    pinchScaleX: MutableState<Float>,
    pinchTargetFont: MutableState<Float>,
    pinchGestureActive: MutableState<Boolean>,
    zoomCommitInProgress: MutableState<Boolean>,
    commitShiftX: MutableState<Float>,
    commitShiftY: MutableState<Float>
): Job {
    anchor.job?.cancel()
    anchor.settling = true
    val job = scope.launch {
        try {
            val ratio = EditorZoomGeometry.scaleRatio(
                startMetrics = fontMetricsFor(startFont),
                targetMetrics = fontMetricsFor(targetFont)
            )
            if (kotlin.math.abs(ratio.vertical - currentScaleY) > 0.0005f ||
                kotlin.math.abs(ratio.horizontal - currentScaleX) > 0.0005f
            ) {
                var frameStart = -1L
                while (true) {
                    val now = withFrameNanos { it }
                    if (frameStart < 0L) frameStart = now
                    val progress = ((now - frameStart) / 90_000_000f).coerceIn(0f, 1f)
                    pinchScaleY.value = EditorZoomGeometry.easedScale(currentScaleY, ratio.vertical, progress)
                    pinchScaleX.value = EditorZoomGeometry.easedScale(currentScaleX, ratio.horizontal, progress)
                    if (progress >= 1f) break
                }
            }

            val startY = verticalScroll.value.toFloat()
            val startX = horizontalScroll.value.toFloat()
            val targets = EditorZoomGeometry.committedScrollTarget(
                currentX = startX,
                currentY = startY,
                oldGutterPx = currentGutterPx(),
                newGutterPx = gutterPxForFont(targetFont),
                textPaddingPx = textPaddingPx,
                ratio = ratio,
                wordWrap = wordWrap
            )
            anchor.targetX = targets.x
            anchor.targetY = targets.y
            anchor.token += 1
            anchor.pending = true
            commitShiftY.value = startY - targets.y
            commitShiftX.value = startX - targets.x
            zoomCommitInProgress.value = true
            onFontSizeChange(targetFont)
            pinchScaleY.value = 1f
            pinchScaleX.value = 1f
            pinchTargetFont.value = 0f
            pinchGestureActive.value = false

            // If the font/layout effect does not arrive, do not leave the
            // compensation layer or hidden selection handles stuck forever.
            val commitToken = anchor.token
            scope.launch {
                delay(700)
                if (anchor.token == commitToken &&
                    (anchor.pending || zoomCommitInProgress.value ||
                        commitShiftX.value != 0f || commitShiftY.value != 0f)
                ) {
                    anchor.pending = false
                    commitShiftX.value = 0f
                    commitShiftY.value = 0f
                    zoomCommitInProgress.value = false
                }
            }
        } finally {
            anchor.settling = false
        }
    }
    anchor.job = job
    return job
}
