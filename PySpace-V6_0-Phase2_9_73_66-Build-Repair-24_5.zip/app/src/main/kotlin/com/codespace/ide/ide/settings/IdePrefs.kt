package com.codespace.ide.ide.settings

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import com.codespace.ide.ide.EditorFontCatalog
import com.codespace.ide.ide.EditorSymbolCatalog
import com.codespace.ide.ide.PythonRuntimeCatalog
import com.codespace.ide.ide.theme.IdeTheme

/** Editor/user settings, persisted in SharedPreferences. */
class IdePrefs(context: Context) {
    private val sp = context.getSharedPreferences("pyspace_ide", Context.MODE_PRIVATE)

    /** Selected native IDE color theme. */
    var themeId: String
        get() = IdeTheme.normalizeThemeId(sp.getString("ide_theme", IdeTheme.DARK))
        set(value) = sp.edit().putString("ide_theme", IdeTheme.normalizeThemeId(value)).apply()

    /** Selected runtime for the standalone interactive Python interpreter. */
    var interpreterPythonVersionId: String
    get() = sp.getString("interpreter_python_version", PythonRuntimeCatalog.DEFAULT_ID)
        ?.takeIf { PythonRuntimeCatalog.find(it) != null } ?: PythonRuntimeCatalog.DEFAULT_ID
    set(v) = sp.edit().putString("interpreter_python_version", v.takeIf { PythonRuntimeCatalog.find(it) != null } ?: PythonRuntimeCatalog.DEFAULT_ID).apply()

    var codeFontSize: Float
    get() = sp.getFloat("code_font", 13f).coerceIn(9f, 24f)
    set(v) = sp.edit().putFloat("code_font", v.coerceIn(9f, 24f)).apply()
    /** User-defined order for the Python extra-key bar; the first four entries stay pinned. */
    var editorSymbolOrder: List<String>
        get() = com.codespace.ide.ide.EditorSymbolCatalog.decode(
            sp.getString("editor_symbol_order", null)
        )
        set(value) = sp.edit().putString(
            "editor_symbol_order",
            com.codespace.ide.ide.EditorSymbolCatalog.encode(value)
        ).apply()
    /** Selected bundled source-editor typeface; unrelated app text keeps its default family. */
    var editorFontFamilyId: String
        get() = com.codespace.ide.ide.EditorFontCatalog.normalizeId(sp.getString("editor_font_family", com.codespace.ide.ide.EditorFontCatalog.DEFAULT_ID))
        set(v) = sp.edit().putString("editor_font_family", com.codespace.ide.ide.EditorFontCatalog.normalizeId(v)).apply()
    var tabWidth: Int
    get() = sp.getInt("tab_width", 4).coerceIn(2, 8)
    set(v) = sp.edit().putInt("tab_width", v.coerceIn(2, 8)).apply()
    var autoIndent: Boolean
    get() = sp.getBoolean("auto_indent", true)
    set(v) = sp.edit().putBoolean("auto_indent", v).apply()
    /** Where a web page opens: "ask" | "ide" (built-in browser) | "phone" (the phone's browser). */
    var webOpenMode: String
    get() = sp.getString("web_open_mode", "ask") ?: "ask"
    set(v) = sp.edit().putString("web_open_mode", v).apply()
    var lineNumbers: Boolean
    get() = sp.getBoolean("line_numbers", true)
    set(v) = sp.edit().putBoolean("line_numbers", v).apply()
    var wordWrap: Boolean
    get() = sp.getBoolean("word_wrap", false)
    set(v) = sp.edit().putBoolean("word_wrap", v).apply()
    /** Editor popup visibility preferences; enabled by default for existing users. */
    var showDiagnosticPopup: Boolean
    get() = sp.getBoolean("show_diagnostic_popup", true)
    set(v) = sp.edit().putBoolean("show_diagnostic_popup", v).apply()
    var showCompletionPopup: Boolean
    get() = sp.getBoolean("show_completion_popup", true)
    set(v) = sp.edit().putBoolean("show_completion_popup", v).apply()
    var showDocumentationPopup: Boolean
    get() = sp.getBoolean("show_documentation_popup", true)
    set(v) = sp.edit().putBoolean("show_documentation_popup", v).apply()
    /** Free 2D pan: strokes along one axis also coast the other (default off). */
    /** Project the user was inside when the app last went to background. */
    var lastProject: String
    get() = try {
        sp.getString("last_project", "") ?: ""
    } catch (_: Exception) {
        ""
    }
    set(v) = sp.edit().putString("last_project", v).apply()

    /** A deliberate project exit must survive an immediate process kill. */
    fun clearLastProject() {
        try { sp.edit().putString("last_project", "").commit() } catch (_: Exception) { }
    }

    fun sessionJson(project: String): String = try {
        sp.getString("session_$project", "") ?: ""
    } catch (_: Exception) {
        ""
    }

    fun setSessionJson(project: String, json: String) {
        try {
            sp.edit().putString("session_$project", json).apply()
        } catch (_: Exception) {
        }
    }

    var pan2D: Boolean
    get() = sp.getBoolean("pan_2d", false)
    set(v) = sp.edit().putBoolean("pan_2d", v).apply()
    /** Pinch-to-zoom the code font (default on). */
    var pinchZoom: Boolean
    get() = sp.getBoolean("pinch_zoom", true)
    set(v) = sp.edit().putBoolean("pinch_zoom", v).apply()
    /** X server host (kept for compatibility; the embedded display uses :1). */
    var displayHost: String
    get() = try {
        (sp.getString("display_host", "127.0.0.1") ?: "127.0.0.1")
        .trim().take(64).ifBlank { "127.0.0.1" }
    } catch (_: Exception) {
        "127.0.0.1"
    }
    set(v) = sp.edit().putString(
        "display_host", v.trim().take(64).ifBlank { "127.0.0.1" }
    ).apply()
    /** X display number (TCP port = 6000 + this). */
    var displayNum: Int
    get() = try {
        sp.getInt("display_num", 0).coerceIn(0, 99)
    } catch (_: Exception) {
        0
    }
    set(v) = sp.edit().putInt("display_num", v.coerceIn(0, 99)).apply()
    /** GitHub token encrypted with an Android Keystore AES-256-GCM key.
     *  Migrates the legacy plaintext preference once, then removes it. */
    var githubToken: String
        get() = try {
            val encrypted = sp.getString("github_token_enc", null)
            if (!encrypted.isNullOrBlank()) {
                // Remove any legacy plaintext copy left by an interrupted migration.
                sp.edit().remove("github_token").apply()
                decryptGithubToken(encrypted)
            } else {
                val legacy = sp.getString("github_token", "") ?: ""
                if (legacy.isNotBlank()) {
                    val cipherText = encryptGithubToken(legacy)
                    if (cipherText != null) {
                        sp.edit().putString("github_token_enc", cipherText)
                            .remove("github_token").apply()
                        legacy
                    } else {
                        // Never keep a credential in plaintext if Keystore fails.
                        sp.edit().remove("github_token").apply()
                        ""
                    }
                } else ""
            }
        } catch (_: Exception) {
            ""
        }
        set(value) {
            try {
                if (value.isBlank()) {
                    sp.edit().remove("github_token_enc").remove("github_token").apply()
                } else {
                    val encrypted = encryptGithubToken(value)
                    if (encrypted != null) {
                        sp.edit().putString("github_token_enc", encrypted)
                            .remove("github_token").apply()
                    } else {
                        // Fail closed: do not persist the token unencrypted.
                        sp.edit().remove("github_token_enc").remove("github_token").apply()
                    }
                }
            } catch (_: Exception) {
                sp.edit().remove("github_token").apply()
            }
        }
    /** Optional user-supplied PAT expiration date (epoch millis, UTC midnight). */
    var githubTokenExpiresAt: Long
        get() = try { sp.getLong("github_token_expires_at", 0L) } catch (_: Exception) { 0L }
        set(value) { try { sp.edit().putLong("github_token_expires_at", value.coerceAtLeast(0L)).apply() } catch (_: Exception) {} }

    /** Last verified GitHub account login for the globally stored token. */
    var githubLogin: String
        get() = try { sp.getString("github_login", "") ?: "" } catch (_: Exception) { "" }
        set(value) { try { sp.edit().putString("github_login", value.take(100)).apply() } catch (_: Exception) {} }

    fun saveGithubAccount(token: String, login: String, expiresAt: Long): Boolean {
        return try {
            if (token.isBlank()) return false
            val encrypted = encryptGithubToken(token) ?: return false
            sp.edit()
                .putString("github_token_enc", encrypted)
                .remove("github_token")
                .putLong("github_token_expires_at", expiresAt.coerceAtLeast(0L))
                .putString("github_login", login.take(100))
                .apply()
            true
        } catch (_: Exception) { false }
    }

    fun clearGithubAccount() {
        try {
            sp.edit().remove("github_token_enc").remove("github_token")
                .remove("github_token_expires_at").remove("github_login").apply()
        } catch (_: Exception) { }
    }

    /** Last push target for a project ("owner/repo@branch", "" = none). */
    fun githubTarget(project: String): String {
        return try {
            sp.getString("gh_target_$project", "") ?: ""
        } catch (_: Exception) {
            ""
        }
    }

    fun setGithubTarget(project: String, v: String) {
        try {
            sp.edit().putString("gh_target_$project", v).apply()
        } catch (_: Exception) {
        }
    }
}


private const val GITHUB_TOKEN_KEY_ALIAS = "pyspace.github.token.v1"

/** AES/GCM key never leaves Android Keystore; ciphertext alone is stored in prefs. */
private fun githubTokenKey(): SecretKey {
    val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    val existing = store.getKey(GITHUB_TOKEN_KEY_ALIAS, null) as? SecretKey
    if (existing != null) return existing
    val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
    generator.init(
        KeyGenParameterSpec.Builder(
            GITHUB_TOKEN_KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setRandomizedEncryptionRequired(true)
            .build()
    )
    return generator.generateKey()
}

private fun encryptGithubToken(value: String): String? = try {
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, githubTokenKey())
    val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
    val packed = cipher.iv + encrypted
    Base64.encodeToString(packed, Base64.NO_WRAP)
} catch (_: Exception) {
    null
}

private fun decryptGithubToken(encoded: String): String = try {
    val packed = Base64.decode(encoded, Base64.NO_WRAP)
    if (packed.size <= 12) "" else {
        val iv = packed.copyOfRange(0, 12)
        val encrypted = packed.copyOfRange(12, packed.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, githubTokenKey(), GCMParameterSpec(128, iv))
        String(cipher.doFinal(encrypted), Charsets.UTF_8)
    }
} catch (_: Exception) {
    ""
}
