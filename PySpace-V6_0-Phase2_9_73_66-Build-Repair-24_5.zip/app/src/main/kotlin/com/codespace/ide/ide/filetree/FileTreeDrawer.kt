package com.codespace.ide.ide.filetree

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.codespace.ide.ide.codeintel.CodeIntelligenceViewModel
import com.codespace.ide.ide.codeintel.ProjectTransactionManager
import com.codespace.ide.ide.editor.EditorViewModel
import com.codespace.ide.ProotManager
import com.codespace.ide.ide.explorer.ExplorerFileEntry
import com.codespace.ide.ide.explorer.FileExplorerViewModel
import com.codespace.ide.ide.explorer.ProjectFileWatcher
import com.codespace.ide.ide.terminal.TermBridge
import com.codespace.ide.ide.theme.IdeTheme

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun FileTreeDrawer(
    editorViewModel: EditorViewModel,
    explorerViewModel: FileExplorerViewModel,
    codeIntelligenceViewModel: CodeIntelligenceViewModel,
    bridge: TermBridge,
    proot: com.codespace.ide.ProotManager,
    onOpenFile: (File) -> Unit,
    onJumpToLine: (File, Int) -> Unit
) {
    val session = editorViewModel.session
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val explorerVm = explorerViewModel
    val explorerState by explorerVm.state.collectAsState()
    val codeVm = codeIntelligenceViewModel
    val expandedSnapshot = session.expanded.toMap()
    // Observe project filesystem changes made outside the editor (terminal,
    // Python scripts, package installers, etc.).
    androidx.compose.runtime.DisposableEffect(session.project.dir, session.showHidden, session.treeViewMode) {
        val watcher = ProjectFileWatcher(
            session.project.dir,
            includeHidden = session.showHidden || session.treeViewMode == 1
        ) { structureChanged ->
            session.refreshTree(contentChanged = structureChanged)
        }
        watcher.start()
        onDispose { watcher.close() }
    }
    LaunchedEffect(
        session.project.dir, session.treeVersion, session.treeContentVersion, expandedSnapshot,
        session.sortMode, session.showHidden, session.treeViewMode
    ) {
        explorerVm.refresh(
            root = session.project.dir,
            expanded = expandedSnapshot,
            sortByType = session.sortMode == 1,
            showHidden = session.showHidden || session.treeViewMode == 1,
            collapseChains = false,
            contentVersion = session.treeContentVersion.toLong(),
        )
    }
    val drawerScope = rememberCoroutineScope()
    var showTransactionHistory by remember { mutableStateOf(false) }
    var transactionHistory by remember(session.project.dir.absolutePath) {
        mutableStateOf<List<ProjectTransactionManager.HistoryEntry>>(emptyList())
    }
    var transactionHistoryMessage by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(showTransactionHistory, session.project.dir.absolutePath) {
        if (showTransactionHistory) {
            transactionHistory = withContext(Dispatchers.IO) {
                ProjectTransactionManager.history(session.project.dir, 100)
            }
        }
    }
    var pickChildren by remember { mutableStateOf<List<ExplorerFileEntry>>(emptyList()) }
    var importDir by remember { mutableStateOf<File?>(null) }
    val importer = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri ->
        val d = importDir
        if (uri != null && d != null) {
            drawerScope.launch {
                val imported = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    importUriToDir(ctx, uri, d)
                }
                if (imported) session.refreshTree()
                else android.widget.Toast.makeText(ctx, "Import failed", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
        importDir = null
    }
    // Export: copy ONE project file to wherever the user picks on the device (system "save as" picker,
    // no storage permission needed).
    var exportFile by remember { mutableStateOf<File?>(null) }
    val exportScope = androidx.compose.runtime.rememberCoroutineScope()
    val exporter = androidx.activity.compose.rememberLauncherForActivityResult(ExportFileContract()) { uri ->
        val f = exportFile
        exportFile = null
        if (uri != null && f != null) {
            exportScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                val ok = try {
                    ctx.contentResolver.openOutputStream(uri)?.use { out ->
                        f.inputStream().use { it.copyTo(out) }
                    } != null
                } catch (_: Exception) {
                    false
                }
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    android.widget.Toast.makeText(
                        ctx,
                        if (ok) "Exported ${f.name}" else "Could not export ${f.name}",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }
    var opTarget by remember { mutableStateOf<File?>(null) }
    var opTargetIsDirectory by remember { mutableStateOf(true) }
    var opMenu by remember { mutableStateOf(false) }
    var treeMoreOpen by remember { mutableStateOf(false) }
    var viewMenu by remember { mutableStateOf(false) }
    var pickOp by remember { mutableStateOf<String?>(null) }
    var pickSrc by remember { mutableStateOf<File?>(null) }
    var pickDest by remember { mutableStateOf(session.project.dir) }
    var newSubmenu by remember { mutableStateOf(false) }
    var newKind by remember { mutableStateOf<String?>(null) }
    var newName by remember { mutableStateOf("") }
    var renameFor by remember { mutableStateOf<File?>(null) }
    var renameText by remember { mutableStateOf("") }
    var confirmDel by remember { mutableStateOf<File?>(null) }
    // Drawer tab: 0 files · 1 search · 2 structure · 3 git.
    var drawerTab by remember { mutableStateOf(0) }
    // In-tree file/folder search: query, 2s flash path, pending reveal.
    var treeSearchOpen by remember { mutableStateOf(false) }
    var treeQuery by remember { mutableStateOf("") }
    var treeFlashPath by remember { mutableStateOf<String?>(null) }
    var pendingReveal by remember { mutableStateOf<String?>(null) }
    var treeNoMatch by remember { mutableStateOf(false) }
    val treeListState = rememberLazyListState()
    LaunchedEffect(pickDest, pickOp) {
        if (pickOp != null) {
            pickChildren = try {
                explorerVm.listDestinationChildren(pickDest, session.project.dir)
            } catch (_: Exception) {
                emptyList()
            }
        } else {
            pickChildren = emptyList()
        }
    }

    // File count and tree rows are produced by FileExplorerViewModel on IO.
    val fileCountText = if (explorerState.fileCountCapped) {
        "${explorerState.fileCount}+ files"
    } else {
        "${explorerState.fileCount} files"
    }
    val treeNodes = explorerState.nodes
    // Keep this effect above the drawer-tab switch: a breadcrumb tap must
    // work even when the drawer was last left on Search, Structure or Git.
    LaunchedEffect(session.treeRevealRequest, treeNodes) {
        val request = session.treeRevealRequest ?: return@LaunchedEffect
        val targetPath = request.first
        val rootPath = session.project.dir.absoluteFile.absolutePath.trimEnd('/')
        if (targetPath != rootPath && !targetPath.startsWith(rootPath + "/")) {
            return@LaunchedEffect
        }
        drawerTab = 0
        treeSearchOpen = false
        treeQuery = ""
        var parent = File(targetPath).parentFile
        while (parent != null &&
            (parent.absolutePath == rootPath || parent.absolutePath.startsWith(rootPath + "/"))
        ) {
            if (session.expanded[parent.absolutePath] != true) {
                session.expanded[parent.absolutePath] = true
            }
            parent = parent.parentFile
        }
        val targetIndex = treeNodes.indexOfFirst { it.file.absolutePath == targetPath }
        if (targetIndex >= 0) {
            try {
                treeListState.animateScrollToItem(targetIndex)
            } catch (_: Exception) {
            }
            treeFlashPath = targetPath
            delay(2000)
            if (treeFlashPath == targetPath) treeFlashPath = null
            if (session.treeRevealRequest == request) {
                session.treeRevealRequest = null
            }
        }
    }
    LaunchedEffect(explorerState.error) {
        explorerState.error?.let {
            android.widget.Toast.makeText(ctx, it, android.widget.Toast.LENGTH_SHORT).show()
        }
    }
    CompositionLocalProvider(LocalContentColor provides Color(IdeTheme.TEXT)) {
    Column(
        Modifier
        .fillMaxHeight()
        .width(300.dp)
        .background(Color(IdeTheme.PANEL))
        .statusBarsPadding()
        .navigationBarsPadding()
    ) {
        DrawerTabBar(selected = drawerTab, onSelect = { drawerTab = it })
        when (drawerTab) {
            0 -> {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(IdeTheme.LILAC).copy(alpha = 0.35f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                session.project.name.firstOrNull()?.uppercase() ?: "P",
                                fontWeight = FontWeight.Bold, fontSize = 18.sp,
                                color = Color(IdeTheme.LILAC)
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                session.project.name, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                                maxLines = 1
                            )
                            Text(
                                fileCountText,
                                color = Color(IdeTheme.DIM), fontSize = 11.sp
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    // Action rail: new file · import · more.
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        DrawerIconButton("+", "new file") {
                            opTarget = session.project.dir
                            opTargetIsDirectory = true
                            newKind = "file"
                            newName = ""
                            pickOp = "create"
                            pickSrc = null
                            pickDest = session.project.dir
                        }
                        DrawerIconButton("⤓", "import file") {
                            importDir = session.project.dir
                            try {
                                importer.launch("*/*")
                            } catch (_: Exception) {
                            }
                        }
                        Spacer(Modifier.weight(1f))
                        DrawerIconButton("⌕", "search files") {
                            treeSearchOpen = !treeSearchOpen
                            if (!treeSearchOpen) {
                                treeQuery = ""
                                treeFlashPath = null
                                treeNoMatch = false
                            }
                        }
                        DrawerIconButton("⋯", "more") { treeMoreOpen = true }
                    }
                    Spacer(Modifier.height(10.dp))
                    // View-mode chip: Project (smart structure) vs All files (raw).
                    Box {
                        Row(
                            Modifier
                            .clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
                            .background(Color(IdeTheme.CARD))
                            .clickable { viewMenu = true }
                            .padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                if (session.treeViewMode == 0) "Project" else "All files",
                                fontSize = 13.sp, color = Color(IdeTheme.TEXT)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text("⌄", fontSize = 11.sp, color = Color(IdeTheme.DIM))
                        }
                        DropdownMenu(
                            expanded = viewMenu,
                            onDismissRequest = { viewMenu = false },
                            modifier = Modifier.background(
                                Color(IdeTheme.CARD),
                                androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                            )
                        ) {
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "Project", fontSize = 14.sp,
                                            color = Color(IdeTheme.TEXT),
                                            modifier = Modifier.weight(1f)
                                        )
                                        if (session.treeViewMode == 0) {
                                            Text("✓", fontSize = 14.sp, color = Color(IdeTheme.LILAC))
                                        }
                                    }
                                },
                                onClick = {
                                    session.treeViewMode = 0
                                    viewMenu = false
                                }
                            )
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "All files", fontSize = 14.sp,
                                            color = Color(IdeTheme.TEXT),
                                            modifier = Modifier.weight(1f)
                                        )
                                        if (session.treeViewMode == 1) {
                                            Text("✓", fontSize = 14.sp, color = Color(IdeTheme.LILAC))
                                        }
                                    }
                                },
                                onClick = {
                                    session.treeViewMode = 1
                                    viewMenu = false
                                }
                            )
                        }
                    }
                }
                if (treeSearchOpen) {
                    OutlinedTextField(
                        value = treeQuery,
                        onValueChange = { treeQuery = it },
                        placeholder = { Text("Search files…") },
                        leadingIcon = {
                            Text("⌕", fontSize = 15.sp, color = Color(IdeTheme.DIM))
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                        .padding(start = 12.dp, end = 12.dp, bottom = 10.dp)
                    )
                    if (treeNoMatch && treeQuery.trim().length >= 2) {
                        Text(
                            "No match.", color = Color(IdeTheme.DIM), fontSize = 11.sp,
                            modifier = Modifier.padding(start = 16.dp, bottom = 6.dp)
                        )
                    }
                }
                Divider(color = Color(IdeTheme.LINE))
                if (explorerState.isLoading || explorerState.isOperating) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                val rootDir = session.project.dir
                val treeShowHidden = session.showHidden || session.treeViewMode == 1
                val nodes = treeNodes
                val flashPath = treeFlashPath
                if (explorerState.isLoading && nodes.isEmpty()) {
                    Text("Loading project files…", color = Color(IdeTheme.DIM), fontSize = 12.sp,
                        modifier = Modifier.padding(16.dp))
                }
                LazyColumn(
                        state = treeListState,
                        modifier = Modifier.fillMaxSize().padding(vertical = 4.dp)
                    ) {
                        nodes.forEach { node ->
                            if (node.overflow > 0) {
                                item(key = node.file.absolutePath + "#more") {
                                    Row(
                                        Modifier.fillMaxWidth()
                                        .padding(
                                            start = (14 + node.depth * 12).dp,
                                            end = 8.dp, top = 6.dp, bottom = 6.dp
                                        ),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "… +${node.overflow} more",
                                            color = Color(IdeTheme.DIM), fontSize = 11.sp
                                        )
                                    }
                                }
                            } else {
                                item(key = node.file.absolutePath) {
                                    TreeRow(
                                        node = node,
                                        expanded = session.expanded[node.file.absolutePath] == true,
                                        selected = session.active?.file?.absolutePath == node.file.absolutePath,
                                        flash = flashPath != null && nodeMatchesPath(node, flashPath),
                                        onToggle = {
                                            val p = node.file.absolutePath
                                            session.expanded[p] = !(session.expanded[p] == true)
                                            session.refreshTree(contentChanged = false)
                                        },
                                        onOpen = onOpenFile,
                                        onLong = {
                                            opTarget = node.file
                                            opTargetIsDirectory = node.isDirectory
                                            opMenu = true
                                        }
                                    )
                                }
                            }
                        }
                    }
                    // Locate-on-type: expand the match's parents, rebuild, reveal.
                    LaunchedEffect(treeQuery, treeShowHidden) {
                        delay(220)
                        val needle = treeQuery.trim()
                        if (needle.length < 2) {
                            treeNoMatch = false
                            return@LaunchedEffect
                        }
                        val match = explorerVm.findFirstMatch(
                            rootDir, needle, showHidden = treeShowHidden
                        )
                        if (match == null) {
                            treeNoMatch = true
                            return@LaunchedEffect
                        }
                        treeNoMatch = false
                        var d = match.parentFile
                        while (d != null &&
                            (d.absolutePath == rootDir.absolutePath ||
                                d.absolutePath.startsWith(rootDir.absolutePath + "/"))
                        ) {
                            // Guarded write: same-value puts would still churn
                            // recomposition on every keystroke.
                            if (session.expanded[d.absolutePath] != true) {
                                session.expanded[d.absolutePath] = true
                            }
                            d = d.parentFile
                        }
                        // No refreshTree() here: the expanded-map mutation already
                        // invalidates the nodes remember below. Bumping treeVersion
                        // would restart the key() scope (and this effect) per
                        // keystroke — an infinite rebuild loop.
                        pendingReveal = match.absolutePath
                    }
                    // Reveal-on-search: after the list rebuilds, glide to the match
                    // and flash it for 2s.
                    LaunchedEffect(pendingReveal, nodes) {
                        val p = pendingReveal ?: return@LaunchedEffect
                        val idx = nodes.indexOfFirst { nodeMatchesPath(it, p) }
                        if (idx >= 0) {
                            try {
                                treeListState.animateScrollToItem(idx)
                            } catch (_: Exception) {
                            }
                            treeFlashPath = p
                            delay(2000)
                            if (treeFlashPath == p) treeFlashPath = null
                        }
                        pendingReveal = null
                    }
            }
            1 -> SearchTab(session = session, viewModel = codeVm, onJumpToLine = onJumpToLine)
            2 -> StructureTab(session = session, viewModel = codeVm, onJumpToLine = onJumpToLine)
            3 -> GitHubTab(session = session)
        }
    }
    }
    // Long-press context menu (reference file-manager style): dark rounded
    // card, icon rows, inline New submenu, red Delete.
    if (opMenu && opTarget != null) {
        val t = opTarget!!
        val baseDir = if (opTargetIsDirectory) t else t.parentFile ?: session.project.dir
        // The project root itself can gain children but can never be
        // renamed/moved/copied/deleted from its own tree.
        val isProjRoot = t.absolutePath == session.project.dir.absolutePath
        IdeAlertDialog(
            onDismissRequest = { opMenu = false; newSubmenu = false },
            title = { Text(t.name, fontSize = 14.sp, fontFamily = FontFamily.Monospace) },
            text = {
                Column(Modifier.fillMaxWidth()) {
                    CtxRow("◷", "Transaction history") {
                        opMenu = false
                        transactionHistoryMessage = null
                        showTransactionHistory = true
                    }
                    CtxRow("+", "New", trailing = "▸") { newSubmenu = !newSubmenu }
                    if (newSubmenu) {
                        CtxRow("+", "File", indent = true) {
                            opMenu = false; newSubmenu = false
                            opTarget = baseDir; opTargetIsDirectory = true; newKind = "file"; newName = ""
                            pickOp = "create"; pickSrc = null; pickDest = baseDir
                        }
                        CtxRow("▢", "Directory", indent = true) {
                            opMenu = false; newSubmenu = false
                            opTarget = baseDir; opTargetIsDirectory = true; newKind = "dir"; newName = ""
                            pickOp = "create"; pickSrc = null; pickDest = baseDir
                        }
                    }
                    CtxRow("⤓", "Import from file manager") {
                        opMenu = false; newSubmenu = false
                        importDir = baseDir
                        try {
                            importer.launch("*/*")
                        } catch (_: Exception) {
                        }
                    }
                    CtxRow("⧉", "Copy path") {
                        opMenu = false; newSubmenu = false
                        copyPathToClipboard(ctx, t.absolutePath)
                    }
                    if (!opTargetIsDirectory) {
                        CtxRow("⤒", "Export to device") {
                            opMenu = false; newSubmenu = false
                            exportFile = t
                            val ext = t.extension.lowercase()
                            val mime = android.webkit.MimeTypeMap.getSingleton()
                                .getMimeTypeFromExtension(ext) ?: "application/octet-stream"
                            try {
                                exporter.launch(t.name to mime)
                            } catch (_: Exception) {
                                exportFile = null
                            }
                        }
                    }
                    if (!isProjRoot) {
                        CtxRow("✎", "Rename") {
                            opMenu = false; newSubmenu = false
                            renameFor = t; renameText = t.name
                        }
                        CtxRow("→", "Move") {
                            opMenu = false; newSubmenu = false
                            pickOp = "move"; pickSrc = t
                            pickDest = baseDir
                        }
                        CtxRow("❏", "Copy") {
                            opMenu = false; newSubmenu = false
                            pickOp = "copy"; pickSrc = t
                            pickDest = baseDir
                        }
                        CtxRow("✕", "Delete", danger = true) {
                            opMenu = false; newSubmenu = false
                            confirmDel = t
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { opMenu = false; newSubmenu = false }) { Text("Close") } }
        )
    }
    // Header ⋯ menu: New / Refresh / Expand / Collapse / Sort.
    if (treeMoreOpen) {
        IdeAlertDialog(
            onDismissRequest = { treeMoreOpen = false },
            title = { Text(session.project.name, fontSize = 14.sp) },
            text = {
                Column(Modifier.fillMaxWidth()) {
                    CtxRow("+", "New file") {
                        treeMoreOpen = false
                        opTarget = session.project.dir; opTargetIsDirectory = true; newKind = "file"; newName = ""
                        pickOp = "create"; pickSrc = null; pickDest = session.project.dir
                    }
                    CtxRow("▢", "New folder") {
                        treeMoreOpen = false
                        opTarget = session.project.dir; opTargetIsDirectory = true; newKind = "dir"; newName = ""
                        pickOp = "create"; pickSrc = null; pickDest = session.project.dir
                    }
                    CtxRow("⟳", "Refresh") {
                        treeMoreOpen = false
                        session.refreshTree()
                    }
                    CtxRow("▾", "Expand all") {
                        treeMoreOpen = false
                        drawerScope.launch {
                            val directories = explorerVm.listAllDirectories(
                                session.project.dir,
                                showHidden = session.showHidden || session.treeViewMode == 1,
                            )
                            session.expanded.putAll(directories.associateWith { true })
                            session.refreshTree(contentChanged = false)
                        }
                    }
                    CtxRow("▴", "Collapse all") {
                        treeMoreOpen = false
                        session.expanded.clear()
                        session.refreshTree(contentChanged = false)
                    }
                    Text(
                        "Sort by", color = Color(IdeTheme.DIM), fontSize = 12.sp,
                        modifier = Modifier.padding(top = 8.dp, bottom = 2.dp)
                    )
                    CtxRow("", "Name", check = session.sortMode == 0) {
                        session.sortMode = 0
                    }
                    CtxRow("", "Type", check = session.sortMode == 1) {
                        session.sortMode = 1
                    }
                    CtxRow("", "Hidden folders", check = session.showHidden) {
                        session.showHidden = !session.showHidden
                    }
                }
            },
            confirmButton = { TextButton(onClick = { treeMoreOpen = false }) { Text("Close") } }
        )
    }
    // Destination picker shared by Copy, Move, and New File/Folder.
    if (pickOp != null && (pickSrc != null || pickOp == "create")) {
        val operation = pickOp.orEmpty()
        val isCreate = operation == "create"
        val isCopy = operation == "copy"
        val src = pickSrc
        IdeAlertDialog(
            onDismissRequest = { pickOp = null; if (isCreate) newKind = null },
            title = {
                Text(
                    when {
                        isCreate -> if (newKind == "dir") "New folder" else "New file"
                        isCopy -> "Copy '${src?.name.orEmpty()}' to…"
                        else -> "Move '${src?.name.orEmpty()}' to…"
                    },
                    fontSize = 14.sp
                )
            },
            text = {
                Column(Modifier.fillMaxWidth()) {
                    if (isCreate) {
                        OutlinedTextField(
                            value = newName,
                            onValueChange = { newName = it },
                            label = { Text("Name") },
                            placeholder = { Text(if (newKind == "dir") "new_folder" else "module.py") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("Create in", color = Color(IdeTheme.DIM), fontSize = 11.sp)
                    }
                    PickBreadcrumb(
                        root = session.project.dir,
                        dest = pickDest,
                        onPick = { pickDest = it }
                    )
                    Spacer(Modifier.height(6.dp))
                    Box(Modifier.fillMaxWidth().height(240.dp)) {
                        LazyColumn(Modifier.fillMaxSize()) {
                            val kids = pickChildren
                            if (kids.isEmpty()) {
                                item {
                                    Text(
                                        "This folder is empty", color = Color(IdeTheme.DIM),
                                        fontSize = 12.sp, modifier = Modifier.padding(12.dp)
                                    )
                                }
                            }
                            items(kids, key = { it.file.absolutePath }) { child ->
                                if (child.isDirectory) {
                                    Row(
                                        Modifier.fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable { pickDest = child.file }
                                            .padding(horizontal = 8.dp, vertical = 9.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        FileBadge(child.file, isDirectory = true)
                                        Spacer(Modifier.width(9.dp))
                                        Text(
                                            child.file.name, fontSize = 13.sp,
                                            modifier = Modifier.weight(1f), maxLines = 1
                                        )
                                        Text("›", color = Color(IdeTheme.DIM), fontSize = 18.sp)
                                    }
                                } else {
                                    Row(
                                        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        FileBadge(child.file, isDirectory = false)
                                        Spacer(Modifier.width(9.dp))
                                        Text(
                                            child.file.name, fontSize = 12.sp,
                                            color = Color(IdeTheme.DIM), maxLines = 1,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                    Text(
                        "Destination: ${pickDest.name}",
                        color = Color(IdeTheme.ACCENT), fontSize = 11.sp,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (isCreate) {
                        val name = newName.trim()
                        val kind = newKind
                        if (name.isNotEmpty() && kind != null) {
                            explorerVm.createEntryAsync(
                                session.project.dir, pickDest, name, kind == "dir"
                            ) { result ->
                                result.onSuccess { created ->
                                    var ancestor: File? = pickDest
                                    val projectRoot = session.project.dir
                                    while (ancestor != null &&
                                        (ancestor.absolutePath == projectRoot.absolutePath ||
                                            ancestor.absolutePath.startsWith(projectRoot.absolutePath + "/"))
                                    ) {
                                        session.expanded[ancestor.absolutePath] = true
                                        ancestor = ancestor.parentFile
                                    }
                                    if (created.isDirectory) session.expanded[created.absolutePath] = true
                                    session.refreshTree()
                                }
                            }
                        }
                        pickOp = null
                        newKind = null
                    } else {
                        val source = src
                        if (source != null) {
                            val dp = pickDest.absolutePath
                            val sp = source.absolutePath
                            val bad = dp == sp || dp.startsWith(sp + "/")
                            if (!bad) {
                                val complete: (Result<File>) -> Unit = { result ->
                                    if (result.isSuccess) {
                                        if (!isCopy) session.removeTabsUnder(source)
                                        session.refreshTree()
                                    }
                                }
                                if (isCopy) {
                                    explorerVm.copyEntryAsync(session.project.dir, source, pickDest, complete)
                                } else {
                                    editorViewModel.saveTabsUnder(source) { saved ->
                                        if (saved) explorerVm.moveEntryAsync(session.project.dir, source, pickDest, complete)
                                        else android.widget.Toast.makeText(ctx, "Save open files before moving", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                }
                            } else {
                                android.widget.Toast.makeText(ctx, "Choose a different destination", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        }
                        pickOp = null
                    }
                }) {
                    Text(
                        when { isCreate -> "Create here"; isCopy -> "Copy here"; else -> "Move here" },
                        color = Color(IdeTheme.ACCENT)
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { pickOp = null; if (isCreate) newKind = null }) {
                    Text("Cancel", color = Color(IdeTheme.DIM))
                }
            }
        )
    }
    if (renameFor != null) {
        IdeAlertDialog(
            onDismissRequest = { renameFor = null },
            title = { Text("Rename") },
            text = {
                OutlinedTextField(
                    value = renameText, onValueChange = { renameText = it },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                        val old = renameFor!!
                        val perform = {
                            explorerVm.renameEntryAsync(session.project.dir, old, renameText) { result ->
                                if (result.isSuccess) {
                                    // Import declarations in otherwise unrelated open
                                    // documents may have changed on disk as part of the
                                    // same package/module rename transaction.
                                    session.removeTabsUnder(old)
                                    session.tabs.toList().forEach { openTab ->
                                        if (openTab.file.isFile) runCatching { openTab.reload() }
                                    }
                                    session.refreshTree()
                                }
                            }
                        }
                        // A package/file rename can rewrite imports in any Python
                        // file, so persist every open document before scanning edits.
                        editorViewModel.saveTabsUnder(session.project.dir) { saved ->
                            if (saved) perform()
                            else android.widget.Toast.makeText(ctx, "Save open files before renaming", android.widget.Toast.LENGTH_SHORT).show()
                        }
                        renameFor = null
                }) { Text("Rename") }
            },
            dismissButton = { TextButton(onClick = { renameFor = null }) { Text("Cancel") } }
        )
    }
    if (confirmDel != null) {
        IdeAlertDialog(
            onDismissRequest = { confirmDel = null },
            title = { Text("Delete?") },
            text = { Text("\"${confirmDel!!.name}\" will be removed.") },
            confirmButton = {
                TextButton(onClick = {
                        val gone = confirmDel!!
                        val perform = {
                            explorerVm.deleteEntryAsync(session.project.dir, gone) { result ->
                                if (result.isSuccess) {
                                    session.removeTabsUnder(gone)
                                    session.refreshTree()
                                }
                            }
                        }
                        editorViewModel.saveTabsUnder(gone) { saved ->
                            if (saved) perform()
                            else android.widget.Toast.makeText(ctx, "Save open files before deleting", android.widget.Toast.LENGTH_SHORT).show()
                        }
                        confirmDel = null
                }) { Text("Delete", color = Color(IdeTheme.ERROR)) }
            },
            dismissButton = { TextButton(onClick = { confirmDel = null }) { Text("Cancel") } }
        )
    }
    if (showTransactionHistory) {
        IdeAlertDialog(
            onDismissRequest = { showTransactionHistory = false },
            title = { Text("Project transaction history") },
            text = {
                Column(
                    Modifier.fillMaxWidth().heightIn(max = 420.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("Recent file operations recorded by PySpace", color = Color(IdeTheme.DIM), fontSize = 11.sp)
                    transactionHistoryMessage?.let { Text(it, color = Color(IdeTheme.ACCENT), fontSize = 11.sp) }
                    if (transactionHistory.isEmpty()) {
                        Text("No project transactions have been recorded yet.", color = Color(IdeTheme.DIM), fontSize = 12.sp)
                    } else {
                        transactionHistory.take(18).forEach { entry ->
                            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(IdeTheme.BG)).padding(9.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(entry.operation.replace('_', ' '), color = Color(IdeTheme.TEXT), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                    val statusColor = when (entry.status) {
                                        ProjectTransactionManager.Status.COMMITTED -> Color(0xFF35B66A)
                                        ProjectTransactionManager.Status.FAILED -> Color(IdeTheme.ERROR)
                                        ProjectTransactionManager.Status.INTERRUPTED -> Color(IdeTheme.WARN)
                                        ProjectTransactionManager.Status.RESTORED -> Color(IdeTheme.ACCENT)
                                    }
                                    Text(entry.status.name, color = statusColor, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                                if (entry.paths.isNotEmpty()) {
                                    Text(entry.paths.take(3).joinToString(" · "), color = Color(IdeTheme.DIM), fontSize = 10.sp, maxLines = 2)
                                }
                                if (entry.detail.isNotBlank()) Text(entry.detail, color = Color(IdeTheme.WARN), fontSize = 10.sp)
                                if (entry.recoveryAvailable) {
                                    TextButton(onClick = {
                                        drawerScope.launch {
                                            val restored = runCatching {
                                                ProjectTransactionManager.restoreInterruptedDelete(session.project.dir, entry.id)
                                            }.getOrDefault(false)
                                            transactionHistoryMessage = if (restored) "The original item was restored successfully." else "The item could not be restored. Its original path may already be occupied or its recovery data may be unavailable."
                                            transactionHistory = withContext(Dispatchers.IO) {
                                                ProjectTransactionManager.history(session.project.dir, 100)
                                            }
                                            session.treeContentVersion++
                                        }
                                    }) { Text("Restore deleted item", color = Color(IdeTheme.ACCENT), fontSize = 11.sp) }
                                }
                                Text(java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(entry.startedAt)), color = Color(IdeTheme.DIM), fontSize = 9.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showTransactionHistory = false }) { Text("Close") } },
        )
    }
}

// --------------------------- Drawer tabs -----------------------------------
