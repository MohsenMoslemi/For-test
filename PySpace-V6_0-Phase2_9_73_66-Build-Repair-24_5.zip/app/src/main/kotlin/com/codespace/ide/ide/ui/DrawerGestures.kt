package com.codespace.ide.ide.ui

import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.unit.Velocity
import kotlin.math.abs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/** Push-drawer shift state. Owned by IdeRoot, driven from editor gestures. */
class DrawerShift {
    companion object {
        const val WIDTH_DP = 300
    }

    val px = Animatable(0f)
    var widthPx = 0f
    /** Last finger-driven update (uptime ms), for the idle watchdog below. */
    var lastDragMs = 0L
    /** Last update driven by the threshold detector (handoff guard). */
    var lastDirectMs = 0L
    /** Last update driven by the nested-scroll tap (handoff guard). */
    var lastNestedMs = 0L
    /** True while a settle/open/close animation is in flight. */
    var busy = false

    val fraction: Float
    get() = if (widthPx > 0f) (px.value / widthPx).coerceIn(0f, 1f) else 0f

    // Release velocity, measured on the DRAWER's own position (px), not on
    // pointer events. The editor/panel world is shifted by px, so pointer
    // positions are node-local and move together with the finger: velocity
    // taken from them reads ~0 for a fast swipe, the release then fell back
    // to "past half way?" and a quick flick snapped back. The drawer's own
    // position is always in one stable space.
    private var velTracker = VelocityTracker()
    private var lastSampleMs = 0L

    private fun recordSample() {
        val now = SystemClock.uptimeMillis()
        if (now - lastSampleMs > 120L) velTracker = VelocityTracker()
        lastSampleMs = now
        velTracker.addPosition(now, Offset(px.value, 0f))
    }

    /** Horizontal velocity (px/s, + = opening) of the drag that just ended. */
    fun releaseVelocityX(): Float {
        if (SystemClock.uptimeMillis() - lastSampleMs > 120L) return 0f
        return try {
            velTracker.calculateVelocity().x
        } catch (_: Exception) {
            0f
        }
    }

    suspend fun dragBy(dx: Float) {
        if (widthPx <= 0f) return
        try {
            lastDragMs = SystemClock.uptimeMillis()
        } catch (_: Exception) {
        }
        px.snapTo((px.value + dx).coerceIn(0f, widthPx))
        recordSample()
    }

    suspend fun open() {
        if (widthPx <= 0f) return
        busy = true
        try {
            px.animateTo(widthPx, spring(dampingRatio = 0.9f, stiffness = 550f))
        } finally {
            busy = false
        }
    }

    suspend fun close() {
        busy = true
        try {
            px.animateTo(0f, spring(dampingRatio = 0.9f, stiffness = 550f))
        } finally {
            busy = false
        }
    }

    suspend fun settle(velocityX: Float) {
        if (velocityX > 700f || (velocityX > -700f && fraction > 0.5f)) open() else close()
    }
}

/**
 * Threshold-gated drawer drag, built only on high-level gesture APIs. Taps,
 * vertical scrolls, long-presses and an active text selection NEVER reach
 * the drawer: the gesture is abandoned without consuming a single event, so
 * clicks, editor scrolling, cursor drags and selection keep working exactly
 * as before. Only a committed horizontal swipe (either direction) drives
 * the drawer 1:1 and settles it on release. Safe to attach anywhere.
 */
@Composable
fun Modifier.drawerDrag(
    drawerShift: DrawerShift,
    scope: CoroutineScope,
    selectionActive: Boolean,
    commitPx: Float
): Modifier = pointerInput(drawerShift, selectionActive, commitPx) {
    val slop = viewConfiguration.touchSlop
    var driving = false
    try {
        // One detector pass per gesture; a normal end returns and the next
        // pass waits for the next finger. Cancellation (keys changed)
        // lands in finally below.
        while (true) {
            var dxSum = 0f
            var dySum = 0f
            var downTime = 0L
            driving = false
            val tracker = VelocityTracker()
            detectDragGestures(
                onDragStart = {
                    downTime = SystemClock.uptimeMillis()
                },
                onDragCancel = {
                    // Interrupted mid-drive (second finger, disposal):
                    // park by position instead of stranding half-open.
                    if (driving) {
                        driving = false
                        scope.launch {
                            try {
                                drawerShift.settle(0f)
                            } catch (_: Exception) {
                            }
                        }
                    }
                },
                onDragEnd = {
                    if (driving) {
                        driving = false
                        val vx = try {
                            val local = tracker.calculateVelocity().x
                            val own = drawerShift.releaseVelocityX()
                            if (abs(own) > abs(local)) own else local
                        } catch (_: Exception) {
                            0f
                        }
                        scope.launch {
                            try {
                                drawerShift.settle(vx)
                            } catch (_: Exception) {
                            }
                        }
                    }
                },
                onDrag = { change, dragAmount ->
                    tracker.addPosition(change.uptimeMillis, change.position)
                    dxSum += dragAmount.x
                    dySum += dragAmount.y
                    // The nested tap owns this gesture (a scrollable just
                    // moved): stand down so the drawer never moves at double
                    // finger speed. Time-based, so it can never deadlock.
                    if (SystemClock.uptimeMillis() - drawerShift.lastNestedMs < 150L) {
                        return@detectDragGestures
                    }
                    if (!driving) {
                        // Vertical: the scrollable underneath owns this —
                        // never consume, never drive.
                        if (abs(dySum) > slop && abs(dySum) >= abs(dxSum)) return@detectDragGestures
                        // Held finger: cursor/selection/menu territory.
                        if (SystemClock.uptimeMillis() - downTime > 450L) return@detectDragGestures
                        // Live text selection: never steal its drag.
                        if (selectionActive) return@detectDragGestures
                        if (dxSum > commitPx || dxSum < -commitPx) {
                            driving = true
                        } else {
                            return@detectDragGestures
                        }
                    }
                    scope.launch {
                        try {
                            drawerShift.lastDirectMs = SystemClock.uptimeMillis()
                            drawerShift.dragBy(dragAmount.x)
                        } catch (_: Exception) {
                        }
                    }
                    change.consume()
                }
            )
        }
    } finally {
        // Detector coroutine cancelled mid-drive (e.g. a selection started
        // and restarted this detector): park instead of stranding half-open.
        if (driving) {
            driving = false
            scope.launch {
                try {
                    drawerShift.settle(0f)
                } catch (_: Exception) {
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Nested-scroll drawer driving: the editor's own scroll modifiers dispatch
// leftover deltas here even when the touch started on the text field itself
// (a parent gesture detector starves there, because the field consumes the
// press). We take ONLY leftovers the content could not use — at line start,
// or past the scroll bounds — so editor scrolling, cursor drags and text
// selection can never be disturbed; there is simply nothing to disturb.
// Programmatic scrolls (SideEffect) are ignored: an auto-scroll must never
// swing the drawer open by itself.
// ---------------------------------------------------------------------------

/**
 * Nested-scroll tap for the drawer: horizontal leftovers drive it 1:1,
 * flings settle it. Pair with [drawerDrag] (which covers non-scrollable
 * areas and owns release-settling there); every drag funnels through
 * [DrawerShift.dragBy], so release handling stays unified.
 */
@Composable
fun Modifier.drawerNestedScroll(
    drawerShift: DrawerShift,
    scope: CoroutineScope,
    holdPx: Float = 0f
): Modifier {
    val connection = remember(drawerShift) {
        object : NestedScrollConnection {
            // Per-gesture bookkeeping (a gesture = events < 250 ms apart).
            private var lastEventMs = 0L
            private var scrolledInGesture = false
            private var driving = false
            private var pending = 0f

            override fun onPreScroll(
                available: Offset,
                source: NestedScrollSource
            ): Offset = Offset.Zero

            override fun onPostScroll(
                consumed: Offset,
                available: Offset,
                source: NestedScrollSource
            ): Offset {
                // Only a FINGER drag may open/close the tree. A tab strip or
                // code line still coasting from a fling used to leak its
                // leftover into the drawer the instant it reached its start
                // (the "scroll hasn't finished, tree opens anyway" bug).
                if (source != NestedScrollSource.UserInput) return Offset.Zero
                val now = SystemClock.uptimeMillis()
                if (now - lastEventMs > 250L) {
                    scrolledInGesture = false
                    driving = false
                    pending = 0f
                }
                lastEventMs = now
                // The content itself scrolled during this gesture: let it
                // finish first; the tree only starts after the user keeps
                // dragging past the scroll's end.
                if (abs(consumed.x) > 0.5f) {
                    scrolledInGesture = true
                    driving = false
                    pending = 0f
                }
                // The threshold detector owns this gesture: stand down so
                // the drawer never moves at double finger speed.
                if (now - drawerShift.lastDirectMs < 150L) {
                    return Offset.Zero
                }
                val dx = available.x
                if (dx == 0f) return Offset.Zero
                if (scrolledInGesture && !driving) {
                    pending += dx
                    if (abs(pending) < holdPx) return Offset.Zero
                    driving = true
                }
                scope.launch {
                    try {
                        drawerShift.lastNestedMs = SystemClock.uptimeMillis()
                        drawerShift.dragBy(dx)
                    } catch (_: Exception) {
                    }
                }
                return Offset(dx, 0f)
            }

            override suspend fun onPostFling(
                consumed: Velocity,
                available: Velocity
            ): Velocity {
                val w = drawerShift.widthPx
                val wasScrolled = scrolledInGesture
                scrolledInGesture = false
                driving = false
                pending = 0f
                if (w > 0f) {
                    val px = drawerShift.px.value
                    // Settle ONLY a drawer the finger actually dragged
                    // (mid-travel). A fast flick over a scrolled tab strip /
                    // code line must never open the tree by itself.
                    if (px > 1f && px < w - 1f) {
                        val own = drawerShift.releaseVelocityX()
                        val v = if (abs(own) > abs(available.x)) own else available.x
                        drawerShift.settle(v)
                        return Velocity.Zero
                    }
                }
                return available
            }
        }
    }
    return nestedScroll(connection)
}

// ---------------------------------------------------------------------------
// IDE root: navigation, per-project sessions, console runs and the bottom
// panel (Console / Problems / Terminal / Debug / Test). Run output goes to
// the Console tab — the Terminal tab stays the user's interactive shell.
// ---------------------------------------------------------------------------
