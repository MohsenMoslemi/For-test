package com.codespace.ide.ide.codeintel

import java.io.File
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

/** A single source line returned by project text search. */
data class TextHit(val line: Int, val text: String, val start: Int, val end: Int)

/** Best-effort symbol entry used by outline and symbol search. */
data class OutlineItem(val kind: Char, val name: String, val detail: String, val line: Int)

data class TextSearchOptions(
    val matchCase: Boolean = false,
    val wholeWord: Boolean = false,
    val regex: Boolean = false,
)

data class TextSearchResult(
    val hits: Map<File, List<TextHit>> = emptyMap(),
    val invalidPattern: Boolean = false,
)

interface CodeIntelligenceRepository {
    suspend fun outline(fileName: String, text: String): List<OutlineItem>
    suspend fun searchText(root: File, query: String, options: TextSearchOptions): TextSearchResult
    suspend fun searchSymbols(root: File, query: String, membersOnly: Boolean): Map<File, List<OutlineItem>>
}

/**
 * Bounded, best-effort source analysis. It deliberately avoids a full parser or
 * external dependency so it remains lightweight on older phones and works
 * offline. All directory traversal and file reads are called from IO.
 */
class FileCodeIntelligenceRepository : CodeIntelligenceRepository {
    override suspend fun outline(fileName: String, text: String): List<OutlineItem> {
        return parseOutline(fileName, text)
    }

    override suspend fun searchText(
        root: File,
        query: String,
        options: TextSearchOptions,
    ): TextSearchResult {
        if (query.isEmpty()) return TextSearchResult()
        val regexOptions = if (options.matchCase) emptySet() else setOf(RegexOption.IGNORE_CASE)
        val compiled = when {
            options.regex -> try { Regex(query, regexOptions) } catch (_: Exception) { return TextSearchResult(invalidPattern = true) }
            options.wholeWord -> try { Regex("\b" + Regex.escape(query) + "\b", regexOptions) } catch (_: Exception) { return TextSearchResult(invalidPattern = true) }
            else -> null
        }
        val needle = if (options.matchCase) query else query.lowercase()
        val out = linkedMapOf<File, MutableList<TextHit>>()
        var files = 0
        var total = 0
        var scannedNodes = 0
        val context = currentCoroutineContext()
        try {
            root.walkTopDown()
                .onEnter { directory ->
                    scannedNodes++
                    !isHiddenTreeDir(directory.name) && files < 150 && total < 400 && scannedNodes < MAX_SCANNED_NODES
                }
                .forEach { file ->
                    context.ensureActive()
                    scannedNodes++
                    if (scannedNodes > MAX_SCANNED_NODES || total >= 400 || !file.isFile || file.extension.lowercase() !in TEXT_EXTS) return@forEach
                    val length = try { file.length() } catch (_: Exception) { -1L }
                    if (length < 0L || length > MAX_TEXT_BYTES) return@forEach
                    val source = try { file.readText(Charsets.UTF_8).take(MAX_TEXT_BYTES.toInt()) } catch (_: Exception) { return@forEach }
                    files++
                    var perFile = 0
                    source.lineSequence().take(MAX_LINES_PER_FILE).forEachIndexed { index, line ->
                        if (perFile >= MAX_HITS_PER_FILE || total >= MAX_TOTAL_HITS) return@forEachIndexed
                        val match = when {
                            compiled != null -> compiled.find(line)?.let { it.range.first to (it.range.last + 1) }
                            options.matchCase -> line.indexOf(query).takeIf { it >= 0 }?.let { it to it + query.length }
                            else -> line.lowercase().indexOf(needle).takeIf { it >= 0 }?.let { it to it + query.length }
                        }
                        if (match != null) {
                            out.getOrPut(file) { mutableListOf() }.add(
                                TextHit(index + 1, line.take(140), match.first.coerceAtMost(140), match.second.coerceAtMost(140))
                            )
                            perFile++
                            total++
                        }
                    }
                }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            // Unreadable or concurrently removed files are skipped.
        }
        return TextSearchResult(out.mapValues { it.value.toList() })
    }

    override suspend fun searchSymbols(root: File, query: String, membersOnly: Boolean): Map<File, List<OutlineItem>> {
        if (query.length < 2) return emptyMap()
        val out = linkedMapOf<File, List<OutlineItem>>()
        var files = 0
        var scannedNodes = 0
        val context = currentCoroutineContext()
        try {
            root.walkTopDown()
                .onEnter { directory ->
                    scannedNodes++
                    !isHiddenTreeDir(directory.name) && files < 100 && out.size < 60 && scannedNodes < MAX_SCANNED_NODES
                }
                .forEach { file ->
                    context.ensureActive()
                    scannedNodes++
                    if (scannedNodes > MAX_SCANNED_NODES || out.size >= 60 || !file.isFile || file.extension.lowercase() !in SYMBOL_EXTS) return@forEach
                    val length = try { file.length() } catch (_: Exception) { -1L }
                    if (length < 0L || length > MAX_SYMBOL_BYTES) return@forEach
                    val source = try { file.readText(Charsets.UTF_8).take(MAX_SYMBOL_BYTES.toInt()) } catch (_: Exception) { return@forEach }
                    files++
                    val matches = parseOutline(file.name, source).filter {
                        (!membersOnly || it.kind != 'C') && it.name.contains(query, ignoreCase = true)
                    }.take(30)
                    if (matches.isNotEmpty()) out[file] = matches
                }
        } catch (cancelled: kotlinx.coroutines.CancellationException) {
            throw cancelled
        } catch (_: Exception) {
            // Ignore individual filesystem failures; keep the useful results.
        }
        return out
    }

    private fun parseOutline(fileName: String, source: String): List<OutlineItem> {
        val extension = fileName.substringAfterLast('.', "").lowercase()
        if (extension !in SYMBOL_EXTS) return emptyList()
        val output = ArrayList<OutlineItem>()
        source.lineSequence().take(MAX_SOURCE_LINES).forEachIndexed { index, raw ->
            val trimmed = raw.trim()
            if (trimmed.isEmpty() || trimmed.startsWith("//") || trimmed.startsWith("#") ||
                trimmed.startsWith("*") || trimmed.startsWith("/*")) return@forEachIndexed
            when (extension) {
                "py" -> {
                    PY_CLASS.find(trimmed)?.let { output += OutlineItem('C', it.groupValues[1], "", index + 1) }
                        ?: PY_DEF.find(trimmed)?.let { output += OutlineItem('m', it.groupValues[1], it.groupValues[2].take(40), index + 1) }
                        ?: run {
                            if (!raw.startsWith(" ") && !raw.startsWith("\t")) {
                                PY_FIELD.find(trimmed)?.let { output += OutlineItem('f', it.groupValues[1], "", index + 1) }
                            }
                        }
                }
                else -> {
                    KT_CLASS.find(trimmed)?.let { output += OutlineItem('C', it.groupValues[2], "", index + 1) }
                        ?: KT_FUN.find(trimmed)?.let { output += OutlineItem('m', it.groupValues[1], it.groupValues[2].take(40), index + 1) }
                        ?: KT_FIELD.find(trimmed)?.let { output += OutlineItem('f', it.groupValues[2], "", index + 1) }
                }
            }
            if (output.size >= 500) return output
        }
        return output
    }

    private companion object {
        const val MAX_TEXT_BYTES = 300_000L
        const val MAX_SYMBOL_BYTES = 200_000L
        const val MAX_LINES_PER_FILE = 4_000
        const val MAX_SOURCE_LINES = 4_000
        const val MAX_HITS_PER_FILE = 40
        const val MAX_TOTAL_HITS = 400
        const val MAX_SCANNED_NODES = 2_500
        val TEXT_EXTS = setOf("py", "kt", "kts", "java", "txt", "md", "toml", "cfg", "ini", "json", "yaml", "yml", "xml", "html", "sh", "pro", "gradle", "properties")
        val SYMBOL_EXTS = setOf("py", "kt", "kts", "java")
        val PY_CLASS = Regex("""^class\s+([A-Za-z_]\w*)""")
        val PY_DEF = Regex("""^def\s+([A-Za-z_]\w*)\s*(\([^)]*\))?""")
        val PY_FIELD = Regex("""^([A-Za-z_]\w*)\s*=\s*[^=]""")
        val KT_CLASS = Regex("""\b(class|object|interface)\s+([A-Za-z_]\w*)""")
        val KT_FUN = Regex("""\bfun\s+([A-Za-z_]\w*)\s*(\([^)]*\))?""")
        val KT_FIELD = Regex("""\b(val|var)\s+([A-Za-z_]\w*)""")
    }
}
