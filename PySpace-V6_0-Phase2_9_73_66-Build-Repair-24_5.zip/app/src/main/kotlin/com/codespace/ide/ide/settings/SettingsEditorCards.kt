package com.codespace.ide.ide.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ide.EditorFontCatalog
import com.codespace.ide.ide.EditorSymbolCatalog
import com.codespace.ide.ide.theme.IdeTheme

/** Editor preferences page. All values are owned by SettingsViewModel. */
@Composable
internal fun EditorSettingsCard(
    settings: IdeSettingsState,
    viewModel: SettingsViewModel,
) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.CARD)), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text("CODE EDITOR", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.3.sp)
            Spacer(Modifier.height(8.dp))
            Text("Editing preferences", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(12.dp))
            Text("Editor font", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Spacer(Modifier.height(3.dp))
            Text("Choose a typeface for code and line numbers only.", color = Color(IdeTheme.DIM), fontSize = 10.sp)
            var fontMenuExpanded by remember { mutableStateOf(false) }
            val selectedEditorFont = EditorFontCatalog.find(settings.editorFontFamilyId)
            Box(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .background(Color(IdeTheme.BG))
                        .clickable { fontMenuExpanded = true }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(selectedEditorFont.title, color = Color(IdeTheme.TEXT), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Spacer(Modifier.height(4.dp))
                        Text("def main():  return 42", color = Color(IdeTheme.TEXT), fontSize = 13.sp, fontFamily = selectedEditorFont.family, maxLines = 1)
                    }
                    Text("⌄", color = Color(IdeTheme.ACCENT), fontSize = 20.sp)
                }
                DropdownMenu(
                    expanded = fontMenuExpanded,
                    onDismissRequest = { fontMenuExpanded = false },
                    modifier = Modifier.background(Color(IdeTheme.PANEL))
                ) {
                    EditorFontCatalog.options.forEach { option ->
                        DropdownMenuItem(
                            text = {
                                Column(Modifier.width(224.dp)) {
                                    Text(option.title, color = Color(IdeTheme.TEXT), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                    Spacer(Modifier.height(3.dp))
                                    Text("def main():  return 42", color = Color(IdeTheme.TEXT), fontFamily = option.family, fontSize = 13.sp, maxLines = 1)
                                    Text(option.description, color = Color(IdeTheme.DIM), fontSize = 9.sp, maxLines = 1)
                                }
                            },
                            trailingIcon = {
                                if (option.id == settings.editorFontFamilyId) Text("✓", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.Bold)
                            },
                            onClick = {
                                viewModel.setEditorFontFamilyId(option.id)
                                fontMenuExpanded = false
                            }
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            SettingStepper("Code font size", "${settings.codeFontSize.toInt()}sp", onMinus = {
                viewModel.setCodeFontSize(settings.codeFontSize - 1f)
            }, onPlus = {
                viewModel.setCodeFontSize(settings.codeFontSize + 1f)
            })
            SettingStepper("Tab width", "${settings.tabWidth} spaces", onMinus = {
                viewModel.setTabWidth(settings.tabWidth - 1)
            }, onPlus = {
                viewModel.setTabWidth(settings.tabWidth + 1)
            })
            SettingSwitch("Auto-indent on Enter", settings.autoIndent, onChange = viewModel::setAutoIndent)
            SettingSwitch("Line numbers", settings.lineNumbers, onChange = viewModel::setLineNumbers)
            SettingSwitch("Word wrap", settings.wordWrap, onChange = viewModel::setWordWrap)
        }
    }
}

/** Reorders the complete symbol inventory; the first four entries are pinned in the editor bar. */
@Composable
internal fun EditorSymbolBarSettingsCard(
    settings: IdeSettingsState,
    viewModel: SettingsViewModel,
) {
    val symbols = EditorSymbolCatalog.normalize(settings.editorSymbolOrder)

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.CARD)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(18.dp)) {
            Text("SYMBOL SHORTCUT BAR", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.3.sp)
            Spacer(Modifier.height(8.dp))
            Text("Arrange editor keys", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                "The first four keys stay fixed beside the divider. Move a key up to pin it, or move it down to place it in the horizontally scrollable group.",
                color = Color(IdeTheme.DIM), fontSize = 11.sp, lineHeight = 16.sp
            )
            Spacer(Modifier.height(14.dp))
            Text("PINNED · ALWAYS VISIBLE", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.sp)
            Spacer(Modifier.height(6.dp))
            symbols.take(EditorSymbolCatalog.PINNED_COUNT).forEachIndexed { index, symbol ->
                EditorSymbolOrderRow(
                    symbol = symbol,
                    position = index + 1,
                    canMoveUp = index > 0,
                    canMoveDown = index < symbols.lastIndex,
                    onMoveUp = { viewModel.setEditorSymbolOrder(symbols.toMutableList().apply { add(index - 1, removeAt(index)) }) },
                    onMoveDown = { viewModel.setEditorSymbolOrder(symbols.toMutableList().apply { add(index + 1, removeAt(index)) }) }
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f).height(1.dp).background(Color(IdeTheme.LINE)))
                Text("  DIVIDER  ", color = Color(IdeTheme.DIM), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Box(Modifier.weight(1f).height(1.dp).background(Color(IdeTheme.LINE)))
            }
            Spacer(Modifier.height(8.dp))
            Text("SCROLLABLE · MORE KEYS", color = Color(IdeTheme.DIM), fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.sp)
            Spacer(Modifier.height(6.dp))
            symbols.drop(EditorSymbolCatalog.PINNED_COUNT).forEachIndexed { offset, symbol ->
                val index = offset + EditorSymbolCatalog.PINNED_COUNT
                EditorSymbolOrderRow(
                    symbol = symbol,
                    position = index + 1,
                    canMoveUp = true,
                    canMoveDown = index < symbols.lastIndex,
                    onMoveUp = { viewModel.setEditorSymbolOrder(symbols.toMutableList().apply { add(index - 1, removeAt(index)) }) },
                    onMoveDown = { viewModel.setEditorSymbolOrder(symbols.toMutableList().apply { add(index + 1, removeAt(index)) }) }
                )
            }
            Spacer(Modifier.height(8.dp))
            Text("Use ↑ to move a key toward the pinned group and ↓ to move it back. Your order is saved automatically.", color = Color(IdeTheme.DIM), fontSize = 10.sp, lineHeight = 15.sp)
        }
    }
}

@Composable
internal fun EditorSymbolOrderRow(
    symbol: String,
    position: Int,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
            .clip(RoundedCornerShape(10.dp)).background(Color(IdeTheme.BG))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(if (symbol == "TAB") "⇥" else symbol, color = Color(IdeTheme.TEXT), fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(48.dp))
        Text(if (symbol == "TAB") "Tab character" else "Symbol", color = Color(IdeTheme.DIM), fontSize = 11.sp, modifier = Modifier.weight(1f))
        Text("$position", color = Color(IdeTheme.DIM), fontSize = 10.sp, modifier = Modifier.padding(end = 6.dp))
        Box(
            Modifier.size(34.dp).clip(RoundedCornerShape(8.dp))
                .background(if (canMoveUp) Color(IdeTheme.PANEL) else Color(IdeTheme.PANEL).copy(alpha = 0.35f))
                .clickable(enabled = canMoveUp, onClick = onMoveUp),
            contentAlignment = Alignment.Center
        ) { Text("↑", color = if (canMoveUp) Color(IdeTheme.ACCENT) else Color(IdeTheme.DIM), fontSize = 18.sp) }
        Spacer(Modifier.width(6.dp))
        Box(
            Modifier.size(34.dp).clip(RoundedCornerShape(8.dp))
                .background(if (canMoveDown) Color(IdeTheme.PANEL) else Color(IdeTheme.PANEL).copy(alpha = 0.35f))
                .clickable(enabled = canMoveDown, onClick = onMoveDown),
            contentAlignment = Alignment.Center
        ) { Text("↓", color = if (canMoveDown) Color(IdeTheme.ACCENT) else Color(IdeTheme.DIM), fontSize = 18.sp) }
    }
}

/** Independent visibility controls for contextual editor popups. */
@Composable
internal fun EditorPopupSettingsCard(
    settings: IdeSettingsState,
    viewModel: SettingsViewModel,
) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.CARD)), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text("EDITOR POPUPS", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.3.sp)
            Spacer(Modifier.height(8.dp))
            Text("Contextual windows", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(4.dp))
            Text("Turn off any popup you do not want while editing. These settings do not disable diagnostics or code intelligence themselves.", color = Color(IdeTheme.DIM), fontSize = 11.sp, lineHeight = 16.sp)
            Spacer(Modifier.height(8.dp))
            SettingSwitch("Errors and warnings", settings.showDiagnosticPopup, "Diagnostic details near the current line", onChange = viewModel::setShowDiagnosticPopup)
            SettingSwitch("Code suggestions", settings.showCompletionPopup, "Autocomplete and completion suggestions", onChange = viewModel::setShowCompletionPopup)
            SettingSwitch("Documentation", settings.showDocumentationPopup, "Symbol documentation and definition popups", onChange = viewModel::setShowDocumentationPopup)
        }
    }
}

/** Gesture preferences page. */
@Composable
internal fun GesturesCard(
    settings: IdeSettingsState,
    viewModel: SettingsViewModel,
) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color(IdeTheme.CARD)), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text("TOUCH CONTROLS", color = Color(IdeTheme.ACCENT), fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.3.sp)
            Spacer(Modifier.height(8.dp))
            Text("Editor gestures", color = Color(IdeTheme.TEXT), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            SettingSwitch(
                "Two-axis scrolling", settings.pan2D,
                subtitle = "Drag in any direction to scroll both axes at once (touch)",
                enabled = !settings.wordWrap,
                onChange = viewModel::setPan2D,
            )
            SettingSwitch(
                "Pinch to zoom", settings.pinchZoom,
                subtitle = "Pinch with two fingers to change the code font size",
                onChange = viewModel::setPinchZoom,
            )
        }
    }
}
