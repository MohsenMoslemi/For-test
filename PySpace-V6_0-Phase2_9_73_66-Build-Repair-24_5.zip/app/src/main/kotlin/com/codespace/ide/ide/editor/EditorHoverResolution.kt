package com.codespace.ide.ide.editor

import com.codespace.ide.ide.codeintel.PythonDefinitionLocation
import com.codespace.ide.ide.codeintel.PythonHoverDoc
import com.codespace.ide.ide.codeintel.PythonHoverDocumentation
import com.codespace.ide.ide.codeintel.PythonLspController
import java.io.File

/** Result of resolving documentation and navigation for one immutable source snapshot. */
internal data class EditorHoverResolution(
    val documentation: PythonHoverDoc?,
    val definition: PythonDefinitionLocation?
)

/**
 * Resolves hover information without owning UI state. The caller owns cancellation and
 * verifies that the source snapshot is still current before publishing this result.
 */
internal object EditorHoverResolver {
    fun offlineDocumentation(
        source: String,
        target: EditorHoverTarget,
        controller: PythonLspController?
    ): PythonHoverDoc? = PythonHoverDocumentation.resolveAt(
        source,
        target.offset,
        controller?.installedPackagesSnapshot()
    )

    suspend fun resolve(
        file: File,
        source: String,
        target: EditorHoverTarget,
        controller: PythonLspController?,
        offlineDocumentation: PythonHoverDoc?
    ): EditorHoverResolution? {
        if (controller == null && offlineDocumentation == null) return null
        val documentation = offlineDocumentation ?: controller?.hover(file, source, target.offset)
        val candidate = controller?.definitionLocation(file, source, target.wordStart)
        val definition = candidate?.takeUnless {
            val line = source.substring(0, target.wordStart).count { ch -> ch == '\n' } + 1
            val lineStart = source.lastIndexOf('\n', (target.wordStart - 1).coerceAtLeast(0)) + 1
            val column = target.wordStart - lineStart
            val sameDeclaration = runCatching {
                it.file.canonicalFile == file.canonicalFile &&
                    it.line == line &&
                    it.column in column until (column + target.wordEnd - target.wordStart)
            }.getOrDefault(false)
            !it.file.exists() || !it.file.isFile || sameDeclaration
        }

        if (documentation == null && definition == null) return null
        return EditorHoverResolution(documentation, definition)
    }
}
