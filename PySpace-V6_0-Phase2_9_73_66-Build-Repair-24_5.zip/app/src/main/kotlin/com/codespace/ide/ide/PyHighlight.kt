package com.codespace.ide.ide

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontStyle
import com.codespace.ide.ide.theme.IdeTheme

// ---------------------------------------------------------------------------
// Python syntax highlighting: single-pass tokenizer -> AnnotatedString.
// O(n), no regex backtracking, safe on large files. Covers comments,
// strings (triple/single, prefixes, escapes), numbers, keywords, builtins,
// decorators and self/cls.
// ---------------------------------------------------------------------------

private val PY_KEYWORDS = setOf(
    "False", "None", "True", "and", "as", "assert", "async", "await",
    "break", "class", "continue", "def", "del", "elif", "else", "except",
    "finally", "for", "from", "global", "if", "import", "in", "is",
    "lambda", "nonlocal", "not", "or", "pass", "raise", "return",
    "try", "while", "with", "yield", "match", "case"
)

private val PY_BUILTINS = setOf(
    "abs", "all", "any", "ascii", "bin", "bool", "breakpoint", "bytearray",
    "bytes", "callable", "chr", "classmethod", "compile", "complex",
    "delattr", "dict", "dir", "divmod", "enumerate", "eval", "exec",
    "filter", "float", "format", "frozenset", "getattr", "globals",
    "hasattr", "hash", "help", "hex", "id", "input", "int", "isinstance",
    "issubclass", "iter", "len", "list", "locals", "map", "max",
    "memoryview", "min", "next", "object", "oct", "open", "ord", "pow",
    "print", "property", "range", "repr", "reversed", "round", "set",
    "setattr", "slice", "sorted", "staticmethod", "str", "sum", "super",
    "tuple", "type", "vars", "zip", "__import__"
)

private fun isWordChar(c: Char): Boolean = c.isLetterOrDigit() || c == '_'

fun highlightPython(code: String): AnnotatedString {
    if (code.isEmpty()) return AnnotatedString("")

    val keyword = SpanStyle(color = Color(IdeTheme.KEYWORD), fontWeight = FontWeight.Bold)
    val string = SpanStyle(color = Color(IdeTheme.STRING))
    val comment = SpanStyle(color = Color(IdeTheme.COMMENT), fontStyle = FontStyle.Italic)
    val number = SpanStyle(color = Color(IdeTheme.NUMBER), fontWeight = FontWeight.Medium)
    val builtin = SpanStyle(color = Color(IdeTheme.BUILTIN))
    val decorator = SpanStyle(color = Color(IdeTheme.DECORATOR), fontWeight = FontWeight.Medium)
    val function = SpanStyle(color = Color(IdeTheme.FUNCTION), fontWeight = FontWeight.SemiBold)
    val className = SpanStyle(color = Color(IdeTheme.CLASS_NAME), fontWeight = FontWeight.Bold)
    val constant = SpanStyle(color = Color(IdeTheme.CONSTANT), fontWeight = FontWeight.Medium)
    val operator = SpanStyle(color = Color(IdeTheme.OPERATOR), fontWeight = FontWeight.Medium)
    val selfStyle = SpanStyle(color = Color(IdeTheme.DECORATOR), fontWeight = FontWeight.Bold)

    return buildAnnotatedString {
        append(code)
        val n = code.length
        var i = 0
        // Set by `def`/`class`; whitespace and annotations do not consume it.
        var expectedDefinition: String? = null

        while (i < n) {
            val c = code[i]

            if (c.isWhitespace()) {
                i++
                continue
            }

            // Comments run to the end of the physical line.
            if (c == '#') {
                var j = i + 1
                while (j < n && code[j] != '\n') j++
                addStyle(comment, i, j)
                i = j
                continue
            }

            // String literals, including r/b/f/u prefixes and triple-quoted blocks.
            if (c == '\'' || c == '"' || (c.isLetter() && i + 1 < n &&
                    (code[i + 1] == '\'' || code[i + 1] == '"'))
            ) {
                var quoteAt = i
                while (quoteAt < n && code[quoteAt].isLetter() && code[quoteAt] != '\'' && code[quoteAt] != '"') quoteAt++
                if (quoteAt < n && (code[quoteAt] == '\'' || code[quoteAt] == '"')) {
                    val quote = code[quoteAt]
                    val triple = quoteAt + 2 < n && code[quoteAt + 1] == quote && code[quoteAt + 2] == quote
                    var j = if (triple) quoteAt + 3 else quoteAt + 1
                    while (j < n) {
                        if (!triple && code[j] == '\n') break
                        if (code[j] == '\\') {
                            j = (j + 2).coerceAtMost(n)
                            continue
                        }
                        if (code[j] == quote) {
                            if (!triple) {
                                j++
                                break
                            }
                            if (j + 2 < n && code[j + 1] == quote && code[j + 2] == quote) {
                                j += 3
                                break
                            }
                        }
                        j++
                    }
                    addStyle(string, i, j.coerceAtMost(n))
                    i = j.coerceAtLeast(i + 1)
                    continue
                }
            }

            // Numeric literals: decimal, exponent, hex/octal/binary and imaginary.
            if (c.isDigit() || (c == '.' && i + 1 < n && code[i + 1].isDigit())) {
                var j = i
                if (c == '0' && j + 1 < n && code[j + 1] in "xXoObB") {
                    j += 2
                    while (j < n && (code[j].isLetterOrDigit() || code[j] == '_')) j++
                } else {
                    while (j < n && (code[j].isDigit() || code[j] == '_')) j++
                    if (j < n && code[j] == '.') {
                        j++
                        while (j < n && (code[j].isDigit() || code[j] == '_')) j++
                    }
                    if (j < n && code[j] in "eE") {
                        var k = j + 1
                        if (k < n && code[k] in "+-") k++
                        if (k < n && code[k].isDigit()) {
                            j = k + 1
                            while (j < n && (code[j].isDigit() || code[j] == '_')) j++
                        }
                    }
                    if (j < n && code[j] in "jJ") j++
                }
                addStyle(number, i, j)
                i = j
                continue
            }

            // Decorators, including dotted decorator paths.
            if (c == '@' && (i == 0 || !isWordChar(code[i - 1]))) {
                var j = i + 1
                while (j < n && (isWordChar(code[j]) || code[j] == '.')) j++
                if (j > i + 1) addStyle(decorator, i, j)
                i = j.coerceAtLeast(i + 1)
                continue
            }

            if (c.isLetter() || c == '_') {
                var j = i + 1
                while (j < n && isWordChar(code[j])) j++
                val word = code.substring(i, j)
                when {
                    word in PY_KEYWORDS -> {
                        addStyle(keyword, i, j)
                        if (word == "def") expectedDefinition = "function"
                        else if (word == "class") expectedDefinition = "class"
                    }
                    expectedDefinition == "function" -> {
                        addStyle(function, i, j)
                        expectedDefinition = null
                    }
                    expectedDefinition == "class" -> {
                        addStyle(className, i, j)
                        expectedDefinition = null
                    }
                    word == "self" || word == "cls" -> addStyle(selfStyle, i, j)
                    word in PY_BUILTINS -> addStyle(builtin, i, j)
                    word.length > 1 && word.all { !it.isLetter() || it.isUpperCase() } && word.any { it.isLetter() } ->
                        addStyle(constant, i, j)
                    else -> {
                        var next = j
                        while (next < n && code[next].isWhitespace()) next++
                        if (next < n && code[next] == '(') addStyle(function, i, j)
                    }
                }
                i = j
                continue
            }

            // Operators receive a distinct semantic color without tinting punctuation.
            if (c in "+-*/%=<>!&|^~") {
                var j = i + 1
                while (j < n && code[j] in "=<>" && c in "+-*/%=<>!&|^") j++
                addStyle(operator, i, j)
                i = j
                continue
            }

            i++
        }
    }
}

// ---------------------------------------------------------------------------
// Lightweight static checks (instant, offline): unbalanced brackets, mixed
// tabs/spaces, overlong lines, missing trailing newline. Shown in the
// Problems panel tab next to the terminal.
// ---------------------------------------------------------------------------

data class PyProblem(val line: Int, val message: String, val error: Boolean)

fun pythonProblems(code: String): List<PyProblem> {
    if (code.isEmpty()) return emptyList()
    val out = mutableListOf<PyProblem>()
    val lines = code.split('\n')
    var indentComplaint = false
    lines.forEachIndexed { idx, ln ->
        val lnNo = idx + 1
        if (ln.length > 140) {
            out.add(PyProblem(lnNo, "Line too long (${ln.length} > 140)", false))
        }
        if (!indentComplaint && ln.startsWith("\t")) {
            indentComplaint = true
            out.add(PyProblem(lnNo, "Tab indentation (use spaces)", false))
        }
        if (ln.endsWith(" ") || ln.endsWith("\t")) {
            if (ln.isNotBlank()) out.add(PyProblem(lnNo, "Trailing whitespace", false))
        }
    }
    // Bracket balance with string/comment awareness.
    var depth = 0
    var errLine = -1
    var i = 0
    var lineNo = 1
    val n = code.length
    while (i < n) {
        val c = code[i]
        if (c == '\n') {
            lineNo++
            i++
            continue
        }
        if (c == '#') {
            while (i < n && code[i] != '\n') i++
            continue
        }
        if (c == '\'' || c == '"') {
            val q = c
            val triple = i + 2 < n && code[i + 1] == q && code[i + 2] == q
            i = if (triple) i + 3 else i + 1
            while (i < n) {
                if (!triple && code[i] == '\n') break
                if (code[i] == '\\') {
                    i += 2
                    continue
                }
                if (code[i] == q) {
                    if (triple) {
                        if (i + 2 < n && code[i + 1] == q && code[i + 2] == q) {
                            i += 3
                            break
                        }
                        i++
                    } else {
                        i++
                        break
                    }
                } else {
                    if (code[i] == '\n') lineNo++
                    i++
                }
            }
            continue
        }
        when (c) {
            '(', '[', '{' -> {
                depth++
                if (errLine < 0) errLine = lineNo
            }
            ')', ']', '}' -> {
                depth--
                if (depth < 0) {
                    out.add(PyProblem(lineNo, "Unmatched closing '$c'", true))
                    return out
                }
                if (depth == 0) errLine = -1
            }
        }
        i++
    }
    if (depth > 0) {
        out.add(PyProblem(if (errLine > 0) errLine else 1, "Unbalanced bracket (missing closer)", true))
    }
    if (!code.endsWith("\n")) {
        out.add(PyProblem(lines.size, "Missing trailing newline", false))
    }
    return out
}
