package com.codespace.ide.ide.explorer

import java.io.File

/**
 * Rewrites only Python import declarations whose resolved module path is the
 * renamed module (or a child of a renamed package). It deliberately does not
 * perform global text replacement: comments, strings and ordinary identifiers
 * are never touched.
 */
internal object PythonImportPathRefactor {
    private val fromImport = Regex("^(\\s*from\\s+)(\\.*[A-Za-z_][A-Za-z0-9_.]*|\\.+)(\\s+import\\b.*)$")
    private val importStatement = Regex("^(\\s*import\\s+)([A-Za-z_][A-Za-z0-9_.,\\s]*)(\\s*(?:#.*)?)$")

    fun collect(root: File, source: File, target: File): Map<File, String> {
        // __init__.py defines package semantics rather than a normal module
        // name; changing it must never rewrite every import of its package.
        if (!source.isDirectory && source.name in setOf("__init__.py", "__init__.pyi")) return emptyMap()
        if (target.name in setOf("__init__.py", "__init__.pyi")) return emptyMap()
        val oldModule = modulePath(root, source) ?: return emptyMap()
        val newModule = modulePath(root, target, source) ?: return emptyMap()
        if (oldModule == newModule) return emptyMap()
        val result = LinkedHashMap<File, String>()
        var scanned = 0
        var changedBytes = 0L
        val ignored = setOf(".git", ".venv", "venv", "__pycache__", "build", ".gradle", ".idea")
        root.walkTopDown().onEnter { dir ->
            dir == root || (dir.name !in ignored && !Files.isLink(dir))
        }.filter { it.isFile && it.extension.lowercase() in setOf("py", "pyi") && it.length() <= 4L * 1024 * 1024 }
            .forEach { file ->
                scanned++
                require(scanned <= 10_000) { "Project is too large to safely update imports in one operation" }
                val original = runCatching { file.readText(Charsets.UTF_8) }.getOrNull() ?: return@forEach
                val updated = rewrite(original, oldModule, newModule, root, file, source)
                if (updated != original) {
                    changedBytes += original.toByteArray(Charsets.UTF_8).size + updated.toByteArray(Charsets.UTF_8).size
                    require(changedBytes <= 32L * 1024 * 1024) { "Import updates exceed the safe transaction size" }
                    result[file.canonicalFile] = updated
                }
                require(result.size <= 300) { "Too many Python files reference this module" }
            }
        return result
    }

    private fun rewrite(text: String, oldModule: String, newModule: String, root: File, importer: File, renamedSource: File): String {
        val separator = if (text.contains("\r\n")) "\r\n" else "\n"
        val trailingNewline = text.endsWith("\n")
        val rewritten = text.lineSequence().joinToString(separator) { line ->
            val from = fromImport.matchEntire(line)
            if (from != null) {
                val module = from.groupValues[2]
                val relative = module.startsWith('.')
                if (relative && renamedSource.isDirectory) return@joinToString line
                val dotCount = module.takeWhile { it == '.' }.length
                val parentParts = runCatching {
                    importer.canonicalFile.parentFile.canonicalFile.relativeTo(root.canonicalFile).invariantSeparatorsPath
                        .split('/').filter { it.isNotBlank() }
                }.getOrDefault(emptyList())
                val baseParts = if (relative) parentParts.dropLast((dotCount - 1).coerceAtLeast(0)) else emptyList()
                val suffixModule = if (relative) module.drop(dotCount) else module
                val resolved = (if (relative) baseParts else emptyList()) + suffixModule.split('.').filter { it.isNotBlank() }
                val resolvedName = resolved.joinToString(".")
                val changedResolved = replaceModulePrefix(resolvedName, oldModule, newModule)
                val rewrittenModule = if (changedResolved != resolvedName && relative) {
                    val changedParts = changedResolved.split('.')
                    var common = 0
                    while (common < baseParts.size && common < changedParts.size && baseParts[common] == changedParts[common]) common++
                    ".".repeat((baseParts.size - common + 1).coerceAtLeast(1)) + changedParts.drop(common).joinToString(".")
                } else if (changedResolved != resolvedName) changedResolved else module
                if (changedResolved != resolvedName) {
                    from.groupValues[1] + rewrittenModule + from.groupValues[3]
                } else if (oldModule.startsWith(if (relative) resolvedName + "." else "$module.")) {
                    // `from package import child_module` is also a module reference.
                    val prefix = if (relative) resolvedName else module
                    val child = oldModule.removePrefix("$prefix.").substringBefore('.')
                    val newChild = newModule.removePrefix("$prefix.").substringBefore('.')
                    val suffix = from.groupValues[3]
                    val importPrefix = suffix.substringBefore("import") + "import"
                    val imported = suffix.substringAfter("import", "")
                    val rewrittenItems = imported.split(',').map { item ->
                        val trimmed = item.trim()
                        val aliasAt = trimmed.indexOf(" as ")
                        val name = if (aliasAt >= 0) trimmed.substring(0, aliasAt).trim() else trimmed
                        if (name == child) item.replaceFirst(Regex("\\b${Regex.escape(child)}\\b"), newChild) else item
                    }
                    val rewrittenSuffix = importPrefix + rewrittenItems.joinToString(",")
                    if (rewrittenSuffix == suffix) line else from.groupValues[1] + module + rewrittenSuffix
                } else line
            } else {
                val match = importStatement.matchEntire(line) ?: return@joinToString line
                val items = match.groupValues[2].split(',')
                var touched = false
                val rewritten = items.map { item ->
                    val trimmed = item.trim()
                    val aliasAt = trimmed.indexOf(" as ")
                    val module = if (aliasAt >= 0) trimmed.substring(0, aliasAt).trim() else trimmed
                    val changed = replaceModulePrefix(module, oldModule, newModule)
                    if (changed != module) touched = true
                    val leading = item.takeWhile { it.isWhitespace() }
                    val trailing = item.takeLastWhile { it.isWhitespace() }
                    leading + changed + (if (aliasAt >= 0) trimmed.substring(aliasAt) else "") + trailing
                }
                if (!touched) line else match.groupValues[1] + rewritten.joinToString(",") + match.groupValues[3]
            }
        }
        return rewritten + if (trailingNewline && !rewritten.endsWith("\n")) separator else ""
    }

    private fun replaceModulePrefix(module: String, old: String, new: String): String = when {
        module == old -> new
        module.startsWith("$old.") -> new + module.removePrefix(old)
        else -> module
    }

    private fun modulePath(root: File, file: File, packageTemplate: File? = null): String? {
        val relative = runCatching { file.canonicalFile.relativeTo(root.canonicalFile).invariantSeparatorsPath }.getOrNull() ?: return null
        val parts = relative.split('/').toMutableList()
        if (parts.isEmpty()) return null
        val isPackageDirectory = file.isDirectory || (packageTemplate?.isDirectory == true)
        if (isPackageDirectory) {
            // Python 3 namespace packages are importable without __init__.py.
        } else {
            if (file.extension.lowercase() !in setOf("py", "pyi")) return null
            val last = parts.removeAt(parts.lastIndex)
            val stem = last.substringBeforeLast('.', last)
            if (stem == "__init__") return parts.takeIf { it.isNotEmpty() }?.joinToString(".")
            parts += stem
        }
        if (parts.isEmpty() || parts.any { !it.matches(Regex("[A-Za-z_][A-Za-z0-9_]*")) }) return null
        return parts.joinToString(".")
    }

    private object Files {
        fun isLink(file: File): Boolean = try {
            java.nio.file.Files.isSymbolicLink(file.toPath())
        } catch (_: Exception) { true }
    }
}
