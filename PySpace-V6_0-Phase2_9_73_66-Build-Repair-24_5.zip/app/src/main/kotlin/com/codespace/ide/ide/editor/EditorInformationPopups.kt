package com.codespace.ide.ide.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.layoutId
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.codespace.ide.ide.theme.IdeTheme
import com.codespace.ide.ide.codeintel.PythonSignatureInfo

/** Presentation-only signature help card. It owns no editor state or LSP lifecycle. */
@Composable
internal fun EditorSignatureHelpCard(
    signature: PythonSignatureInfo,
    onDismiss: () -> Unit,
    onPositioned: (LayoutCoordinates) -> Unit
) {
    val shape = RoundedCornerShape(11.dp)
    val activeParameter = signature.parameters.getOrNull(signature.activeParameter)
    val highlighted = buildAnnotatedString {
        val start = activeParameter?.start ?: -1
        val end = activeParameter?.end ?: -1
        if (start >= 0 && end > start && end <= signature.label.length) {
            append(signature.label.substring(0, start))
            withStyle(SpanStyle(
                color = Color(IdeTheme.ACCENT),
                background = Color(IdeTheme.ACCENT).copy(alpha = 0.18f)
            )) { append(signature.label.substring(start, end)) }
            append(signature.label.substring(end))
        } else append(signature.label)
    }
    Column(
        modifier = Modifier
            .layoutId(3)
            .onGloballyPositioned(onPositioned)
            .heightIn(max = 128.dp)
            .shadow(14.dp, shape)
            .clip(shape)
            .containPopupScroll()
            .background(Color(IdeTheme.PANEL))
            .border(1.dp, Color(IdeTheme.LINE), shape)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 11.dp, vertical = 9.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("PARAMETERS", color = Color(IdeTheme.TEAL), fontSize = 9.sp, letterSpacing = 0.8.sp)
            Spacer(Modifier.weight(1f))
            Text("${signature.activeParameter + 1}/${signature.parameters.size.coerceAtLeast(1)}",
                color = Color(IdeTheme.DIM), fontSize = 9.sp)
            Spacer(Modifier.width(4.dp))
            PopupClose(onDismiss)
        }
        Spacer(Modifier.height(6.dp))
        Text(highlighted, color = Color(IdeTheme.TEXT), fontFamily = FontFamily.Monospace,
            fontSize = 11.sp, lineHeight = 16.sp)
        val description = activeParameter?.documentation?.ifBlank { null }
            ?: signature.documentation.ifBlank { null }
        if (description != null) {
            Spacer(Modifier.height(6.dp))
            Text(description, color = Color(IdeTheme.DIM), fontSize = 10.sp, lineHeight = 14.sp)
        }
    }
}

/** Small documentation affordance; placement remains controlled by the editor viewport. */
@Composable
internal fun EditorDocumentationBubble(
    position: () -> IntOffset,
    onPositioned: (LayoutCoordinates) -> Unit,
    onClick: () -> Unit
) {
    val size = 28.dp
    val shape = RoundedCornerShape(50)
    Box(
        modifier = Modifier
            .zIndex(0.6f)
            .offset { position() }
            .onGloballyPositioned(onPositioned)
            .size(size)
            .shadow(8.dp, shape)
            .clip(shape)
            .background(Color(IdeTheme.PANEL))
            .border(1.dp, Color(IdeTheme.ACCENT).copy(alpha = 0.75f), shape)
            .then(Modifier.clickable(onClick = onClick)),
        contentAlignment = Alignment.Center
    ) {
        Text("i", color = Color(IdeTheme.ACCENT), fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}
