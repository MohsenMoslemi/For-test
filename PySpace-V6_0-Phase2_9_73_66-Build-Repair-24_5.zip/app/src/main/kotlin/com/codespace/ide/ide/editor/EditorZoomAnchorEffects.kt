package com.codespace.ide.ide.editor

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.text.TextLayoutResult

/** Owns the post-commit scroll hand-off and live wrapped-layout re-anchoring effects. */
@Composable
internal fun EditorZoomAnchorEffects(
    fontSize: Float,
    verticalScroll: ScrollState,
    horizontalScroll: ScrollState,
    wordWrap: Boolean,
    textLayout: TextLayoutResult?,
    pinchGestureActive: Boolean,
    anchor: ZoomAnchor,
    onCommitSettled: () -> Unit,
    onWrappedLayoutChanged: (TextLayoutResult) -> Unit
) {
    LaunchedEffect(fontSize) {
        if (!anchor.pending) return@LaunchedEffect
        anchor.pending = false
        val commitToken = anchor.token
        try {
            withFrameNanos { }
            withFrameNanos { }
            if (anchor.token == commitToken && !pinchGestureActive) {
                val targetY = anchor.targetY.toInt().coerceIn(0, verticalScroll.maxValue)
                val deltaY = targetY - verticalScroll.value
                if (deltaY != 0) verticalScroll.dispatchRawDelta(deltaY.toFloat())
                if (!wordWrap) {
                    val targetX = anchor.targetX.toInt().coerceIn(0, horizontalScroll.maxValue)
                    val deltaX = targetX - horizontalScroll.value
                    if (deltaX != 0) horizontalScroll.dispatchRawDelta(deltaX.toFloat())
                }
            }
        } finally {
            if (anchor.token == commitToken) onCommitSettled()
        }
    }

    LaunchedEffect(verticalScroll.maxValue, textLayout) {
        val layout = textLayout
        if (layout != null && anchor.wrapLive) onWrappedLayoutChanged(layout)
    }
}
