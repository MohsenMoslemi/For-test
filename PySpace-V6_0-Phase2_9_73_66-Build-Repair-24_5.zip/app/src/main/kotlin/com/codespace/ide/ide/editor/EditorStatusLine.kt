package com.codespace.ide.ide.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.codespace.ide.ide.EditorSymbolCatalog
import com.codespace.ide.ide.theme.IdeTheme

@Composable
fun EditorStatusLine(
    tab: OpenTab?,
    line: Int,
    col: Int,
    problems: Int,
    modifier: Modifier = Modifier,
    /** Tap on the line:column chip (find the caret again in a long file). */
    onPositionClick: (() -> Unit)? = null
) {
    Row(
        modifier
        .fillMaxWidth()
        .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            tab?.name ?: "No file open",
            color = Color(IdeTheme.DIM),
            fontSize = 11.sp,
            modifier = Modifier.weight(1f)
        )
        if (problems > 0) {
            Text(
                "$problems problem${if (problems == 1) "" else "s"}",
                color = Color(IdeTheme.WARN),
                fontSize = 11.sp
            )
            Spacer(Modifier.size(8.dp))
        }
        if (tab != null) {
            // Green chip = tappable: glides the editor to the caret and centres it.
            val chipShape = RoundedCornerShape(8.dp)
            Text(
                "$line:$col",
                color = Color(IdeTheme.ACCENT),
                fontSize = 11.sp,
                textAlign = TextAlign.End,
                modifier = Modifier
                    .clip(chipShape)
                    .background(Color(IdeTheme.ACCENT).copy(alpha = 0.18f))
                    .border(1.dp, Color(IdeTheme.ACCENT).copy(alpha = 0.55f), chipShape)
                    .then(if (onPositionClick != null) Modifier.clickable { onPositionClick() } else Modifier)
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            )
        }
    }
}

val PY_SYMBOLS = EditorSymbolCatalog.defaults
