package com.codespace.ide.ide.display

import android.widget.Toast
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.layout.Arrangement
import java.io.File

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitTouchSlopOrCancellation
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.isImeVisible
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInParent
import kotlinx.coroutines.channels.Channel
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.BackHandler
import com.codespace.ide.ProotManager
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.max
import kotlin.math.min
import com.codespace.ide.ide.theme.IdeTheme

// ---------------------------------------------------------------------------
// Embedded Linux display: an Xvnc server inside the guest plus an in-app VNC
// (RFB 3.8) viewer. No external apps, no extra dependencies — plain
// java.net sockets, Android Bitmaps and org.json-free hand-rolled protocol.
// GUI runs target DISPLAY=:1; the viewer below renders it full-screen.
//
// Supported subset (enough for toolkits, deliberately small): version 3.8,
// None auth, 32-bit truecolor 888, Raw + CopyRect encodings, pointer events.
// Clipboard and audio are out of scope for v1.
// ---------------------------------------------------------------------------

/**
 * Display viewer: a "window" (toolbar, picture, status bar) around the live X11 screen.
 *
 * The picture is the VIEWPORT bitmap (normally exactly the app window, found by the in-guest window
 * manager), drawn with a GPU transform for zoom/pan, so the nicer look costs no extra speed.
 * Touch: one finger = mouse (tap = click, drag = press + move), two fingers = pinch zoom / pan.
 * Phone Back hides the viewer; the toolbar's Back button is the app's own Back (Esc).
 */
@Composable
@OptIn(ExperimentalLayoutApi::class)
fun DisplayViewer(
    display: VncDisplay,
    title: String,
    saveDir: File?,
    onSaved: () -> Unit,
    /** True while the guest app is running (drives the activity spinner). */
    running: Boolean,
    /** Hide the viewer, keep the app and display alive. */
    onMinimize: () -> Unit,
    /** Stop the run, drop the display connection, leave the viewer. */
    onStop: () -> Unit
) {
    // Phone Back only HIDES the viewer (the app keeps running). The app's own "back" is the
    // toolbar's Back button, which sends Esc to the guest app.
    BackHandler { onMinimize() }
    LaunchedEffect(Unit) { display.connect() }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    // Android keyboard → guest keystrokes. A 1dp invisible text field owns
    // the IME; every edit is diffed against the previous text and replayed
    // as key events (backspaces + typed characters), so Gboard composition
    // and Persian layouts work too.
    val keyboard = LocalSoftwareKeyboardController.current
    val imeVisible = WindowInsets.isImeVisible
    val kbFocus = remember { FocusRequester() }
    var kbValue by remember { mutableStateOf(TextFieldValue("")) }
    var kbReq by remember { mutableStateOf(0) }
    LaunchedEffect(kbReq) {
        if (kbReq > 0) {
            delay(30)
            try {
                kbFocus.requestFocus()
            } catch (_: Exception) {
            }
            keyboard?.show()
        }
    }
    // Picture box size and position (root coordinates) for finger -> screen mapping.
    var viewW by remember { mutableStateOf(0) }
    var viewH by remember { mutableStateOf(0) }
    var picX by remember { mutableStateOf(0f) }
    var picY by remember { mutableStateOf(0f) }
    var rootX by remember { mutableStateOf(0f) }
    var rootY by remember { mutableStateOf(0f) }
    var zoom by remember { mutableStateOf(1f) }
    var tx by remember { mutableStateOf(0f) }
    var ty by remember { mutableStateOf(0f) }
    var followWindow by remember { mutableStateOf(true) }
    var moveMode by remember { mutableStateOf(false) }
    // Bumped on every toolbar action: restarts the touch detector so no gesture state can survive a
    // viewport/zoom change (touch used to stay dead after Window/Zoom/Screen until Click was tapped).
    var gestureEpoch by remember { mutableStateOf(0) }

    val ver = display.version
    val bmp = display.bitmap
    val fw = bmp?.width ?: 0
    val fh = bmp?.height ?: 0
    val rect = display.winRect

    // Follow the app window: poll the rectangle the window manager publishes (a tiny file read).
    LaunchedEffect(Unit) {
        while (true) {
            display.pollWindowRect()
            delay(150)
        }
    }
    // Viewport = the window (or the whole screen); a new viewport starts at "fit".
    LaunchedEffect(rect?.toList(), followWindow) {
        val r = rect
        if (followWindow && r != null) {
            display.setViewport(r[0], r[1], r[2], r[3])
        } else {
            display.setViewportAll()
        }
        zoom = 1f
        tx = 0f
        ty = 0f
    }

    // LIVE picture size: the touch detector outlives recompositions, so it must never use values
    // captured from an older composition (the viewport bitmap changes size with Window/Screen).
    fun baseScale(): Float {
        val bw = display.bitmap?.width ?: 0
        val bh = display.bitmap?.height ?: 0
        return if (bw > 0 && bh > 0 && viewW > 0 && viewH > 0) min(viewW.toFloat() / bw, viewH.toFloat() / bh) else 1f
    }

    fun clampT() {
        val mx = zoom * viewW / 2f
        val my = zoom * viewH / 2f
        tx = tx.coerceIn(-mx, mx)
        ty = ty.coerceIn(-my, my)
    }

    fun zoomBy(factor: Float, px: Float = viewW / 2f, py: Float = viewH / 2f) {
        val nz = (zoom * factor).coerceIn(MIN_ZOOM, MAX_ZOOM)
        val z = nz / zoom
        val cx = viewW / 2f
        val cy = viewH / 2f
        tx = (1f - z) * (px - cx) + z * tx
        ty = (1f - z) * (py - cy) + z * ty
        zoom = nz
        clampT()
    }

    /** Picture-local finger position -> screen pixel (undo zoom/pan, then the Fit letterbox). */
    fun mapScreen(px: Float, py: Float): Pair<Int, Int> {
        val bw = display.bitmap?.width ?: 0
        val bh = display.bitmap?.height ?: 0
        if (bw <= 0 || bh <= 0 || viewW <= 0 || viewH <= 0) return 0 to 0
        val s = baseScale()
        val cx = viewW / 2f
        val cy = viewH / 2f
        val lx = (px - cx - tx) / zoom + cx
        val ly = (py - cy - ty) / zoom + cy
        val ox = (viewW - bw * s) / 2f
        val oy = (viewH - bh * s) / 2f
        val x = ((lx - ox) / s).toInt().coerceIn(0, bw - 1) + display.viewX
        val y = ((ly - oy) / s).toInt().coerceIn(0, bh - 1) + display.viewY
        return x to y
    }

    fun act(block: () -> Unit) {
        gestureEpoch++
        block()
    }

    Column(
        Modifier.fillMaxSize().background(Color(IdeTheme.BG))
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(horizontal = 10.dp)
            .onGloballyPositioned {
                val o = it.positionInRoot()
                rootX = o.x
                rootY = o.y
            }
            // MODAL shield: ONE detector owns every touch in this overlay and consumes it itself, so
            // nothing behind (editor, panel, menus) can start from a viewer touch. Children (buttons)
            // run first in the Main pass, so the toolbar keeps working.
            .pointerInput(moveMode, gestureEpoch, fw, fh) {
                awaitEachGesture {
                    try {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    down.consume()
                    val ox = picX - rootX
                    val oy = picY - rootY
                    val px0 = down.position.x - ox
                    val py0 = down.position.y - oy
                    if (px0 < 0f || py0 < 0f || px0 > viewW || py0 > viewH) {
                        while (true) {
                            val ev = awaitPointerEvent()
                            ev.changes.forEach { it.consume() }
                            if (ev.changes.none { it.pressed }) break
                        }
                        return@awaitEachGesture
                    }
                    val slop = viewConfiguration.touchSlop
                    var multi = false
                    var dragging = false
                    while (true) {
                        val ev = awaitPointerEvent()
                        ev.changes.forEach { it.consume() }
                        val pressed = ev.changes.count { it.pressed }
                        if (pressed == 0) {
                            if (!multi) {
                                if (dragging) {
                                    display.release()
                                } else if (!moveMode) {
                                    val (fx, fy) = mapScreen(px0, py0)
                                    display.tap(fx, fy)
                                }
                            }
                            break
                        }
                        if (pressed >= 2) {
                            if (dragging) {
                                display.release()
                                dragging = false
                            }
                            multi = true
                            val z = ev.calculateZoom()
                            val pan = ev.calculatePan()
                            val cen = ev.calculateCentroid(useCurrent = true)
                            zoomBy(z, cen.x - ox, cen.y - oy)
                            tx += pan.x
                            ty += pan.y
                            clampT()
                        } else if (!multi) {
                            val c = ev.changes.firstOrNull { it.id == down.id } ?: ev.changes.first()
                            if (moveMode) {
                                val d = c.position - c.previousPosition
                                tx += d.x
                                ty += d.y
                                clampT()
                            } else {
                                if (!dragging && (c.position - down.position).getDistance() > slop) {
                                    dragging = true
                                    // Press at the exact touchdown point, not at the slop point.
                                    val (fx0, fy0) = mapScreen(px0, py0)
                                    display.press(fx0, fy0)
                                }
                                if (dragging) {
                                    val (fx, fy) = mapScreen(c.position.x - ox, c.position.y - oy)
                                    display.move(fx, fy)
                                }
                            }
                        }
                    }
                    } catch (e: Exception) {
                        // A bug in one gesture must never kill the detector for good.
                        if (e is kotlinx.coroutines.CancellationException) throw e
                    }
                }
            }
    ) {
        // ---- header ----
        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    title.ifBlank { "Display" }, color = Color(IdeTheme.TEXT),
                    fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (running) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(10.dp), strokeWidth = 1.5.dp,
                            color = Color(IdeTheme.ACCENT)
                        )
                        Spacer(Modifier.width(6.dp))
                    }
                    Text(
                        display.status, color = Color(IdeTheme.DIM), fontSize = 11.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            PillButton("Hide", Color(IdeTheme.TEXT)) { onMinimize() }
            Spacer(Modifier.width(8.dp))
            PillButton("Stop", Color(IdeTheme.ERROR)) { onStop() }
        }

        // ---- the "window": toolbar + picture + status ----
        Column(
            Modifier.weight(1f).fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, Color(IdeTheme.LINE), RoundedCornerShape(14.dp))
                .background(Color(IdeTheme.PANEL))
        ) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ToolBtn("◂", "Back") { act { display.keyPress(KEY_ESC) } }
                ToolBtn("▭", "Window", active = followWindow) { act { followWindow = true; zoom = 1f; tx = 0f; ty = 0f } }
                ToolBtn("□", "Screen", active = !followWindow) { act { followWindow = false; zoom = 1f; tx = 0f; ty = 0f } }
                ToolBtn("+", "Zoom in") { act { zoomBy(1.5f) } }
                ToolBtn("−", "Zoom out") { act { zoomBy(1f / 1.5f) } }
                ToolBtn("1:1", "100%") {
                    act {
                        zoom = (1f / baseScale()).coerceIn(MIN_ZOOM, MAX_ZOOM)
                        tx = 0f
                        ty = 0f
                    }
                }
                ToolBtn(
                    if (moveMode) "↔" else "↖", if (moveMode) "Move" else "Click",
                    active = moveMode
                ) { act { moveMode = !moveMode } }
                ToolBtn("⌨", "Keys", active = imeVisible) {
                    act { if (imeVisible) keyboard?.hide() else kbReq++ }
                }
                ToolBtn("↓", "Save") {
                    gestureEpoch++
                    val b = bmp
                    if (b == null) {
                        Toast.makeText(ctx, "No picture yet", Toast.LENGTH_SHORT).show()
                    } else {
                        scope.launch(Dispatchers.IO) {
                            val saved = saveFrame(ctx, b, saveDir)
                            kotlinx.coroutines.withContext(Dispatchers.Main) {
                                Toast.makeText(
                                    ctx,
                                    if (saved != null) "Saved: $saved" else "Could not save the picture",
                                    Toast.LENGTH_SHORT
                                ).show()
                                if (saved != null) onSaved()
                            }
                        }
                    }
                }
            }
            Box(
                Modifier.weight(1f).fillMaxWidth().clipToBounds()
                    .background(Color.Black)
                    .onSizeChanged { viewW = it.width; viewH = it.height }
                    .onGloballyPositioned {
                        val o = it.positionInRoot()
                        picX = o.x
                        picY = o.y
                    }
            ) {
                BasicTextField(
                    value = kbValue,
                    onValueChange = { nv ->
                        val old = kbValue.text
                        val new = nv.text
                        var p = 0
                        val m = min(old.length, new.length)
                        while (p < m && old[p] == new[p]) p++
                        repeat(old.length - p) { display.backspace() }
                        if (new.length > p) display.typeText(new.substring(p))
                        // Keep the buffer small, but never while composing.
                        kbValue = if (nv.composition == null && new.length > 64) {
                            TextFieldValue("")
                        } else {
                            nv
                        }
                    },
                    modifier = Modifier
                        .size(1.dp)
                        .alpha(0f)
                        .focusRequester(kbFocus)
                        .onPreviewKeyEvent { ev ->
                            if (ev.type != KeyEventType.KeyDown) {
                                false
                            } else {
                                when (ev.key) {
                                    // Backspace on an EMPTY buffer produces no text
                                    // change, only this key event.
                                    Key.Backspace -> if (kbValue.text.isEmpty()) {
                                        display.backspace()
                                        true
                                    } else {
                                        false
                                    }
                                    Key.Enter -> {
                                        display.keyPress(KEY_RETURN)
                                        true
                                    }
                                    Key.Tab -> {
                                        display.keyPress(KEY_TAB)
                                        true
                                    }
                                    else -> false
                                }
                            }
                        },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        autoCorrect = false,
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Send
                    ),
                    keyboardActions = KeyboardActions(
                        onAny = { display.keyPress(KEY_RETURN) }
                    )
                )
                if (bmp != null && fw > 0 && fh > 0) {
                    // Keyed ONLY on the frame counter: nothing can tear down mid-gesture.
                    val img = key(ver) { bmp.asImageBitmap() }
                    Image(
                        bitmap = img,
                        contentDescription = "Linux display",
                        modifier = Modifier.fillMaxSize().graphicsLayer(
                            scaleX = zoom, scaleY = zoom, translationX = tx, translationY = ty
                        )
                    )
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(display.status, color = Color(IdeTheme.DIM), fontSize = 13.sp)
                    }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (moveMode) "Move mode: drag to pan · pinch to zoom"
                    else "Tap = click · drag = press + move · pinch = zoom · ◂ = app Back",
                    color = Color(IdeTheme.DIM), fontSize = 11.sp,
                    modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                val sz = if (fw > 0) "${fw}×${fh}" else "—"
                Text(
                    "$sz · ${(zoom * baseScale() * 100f).toInt()}%",
                    color = Color(IdeTheme.TEXT), fontSize = 11.sp
                )
            }
        }
        // IME or navigation bar, whichever is taller: the picture area shrinks above the
        // keyboard instead of hiding behind it.
        Spacer(
            Modifier.fillMaxWidth()
                .windowInsetsPadding(WindowInsets.ime.union(WindowInsets.navigationBars))
                .height(10.dp)
        )
    }
}
