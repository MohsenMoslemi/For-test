package com.codespace.ide.ide

// GENERATED from the tested guest scripts (see IDE-RUN-NOTES.md). Written into the guest /tmp/ide at start.

val IDE_RUN_PY = """# ide-run-v1: launches `python script.py`, `flask run`, ... from the IDE terminal as a MANAGED run:
# the IDE gets display / camera / web setup, run state (Stop, Browser, Display), and conflict warnings.
# Fail-open: if the IDE bridge does not answer, the command simply runs as usual.
import os, sys, json, signal, subprocess, http.client

BR = os.environ.get("IDE_BRIDGE", "")
TK = os.environ.get("IDE_TOKEN", "")
PYDIR = os.environ.get("IDE_PY_DIR", "/tmp/ide/py")


def call(path, obj, timeout=3.0):
    try:
        hp = BR.split("://", 1)[-1].rstrip("/")
        host, _, port = hp.partition(":")
        c = http.client.HTTPConnection(host, int(port or 80), timeout=timeout)
        c.request("POST", path, json.dumps(obj).encode(), {"X-IDE-Token": TK, "Content-Type": "application/json"})
        r = c.getresponse()
        data = r.read()
        c.close()
        return json.loads(data.decode() or "{}")
    except Exception:
        return None


def run_plain(argv):
    try:
        os.execvp(argv[0], argv)
    except OSError as e:
        sys.stderr.write("%s: %s\n" % (argv[0], e))
        sys.exit(127)


def ask(question):
    try:
        sys.stderr.write(question)
        sys.stderr.flush()
        ans = input()
    except (EOFError, KeyboardInterrupt):
        return False
    return ans.strip().lower() in ("y", "yes")


def ask_yes(question):
    try:
        sys.stderr.write(question)
        sys.stderr.flush()
        ans = input()
    except (EOFError, KeyboardInterrupt):
        return False
    return ans.strip().lower() not in ("n", "no")


def main():
    argv = sys.argv[1:]
    if not argv:
        sys.exit(2)
    if not BR or not TK:
        run_plain(argv)
    plan = call("/run/prepare", {"cwd": os.getcwd(), "argv": argv})
    if not plan or not plan.get("ok"):
        run_plain(argv)
    rid = plan["id"]
    conflict = plan.get("conflict")
    if conflict:
        sys.stderr.write(
            "\033[1;33m\u26a0 %s is already running from the %s (since %s).\033[0m\n"
            % (conflict.get("title", "This program"), conflict.get("source", "IDE"), conflict.get("started", "?"))
        )
        if sys.stdin.isatty():
            if not ask("Stop it and run it here? [y/N] "):
                sys.stderr.write("Not started.\n")
                sys.exit(130)
            call("/run/stop", {"id": conflict.get("id")})
        else:
            sys.stderr.write("Starting a second copy anyway (no terminal to ask).\n")
    prefix = (plan.get("prefix") or "").strip()
    env = dict(os.environ)
    env["IDE_RUN_ID"] = rid
    # A web framework file that does not start a server by itself (e.g. a Flask app without app.run):
    # plain python would just exit. The Run button starts the framework server instead; offer the same.
    alt_cmd = None
    alt = plan.get("alt")
    if alt and alt.get("command") and sys.stdin.isatty():
        sys.stderr.write("\033[1;36m\u2139 %s\033[0m\n" % alt.get("why", "This file does not start a server by itself."))
        if ask_yes("Start the %s instead (like the Run button)? [Y/n] " % alt.get("label", "server")):
            alt_cmd = alt["command"]
            sys.stderr.write("\033[2m${'$'} %s\033[0m\n" % alt_cmd)
    env_line = 'export PYTHONPATH="%s${'$'}{PYTHONPATH:+:${'$'}PYTHONPATH}"' % PYDIR
    last = alt_cmd if alt_cmd else 'exec "${'$'}0" "${'$'}@"'
    tail = env_line + "\n" + last
    script = (prefix + "\n" if prefix else "") + tail
    # Never let the IDE's setup break running a program: if the prepared shell snippet is not valid
    # shell, skip it (the program still runs, just without the extra setup).
    try:
        ok = subprocess.run(["/bin/sh", "-n", "-c", script], stderr=subprocess.DEVNULL).returncode == 0
    except OSError:
        ok = False
    if not ok:
        sys.stderr.write("(IDE setup skipped: invalid prefix)\n")
        script = tail
    try:
        cmd = ["/bin/sh", "-c", script] + ([] if alt_cmd else argv)
        child = subprocess.Popen(cmd, env=env)
    except OSError as e:
        sys.stderr.write("%s: %s\n" % (argv[0], e))
        call("/run/done", {"id": rid, "code": 127})
        sys.exit(127)
    call("/run/start", {"id": rid, "pid": child.pid, "pgid": os.getpgid(0), "cwd": os.getcwd(), "argv": argv})
    # Ctrl+C reaches the whole foreground group: the child handles it, we just wait.
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    signal.signal(signal.SIGTERM, lambda *_: child.terminate())
    code = child.wait()
    call("/run/done", {"id": rid, "code": code})
    sys.exit(code if code >= 0 else 128 - code)


main()
"""

val IDE_RUN_HOOK_PY = """# ide-run-hook-v1: reports the TCP ports a Python program listens on to the IDE (for the Browser button).
# Loaded through sitecustomize in every Python process of an IDE-managed run (children included, so
# Django/Flask reloaders, uvicorn --reload and gunicorn workers are covered). Inert outside the IDE.
import os, sys, socket, threading, json

_RID = os.environ.get("IDE_RUN_ID")
_BR = os.environ.get("IDE_BRIDGE")
_TK = os.environ.get("IDE_TOKEN")
_seen = set()


def _post(obj):
    try:
        import http.client
        hp = _BR.split("://", 1)[-1].rstrip("/")
        host, _, port = hp.partition(":")
        c = http.client.HTTPConnection(host, int(port or 80), timeout=2)
        body = json.dumps(obj).encode()
        c.request("POST", "/run/port", body, {"X-IDE-Token": _TK, "Content-Type": "application/json"})
        c.getresponse().read()
        c.close()
    except Exception:
        pass


def _install():
    orig = socket.socket.listen

    def listen(self, *a, **k):
        r = orig(self, *a, **k)
        try:
            if self.family in (socket.AF_INET, socket.AF_INET6) and self.type & socket.SOCK_STREAM:
                name = self.getsockname()
                port = name[1]
                key = (name[0], port)
                if port and key not in _seen:
                    _seen.add(key)
                    threading.Thread(
                        target=_post,
                        args=({"id": _RID, "host": name[0], "port": port, "pid": os.getpid()},),
                        daemon=True,
                    ).start()
        except Exception:
            pass
        return r

    socket.socket.listen = listen


if _RID and _BR and _TK:
    try:
        _install()
    except Exception:
        pass
"""

val IDE_RUN_SITECUSTOMIZE_PY = """# ide-sitecustomize-v1: loads the IDE run hook, then chains to the IDE's other shims
# (camera adapter, frame view, GUI shim) that would otherwise be shadowed by this file.
import os, sys

try:
    import ide_run_hook  # noqa: F401
except Exception:
    pass

_here = os.path.dirname(os.path.abspath(__file__))
_ALLOWED = ("/tmp/ide-camera", "/opt/ide-view", "/opt/ide-shim", "/opt/ide-camera")
for _p in list(sys.path):
    try:
        if not _p or os.path.abspath(_p) == _here:
            continue
        if not any(os.path.abspath(_p).startswith(a) for a in _ALLOWED):
            continue
        _f = os.path.join(_p, "sitecustomize.py")
        if os.path.isfile(_f):
            with open(_f, "rb") as _h:
                exec(compile(_h.read(), _f, "exec"), {"__name__": "sitecustomize", "__file__": _f})
    except Exception:
        pass
"""

val IDE_SHELL_INIT_SH = """# IDE shell integration (sourced once from PROMPT_COMMAND of the IDE terminal).
# - python / flask / uvicorn ... run as managed IDE runs (display, Browser, Stop, conflict warnings)
# - the virtual environment follows the folder (cd into another project -> its .venv)
# Everything fails open: without the IDE bridge the commands behave exactly as before.
__IDE_DIR="${'$'}{IDE_DIR:-/tmp/ide}"
__IDE_PROJ="${'$'}{IDE_PROJECTS:-/files/projects}"

__ide_ready() {
    [ -n "${'$'}IDE_BRIDGE" ] && [ -n "${'$'}IDE_TOKEN" ] && [ -x /usr/bin/python3 ] && [ -f "${'$'}__IDE_DIR/ide_run.py" ]
}

__ide_run() {
    local name="${'$'}1"; shift
    local real
    real="${'$'}(type -P "${'$'}name" 2>/dev/null)"
    if [ -z "${'$'}real" ] || ! __ide_ready; then command "${'$'}name" "${'$'}@"; return; fi
    case "${'$'}name" in
        python|python3|python3.*)
            if [ ${'$'}# -eq 0 ]; then command "${'$'}name"; return; fi
            case "${'$'}1" in
                -c|-V|--version|-h|--help|-i|-) command "${'$'}name" "${'$'}@"; return ;;
                -m)
                    case "${'$'}2" in
                        pip|pip3|venv|ensurepip|idlelib|json.tool|py_compile|compileall|site|sysconfig|pydoc)
                            command "${'$'}name" "${'$'}@"; return ;;
                    esac ;;
            esac ;;
    esac
    /usr/bin/python3 "${'$'}__IDE_DIR/ide_run.py" "${'$'}real" "${'$'}@"
}

python() { __ide_run python "${'$'}@"; }
python3() { __ide_run python3 "${'$'}@"; }
flask() { __ide_run flask "${'$'}@"; }
uvicorn() { __ide_run uvicorn "${'$'}@"; }
gunicorn() { __ide_run gunicorn "${'$'}@"; }
hypercorn() { __ide_run hypercorn "${'$'}@"; }
daphne() { __ide_run daphne "${'$'}@"; }
streamlit() { __ide_run streamlit "${'$'}@"; }
fastapi() { __ide_run fastapi "${'$'}@"; }
django-admin() { __ide_run django-admin "${'$'}@"; }

# Nearest virtual environment from ${'$'}PWD upwards, inside /files/projects only (result in __IDE_V).
__ide_find_venv() {
    __IDE_V=""
    local d="${'$'}PWD" n
    case "${'$'}d" in "${'$'}__IDE_PROJ"/*) ;; *) return 1 ;; esac
    while [ "${'$'}d" != "${'$'}__IDE_PROJ" ] && [ -n "${'$'}d" ] && [ "${'$'}d" != "/" ]; do
        for n in .venv venv env; do
            if [ -f "${'$'}d/${'$'}n/bin/activate" ]; then __IDE_V="${'$'}d/${'$'}n"; return 0; fi
        done
        d="${'$'}{d%/*}"
    done
    return 1
}

# Keep the selected base interpreter on PATH only while its project is active.
# A project's venv always takes precedence over this base interpreter.
__IDE_PROJECT_PYTHON_DIR=""
__ide_set_project_python() {
    local desired="" d="${'$'}PWD" p oldIFS part rebuilt=""
    if [ "${'$'}1" = "apply" ]; then
        case "${'$'}d" in "${'$'}__IDE_PROJ"/*) ;; *) d="" ;; esac
        while [ -n "${'$'}d" ] && [ "${'$'}d" != "${'$'}__IDE_PROJ" ] && [ "${'$'}d" != "/" ]; do
            if [ -f "${'$'}d/.pyspace_python_path" ]; then
                p="${'$'}(cat "${'$'}d/.pyspace_python_path" 2>/dev/null)"
                [ -x "${'$'}p" ] && desired="${'$'}{p%/*}"
                break
            fi
            d="${'$'}{d%/*}"
        done
    fi
    [ "${'$'}desired" = "${'$'}__IDE_PROJECT_PYTHON_DIR" ] && return 0
    if [ -n "${'$'}__IDE_PROJECT_PYTHON_DIR" ]; then
        oldIFS="${'$'}IFS"; IFS=:
        for part in ${'$'}PATH; do
            [ "${'$'}part" = "${'$'}__IDE_PROJECT_PYTHON_DIR" ] && continue
            rebuilt="${'$'}{rebuilt:+${'$'}rebuilt:}${'$'}part"
        done
        IFS="${'$'}oldIFS"
        PATH="${'$'}rebuilt"
    fi
    __IDE_PROJECT_PYTHON_DIR="${'$'}desired"
    if [ -n "${'$'}desired" ]; then PATH="${'$'}desired:${'$'}PATH"; fi
    export PATH
}

__ide_prompt() {
    __ide_find_venv
    local want="${'$'}__IDE_V"
    [ -z "${'$'}want" ] && [ -n "${'$'}IDE_VENV0" ] && [ -f "${'$'}IDE_VENV0/bin/activate" ] && [ -z "${'$'}VIRTUAL_ENV" ] && want="${'$'}IDE_VENV0"
    if [ -n "${'$'}want" ]; then
        __ide_set_project_python ""
        if [ "${'$'}VIRTUAL_ENV" != "${'$'}want" ] && { [ -z "${'$'}VIRTUAL_ENV" ] || [ "${'$'}VIRTUAL_ENV" = "${'$'}__IDE_AUTO" ]; }; then
            [ -n "${'$'}VIRTUAL_ENV" ] && type deactivate >/dev/null 2>&1 && deactivate >/dev/null 2>&1
            . "${'$'}want/bin/activate" >/dev/null 2>&1
            __IDE_AUTO="${'$'}want"
        fi
    else
        if [ -n "${'$'}VIRTUAL_ENV" ] && [ "${'$'}VIRTUAL_ENV" = "${'$'}__IDE_AUTO" ]; then
            type deactivate >/dev/null 2>&1 && deactivate >/dev/null 2>&1
            __IDE_AUTO=""
        fi
        if [ -z "${'$'}VIRTUAL_ENV" ]; then
            __ide_set_project_python "apply"
        else
            __ide_set_project_python ""
        fi
    fi
}
PROMPT_COMMAND="__ide_prompt"
__ide_prompt
"""

val IDE_KERNEL_PY = """# ide-kernel-v1: a small Jupyter-style kernel for the IDE's native notebook editor.
# Pure standard library. One client over a local TCP socket, JSON lines both ways.
#   app -> kernel: {"op":"hello","token":T} | {"op":"execute","id":N,"code":S} | {"op":"cancel","id":N} | {"op":"shutdown"}
#   kernel -> app: {"type":"ready",...} {"type":"started","id"} {"type":"stream","id","name","text"} {"type":"display","id","data","metadata"}
#                  {"type":"result","id","data","execution_count"} {"type":"error","id","ename","evalue","traceback"}
#                  {"type":"clear","id"} {"type":"done","id","status","execution_count"}
import sys, os, io, json, socket, threading, queue, traceback, ast, time, base64, subprocess, types, signal, linecache, builtins

PORT = int(sys.argv[1])
TOKEN = sys.argv[2]
CWD = sys.argv[3] if len(sys.argv) > 3 else os.getcwd()
os.environ.setdefault("MPLBACKEND", "Agg")
try:
    os.chdir(CWD)
except OSError:
    pass
if CWD not in sys.path:
    sys.path.insert(0, CWD)

MAX_STREAM = 400_000
_lock = threading.Lock()
_out = None
_cur = [0]
_count = [0]
_streamed = [0]
_running = [False]
_cancelled = set()
_cell_lock = threading.Lock()
_MAIN_THREAD_ID = threading.main_thread().ident
NS = {"__name__": "__main__", "__builtins__": builtins}


def send(obj):
    if obj.get("type") != "stream":
        _flush_streams()  # pending text must come BEFORE a result/error/display that follows it
    _send_raw(obj)


def _send_raw(obj):
    data = (json.dumps(obj, ensure_ascii=False) + "\n").encode("utf-8")
    with _lock:
        try:
            _out.write(data)
            _out.flush()
        except Exception:
            pass


_streams = []


def _flush_streams():
    for st in _streams:
        st.flush()


class Stream:
    encoding = "utf-8"

    def __init__(self, name):
        self.name = name
        self.buf = ""
        _streams.append(self)

    def _emit(self, s):
        room = MAX_STREAM - _streamed[0]
        if room <= 0:
            return
        if len(s) > room:
            s = s[:room] + "\n[output truncated]\n"
        _streamed[0] += len(s)
        _send_raw({"type": "stream", "id": _cur[0], "name": self.name, "text": s})

    def write(self, s):
        if not isinstance(s, str):
            s = str(s)
        if not s:
            return 0
        for other in _streams:  # keep stdout/stderr in the order they were written
            if other is not self:
                other.flush()
        self.buf += s
        if "\n" in self.buf or len(self.buf) > 4096:
            i = self.buf.rfind("\n") + 1 if "\n" in self.buf else len(self.buf)
            chunk, self.buf = self.buf[:i], self.buf[i:]
            self._emit(chunk)
        return len(s)

    def flush(self):
        if self.buf:
            chunk, self.buf = self.buf, ""
            self._emit(chunk)

    def isatty(self):
        return False

    def writable(self):
        return True

    def fileno(self):
        raise io.UnsupportedOperation("fileno")


# ------------------------------------------------------------------ rich display
def _bundle(obj):
    data = {}
    mb = getattr(obj, "_repr_mimebundle_", None)
    if callable(mb):
        try:
            r = mb()
            if isinstance(r, tuple):
                r = r[0]
            if isinstance(r, dict):
                for k, v in r.items():
                    data[k] = v if isinstance(v, str) else json.dumps(v)
        except Exception:
            pass
    for attr, mime in (("_repr_png_", "image/png"), ("_repr_jpeg_", "image/jpeg"), ("_repr_svg_", "image/svg+xml"),
                       ("_repr_html_", "text/html"), ("_repr_markdown_", "text/markdown"),
                       ("_repr_latex_", "text/latex"), ("_repr_json_", "application/json")):
        fn = getattr(obj, attr, None)
        if callable(fn) and mime not in data:
            try:
                v = fn()
            except Exception:
                continue
            if v is None:
                continue
            if isinstance(v, tuple):
                v = v[0]
            if isinstance(v, (bytes, bytearray)):
                v = base64.b64encode(bytes(v)).decode("ascii")
            elif not isinstance(v, str):
                v = json.dumps(v)
            data[mime] = v
    mod = type(obj).__module__ or ""
    if hasattr(obj, "savefig") and mod.startswith("matplotlib") and "image/png" not in data:
        try:
            b = io.BytesIO()
            obj.savefig(b, format="png", bbox_inches="tight", dpi=100)
            data["image/png"] = base64.b64encode(b.getvalue()).decode("ascii")
        except Exception:
            pass
    try:
        data["text/plain"] = repr(obj)
    except Exception as e:
        data["text/plain"] = "<repr failed: %s>" % e
    return data


def display(*objs, **kw):
    for o in objs:
        send({"type": "display", "id": _cur[0], "data": _bundle(o), "metadata": {}})


def _flush_figures():
    plt = sys.modules.get("matplotlib.pyplot")
    if plt is None:
        return
    try:
        nums = list(plt.get_fignums())
    except Exception:
        nums = []
    for num in nums:
        try:
            fig = plt.figure(num)
            b = io.BytesIO()
            fig.savefig(b, format="png", bbox_inches="tight", dpi=100)
            send({"type": "display", "id": _cur[0],
                  "data": {"image/png": base64.b64encode(b.getvalue()).decode("ascii"), "text/plain": "<Figure>"},
                  "metadata": {}})
        except Exception:
            pass
    try:
        plt.close("all")
    except Exception:
        pass


class _Rich:
    def __init__(self, data=None, **kw):
        self.data = data


class HTML(_Rich):
    def _repr_html_(self):
        return self.data


class Markdown(_Rich):
    def _repr_markdown_(self):
        return self.data


class Latex(_Rich):
    def _repr_latex_(self):
        return self.data


class SVG(_Rich):
    def _repr_svg_(self):
        return self.data


class JSON(_Rich):
    def _repr_json_(self):
        return self.data


class Image:
    def __init__(self, data=None, url=None, filename=None, format=None, **kw):
        self.data = data
        if data is None and filename:
            with open(filename, "rb") as f:
                self.data = f.read()
        self.format = (format or "png").lower()

    def _repr_png_(self):
        return self.data if self.format == "png" else None

    def _repr_jpeg_(self):
        return self.data if self.format in ("jpg", "jpeg") else None


def clear_output(*a, **k):
    send({"type": "clear", "id": _cur[0]})


def _install_ipython():
    import importlib.util
    try:
        if importlib.util.find_spec("IPython") is not None:
            import IPython.display as ipd
            ipd.display = display
            ipd.clear_output = clear_output
            try:
                import IPython.core.display_functions as dfn
                dfn.display = display
                dfn.clear_output = clear_output
            except Exception:
                pass
            return
    except Exception:
        pass
    ip = types.ModuleType("IPython")
    ipd = types.ModuleType("IPython.display")
    for n, v in (("display", display), ("HTML", HTML), ("Markdown", Markdown), ("Latex", Latex), ("SVG", SVG),
                 ("JSON", JSON), ("Image", Image), ("clear_output", clear_output)):
        setattr(ipd, n, v)
    ip.display = ipd
    ip.get_ipython = lambda: None
    ip.__version__ = "8.30.0"          # libraries (matplotlib, tqdm ...) inspect these
    ip.version_info = (8, 30, 0, "")
    sys.modules["IPython"] = ip
    sys.modules["IPython.display"] = ipd


# ------------------------------------------------------------------ magics
def _run_shell(cmd):
    try:
        p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, cwd=os.getcwd())
        for line in iter(p.stdout.readline, b""):
            sys.stdout.write(line.decode("utf-8", "replace"))
        p.wait()
    except KeyboardInterrupt:
        try:
            p.kill()
        except Exception:
            pass
        raise


def _interp(cmd):
    try:
        return cmd.format_map(NS)
    except Exception:
        return cmd


def _preprocess(code):
    lines = code.split("\n")
    first = lines[0].strip() if lines else ""
    if first.startswith("%%"):
        magic = first[2:].split()[0] if first[2:].split() else ""
        body = "\n".join(lines[1:])
        if magic in ("bash", "sh", "script"):
            _run_shell(body)
            return "pass"
        if magic == "html":
            display(HTML(body))
            return "pass"
        if magic in ("markdown", "md"):
            display(Markdown(body))
            return "pass"
        if magic == "writefile":
            path = first[2:].split(None, 1)[1].strip() if len(first[2:].split(None, 1)) > 1 else ""
            with open(path, "w", encoding="utf-8") as f:
                f.write(body + ("\n" if body and not body.endswith("\n") else ""))
            sys.stdout.write("Writing " + path + "\n")
            return "pass"
        if magic == "time":
            lines = lines[1:]
            return "__t0 = __import__('time').perf_counter()\n" + "\n".join(lines) + \
                   "\nprint('Wall time: %.3f s' % (__import__('time').perf_counter() - __t0))"
        raise RuntimeError("Cell magic %%" + magic + " is not supported yet")
    out = []
    in_str = None
    for ln in lines:
        s = ln.lstrip()
        if in_str is None and ln[:len(ln) - len(s)] == "" and len(s) > 1 and s[0] == "%" and s[1].isalpha():
            name, _, rest = s[1:].partition(" ")
            if name in ("matplotlib", "config", "load_ext", "autoreload", "reload_ext", "precision", "pylab", "alias_magic"):
                out.append("pass")
            elif name in ("pip", "conda", "uv"):
                _run_shell(sys.executable + " -m pip " + rest if name == "pip" else name + " " + rest)
                out.append("pass")
            elif name == "cd":
                os.chdir(os.path.expanduser(rest.strip() or "~"))
                out.append("pass")
            elif name == "pwd":
                sys.stdout.write(os.getcwd() + "\n")
                out.append("pass")
            elif name == "who" or name == "whos":
                sys.stdout.write("  ".join(sorted(k for k in NS if not k.startswith("_"))) + "\n")
                out.append("pass")
            else:
                raise RuntimeError("Magic %" + name + " is not supported yet")
            continue
        if in_str is None and len(s) > 1 and s[0] == "!" and s[1] != "=" and ln[:len(ln) - len(s)] == "":
            _run_shell(_interp(s[1:]))
            out.append("pass")
            continue
        for q in ('"' * 3, "'" * 3):
            n = ln.count(q)
            if n % 2 == 1:
                in_str = None if in_str == q else (in_str or q)
        out.append(ln)
    return "\n".join(out)


# ------------------------------------------------------------------ execution
def _format_exc():
    etype, e, tb = sys.exc_info()
    if tb is not None and tb.tb_next is not None:
        tb = tb.tb_next  # drop the kernel's own frame
    if isinstance(e, SyntaxError):
        lines = traceback.format_exception_only(etype, e)
    else:
        lines = traceback.format_exception(etype, e, tb)
    text = "".join(lines).rstrip("\n")
    return type(e).__name__, str(e), text.split("\n")


def _purge_failed_imports(tb, before):
    # A KeyboardInterrupt raised while a module is being imported can leave that
    # module (and its partially imported parents) in sys.modules. Re-importing
    # afterwards then fails with a confusing "cannot find ..." error. Walk the
    # traceback, find the modules whose code was executing, and drop the ones
    # that appeared during this cell so the next run imports them cleanly.
    names = set()
    while tb is not None:
        g = tb.tb_frame.f_globals
        spec = g.get("__spec__")
        n = getattr(spec, "name", None) or g.get("__name__")
        if isinstance(n, str):
            names.add(n)
        tb = tb.tb_next
    for n in names:
        if n in ("__main__", "builtins") or n in before:
            continue
        for k in list(sys.modules):
            if k == n or k.startswith(n + "."):
                sys.modules.pop(k, None)


def run_cell(code, cid):
    _streamed[0] = 0
    _count[0] += 1
    status = "ok"
    before_mods = set(sys.modules)
    try:
        try:
            with _cell_lock:
                _cur[0] = cid
                _running[0] = True
                cancelled_before_start = cid in _cancelled
                _cancelled.discard(cid)
            if cancelled_before_start:
                status = "error"
                send({"type": "error", "id": cid, "ename": "KeyboardInterrupt", "evalue": "Cell cancelled before execution", "traceback": ["KeyboardInterrupt"]})
                return
            send({"type": "started", "id": cid})
            src = _preprocess(code)
            linecache.cache["<cell>"] = (len(src), None, src.splitlines(True), "<cell>")
            tree = ast.parse(src, "<cell>", "exec")
            last = None
            if tree.body and isinstance(tree.body[-1], ast.Expr) and not src.rstrip().endswith(";"):
                last = ast.Expression(tree.body.pop().value)
                ast.fix_missing_locations(last)
            exec(compile(tree, "<cell>", "exec"), NS)
            if last is not None:
                val = eval(compile(last, "<cell>", "eval"), NS)
                if val is not None:
                    NS["_"] = val
                    send({"type": "result", "id": cid, "data": _bundle(val), "execution_count": _count[0]})
        except KeyboardInterrupt:
            status = "error"
            try:
                _purge_failed_imports(sys.exc_info()[2], before_mods)
            except Exception:
                pass
            send({"type": "error", "id": cid, "ename": "KeyboardInterrupt", "evalue": "", "traceback": ["KeyboardInterrupt"]})
        except SystemExit as e:
            status = "error"
            send({"type": "error", "id": cid, "ename": "SystemExit", "evalue": str(e.code), "traceback": ["SystemExit: " + str(e.code)]})
        except BaseException:
            status = "error"
            en, ev, tbl = _format_exc()
            send({"type": "error", "id": cid, "ename": en, "evalue": ev, "traceback": tbl})
    finally:
        with _cell_lock:
            _running[0] = False
            _cancelled.discard(cid)
        try:
            _flush_streams()
        except BaseException:
            pass
        try:
            _flush_figures()
        except BaseException:
            pass
        try:
            send({"type": "done", "id": cid, "status": status, "execution_count": _count[0]})
        except BaseException:
            pass


def _input(prompt=""):
    raise RuntimeError("input() is not available in notebook cells yet")


def main():
    global _out
    # The IDE starts this kernel with `nohup ... &` from a NON-interactive shell.
    # Such children inherit SIGINT as SIG_IGN, so the notebook Stop button used to
    # be a silent no-op. Restore the default handler before any cell can run.
    try:
        signal.signal(signal.SIGINT, signal.default_int_handler)
    except Exception:
        pass
    srv = socket.socket()
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", PORT))
    srv.listen(1)
    conn, _ = srv.accept()
    rf = conn.makefile("rb")
    _out = conn.makefile("wb")
    hello = rf.readline()
    try:
        ok = json.loads(hello.decode("utf-8")).get("token") == TOKEN
    except Exception:
        ok = False
    if not ok:
        return
    sys.stdout = Stream("stdout")
    sys.stderr = Stream("stderr")
    sys.stdin = io.StringIO("")
    builtins.input = _input
    NS["display"] = display
    _install_ipython()
    send({"type": "ready", "python": sys.version.split()[0], "executable": sys.executable, "cwd": os.getcwd()})
    q = queue.Queue()

    def reader():
        while True:
            line = rf.readline()
            if not line:
                q.put({"op": "shutdown"})
                return
            try:
                m = json.loads(line.decode("utf-8"))
            except Exception:
                continue
            if m.get("op") == "cancel":
                target = m.get("id")
                removed = False
                # Remove a request that has not started yet. If the main thread
                # already dequeued it, _cancelled closes the tiny handoff race.
                with q.mutex:
                    retained = []
                    while q.queue:
                        pending = q.queue.popleft()
                        if pending.get("op") == "execute" and pending.get("id") == target:
                            removed = True
                        else:
                            retained.append(pending)
                    q.queue.extend(retained)
                    q.not_full.notify_all()
                if removed:
                    _send_raw({"type": "error", "id": target, "ename": "KeyboardInterrupt", "evalue": "Cell cancelled before execution", "traceback": ["KeyboardInterrupt"]})
                    _send_raw({"type": "done", "id": target, "status": "error", "execution_count": _count[0]})
                else:
                    with _cell_lock:
                        if _cur[0] == target and _running[0]:
                            # Send while holding the state lock. The main thread
                            # cannot mark this cell finished before SIGINT is
                            # queued, so a late cancel cannot hit the next cell.
                            try:
                                main_thread_id = _MAIN_THREAD_ID
                                if main_thread_id is not None and hasattr(signal, "pthread_kill"):
                                    signal.pthread_kill(main_thread_id, signal.SIGINT)
                                else:
                                    os.kill(os.getpid(), signal.SIGINT)
                            except Exception:
                                try:
                                    os.kill(os.getpid(), signal.SIGINT)
                                except Exception:
                                    pass
                        elif _cur[0] != target:
                            # The main thread dequeued this request but has not
                            # entered run_cell yet. Its start gate consumes it.
                            _cancelled.add(target)
                        # If _cur matches but _running is false, that request
                        # has already finished; do not retain a stale cancel ID.
            else:
                q.put(m)

    threading.Thread(target=reader, daemon=True).start()
    while True:
        try:
            m = q.get()
            op = m.get("op")
            if op == "execute":
                run_cell(m.get("code", ""), m.get("id", 0))
            elif op == "ping":
                send({"type": "pong"})
            elif op == "shutdown":
                return
        except KeyboardInterrupt:
            # A late interrupt can land between cells; never let it escape main()
            # and terminate the kernel.
            continue


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
"""
