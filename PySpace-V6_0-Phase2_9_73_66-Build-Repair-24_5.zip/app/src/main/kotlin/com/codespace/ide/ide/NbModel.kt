package com.codespace.ide.ide

import com.codespace.ide.presentation.notebook.NbCell as PresentationNbCell
import com.codespace.ide.presentation.notebook.NbDoc as PresentationNbDoc
import com.codespace.ide.presentation.notebook.NbOutput as PresentationNbOutput
import com.codespace.ide.presentation.notebook.snapshotNotebook as snapshotPresentationNotebook
import com.codespace.ide.presentation.notebook.toUiDocument as toPresentationUiDocument

/** Compatibility facade for existing notebook UI call sites. */
typealias NbOutput = PresentationNbOutput
typealias NbCell = PresentationNbCell
typealias NbDoc = PresentationNbDoc

typealias NbOutputSnapshot = com.codespace.ide.domain.notebook.model.NbOutputSnapshot
typealias NbCellSnapshot = com.codespace.ide.domain.notebook.model.NbCellSnapshot
typealias NbDocSnapshot = com.codespace.ide.domain.notebook.model.NbDocSnapshot

fun newCellId(): String = com.codespace.ide.presentation.notebook.newCellId()
fun newNotebook(): NbDoc = com.codespace.ide.presentation.notebook.newNotebook()
fun NbDocSnapshot.toUiDocument(): NbDoc = this.toPresentationUiDocument()
fun snapshotNotebook(doc: NbDoc): NbDocSnapshot = snapshotPresentationNotebook(doc)
