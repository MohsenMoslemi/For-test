package com.codespace.ide.ide.codeintel
import com.codespace.ide.ide.Image
import com.codespace.ide.ide.PythonImportManager


/**
 * Deterministic auto-import catalogue for Python standard-library modules and
 * popular third-party packages. It never imports or executes project code.
 * Standard-library imports are always available; third-party imports are gated
 * by the active project's installed-package snapshot.
 */
internal object PythonAutoImportCatalog {
    private data class Entry(
        val name: String,
        val packageNames: Set<String>,
        val statement: String,
        val callable: Boolean = false,
        /** Standard-library modules are part of Python and need no pip package check. */
        val standardLibrary: Boolean = false,
    )

    private val standardLibraryEntries = listOf(
        "re", "os", "sys", "json", "math", "pathlib", "datetime", "collections",
        "itertools", "functools", "typing", "argparse", "base64", "hashlib", "csv",
        "io", "subprocess", "shutil", "glob", "random", "statistics", "time",
        "threading", "multiprocessing", "logging", "socket", "urllib", "html", "xml",
        "sqlite3", "pickle", "textwrap", "traceback", "tempfile", "uuid", "enum",
        "dataclasses", "abc", "inspect", "ast", "copy", "string", "struct", "zlib",
        "gzip", "zipfile", "tarfile", "email", "smtplib", "http", "socketserver",
        "unittest", "asyncio", "contextlib", "concurrent", "configparser", "getpass",
        "platform", "plistlib", "pprint", "queue", "sched", "secrets", "signal",
        "weakref", "warnings", "operator", "decimal", "fractions", "cmath", "locale",
        "calendar", "timeit", "pdb", "cProfile", "profile", "linecache", "tokenize",
        "token", "keyword", "codecs", "unicodedata", "difflib", "fnmatch", "fileinput",
        "resource", "mmap", "ctypes", "errno", "stat", "filecmp", "shlex",
        "pty", "tty", "termios", "fcntl", "select", "selectors", "ssl", "imaplib",
        "poplib", "ftplib", "telnetlib", "xmlrpc", "wsgiref", "cgitb", "webbrowser"
    ).map { module -> Entry(module, emptySet(), "import $module", standardLibrary = true) }

    private val entries = standardLibraryEntries + listOf(
        // Import public symbols as symbols, not merely their containing module.
        // This is important for decorators such as @dataclass.
        Entry("dataclass", emptySet(), "from dataclasses import dataclass", true, standardLibrary = true),
        Entry("field", emptySet(), "from dataclasses import field", true, standardLibrary = true),
        Entry("asdict", emptySet(), "from dataclasses import asdict", true, standardLibrary = true),
        Entry("astuple", emptySet(), "from dataclasses import astuple", true, standardLibrary = true),
        Entry("is_dataclass", emptySet(), "from dataclasses import is_dataclass", true, standardLibrary = true),
        Entry("make_dataclass", emptySet(), "from dataclasses import make_dataclass", true, standardLibrary = true),
        Entry("replace", emptySet(), "from dataclasses import replace", true, standardLibrary = true),
        Entry("np", setOf("numpy"), "import numpy as np"),
        Entry("array", setOf("numpy"), "from numpy import array", true),
        Entry("asarray", setOf("numpy"), "from numpy import asarray", true),
        Entry("arange", setOf("numpy"), "from numpy import arange", true),
        Entry("linspace", setOf("numpy"), "from numpy import linspace", true),
        Entry("zeros", setOf("numpy"), "from numpy import zeros", true),
        Entry("ones", setOf("numpy"), "from numpy import ones", true),
        Entry("ndarray", setOf("numpy"), "from numpy import ndarray", true),
        Entry("pd", setOf("pandas"), "import pandas as pd"),
        Entry("DataFrame", setOf("pandas"), "from pandas import DataFrame", true),
        Entry("Series", setOf("pandas"), "from pandas import Series", true),
        Entry("read_csv", setOf("pandas"), "from pandas import read_csv", true),
        Entry("plt", setOf("matplotlib"), "import matplotlib.pyplot as plt"),
        Entry("plot", setOf("matplotlib"), "from matplotlib.pyplot import plot", true),
        Entry("show", setOf("matplotlib"), "from matplotlib.pyplot import show", true),
        Entry("subplots", setOf("matplotlib"), "from matplotlib.pyplot import subplots", true),
        Entry("cv2", setOf("opencv-python", "opencv-python-headless", "opencv-contrib-python", "opencv-contrib-python-headless"), "import cv2"),
        Entry("pygame", setOf("pygame"), "import pygame"),
        Entry("requests", setOf("requests"), "import requests"),
        Entry("Flask", setOf("flask"), "from flask import Flask", true),
        Entry("jsonify", setOf("flask"), "from flask import jsonify", true),
        Entry("train_test_split", setOf("scikit-learn"), "from sklearn.model_selection import train_test_split", true),
        Entry("RandomForestClassifier", setOf("scikit-learn"), "from sklearn.ensemble import RandomForestClassifier", true),
        Entry("LinearRegression", setOf("scikit-learn"), "from sklearn.linear_model import LinearRegression", true),
        Entry("Image", setOf("pillow"), "from PIL import Image", true),
        Entry("App", setOf("kivy"), "from kivy.app import App", true),
        Entry("Widget", setOf("kivy"), "from kivy.uix.widget import Widget", true),
    )

    fun suggestions(
        source: String,
        caret: Int,
        prefix: String,
        installedPackages: Set<String>?,
        includeExactMatch: Boolean = false,
    ): List<PythonCompletionItem> {
        if (prefix.isBlank() || prefix.length > 40) return emptyList()
        val safeCaret = caret.coerceIn(0, source.length)
        val beforeCaret = source.substring(0, safeCaret)
        // If the identifier being completed is already bound in this buffer,
        // it is not an unresolved name. This prevents prefix collisions such
        // as `dataclass` accidentally offering `import dataclasses`.
        val bindings = PythonSourceBindings.from(beforeCaret)
        if (bindings.contains(prefix)) return emptyList()
        // Suppress Quick Import anywhere on an import statement, including
        // when the caret is on the module token before the `import` keyword.
        // Looking only at text before the caret caused `dataclasses` itself
        // to reopen Quick Import when tapped in `from dataclasses import ...`.
        val lineStart = source.lastIndexOf('\n', (safeCaret - 1).coerceAtLeast(0)).let { it + 1 }
        val lineEnd = source.indexOf('\n', safeCaret).let { if (it < 0) source.length else it }
        val currentLine = source.substring(lineStart, lineEnd).trimStart()
        if (currentLine.startsWith("import ") || currentLine == "import" ||
            currentLine.startsWith("from ") || currentLine.startsWith("from\t")) return emptyList()

        return entries.asSequence()
            .filter { it.name.startsWith(prefix, ignoreCase = true) &&
                (includeExactMatch || it.callable || !it.name.equals(prefix, true)) }
            .filter { entry ->
                entry.standardLibrary || installedPackages?.any { pkg ->
                    pkg.equalsAnyPackageName(entry.packageNames)
                } == true
            }
            .filterNot { entry -> bindings.contains(entry.name) }
            .map { entry ->
                PythonCompletionItem(
                    name = entry.name,
                    kind = "auto_import",
                    detail = "Quick import · ${entry.statement}",
                    callable = entry.callable,
                    priority = 5,
                    autoImportStatement = entry.statement,
                    autoImportSource = if (entry.standardLibrary) "Python Standard Library" else entry.packageNames.sorted().joinToString(" / "),
                    autoImportOffset = importInsertionOffset(source),
                )
            }
            .distinctBy { it.autoImportStatement }
            .take(20)
            .toList()
    }

    private fun String.equalsAnyPackageName(names: Set<String>): Boolean =
        names.any { candidate -> equals(candidate, ignoreCase = true) }

    /** Computes the header insertion delta using the same rules as Auto Import application. */
    private fun importInsertionOffset(source: String): Int {
        val marker = "# __PYSPACE_IMPORT_MARKER__"
        val inserted = PythonImportManager.insert(source, marker)
        return (inserted.first.indexOf(marker)).coerceIn(0, source.length)
    }
}
