package com.codespace.ide.ide.terminal

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Bridge from the IDE shell into the live terminal session. The terminal
 * screen registers [send] itself; IDE actions (Run, Git, pip) only call
 * [run], which also asks the shell to reveal the terminal panel.
 */
class TermBridge {
    /** Returns true only when the text was delivered to a live PTY session. */
    var send: ((String) -> Boolean)? = null
    var expand: (() -> Unit)? = null

    /**
     * Command waiting for a live shell. When Run fires while no session
     * exists yet (panel just opened), the command waits here and the fresh
     * session flushes it on startup instead of dropping it.
     */
    var pending: String? = null

    /**
     * Fired when the soft keyboard opens over the terminal panel; the IDE
     * shell grows the panel so the surface and extra-keys stay usable.
     */
    var onImeShown: (() -> Unit)? = null

    /**
     * Switches the panel to the interactive Terminal tab (terminal-bound
     * commands show their output there, never in the run console).
     */
    var goTerminal: (() -> Unit)? = null

    fun run(command: String) {
        val c = command.trim()
        if (c.isEmpty()) return
        try {
            expand?.invoke()
        } catch (_: Exception) {
        }
        try {
            goTerminal?.invoke()
        } catch (_: Exception) {
        }
        val s = send
        if (s == null) {
            pending = c + "\r"
            return
        }
        try {
            s(c + "\r")
        } catch (_: Exception) {
            pending = c + "\r"
        }
    }
}


/** Max bytes pulled from one batch run (tests/pip) into the UI process. */
const val MAX_RUN_BYTES = 600_000

/**
 * Console run state. Output itself lives in the console's own terminal
 * emulator (same engine as the interactive shell: capped scrollback,
 * virtualized rows), so this only tracks status. The Terminal tab stays
 * the user's interactive shell.
 */
class ConsoleState {
    var running by mutableStateOf(false)
    var title by mutableStateOf("Console — press ▶ to run")

    fun clear() {
        title = "Console — press ▶ to run"
    }
}

/**
 * Handle to a command-running terminal instance (IDE console). The screen
 * registers its actions; the IDE shell drives rerun/stop and learns when
 * the guest program ends. Plain vars, no recomposition.
 */
class TermController {
    /** Restart the same command immediately (no confirm dialog). */
    var rerun: (() -> Unit)? = null

    /** Close the session (guest gets SIGKILL); the exit line appears. */
    var stop: (() -> Unit)? = null

    /** Fired once when the guest program ends or fails to start. */
    var onDone: (() -> Unit)? = null

    /**
     * True while the console's session has a live child process. Registered
     * by the console terminal, cleared on dispose. Lets Rerun know whether
     * it must stop a live server first (port still bound) or can restart
     * immediately. Read-only: no session/PTY/UI state is touched.
     */
    var isAlive: (() -> Boolean)? = null

    /**
     * Read-only tail of the console transcript for IDE features that react to
     * printed output (for example, a local server URL). Registered by the
     * console terminal, cleared when it is disposed. It never writes to the
     * emulator, session, selection, scroll, focus, or keyboard state.
     */
    var transcriptTail: (() -> String)? = null
}
