package com.codespace.ide.ide.projects


import java.io.File
import java.util.Properties
import java.util.UUID

/**
 * Stages project deletions outside the Ubuntu workspace so the project remains
 * private from ordinary guest-terminal commands while the Undo window is open.
 * The staging directory is a sibling of the workspace on the same app volume.
 */
class ProjectDeletionManager(private val workspace: File) {
    private val stagingRoot = File(workspace.parentFile ?: workspace, ".pyspace-pending-project-deletions")

    data class Entry(
        val id: String,
        val projectName: String,
        val originalPath: String,
        val stagedPath: String,
        val deadlineAtMillis: Long,
    ) {
        val project: PyProject get() = PyProject(projectName, File(originalPath))
    }

    fun stage(project: PyProject, deadlineAtMillis: Long): Entry {
        require(project.dir.isDirectory) { "Project folder no longer exists." }
        if (!stagingRoot.exists() && !stagingRoot.mkdirs()) {
            throw IllegalStateException("Could not prepare secure temporary project storage.")
        }
        val id = UUID.randomUUID().toString()
        val entryDir = File(stagingRoot, id)
        if (!entryDir.mkdirs()) throw IllegalStateException("Could not prepare project deletion.")
        val stagedProject = File(entryDir, "project")
        val properties = Properties().apply {
            setProperty("id", id)
            setProperty("projectName", project.name)
            setProperty("originalPath", project.dir.absolutePath)
            setProperty("stagedPath", stagedProject.absolutePath)
            setProperty("deadlineAtMillis", deadlineAtMillis.toString())
        }
        try {
            // Persist recovery metadata before moving the user's project. If the
            // process is killed at this point, the original folder is untouched.
            File(entryDir, "pending.properties").outputStream().use { properties.store(it, "PySpace pending project deletion") }
        } catch (error: Exception) {
            entryDir.deleteRecursively()
            throw error
        }
        if (!project.dir.renameTo(stagedProject)) {
            entryDir.deleteRecursively()
            throw IllegalStateException("Could not safely stage this project for deletion.")
        }
        return Entry(id, project.name, project.dir.absolutePath, stagedProject.absolutePath, deadlineAtMillis)
    }

    fun loadPending(): List<Entry> {
        val folders = stagingRoot.listFiles()?.filter { it.isDirectory } ?: return emptyList()
        return folders.mapNotNull { folder ->
            try {
                val metadata = File(folder, "pending.properties")
                val properties = Properties().apply { metadata.inputStream().use(::load) }
                val id = properties.getProperty("id") ?: folder.name
                val name = properties.getProperty("projectName") ?: return@mapNotNull null
                val original = properties.getProperty("originalPath") ?: return@mapNotNull null
                val staged = properties.getProperty("stagedPath") ?: return@mapNotNull null
                val deadline = properties.getProperty("deadlineAtMillis")?.toLongOrNull() ?: return@mapNotNull null
                if (!File(staged).isDirectory) {
                    folder.deleteRecursively()
                    return@mapNotNull null
                }
                Entry(id, name, original, staged, deadline)
            } catch (_: Exception) { null }
        }
    }

    /** Restores to the original location, choosing a safe recovered name on collision. */
    fun restore(entry: Entry): PyProject {
        val staged = File(entry.stagedPath)
        require(staged.isDirectory) { "The pending project data is no longer available." }
        val original = File(entry.originalPath)
        var destination = original
        if (destination.exists()) {
            val parent = original.parentFile ?: workspace
            var index = 1
            do {
                destination = File(parent, "${original.name}_recovered$index")
                index++
            } while (destination.exists())
        }
        if (!staged.renameTo(destination)) throw IllegalStateException("Could not restore the project to the workspace.")
        File(entry.stagedPath).parentFile?.deleteRecursively()
        return PyProject(destination.name, destination)
    }

    fun finalizeDeletion(entry: Entry) {
        val staged = File(entry.stagedPath)
        if (staged.exists() && !deleteRecursivelySafe(staged)) {
            throw IllegalStateException("Could not permanently delete project ${entry.projectName}.")
        }
        val folder = staged.parentFile
        if (folder?.exists() == true && !folder.deleteRecursively()) {
            throw IllegalStateException("Could not clean temporary project deletion data.")
        }
        if (stagingRoot.exists() && stagingRoot.listFiles().isNullOrEmpty()) stagingRoot.delete()
    }
}
