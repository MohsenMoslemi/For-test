package com.codespace.ide.ide.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import com.codespace.ide.ide.EditorFontCatalog
import com.codespace.ide.ide.EditorSymbolCatalog
import com.codespace.ide.ide.theme.IdeTheme

/** Owns the settings screen state and persists every user preference change. */
class SettingsViewModel(
    private val repository: SettingsRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(repository.readSettings())
    val state: StateFlow<IdeSettingsState> = _state.asStateFlow()

    /** Re-read when the overlay opens so changes made elsewhere stay in sync. */
    fun refresh() {
        _state.value = repository.readSettings()
    }

    fun setThemeId(value: String) {
        val safe = com.codespace.ide.ide.theme.IdeTheme.normalizeThemeId(value)
        repository.setThemeId(safe)
        // Apply the in-memory palette immediately; Compose observes IdeTheme's state.
        com.codespace.ide.ide.theme.IdeTheme.setTheme(safe)
        _state.value = _state.value.copy(themeId = safe)
    }

    fun setCodeFontSize(value: Float) {
        val safe = value.coerceIn(9f, 24f)
        repository.setCodeFontSize(safe)
        _state.value = _state.value.copy(codeFontSize = safe)
    }

    fun setEditorFontFamilyId(value: String) {
        val safe = com.codespace.ide.ide.EditorFontCatalog.normalizeId(value)
        repository.setEditorFontFamilyId(safe)
        _state.value = _state.value.copy(editorFontFamilyId = safe)
    }

    fun setEditorSymbolOrder(value: List<String>) {
        val safe = com.codespace.ide.ide.EditorSymbolCatalog.normalize(value)
        repository.setEditorSymbolOrder(safe)
        _state.value = _state.value.copy(editorSymbolOrder = safe)
    }

    fun setTabWidth(value: Int) {
        val safe = value.coerceIn(2, 8)
        repository.setTabWidth(safe)
        _state.value = _state.value.copy(tabWidth = safe)
    }

    fun setAutoIndent(value: Boolean) {
        repository.setAutoIndent(value)
        _state.value = _state.value.copy(autoIndent = value)
    }

    fun setLineNumbers(value: Boolean) {
        repository.setLineNumbers(value)
        _state.value = _state.value.copy(lineNumbers = value)
    }

    fun setWordWrap(value: Boolean) {
        repository.setWordWrap(value)
        _state.value = _state.value.copy(wordWrap = value)
    }

    fun setWebOpenMode(value: String) {
        val safe = value.takeIf { it == "ask" || it == "ide" || it == "phone" } ?: "ask"
        repository.setWebOpenMode(safe)
        _state.value = _state.value.copy(webOpenMode = safe)
    }

    fun setPan2D(value: Boolean) {
        repository.setPan2D(value)
        _state.value = _state.value.copy(pan2D = value)
    }

    fun setPinchZoom(value: Boolean) {
        repository.setPinchZoom(value)
        _state.value = _state.value.copy(pinchZoom = value)
    }

    fun setShowDiagnosticPopup(value: Boolean) {
        repository.setShowDiagnosticPopup(value)
        _state.value = _state.value.copy(showDiagnosticPopup = value)
    }

    fun setShowCompletionPopup(value: Boolean) {
        repository.setShowCompletionPopup(value)
        _state.value = _state.value.copy(showCompletionPopup = value)
    }

    fun setShowDocumentationPopup(value: Boolean) {
        repository.setShowDocumentationPopup(value)
        _state.value = _state.value.copy(showDocumentationPopup = value)
    }

    class Factory(private val repository: SettingsRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (!modelClass.isAssignableFrom(SettingsViewModel::class.java)) {
                throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
            }
            return SettingsViewModel(repository) as T
        }
    }
}
