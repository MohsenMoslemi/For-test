package com.codespace.ide.ide

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Writes the stack trace of an uncaught exception to a file before the app dies, so the next start can show
 * it ("The app closed unexpectedly last time") instead of leaving the user to guess.
 */
object CrashLog {
    @Volatile private var installed = false

    private fun file(ctx: Context) = File(ctx.applicationContext.filesDir, "last_crash.txt")

    fun install(ctx: Context) {
        if (installed) return
        installed = true
        val f = file(ctx)
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                f.writeText(
                    "Crash at " + stamp + " on thread " + t.name + "\n\n" + android.util.Log.getStackTraceString(e)
                )
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(t, e)
        }
    }

    fun read(ctx: Context): String? = try {
        val f = file(ctx)
        if (f.isFile && f.length() > 0) f.readText().take(6000) else null
    } catch (_: Exception) {
        null
    }

    fun clear(ctx: Context) {
        try {
            file(ctx).delete()
        } catch (_: Exception) {
        }
    }
}
