package com.codespace.ide.ide.editor

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.codespace.ide.ide.codeintel.PythonSyntaxDiagnostic

/**
 * Per-document presentation state for diagnostics in the editor.
 *
 * Validation results themselves remain owned by the language-analysis layer;
 * this holder contains only transient UI decisions: which line is currently
 * being edited (so its stale underline can be suppressed) and which diagnostic
 * the user explicitly dismissed from the popup.
 */
class EditorDiagnosticsSessionState {
    var editingLine: Int? by mutableStateOf(null)

    var dismissedDiagnostic: PythonSyntaxDiagnostic? by mutableStateOf(null)

    /** A new caret line makes the previously dismissed line-card eligible again. */
    fun clearDismissal() {
        dismissedDiagnostic = null
    }
}
