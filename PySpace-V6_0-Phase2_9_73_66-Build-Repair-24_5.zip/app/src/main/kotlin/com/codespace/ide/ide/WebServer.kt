package com.codespace.ide.ide

import java.io.File
import com.codespace.ide.ide.projects.PyProject

/**
 * Smart web-run support: recognize a Python web project when Run fires, guess
 * its local server address, and upgrade that guess when the console actually
 * prints the serving URL. Pure Kotlin/file logic (no Compose, no Android), so
 * it stays unit-testable and can never disturb terminal rendering or input.
 */
data class WebServer(
    val framework: String,
    val host: String,
    val port: Int,
    val path: String = "/",
    val entryFile: String? = null,
    val launchable: Boolean = false
) {
    /** Browser URL, or null when the detected endpoint is unusable. */
    val url: String?
        get() = browserUrl(host, port, path)
}

private const val MAX_SOURCE_CHARS = 200_000
private const val MAX_SCAN_FILE_BYTES = 160_000L
private const val MAX_PROJECT_FILES = 48
private const val MAX_PROJECT_BYTES = 768_000L
private const val MAX_CONSOLE_SCAN_LINES = 500

private val HOST_KW_VALUE =
    Regex("""(?i)\bhost\s*=\s*["']?([^"',\s)\]]+)["']?""")
private val PORT_KW_VALUE =
    Regex("""(?i)\bport\s*=\s*["']?(\d{2,5})["']?""")
private val HOST_CLI_VALUE =
    Regex("""(?i)--host[=\s]+([^ \t"'`,;\]]+)""")
private val PORT_CLI_VALUE =
    Regex("""(?i)(?:--port[=\s]+|-p\s+)(\d{2,5})""")
private val BIND_CLI_VALUE =
    Regex("""(?i)(?:--bind|-b)[=\s]+([^ \t"'`,;\]]+)""")
private val SERVER_PORT_KW_VALUE =
    Regex("""(?i)\bserver[_-]?port\s*=\s*["']?(\d{2,5})["']?""")
private val RUNSERVER_VALUE =
    Regex("""(?i)\brunserver\s+(?:(\[[^\]]+\]|[^:\s]+):)?(\d{2,5})?\b""")
private val PRINTED_URL =
    Regex("""https?://[^\s"'`<>\](){}]+""")
private val HOST_PORT_LITERAL =
    Regex("""(?i)(localhost|127(?:\.\d{1,3}){3}|0\.0\.0\.0|::|\[::\])(?::(\d{2,5}))?""")
private val PORT_WORD_VALUE =
    Regex("""(?i)\bport\s*[:=]?\s*(\d{2,5})\b""")
private val SERVER_LINE_HINT =
    Regex("""(?i)\b(running|serving|serve|listening|listen|started|starting|available|local|network|address|url|server|uvicorn|flask|django|streamlit|gradio|fastapi|app|application)\b""")
private val HOST_PORT_LINE_HINT =
    Regex("""(?i)\b(running|serving|serve|listening|listen|started|starting|available|local|network|address|server|uvicorn|flask|django|streamlit|gradio|fastapi)\b""")
private val ANSI_SEQUENCE =
    Regex("\u001B\\[[0-9;?]*[A-Za-z]")

private data class FrameworkGuess(
    val framework: String,
    val defaultPort: Int,
    val defaultHost: String = "127.0.0.1",
    val markers: List<Regex>,
    val runners: List<Regex>,
    val packages: List<String>,
    val fileNames: Set<String> = emptySet()
)

private val WEB_FRAMEWORKS = listOf(
    FrameworkGuess(
        framework = "FastAPI",
        defaultPort = 8000,
        markers = listOf(
            Regex("""(?i)\bfrom\s+fastapi\s+import\b"""),
            Regex("""(?i)\bimport\s+fastapi\b"""),
            Regex("""\bFastAPI\s*\("""),
            Regex("""\bAPIRouter\s*\(""")
        ),
        runners = listOf(
            Regex("""\buvicorn\.run\s*\("""),
            Regex("""(?i)\buvicorn\s+[A-Za-z0-9_.:/-]+"""),
            Regex("""(?i)\bhypercorn\s+[A-Za-z0-9_.:/-]+"""),
            Regex("""(?i)\bgunicorn\s+[A-Za-z0-9_.:/-]+"""),
            Regex("""(?i)\bdaphne\s+[A-Za-z0-9_.:/-]+""")
        ),
        packages = listOf("fastapi", "uvicorn", "hypercorn", "gunicorn", "daphne")
    ),
    FrameworkGuess(
        framework = "Flask",
        defaultPort = 5000,
        markers = listOf(
            Regex("""(?i)\bfrom\s+flask\s+import\b"""),
            Regex("""(?i)\bimport\s+flask\b"""),
            Regex("""\bFlask\s*\(""")
        ),
        runners = listOf(
            Regex("""\.run\s*\("""),
            Regex("""(?i)\bflask\s+run\b"""),
            Regex("""\bwaitress\.serve\s*\("""),
            Regex("""\bwerkzeug\.serving\.run_simple\s*\("""),
            Regex("""(?i)\bgunicorn\s+[A-Za-z0-9_.:/-]+""")
        ),
        packages = listOf("flask", "werkzeug", "waitress", "gunicorn")
    ),
    FrameworkGuess(
        framework = "Django",
        defaultPort = 8000,
        markers = listOf(
            Regex("""(?i)\bfrom\s+django\b"""),
            Regex("""(?i)\bimport\s+django\b"""),
            Regex("""\bexecute_from_command_line\s*\("""),
            Regex("""\bget_(wsgi|asgi)_application\s*\(""")
        ),
        runners = listOf(
            Regex("""(?i)\brunserver\b"""),
            Regex("""(?i)\bgunicorn\s+[A-Za-z0-9_.:/-]+"""),
            Regex("""(?i)\bdaphne\s+[A-Za-z0-9_.:/-]+"""),
            Regex("""(?i)\buvicorn\s+[A-Za-z0-9_.:/-]+""")
        ),
        packages = listOf("django", "gunicorn", "uvicorn", "daphne"),
        fileNames = setOf("manage.py", "settings.py", "wsgi.py", "asgi.py")
    ),
    FrameworkGuess(
        framework = "Streamlit",
        defaultPort = 8501,
        defaultHost = "localhost",
        markers = listOf(
            Regex("""(?i)\bfrom\s+streamlit\s+import\b"""),
            Regex("""(?i)\bimport\s+streamlit\b"""),
            Regex("""\bst\.(title|header|subheader|write|button|sidebar|columns|tabs)\s*[\.(]""")
        ),
        runners = listOf(Regex("""(?i)\bstreamlit\s+run\b""")),
        packages = listOf("streamlit")
    ),
    FrameworkGuess(
        framework = "Gradio",
        defaultPort = 7860,
        markers = listOf(
            Regex("""(?i)\bfrom\s+gradio\s+import\b"""),
            Regex("""(?i)\bimport\s+gradio\b"""),
            Regex("""\bgr\.(Interface|Blocks|ChatInterface|TabbedInterface)\s*\(""")
        ),
        runners = listOf(
            Regex("""\.launch\s*\("""),
            Regex("""(?i)\bgradio\s+[A-Za-z0-9_.:/-]+""")
        ),
        packages = listOf("gradio")
    ),
    FrameworkGuess(
        framework = "aiohttp",
        defaultPort = 8080,
        markers = listOf(
            Regex("""(?i)\bfrom\s+aiohttp\s+import\s+[^\n]*\bweb\b"""),
            Regex("""(?i)\bfrom\s+aiohttp\.web\b"""),
            Regex("""\bweb\.Application\s*\(""")
        ),
        runners = listOf(Regex("""\bweb\.run_app\s*\(""")),
        packages = listOf("aiohttp")
    ),
    FrameworkGuess(
        framework = "Tornado",
        defaultPort = 8888,
        markers = listOf(
            Regex("""(?i)\bfrom\s+tornado\b"""),
            Regex("""(?i)\bimport\s+tornado\b"""),
            Regex("""\btornado\.web\.Application\s*\("""),
            Regex("""\btornado\.httpserver\.HTTPServer\s*\(""")
        ),
        runners = listOf(
            Regex("""\.listen\s*\("""),
            Regex("""(?i)\bIOLoop\b[^\n]{0,200}\bstart\s*\(""")
        ),
        packages = listOf("tornado")
    ),
    FrameworkGuess(
        framework = "Dash",
        defaultPort = 8050,
        markers = listOf(
            Regex("""(?i)\bfrom\s+dash\s+import\b"""),
            Regex("""(?i)\bimport\s+dash\b"""),
            Regex("""\bDash\s*\(""")
        ),
        runners = listOf(
            Regex("""\.run_server\s*\("""),
            Regex("""\.run\s*\(""")
        ),
        packages = listOf("dash")
    ),
    FrameworkGuess(
        framework = "Sanic",
        defaultPort = 8000,
        markers = listOf(
            Regex("""(?i)\bfrom\s+sanic\s+import\b"""),
            Regex("""(?i)\bimport\s+sanic\b"""),
            Regex("""\bSanic\s*\(""")
        ),
        runners = listOf(Regex("""\.run\s*\(""")),
        packages = listOf("sanic")
    ),
    FrameworkGuess(
        framework = "Quart",
        defaultPort = 5000,
        markers = listOf(
            Regex("""(?i)\bfrom\s+quart\s+import\b"""),
            Regex("""(?i)\bimport\s+quart\b"""),
            Regex("""\bQuart\s*\(""")
        ),
        runners = listOf(Regex("""\.run\s*\(""")),
        packages = listOf("quart", "hypercorn")
    ),
    FrameworkGuess(
        framework = "Bottle",
        defaultPort = 8080,
        markers = listOf(
            Regex("""(?i)\bfrom\s+bottle\s+import\b"""),
            Regex("""(?i)\bimport\s+bottle\b"""),
            Regex("""\bBottle\s*\("""),
            Regex("""@(route|get|post|put|delete|patch)\s*\(""")
        ),
        runners = listOf(
            Regex("""\bbottle\.run\s*\("""),
            Regex("""[^\w.]run\s*\(""")
        ),
        packages = listOf("bottle")
    ),
    FrameworkGuess(
        framework = "Falcon",
        defaultPort = 8000,
        markers = listOf(
            Regex("""(?i)\bfrom\s+falcon\s+import\b"""),
            Regex("""(?i)\bimport\s+falcon\b"""),
            Regex("""\bfalcon\.App\w*\s*\(""")
        ),
        runners = listOf(
            Regex("""\bmake_server\s*\("""),
            Regex("""\bserve_forever\s*\("""),
            Regex("""\brun_simple\s*\("""),
            Regex("""\bwaitress\.serve\s*\("""),
            Regex("""(?i)\bgunicorn\s+[A-Za-z0-9_.:/-]+"""),
            Regex("""(?i)\buvicorn\s+[A-Za-z0-9_.:/-]+""")
        ),
        packages = listOf("falcon", "waitress", "gunicorn", "uvicorn")
    ),
    FrameworkGuess(
        framework = "Python web server",
        defaultPort = 8000,
        markers = listOf(
            Regex("""(?i)\bfrom\s+http\.server\s+import\b"""),
            Regex("""(?i)\bimport\s+http\.server\b"""),
            Regex("""(?i)\bfrom\s+socketserver\s+import\b"""),
            Regex("""(?i)\bimport\s+socketserver\b"""),
            Regex("""(?i)\bfrom\s+wsgiref\.simple_server\s+import\b"""),
            Regex("""(?i)\bimport\s+cherrypy\b"""),
            Regex("""(?i)\bfrom\s+cherrypy\s+import\b""")
        ),
        runners = listOf(
            Regex("""\bserve_forever\s*\("""),
            Regex("""\bserve\s*\("""),
            Regex("""\brun_simple\s*\("""),
            Regex("""\bwaitress\.serve\s*\("""),
            Regex("""\bcherrypy\.quickstart\s*\(""")
        ),
        packages = listOf("waitress", "cherrypy", "gunicorn", "uvicorn")
    )
)

/** Loopback/wildcard host shown to the Android browser as 127.0.0.1. */
fun browserHost(rawHost: String): String {
    val trimmed = rawHost.trim().trim('"', '\'')
    val lower = trimmed.lowercase()
    return when {
        lower.isEmpty() || lower == "*" || lower == "0.0.0.0" || lower == "::" ||
            lower == "[::]" || lower == "0:0:0:0:0:0:0:0" -> "127.0.0.1"
        lower == "localhost" || lower == "127.0.0.1" -> lower
        lower.startsWith("[") && lower.endsWith("]") -> lower
        lower.contains(":") && !lower.contains(".") -> "[$lower]"
        else -> trimmed
    }
}

/** Local server URL for the browser, or null for an unusable host/port. */
fun browserUrl(host: String, port: Int, path: String = "/"): String? {
    if (port !in 1..65535) return null
    val cleanPath = path.trim().ifEmpty { "/" }.let { if (it.startsWith("/")) it else "/$it" }
    return "http://" + browserHost(host) + ":" + port + cleanPath
}

private fun isLoopbackHost(host: String): Boolean {
    val h = host.trim().trim('"', '\'').lowercase()
    return h == "localhost" || h == "127.0.0.1" || h == "0.0.0.0" ||
        h == "::" || h == "[::]" || h == "0:0:0:0:0:0:0:0" || h == "*"
}

private fun firstInt(match: MatchResult?): Int? {
    if (match == null) return null
    return match.groupValues.drop(1).firstOrNull { it.isNotEmpty() }
        ?.toIntOrNull()?.takeIf { it in 1..65535 }
}

private fun splitBindHostPort(raw: String?): Pair<String?, Int?> {
    if (raw.isNullOrBlank()) return null to null
    val v = raw.trim().trim('"', '\'')
    if (v.startsWith("unix:", ignoreCase = true) || v.contains("/")) return null to null
    if (v.startsWith("[")) {
        val end = v.indexOf(']')
        if (end > 0) {
            val host = v.substring(0, end + 1)
            val port = v.substring(end + 1).trimStart(':').toIntOrNull()
                ?.takeIf { it in 1..65535 }
            return host to port
        }
        return null to null
    }
    val cut = v.lastIndexOf(':')
    if (cut > 0 && v.indexOf(':') == cut) {
        return v.substring(0, cut).ifEmpty { null } to
            v.substring(cut + 1).toIntOrNull()?.takeIf { it in 1..65535 }
    }
    return v to null
}

private fun cleanEndpointHost(raw: String?): String? {
    if (raw.isNullOrBlank()) return null
    val host = raw.trim().trim('"', '\'')
    if (host.isEmpty()) return null
    val lower = host.lowercase()
    if (lower == "*" || lower == "0.0.0.0" || lower == "::" || lower == "[::]" ||
        lower == "0:0:0:0:0:0:0:0" || lower == "localhost"
    ) {
        return host
    }
    if (lower.matches(Regex("""127(?:\.\d{1,3}){3}"""))) return host
    if (host.matches(Regex("""\[[0-9a-fA-F:.]+\]"""))) return host
    if (host.matches(Regex("""[0-9a-fA-F:.]+""")) && host.contains(":")) return host
    // A bare name is accepted only when it looks like a real DNS host. This
    // keeps variable references such as host=host from becoming a fake URL.
    if (host.matches(Regex("""(?i)[a-z0-9](?:[a-z0-9.-]{0,253}[a-z0-9])?""")) &&
        (host.contains(".") || host.equals("localhost", ignoreCase = true))
    ) {
        return host
    }
    return null
}

private fun explicitEndpoint(window: String): Pair<String?, Int?> {
    val runserver = RUNSERVER_VALUE.find(window)
    val (runserverHost, runserverPort) = if (runserver == null) {
        null to null
    } else {
        runserver.groupValues.getOrNull(1)?.ifEmpty { null } to firstInt(runserver)
    }
    val (bindHost, bindPort) = splitBindHostPort(BIND_CLI_VALUE.find(window)?.groupValues?.getOrNull(1))
    val host = cleanEndpointHost(
        HOST_KW_VALUE.find(window)?.groupValues?.getOrNull(1)?.ifEmpty { null }
            ?: HOST_CLI_VALUE.find(window)?.groupValues?.getOrNull(1)?.ifEmpty { null }
            ?: bindHost
            ?: runserverHost
    )
    val port = firstInt(PORT_KW_VALUE.find(window))
        ?: firstInt(PORT_CLI_VALUE.find(window))
        ?: firstInt(SERVER_PORT_KW_VALUE.find(window))
        ?: bindPort
        ?: runserverPort
    return host to port
}

private fun balancedCallArguments(text: String, openParen: Int): String? {
    if (openParen < 0 || openParen >= text.length || text[openParen] != '(') return null
    var depth = 0
    var i = openParen
    val end = (openParen + 800).coerceAtMost(text.length)
    while (i < end) {
        when (text[i]) {
            '(' -> depth++
            ')' -> {
                depth--
                if (depth == 0) return text.substring(openParen + 1, i)
            }
        }
        i++
    }
    return null
}

private fun endpointNearRunner(text: String, framework: FrameworkGuess): Pair<String?, Int?> {
    val matches = framework.runners.flatMap { it.findAll(text) }.sortedBy { it.range.first }
    for (match in matches) {
        val lineStart = text.lastIndexOf('\n', match.range.first - 1) + 1
        val lineEnd = text.indexOf('\n', match.range.last).takeIf { it >= 0 } ?: text.length
        val line = text.substring(lineStart.coerceAtLeast(0), lineEnd.coerceAtMost(text.length))
        val lineEndpoint = explicitEndpoint(line)
        if (lineEndpoint.first != null || lineEndpoint.second != null) return lineEndpoint
        // For a Python call, only inspect its own argument list. A fixed
        // window across adjacent lines could otherwise borrow an unrelated
        // database port or host from nearby configuration.
        if (match.value.contains('(')) {
            val args = balancedCallArguments(text, text.indexOf('(', match.range.first))
            if (args != null) {
                val argEndpoint = explicitEndpoint(args)
                if (argEndpoint.first != null || argEndpoint.second != null) return argEndpoint
            }
        }
    }
    return null to null
}

private fun frameworkMatches(framework: FrameworkGuess, fileName: String, lowerSource: String): Boolean {
    if (framework.fileNames.contains(fileName.lowercase()) && lowerSource.contains(framework.framework.lowercase())) {
        return true
    }
    return framework.markers.any { it.containsMatchIn(lowerSource) }
}

/**
 * Source without full-line `#` comments. A commented example such as
 * `# uvicorn main:app --port 8000` identifies the project as web-capable,
 * but it must not mark the file as launchable because Run does not execute
 * comments.
 */
private fun codeText(source: String): String {
    return source.lineSequence().filter { line ->
        val trimmed = line.trimStart()
        trimmed.isNotEmpty() && !trimmed.startsWith("#")
    }.joinToString("\n")
}

/**
 * In-memory detection for the file Run is executing. Cheap enough for the UI
 * thread: the caller already holds the editor buffer, so no disk IO happens.
 */
fun detectWebServerFromSource(
    fileName: String,
    source: String,
    isRunEntry: Boolean = true
): WebServer? {
    val ext = fileName.substringAfterLast('.', "").lowercase()
    if (ext != "py" && ext != "pyw" && ext != "pyi") return null
    val text = if (source.length > MAX_SOURCE_CHARS) source.substring(0, MAX_SOURCE_CHARS) else source
    if (text.isBlank()) return null
    val lower = text.lowercase()
    val code = codeText(text)
    var fallback: WebServer? = null
    for (framework in WEB_FRAMEWORKS) {
        if (!frameworkMatches(framework, fileName, lower)) continue
        val hasRunner = framework.runners.any { it.containsMatchIn(code) }
        val (host, port) = endpointNearRunner(code, framework)
        val server = WebServer(
            framework = framework.framework,
            host = host ?: framework.defaultHost,
            port = port ?: framework.defaultPort,
            entryFile = fileName.ifBlank { null },
            launchable = isRunEntry && hasRunner
        )
        if (server.launchable && server.url != null) return server
        if (fallback == null && server.url != null) fallback = server
    }
    return fallback
}

private fun readWebText(file: File, maxChars: Long): String {
    return try {
        if (!file.isFile || file.length() > maxChars || maxChars <= 0) return ""
        file.readText()
    } catch (_: Exception) {
        ""
    }
}

private fun isSkippableDir(name: String): Boolean {
    if (name.isEmpty()) return true
    if (name.startsWith(".")) return true
    if (name == ".venv" || name == "venv" || name == "env" || name == "__pycache__" ||
        name == ".git" || name == ".hg" || name == ".svn" || name == "node_modules" ||
        name == ".pytest_cache" || name == ".mypy_cache" || name == ".ruff_cache" ||
        name == ".tox" || name == "build" || name == "dist" || name == "site-packages" ||
        name == ".cache"
    ) {
        return true
    }
    return name.endsWith(".egg-info")
}

private fun isUnder(rootCanonical: String, file: File): Boolean {
    return try {
        val p = file.canonicalPath
        p == rootCanonical || p.startsWith(rootCanonical + File.separator)
    } catch (_: Exception) {
        false
    }
}

private fun collectServerCandidates(root: File, activeFile: File?): List<File> {
    val rootCanonical = try {
        root.canonicalPath
    } catch (_: Exception) {
        return emptyList()
    }
    val found = LinkedHashSet<File>()
    if (activeFile != null && isUnder(rootCanonical, activeFile) && activeFile.isFile) {
        found.add(activeFile)
    }
    var bytes = 0L
    val queue = ArrayDeque<Pair<File, Int>>()
    queue.add(root to 0)
    while (queue.isNotEmpty() && found.size < MAX_PROJECT_FILES && bytes < MAX_PROJECT_BYTES) {
        val (dir, depth) = queue.removeFirst()
        val kids = try {
            dir.listFiles()?.sortedBy { it.name.lowercase() } ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }
        for (kid in kids) {
            if (found.size >= MAX_PROJECT_FILES || bytes >= MAX_PROJECT_BYTES) break
            if (!isUnder(rootCanonical, kid)) continue
            if (kid.isDirectory) {
                if (depth < 3 && shouldDescend(kid)) queue.add(kid to depth + 1)
            } else if (kid.isFile) {
                val ext = kid.extension.lowercase()
                if ((ext == "py" || ext == "pyw" || ext == "pyi") &&
                    kid.length() in 1..MAX_SCAN_FILE_BYTES
                ) {
                    if (found.add(kid)) bytes += kid.length()
                }
            }
        }
    }
    fun rank(f: File): Int {
        return when (f.name.lowercase()) {
            "app.py", "main.py", "server.py", "application.py", "asgi.py", "wsgi.py",
            "manage.py", "streamlit_app.py" -> 0
            else -> if (f.parent == rootCanonical) 1 else 2
        }
    }
    return found.sortedWith(compareBy({ rank(it) }, { it.name.lowercase() }))
}

private fun shouldDescend(dir: File): Boolean = !isSkippableDir(dir.name)

private fun readDependencyText(root: File): String {
    val rootCanonical = try {
        root.canonicalPath
    } catch (_: Exception) {
        return ""
    }
    val names = listOf(
        "requirements.txt", "requirements-dev.txt", "requirements-prod.txt",
        "pyproject.toml", "setup.py", "setup.cfg", "Pipfile", "Pipfile.lock",
        "environment.yml", "environment.yaml", "conda.yml", "Procfile",
        "Dockerfile", "docker-compose.yml", "docker-compose.yaml"
    )
    val sb = StringBuilder()
    for (name in names) {
        val f = File(root, name)
        if (!isUnder(rootCanonical, f)) continue
        val text = readWebText(f, 100_000L)
        if (text.isNotBlank()) sb.append('\n').append(text)
        if (sb.length > 400_000) break
    }
    try {
        File(root, "requirements").listFiles()
            ?.filter { it.isFile && it.name.endsWith(".txt", ignoreCase = true) }
            ?.sortedBy { it.name.lowercase() }
            ?.take(5)
            ?.forEach {
                if (isUnder(rootCanonical, it)) {
                    val text = readWebText(it, 100_000L)
                    if (text.isNotBlank()) sb.append('\n').append(text)
                }
            }
    } catch (_: Exception) {
    }
    return sb.toString()
}

private fun deploymentEndpoint(root: File): Pair<String?, Int?> {
    val rootCanonical = try {
        root.canonicalPath
    } catch (_: Exception) {
        return null to null
    }
    val texts = StringBuilder()
    for (name in listOf("Procfile", "Dockerfile", "docker-compose.yml", "docker-compose.yaml")) {
        val f = File(root, name)
        if (isUnder(rootCanonical, f)) texts.append('\n').append(readWebText(f, 100_000L))
    }
    val text = texts.toString()
    if (text.isBlank()) return null to null
    val (bindHost, bindPort) = splitBindHostPort(BIND_CLI_VALUE.find(text)?.groupValues?.getOrNull(1))
    val host = cleanEndpointHost(
        HOST_CLI_VALUE.find(text)?.groupValues?.getOrNull(1)?.ifEmpty { null }
            ?: HOST_KW_VALUE.find(text)?.groupValues?.getOrNull(1)?.ifEmpty { null }
            ?: bindHost
    )
    val port = firstInt(PORT_CLI_VALUE.find(text))
        ?: firstInt(PORT_KW_VALUE.find(text))
        ?: firstInt(SERVER_PORT_KW_VALUE.find(text))
        ?: firstInt(PORT_WORD_VALUE.find(text))
        ?: bindPort
    return host to port
}

private fun dependencyNames(lowerDependencies: String): Set<String> {
    return lowerDependencies.split(Regex("""[^a-z0-9_.-]+"""))
        .map { it.trim('.', '-', '_') }
        .filter { it.isNotEmpty() }
        .toSet()
}

private fun webServerFromDependencies(
    dependencies: String,
    deployment: Pair<String?, Int?>
): WebServer? {
    if (dependencies.isBlank()) return null
    val lower = dependencies.lowercase()
    val names = dependencyNames(lower)
    for (framework in WEB_FRAMEWORKS) {
        if (framework.packages.any { names.contains(it) }) {
            val server = WebServer(
                framework = framework.framework,
                host = deployment.first ?: framework.defaultHost,
                port = deployment.second ?: framework.defaultPort,
                launchable = false
            )
            if (server.url != null) return server
        }
    }
    return null
}

/**
 * Project-wide detection. Disk-bound: call from a background coroutine, not
 * from composition. The active editor buffer is checked first because Run
 * always executes that file.
 */
fun detectWebServerInProject(
    project: PyProject,
    activeFile: File? = null,
    activeSource: String? = null
): WebServer? {
    val root = project.dir
    val rootCanonical = try {
        root.canonicalPath
    } catch (_: Exception) {
        return null
    }
    val immediate = if (activeFile != null && isUnder(rootCanonical, activeFile)) {
        val text = activeSource ?: readWebText(activeFile, MAX_SCAN_FILE_BYTES)
        detectWebServerFromSource(activeFile.name, text, isRunEntry = true)
    } else {
        null
    }
    if (immediate?.launchable == true && immediate.url != null) return immediate
    val deployment = deploymentEndpoint(root)
    val dependencies = readDependencyText(root)
    var best = immediate
    for (file in collectServerCandidates(root, activeFile)) {
        val isActive = activeFile != null && try {
            file.canonicalPath == activeFile.canonicalPath
        } catch (_: Exception) {
            false
        }
        // The active file was already scored above; rescoring would only
        // duplicate it inside the bounded project walk.
        if (isActive && activeSource != null) continue
        val text = if (isActive) {
            activeSource ?: readWebText(file, MAX_SCAN_FILE_BYTES)
        } else {
            readWebText(file, MAX_SCAN_FILE_BYTES)
        }
        val candidate = detectWebServerFromSource(file.name, text, isRunEntry = isActive)
            ?: continue
        val merged = candidate.copy(
            host = deployment.first ?: candidate.host,
            port = deployment.second ?: candidate.port
        )
        if (merged.url == null) continue
        if (merged.launchable) return merged
        if (best == null) best = merged
    }
    return best ?: webServerFromDependencies(dependencies, deployment)
}

// ---------------------------------------------------------------------------
// Automatic framework server commands: Run executes these instead of
// `python file` when the active file belongs to a web framework but would
// not start a server on its own (a FastAPI module without uvicorn.run, a
// Flask app without app.run, manage.py without runserver, a Streamlit
// script). Files that already launch their own server keep running exactly
// as written — the IDE never overrides explicit code.
// ---------------------------------------------------------------------------

/** A generated server command plus the server entry it serves. */
data class WebAutoRun(
    val server: WebServer,
    val command: String,
    val entryRel: String
)

private fun findAppVar(code: String, factory: String): String? {
    val name = Regex("""(\w+)\s*=\s*""" + Regex.escape(factory) + """\s*\(""")
        .find(code)?.groupValues?.getOrNull(1).orEmpty()
    return if (name.matches(Regex("""[A-Za-z_][A-Za-z0-9_]*"""))) name else null
}

private fun relPathUnder(rootCanonical: String, file: File): String? {
    return try {
        val p = file.canonicalPath
        if (p == rootCanonical || !p.startsWith(rootCanonical + File.separator)) return null
        p.removePrefix(rootCanonical + File.separator).replace(File.separatorChar, '/')
    } catch (_: Exception) {
        null
    }
}

private fun modulePathForFile(rootCanonical: String, file: File): String? {
    val rel = relPathUnder(rootCanonical, file) ?: return null
    val base = when {
        rel.endsWith(".py") -> rel.removeSuffix(".py")
        rel.endsWith(".pyw") -> rel.removeSuffix(".pyw")
        rel.endsWith(".pyi") -> rel.removeSuffix(".pyi")
        else -> return null
    }
    val dotted = when {
        base.endsWith("/__init__") -> base.removeSuffix("/__init__")
        base.endsWith("/__main__") -> base.removeSuffix("/__main__")
        base == "__init__" || base == "__main__" -> return null
        else -> base
    }.replace('/', '.')
    if (dotted.isEmpty()) return null
    val part = Regex("""[A-Za-z_][A-Za-z0-9_]*""")
    if (!dotted.split('.').all { it.matches(part) }) return null
    return dotted
}

/** Bind address for a generated server command (wildcards become 127.0.0.1). */
private fun bindHostForCommand(host: String): String {
    val h = host.trim()
    val l = h.lowercase()
    if (l.isEmpty() || l == "*" || l == "0.0.0.0" || l == "::" || l == "[::]" ||
        l == "0:0:0:0:0:0:0:0" || l == "localhost" || l == "127.0.0.1"
    ) {
        return "127.0.0.1"
    }
    if (l.startsWith("[") && l.endsWith("]")) return l.removePrefix("[").removeSuffix("]")
    return h
}

private fun findManagePy(root: File, rootCanonical: String): File? {
    return try {
        val direct = File(root, "manage.py")
        if (direct.isFile && isUnder(rootCanonical, direct)) return direct
        val queue = ArrayDeque<Pair<File, Int>>()
        queue.add(root to 0)
        var seen = 0
        while (queue.isNotEmpty() && seen < 400) {
            val (dir, depth) = queue.removeFirst()
            val kids = try {
                dir.listFiles()?.sortedBy { it.name.lowercase() } ?: emptyList()
            } catch (_: Exception) {
                emptyList()
            }
            for (kid in kids) {
                seen++
                if (seen > 400) break
                if (!isUnder(rootCanonical, kid)) continue
                if (kid.isFile && kid.name == "manage.py") return kid
                if (kid.isDirectory && depth < 2 && !isSkippableDir(kid.name)) {
                    queue.add(kid to depth + 1)
                }
            }
        }
        null
    } catch (_: Exception) {
        null
    }
}

/**
 * Framework server command for the file Run is executing, or null when plain
 * `python file` is already the right thing (explicit in-code server runner)
 * or no reliable command can be built. Pure logic: safe to unit-test, never
 * touches the terminal, session, or UI state.
 */
fun webAutoRun(
    projectDir: File,
    file: File,
    sourceText: String?,
    detected: WebServer?,
    pythonBin: String
): WebAutoRun? {
    if (detected == null || detected.launchable || detected.url == null) return null
    val rootCanonical = try {
        projectDir.canonicalPath
    } catch (_: Exception) {
        return null
    }
    val text = sourceText ?: readWebText(file, MAX_SCAN_FILE_BYTES)
    if (text.isBlank()) return null
    val code = codeText(text)
    val bin = pythonBin.ifBlank { "python3" }
    val bind = bindHostForCommand(detected.host)
    return when (detected.framework) {
        "FastAPI" -> {
            if (!code.contains(Regex("""\bFastAPI\s*\("""))) return null
            val module = modulePathForFile(rootCanonical, file) ?: return null
            val appVar = findAppVar(code, "FastAPI") ?: "app"
            val rel = relPathUnder(rootCanonical, file) ?: file.name
            val server = detected.copy(entryFile = file.name, launchable = true)
            WebAutoRun(
                server,
                "$bin -m uvicorn $module:$appVar --host $bind --port ${detected.port}",
                rel
            )
        }
        "Flask" -> {
            if (!code.contains(Regex("""\bFlask\s*\("""))) return null
            val module = modulePathForFile(rootCanonical, file) ?: return null
            val rel = relPathUnder(rootCanonical, file) ?: file.name
            val server = detected.copy(entryFile = file.name, launchable = true)
            WebAutoRun(
                server,
                "$bin -m flask --app $module run --host $bind --port ${detected.port}",
                rel
            )
        }
        "Django" -> {
            val manage = if (file.name == "manage.py") file
            else findManagePy(projectDir, rootCanonical) ?: return null
            val manageRel = relPathUnder(rootCanonical, manage) ?: return null
            val hostPort = if (":" in bind) "[$bind]:${detected.port}" else "$bind:${detected.port}"
            val server = detected.copy(entryFile = manage.name, launchable = true)
            WebAutoRun(server, "$bin \"$manageRel\" runserver $hostPort", manageRel)
        }
        "Streamlit" -> {
            val rel = relPathUnder(rootCanonical, file) ?: return null
            val server = detected.copy(entryFile = file.name, launchable = true)
            WebAutoRun(
                server,
                "$bin -m streamlit run \"$rel\" --server.address $bind --server.port ${detected.port}",
                rel
            )
        }
        else -> null
    }
}

private fun cleanPrintedUrl(raw: String): String? {
    val v = raw.trim().trimEnd('.', ',', ';', ':', '!', '?', ')', ']', '}', '>', '"', '\'')
    if (v.length < 11 || !v.contains("://")) return null
    return v
}

private fun splitPrintedUrl(raw: String): Triple<String, String, String>? {
    val schemeEnd = raw.indexOf("://")
    if (schemeEnd <= 0) return null
    val scheme = raw.substring(0, schemeEnd).lowercase()
    if (scheme != "http" && scheme != "https") return null
    val rest = raw.substring(schemeEnd + 3)
    if (rest.isEmpty()) return null
    val pathStart = rest.indexOfFirst { it == '/' || it == '?' || it == '#' }
    val authority = if (pathStart < 0) rest else rest.substring(0, pathStart)
    val path = if (pathStart < 0) "/" else rest.substring(pathStart)
    if (authority.isEmpty()) return null
    val hostPort = authority.substringAfterLast('@')
    if (hostPort.isEmpty()) return null
    val host: String
    val portText: String?
    if (hostPort.startsWith("[")) {
        val end = hostPort.indexOf(']')
        if (end <= 0) return null
        host = hostPort.substring(0, end + 1)
        portText = hostPort.substring(end + 1).trimStart(':').ifEmpty { null }
    } else {
        val cut = hostPort.lastIndexOf(':')
        if (cut >= 0 && hostPort.indexOf(':') == cut) {
            host = hostPort.substring(0, cut)
            portText = hostPort.substring(cut + 1).ifEmpty { null }
        } else {
            host = hostPort
            portText = null
        }
    }
    if (host.isEmpty()) return null
    return Triple(scheme, host, path.ifEmpty { "/" })
}

private fun normalizePrintedUrl(raw: String): String? {
    val cleaned = cleanPrintedUrl(raw) ?: return null
    val (scheme, host, path) = splitPrintedUrl(cleaned) ?: return null
    val authority = cleaned.substringAfter("://").substringBefore('/').substringBefore('?')
        .substringBefore('#').substringAfterLast('@')
    val portText = if (authority.startsWith("[")) {
        val end = authority.indexOf(']')
        if (end < 0) return null
        authority.substring(end + 1).trimStart(':')
    } else {
        val cut = authority.lastIndexOf(':')
        if (cut < 0 || authority.indexOf(':') != cut) null
        else authority.substring(cut + 1)
    }
    val port = if (portText.isNullOrEmpty()) {
        if (scheme == "https") 443 else 80
    } else {
        portText.toIntOrNull()?.takeIf { it in 1..65535 } ?: return null
    }
    val normalizedHost = browserHost(host)
    return "$scheme://$normalizedHost:$port$path"
}

private fun printedHost(raw: String): String? {
    val cleaned = cleanPrintedUrl(raw) ?: return null
    return splitPrintedUrl(cleaned)?.second
}

private fun directServingUrl(line: String, onlyLoopback: Boolean): String? {
    val hint = SERVER_LINE_HINT.containsMatchIn(line.lowercase())
    for (match in PRINTED_URL.findAll(line)) {
        val normalized = normalizePrintedUrl(match.value) ?: continue
        val host = printedHost(match.value) ?: continue
        if (isLoopbackHost(host)) return normalized
        if (!onlyLoopback && hint) return normalized
    }
    return null
}

private fun hostPortServingUrl(line: String): String? {
    if (!HOST_PORT_LINE_HINT.containsMatchIn(line.lowercase())) return null
    for (match in HOST_PORT_LITERAL.findAll(line)) {
        val host = match.groupValues.getOrNull(1).orEmpty()
        if (host.isEmpty()) continue
        var port = match.groupValues.getOrNull(2)?.toIntOrNull()?.takeIf { it in 1..65535 }
        if (port == null) {
            port = firstInt(PORT_WORD_VALUE.find(line))
        }
        if (port == null) continue
        browserUrl(host, port)?.let { return it }
    }
    val servePort = firstInt(
        Regex("""(?i)\b(?:serving|running|listening|started|local|network)\b[^\n]{0,80}?\bport\s*[:=]?\s*(\d{2,5})""")
            .find(line)
    )
    if (servePort != null) {
        browserUrl("127.0.0.1", servePort)?.let { return it }
    }
    return null
}

/**
 * Latest serving URL in console output: printed URLs win over reconstructed
 * bare host:port text, and loopback URLs win over remote share links.
 * Returns a browser-ready URL with 0.0.0.0/:: normalized to 127.0.0.1.
 */
fun latestServingUrl(output: String): String? {
    if (output.isBlank()) return null
    val lines = output.lines().map {
        ANSI_SEQUENCE.replace(it, "").replace('\r', ' ').trim()
    }.filter {
        // IDE status lines (camera bridge, display) are not the user's web server.
        it.isNotEmpty() && !it.startsWith("[camera]") && !it.startsWith("[display]")
    }.takeLast(MAX_CONSOLE_SCAN_LINES)
    for (i in lines.indices.reversed()) {
        directServingUrl(lines[i], onlyLoopback = true)?.let { return it }
    }
    for (i in lines.indices.reversed()) {
        directServingUrl(lines[i], onlyLoopback = false)?.let { return it }
    }
    for (i in lines.indices.reversed()) {
        hostPortServingUrl(lines[i])?.let { return it }
    }
    return null
}

// ---------------------------------------------------------------------------
// "Run" on a file that is part of a web project but not a program by itself (views.py, models.py,
// urls.py, a Flask routes module ...): the user means "run my project", so start the PROJECT's server.
// Scripts with an entry point or top-level calls (seed.py, tools) are never hijacked.
// ---------------------------------------------------------------------------

private val LIBRARY_NAMES = setOf(
    "views", "models", "urls", "forms", "admin", "apps", "serializers", "settings", "signals",
    "middleware", "context_processors", "templatetags", "consumers", "routing", "routes", "schemas",
    "api", "blueprints", "handlers", "controllers", "dependencies", "crud", "database", "db", "utils",
    "helpers", "config", "tests", "wsgi", "asgi", "forms", "managers", "permissions", "filters"
)
private val TOP_LEVEL_CALL = Regex("""(?m)^[A-Za-z_][\w.]*\s*\(""")

/** A module that is meant to be imported (no `__main__` guard, no top-level calls). */
fun isLibraryLikeModule(file: File, text: String?): Boolean {
    val t = text ?: return false
    if (t.contains("__main__")) return false
    if (TOP_LEVEL_CALL.containsMatchIn(codeText(t))) return false
    val stem = file.nameWithoutExtension.lowercase()
    val inPackage = try {
        File(file.parentFile, "__init__.py").isFile
    } catch (_: Exception) {
        false
    }
    return stem in LIBRARY_NAMES || inPackage
}

private fun findFileByName(root: File, rootCanonical: String, name: String): File? {
    return try {
        val queue = ArrayDeque<Pair<File, Int>>()
        queue.add(root to 0)
        var seen = 0
        while (queue.isNotEmpty() && seen < 600) {
            val (dir, depth) = queue.removeFirst()
            val kids = try {
                dir.listFiles()?.sortedBy { it.name.lowercase() } ?: emptyList()
            } catch (_: Exception) {
                emptyList()
            }
            for (kid in kids) {
                seen++
                if (!isUnder(rootCanonical, kid)) continue
                if (kid.isFile && kid.name == name) return kid
                if (kid.isDirectory && depth < 3 && !isSkippableDir(kid.name)) queue.add(kid to depth + 1)
            }
        }
        null
    } catch (_: Exception) {
        null
    }
}

/** The project's own server command for a library-like [activeFile], or null (then plain python runs). */
fun resolveProjectWebRun(
    project: PyProject,
    activeFile: File,
    activeSource: String?,
    pythonBin: String
): WebAutoRun? {
    if (!isLibraryLikeModule(activeFile, activeSource ?: readWebText(activeFile, MAX_SCAN_FILE_BYTES))) return null
    val detected = detectWebServerInProject(project, activeFile, activeSource) ?: return null
    if (detected.launchable) return null
    val root = project.dir
    val rootCanonical = try {
        root.canonicalPath
    } catch (_: Exception) {
        return null
    }
    val entry = if (detected.framework == "Django") {
        findManagePy(root, rootCanonical)
    } else {
        detected.entryFile?.let { findFileByName(root, rootCanonical, it) }
    } ?: return null
    val text = readWebText(entry, MAX_SCAN_FILE_BYTES)
    return webAutoRun(root, entry, text, detected, pythonBin)
}
