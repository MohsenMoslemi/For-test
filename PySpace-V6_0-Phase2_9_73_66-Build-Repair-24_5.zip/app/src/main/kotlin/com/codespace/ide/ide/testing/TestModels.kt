package com.codespace.ide.ide.testing

import org.json.JSONArray
import org.json.JSONObject
import com.codespace.ide.ide.JSON

// Test Explorer data model plus JSON/coverage/analytics parsing and filtering. No UI.

internal enum class TestStatus { NOT_RUN, RUNNING, PASSED, FAILED, SKIPPED, XFAILED, XPASSED }
internal data class TestCase(
    val id: String,
    val label: String,
    val file: String,
    val status: TestStatus = TestStatus.NOT_RUN,
    val duration: String = "",
    val detail: String = "",
    val className: String = "",
    val line: Int = 0,
    val selected: Boolean = false
)
internal data class TestSnapshot(
    val cases: List<TestCase> = emptyList(),
    val output: String = "Discover tests to get started.",
    val running: Boolean = false,
    val discovering: Boolean = false,
    val framework: String = "auto",
    val detectedFramework: String = "",
    val lastRun: String = "",
    val totalDuration: String = "",
    val history: List<String> = emptyList(),
    val coveragePercent: String = "",
    val reportPath: String = "",
    val htmlReportPath: String = "",
    val jsonReportPath: String = "",
    val keyword: String = "",
    val marker: String = "",
    val failFast: Boolean = false,
    val coverageEnabled: Boolean = false,
    val lastExitCode: Int = -1,
    val runSummary: String = "",
    val coverageFiles: List<CoverageFile> = emptyList(),
    val coverageLoading: Boolean = false,
    val coverageMessage: String = "Run tests with coverage enabled to explore file-level coverage.",
    val analyticsRunNumber: Int = 0,
    val analyticsCounts: AnalyticsCounts = AnalyticsCounts(),
    val analyticsChanges: List<AnalyticsChange> = emptyList(),
    val flakyTests: List<FlakyTest> = emptyList(),
    val analyticsMessage: String = "Run tests at least three times to start detecting flaky tests."
)

internal data class CoverageFile(
    val path: String,
    val percent: Double,
    val covered: Int,
    val statements: Int,
    val missingLines: List<Int>
)

internal data class AnalyticsCounts(val new: Int = 0, val regressions: Int = 0, val fixed: Int = 0, val unchanged: Int = 0)
internal data class AnalyticsChange(val id: String, val name: String, val file: String, val line: Int,
    val status: String, val previousStatus: String, val change: String, val duration: Double)
internal data class FlakyTest(val id: String, val name: String, val file: String, val line: Int,
    val runs: Int, val passed: Int, val failed: Int, val lastStatus: String)

/** A project-scoped service: UI composition/lifecycle never owns or cancels a test process. */

internal fun parseAnalyticsCounts(o: JSONObject) = AnalyticsCounts(o.optInt("new"), o.optInt("regressions"), o.optInt("fixed"), o.optInt("unchanged"))
internal fun parseAnalyticsChanges(a: JSONArray): List<AnalyticsChange> = (0 until a.length()).mapNotNull { i ->
    val o = a.optJSONObject(i) ?: return@mapNotNull null
    AnalyticsChange(o.optString("id"), o.optString("name"), o.optString("file"), o.optInt("line"), o.optString("status"), o.optString("previousStatus"), o.optString("change"), o.optDouble("duration"))
}
internal fun parseFlakyTests(a: JSONArray): List<FlakyTest> = (0 until a.length()).mapNotNull { i ->
    val o = a.optJSONObject(i) ?: return@mapNotNull null
    FlakyTest(o.optString("id"), o.optString("name"), o.optString("file"), o.optInt("line"), o.optInt("runs"), o.optInt("passed"), o.optInt("failed"), o.optString("lastStatus"))
}
internal fun analyticsChangesToJson(items: List<AnalyticsChange>) = JSONArray().also { a -> items.take(2000).forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("file", it.file).put("line", it.line).put("status", it.status).put("previousStatus", it.previousStatus).put("change", it.change).put("duration", it.duration)) } }
internal fun flakyTestsToJson(items: List<FlakyTest>) = JSONArray().also { a -> items.take(500).forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("file", it.file).put("line", it.line).put("runs", it.runs).put("passed", it.passed).put("failed", it.failed).put("lastStatus", it.lastStatus)) } }

internal fun parseCoverageFiles(array: JSONArray): List<CoverageFile> = (0 until array.length()).mapNotNull { index ->
    val item = array.optJSONObject(index) ?: return@mapNotNull null
    val missing = item.optJSONArray("missingLines") ?: JSONArray()
    CoverageFile(item.optString("path"), item.optDouble("percent"), item.optInt("covered"), item.optInt("statements"),
        (0 until missing.length()).mapNotNull { missing.optInt(it, -1).takeIf { line -> line > 0 } })
}
internal fun coverageFilesToJson(files: List<CoverageFile>): JSONArray = JSONArray().also { array ->
    files.take(2000).forEach { file ->
        val missing = JSONArray(); file.missingLines.take(10000).forEach { missing.put(it) }
        array.put(JSONObject().put("path", file.path).put("percent", file.percent).put("covered", file.covered).put("statements", file.statements).put("missingLines", missing))
    }
}

internal fun matchesTest(test: TestCase, query: String, filter: String): Boolean {
    val statusMatch = when (filter) {
        "Failed" -> test.status == TestStatus.FAILED || test.status == TestStatus.XPASSED
        "Passed" -> test.status == TestStatus.PASSED
        "Skipped" -> test.status == TestStatus.SKIPPED || test.status == TestStatus.XFAILED
        "Not run" -> test.status == TestStatus.NOT_RUN
        else -> true
    }
    val q = query.trim()
    return statusMatch && (q.isBlank() || test.id.contains(q, true) || test.file.contains(q, true) || test.className.contains(q, true))
}
