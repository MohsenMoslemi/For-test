package com.codespace.ide.ide.shell

import com.codespace.ide.application.editor.usecase.SerializeEditorSessionUseCase
import com.codespace.ide.runtime.RuntimeTaskScope
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import com.codespace.ide.ide.editor.EditorViewModel
import com.codespace.ide.ide.projects.PyProject
import com.codespace.ide.ide.settings.IdePrefs

/**
 * Owns the durable IDE-session write protocol. UI/shell code supplies the current
 * project and editor; this coordinator owns snapshot revisions, stale-write rejection,
 * and the crash/recents restore marker.
 */
internal class IdeSessionPersistence(
    private val prefs: IdePrefs,
    private val serializeEditorSession: SerializeEditorSessionUseCase,
    private val runtimeTaskScope: RuntimeTaskScope,
) {
    private val lock = Any()
    private val revisions = mutableMapOf<String, Long>()
    private val restoreMarkerEpoch = AtomicLong(0L)

    fun persist(project: PyProject, editor: EditorViewModel, saveFiles: Boolean, markForRestore: Boolean) {
        val projectPath = project.dir.absolutePath
        try {
            if (saveFiles) editor.saveAll()
            // Snapshot state before leaving the caller's lifecycle; encode and persist
            // on the application scope so Activity disposal cannot cancel the final write.
            val snapshot = editor.session.persistenceSnapshot()
            val markerEpoch = restoreMarkerEpoch.get()
            val revision = synchronized(lock) {
                (revisions[projectPath] ?: 0L).plus(1L).also { revisions[projectPath] = it }
            }
            runtimeTaskScope.scope.launch(Dispatchers.Default) {
                val json = serializeEditorSession(snapshot)
                synchronized(lock) {
                    if (revisions[projectPath] == revision) {
                        prefs.setSessionJson(projectPath, json)
                        if (markForRestore && restoreMarkerEpoch.get() == markerEpoch) {
                            prefs.lastProject = projectPath
                        }
                    }
                }
            }
        } catch (_: Exception) {
            // Persistence is best-effort during lifecycle transitions; the last
            // committed snapshot remains available for recovery.
        }
    }

    /** Invalidates any pending write's permission to set the resume marker. */
    fun invalidateRestoreMarker() {
        restoreMarkerEpoch.incrementAndGet()
    }
}
