package com.codespace.ide.ide

import android.graphics.BitmapFactory
import android.text.Html
import android.util.Base64
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image
import com.codespace.ide.memory.MemoryRuntimePolicy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import com.codespace.ide.ide.codeintel.PythonCompletion
import com.codespace.ide.ide.codeintel.PythonCompletionItem
import com.codespace.ide.ide.codeintel.PythonLspController
import com.codespace.ide.ide.editor.OpenTab
import com.codespace.ide.ide.editor.applySmartEdit
import com.codespace.ide.ide.notebook.NotebookRepository
import com.codespace.ide.ide.projects.PyProject
import com.codespace.ide.ide.theme.IdeTheme
import com.codespace.ide.presentation.notebook.NbCell
import com.codespace.ide.presentation.notebook.NbDoc
import com.codespace.ide.presentation.notebook.NbOutput

// ---------------------------------------------------------------------------
// Native notebook editor (Jetpack Compose): the Jupyter model (code + text cells, outputs, execution
// counts) with the IDE's own look and controls. Cells run on a small kernel in the project's Python
// (NbKernel). .ipynb files stay standard Jupyter files.
// ---------------------------------------------------------------------------

private object NbHighlight : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val colored = try {
            highlightPython(text.text)
        } catch (_: Throwable) {
            text
        }
        return TransformedText(if (colored.length == text.length) colored else text, OffsetMapping.Identity)
    }
}

private val ANSI = Regex("\u001B\\[[0-9;]*[A-Za-z]")
private val MONO = FontFamily.Monospace

@Composable
fun NativeNotebook(
    tab: OpenTab,
    project: PyProject,
    codeFontFamily: FontFamily = FontFamily.Monospace,
    pythonLspController: PythonLspController? = null,
    notebookRepository: NotebookRepository,
    onRaw: () -> Unit,
    modifier: Modifier = Modifier
) {
    val existingSession = remember(tab.file.absolutePath, project.dir.absolutePath) {
        notebookRepository.existingSession(tab.file, project, tab)
    }
    val parsed = produceState<Pair<Boolean, NbDoc?>>(false to null, tab.file.absolutePath) {
        value = if (existingSession != null) {
            true to existingSession.doc
        } else {
            val source = tab.text
            true to notebookRepository.parse(source)
        }
    }.value
    if (!parsed.first) {
        Column(modifier.fillMaxSize().background(Color(IdeTheme.BG)), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            CircularProgressIndicator(color = Color(IdeTheme.ACCENT))
            Spacer(Modifier.height(10.dp))
            Text("Loading notebook…", color = Color(IdeTheme.DIM), fontSize = 12.sp)
        }
        return
    }
    val parsedDoc = parsed.second
    if (parsedDoc == null) {
        Column(modifier.fillMaxSize().background(Color(IdeTheme.BG)).padding(16.dp)) {
            Text("This file is not a valid notebook", fontWeight = FontWeight.Bold, color = Color(IdeTheme.TEXT), fontSize = 15.sp)
            Spacer(Modifier.height(6.dp))
            Text("The JSON could not be read. Fix it as raw JSON.", color = Color(IdeTheme.DIM), fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            PillButton("Raw JSON", Color(IdeTheme.ACCENT)) { onRaw() }
        }
        return
    }
    // The repository owns the session and its message subscription beyond this
    // Composable's lifetime. Raw JSON toggles and Activity recreation do not
    // discard cell state, queued output or the Python process.
    val ctl = remember(tab.file.absolutePath, project.dir.absolutePath, parsedDoc) {
        notebookRepository.sessionFor(tab.file, project, parsedDoc, tab)
    }
    val doc = ctl.doc
    val kernel = ctl.kernel
    val kernelState by kernel.state.collectAsState()
    val kernelInfo by kernel.info.collectAsState()
    // Observe the revision so in-place stream aggregation also refreshes the UI.
    @Suppress("UNUSED_VARIABLE")
    val notebookRevision = ctl.version
    var selected by remember { mutableStateOf(0) }
    val editingMd = remember { mutableStateListOf<String>() }
    val listState = rememberLazyListState()

    // Small inline status banner near the top: 0 hidden, 1 starting, 2 started, 3 failed.
    // It only appears for a real start (or restart), never for an already-idle kernel.
    var kernelBanner by remember { mutableStateOf(0) }
    LaunchedEffect(ctl.starting, kernelState) {
        if (ctl.starting || kernelState == "starting") {
            kernelBanner = 1
        } else if (kernelBanner == 1) {
            kernelBanner = if (kernelState == "idle" || kernelState == "busy") 2 else 3
        }
    }
    LaunchedEffect(kernelBanner) {
        if (kernelBanner == 2 || kernelBanner == 3) {
            delay(if (kernelBanner == 2) 3000L else 5000L)
            kernelBanner = 0
        }
    }


    fun selectedCell(): NbCell? = doc.cells.getOrNull(selected.coerceIn(0, (doc.cells.size - 1).coerceAtLeast(0)))

    fun runSelectedAndAdvance() {
        val c = selectedCell() ?: return
        val i = doc.cells.indexOf(c)
        if (c.type == "markdown") {
            editingMd.remove(c.id)
        } else {
            ctl.run(listOf(c))
        }
        if (i == doc.cells.size - 1) {
            val n = ctl.add(i + 1, "code")
            selected = doc.cells.indexOf(n)
        } else {
            selected = i + 1
        }
    }

    Column(modifier.fillMaxSize().background(Color(IdeTheme.BG))) {
        // ---- toolbar ----
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            PillButton("▶ Run", Color(IdeTheme.ACCENT)) { runSelectedAndAdvance() }
            PillButton("Run all", Color(IdeTheme.TEXT)) { ctl.run(doc.cells.toList()) }
            PillButton("■", Color(IdeTheme.ERROR)) { ctl.interrupt() }
            PillButton("↻", Color(IdeTheme.WARN)) { ctl.restart() }
            PillButton("+ Code", Color(IdeTheme.TEXT)) {
                val n = ctl.add(selected + 1, "code")
                selected = doc.cells.indexOf(n)
            }
            PillButton("+ Text", Color(IdeTheme.TEXT)) {
                val n = ctl.add(selected + 1, "markdown")
                selected = doc.cells.indexOf(n)
                editingMd.add(n.id)
            }
            PillButton("↑", Color(IdeTheme.TEXT)) {
                ctl.move(selected, -1)
                selected = (selected - 1).coerceAtLeast(0)
            }
            PillButton("↓", Color(IdeTheme.TEXT)) {
                ctl.move(selected, 1)
                selected = (selected + 1).coerceAtMost(doc.cells.size - 1)
            }
            PillButton("Clear out", Color(IdeTheme.DIM)) { selectedCell()?.let { ctl.clearOutputs(it) } }
            PillButton("Delete", Color(IdeTheme.ERROR)) {
                ctl.delete(selected)
                selected = selected.coerceIn(0, doc.cells.size - 1)
            }
            val (kText, kColor) = when {
                ctl.starting || kernelState == "starting" -> "Starting kernel…" to IdeTheme.WARN
                kernelState == "busy" -> kernelInfo.ifBlank { "Python" } + " · shared · busy" to IdeTheme.WARN
                kernelState == "idle" -> kernelInfo.ifBlank { "Python" } + " · shared · idle" to IdeTheme.ACCENT
                kernelState == "dead" -> "Kernel stopped" to IdeTheme.ERROR
                else -> "Kernel: starts on first run" to IdeTheme.DIM
            }
            Text(kText, color = Color(kColor), fontSize = 11.sp)
            PillButton("Raw JSON", Color(IdeTheme.DIM)) { onRaw() }
        }
        if (kernelBanner != 0) {
            val starting = kernelBanner == 1
            val failed = kernelBanner == 3
            val bg = when {
                starting -> Color(IdeTheme.WARN).copy(alpha = 0.14f)
                failed -> Color(IdeTheme.ERROR).copy(alpha = 0.16f)
                else -> Color(IdeTheme.ACCENT)
            }
            val fg = when {
                starting -> Color(IdeTheme.WARN)
                failed -> Color(IdeTheme.ERROR)
                else -> Color(IdeTheme.SUCCESS_SURFACE)
            }
            Row(
                Modifier.fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 2.dp)
                    .background(bg, RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (starting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(14.dp),
                        color = fg,
                        strokeWidth = 2.dp
                    )
                } else {
                    Text(
                        if (failed) "✕" else "✓",
                        color = fg,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    when {
                        starting -> "Starting the Python kernel, please wait…"
                        failed -> "The Python kernel could not start. Check that Python is installed for this project."
                        else -> "Kernel started. You can run your cells now."
                    },
                    color = fg,
                    fontSize = 12.sp
                )
            }
        }
        ctl.lastError?.let { error ->
            Text(
                error,
                color = Color(IdeTheme.ERROR),
                fontSize = 11.sp,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 6.dp)
        ) {
            itemsIndexed(doc.cells, key = { _, c -> c.id }) { idx, cell ->
                val precedingCode = doc.cells.take(idx)
                    .filter { it.type == "code" }
                    .joinToString("\n") { it.source }
                val completionFile = remember(tab.file.absolutePath, cell.id) {
                    File(project.dir, ".pyspace/notebook-completion/${tab.file.nameWithoutExtension}_${cell.id}.py")
                }
                CellView(
                    cell = cell,
                    selected = idx == selected,
                    editingMarkdown = editingMd.contains(cell.id),
                    codeFontFamily = codeFontFamily,
                    precedingCode = precedingCode,
                    completionFile = completionFile,
                    projectRoot = project.dir,
                    pythonLspController = pythonLspController,
                    onSelect = { selected = idx },
                    onEditMarkdown = { editingMd.add(cell.id) },
                    onChanged = { ctl.touch() }
                )
            }
            item {
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    PillButton("+ Code cell", Color(IdeTheme.ACCENT)) {
                        val n = ctl.add(doc.cells.size, "code")
                        selected = doc.cells.indexOf(n)
                    }
                    Spacer(Modifier.width(8.dp))
                    PillButton("+ Text cell", Color(IdeTheme.TEXT)) {
                        val n = ctl.add(doc.cells.size, "markdown")
                        selected = doc.cells.indexOf(n)
                        editingMd.add(n.id)
                    }
                }
            }
        }
    }
}

@Composable
private fun CellView(
    cell: NbCell,
    selected: Boolean,
    editingMarkdown: Boolean,
    codeFontFamily: FontFamily,
    precedingCode: String,
    completionFile: File,
    projectRoot: File,
    pythonLspController: PythonLspController?,
    onSelect: () -> Unit,
    onEditMarkdown: () -> Unit,
    onChanged: () -> Unit
) {
    // Stream output text is appended into an existing NbOutput instance. Read
    // this per-cell revision so those in-place updates recompose this cell even
    // when the outputs list itself did not structurally change.
    val outputRevision = cell.outputRevision
    val outputSnapshot = remember(cell.id, outputRevision) { cell.outputs.toList() }
    val shape = RoundedCornerShape(12.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape)
            .background(Color(if (selected) IdeTheme.CARD else IdeTheme.PANEL))
            .border(1.dp, Color(if (selected) IdeTheme.ACCENT else IdeTheme.LINE), shape)
            .clickable { onSelect() }
            .padding(8.dp)
    ) {
        // gutter: In [n]
        Box(Modifier.width(44.dp).padding(top = 6.dp)) {
            if (cell.type == "code") {
                Text(
                    when {
                        cell.running -> "[*]"
                        cell.queued -> "[…]"
                        cell.execCount != null -> "[" + cell.execCount + "]"
                        else -> "[ ]"
                    },
                    color = Color(if (cell.running || cell.queued) IdeTheme.WARN else IdeTheme.TEAL),
                    fontSize = 11.sp, fontFamily = if (cell.type == "code") codeFontFamily else MONO
                )
            } else {
                Text("Md", color = Color(IdeTheme.VIOLET), fontSize = 11.sp, fontFamily = MONO)
            }
        }
        Column(Modifier.weight(1f)) {
            if (cell.type == "markdown" && !editingMarkdown && cell.source.isNotBlank()) {
                Box(Modifier.fillMaxWidth().clickable { onSelect(); onEditMarkdown() }.padding(vertical = 4.dp)) {
                    MarkdownText(cell.source)
                }
            } else {
                var tfv by remember(cell.id) { mutableStateOf(TextFieldValue(cell.source)) }
                var editorFocused by remember(cell.id) { mutableStateOf(false) }
                var completionItems by remember(cell.id) { mutableStateOf<List<PythonCompletionItem>>(emptyList()) }
                var completionRange by remember(cell.id) { mutableStateOf(0 to 0) }
                var completionEditVersion by remember(cell.id) { mutableStateOf(0) }
                var lastCompletionEditVersion by remember(cell.id) { mutableStateOf(0) }
                var codeTextLayout by remember(cell.id) { mutableStateOf<TextLayoutResult?>(null) }
                val density = LocalDensity.current
                val cellCodeFont = if (cell.type == "code") codeFontFamily else MONO

                DisposableEffect(completionFile, pythonLspController) {
                    onDispose { pythonLspController?.closeDocument(completionFile) }
                }

                LaunchedEffect(cell.id, completionEditVersion, editorFocused,
                    precedingCode, pythonLspController) {
                    completionItems = emptyList()
                    if (completionEditVersion <= lastCompletionEditVersion) return@LaunchedEffect
                    lastCompletionEditVersion = completionEditVersion
                    if (cell.type != "code" || !editorFocused || !tfv.selection.collapsed || tfv.text.isBlank()) {
                        return@LaunchedEffect
                    }
                    val cellText = tfv.text
                    val caretInCell = tfv.selection.start.coerceIn(0, cellText.length)
                    val prefix = precedingCode.trimEnd()
                    val prefixOffset = if (prefix.isBlank()) 0 else prefix.length + 1
                    val source = if (prefix.isBlank()) cellText else "$prefix\n$cellText"
                    val caret = prefixOffset + caretInCell
                    if (PythonCompletion.isInsideStringOrComment(source, caret)) return@LaunchedEffect
                    delay(100)
                    if (!editorFocused || tfv.text != cellText || tfv.selection.start != caretInCell) return@LaunchedEffect

                    val installed = pythonLspController?.installedPackagesSnapshot()
                    val local = withContext(Dispatchers.Default) {
                        PythonCompletion.complete(source, caret, installed, projectRoot = projectRoot)
                    }
                    val lsp = pythonLspController?.complete(completionFile, source, caret)
                    if (tfv.text != cellText || tfv.selection.start != caretInCell || !editorFocused ||
                        completionEditVersion != lastCompletionEditVersion) return@LaunchedEffect
                    var tokenPrefixStart = caretInCell
                    while (tokenPrefixStart > 0 && (cellText[tokenPrefixStart - 1].isLetterOrDigit() || cellText[tokenPrefixStart - 1] == '_')) tokenPrefixStart--
                    val tokenPrefix = cellText.substring(tokenPrefixStart, caretInCell)
                    val explicitMemberContext = cellText.substring(0, caretInCell).trimEnd().endsWith('.')
                    val merged = (lsp?.items.orEmpty() + local?.items.orEmpty())
                        .filter { it.autoImportStatement.isNullOrBlank() }
                        .filter { explicitMemberContext || (tokenPrefix.isNotEmpty() && it.name.startsWith(tokenPrefix) && it.name != tokenPrefix) }
                        .groupBy { it.name }
                        .values
                        .map { group -> group.firstOrNull { it.priority < 50 } ?: group.first() }
                        .sortedWith(compareBy<PythonCompletionItem> { it.priority }.thenBy { it.name.lowercase() })
                        .take(8)
                    if (merged.isNotEmpty()) {
                        // Use the complete identifier in this cell as the edit
                        // range, even when the caret sits in its middle. LSP
                        // and local providers can report slightly different
                        // replacement ranges for the same merged suggestion.
                        var tokenStart = caretInCell
                        while (tokenStart > 0 && (cellText[tokenStart - 1].isLetterOrDigit() || cellText[tokenStart - 1] == '_')) tokenStart--
                        var tokenEnd = caretInCell
                        while (tokenEnd < cellText.length && (cellText[tokenEnd].isLetterOrDigit() || cellText[tokenEnd] == '_')) tokenEnd++
                        completionRange = tokenStart to tokenEnd
                        completionItems = merged
                    }
                }

                Box(Modifier.fillMaxWidth()) {
                    BasicTextField(
                        value = tfv,
                        onValueChange = { v ->
                            val (t, c) = applySmartEdit(cell.source, v.text, v.selection.start, 4, true)
                            tfv = if (t != v.text) TextFieldValue(t, TextRange(c)) else v
                            if (t != cell.source) {
                                cell.source = t
                                completionEditVersion++
                                onChanged()
                            }
                        },
                        textStyle = TextStyle(
                            color = Color(IdeTheme.TEXT), fontSize = 13.sp, fontFamily = cellCodeFont,
                            lineHeight = 19.sp
                        ),
                        cursorBrush = SolidColor(Color(IdeTheme.ACCENT)),
                        visualTransformation = if (cell.type == "code") NbHighlight else VisualTransformation.None,
                        modifier = Modifier.fillMaxWidth().onFocusChanged {
                            editorFocused = it.isFocused
                            if (it.isFocused) onSelect() else completionItems = emptyList()
                        }.padding(vertical = 6.dp, horizontal = 4.dp),
                        onTextLayout = { codeTextLayout = it },
                        decorationBox = { inner ->
                            Box {
                                if (tfv.text.isEmpty()) {
                                    Text(
                                        if (cell.type == "code") "# code" else "Write text (Markdown)",
                                        color = Color(IdeTheme.DIM), fontSize = 13.sp, fontFamily = cellCodeFont
                                    )
                                }
                                inner()
                            }
                        }
                    )
                    if (cell.type == "code" && editorFocused && completionItems.isNotEmpty() && codeTextLayout != null) {
                        val cursorRect = codeTextLayout!!.getCursorRect(tfv.selection.start.coerceIn(0, tfv.text.length))
                        val popupProvider = remember(cursorRect, density) {
                            object : PopupPositionProvider {
                                override fun calculatePosition(
                                    anchorBounds: IntRect,
                                    windowSize: IntSize,
                                    layoutDirection: LayoutDirection,
                                    popupContentSize: IntSize
                                ): IntOffset {
                                    val gap = with(density) { 4.dp.roundToPx() }
                                    val caretX = anchorBounds.left + cursorRect.left.toInt() + with(density) { 4.dp.roundToPx() }
                                    val x = caretX.coerceIn(0, (windowSize.width - popupContentSize.width).coerceAtLeast(0))
                                    val below = anchorBounds.top + cursorRect.bottom.toInt() + gap
                                    val y = if (below + popupContentSize.height <= windowSize.height - gap) below
                                        else (anchorBounds.top + cursorRect.top.toInt() - popupContentSize.height - gap).coerceAtLeast(gap)
                                    return IntOffset(x, y)
                                }
                            }
                        }
                        Popup(
                            popupPositionProvider = popupProvider,
                            onDismissRequest = { completionItems = emptyList() }
                        ) {
                            val popupShape = RoundedCornerShape(9.dp)
                            Column(
                                Modifier.widthIn(min = 190.dp, max = 260.dp).heightIn(max = 176.dp)
                                    .clip(popupShape).background(Color(IdeTheme.PANEL))
                                    .border(1.dp, Color(IdeTheme.LINE), popupShape)
                                    .verticalScroll(rememberScrollState()).padding(vertical = 4.dp)
                            ) {
                                completionItems.forEach { item ->
                                    Row(
                                        Modifier.fillMaxWidth().clickable {
                                            val start = completionRange.first.coerceIn(0, tfv.text.length)
                                            val end = completionRange.second.coerceIn(start, tfv.text.length)
                                            val base = item.insertText.ifBlank { item.name }
                                            val lineStart = if (start == 0) 0 else tfv.text.lastIndexOf('\n', start - 1) + 1
                                            val linePrefix = tfv.text.substring(lineStart, start).trimStart()
                                            val importLine = linePrefix.startsWith("import ") || linePrefix.startsWith("from ")
                                            val decorator = linePrefix.startsWith("@")
                                            val suffix = if (item.callable && !importLine && !decorator &&
                                                !base.endsWith("(") && !base.endsWith("()") && tfv.text.getOrNull(end) != '(') "()" else ""
                                            val insertion = base + suffix
                                            val updated = tfv.text.substring(0, start) + insertion + tfv.text.substring(end)
                                            val caret = (start + insertion.length - if (suffix.isNotEmpty() || (item.callable && base.endsWith("()"))) 1 else 0)
                                                .coerceIn(0, updated.length)
                                            tfv = TextFieldValue(updated, TextRange(caret))
                                            cell.source = updated
                                            onChanged()
                                            completionItems = emptyList()
                                        }.padding(horizontal = 10.dp, vertical = 7.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(item.name, color = Color(IdeTheme.TEXT), fontSize = 12.sp,
                                            fontFamily = codeFontFamily, modifier = Modifier.weight(1f), maxLines = 1)
                                        Spacer(Modifier.width(8.dp))
                                        Text(item.kind, color = Color(IdeTheme.TEAL), fontSize = 9.sp, maxLines = 1)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (cell.type == "code" && outputSnapshot.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                for (o in outputSnapshot) OutputView(o, codeFontFamily)
            }
            if (cell.running) {
                Spacer(Modifier.height(6.dp))
                CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp, color = Color(IdeTheme.ACCENT))
            }
        }
    }
}

@Composable
private fun OutputView(o: NbOutput, codeFontFamily: FontFamily) {
    when (o.kind) {
        "stream" -> Text(
            o.text.trimEnd('\n'),
            color = Color(if (o.name == "stderr") 0xFFFF9E80 else IdeTheme.TEXT),
            fontSize = 12.sp, fontFamily = codeFontFamily, lineHeight = 17.sp,
            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
        )
        "error" -> Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
            Text(o.ename + (if (o.evalue.isNotEmpty()) ": " + o.evalue else ""), color = Color(IdeTheme.ERROR), fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = codeFontFamily)
            Text(
                ANSI.replace(o.text, ""), color = Color(IdeTheme.ERROR), fontSize = 11.sp, fontFamily = codeFontFamily,
                lineHeight = 15.sp
            )
        }
        else -> RichData(o.data)
    }
}

@Composable
private fun RichData(data: Map<String, String>) {
    val png = data["image/png"] ?: data["image/jpeg"]
    val html = data["text/html"]
    val md = data["text/markdown"]
    when {
        png != null -> Base64Image(png)
        html != null && html.contains("<table", ignoreCase = true) -> HtmlTable(html)
        html != null -> Text(htmlToText(html), color = Color(IdeTheme.TEXT), fontSize = 12.sp)
        md != null -> MarkdownText(md)
        data["image/svg+xml"] != null -> Text("[SVG image]", color = Color(IdeTheme.DIM), fontSize = 12.sp, fontFamily = MONO)
        data["application/json"] != null -> Text(data["application/json"] ?: "", color = Color(IdeTheme.TEXT), fontSize = 12.sp, fontFamily = MONO)
        else -> Text(
            data["text/plain"] ?: data["text/latex"] ?: "", color = Color(IdeTheme.TEXT),
            fontSize = 12.sp, fontFamily = MONO, lineHeight = 17.sp,
            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
        )
    }
}

@Composable
private fun Base64Image(b64: String) {
    val img by produceState<ImageBitmap?>(null, b64) {
        value = withContext(Dispatchers.Default) {
            try {
                val bytes = Base64.decode(b64.trim(), Base64.DEFAULT)
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@withContext null
                val maxEdge = MemoryRuntimePolicy.imageMaxEdge()
                var sample = 1
                while (bounds.outWidth / sample > maxEdge || bounds.outHeight / sample > maxEdge) {
                    sample *= 2
                }
                val options = BitmapFactory.Options().apply { inSampleSize = sample }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)?.asImageBitmap()
            } catch (_: Throwable) {
                null
            }
        }
    }
    val i = img
    if (i != null) {
        Image(
            bitmap = i, contentDescription = "output image", contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp).padding(vertical = 4.dp)
        )
    } else {
        Text("[image]", color = Color(IdeTheme.DIM), fontSize = 12.sp)
    }
}

// ---- HTML output (pandas tables and simple markup), shown natively --------------------------------

private val STYLE_BLOCK = Regex("(?is)<(style|script)[^>]*>.*?</\\1>")
private val ROW = Regex("(?is)<tr[^>]*>(.*?)</tr>")
private val CELL = Regex("(?is)<(th|td)[^>]*>(.*?)</\\1>")

private fun htmlToText(html: String): String {
    val clean = STYLE_BLOCK.replace(html, "")
    return try {
        Html.fromHtml(clean, Html.FROM_HTML_MODE_LEGACY).toString().trim()
    } catch (_: Throwable) {
        clean.replace(Regex("<[^>]+>"), "")
    }
}

@Composable
private fun HtmlTable(html: String) {
    val rows = remember(html) {
        val clean = STYLE_BLOCK.replace(html, "")
        ROW.findAll(clean).take(61).map { r ->
            CELL.findAll(r.groupValues[1]).map { c ->
                (c.groupValues[1].equals("th", true)) to htmlToText(c.groupValues[2])
            }.toList()
        }.filter { it.isNotEmpty() }.toList()
    }
    if (rows.isEmpty()) {
        Text(htmlToText(html), color = Color(IdeTheme.TEXT), fontSize = 12.sp)
        return
    }
    Column(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
        for ((ri, row) in rows.withIndex()) {
            Row(Modifier.background(Color(if (ri % 2 == 0) IdeTheme.PANEL else IdeTheme.CARD))) {
                for ((isHead, text) in row) {
                    Text(
                        text, fontSize = 12.sp, fontFamily = MONO,
                        fontWeight = if (isHead || ri == 0) FontWeight.Bold else FontWeight.Normal,
                        color = Color(if (isHead) IdeTheme.ACCENT else IdeTheme.TEXT),
                        modifier = Modifier.widthIn(min = 56.dp).padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
        if (rows.size > 60) Text("… more rows", color = Color(IdeTheme.DIM), fontSize = 11.sp, modifier = Modifier.padding(6.dp))
    }
}

// ---- Markdown (headings, lists, quotes, code, bold/italic/inline code/links) ------------------------

@Composable
private fun MarkdownText(src: String) {
    val lines = remember(src) { src.split("\n") }
    Column(Modifier.fillMaxWidth()) {
        var i = 0
        while (i < lines.size) {
            val ln = lines[i]
            val t = ln.trim()
            when {
                t.startsWith("```") -> {
                    val sb = StringBuilder()
                    i++
                    while (i < lines.size && !lines[i].trim().startsWith("```")) {
                        sb.append(lines[i]).append('\n')
                        i++
                    }
                    Text(
                        sb.toString().trimEnd('\n'), fontFamily = MONO, fontSize = 12.sp, color = Color(IdeTheme.STRING),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(8.dp))
                            .background(Color(IdeTheme.BG)).padding(8.dp)
                    )
                }
                t.startsWith("#") -> {
                    val level = t.takeWhile { it == '#' }.length.coerceIn(1, 6)
                    val size = when (level) { 1 -> 22.sp; 2 -> 19.sp; 3 -> 17.sp; else -> 15.sp }
                    Text(
                        inlineMd(t.trimStart('#').trim()), color = Color(IdeTheme.TEXT), fontSize = size,
                        fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp, bottom = 2.dp)
                    )
                }
                t.startsWith("- ") || t.startsWith("* ") || t.startsWith("+ ") -> Row(Modifier.padding(start = 6.dp, top = 1.dp)) {
                    Text("•  ", color = Color(IdeTheme.ACCENT), fontSize = 13.sp)
                    Text(inlineMd(t.substring(2)), color = Color(IdeTheme.TEXT), fontSize = 13.sp)
                }
                Regex("^\\d+[.)] .*").matches(t) -> Row(Modifier.padding(start = 6.dp, top = 1.dp)) {
                    Text(t.substringBefore(' ') + " ", color = Color(IdeTheme.ACCENT), fontSize = 13.sp)
                    Text(inlineMd(t.substringAfter(' ')), color = Color(IdeTheme.TEXT), fontSize = 13.sp)
                }
                t.startsWith(">") -> Text(
                    inlineMd(t.trimStart('>').trim()), color = Color(IdeTheme.DIM), fontSize = 13.sp,
                    fontStyle = FontStyle.Italic, modifier = Modifier.padding(start = 10.dp, top = 2.dp)
                )
                t == "---" || t == "***" -> Spacer(Modifier.height(10.dp))
                t.isEmpty() -> Spacer(Modifier.height(6.dp))
                else -> Text(inlineMd(ln), color = Color(IdeTheme.TEXT), fontSize = 13.sp, lineHeight = 19.sp)
            }
            i++
        }
    }
}

private fun inlineMd(s: String): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < s.length) {
        val c = s[i]
        when {
            s.startsWith("**", i) && s.indexOf("**", i + 2) > 0 -> {
                val e = s.indexOf("**", i + 2)
                pushStyle(SpanStyle(fontWeight = FontWeight.Bold)); append(s.substring(i + 2, e)); pop()
                i = e + 2
            }
            (c == '*' || c == '_') && i + 1 < s.length && s[i + 1] != ' ' && s.indexOf(c, i + 1) > 0 -> {
                val e = s.indexOf(c, i + 1)
                pushStyle(SpanStyle(fontStyle = FontStyle.Italic)); append(s.substring(i + 1, e)); pop()
                i = e + 1
            }
            c == '`' && s.indexOf('`', i + 1) > 0 -> {
                val e = s.indexOf('`', i + 1)
                pushStyle(SpanStyle(fontFamily = MONO, background = Color(IdeTheme.TEXT).copy(alpha = 0.20f))); append(s.substring(i + 1, e)); pop()
                i = e + 1
            }
            c == '[' && s.indexOf("](", i) > 0 && s.indexOf(')', s.indexOf("](", i)) > 0 -> {
                val mid = s.indexOf("](", i)
                val end = s.indexOf(')', mid)
                pushStyle(SpanStyle(color = Color(IdeTheme.BUILTIN), textDecoration = TextDecoration.Underline))
                append(s.substring(i + 1, mid)); pop()
                i = end + 1
            }
            else -> {
                append(c)
                i++
            }
        }
    }
}
