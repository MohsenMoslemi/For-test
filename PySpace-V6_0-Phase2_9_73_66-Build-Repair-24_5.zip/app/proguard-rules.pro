# Add project-specific ProGuard/R8 keep rules here.
# These are applied on top of the bundled defaults (proguard-android-optimize.txt) when the
# build type has minifyEnabled = true.
#
# Keep a class that is referenced only by reflection / from XML, e.g.:
# -keep class com.codespace.ide.SomeClass { *; }
#
# Preserve line numbers for readable crash stack traces, then hide the original file name:
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# --- JNI (native/pty_bridge.c, native/key_bridge.c) -------------------------------------------
# The prebuilt .so files bind to these classes and methods by their EXACT current name
# (package + class + method). R8 renaming/removing either breaks native loading at runtime with
# UnsatisfiedLinkError. This standard rule keeps only classes that declare a native method -
# everything else in the app still gets fully obfuscated.
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}
# Kotlin `object` singletons generate an INSTANCE field; native instance methods are invoked
# through it, so keep it alongside the native methods above for the two JNI bridge classes.
-keepclassmembers class com.codespace.ide.PtyNative {
    public static final ** INSTANCE;
}
-keepclassmembers class com.codespace.ide.runtime.RuntimeAssetCipher {
    public static final ** INSTANCE;
}

# --- Manifest components ---------------------------------------------------------------------
# Android's framework instantiates these by the exact class name in AndroidManifest.xml. The
# standard AGP/Gradle build auto-generates keep rules for manifest components; this project's
# build tool may not, so they are listed explicitly - losing any one of these is a hard crash
# right at the point Android tries to start it (an Activity switch, or app launch).
-keep public class com.codespace.ide.UbuntuTerminalApplication
-keep public class com.codespace.ide.MainActivity
-keep public class com.codespace.ide.service.RunForegroundService
-keep public class com.codespace.ide.CrashViewerActivity
-keep class com.codespace.ide.ide.CrashLog { *; }

# --- Koin dependency injection ----------------------------------------------------------------
# Module/factory lambdas and the classes they construct must keep their constructors reachable;
# Koin resolves them by the compile-time type, but R8 must not remove a "seemingly unused"
# constructor that's only called indirectly through a Koin definition.
-keep class com.codespace.ide.di.** { *; }

# --- ViewModels --------------------------------------------------------------------------------
# ROOT CAUSE of the release-only crash (java.lang.NoSuchMethodException: a4.ed.<init>, 2026-11-05
# crash log): androidx.lifecycle.ViewModelProvider builds a ViewModel with
# Class.getDeclaredConstructor().newInstance() - plain reflection, invisible to R8's call-graph
# analysis - so R8 stripped the "unused" no-arg constructor it could not see being called.
# This keeps exactly the constructors ViewModelProvider needs, for every ViewModel subclass
# (InstallViewModel, FileExplorerViewModel, EditorViewModel, PackageManagerViewModel,
# ProjectsViewModel, CodeIntelligenceViewModel, RuntimeUiViewModel, SettingsViewModel) - nothing
# else in the app is exempted from obfuscation/shrinking.
-keep class * extends androidx.lifecycle.ViewModel {
    <init>(...);
}

# --- CameraX ---------------------------------------------------------------------------------
-dontwarn androidx.camera.**
-keep class androidx.camera.** { *; }

# --- Kotlin / Compose synthetic metadata (defensive; usually bundled by the libraries) --------
-keepattributes *Annotation*, InnerClasses, EnclosingMethod, Signature
-dontwarn kotlin.**
-dontwarn kotlinx.coroutines.**
