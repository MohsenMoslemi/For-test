# PySpace — Final Architecture Audit (Ownership Refinement 24)

Baseline: `2.9.73.66` — Ownership Refinement 23.

## Final result

The planned ownership-refinement sequence is complete. The project now has explicit domain/application contracts for the extracted pure policies and serialization use cases, a single Koin composition root for application services, and dedicated owners for the major editor, language-server, shell, terminal, notebook, and lifecycle workflows.

This is the final architecture baseline for the current single-module Tyron CodeAssist project. No additional architecture phase is planned. Future changes should be feature work or targeted maintenance driven by a concrete defect, not another open-ended refactor cycle.

## Stage 24 corrections

The final audit found two correctness gaps in the recently extracted output buffers and corrected them in this stage:

- `TerminalOutputBuffer.enqueue` previously admitted a single PTY read larger than the configured pending-character budget, and `drain` could consume more than the requested per-frame character budget when a queued chunk was large. The buffer now splits incoming reads into policy-sized pieces, applies lossless back-pressure to every piece, and supports partial drains while preserving byte/text order. Pending characters remain within the active policy limit, and a frame drain does not exceed `maxChars`.
- `NotebookOutputBuffer.clear` previously reset size accounting but left pending cell notifications scheduled; `remove` also left a removed cell in the pending notification set. Both operations now cancel or update the batched notification state so document replacement and cell removal retire stale work cleanly.

These corrections preserve the single PTY reader, terminal emulator, notebook kernel, notebook document, and execution queue owners.

## Dependency and composition checks

- `domain` and `application` source packages contain no imports from Android, AndroidX, Compose, IDE presentation, data implementations, or Android services.
- `ProotPackageManagerRepository` is constructed only in `di/AppModule.kt`; consumers resolve `PackageManagerRepository`.
- `NotebookKernelManager` is registered once in `di/AppModule.kt`; notebook sessions continue to use the existing `NotebookRepository` and kernel lifecycle rather than constructing parallel kernels.
- `TerminalOutputBuffer` has one owner per `TerminalScreenState`; `NotebookOutputBuffer` has one owner per `NotebookViewModel`.
- `AppDependencies` is resolved at the Activity composition boundary and passed to `IdeRoot`. The remaining `GlobalContext` lookups are confined to Android process/service entry points that are not Compose feature coordinators.
- Domain/application contracts remain framework-independent; implementation bindings are centralized in the Koin module.

## Ownership map

- **Application composition:** `di/AppModule.kt` owns concrete dependency bindings; `MainActivity` resolves the typed Activity dependency bundle.
- **Domain/application:** pure policies, snapshots, repository/serializer contracts, and notebook/editor use cases live outside the Android presentation package.
- **Project and shell lifecycle:** `ProjectFeatureFactory`, `IdeSessionPersistence`, `ProjectLifecycleCleanup`, `ProjectExitCoordinator`, `IdeRunSessionState`, `IdeBridgeCoordinator`, `TerminalRunLifecycleCoordinator`, `ConsoleDisplayLifecycleCoordinator`, `ConsoleRunCompletionCoordinator`, and `ConsoleRunPreparationCoordinator` own focused workflows. `IdeShell` remains the ordered Console run coordinator and `IdeRoot` remains the Compose composition root.
- **Editor:** `EditorSession` remains the source of truth for open tabs and document buffers. `PyEditor` coordinates live Compose text/IME interactions while dedicated collaborators own scroll, viewport, gutter geometry, syntax projection, folding, completion, formatting, rename, caret, zoom, and popup workflows. No second document store was introduced.
- **Code intelligence:** `PythonLspController` remains the single project-scoped process/session and request-policy owner. Transport, document synchronization, workspace configuration, diagnostic mapping, native diagnostics, import resolution, reference classification, and workspace reference aggregation are delegated to dedicated collaborators. Diagnostic publication/merge remains single-owner.
- **Terminal:** `TerminalScreenState` remains the Compose/emulator presentation state owner; `TerminalOutputBuffer` owns only the synchronized PTY-to-UI hand-off.
- **Notebook:** `NotebookViewModel` remains the single per-notebook execution/session state owner; `NotebookOutputBuffer` owns output accounting, MIME limiting, stream coalescing, and batched output notifications. The process-wide kernel manager and notebook repository remain the kernel/session owners.

## Intentional architectural constraints

- The app remains a **single module** because the supported CodeAssist import/build workflow is the governing constraint. Package boundaries and dependency direction provide the current separation without introducing a multi-module Gradle/KSP dependency graph.
- Compose screen coordinators such as `IdeRoot`, `IdeShell`, `PyEditor`, `TerminalScreenState`, and `NotebookViewModel` are not required to be tiny. Their remaining coordination is presentation- and lifecycle-bound; extracting their mutable state into duplicate stores or pushing Compose/IME state into Domain would weaken correctness.
- `PythonLspController` remains substantial because it is the single project-scoped policy façade for session freshness, requests, and diagnostic publication. Its independent transport, synchronization, configuration, mapping, and resolver responsibilities have explicit collaborators.
- Existing Android service/application entry points may resolve process-scoped services from Koin because Android constructs those entry points. Feature coordinators do not add new service-locator lookups.

## Verification performed in this stage

- Source scan of all `domain` and `application` imports for Android/Compose/IDE/data/service dependencies.
- Construction-site scan for `ProotPackageManagerRepository` and `NotebookKernelManager`.
- Ownership scan for the two extracted output buffers.
- Manual source review of terminal queue bounds, partial draining, interruption, reset, and stop behavior.
- Manual source review of notebook output-buffer clear/remove notification cleanup.
- ZIP integrity and required payload checks.

## Verification not performed

- Full Android compilation through Tyron CodeAssist.
- Installation or runtime regression tests on the user's phone.
- Live PRoot, pip, LSP, camera, VNC, GitHub, Notebook, Debugger, or PTY integration tests.

The source-level audit is complete, but the final acceptance gate remains a CodeAssist build and device regression pass. This is a validation requirement, not a reason to start another architecture phase.
