Bundled editor font families
============================

JetBrains Mono — Copyright 2020 The JetBrains Mono Project Authors. SIL Open Font License 1.1.
Fira Code — Copyright 2012-2015 The Fira Code Project Authors. SIL Open Font License 1.1.
IBM Plex Mono — Copyright 2017 IBM Corp. SIL Open Font License 1.1.
Source Code Pro — Copyright 2010, 2012 Adobe Systems Incorporated. SIL Open Font License 1.1; Reserved Font Name: Source.

Cascadia Code was not bundled because the supplied archive's font has restricted embedding permissions and only 102 mapped glyphs. See CASCADIA-ARCHIVE-REVIEW.txt.

The bundled font binaries are unmodified. License notices are retained here for redistribution compliance.
