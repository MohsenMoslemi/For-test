#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

# Run from the root of PySpace in Termux.
PROJECT_ROOT="$(pwd)"
DEST="$PROJECT_ROOT/app/src/main/jniLibs/arm64-v8a"
WORK="$HOME/.pyspace-proot"

mkdir -p "$DEST" "$WORK"
cd "$WORK"

pkg update -y
pkg install -y proot libtalloc libandroid-shmem dpkg patchelf

# Download the exact ARM64/aarch64 packages installed by this Termux.
rm -f ./*.deb
apt download proot libtalloc libandroid-shmem

rm -rf extract
mkdir -p extract
for deb in ./*.deb; do
    dpkg-deb -x "$deb" extract
 done

PREFIX_ROOT="extract/data/data/com.termux/files/usr"
PROOT_BIN="$PREFIX_ROOT/bin/proot"
LOADER="$PREFIX_ROOT/libexec/proot/loader"
TALLOC="$(find "$PREFIX_ROOT/lib" -maxdepth 1 -type f -name 'libtalloc.so.2*' | head -n 1 || true)"
SHMEM="$(find "$PREFIX_ROOT/lib" -maxdepth 1 -type f -name 'libandroid-shmem.so*' | head -n 1 || true)"

for f in "$PROOT_BIN" "$LOADER" "$TALLOC" "$SHMEM"; do
    if [ -z "$f" ] || [ ! -f "$f" ]; then
        echo "ERROR: required PRoot file not found: $f"
        exit 1
    fi
done

rm -f "$DEST"/*.so

# Android extracts native libraries from jniLibs into nativeLibraryDir.
# Use normal lib*.so names rather than Termux's versioned filenames.
cp -L "$PROOT_BIN" "$DEST/libproot.so"
cp -L "$LOADER" "$DEST/libproot-loader.so"
cp -L "$TALLOC" "$DEST/libtalloc.so"
cp -L "$SHMEM" "$DEST/libandroid-shmem.so"

# Termux's PRoot package links against libtalloc.so.2. Android's native
# library extraction does not reliably preserve the .so.2 name, so rewrite
# the dependency to the bundled libtalloc.so filename.
if patchelf --print-needed "$DEST/libproot.so" 2>/dev/null | grep -qx 'libtalloc.so.2'; then
    patchelf --replace-needed libtalloc.so.2 libtalloc.so "$DEST/libproot.so"
fi

# PRoot locates its guest-ELF loader through PROOT_LOADER.
# We set it from Kotlin at runtime to nativeLibraryDir/libproot-loader.so.
chmod 0755 "$DEST"/*.so

printf '\nPRoot ARM64 files installed into:\n  %s\n\n' "$DEST"
ls -lh "$DEST"
printf '\nDT_NEEDED for libproot.so:\n'
patchelf --print-needed "$DEST/libproot.so" || true
printf '\nDone. Rebuild the project in CodeAssist.\n'
