#!/usr/bin/env python3
"""
Encrypts a runtime asset so it can only be read by the PySpace app.

    python3 tools/encrypt_runtime_asset.py <input> <output> [--verify]

Examples (run from the project root):
    python3 tools/encrypt_runtime_asset.py system_files.tar.xz app/src/main/assets/runtime/system.psr --verify
    python3 tools/encrypt_runtime_asset.py pyspace-pylsp-wheelhouse.zip app/src/main/assets/runtime/lsp.psr --verify

Requires:  pip install cryptography      (Termux: pkg install python-cryptography)
Key file:  tools/runtime-key.hex  (keep private - never publish this folder)

Format "PSR1" (must match app/.../runtime/RuntimeAssetCipher.kt):
    header (12 bytes): "PSR1" | 4 random nonce-prefix bytes | chunk size (u32, big endian)
    chunks: AES-256-GCM, nonce = prefix(4) || chunk index (u64 BE),
            AAD = header || (1 if last chunk else 0), ciphertext = plaintext + 16-byte tag
    The final chunk is flagged in the AAD, so truncation or reordering is detected.
    AES key = SHA-256("PySpace/runtime/v1" || master key).
"""
import hashlib, os, struct, sys
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

MAGIC = b"PSR1"
CHUNK = 256 * 1024
TAG = 16

def load_key():
    hexkey = (Path(__file__).with_name("runtime-key.hex")).read_text().strip()
    master = bytes.fromhex(hexkey)
    if len(master) != 32:
        sys.exit("runtime-key.hex must contain 32 bytes (64 hex chars)")
    return hashlib.sha256(b"PySpace/runtime/v1" + master).digest()

def read_full(f, n):
    out = bytearray()
    while len(out) < n:
        b = f.read(n - len(out))
        if not b:
            break
        out += b
    return bytes(out)

def nonce(prefix, i):
    return prefix + struct.pack(">Q", i)

def encrypt(src, dst, key):
    aes = AESGCM(key)
    prefix = os.urandom(4)
    header = MAGIC + prefix + struct.pack(">I", CHUNK)
    with open(src, "rb") as fin, open(dst, "wb") as fout:
        fout.write(header)
        cur = read_full(fin, CHUNK)
        i = 0
        while True:
            nxt = read_full(fin, CHUNK) if len(cur) == CHUNK else b""
            last = len(nxt) == 0
            fout.write(aes.encrypt(nonce(prefix, i), cur, header + (b"\x01" if last else b"\x00")))
            if last:
                break
            cur, i = nxt, i + 1

def decrypt_hash(src, key):
    aes = AESGCM(key)
    h = hashlib.sha256()
    with open(src, "rb") as f:
        header = read_full(f, 12)
        assert header[:4] == MAGIC, "bad magic"
        prefix = header[4:8]
        size = struct.unpack(">I", header[8:12])[0]
        cur = read_full(f, size + TAG)
        i = 0
        while True:
            nxt = read_full(f, size + TAG) if len(cur) == size + TAG else b""
            last = len(nxt) == 0
            h.update(aes.decrypt(nonce(prefix, i), cur, header + (b"\x01" if last else b"\x00")))
            if last:
                break
            cur, i = nxt, i + 1
    return h.hexdigest()

def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        while True:
            b = f.read(1 << 20)
            if not b:
                break
            h.update(b)
    return h.hexdigest()

if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if len(args) != 2:
        sys.exit(__doc__)
    src, dst = args
    key = load_key()
    encrypt(src, dst, key)
    print(f"encrypted: {dst} ({os.path.getsize(dst):,} bytes)")
    if "--verify" in sys.argv:
        ok = decrypt_hash(dst, key) == sha256_file(src)
        print("verify:", "OK" if ok else "FAILED")
        sys.exit(0 if ok else 1)
