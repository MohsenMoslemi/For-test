# Agent notes

## Mandatory build handoff (every task)

After finishing ANY change in this project, sync the working tree to the shared
folder so the user can build it from there:

- Destination: `/storage/emulated/0/MyProjects/PySpace`
- Replace the destination contents with this project (remove stale files).
- Never copy the `.git` directory.
- Keep the final message in Persian and tell the user the sync is done.

This rule applies to every future session, not just the current one.

## Build environment

- This machine has no Gradle/JDK/SDK; the user builds in their Android IDE.
- Module descriptor: `app/module.toml` (do not assume Gradle files).
- Work incrementally and keep each phase buildable.

## Architecture

- The architecture refactor is in progress; read `ARCHITECTURE.md` first. It documents the layers, package map, IDE shell
  (`IdeRoot` + `shell/IdeShell`), lifecycle/threading rules, conventions and the remaining known limitations.
- Keep the application single-module and use `koin-core`; do not migrate to `koin-android` or Hilt without validating
  CodeAssist's POM dependency resolver.
- Do not do big-bang rewrites. Move code with its imports, keep each change buildable, and update `ARCHITECTURE.md` when structure changes.
- Preserve the existing PRoot/Ubuntu/Python runtime and the CodeAssist `app/module.toml` build system unless the user explicitly approves a change.
- Runtime/native/asset tooling is documented in `docs/RUNTIME-AND-TOOLING.md`.
