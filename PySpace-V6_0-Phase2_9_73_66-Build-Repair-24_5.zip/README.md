# PySpace

An Android Python IDE with an embedded ARM64 Ubuntu (PRoot) runtime. Kotlin + Jetpack Compose, single module.

Features: private project workspace, multi-tab editor with a Python language server, smart indentation, refactoring and import
management, terminals, native notebooks, run/debug/test tooling, an embedded display (X11 over VNC and a lightweight frame view),
an in-app browser, camera bridge, GitHub integration, backup/recovery.

## Build

- Built from `app/module.toml` by CodeAssist (no Gradle files). Java 17, compileSdk 36, minSdk 30, targetSdk 35, ARM64 devices.
- Before the first full build you need the native libraries and encrypted runtime assets described in
  [`docs/RUNTIME-AND-TOOLING.md`](docs/RUNTIME-AND-TOOLING.md) (PRoot `.so` files, `libkeybridge.so`, `system.psr`).

## Documentation

| Document | What it covers |
|---|---|
| [`ARCHITECTURE.md`](ARCHITECTURE.md) | Layers, package map, IDE shell, lifecycle/threading rules, subsystems, conventions, known limitations |
| [`docs/RUNTIME-AND-TOOLING.md`](docs/RUNTIME-AND-TOOLING.md) | PRoot libraries, encrypted assets and key bridge, R8 notes, crash viewer, permissions |
| [`CHANGELOG.md`](CHANGELOG.md) | Summary of the architecture refactor |
| [`AGENTS.md`](AGENTS.md) | Working notes for automated assistants |

## Source layout

```
app/src/main/kotlin/com/codespace/ide/
  *.kt            Application, MainActivity, runtime core (Ubuntu/PRoot/PTY/terminal emulator)
  di/ runtime/ memory/ service/ ui/install/
  ide/            IDE application code, grouped by feature (see ARCHITECTURE.md §5)
app/src/main/{assets,jniLibs,res}   encrypted runtime assets, native libraries, resources
native/           C sources and build scripts for the PTY and key bridges
tools/            asset encryption and PRoot install helpers (do not publish: contains the key file)
THIRD_PARTY_NOTICES/   font licenses
```
