# PySpace IDE — Architecture

Status: **Architecture ownership refinement in progress** on 2.9.73.66. The seven-step baseline has been followed by focused ownership extractions. Core dependency direction, construction boundaries, selected runtime state, project-scoped resource lifetime, and testability seams are implemented. UI-specific Compose state remains in presentation/platform adapters by design; it is not treated as domain state. Remaining large feature coordinators and their accepted responsibilities are documented in `ARCHITECTURE-AUDIT.md`; no claim is made that every coordinator has already been reduced to a small class.
This document describes the code as it is. If you change structure, update it in the same change.

### Architecture refactor — Stage 1 (IdeRoot / IdeShell ownership)

- Added `IdeNavigationState` and `IdePanelState` as explicit owners for navigation/recovery and bottom-panel presentation state.
- Added `ProjectFeatureRegistry` as the single owner for project-keyed editor, explorer, code-intelligence and debugger instances.
- `IdeShell` now forwards the existing UI-facing properties to those owners, preserving the current call surface while avoiding
  duplicated mutable state. Project deletion routes feature-map removal and debugger disposal through the registry; IDE-host disposal
  uses its centralized debugger cleanup method.
- This stage does not yet extract run lifecycle, bridge coordination or session persistence; those remain scheduled for later work.

### Next31.1 CodeAssist compatibility corrections

The editor surface modifier is a composable boundary because it composes the shared two-axis pan and pinch-gesture modifiers. Its injected pinch modifier is therefore explicitly a composable lambda. The caret-navigation snapshot receives live Compose `State` handles, while ordinary layout/document values remain in the editor for immediate rendering. Code-intelligence receives the stable language enum name, and the input layer receives only the hover symbol key needed to suppress competing caret-dismissal behavior.

### Editor gesture/workflow coordination

Pinch pointer recognition remains in `EditorPinchZoomGesture`, which only detects and consumes a genuine two-pointer gesture. The resulting lifecycle is coordinated by `EditorPinchZoomCoordinator`: it manages wrapped-text live reflow anchoring, unwrapped preview scale and gutter updates, the transition into the existing zoom commit workflow, and delayed wrap-session cleanup. `EditorZoomSessionState` remains the presentation-state owner, while `launchEditorZoomCommit` owns the animation/commit sequence and `EditorZoomAnchorEffects` owns post-layout scroll hand-off. These boundaries deliberately keep pointer mechanics, gesture policy, mutable presentation state, and animation effects separate.

### Code Intelligence — Stage 3 (LSP transport and diagnostics boundaries)

- `PythonLspController` remains the project-scoped language-server orchestrator: it owns process/session lifecycle, request freshness, and publication of diagnostics. It delegates document protocol synchronization to `LspDocumentSynchronizer` and interpreter/Jedi workspace settings to `LspWorkspaceConfiguration`.
- `LspSessionTransport` is the narrow boundary consumed by the controller. `PythonLspSession` is the concrete process-backed JSON-RPC implementation and owns stdio framing, request-ID correlation, server-initiated protocol replies, stderr draining, and process shutdown. This prevents project policy from depending directly on the process transport implementation.
- `LspDocumentSynchronizer` owns `didOpen`/`didChange` publication, document version increments, and the required publish-before-notify ordering. `LspDocumentRegistry` remains the single source of truth for open document snapshots and versions.
- `LspWorkspaceConfiguration` owns selected-interpreter fingerprinting, project import-root discovery, and Jedi/pylsp settings refresh. It can be reset independently when the project's Python environment revision changes.
- `LspDiagnosticMapper` performs protocol-to-domain conversion for `publishDiagnostics` messages. `PythonNativeDiagnosticsSession` independently owns the debounced app-native Kotlin Python checker jobs, per-file source freshness, and native diagnostic snapshots; it reports changes through the controller callback so there is still one combined publication path. Version freshness, URI-to-project-document lookup, unused-import filtering, missing-import resolution, and merging pylsp results with native results remain in the controller because they require project-owned state.
- The workspace reference index, refactor transaction manager, and completion engine remain intact. Their indexing and edit semantics are high-risk behavior and are not rewritten as part of a structural extraction.


### Terminal, Notebook and Debugger — Stage 5

- `TerminalRepository` remains the single owner of the current native PTY/process-group resource; `TerminalViewModel` owns the per-surface start/send/stop orchestration and observable lifecycle snapshot. `TerminalScreenState` intentionally remains a composition-bound presentation adapter: its emulator transcript, IME conduit, Compose selection/layout geometry, clipboard, keyboard, and gesture state are coupled to the live terminal surface and must not be moved into Domain or an application singleton. `TerminalTabs` owns only tab selection and tab-surface composition; each tab retains its own PTY and transcript.
- Notebook session indexing and lifetime bookkeeping now live in `NotebookSessionRegistry`. It serializes session lookup/creation, stale-persistence validation, and removal by file, subtree, project, or process shutdown. `NotebookRepository` remains responsible for coordinating registry entries with kernel subscriptions, persistence use cases, and kernel release. Disposal occurs after entries are detached from the registry, avoiding external cleanup while holding the registry lock.
- `NotebookViewModel` remains the per-notebook presentation/session coordinator because its `NbDoc`/`NbCell` objects are Compose snapshot-backed. It owns execution queue progression, cell status/output publication, persistence debounce and restart transitions; `NbKernel` remains the isolated interpreter owner. The repository keeps the notebook/kernel session alive when the UI detaches, preserving the existing one-kernel-per-notebook behavior.
- Debugger output staging was extracted to `DebugOutputBuffer`, a bounded, thread-safe, Android-free buffer. DAP reader threads append to it; `DebugController` retains the 50 ms main-thread publication cadence and the 100,000-character visible-history cap. `DapDebugSession` continues to own DAP framing, request correlation, socket/process lifetime, and protocol operations; `DebugController` continues to own project policy, generation checks, breakpoint/watch persistence, and observable debugger state.
- No runtime session, kernel, PTY, DAP transport, or Compose-backed notebook document was duplicated. Existing resource lifetime boundaries and public call surfaces were retained.

### Editor presentation-state ownership

Pinch-zoom transient presentation state is grouped in `ide/editor/EditorZoomSessionState`: preview X/Y scales, target font, gesture pivot, gesture/commit flags, commit compensation shifts, preview gutter width, and the zoom anchor lifecycle object. The holder also derives the layer scales, gutter font ratio, and sheet compensation values used by the editor layers. Animation sequencing remains in `launchEditorZoomCommit`, while post-layout scroll hand-off and wrapped-layout re-anchoring remain in `EditorZoomAnchorEffects`; the holder does not own document, font preference, or scroll state.


`OpenTab` is the sole source of truth for document text, dirty tracking and edit history. The Compose `TextFieldValue` is a presentation adapter, not a second document buffer: `ide/editor/EditorTextInputState` owns its live selection/IME composition and centralizes external text replacement, selection requests and caret placement. `EditorDocumentSyncEffects` only schedules synchronization through that holder. Completion candidates, replacement range, request generations and signature-help presentation are grouped in `ide/editor/EditorCompletionSessionState`; diagnostics, hover documentation, caret interaction and zoom remain in their respective focused presentation holders. The live viewport coordinates, `TextLayoutResult`, scroll states and gesture measurements stay in `PyEditor` because they are bound to the active Compose layout tree. Caret viewport movement remains coordinated by `EditorCaretInteractionCoordinator` and its live navigation snapshot.

### Architecture refactor — Stage 7 (final audit and dependency correction)

- Audited the Domain and Application source sets: no Android, AndroidX, Compose, or `ide.*` implementation imports remain in those packages.
- Corrected the package-management dependency boundary introduced in Stage 6. `PackageManagerRepository` is now registered once in the Koin application graph, exposed through `AppDependencies`, and passed to both the package-management ViewModel and `PythonLspController`. UI and code-intelligence orchestration no longer instantiate `ProotPackageManagerRepository` directly.
- Corrected the installed-package inventory call to pass the project's directory (`project.dir`) to the repository contract. The repository's process-wide command mutex now serializes package inventory/install/uninstall operations through the same adapter instance.
- Rechecked moved Camera, Display, GitHub and Browser package references, Koin resolution at the application composition root, and the notebook/debugger resource ownership boundaries.
- The final audit records intentionally retained orchestration coordinators and verification limits in `ARCHITECTURE-AUDIT.md`.

Verification: pure Kotlin smoke tests passed for browser URL normalization, package requirement validation and freeze parsing, camera command-prefix generation, and bounded debugger output buffering. Source-level boundary/reference checks and ZIP payload checks passed. Full Android/CodeAssist compilation and device regression tests were not run.

## 1. What this is

PySpace is an Android Python IDE. It embeds an ARM64 Ubuntu 24.04 userland (run through PRoot) with Python,
pip/venv, a Python language server and a debugger, and wraps it in a Kotlin / Jetpack Compose app:
project workspace, multi-tab editor with code intelligence, terminals, notebooks, run/debug/test tooling,
an embedded display (X11 over VNC and a lightweight "frame view"), a browser, camera bridge and GitHub integration.

## 2. Build and project constraints

- **Single Gradle-less module** built by CodeAssist from `app/module.toml` (Java 17, compileSdk 36, minSdk 30, targetSdk 35).
  Do not assume Gradle files exist. Keep it a single module unless there is a demonstrated build/ownership reason.
- **DI is `koin-core`** (application singletons in `di/AppModule.kt`). Do not move to `koin-android` or Hilt without
  validating CodeAssist's POM dependency resolver first.
- UI is **Jetpack Compose + Material 3**; state holders are AndroidX `ViewModel`s plus plain Kotlin classes.
- Native pieces: PRoot (`jniLibs/arm64-v8a`), PTY bridge (`native/pty_bridge.c`), key bridge (`native/key_bridge.c`).
  See `docs/RUNTIME-AND-TOOLING.md`.
- There is no unit-test source set. Verification is by building and running on a device.

## 3. Layers and dependency rules

```
 Compose UI  (screens, panels, dialogs)         ide/home, ide/filetree, ide/editor/IdeEditor, ide/settings, ide/shell, ...
      │  reads state / calls intents
 State holders                                   ViewModels (Activity- or project-scoped), IdeShell, TerminalScreenState
      │  call suspend functions / flows
 Domain contracts/use cases                       domain/{notebook,editor}: immutable snapshots, ports and use cases
      │
 Data adapters / repositories                      data/{notebook,editor}, *Repository
      │
 Runtime & platform                              ProotManager, UbuntuManager, PtyNative, RunHub, foreground service, memory policy
```

Rules that the code follows (and new code must keep following):

1. **Composables do not do blocking I/O.** Filesystem walks, process and socket work go through a repository on
   `Dispatchers.IO`; CPU-heavy parsing/formatting on `Dispatchers.Default`; Compose state is updated on Main.
2. **Structured cancellation.** Catch `CancellationException` separately and rethrow it. No `GlobalScope`,
   no `runBlocking` on Main, no unbounded thread creation.
3. **Long-lived work belongs to an application, service or ViewModel scope**, never to a `remember`ed scope.
   The one deliberate exception is a terminal PTY: it is surface-scoped and always stopped on disposal.
4. **Pure rules live in plain Kotlin** (no Android, no Compose) so they can be moved or reused:
   `run/RunIdentityResolver`, `run/RunCommandBuilder`, `run/RunSourceAnalyzer`, `PyFormat` (indent engine),
   `editor/EditorTextOps`, `codeintel/*` analyzers.
5. **One owner per piece of state.** E.g. open documents are owned by `EditorViewModel`, run registry by `RunHub`.
6. **No service locator in feature/core classes.** Resolve process dependencies at the Android/application composition boundary and pass them through constructors or explicit parameters. `MainActivity` creates a typed `AppDependencies` bundle once before entering Compose. Koin global access is retained only at framework boundaries (`Application`, `Service`, and the Activity composition root), not in feature composables or shell logic.
7. **Runtime state must not depend on Compose.** Process services and domain/runtime coordinators expose Flow/StateFlow or immutable snapshots; Compose adapts them at the presentation boundary. `NbKernel`, `DebugController`, `RunHub`, and `ProjectTestController` publish Flow/StateFlow snapshots. Compose state is allowed only in presentation adapters and UI coordinators whose responsibility is rendering or direct Android UI interaction.
8. **Project-owned resources must have deterministic eviction.** A registry that owns project-scoped controllers must expose removal and close resources when a project is deleted or permanently left. Closing is idempotent, cancels owned work, and terminates owned processes.
9. **ViewModel factories receive repositories explicitly.** Factories must not silently instantiate their own repository defaults. App-wide repositories are resolved at the composition root; project- or surface-scoped adapters are created at the owning feature boundary and passed into the factory/constructor.

## 4. Process, application and services

| Piece | File | Role |
|---|---|---|
| `UbuntuTerminalApplication` | `com.codespace.ide` | Installs `CrashLog` first, starts Koin, initializes `MemoryRuntimePolicy`. Skips Koin/services in the `:viewer` process. |
| `MainActivity` | `com.codespace.ide` | Thin Android composition root: applies window theme, resolves `AppDependencies`, and enters `UbuntuTerminalApp`. Install flow lives in `UbuntuInstallFlow`; terminal surface and IME handling live in `TerminalScreen`; shared terminal UI tokens live in `TerminalUiTokens`. |
| `CrashViewerActivity` | `com.codespace.ide` | Separate process, plain Views, shows the last crash (`CrashLog`) even if `MainActivity` cannot start. |
| `di/AppModule.kt` | `com.codespace.ide.di` | Koin singletons: runtime managers, notebook parser/serializer use cases and adapters, editor-session serializer use case, repositories, run services. |
| `runtime/` | | `RuntimeDispatchers` (IO/Default/Main abstraction), `RuntimeTaskScope`, `RuntimeAssetCipher` (AES-256-GCM stream decrypt, JNI key). |
| `memory/MemoryRuntimePolicy` | | Process-wide memory profiles (Balanced/Low), trim callbacks, weak registry of trimmable caches. |
| `service/` | | `RunForegroundService` (one generic foreground service that watches `RunHub`), `RunServiceManager`. |
| `ui/install/InstallViewModel` | | First-run runtime installation state. |
| `UbuntuManager`, `ProotManager`, `TerminalSession`, `PtyNative`, `TerminalEmulator` | `com.codespace.ide` | Runtime core: rootfs install/recovery, PRoot process launch, PTY, terminal emulation. |

## 4.1 Activity and editor widget boundaries

- `MainActivity` is kept as the Android entry/composition root. Ubuntu installation UI is in `UbuntuInstallFlow.kt`; terminal rendering, selection rendering, IME overlap handling and window-mode ownership are in `TerminalScreen.kt`; shared terminal style/limits are in `TerminalUiTokens.kt`.
- `PyEditor` remains the editor surface coordinator because text-field selection, folding, diagnostics, completion, zoom anchoring and gutter geometry share live Compose state. Font-metric caching, wrapped-line measurement and gutter-width calculation live in `editor/EditorLayoutMetrics.kt`; gutter rendering and information cards are separate composables. The code-lane row, pinch-preview transform, selection-handle policy, text-field/IME bridge, edit normalization, undo/redo keyboard handling, and selection-toolbar host are grouped in `EditorCodeInputLayer`; it receives the live field and explicit state callbacks from `PyEditor`, so it does not become a second document owner. Input normalization, popup hit testing, completion/signature request lifecycles, project-wide rename selection analysis/preview/execution workflow and its presentation-only dialog, completion candidate filtering, caret viewport target calculations and the asynchronous two-axis caret reveal/centering workflow, pinch-zoom geometry, gesture lifecycle coordination and post-commit anchor effects, hover pointer mapping, hover documentation/definition resolution, and external document/selection synchronization live respectively in `editor/EditorInputEditProcessor`, `EditorPopupHitTester`, `EditorCompletionEffect`, `EditorSignatureHelpEffect`, `EditorRenameWorkflow` and `EditorRenameDialog`, `EditorCompletionCandidates`, `EditorCaretViewport`, `EditorZoomGeometry`, `EditorZoomAnchorEffects`, `EditorLayoutMetrics`, `EditorHoverPosition`, `EditorHoverResolution`, and `EditorDocumentSyncEffects`. The editor coordinator composes the live editing surface but does not own a second document buffer: `OpenTab` owns document content, `EditorTextInputState` owns the Compose editing value, and focused per-document presentation holders own completion/diagnostic/caret/zoom transient state. LSP request cancellation and stale-source validation remain at the code-intelligence boundary; extracted helpers receive explicit snapshots and callbacks rather than creating competing owners.

## 5. Package map (`com.codespace.ide.ide`)

| Package | Contents |
|---|---|
| `domain/notebook` | Immutable notebook snapshots, parser/serializer ports, and parse/serialize use cases. No Compose or Android UI types. |
| `domain/editor` | Immutable editor-session persistence snapshots, serializer port, and serialization use case. |
| `data/notebook` | nbformat JSON parser and serializer adapters operating only on immutable snapshots. |
| `data/editor` | JSON adapter for editor-session persistence snapshots. |
| `ide` (root) | App-level features that are not yet packaged: `IdeRoot` (Compose entry/coordinator), `EditorLspHost`, `EditorProblemCounts`, `PyEditor` (editor surface coordinator; document content is owned by `OpenTab`, live TextFieldValue by `EditorTextInputState`, completion transient state by `EditorCompletionSessionState`; font metric caching, wrapped-line measurement/cache policy and gutter-width calculation are extracted to `editor/EditorLayoutMetrics`; caret viewport target calculations are extracted to `editor/EditorCaretViewport`), `PyFormat`/`PyHighlight`, `RunHub`+`IdeBridge`, `WebServer` detection, `IdeBrowser`, `FrameView`, `PhoneCamera`/`CameraPanel`, `NativeNotebook`+`NbKernel`, `IdeInterpreter`, `IdePanels`, `RunStrip`, `PythonRuntimeCatalog`, `PythonImportManager`, `EditorLanguage/Folding/FontCatalog/SymbolCatalog/SelectionToolbar`, `IdeGuestFiles` (guest-side scripts), `IdeAlertDialog`, `CrashLog`, `FileKind`, `FileViewers`, `TestExplorer` (UI), `Vnc` (viewer UI), `GitHub` (UI), `DisplayWm`, `ProjectViewModelStoreRegistry`, `IdeNavigation`. |
| `shell` | `IdeShell` (non-UI core of the IDE screen), `IdeShellContent` (dialogs, overlays, `ScreenHost`, `IdeBottomPanel`), `IdeShellComponents`. |
| `home` | Home screen: `IdeHome`, `ProjectsTab`, `NewProjectPage`, `PackagesTab`, `LearnTab`. |
| `editor` | `EditorViewModel` + `EditorSession` + `EditorRepository` + `EditorEditHistory` + breakpoints; `IdeEditor` screen; editor widget helpers (`EditorTextOps`, `EditorPopupLayout`, `EditorViewport`, `EditorGutter`, `EditorColors`, `EditorStatusLine`). |
| `filetree` | Drawer: `FileTreeDrawer`, tree rows/components, `SearchTab`, `StructureTab`, `GitSheet`, `FileTreeFiles` (clipboard/import/export), `TreeNode`. |
| `explorer` | `FileExplorerViewModel`/`Repository`, `ProjectFileWatcher`, `PythonImportPathRefactor`. |
| `projects` | `ProjectsViewModel`/`Repository`, workspace layout (`ProjectWorkspace`, `ProjectVenv`), `PythonRuntimeInstaller`, backup/deletion/auto-recovery managers, `PyProject`. |
| `codeintel` | Language server controller, project/environment indexes, completion, hover, diagnostics, quick fixes, refactor transactions, `ProjectTransactionManager`. |
| `debug` | `DapDebugSession` (debugpy over DAP), `DebugController`. |
| `run` | `RunOrchestrator`, `RunIdentityResolver`, `RunCommandBuilder`, `RunSourceAnalyzer`, `ProjectWebResolverRepository`, `DisplayRunCoordinator`, `CameraRunCoordinator`, `ExpiringPlanStore`. |
| `runtimeui` | `RuntimeUiViewModel`: immutable presentation state for display / web preview. |
| `terminal` | `TerminalViewModel`, `TerminalRepository`, `TerminalTabs`, `TerminalScreenState` (selection/flush/key logic), `TermBridge`/`TermController`/`ConsoleState`. |
| `notebook` | `NotebookViewModel`, `NotebookRepository` (process-scoped sessions). |
| `presentation.notebook` | Compose-observable `NbDoc`/`NbCell`/`NbOutput` models and snapshot/UI mapping. |
| `domain.notebook` | Immutable notebook snapshots, parser/serializer ports, use cases and snapshot factory. |
| `packages` | pip package manager VM/repository, curated package list. |
| `settings` | `IdePrefs`, `SettingsViewModel`/`Repository`, settings overlay and cards. |
| `testing` | `ProjectTestController` (StateFlow state + owned test process), `TestModels` (immutable test/coverage/analytics snapshots), and `TestControllerRegistry` (project-scoped lifetime). |
| `github` | REST client, publish (push snapshot) and import/clone logic. |
| `display` | `VncDisplay` (Xvnc lifecycle + RFB client). |
| `gui` | GUI-framework detection, launch prefix and display shims. |
| `browser` | WebView lifecycle safety helper. |
| `files` | Safe read/write/rename/delete and tree-visibility rules. |
| `theme` | `IdeTheme` (runtime-switchable palette). |
| `ui` | Shared UI utilities: drawer gestures, `ScreenSlide`/`OverlaySlideUp`. |
| `learn` | Built-in lessons and templates. |

## 6. The IDE screen: `IdeRoot`, `IdeShell`, content composables

`IdeRoot()` is the only composable entry point of the IDE. It is deliberately thin:

1. Resolves the workspace (shows a preparing screen until ready) and delegates Activity-scoped ViewModel provisioning
   (`ProjectsViewModel`, `SettingsViewModel`, `RuntimeUiViewModel`, `ProjectViewModelStoreRegistry`) to `presentation/IdeRootViewModels`.
2. Creates one **`IdeShell`** via `remember` and runs the rest of its body inside `with(shell) { ... }`.
3. Composes the layout skeleton and delegates project-LSP attachment, Problems aggregation, recovery, and Activity lifecycle persistence/camera effects to focused presentation adapters.

**`IdeShell`** (`shell/IdeShell.kt`) is the host coordinator. Its state ownership is now delegated to focused holders:
`IdeNavigationState` owns destination, home tab, settings and recovery presentation state; `IdePanelState` owns bottom-panel
visibility, sizing, selected tab and pending import selection; `ProjectFeatureRegistry` owns project-keyed editor, explorer,
code-intelligence and debugger instances, including centralized debugger disposal. `IdeShell` retains compatibility accessors
for existing UI call sites while coordinating Console Run/Stop/Rerun, display/camera preparation, conflict decisions, session
persistence (`persistNow`), project leave/delete cleanup, URL helpers and `buildProjVenv`. Guest bridge callbacks are owned by
`IdeBridgeCoordinator`; terminal process stop/completion policy is owned by `TerminalRunLifecycleCoordinator`.

**`IdeShellContent.kt`** holds extension composables on `IdeShell`: `ScreenHost` (Home/Editor), `IdeBottomPanel` (a `BoxScope`
extension: console, terminal, debug, problems, tests), `FileTreePanel`, and the dialogs/overlays (`CrashReportDialog`,
`RunConflictDialog`, `BrowserChoiceDialog`, `MissingProjectDialog`, `ImportSelectionDialog`, `DisplayOverlay`, `BrowserOverlay`,
`SettingsOverlayHost`).

Why `with(shell)`: the UI code reads the same names (`screen`, `panelOpen`, `console`, ...) it always did. Locals declared in
`IdeRoot` (e.g. `displayOpen` from `collectAsState`) shadow same-named non-reactive getters on the shell, which is what logic functions use.
When adding state: assign it to the narrowest lifecycle owner. Navigation and panel state belong to their dedicated holders;
project feature instances belong to `ProjectFeatureRegistry`; surface-only transient view state stays local to the composable.
The shell's forwarding properties are compatibility accessors, not additional state owners.

## 7. State ownership and lifecycle

| Scope | Who | Notes |
|---|---|---|
| Application (Koin singletons) | runtime, proot, `RunHub`, `RunOrchestrator`, notebook repository/kernels, run service | Survive Activity recreation. Notebook sessions/kernels are released only when the notebook session is removed (file move/delete, project delete, shutdown). |
| Activity (`ViewModelStore`) | `ProjectsViewModel`, `SettingsViewModel`, `RuntimeUiViewModel`, `ProjectViewModelStoreRegistry`, `InstallViewModel` | Cleared with the Activity. |
| Project (child store from `ProjectViewModelStoreRegistry`) | `EditorViewModel`, `FileExplorerViewModel`, `CodeIntelligenceViewModel`, `PackageManagerViewModel` | Cleared when the project is deleted or the Activity dies. `EditorViewModel.onCleared()` cancels open jobs; `CodeIntelligenceViewModel.onCleared()` cancels search/outline jobs and invalidates request generations. |
| Surface (composition) | `TerminalViewModel` + PTY, `TerminalScreenState`, `BrowserState` | A terminal surface owns its PTY and stops it on disposal. `TerminalRepository` uses a generation token so a stale start cannot revive a stopped session. |

`EditorViewModel` owns its `EditorSession` (tabs, caret/scroll restore data) and is the **only** path for opening, saving, closing and
restoring documents (disk I/O off the main thread). `IdeShell.editorFor(project)` returns it.

## 8. Subsystems

### Projects and workspace
Projects live in a private workspace under the app's Ubuntu rootfs (`ProjectWorkspace`). `ProjectsViewModel` lists/creates/imports/
backs up/deletes projects via `ProjectRepository`. Deletion is staged outside the guest-visible workspace with an Undo window
(`ProjectDeletionManager`). `ProjectAutoRecoveryManager` keeps a content-addressed incremental recovery store outside the workspace
(atomic manifests with a rollback point) and `ProjectRecoveryWatcher` feeds it. Project mutations from different features
(editor saves, explorer operations, LSP refactors) are serialized and journaled by `codeintel/ProjectTransactionManager`.
Python environments: each project may have a venv (`ProjectVenv`); interpreters come from `PythonRuntimeCatalog` and are installed
by `PythonRuntimeInstaller`.

### Editor
`IdeEditor` (screen) composes the tab bar, toolbar, `PyEditor` (custom text editor widget with caret handling, IME, zoom,
gutter, folding, popups) and panels. Editing rules live in plain Kotlin: `PyFormat` (block-aware indent engine, reformat),
`EditorTextOps.applySmartEdit`. Edits are recognised relative to the cursor and only when exactly one character changes,
so pastes are never auto-indented. `PyEditor`'s body is intentionally one large composable (see §11).

### Code intelligence
`PythonLspController` runs one `pylsp` per open project (stdio JSON-RPC, Content-Length framing) inside PRoot, using the venv selected
for the project. It is supplemented by: `PythonSyntaxDiagnostics`, `KotlinPythonTypeChecker`, `PythonCompletion`, `PythonHoverDocumentation`,
`PythonQuickFixes` / `PythonImportAnalyzer` / `PythonAutoImportCatalog` (import management), `PythonProjectSymbolIndex` and the
disk-backed `WorkspacePythonReferenceIndex` (independent, fail-closed reference index used for rename/refactors),
`ProjectIndexMonitor`/`PythonEnvironmentIndexMonitor` (indexing status), and `WorkspaceRefactorTransaction`.
Closing a tab sends LSP `didClose` and releases per-file snapshots; closing a project controller clears all source/diagnostic maps.

### Run system (Console, Run button, Terminal)
All runs share one state so a program behaves the same however it is started.
- `RunHub` is the observable registry of runs (source Console/Terminal, folder, title, pid/pgid, display, web URL).
- `RunOrchestrator` (application scope) owns policy: registration, id allocation, conflict lookup, completion and
  SIGTERM→SIGKILL escalation for terminal runs. It does not own PTYs, PRoot, display servers or WebViews.
- `RunIdentityResolver`, `RunCommandBuilder`, `RunSourceAnalyzer` are pure helpers (script-argument parsing and conflict keys; shell
  string assembly; GUI/frame-view/camera/web decisions from source text).
- `IdeBridge` is a loopback server (127.0.0.1, random port, secret token) for guest → IDE messages. Guest scripts generated from
  `IdeGuestFiles.kt` are written to guest `/tmp/ide`: shell integration (wraps `python`, `flask`, `uvicorn`, ... in IDE terminals),
  `ide_run.py` (asks the IDE to prepare a run, detects conflicts, forwards signals) and a `sitecustomize` hook that reports listening ports
  of every Python process of the run (children and reloaders included). The IDE verifies the port answers HTTP before offering Browser.
- `IdeBridgeCoordinator` owns the guest callback protocol and forwards terminal lifecycle events to `TerminalRunLifecycleCoordinator`.
  `IdeShell` owns Console Run/Stop/Rerun and supplies display/camera and UI callbacks. Conflict decisions remain presentation-driven
  (`RunConflictDialog`). Web projects: `ProjectWebResolverRepository` resolves framework servers
  (Django/Flask/FastAPI/Streamlit); a module that is not a program starts the project server instead.
- `RunForegroundService` keeps the process alive while any run exists; it stops itself when `RunHub` is empty.

### Display, frame view and camera
- **X11 display:** Xvnc runs in the guest on a 1600×1600 canvas. `DisplayWm.kt` is a tiny guest-side window manager (ctypes + libX11)
  that centers windows and publishes their bounding box so the viewer shows only the window. `display/VncDisplay` starts Xvnc and speaks
  RFB 3.8 (None auth, 32-bit truecolor, Raw + CopyRect) and keeps a viewport-sized bitmap. `Vnc.kt` is the viewer UI (zoom/pan are GPU
  transforms; one finger = mouse, two = pinch/pan; Back hides the viewer, toolbar Back sends Esc). If the window manager cannot start,
  the display restarts once in classic phone-sized mode (`/tmp/ide-wm.fail`).
- **Frame view (no X11):** for files whose only graphics are `cv2.imshow` or matplotlib `show/pause`, `FrameDisplay` polls a JPEG written
  by guest shims (`/tmp/ide-view/frame.jpg`) and sends key/mouse events through `/tmp/ide-view/events`. Falls back to X11 for anything
  interactive (other toolkits, animations, trackbars, `ginput`, widgets).
- **Camera:** `PhoneCamera` serves frames to guest code (`cv2.VideoCapture(0/1)` shim) with a demand-driven long-poll
  (`/frame.jpg?after=<ver>&wait=<ms>`) so readers always get the newest frame; frames are encoded only while a reader exists.
- Coordination: `DisplayRunCoordinator`, `CameraRunCoordinator`, `RuntimeUiViewModel` (immutable presentation state).

### Terminal
`TerminalScreen` (UI, `MainActivity.kt`) renders a `TerminalEmulator` model. All non-UI logic is in
`terminal/TerminalScreenState` (selection model and geometry, output pump/flush, PTY sizing, restart, key/IME translation, clipboard).
`TerminalViewModel`/`TerminalRepository` own the PTY session lifecycle; `TerminalTabs` manages multiple terminals.
The PTY reader → UI queue is bounded by `MemoryRuntimePolicy` (back-pressures the PTY rather than dropping output).

### Notebooks
Native Compose notebook editor (`NativeNotebook`, `NbModel`, `NbKernel`) on standard nbformat 4. Each notebook owns one Python kernel
process (`ide_kernel.py`, standard library only) started on first run in the project's interpreter; JSON lines over a loopback socket
with a random token. Sessions and kernels are process-scoped (`NotebookRepository`, `NotebookKernelManager`) and survive tab switches,
Raw-JSON toggling and Activity recreation. Supported: cell state, last-expression results, `display()`, rich outputs, `!cmd`, `%pip`,
`%%bash`, `%%time`, `%%writefile`, `%cd`, `%pwd`, `%matplotlib`, interrupt, restart. Not supported: `input()`, other magics, ipywidgets.

### Debugger and tests
`debug/DapDebugSession` talks DAP to `debugpy` (provisioned from the encrypted `dbg.psr` asset into `/opt/pyspace-debugger/site-packages`
on first use and added via `PYTHONPATH`; project venvs are not modified). `DebugController` exposes breakpoints, stepping and the
variable tree. `testing/ProjectTestController` discovers and runs tests through the bundled, stdlib-only `assets/pyspace_test_runner.py`
(unittest-based; pytest and coverage are used when the project has them), parses results, coverage and insights;
`TestExplorer.kt` is its UI.

### Browser
`IdeBrowser` is a real WebView (JS, DOM storage, cookies, downloads, device-size modes that change user agent and viewport width, console
panel, no cache). `browser/BrowserWebViewLifecycle` makes pause/resume/release idempotent. Browser buttons everywhere go through one
preference (Ask / IDE browser / phone browser). `usesCleartextTraffic=true` is required for localhost and LAN dev servers.

### GitHub
`github/GitHubApi` (REST), `GitHubPublish` (.gitignore handling, snapshot push), `GitHubImport` (zipball/tree download, clone).
Tokens are kept with Keystore-based encryption in `settings/IdePrefs`. UI is `GitHub.kt`.

### Settings
`IdePrefs` (SharedPreferences + Keystore) is read through `SettingsViewModel`/`SettingsRepository`. Settings overlay and cards live in
`settings/`. Includes theme, editor, symbol bar, popups, gestures, runtime/environment, display, web preview, memory & performance, about.

### Memory management
`MemoryRuntimePolicy` provides Balanced and Low-memory profiles (terminal scrollback, styled-line documents, image decode edge,
undo history budgets), reacts to `onTrimMemory`, and keeps a weak registry of trimmable caches. Image decoding downsamples before decoding.
Settings → Memory & performance shows live PSS/heap and offers cache clearing (never touches kernels, servers or user files).

### Crash handling
`CrashLog` is installed first in `Application.onCreate`, writes `last_crash.txt`, and the next start shows it. `CrashViewerActivity`
(own process) is a second launcher entry that works even if `MainActivity` cannot start.

## 9. Threading reference

- IO: file, socket, process, PRoot operations. Default: parsing, formatting, serialization. Main: Compose state and UI observers.
- `RunHub` exposes its change token as `StateFlow<Int>` and calls app observers on Main even when events come from worker threads. The runtime registry itself has no Compose dependency.
- Bridge callbacks run on a bounded daemon thread pool (`ide-bridge-worker`, `ThreadPoolExecutor` with an abort policy); work that touches Compose state hops to Main.
- Dedicated native reader/waiter threads exist in PTY, notebook socket and camera code. They are explicit resource-owning loops; keep their shutdown paths intact.

## 10. Stage 3 architecture changes

- `CodeIntelligenceRepository` is now registered in the application Koin graph and resolved at the `IdeRoot` composition boundary.
- `IdeShell` receives both `CodeIntelligenceRepository` and `RuntimeDispatchers` explicitly and creates each project-scoped `CodeIntelligenceViewModel` with those dependencies.
- `CodeIntelligenceViewModel` no longer creates a default repository or a default dispatcher policy. Its constructor and `Factory` require both dependencies, making ownership visible and deterministic.
- `FileTreeDrawer` now requires the project-owned `CodeIntelligenceViewModel`; it no longer creates a fallback ViewModel inside composition. `IdeShellContent` fails fast if the active project's ViewModel was not initialized.
- `EditorViewModel` no longer supplies default dispatcher/repository instances. Its project-scoped factory and direct fallback path receive the shared dispatcher policy and a project-root-bound `FileEditorRepository`.
- This is an incremental dependency-boundary improvement, not a claim that all project ViewModels are fully Koin-managed.

## 11. Stage 4 architecture changes

- Added immutable, Compose-independent notebook snapshot contracts under `domain/notebook/model`.
- Added `NotebookParser` / `NotebookSerializer` ports and `ParseNotebookUseCase` / `SerializeNotebookUseCase`.
- Moved nbformat JSON parsing and serialization into `data/notebook` adapters. Parsing now runs on the CPU dispatcher and produces an immutable snapshot; only then does `NotebookRepository` switch to Main to construct Compose-observable `NbDoc` / `NbCell` instances.
- Notebook serialization still snapshots Compose-backed state on the caller/Main thread, then sends only immutable values to the CPU dispatcher and the data adapter.
- Added immutable editor-session snapshot models under `domain/editor/model`, plus an editor-session serializer port/use case and JSON data adapter.
- `IdeShell` now receives `SerializeEditorSessionUseCase` explicitly through the Koin composition boundary; session persistence no longer calls a static JSON encoder on `EditorSession`.
- `NbModel.kt` is now the Compose-facing notebook adapter/model; it no longer owns nbformat JSON parsing or serialization.

This stage establishes real domain contracts and data adapters for notebook and editor-session persistence. It does **not** yet complete the migration of `EditorSession`, `OpenTab` or `NbCell` away from Compose state.



## 12. Stage 5 architecture changes

- Replaced `DebugController`'s Compose `mutableStateOf` fields with a single `DebugUiState` snapshot exposed as `StateFlow`. The debugger's DAP session remains privately owned by the controller; the debug panel collects the state flow at the Compose boundary.
- Removed the debugger controller's `snapshotFlow` dependency. `EditorBreakpointStore` now exposes a monotonically increasing `revision: StateFlow<Long>` signal in addition to its Compose-observable map, allowing the runtime debugger to synchronize breakpoint changes without importing Compose Runtime.
- Replaced `NbKernel`'s Compose-backed `state` and `info` properties with `StateFlow` values. Kernel process/socket lifecycle remains owned by `NbKernel`; `NativeNotebook` collects the flows for rendering and `NotebookViewModel` reads the current kernel state through `.value`.
- Preserved kernel message batching, main-thread publication, DAP generation guards, breakpoint synchronization and existing notebook session ownership.

Stage 5 removes Compose Runtime from the debugger controller and notebook kernel runtime state. It does not yet remove Compose state from `EditorSession`, `OpenTab`, `NbDoc`/`NbCell`, or the frame/camera models. The `EditorBreakpointStore` itself remains Compose-observable for the editor gutter and panels; its new Flow revision is the runtime-facing notification seam.

## 13. Stage 6 architecture changes

- Introduced `domain/editor/model/EditorDocumentBuffer`, a plain Kotlin document-content model with no Compose, Android, filesystem, or dispatcher dependency.
- `OpenTab` now acts as the Compose-facing adapter for document text: it mirrors edits into the domain buffer, delegates dirty tracking and saved-baseline handling to that buffer, and keeps caret-aware undo/redo and file reload orchestration at the editor boundary.
- Save tracking retains the exact-snapshot rule: if a newer edit occurs while an earlier snapshot is being written, the newer content remains dirty because the domain buffer marks only the written snapshot as saved.
- Reload updates both the presentation text and the domain buffer baseline, and still clears the existing bounded undo history.
- No file I/O was moved into the domain layer. Binary/oversized-file protection and existing editor tab behaviour remain in `OpenTab`.

Stage 6 is a first extraction of document state policy, not the complete removal of Compose state from `EditorSession` or `OpenTab`. The notebook `NbDoc`/`NbCell` Compose adapters also remain unchanged in this stage; those migrations require a separate pass because notebook UI and execution currently observe mutable cell/output state directly.

## 14. Stage 7 architecture changes

- Moved the Compose-observable notebook presentation graph (`NbDoc`, `NbCell`, `NbOutput`) and its snapshot conversion functions from the legacy `ide` package into `presentation/notebook/NotebookUiModels.kt`.
- Kept `ide/NbModel.kt` as a small compatibility facade so existing notebook UI/execution call sites remain source-compatible while future work migrates them to explicit presentation imports.
- Added `NotebookSnapshotFactory` in `domain/notebook/factory`. Empty nbformat 4.5 document creation and cell-ID generation now produce immutable domain snapshots without depending on Compose or Android UI classes.
- Updated the JSON parser to use the domain factory for missing cell IDs and empty-document creation. The parser continues to return immutable snapshots only.
- Kept conversion from immutable snapshots to Compose-observable models at the Main/presentation boundary, and kept snapshot capture before switching to the CPU dispatcher for serialization.
- No notebook kernel, message queue, execution scheduling, output truncation, persistence debounce, raw-JSON replacement, or session lifecycle policy was intentionally changed.

Stage 7 is a package/layer-boundary extraction, not yet the final removal of Compose state from notebook execution state. `NotebookViewModel` still coordinates execution against presentation cell models; a later stage should introduce a UI-independent notebook session state only after the current cell/output mutation contract has dedicated regression coverage.

## 15. Conventions for changes

- New feature = repository (I/O) + ViewModel (state, jobs) + composables. Resolve repositories from DI and inject them; do not construct default repositories inside ViewModels or Composables. Reuse existing ones before adding layers; do not add use-case classes unless they carry real logic.
- Prefer **moving** code with its imports over rewriting it. For splitting large files by top-level declaration, move whole declarations
  and fix `private`→`internal` visibility where another file needs them.
- Extending the IDE screen: put logic and shared state on `IdeShell`, UI in `shell/IdeShellContent.kt` (extension on `IdeShell`) or a feature package.
- Keep each change buildable; test the touched feature plus the regression paths: project switch/delete, notebook tab detach/reattach,
  terminal stop/restart, browser close/reopen, app background/foreground, run Stop All.

## 16. Final architecture ownership and intentional boundaries

The architecture is treated as a stable, practical Clean Architecture baseline for this single-module Android IDE. The following boundaries are deliberate:

- **Domain** owns deterministic policy and immutable models (`EditorDocumentBuffer`, notebook snapshots and `NotebookExecutionQueue`). It has no Android, Compose, Koin, filesystem, or process dependency.
- **Data/repositories** own persistence and environment operations behind explicit contracts. ViewModels receive repository interfaces; they do not create their own defaults.
- **Presentation** owns Compose-observable objects such as editor tabs, notebook cells/outputs, selection, caret, expansion, and rendering state. These are not domain entities and are allowed to use Compose Runtime at this boundary.
- **Platform/runtime** owns Android camera/display/browser surfaces, PRoot/PTY processes, native resources, and lifecycle adapters. These types may depend on Android APIs, but feature/domain policy must not depend on them.
- **Application composition** resolves Koin once in `MainActivity` into `AppDependencies`. Koin global access remains only at Android framework entry points (`Application`, `Service`, and Activity composition root).

### Project test subsystem

- `ProjectTestController` no longer imports Compose Runtime. Its immutable `TestSnapshot` and expanded-file set are published through `StateFlow`, collected by `TestView` at the presentation boundary.
- The controller owns a cancellable work scope, generation token, active process, and bounded timeout watchdog. `close()` is idempotent, invalidates in-flight generations, terminates the process, cancels the scope, and prevents new operations.
- `ProjectScopedResourceRegistry` owns one closeable controller per canonical project path. Project deletion and deliberate project exit evict and close the corresponding controller. The UI panel does not own or destroy project execution merely because it leaves composition.
- Cancellation exceptions are rethrown instead of being converted into ordinary runner errors. Process timeout cleanup is guaranteed even when output reading fails or is cancelled.

### Dependency construction

- `ProjectRepository` and `SettingsRepository` are registered in Koin and exposed through `AppDependencies`.
- `ProjectsViewModel.Factory` and `SettingsViewModel.Factory` require their repositories explicitly.
- `EditorViewModel.Factory` requires a project-root-bound `EditorRepository`; it does not construct one internally.
- `PackageManagerViewModel.Factory` requires a `PackageManagerRepository`; the project feature boundary creates the project adapter.
- `TerminalViewModel` receives its surface-scoped `TerminalRepository` explicitly.
- These changes make repository lifetime visible: process-wide repositories are shared, while editor and terminal adapters remain scoped to the project/surface that owns them.

### Large UI files and legacy state

Large composables such as `PyEditor`, `IdeEditor`, `TerminalScreen`, and `IdeShellContent` remain presentation composition units. Their size alone is not a reason for mechanical extraction: caret/IME/selection, terminal input, editor viewport, and overlay behavior are tightly coupled to the UI lifecycle. Runtime/domain controllers have been separated where they own independent policy or resources. UI-specific state is intentionally not forced into domain models merely to eliminate every `mutableStateOf` occurrence from the repository.

No new app modules, DI frameworks, runtime assets, or build-system assumptions were introduced. The single-module CodeAssist descriptor, PRoot/Ubuntu runtime, native bridges, encrypted assets, notebook kernel protocol, editor behavior, and existing feature workflows remain the compatibility constraints.

## 17. Architecture direction and compatibility constraints

The architecture should continue evolving through cohesive ownership boundaries, not mechanical file splitting or line-count targets. Changes must preserve the single-module CodeAssist import workflow, existing runtime assets and PRoot/Ubuntu behavior, and the established document/IME/LSP/viewport lifecycle semantics. Each extraction must have an explicit contract and must not create a second owner for document or UI state.

The full Android application still requires the normal CodeAssist build and device regression test because this environment does not contain the Android/CodeAssist toolchain. Standalone checks of pure helpers do not replace that build or device validation.

### Editor derived presentation state

`ide/editor/EditorDerivedState.kt` owns deterministic calculations derived from the editor document and analysis state. It builds the prefix index used to map wrapped display lines to visual rows and applies the existing rule for hiding diagnostics on the actively edited line until the source is validated. It contains no Compose or Android dependencies. `PyEditor` remains the coordinator for Compose state, LSP requests, document mutation, IME, gestures, and viewport lifecycle; those concerns are intentionally not split into stateful helpers without preserving their ordering and cancellation semantics.


### Editor language-intelligence effects

`ide/editor/EditorSignatureHelpEffect.kt` owns the debounced signature-help request lifecycle. It receives a document snapshot, caret/selection state, language eligibility, and the optional LSP controller, then reports the resolved signature through a callback. The effect is keyed to the active file and request inputs, so Compose cancels an obsolete request when the document or caret changes. The `PyEditor` composable remains responsible for storing and presenting the resulting signature state.


`ide/editor/EditorCompletionCandidates.kt` contains pure completion-candidate rules: import-context recognition, prefix/member-context filtering, duplicate resolution, and stable ranking. Request scheduling and edit-generation tracking remain in `PyEditor` because they are coupled to Compose snapshot state and the LSP request lifecycle.


### Completion acceptance boundary
`EditorCompletionApplier` is a non-Compose editor-domain helper. It receives the source buffer, replacement range, and completion item, then returns the resulting text and caret offset. It owns callable-parenthesis rules, decorator/import-context exceptions, and auto-import insertion-offset adjustment. `PyEditor` remains the owner of the active `TextFieldValue`, undoable tab edit, completion-popup dismissal, and cursor reporting. This keeps document transformation separate from UI/session mutation without duplicating editor state.


### Hover target resolution

`EditorHoverTargetResolver` is a pure editor-domain helper that maps a source offset to a validated identifier range. Pointer geometry, folded-document offset translation, LSP requests, cancellation, and popup presentation remain owned by `PyEditor`, preserving the existing Compose and request lifecycle boundaries.

### Editor lifecycle, formatting and external-command adapters

`PyEditor` remains the owner of the live document field, undoable edit commits, cursor state and dialog presentation. The following focused adapters isolate lifecycle and asynchronous workflow boundaries without owning a second document buffer:

- `EditorSessionLifecycle` persists selection and two-axis viewport state to `OpenTab`, clamps restored offsets after measurement, and cancels the latest hover job when the tab leaves composition.
- `EditorImeCaretEffects` owns focus clearing for inactive editor surfaces and the guarded, sequential caret-reveal passes coordinated with the animated IME inset.
- `EditorExternalEditEffects` handles file-targeted undo/redo, symbol-bar insertion, and structure/search jumps. It receives immutable field snapshots and explicit mutation/reporting callbacks.
- `EditorFormattingEffects` owns formatter and import-analysis coroutine lifecycles, stale-source rejection, and request-consumption timing. The UI confirmation for indentation reconstruction and the actual document/selection commit remain in `PyEditor`.

`OpenTab` remains the shared document/history owner; the adapters only coordinate effects around that model. Completion/LSP and hover request lifecycles remain separately scoped in their existing editor helpers.

### Shared editor text-layout geometry

`editor/EditorTextLayoutGeometry.kt` owns the derived geometry pipeline shared by wrapped text, caret navigation, and the gutter: display-line start offsets, bounded wrapped-row measurement, validation of the current `TextLayoutResult` against document/font/density, visual-row prefix indexing, and gutter row geometry with the measured-pitch fallback. It returns immutable geometry snapshots and `State` views for asynchronous caret effects. `PyEditor` continues to own the editable field, publication of layout results, viewport/scroll state, and all gesture/IME/zoom orchestration; the extracted helper does not mutate the document or initiate UI effects.

### Editor interaction policy and completion presentation

`editor/EditorInteractionPolicy.kt` now owns two deterministic presentation decisions: whether native selection handles fit wholly inside the visible code lane (including the handle reach, gutter, scroll offsets, bottom clearance, current fold projection, and stale-layout guard), and how a fold-chevron action updates the collapsed-key set and whether the current selection must be moved out of the newly hidden region. It does not mutate `OpenTab` or `TextFieldValue`; `PyEditor` remains the single owner that commits those results and reports cursor movement.

`editor/EditorCompletionPopup.kt` owns the completion list's Compose presentation, including kind markers, semantic colors, details, dismissal affordance, and popup layout identity. It receives the current immutable item list and explicit select/dismiss/position callbacks. Completion request scheduling, candidate ownership, acceptance, and document mutation remain in `PyEditor` and the existing completion helpers. This keeps popup rendering separate without introducing a second completion state owner.

### Editor popup presentation and information cards (Next 14)

- `EditorPopupPresentation` owns popup-anchor geometry and the visibility/precedence plan, including the same GPU pinch-preview transform applied to code, stale `TextLayoutResult` rejection, memoized anchor translation during pending sheet shifts, and card-slot sizing. `EditorPopupLayer` continues to own collision-aware placement and scroll containment.
- `EditorDocumentationCard` and `EditorDiagnosticCard` are presentation-only composables. Definition navigation, documentation dismissal, quick-fix validation, formatter execution, tab edits, cursor reporting, and popup hit-coordinate storage are injected from `PyEditor` through callbacks.
- The editor remains the single owner of the live document, selection, LSP result state, and edit commits. These extractions do not introduce another document/session state owner.


### Editor tap observation boundary (Next 15)

`editor/EditorCaretNavigation.kt` owns the asynchronous caret reveal and explicit centering workflows. It receives live read-only State handles for the current text layout, selection, folded document, and wrapped-row geometry, plus the editor's existing scroll states. It preserves stale-layout waiting, folded line mapping, handle-clearance-aware vertical reveal, gutter-aware horizontal reveal, and distance-based coordinated centering animation. `PyEditor` remains the sole owner of the field, document, viewport, and scroll states.

`editor/EditorTapObserver.kt` owns the non-consuming Initial-pass tap observer used by the editor surface. It detects a short stationary tap without interfering with `BasicTextField` caret placement or long-press selection, waits for the native field update, validates that the captured text/layout/document projection still agree, maps the tap through the current field and viewport coordinates, and resolves the fallback source offset through `FoldedEditorDocument`. Popup hit-testing, caret commit, cursor reporting, hover-documentation display, and the two transient interaction flags are explicit callbacks. `PyEditor` remains the sole owner of the document, selection, focus state, and popup/LSP state.

### Formatting workflow boundary (Next 16)

Formatting and Fix Imports request orchestration, including the confirmation flow for
reconstructing lost indentation, lives in `EditorFormattingWorkflow`. It delegates
asynchronous request execution to `EditorFormattingEffects`, owns only the transient
confirmation state, and reports accepted edits through the editor's existing buffer
callback. `PyEditor` remains the single owner of the live `TextFieldValue`, cursor
tracking, and document/session state; no second editor-buffer owner is introduced.


### Hover documentation workflow boundary (Next 18)

`editor/EditorHoverDocumentationWorkflow.kt` owns hover-request cancellation, tap-to-source resolution, offline documentation lookup, asynchronous LSP resolution, stale-source validation, and the transient documentation-card state (result, anchor, and expansion). It receives the current source/layout/fold/coordinate snapshot and a live source reader from `PyEditor`; it does not own the editor buffer, `TextLayoutResult`, field coordinates, or LSP controller lifecycle. The editor remains the sole owner of document edits, selection, and the surrounding viewport.

### Pinch gesture recognition boundary (Next 19)

The low-level two-pointer recognition loop now lives in `editor/EditorPinchZoomGesture.kt`. It owns only pointer observation, pinch distance tracking, and consumption of the two active pointer changes. Single-finger events remain unconsumed so `BasicTextField` selection/caret behavior and the outer scroll containers retain their existing gesture responsibilities. The modifier exposes explicit start, update, and end callbacks; font-size changes, zoom preview transforms, wrapped-layout anchoring, scroll compensation, and commit/settle lifecycle remain owned by `PyEditor` and its existing zoom workflow. Updated callback references are read through `rememberUpdatedState`, so an in-flight gesture does not use stale composition captures or restart on ordinary recomposition.

### Pinch zoom commit lifecycle (Next 20)

The post-gesture zoom hand-off now lives in `editor/EditorZoomCommitWorkflow.kt`. It sequences the final 90 ms preview settle, scale-ratio reconciliation against measured font metrics, gutter-aware target scroll calculation, compensation shift, font-size commit, and token-guarded timeout recovery. `PyEditor` still owns the actual Compose `MutableState` holders, scroll states, `ZoomAnchor`, and font/gutter providers; the workflow receives those existing objects explicitly and does not duplicate editor or viewport state. `EditorPinchZoomGesture` remains limited to recognizing and reporting pointer lifecycle events.


### Diagnostic action workflow boundary (Next 21)

`EditorDiagnosticActions` owns the diagnostic card's action coordination: deriving a quick-fix only when diagnostics match the current source, validating the warning/code eligibility for line reformatting, running the pylsp-first/local fallback formatter, applying the E303 blank-line exception, restricting other fixes to the diagnostic line, and rejecting asynchronous results if the source changed. All mutations are returned through explicit callbacks. `PyEditor` and `OpenTab` remain the only owners of the live field, undoable document commit, syntax-editing-line state, and cursor reporting; the helper does not cache a parallel document or LSP session.

### Popup and gutter surface boundary (Next 22)

`EditorPopupAndGutterLayers` now composes the editor's complete floating-information and gutter layer: it resolves caret/documentation anchors against the current layout and pinch-preview transform, creates the popup visibility/precedence plan, places completion/documentation/diagnostic/signature cards, positions the documentation bubble, and draws the gutter. Fold-chevron handling is colocated with that gutter surface, but commits collapsed keys and any selection-safe caret relocation only through explicit callbacks. The component remains a `BoxScope` child so the popup layout keeps its original `matchParentSize` measurement contract. It consumes the editor's current snapshots and existing scroll/zoom objects; `PyEditor` and `OpenTab` remain the sole owners of the editable field, document history, popup request state, and viewport state.


## Editor Refactor Next 23 — code input surface extraction

- Extracted the complete code-lane row and editable text input into `EditorCodeInputLayer.kt`: pinch-preview graphics transform, gutter spacer alignment, selection-handle visibility policy, text-selection locals/toolbar, `BasicTextField`, IME/edit normalization, completion-trigger invalidation, undo/redo shortcuts, focus/coordinate reporting, and text-layout reporting.
- Kept `PyEditor` as the sole owner of `TextFieldValue`, completion state, syntax-editing-line state, focus state, field coordinates, and document commits. The new surface receives values and explicit callbacks; all accepted text mutations still pass through the existing `OpenTab.applyEdit` path.
- Kept the component inside the same `Box`/`Row` measurement hierarchy. The code lane's `graphicsLayer`, gutter spacer, `BasicTextField` padding/height constraints, selection toolbar provider, and overlay toolbar remain in their original relative positions to avoid changing scroll geometry, wrap width, pinch anchoring, or popup hit-testing.
- Preserved native text selection/IME behavior, auto-indent processing, completion dismissal rules, Ctrl+Z/Ctrl+Shift+Z/Ctrl+Y handling, focus callbacks, and field/layout coordinate updates.
- Reduced `PyEditor.kt` from 1,308 to 1,159 lines; the extracted component is approximately 290 lines including its explicit input contract.

Verification: source-level structure and callback ownership were reviewed; ZIP integrity and required payload checks were run. Kotlin/Android module compilation and device regression tests were not run in this environment.

## Editor surface interaction boundary

`EditorSurfaceInteraction` owns viewport-space presentation and scrolling composition: the fixed gutter divider, viewport measurement callbacks, nested-scroll axis arbitration, two-axis pan placement, and whole-surface vertical/horizontal scrolling. Pinch and tap gesture modifiers are injected in a defined order so pointer coordinates remain in viewport space. `PyEditor` continues to own document state and gesture decisions/callbacks.

### Code-intelligence effect coordination boundary (Next 25)

`editor/EditorCodeIntelligenceEffects.kt` now provides one composition boundary for completion and signature-help request lifecycles. It accepts the current file and field snapshot, language/environment revision inputs, existing completion generation state, the LSP controller, and explicit state callbacks. The underlying `EditorCompletionEffect` and `EditorSignatureHelpEffect` retain their existing debounce, cancellation, and stale-result behavior. The coordinator does not own document, selection, completion popup, or signature-card state; those remain in `PyEditor`.

### Caret interaction coordination boundary (Next 26)

`editor/EditorCaretInteractionCoordinator.kt` now coordinates caret-driven viewport movement. It provides the live `EditorCaretNavigationSnapshot` to reveal/center operations, schedules asynchronous reveal requests on the editor scope, and routes caret reports through an explicit callback. The coordinator deliberately does not own `TextFieldValue`, caret line/column state, IME interaction flags, scroll states, or layout geometry; these remain owned by `PyEditor` and are supplied as live providers. This removes the local coroutine scheduling and navigation orchestration from the large editor composable without creating a second source of truth.


The diagnostics presentation boundary now uses `ide/editor/EditorDiagnosticsSessionState` for per-tab transient UI state: the line currently being edited and the diagnostic popup the user dismissed. Validated diagnostics remain inputs from the analysis layer; visibility filtering and diagnostic rendering remain derived/presentation responsibilities. This holder does not own validation, source snapshots, or language-server requests.

### Editor completion transaction boundary

Accepting a completion is coordinated by `ide/editor/EditorCompletionWorkflow`. It delegates insertion-string and import/call-parenthesis rules to the pure `EditorCompletionApplier`, then commits the resulting buffer through the existing `OpenTab.applyEdit` history boundary, publishes the new `TextFieldValue`, dismisses completion presentation, and reports the resulting caret. `PyEditor` remains the owner of the live document, selection, replacement range, popup state, and cursor callback; the workflow receives these as explicit inputs and does not retain editor state.


### Hover coordinate ownership (Next31.2)

`PyEditor` owns the fixed viewport `LayoutCoordinates` used by the surface tap observer. `EditorTapObserver` reports pointer positions in this coordinate space, and `EditorHoverDocumentationWorkflow` converts them into the editable field's local space. The viewport positioning callback must update `gestureCoordinates`; a null reference intentionally causes hover resolution to abort, so this wiring is part of the required editor interaction contract.


### Hover interaction reliability (Next31.3)

The surface tap observer is placed before the scroll and pan modifiers so its pointer positions remain in the same fixed viewport coordinate space as the `LayoutCoordinates` captured for hover resolution. Its callback is read through `rememberUpdatedState`, because the pointer-input coroutine may outlive layout-only recompositions and must not retain stale field/layout/fold snapshots. `EditorHoverDocumentationWorkflow` publishes valid offline documentation and the associated anchor immediately; the asynchronous definition lookup is guarded and can enrich the card without blocking the initial information affordance. These changes preserve the existing single-owner boundaries for document state, pointer observation, coordinate mapping, and documentation lifecycle.


## Architecture refactor — Stage 4 (Domain / Application boundary)

This stage establishes an explicit distinction between domain contracts/models and
application orchestration:

- `domain/**` contains framework-independent values and ports: editor document
  buffers/session snapshots/text snapshots, notebook snapshots, parser/serializer
  contracts, and notebook execution ordering.
- `application/**/usecase` contains application actions that coordinate those
  ports. `ParseNotebookUseCase`, `SerializeNotebookUseCase`, and
  `SerializeEditorSessionUseCase` now live here rather than under `domain`.
- `data/**` remains the adapter layer for JSON encoding/decoding. Android JSON
  implementation details stay out of the domain contracts and models.
- DI remains the composition root: `AppModule` binds data adapters to domain
  ports and constructs application use cases. Feature repositories receive
  use cases explicitly; they do not resolve dependencies globally.
- `EditorTextSnapshot` is now a domain value. The bounded undo/redo history
  remains in the editor adapter because its memory-pressure integration uses
  application memory policy/trim registries. A compatibility typealias keeps
  existing editor-history call sites source-compatible.

Ownership guardrails:
- Compose state, `File`, Android context, dispatchers, kernel processes, and
  runtime sessions must not be introduced into domain models.
- A use case must not become a second owner of mutable feature state; it
  coordinates a single owner and immutable inputs/outputs.
- JSON formats and filesystem details remain in data/platform adapters.
- Runtime-heavy operations (run/debug/kernel/LSP) stay behind their existing
  feature repositories/controllers; this stage does not invent generic
  repositories around already specialized runtime APIs.

The migration intentionally changes package ownership without changing notebook
JSON semantics, editor session payload keys, undo/redo bounds, or runtime lifecycle.

### Browser, Display, Camera, GitHub and Package Manager — Stage 6

- Browser URL-entry normalization is now a pure `domain/browser/BrowserUrlPolicy`. `BrowserState` remains a Compose-observable presentation adapter and continues to own WebView attachment/navigation, find/console state and UI-facing browser commands; WebView lifecycle destruction remains in `BrowserWebViewLifecycle`.
- Package management now has a domain contract and immutable result models in `domain/packages`. `PythonPackageSpec` owns pure requirement/package-name validation and `pip freeze` parsing. The PRoot-backed implementation lives in `data/packages/ProotPackageManagerRepository`; it remains the only adapter that executes pip, serializes mutations, resolves the project venv and bounds command output. The package ViewModel depends on the domain contract (which accepts a project-directory `File`, not the IDE `PyProject` model), not the PRoot implementation.
- Camera feature ownership is grouped under `ide/camera`: CameraX/localhost bridge implementation and its Compose panel moved together without changing permission checks, single-session policy, loopback-only binding, frame mailbox, or stop triggers. Source detection is a pure `domain/camera` policy; run-specific shell environment construction belongs to `ide/run/CameraRunCommandFactory`, while permission prompting and camera activation remain with the existing run coordinator and Android lifecycle owner.
- Display UI and runtime adapters are grouped under `ide/display`: VNC viewer, frame viewer, frame-display adapter, VNC protocol/server owner, and the guest window-manager payload now share the display feature boundary. The guest Python payload and RFB protocol semantics were moved without rewriting them. Compose viewer state and Android Bitmap ownership remain at the presentation/platform edge.
- GitHub Compose screens now live beside the already separated GitHub API, import and publish adapters in `ide/github`. The screen still dispatches blocking API/file operations to IO; encrypted token ownership remains in `IdePrefs`, and repository import/publish semantics are unchanged.
- This stage changes package ownership and dependency direction, not feature behavior. No camera, browser, display, GitHub or pip lifecycle was duplicated.


### Code Intelligence — focused ownership extraction (post Stage 7)

- Extracted `LspDocumentSynchronizer` from `PythonLspController`. The synchronizer owns the LSP document lifecycle notifications, version progression, and snapshot publication ordering. It receives the project URI resolver and environment-refresh callbacks explicitly, so it does not create another session or document owner.
- Extracted `LspWorkspaceConfiguration`. It now owns interpreter selection/fingerprinting, project-local Python import-root discovery, Jedi settings generation, and throttled workspace configuration refresh. `PythonLspController` delegates to it and resets it when the Python environment revision changes or the controller closes.
- `PythonLspController` retains process startup/shutdown, request scheduling/cancellation, stale-result validation, diagnostics aggregation, and project-scoped policy. The transport and document/configuration seams are now independently testable without moving LSP lifecycle ownership.


### IDE shell lifecycle ownership refinement

- `ProjectFeatureFactory` owns creation/restoration of project-keyed Editor, Explorer, and Code Intelligence ViewModels. `ProjectFeatureRegistry` remains their sole project-path registry; `IdeShell` exposes compatibility accessors but no longer constructs these feature graphs inline.
- `IdeSessionPersistence` owns snapshot revision ordering and crash/recents restore-marker invalidation. It receives the current project/editor from the shell and persists on the application runtime task scope.
- `ProjectLifecycleCleanup` owns deleted-project resource cleanup; `ProjectExitCoordinator` owns the ordered intentional-leave protocol (restore-marker invalidation, session save, project debugger/test teardown, run/camera shutdown, and presentation reset). Resource owners still perform their own disposal.
- `IdeRunSessionState` is the sole holder for transient console/web/camera/display run fields. `IdeShell` still coordinates Console Run/Stop/Rerun and supplies live UI/runtime callbacks; guest protocol callbacks and terminal stop/completion policy now have dedicated coordinators.

### IDE bridge and terminal run lifecycle — focused ownership extraction

- `IdeBridgeCoordinator` owns the guest protocol callback implementation (`prepare`, `start`, `port`, `done`, `stop`). It translates guest events into the shared `RunOrchestrator` and receives UI/runtime effects as explicit callbacks. The bridge server itself remains owned by the IDE host lifecycle, and `IdeRoot` still invalidates the host-active gate before detaching/stopping it.
- `TerminalRunLifecycleCoordinator` owns terminal-run stop/kill routing, Stop All, terminal completion, display-owner release, and camera release. It does not own PTYs or duplicate `RunHub`/`RunOrchestrator` state; those remain with their existing runtime owners.
- `IdeShell` now coordinates Console Run/Stop/Rerun and supplies the live callbacks required by the bridge and terminal lifecycle coordinators. Its compatibility methods remain for existing UI call sites.


### Console display and natural-completion ownership refinement

- `ConsoleDisplayLifecycleCoordinator` now owns the GUI display side-effects previously implemented in `IdeShell.startDisplay` and `IdeShell.startFrameDisplay`: display-operation generation checks, VNC startup/viewer attachment, frame wait/open behavior, and failure-title reporting. It receives the existing `VncDisplay`, `FrameDisplay`, `DisplayRunCoordinator`, and `RuntimeUiViewModel`; it does not create or duplicate those resource owners.
- `ConsoleRunCompletionCoordinator` owns the natural Console process-exit callback policy: mark the console stopped, finish the current shared run record, release the phone camera, clear the stale web URL, and conditionally close the VNC overlay after the existing 1.5-second generation-checked delay. Explicit Stop/Rerun invalidation remains in the shell/run owners.
- `IdeShell` now wires these collaborators and retains compatibility entry points for display start requests. Console command preparation/registration remains in `IdeShell` for now because it sequences the live source snapshot, web/camera preparation, guest command, shared run registration, and UI state transitions as one ordered operation.

### Project recovery presentation lifecycle boundary

`ProjectRecoveryEffects` now owns the Compose-lifecycle integration for active-project recovery: delayed snapshots of dirty editor buffers, periodic reconciliation, recursive filesystem watcher attachment, workspace-level detection of project deletion/moves, and delivery of recovery availability/errors or a missing-project event. `ProjectAutoRecoveryManager` remains the recovery-store owner and `ProjectRecoveryWatcher` remains the recursive watcher implementation. The effect adapter receives the active project/session, scope, workspace and callbacks explicitly; it does not own editor documents, project navigation state, or recovery storage. On project disappearance, `IdeRoot` supplies the single host callback that performs navigation and stops active runs/console.

### Root presentation adapters

`IdeRoot` delegates Activity-scoped ViewModel provisioning to `presentation/IdeRootViewModels`, project-scoped LSP attachment to `EditorLspHost`, Activity lifecycle persistence/camera effects to `presentation/IdeHostLifecycleEffects`, and Problems-panel diagnostic aggregation to `EditorProblemCounts`. These adapters own presentation wiring and scheduling only; repositories, ViewModels, the LSP controller, editor documents, and camera runtime retain their original state/resource ownership.


### Ownership refinement — IdeRoot presentation wiring

`presentation/IdeRootViewModels` is the single presentation factory for Activity-scoped root ViewModels. `EditorLspHost` attaches and disposes the active project LSP controller and releases documents on tab close. `IdeHostLifecycleEffects` attaches ON_STOP persistence and camera-shutdown behavior plus the 4-second persistence safety loop. `EditorProblemCounts` derives Problems panel totals with the original 220 ms debounce. These adapters do not create alternate state stores: they preserve the existing ViewModel, EditorSession, LSP controller, and camera runtime owners.


### Code Intelligence ownership additions

`PythonLspController` remains the project-scoped session and request-policy façade. `LspImportResolver` owns only the external Python AST/import-availability probe, while `PythonReferenceClassifier` owns pure source-level occurrence classification. Cancellation, document freshness validation, diagnostic publication/merging, and workspace refactor transactions remain with their existing owners to avoid duplicating state or changing transaction ordering.

### Console run launch boundary

`ConsoleRunLaunchCoordinator` owns the final launch transaction for Console runs: it allocates the shared run ID, builds the guest bridge hook and complete shell command, retires the previous Console registry entry, and registers the replacement through `RunOrchestrator`. `IdeShell` remains the presentation/runtime orchestrator for source capture, asynchronous web/camera preparation, conflict UI, Compose run state, and display startup. The coordinator uses a prepare/publish boundary so the shell commits its command and generation state before the shared registry is updated; `RunHub` remains the single observable registry.

## Ownership Refinement 8 — Console run planning

`ConsoleRunPlanningCoordinator` now owns the deterministic planning step for a Console launch: it classifies the immutable source snapshot through `RunSourceAnalyzer` and derives the Console/Terminal conflict identity through `RunIdentityResolver`. It returns a `ConsoleRunPlan` containing both decisions. `IdeShell.runInConsole` still obtains the editor/disk snapshot, presents conflict UI, schedules asynchronous project-web and camera preparation, updates Compose state, and starts the display; those operations require the live Android/Compose host. This extraction prevents source classification and run identity from being independently recomputed or subtly diverging inside the presentation orchestrator.

### Root environment adapters

The root composition delegates environment setup to `presentation/IdeRootEnvironment.kt`:

- `rememberIdeWorkspace` owns the Compose lifecycle of workspace preparation (loading, retry counter, and visible error), while `workspaceRoot` remains the filesystem/workspace policy implementation.
- `rememberIdeHostActivity` encapsulates ContextWrapper traversal and returns the existing Activity host; it does not retain or create an Activity.
- `IdeWindowThemeEffect` synchronizes the existing `IdeTheme` selection with Android status/navigation bars. It does not own theme preferences or theme policy.

These adapters keep `IdeRoot` focused on composing the IDE and coordinating feature surfaces. They preserve the prior IO dispatcher, retry behavior, system-bar colors, and light-bar flags.

### Editor indexing ownership

`IdeEditor` is the screen-level composition point for editor indexing UI. The project symbol index and Python-environment index lifecycle is encapsulated by `editor/EditorIndexingSession.kt`, which owns monitor creation, state collection, start/close effects, and transient index-chip timing. The detailed index dialog is a presentation component (`EditorIndexDetailsDialog`) driven by explicit state and callbacks. The screen retains only dialog visibility, selected tab, and package-filter input.

### Editor surface geometry ownership — Refinement 11

`PyEditor` now delegates the lifetime of measured surface coordinates, popup hit-test coordinates, and the two persistent popup anchor memos to `EditorSurfaceCoordinatesState`. The holder is keyed by the active document path, so viewport/field/gesture geometry and popup anchors are retired together when the editor switches documents. It also centralizes the popup hit-test operation and its coordinate set. The actual `TextLayoutResult`, scroll states, document/IME buffer, and live gesture execution remain in `PyEditor`: those values are consumed directly by the active Compose layout and are not promoted into a second editor model.


### Editor scroll-session ownership — Refinement 12

`editor/EditorScrollSession.kt` now creates the editor's shared horizontal and vertical scroll states and owns the associated saved-view restoration and dominant-axis nested-scroll policy. `PyEditor` consumes one `EditorScrollSession` and passes its same state instances to caret navigation, pinch zoom, and the editor surface. The helper does not own document text, selection/IME state, or actual scroll commands; those remain with their existing owners.

### Editor gutter geometry ownership — refinement 13

`EditorGutterLayout` now owns the canonical gutter geometry calculation used by the committed editor layout and pinch-zoom preview. It derives fold-slot width, line-number/marker/fold lane width, pixel conversions, preview-vs-committed width hand-off, and font-size-specific width projections from one immutable input snapshot. `PyEditor` supplies current font, density, visibility, folded-document line count, zoom scales, and pinch width, then distributes the resulting geometry to the existing gutter, popup, caret, and zoom consumers. No second geometry cache or mutable state owner is introduced; document, text layout, and gesture state remain with their existing owners.


### Pinch-zoom commit ownership (Refinement 14)

`EditorZoomCommitCoordinator` binds the current `EditorZoomSessionState`, the editor's shared horizontal/vertical scroll states, live gutter/text-padding providers, font metrics, and the font-size callback. `PyEditor` no longer assembles the commit transaction's mutable-state wiring. The animation and bounded recovery policy remain in `launchEditorZoomCommit`; gesture lifecycle policy remains in `EditorPinchZoomCoordinator`. This keeps three distinct responsibilities explicit: pointer lifecycle, commit dependency orchestration, and frame/scroll transaction execution.

### Editor viewport measurement ownership

`EditorViewportSessionState` is the per-document presentation owner for measured viewport dimensions, editable-field width, and the latest `TextLayoutResult`. The editor surface reports measurements to this session; caret navigation, zoom anchoring, layout geometry, popup placement, and gutter layers consume the same snapshot. It intentionally does not own document text, TextField/IME state, scroll offsets, or popup coordinate registrations.

### Editor syntax presentation

`EditorSyntaxPresentation` is the presentation projection for syntax rendering. `rememberEditorSyntaxPresentation` combines the already-owned source/validation/diagnostic inputs into the visible diagnostic list and the `VisualTransformation`, while preserving the per-file highlight cache. It does not own source text, language-server analysis, diagnostic dismissal, or folding state.

### Editor feature package ownership (Refinement 17)

The folded-document projection (`EditorFoldRegion`, `FoldedEditorDocument`) and the editor selection-toolbar presentation (`EditorSelectionToolbarState`, `EditorSelectionToolbarOverlay`) are owned by `ide/editor`. Root-level IDE composition may instantiate these components, but the implementations live with the editor feature. Folding remains a pure document projection over source text and collapsed fold keys; it does not become a second document store. The selection toolbar remains a single Compose presentation state shared by the code-input and rename workflows.

### Editor chrome component ownership (Refinement 18)

The editor's reusable chrome primitives now live in `editor/EditorChromeComponents.kt` rather than at the tail of the `IdeEditor` screen coordinator. This includes the keyboard symbol strip and its individual keys, the save glyph, and the compact index metric tile. These components are shared by the editor screen and index-details presentation, so their ownership is now explicit at the editor-feature presentation layer. The screen coordinator retains only the state and callbacks that configure these components; no editor session state or behavior was duplicated.

### Code Intelligence — Ownership Refinement 19 (native diagnostics session)

- Added `PythonNativeDiagnosticsSession` to own the app-native Python type-checking lifecycle independently from the pylsp transport: per-file debounce jobs, source-generation freshness, native diagnostic snapshots, file removal, environment-reset clearing, and controller shutdown.
- `PythonLspController` now delegates native-check scheduling and lifecycle cleanup to that session. It remains the single project-scoped LSP process owner and the single publication/merge point for pylsp and native diagnostics.
- Preserved the 320 ms native-check debounce, CPU dispatcher, source-size/extension guards, cancellation behavior, diagnostic code namespace, and existing `StateFlow` output contracts. No second diagnostics publisher or document source of truth was introduced.


### Workspace reference resolution boundary (Ownership Refinement 20)

`PythonWorkspaceReferenceResolver` owns project-wide reference aggregation: canonical open-document snapshots, pylsp/Jedi reference normalization, project-bound URI-to-file validation, source snippets, occurrence classification, and the bounded local-index supplement. `PythonLspController` supplies the active session/document operations and serializes workspace import-root refresh through its existing mutex. The controller remains the sole owner of LSP request policy, session lifetime, and rename transactions; the resolver owns no mutable session or diagnostic state.

### Editor navigation chrome ownership — Refinement 21

`editor/EditorNavigationChrome.kt` owns the reusable open-tab strip and project-relative breadcrumb presentation. `EditorTabStrip` receives the existing `EditorSession` and delegates close/save policy through a callback; it does not own tab lifecycle or persistence. `EditorBreadcrumb` derives the visible path from the existing project root and active file, while path reveal and drawer opening remain host callbacks. `IdeEditor` now composes these components rather than embedding their layout and navigation details. The editor session remains the sole owner of tabs, active selection, and tree-reveal requests.


### IDE root runtime-effect ownership — Refinement 22

`IdeRootRuntimeEffects` now owns three root-level runtime observers: the one-time Android notification-permission prompt, Console transcript URL discovery, and terminal-process liveness reconciliation. The adapter receives the existing `RunOrchestrator`, `TermController`, `RuntimeUiViewModel`, permission launcher, preferences, and terminal-completion callback as explicit dependencies. It does not own process records, terminal sessions, Console state, or runtime UI state; it only observes and forwards events. `IdeShell` launch-marker resolution is also isolated in immutable `IdeLaunchRestoreState`, which resolves the persisted project path once and supplies both restored-screen and missing-project outcomes. The IO-bound web-project scan and phone-camera bridge preparation stages are delegated to `ConsoleRunPreparationCoordinator`; request-generation ownership and the final ordered launch continuation remain in `IdeShell`.


### Terminal and notebook output ownership — Refinement 23

`ide/terminal/TerminalOutputBuffer.kt` now owns the thread-safe PTY reader hand-off: bounded pending-character accounting, lossless back-pressure, queue draining, and session reset/stop semantics. `TerminalScreenState` retains Compose scheduling and terminal-emulator mutation on the UI thread, but no longer owns the concurrent queue/monitor/atomic accounting primitives. The `TerminalScreen` lifecycle adapter calls explicit buffer reset/stop operations and reads the buffer's last-output timestamp for Console input-prompt detection.

`ide/notebook/NotebookOutputBuffer.kt` owns per-cell output-size accounting, MIME payload limiting, stream coalescing, truncation policy, and the 45 ms batched output-revision publication. `NotebookViewModel` remains the single notebook execution/session state owner: it decides which cell is active, handles kernel messages and execution transitions, and delegates output materialization/publication to the buffer. The kernel, notebook document, execution queue, and persistence lifecycle remain unchanged and are not duplicated.


## Final architecture baseline — Ownership Refinement 24

The planned ownership-refinement sequence is complete. The final pass tightened the terminal PTY hand-off so enqueue is bounded even for oversized reads and per-frame drains respect their requested character budget; it also retired stale notebook output notifications on document replacement and cell removal. The full ownership map, dependency checks, intentional single-module constraints, and verification limits are recorded in `ARCHITECTURE-AUDIT.md`.

The architecture is considered complete for the current single-module Tyron CodeAssist delivery model: domain/application boundaries are framework-independent, implementation bindings are centralized, feature/session state has explicit owners, and the major lifecycle workflows have focused collaborators. Future work should be feature development or targeted defect correction, not another planned architecture-refinement phase.
