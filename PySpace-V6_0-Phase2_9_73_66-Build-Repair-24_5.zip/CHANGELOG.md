## Architecture refactor — Stage 2 (PyEditor ownership boundaries)

- Added `EditorTextInputState` as the per-document presentation owner for Compose `TextFieldValue`, including selection and IME composition. `OpenTab` remains the sole source of truth for document text, dirty tracking and edit history; the new holder never persists or independently edits document content.
- Centralized external document replacement, selection requests and caret placement in `EditorTextInputState`; `EditorDocumentSyncEffects` now schedules those operations but no longer reimplements text/selection mapping.
- Added `EditorCompletionSessionState` to own completion candidates, replacement range, edit/caret trigger generations, LSP environment revision and signature-help presentation for each open document.
- Kept diagnostics dismissal/editing-line state in `EditorDiagnosticsSessionState`, hover/documentation state in `EditorHoverDocumentationWorkflow`, caret interaction in `EditorCaretSessionState`, and zoom state in `EditorZoomSessionState`. Compose-only viewport coordinates, TextLayoutResult, scroll states and gesture measurements remain in `PyEditor` because they are tied to the live layout tree.
- Preserved the existing edit pipeline, undo/redo, LSP request policy, popup rendering, selection persistence and document save behavior. No duplicate document buffer or second owner for selection persistence was introduced.

Verification: source-level call-site/signature checks, ownership review and ZIP integrity checks completed. Full Android/CodeAssist build and device regression remain pending in the user's environment.

## Next31.3 hover reliability and documentation activation fix

- Changed the editor tap observer placement so it receives pointer positions in the fixed viewport coordinate space, matching the `LayoutCoordinates` captured by `onViewportPositioned`; it no longer interprets a scrolled content-space position as a viewport-space position.
- Routed hover activation through `rememberUpdatedState`. The pointer-input coroutine can remain active across scroll, resize, font zoom, and layout recompositions, so it now invokes the latest source/layout/fold/coordinate snapshot instead of a callback captured when the pointer-input keys last changed.
- `EditorHoverDocumentationWorkflow` now publishes a valid offline documentation result and its anchor immediately, rather than waiting for the definition lookup to finish. Definition resolution is isolated behind a guarded asynchronous result; provider failures no longer suppress already available documentation.
- Kept the existing architecture boundaries: `PyEditor` owns the live document and Compose snapshots, `EditorTapObserver` observes gestures, `EditorHoverPosition` maps viewport coordinates to the field, and `EditorHoverDocumentationWorkflow` owns asynchronous documentation state.

Verification: source references, modifier ordering, and ZIP integrity checked. Full Android/CodeAssist build and device regression still require the user's environment.

## Next31.2 hover / documentation interaction fix

- Restored the fixed editor-viewport `LayoutCoordinates` reference consumed by `EditorTapObserver` and `EditorHoverDocumentationWorkflow`.
- The reference had remained permanently null after the surface extraction, causing hover resolution to return before resolving a word. This suppressed the “i” documentation bubble and the documentation card containing Go To Definition.
- `onViewportPositioned` now updates both the viewport reference and the gesture-coordinate reference; pointer coordinate conversion continues to use the fixed viewport rather than the scrolling text field.
- This is a targeted runtime regression fix. Full Android/CodeAssist build and device regression beyond the user's successful Next31.1 install remain to be verified.

## Next31 build corrections — Compose imports and editor boundary types (Next31.1)

- Corrected the `TextRange` import to `androidx.compose.ui.text.TextRange` and removed an invalid/unused `matchParentSize` import.
- Removed the duplicate `ScrollState` import from `EditorPopupAndGutterLayers`.
- Marked `editorSurfaceInteraction` as `@Composable` and made its injected pinch-zoom modifier a composable lambda, matching the `twoAxisPan` and pinch gesture APIs it composes.
- Restored the editor field-width state used by word-wrap geometry and the code input measurement callback.
- Passed the editor language enum name to the completion effect, supplied live `State` snapshots to caret navigation, converted viewport height to the expected `Float`, and passed the hover symbol name to the code-input tap guard.

These changes address the compiler diagnostics reported against Next31. Source-level signatures and references were checked. A full Android/CodeAssist build is still required to confirm the fix on the target toolchain.

## Editor architecture continuation — pinch-zoom lifecycle coordination (Next30)

- Added `ide/editor/EditorPinchZoomCoordinator` to own the transition rules after the pointer recognizer identifies a two-finger gesture: wrapped live reflow anchoring, unwrapped preview scale/gutter updates, commit hand-off, and delayed wrap-session cleanup.
- Replaced the large inline start/update/end callback bodies in `PyEditor` with explicit coordinator method references. The low-level `EditorPinchZoomGesture` remains responsible only for pointer recognition and consumption.
- The coordinator receives live layout/document/geometry providers and the existing zoom-session holder; it does not own document text, font preferences, scroll persistence, or the animation implementation.
- Preserved the existing zoom bounds (9–24sp), quarter-sp wrapped increments, 160ms wrapped-session settling delay, anchor rules, and commit workflow entry point.

Verification: source-level structure/reference checks and ZIP integrity checks completed. A full Android/CodeAssist build and device regression pass are not available in this environment.

## Editor architecture continuation — pinch-zoom session ownership (Next29)

- Added `ide/editor/EditorZoomSessionState` as the single presentation-state owner for pinch preview scales, target font, pivot, active-gesture/commit flags, visual commit compensation, preview gutter width, and the `ZoomAnchor` lifecycle object.
- Replaced the corresponding independent `remember` declarations in `PyEditor` with one remembered zoom-session holder while preserving the existing `MutableState` handles consumed by the animation workflow.
- Moved the atomic layer-scale, gutter-font-ratio, and sheet-shift presentation derivations into the holder. The zoom gesture recognizer, frame animation, font commit, scroll re-anchoring effects, and wrap behavior remain at their existing workflow boundaries.
- No intended changes to pinch thresholds, zoom limits, animation timing, scroll anchoring, selection-handle suppression, or word-wrap behavior.

Verification: source-level reference checks and ZIP integrity checks completed. A full Android/CodeAssist build and device regression pass are not available in this environment.

## Editor architecture continuation — diagnostics presentation session (Next28)

- Added `ide/editor/EditorDiagnosticsSessionState` to group the per-tab transient diagnostic UI state: the line being edited and the diagnostic popup explicitly dismissed by the user.
- Routed external document synchronization, edit-line suppression, caret-line dismissal reset, and popup dismissal through the holder.
- Kept validated diagnostic data, source-version checks, visibility derivation, syntax analysis, and rendering outside the holder; it does not duplicate language-server or document ownership.
- No intended change to diagnostic validation, underline filtering, popup eligibility, or dismissal behavior.

Verification: source-level reference checks and ZIP integrity checks completed. A full Android/CodeAssist build and device regression pass are not available in this environment.


# Changelog

## Editor architecture continuation — per-tab caret session state (Next27)

- Added `ide/editor/EditorCaretSessionState` to group the tab-scoped caret line/column, real-interaction flag, first-tap settling flag, and transient jump-flash line.
- Replaced five independently remembered caret-related state values in `PyEditor` with one remembered state holder. Cursor reporting now updates the holder atomically before notifying the external cursor callback.
- Kept `TextFieldValue`, document selection, IME ownership, scroll state, caret reveal/centering, and flash rendering at their existing boundaries. The holder does not create a second source of truth for selection or document content.
- No intended changes to caret coordinates, first-tap keyboard settling, search/structure jump highlighting, completion, hover, folding, or zoom behavior.

Verification: source-level reference checks and ZIP integrity checks completed. A full Android/CodeAssist build and device regression pass are not available in this environment.


## Editor architecture continuation — hover resolution and document synchronization

- Extracted `EditorHoverPosition` to map pointer coordinates through the TextField/gesture coordinate spaces and validate the hit against the rendered line bounds. It returns the field-local anchor and display-text offset without owning popup state.
- Extracted `EditorHoverResolver` to resolve offline documentation plus LSP hover/definition results against one immutable source snapshot. It filters missing files and self-definition locations; the caller retains Job cancellation and stale-source publication checks.
- Extracted `EditorDocumentSyncEffects` to synchronize externally applied document changes and one-shot external selections into `BasicTextField` while preserving the existing selection-clamping and diagnostic-editing-line reset behavior.
- `PyEditor` remains the single owner of hover UI state, folded-display/source offset mapping, document text, and request lifecycle.


## Editor architecture continuation — hover target resolution extraction

- Added `ide/editor/EditorHoverTarget.kt` to resolve the source identifier under a hover offset, including punctuation-adjacent caret positions and identifier validation.
- `PyEditor` still owns pointer-coordinate conversion, folded-display-to-source mapping, hover request cancellation, LSP hover/definition calls, stale-document checks, and popup state.
- This keeps source-token resolution pure and independently testable without moving layout or asynchronous lifecycle ownership.

## Editor architecture continuation — caret viewport calculations extraction

- Added `ide/editor/EditorCaretViewport.kt` for pure vertical/horizontal caret reveal and centering target calculations.
- `PyEditor` continues to resolve live Compose layout geometry, folded-document offsets, scroll state and animation timing; the extracted helper receives scalar geometry and returns bounded targets only.
- Kept the existing reveal margins, caret-handle clearance, center thresholds and word-wrap behavior unchanged. This avoids moving Compose state ownership or animation lifecycle out of the editor coordinator.

## Editor architecture continuation — completion candidate logic extraction

- Extracted import-context detection, context-prefix filtering, deterministic deduplication, and ranking into `ide/editor/EditorCompletionCandidates.kt`.
- The helper is pure Kotlin and keeps the existing precedence rule: auto-import candidates win same-name collisions; otherwise the lowest-priority value wins, followed by priority/name sorting and the 80-item cap.
- `PyEditor` retains ownership of edit generations, debounce, stale-request cancellation, local/LSP merging decisions, and completion replacement ranges.

## Editor architecture continuation — signature-help lifecycle extraction

- Moved the debounced Python signature-help request into `ide/editor/EditorSignatureHelpEffect.kt`.
- The effect now owns its request keys, 110 ms debounce, and cancellation lifecycle; the editor passes the current document snapshot and receives the result through an explicit callback.
- Preserved the open-call-context guard and trigger-character behavior for `(` and `,`.
- Completion, hover documentation, editor selection, and IME behavior remain separate and unchanged.

## Editor architecture continuation — project rename dialog extraction

- Extracted the project-wide symbol rename review and confirmation dialog from `PyEditor.kt` into `ide/editor/EditorRenameDialog.kt`.
- Kept LSP workspace-edit execution, multi-tab buffer synchronization, saved-baseline updates, caret remapping, tree refresh, and cancellation ownership in `PyEditor` to avoid changing transaction semantics.
- The extracted composable receives immutable display inputs and explicit callbacks; it does not access the editor session, LSP controller, or Compose global state directly.
- No intended changes to rename behavior, editor input/IME handling, completion, diagnostics, folding, zoom, or persistence.

Older per-feature notes (versions 2.x up to 2.9.73.55) were removed when the documentation was rewritten;
the code and `ARCHITECTURE.md` are the source of truth.

## 2.9.73.56 – 2.9.73.66 — Architecture refactor (no feature changes)

Goal: separate logic from UI and break up oversized files before the first release. Every step moved code without changing behavior.

| Step | Result |
|---|---|
| Logic out of UI files | GitHub client → `github/`; Test Explorer models/controller → `testing/`; VNC client → `display/` |
| `IdeModel.kt` split | → `theme`, `projects`, `gui`, `files`, `terminal`, `editor`, `settings`, `learn`, `packages` |
| Single editor entry point | `EditorViewModel` owns `EditorSession`; synchronous legacy open/save paths removed |
| `IdeRoot` decomposition | logic/state → `shell/IdeShell`; dialogs/overlays/screen host/bottom panel → `shell/IdeShellContent`; `IdeRoot()` 2,262 → ~600 lines |
| `TerminalScreen` | selection, output pump, PTY sizing and key/IME logic → `terminal/TerminalScreenState` (2,150 → ~950 lines) |
| `PyEditor.kt` | top-level helpers, popups, viewport, gutter, colors → `editor/` (composable body intentionally unchanged) |
| `IdeHome.kt` split | → `home/`, `ui/`, `settings/` cards |
| `IdeEditor.kt` + `IdeRoot.kt` leftovers | → `editor/IdeEditor`, `filetree/*`, `ui/DrawerGestures`, `shell/IdeShellComponents`, `projects/LessonsProject` |
| Documentation | replaced ~240 historical notes with `README.md`, `ARCHITECTURE.md`, `docs/RUNTIME-AND-TOOLING.md`, this file |
| Removed | unused unit-test sources under `app/src/test` (no test runner is available for this project) |


## Architecture cleanup — working changes on 2.9.73.66

- Registered `FileExplorerRepository` in Koin and removed repository construction from `FileExplorerViewModel`.
- Injected the file-explorer repository into the project-scoped ViewModel factory.
- Passed process-scoped notebook/run services and runtime scope into `IdeShell` explicitly; removed its direct Koin service-locator calls.
- Passed `NotebookRepository` from the IDE composition boundary through `IdeEditor` to `NativeNotebook`; removed Koin lookup from the notebook feature composable.
- Made `FileTreeDrawer` require the existing project-scoped explorer ViewModel, preventing an untracked fallback instance.
- Corrected architecture documentation to mark the refactor as in progress and list remaining work.


## Architecture refactor — Stage 2 (based on the Stage 1 working snapshot)

- Fixed the Stage 1 compile regression: removed the stray `notebookRepository` named argument from the `PyEditor` call. The repository remains passed to `NativeNotebook`, which is its actual consumer.
- Removed Jetpack Compose Runtime state from `RunHub`. Its change token is now exposed as `StateFlow<Int>`; Compose screens collect it at the UI boundary, while runtime/service code remains Compose-independent. Main-thread serialization of app observer callbacks is preserved.
- Injected `RuntimeDispatchers` into `InstallViewModel` and its factory; the Python language-server installation step now uses the shared IO dispatcher policy instead of hardcoding `Dispatchers.IO`.
- Updated architecture notes to distinguish migrated runtime state from remaining Compose-coupled legacy models.

Verification: archive integrity and targeted source/call-site consistency checks completed. A full Android/CodeAssist build was not available in this environment; this stage is not represented as device-build verified.


## Architecture refactor — Stage 3 (based on the user-confirmed Stage 2 build)

- Registered `CodeIntelligenceRepository` in Koin and resolved it at the `IdeRoot` composition boundary.
- Passed the repository and shared `RuntimeDispatchers` explicitly into `IdeShell`.
- Removed default repository/dispatcher construction from `CodeIntelligenceViewModel`; its constructor and ViewModel factory now require dependencies.
- Removed the fallback `CodeIntelligenceViewModel` creation from `FileTreeDrawer`. The drawer now requires the project-scoped instance owned by `IdeShell`, and the call site checks that initialization invariant explicitly.
- Removed implicit dispatcher/repository defaults from `EditorViewModel`; project-scoped factory and direct construction now receive the shared dispatcher policy and an explicit project-root-bound `FileEditorRepository`.
- Updated architecture documentation to record the new ownership and DI boundary.

Verification: source-level constructor/call-site consistency checks and ZIP integrity checks completed. A full Android/CodeAssist build is not available in this environment; verify this stage in CodeAssist before treating it as build-confirmed.


## Architecture refactor — Stage 4 (based on the user-confirmed Stage 3 build)

- Added immutable, Compose-independent notebook snapshot models in `domain/notebook/model`.
- Added notebook parser/serializer contracts and use cases; JSON nbformat parsing and serialization now live in `data/notebook` adapters.
- Notebook parsing now runs on the CPU dispatcher into an immutable snapshot, then creates Compose-observable notebook objects on the Main dispatcher at the presentation boundary.
- Notebook serialization captures mutable Compose state before dispatcher switching and sends only immutable snapshots to the data adapter on the CPU dispatcher.
- Added immutable editor-session snapshot models, an editor-session serialization contract/use case, and a JSON persistence adapter in the data layer.
- Injected `SerializeEditorSessionUseCase` into `IdeShell` through Koin; removed the static JSON encoding responsibility from `EditorSession`.
- Updated architecture documentation and Koin registrations.

Verification: pure domain contracts/use cases compile with the standalone Kotlin compiler; source-level call-site and dependency-graph checks plus ZIP integrity checks completed. The full Android/CodeAssist build is not available in this environment. Build and test Stage 4 in CodeAssist before treating it as verified.


## Architecture refactor — Stage 5 (based on the user-confirmed Stage 4 build)

- Migrated `DebugController` observable state from Compose mutable state properties to a `DebugUiState` snapshot published through `StateFlow`; the Debug panel now collects this state at the presentation boundary.
- Removed `snapshotFlow` from `DebugController`. `EditorBreakpointStore` now exposes a `StateFlow<Long>` revision signal so the DAP controller can observe gutter/panel breakpoint changes without depending on Compose Runtime.
- Migrated `NbKernel.state` and `NbKernel.info` to `StateFlow`; `NativeNotebook` collects them and `NotebookViewModel` reads the current state via `.value`.
- Preserved existing DAP generation checks, output batching, kernel socket/message batching, and notebook process ownership.
- Updated architecture documentation to reflect the remaining Compose-coupled models accurately.

Verification: targeted source/call-site searches and archive integrity checks completed. A full Android/CodeAssist build is not available in this environment; Stage 5 must be built and regression-tested in CodeAssist before treating it as verified.


## Architecture refactor — Stage 7 (based on the user-confirmed Stage 6 build)

- Moved Compose-observable notebook UI models and snapshot conversion code into `presentation/notebook`.
- Kept `ide/NbModel.kt` as a compatibility facade to avoid a broad risky rewrite of notebook UI/execution call sites in this stage.
- Added a pure domain `NotebookSnapshotFactory` for empty notebook snapshots and stable cell ID generation.
- Updated `JsonNotebookParser` to rely on the domain factory; parsing and serialization continue to operate on immutable snapshots in the data/domain boundary.
- Preserved notebook execution, kernel ownership, persistence, raw JSON replacement, and output batching behaviour.

Verification: source-level dependency/call-site checks and ZIP integrity checks completed. A full Android/CodeAssist build is not available in this environment; build and regression-test Stage 7 in CodeAssist before treating it as verified.


## Architecture refactor — Stage 8
- Fixed the Stage 7 `emptyCodeCell()` unresolved reference in `JsonNotebookParser`; the fallback cell now comes from `NotebookSnapshotFactory`.
- Extracted notebook execution FIFO/capacity bookkeeping into the UI-independent `NotebookExecutionQueue`, keyed by stable cell IDs.
- Preserved kernel protocol, execution lifecycle, output accumulation/throttling, persistence debounce, and Raw JSON replacement behavior.
- Static verification completed; a full Android/CodeAssist build remains required on the user's device.


## Architecture refactor — Stage 9 (final consolidation)
- Added a typed `AppDependencies` bundle as the main UI composition-root contract.
- `MainActivity` now resolves the process graph once, before entering Compose, and passes explicit dependencies to the root UI.
- Removed Koin `GlobalContext` lookups from `UbuntuTerminalApp`, `InstallScreen`, and `IdeRoot`; recomposition no longer performs service-locator resolution.
- Kept Koin global access only at process/Android framework boundaries: `Application` startup, the foreground `Service`, and the Activity composition root. These are framework integration points, not feature-layer dependencies.
- Preserved the existing service-owned run lifecycle, application-scoped runtime/notebook services, and all notebook queue/kernel semantics.
- Audited remaining `runBlocking` calls: project indexing runs on its dedicated serial worker; the two terminal bridge adapters run on the bounded `ide-bridge-worker` pool because the guest HTTP bridge contract is synchronous. None is invoked by Compose Main. These remain explicit synchronous platform-boundary adapters rather than being disguised as suspend feature APIs.
- Updated architecture documentation with the final dependency ownership rules and known remaining legacy boundaries.

Verification: source-level dependency/call-site checks, Kotlin syntax/structure checks, and ZIP integrity checks completed. A full Android/CodeAssist build and device regression pass are still required; Stage 9 is not treated as build-confirmed until the user tests it.


## Architecture consolidation — final baseline (based on user-confirmed Stage 9)

- Replaced `ProjectTestController` Compose Runtime state with immutable `StateFlow` snapshots; `TestView` now collects the state at the presentation boundary.
- Added `ProjectScopedResourceRegistry`, a synchronized, canonical-path registry for closeable project resources. Test controllers are evicted and closed when a project is deleted or deliberately left.
- Made test-controller shutdown idempotent: it invalidates active generations, stops the owned process, cancels the controller scope, rejects future work, and clears project-local expansion state. Cancellation is propagated correctly and the process timeout watchdog is always interrupted/cleaned up.
- Centralized repository bindings for project metadata and settings in Koin and exposed them through `AppDependencies`. `ProjectsViewModel.Factory` and `SettingsViewModel.Factory` now require repository interfaces.
- Removed hidden repository construction from editor/package ViewModel factories and the terminal ViewModel constructor; project/surface repository scope is now explicit at the owning feature boundary.
- Kept UI-only Compose state in presentation adapters instead of forcing it into domain models. No feature behavior, Ubuntu runtime, notebook kernel protocol, debugger protocol, editor semantics, or CodeAssist build configuration was intentionally changed.

Verification: standalone Kotlin smoke tests passed for `ProjectScopedResourceRegistry`, `EditorDocumentBuffer`, and `NotebookExecutionQueue`; source/call-site/dependency-boundary checks and archive integrity checks passed. The Android/CodeAssist build is not available in the preparation environment, so this package is delivered as the final architecture baseline for the user's normal CodeAssist build, not falsely described as device-build verified.


## Architecture consolidation — Activity and editor boundaries

- Reduced `MainActivity.kt` to the Android entry point and typed dependency composition root.
- Extracted Ubuntu install flow into `UbuntuInstallFlow.kt`.
- Extracted terminal screen, terminal selection UI helpers, IME overlap handling and Activity soft-input-mode ownership into `TerminalScreen.kt`.
- Moved shared terminal styles, touch geometry and output/clipboard limits into `TerminalUiTokens.kt`.
- Extracted editor font-metric caching, wrapped-line measurement with bounded LRU cache and canonical gutter-width calculation into `EditorLayoutMetrics.kt`; existing editor state/gesture behavior remains in `PyEditor`.


## Editor decomposition — interaction support extraction

- Extracted the `BasicTextField` input-normalization decision into `EditorInputEditProcessor`, which returns an immutable result and does not mutate the document or Compose state. The existing editor callback retains ownership of completion dismissal, edit commit, cursor reporting and syntax-edit tracking.
- Extracted popup hit-testing geometry into `EditorPopupHitTester`; popup coordinate ownership and gesture policy remain in the editor surface.
- Updated the architecture map to document the new presentation helpers and the remaining shared-state coordination boundary.
- No editor features, key handling, IME behavior, completion timing, formatting, folding, scrolling or zoom policies were intentionally changed.

Verification: source-level call-site checks and ZIP integrity checks completed. Full Android compilation and device interaction tests are not available in this environment.

## Editor architecture continuation — derived presentation state

- Extracted editor-derived presentation calculations into `EditorDerivedState`:
  - immutable visual-row prefix index construction and logical display-line lookup;
  - syntax-diagnostic visibility rules while the current buffer differs from the validated source;
  - caret-line diagnostic selection.
- `PyEditor` now delegates these deterministic calculations instead of owning their implementation.
- No changes intended to editing, completion requests, LSP calls, scroll behavior, wrapping, folding, or diagnostic validation timing.
- The extracted helper was compiled independently with a minimal diagnostic DTO and exercised with focused assertions. A full Android/CodeAssist build was not run.


## Editor architecture continuation — code intelligence lifecycle extraction

- Moved edit-driven completion orchestration into `EditorCompletionEffect`: the 90 ms edit debounce, string/comment suppression, local completion and auto-import lookup, optional LSP completion, result merging/filtering, replacement-range updates, and stale-buffer checks now live in a dedicated Compose effect.
- Kept completion state ownership in `PyEditor`; the effect receives explicit snapshots and callbacks, preserving the existing single owner for document/UI state.
- Preserved the separate signature-help effect and pure candidate-normalization helper introduced in the previous continuation.
- Updated architecture documentation to distinguish code-intelligence lifecycle ownership from editor interaction/state ownership.

Verification: reviewed the extracted effect against the original request flow and checked Kotlin source structure and ZIP integrity. A full Android/CodeAssist build and device regression test were not run.


## Editor Refactor Next 6
- Extracted completion-acceptance text transformation into `EditorCompletionApplier`; `PyEditor` now owns only committing the resulting single undoable edit and updating Compose selection/cursor state. Callable insertion, decorator/import exceptions, and auto-import offset adjustment remain behaviorally centralized.

## Editor Refactor Next 8 — expanded lifecycle and workflow extraction

- Extracted tab/viewport lifecycle synchronization into `EditorSessionLifecycle`: selection persistence, scroll-position persistence, final viewport snapshot on disposal, latest hover-job cleanup, and restored-scroll clamping now share one focused owner.
- Improved disposal correctness by reading the latest hover job through `rememberUpdatedState`, rather than retaining the job value captured when the disposal effect was first installed.
- Extracted keyboard/focus coordination into `EditorImeCaretEffects`, preserving the initial-hidden-IME guard, first-tap protection, and sequential 100/150/250 ms caret-pin passes during keyboard animation.
- Extracted one-shot editor commands into `EditorExternalEditEffects`: file-targeted undo/redo, symbol-bar insertion (including TAB expansion), and file-targeted structure/search jumps. Document mutation still goes through `OpenTab`, while field selection, flash-line state, and cursor reporting return through explicit callbacks.
- Extracted asynchronous formatting and import-cleanup workflows into `EditorFormattingEffects`: pylsp/local formatter fallback, caret remapping, flat-indentation confirmation handoff, Pyflakes analysis, stale-buffer rejection, conservative import fixing, and exact request-consumption timing.
- Kept the confirmation dialog, toast presentation, document field, undo-history commits, and cursor state in `PyEditor`; extracted effects do not create a second owner for those concerns.
- Reduced `PyEditor.kt` from 2,550 to 2,383 lines in this pass (167 lines removed from the central composable), with four cohesive responsibility extractions.

Verification: reviewed extracted call sites, preserved effect keys and request-consumption ordering, checked source structure and archive contents. Full Android/CodeAssist compilation and device regression tests were not run in this environment.


## Editor Refactor Next 10 — pinch-zoom geometry extraction

- Added `EditorZoomGeometry` as the pure calculation boundary for the pinch-zoom commit pipeline. It derives exact vertical-row and horizontal-glyph scale ratios from measured font metrics, reproduces the existing quadratic ease-out interpolation, computes post-commit horizontal/vertical scroll targets (including the distinct word-wrap rule), and computes wrapped-line fractional re-anchoring.
- Replaced the inline calculations in `PyEditor` with these named operations. The Compose coordinator still owns the gesture, animation clock, `ZoomAnchor`, scroll dispatch, font-size commit, temporary compensation, timeout safety net, and cancellation. This deliberately separates deterministic geometry without moving lifecycle state out of its single owner.
- Extracted post-commit zoom scroll restoration and wrapped-layout re-anchoring into `EditorZoomAnchorEffects`. The `ZoomAnchor` token check, two-frame wait, scroll clamping, wrapped-mode horizontal behavior, and final compensation cleanup remain intact; the caller still owns the animation and anchor state.
- Moved `EditorLayoutMetrics.kt` into the `ide.editor` package, alongside the other editor presentation support components. Font metric measurement/cache, bounded wrapped-row measurement/cache, and canonical gutter-width policy now have a package boundary consistent with their consumers; no measurement formula or cache limit changed.
- Preserved the 90 ms settle duration, 0.0005 scale threshold, gutter-plus-padding horizontal origin, wrapped-mode horizontal offset behavior, and 700 ms safety cleanup.

Verification: standalone Kotlin compilation and focused numeric assertions for metric ratios, ease-out endpoints/midpoint, wrapped/unwrapped scroll targets, and fractional line anchoring passed. ZIP integrity and required project payload checks passed. Full Android/CodeAssist build and device regression tests were not run.

## Editor Refactor Next 11 — shared text-layout geometry

- Extracted wrapped visual-row measurement, the bounded per-line row cache, stale-layout validation, logical-to-visual row prefix construction, and gutter row geometry into `editor/EditorTextLayoutGeometry.kt`.
- Kept `PyEditor` as the owner of `TextFieldValue`, `TextLayoutResult` publication, viewport dimensions, scroll state, and zoom/IME coordination. The helper receives the current document/layout snapshots and returns geometry plus live read-only state views for long-running caret effects.
- Preserved the existing cache keys and density/font-scale invalidation, stale TextLayoutResult checks, measured-pitch fallback tolerance, and O(1) visual-row prefix lookup.


## Editor Refactor Next 12 — project-wide rename workflow extraction

- Extracted the complete selection-driven project rename workflow from `PyEditor` into `editor/EditorRenameWorkflow.kt`: selected-symbol validation, definition lookup and refactor-kind labeling, workspace-reference preview, progress/cancellation state, transactional rename execution, open-tab document reconciliation, caret remapping, and workspace tree refresh.
- Kept `PyEditor` as the sole owner of the live `TextFieldValue`; the workflow receives an immutable field snapshot and an explicit `onFieldChange` callback. `EditorSelectionToolbarState` remains the shared toolbar bridge, and the existing presentation-only `EditorRenameDialog` remains separate.
- Preserved the original effect keys, keyword/identifier validation, `.py` definition restriction, reference-preview messages, rename transaction callbacks, cancellation messaging, selection bounds, per-tab edit application, saved-state updates, caret token remapping, and tree-refresh behavior.
- Reduced `PyEditor.kt` from 2,290 to 2,161 lines in this pass; 129 lines of inline workflow code moved behind a dedicated composable boundary.

Verification: reviewed the extraction against the original inline block, checked call-site/state ownership and source structure, and verified ZIP contents and required `.platform` payload. Full Android/CodeAssist compilation and device regression tests were not run.

## Architecture refactor — Next 13

- Extracted completion-list rendering into `EditorCompletionPopup`, with explicit selection, dismissal, and positioning callbacks; completion state and acceptance remain owned by the editor coordinator.
- Added `EditorInteractionPolicy` for selection-handle visibility geometry and fold-toggle decisions. The helper returns decisions only; `PyEditor` remains the sole committer of tab fold state, selection, and cursor reporting.
- Replaced the inline selection-handle geometry and fold-chevron mutation policy with the new contracts while preserving the existing viewport bounds, stale-layout guard, scroll/gutter offsets, hidden-selection behavior, and callback order.

## Editor Refactor Next 14 — popup presentation and information-card extraction

- Extracted popup anchor resolution into `EditorPopupPresentation`: current-layout freshness checks, caret/documentation cursor-rect mapping, pinch-preview transform mapping, and last-valid-anchor translation across pending sheet shifts now live behind one deterministic presentation boundary.
- Extracted popup visibility/precedence and slot-spec construction into the same presentation policy. Completion, expanded documentation, documentation bubble, diagnostic, and signature-help precedence are computed together, while the existing `EditorPopupLayer` remains responsible for collision-aware physical placement.
- Extracted the documentation/definition card into `EditorDocumentationCard` and the diagnostic card into `EditorDiagnosticCard`. Both receive explicit callbacks for navigation, close, fix, line formatting, and hit-test coordinate publication; they do not own editor document or LSP state.
- Kept quick-fix validation and all document mutations in `PyEditor`. The diagnostic line-format action retains the pylsp-first/local fallback pipeline, E303 blank-line exception, one-line-only replacement, stale-buffer rejection, and cursor reporting.
- Reduced `PyEditor.kt` from 2,056 to 1,898 lines in this pass. Three cohesive boundaries were added: popup geometry/policy, documentation card presentation, and diagnostic card presentation.

Verification: checked the extracted popup geometry against the original formulas and preserved the original popup precedence, card dimensions, layout freshness guard, anchor memo shifts, and diagnostic action ordering. ZIP and required payload checks were run. Full Android/CodeAssist compilation and device regression tests were not run.


## Editor Refactor Next 15 — tap observation extraction

- Moved the editor-wide non-consuming tap observer from `PyEditor` into `editor/EditorTapObserver.kt`. This includes Initial-pass pointer tracking, movement/multi-touch and long-press discrimination, delayed native-field synchronization, stale layout/document validation, coordinate conversion, folded-display to source-offset mapping, and fallback caret placement.
- Kept all mutable editor state in `PyEditor`: the helper receives read-only snapshot providers and explicit callbacks for caret placement, cursor reporting, popup hit-testing, hover documentation, and transient interaction flags. `BasicTextField` remains the authority for normal caret placement and native long-press selection.
- Preserved the 80 ms native-update grace period, 180 ms hover-dismissal grace period, touch-slop and long-press thresholds, Initial pointer-event pass, multi-touch exclusion, 8 dp text padding, 4 dp line-right tolerance, and source-offset mapping through the folded document.
- Reduced `PyEditor.kt` from 1,898 to 1,821 lines in this pass; the complete tap-observation coroutine now has a named responsibility boundary rather than being embedded in the editor's modifier chain.

Verification: reviewed the extracted block against the original gesture flow and checked callback/state ownership and archive payload constraints. Full Android/CodeAssist compilation and device regression tests were not run.

## Editor Refactor Next 16 — formatting workflow extraction

- Extracted formatting/Fix Imports orchestration and the lost-indentation confirmation
  dialog into `EditorFormattingWorkflow`.
- Kept live editor-buffer ownership and cursor reporting in `PyEditor`; accepted
  formatting results still use the existing `OpenTab.applyEdit` history path.
- Preserved the pylsp-first/local-fallback formatter, import analysis validation,
  request-consumption callbacks, and the three user choices for reconstructed
  indentation (rebuild, clean up only, cancel).

## Editor Refactor Next 17 — caret navigation workflow extraction

- Moved the complete two-axis caret-reveal and explicit caret-centering workflows into `editor/EditorCaretNavigation.kt`. This includes layout freshness waits, folded source/display line mapping, fallback wrapped-row geometry, handle-clearance-aware vertical reveal, gutter-aware horizontal reveal, and coordinated animated centering.
- Added `EditorCaretNavigationSnapshot`, which passes live read-only `State` handles for the field, layout, folded document, and wrapped-row geometry. Long-running navigation coroutines therefore observe current snapshots instead of retaining stale composition values.
- Kept all viewport and scroll ownership in `PyEditor`; the extracted workflow receives the existing `ScrollState` instances and only issues the same scroll operations. No second document, selection, or scroll owner is introduced.
- Preserved the existing three-frame layout freshness limit, extra reveal frame for scroll-range updates, handle reach/margin calculations, 40 dp reveal margin, 24 dp centering margin, and distance-based 260–520 ms centering animation.
- Reduced `PyEditor.kt` from 1,773 to 1,677 lines (96 lines moved into the dedicated workflow).

Verification: reviewed the extracted algorithms against the original inline implementations and checked the live-state handoff and call sites. Full Android/CodeAssist compilation and device regression tests were not run.


## Editor Refactor Next 18 — hover documentation workflow extraction

- Extracted the asynchronous hover/documentation request lifecycle into `editor/EditorHoverDocumentationWorkflow.kt`: tap-to-source mapping, folded-offset translation, hover-target validation, offline documentation lookup, LSP resolution, stale-source rejection, request cancellation, anchor publication, and expanded/closed presentation state.
- Kept `PyEditor` as the owner of the current `TextFieldValue`, `TextLayoutResult`, field/gesture coordinates, folded-document snapshot, and Python LSP controller. Those are supplied to the workflow per request; the helper never caches an independent document or layout.
- Preserved the `.py` restriction, popup-visibility guard, coordinate tolerances, offline fallback behavior, source-snapshot checks before and after asynchronous resolution, selection-move dismissal behavior, environment-revision invalidation, and tab-disposal cancellation.
- Reduced `PyEditor.kt` from 1,677 to 1,620 lines (57 lines moved into the dedicated workflow class).

Verification: reviewed lifecycle transitions and call sites against the prior inline implementation, checked Kotlin source structure, and verified archive payload constraints. Full Android/CodeAssist compilation and device regression tests were not run.

## Editor Refactor Next 19 — pinch gesture recognition extraction

- Extracted the two-pointer pinch recognition loop from `PyEditor.kt` into `editorPinchZoomGesture` in `EditorPinchZoomGesture.kt`.
- Kept the gesture recognizer focused on pointer lifecycle, distance tracking, and event consumption. `PyEditor` continues to own font/viewport/document zoom state and supplies explicit start/update/end callbacks.
- Preserved single-finger pass-through, the settling-window guard, 9–24sp bounds, wrapped/unwrapped update paths, and guaranteed end-of-gesture cleanup.
- No document, selection, scroll, or zoom state ownership was duplicated.

## Editor Refactor Next 20 — zoom commit workflow extraction

- Moved the post-pinch settle animation, physical scale-ratio reconciliation, committed scroll-target calculation, compensation-layer hand-off, font commit, and 700 ms recovery guard into `editor/EditorZoomCommitWorkflow.kt`.
- `PyEditor` remains the single owner of the Compose state. The workflow receives the existing `MutableState` holders, `ScrollState` instances, anchor object, font-metric and gutter-geometry providers, and the font-change callback; it does not create a parallel zoom state or own a second viewport.
- Preserved the 90 ms eased settle, 0.0005 scale-difference threshold, gutter/text-padding-aware horizontal anchor, wrapped-mode horizontal-scroll behavior, commit token protection, and timeout cleanup.
- The previous low-level pointer recognizer and this commit lifecycle are now separate boundaries: gesture recognition reports lifecycle events, while the commit workflow coordinates the visual/layout transition.

Verification: compared the extracted commit sequence and state transitions with the Next 19 implementation, checked Kotlin source structure and archive contents. Full Android/CodeAssist compilation and device regression tests were not run.


## Editor Refactor Next 21 — diagnostic action workflow extraction

- Extracted the diagnostic card's source-validation, quick-fix, and line-reformat actions into `EditorDiagnosticActions.kt`; `PyEditor` now supplies the current document snapshot and explicit callbacks for accepted edits, cursor reporting, syntax-editing-line state, toast feedback, dismissal, and hit-test coordinates.
- Preserved the quick-fix stale-source guard, pylsp-first formatting, local formatter fallback, E303 blank-line exception, line-only replacement for other diagnostics, caret remapping, and second stale-buffer check after asynchronous work.
- Kept `PyEditor` as the sole owner of `TextFieldValue`, syntax-editing-line state, tab history commits, and cursor state. The extracted composable owns no document or LSP state and only derives the currently valid quick-fix from its inputs.
- Reduced `PyEditor.kt` from 1,522 to 1,446 lines; 76 net lines were removed from the coordinator while the complete diagnostic action path moved behind a dedicated component boundary.

Verification: reviewed the extracted actions against the original inline implementation and checked callback/state ownership. Full Android/CodeAssist compilation and device regression tests were not run.

## Editor Refactor Next 22 — popup and gutter composition extraction

- Moved the complete editor overlay composition into `EditorPopupAndGutterLayers.kt`: popup anchor resolution, popup precedence/slot planning, completion/documentation/diagnostic/signature card placement, documentation bubble placement, and the gutter overlay now form one named surface-layer boundary.
- Moved fold-chevron interaction handling with the gutter, including selection-safe collapse, collapsed-key commit, caret relocation, and cursor reporting. Breakpoint taps continue through the original callback.
- Kept the component in the parent `BoxScope` so `EditorPopupLayer` retains its original `matchParentSize` measurement behavior. It receives the current immutable document/layout snapshots and the existing scroll/zoom objects; it does not create or own another editor buffer, scroll state, or popup lifecycle.
- Preserved popup anchor transforms during pinch/commit shifts, slot precedence and dimensions, scroll-relative positioning, hit-coordinate publication, diagnostic action validation, documentation navigation/close behavior, and fold-collapse caret correction.
- Reduced `PyEditor.kt` from 1,446 to 1,309 lines (137 lines removed from the coordinator in this pass).

Verification: Kotlin parser check found no syntax errors in the edited files. The check cannot resolve Android/Compose/project dependencies in this environment, so it is not a successful module compilation. Full Android/CodeAssist build and device regression tests were not run. ZIP integrity and required payload checks were performed.


## Editor Refactor Next 23 — code input surface extraction

- Extracted the code-lane row and editable input surface into `EditorCodeInputLayer.kt`, including pinch-preview transform, gutter spacer alignment, selection-handle visibility, text-selection toolbar hosting, `BasicTextField`, edit normalization, completion invalidation, undo/redo shortcuts, focus, and layout-coordinate reporting.
- Kept `PyEditor` as the only owner of the live field, completion and syntax-editing state, focus/coordinates, and document commits. The extracted component uses explicit values and callbacks and continues to commit accepted changes through `OpenTab.applyEdit`.
- Preserved the original Box/Row placement, text padding and minimum-height constraints, native IME and selection behavior, auto-indent path, completion dismissal rules, and undo/redo semantics.
- Reduced `PyEditor.kt` from 1,308 to 1,159 lines (149 lines removed from the coordinator).

Verification: reviewed the extraction boundaries and callback flow. Full Kotlin/Android module compilation and device regression tests were not run.

### Architecture refactor — Next 24
- Extracted the viewport-space surface interaction pipeline into `EditorSurfaceInteraction`: fixed gutter divider, viewport measurement, nested-scroll axis arbitration, shared two-axis pan, and whole-surface scroll composition.
- Kept document and gesture state ownership in `PyEditor`; pinch/tap modifiers are injected in their original order to preserve pointer coordinate behavior.

### Architecture refactor — Next 25
- Added `EditorCodeIntelligenceEffects` as the composition boundary coordinating completion and signature-help effects.
- Consolidated the two effect call sites while preserving the original effect implementations and all explicit state callbacks; debounce, cancellation, source/caret checks, and stale-result protections remain in their existing effect components.
- Kept the live field, completion items/range/generation counters, signature result, and popup presentation state owned by `PyEditor`.
- This is a responsibility-boundary extraction, not a claim that the editor coordinator's state has been fully externalized.

Verification: inspected the new call contract against both existing effect signatures and confirmed the archive payload. Full Android/CodeAssist compilation and device regression tests were not run.

### Architecture refactor — Next 26
- Added `EditorCaretInteractionCoordinator` to centralize caret reveal/centering requests and caret-report scheduling behind a focused workflow boundary.
- `PyEditor` now supplies a live navigation snapshot provider and an explicit caret-state callback; the coordinator does not cache layout, selection, document, or scroll state.
- Preserved the existing `EditorCaretNavigation` target calculations and scroll behavior, including center requests and IME-driven reveal calls.
- This pass extracts orchestration only; the source-of-truth caret and IME flags intentionally remain in `PyEditor`.

Verification: source-level callback and state ownership review plus ZIP integrity/payload checks. Full Android/CodeAssist compilation and device regression tests were not run.

### Architecture refactor — Next 31
- Added `EditorCompletionWorkflow` as the editor-facing transaction boundary for accepting a completion. The workflow coordinates the existing pure `EditorCompletionApplier`, the single `OpenTab.applyEdit` history commit, `TextFieldValue` publication, completion dismissal, and resulting caret report.
- Kept document text, selection, completion replacement range, popup state, and cursor reporting owned by `PyEditor`; all are passed explicitly to the workflow, which retains no document or Compose state.
- Preserved import-plus-symbol insertion as one undoable edit, callable insertion/caret placement, replacement-range clamping, and the original cursor line/column calculation.

Verification: reviewed the new call contract and compared the transaction order with the previous inline handler; checked source references and archive payload. Full Android/CodeAssist compilation and device regression tests were not run.


## Architecture Refactor — Stage 3: Code Intelligence / LSP boundaries

- Extracted the process-backed JSON-RPC stdio implementation from `PythonLspController` into `PythonLspSession`. The extracted transport retains Content-Length framing, request correlation and timeout behavior, server-initiated workspace replies, diagnostics notification delivery, stderr draining, document-version tracking, and bounded process shutdown.
- Added `LspSessionTransport` as the controller-facing seam. The project controller now depends on the transport contract rather than the concrete process implementation; project/environment lifecycle and document synchronization remain controller-owned.
- Extracted `LspDiagnosticMapper` to convert LSP diagnostic payloads into immutable `PythonSyntaxDiagnostic` lists. Project URI lookup, source/version freshness checks, filtering, missing-import resolution, and combined diagnostic publication remain in `PythonLspController`.
- Left `WorkspacePythonReferenceIndex`, `ProjectTransactionManager`, `WorkspaceRefactorTransaction`, and `PythonCompletion` behavior unchanged. Their correctness-sensitive indexing, reference resolution, and multi-file edit semantics are preserved rather than rewritten during this boundary change.

Verification: source-level reference and ownership checks, Kotlin parser/compiler diagnostic scan for syntax errors, archive integrity and required-payload checks. Full Android/CodeAssist compilation and device regression tests were not run.


## Architecture Refactor — Stage 5: Terminal / Notebook / Debugger boundaries

- Extracted `NotebookSessionRegistry` from `NotebookRepository`. The registry now exclusively owns the application-scoped notebook-session map, keying, atomic lookup/creation, stale persistence guards, and removal by file, subtree, project, or shutdown. `NotebookRepository` coordinates detached entries with kernel subscriptions and disposal; cleanup remains outside the registry lock.
- Preserved notebook lifecycle semantics: a session and its isolated kernel survive Compose detachment, raw-JSON mode, tab changes, and Activity recreation. `NotebookViewModel` continues to own the Compose-backed notebook document, execution queue, cell state/output publication, and persistence debounce; no second document or kernel owner was introduced.
- Extracted the debugger's bounded cross-thread output staging into the Android-free `DebugOutputBuffer`. The controller retains the existing 50 ms main-thread flush scheduling and visible 100,000-character history cap; the staging cap remains 150,000 characters.
- Kept `TerminalRepository` as the native PTY/process-group owner and `TerminalViewModel` as the per-surface lifecycle coordinator. `TerminalScreenState` remains composition-bound because it directly owns the emulator transcript, IME conduit, Compose selection/layout geometry, and surface gestures; moving those into runtime/domain would create invalid cross-layer ownership.
- Updated `ARCHITECTURE.md` with explicit state/resource ownership and lifetime rules for all three subsystems.

Verification: reviewed all changed call sites and preserved lifecycle paths; checked that registry removal still precedes unsubscribe/ViewModel/kernel disposal, and that debugger buffer bounds and flush cadence are unchanged. Full Android/CodeAssist compilation and device regression tests were not run.

## Architecture refactor — Stage 6 (based on the user-provided Stage 5 ZIP)

- Grouped camera platform integration and its Compose panel under `ide/camera`; moved source detection to a pure domain policy and shell environment construction to the run feature coordinator layer.
- Grouped VNC viewer, frame viewer, frame-display adapter and guest window-manager payload under `ide/display`, preserving the existing protocol and guest script contents.
- Grouped GitHub Compose screens with the existing GitHub API/import/publish adapters under `ide/github` and updated UI call sites.
- Added `domain/browser/BrowserUrlPolicy` for pure URL normalization while retaining WebView ownership and Compose-observable state in the browser presentation adapter.
- Split package management into domain models/contract/policy and a PRoot-backed data adapter. The package ViewModel now depends on the domain contract; pip execution remains serialized and scoped to the project's venv.
- Updated architecture documentation and all affected imports/call sites.

Verification: ZIP integrity, source-reference searches, package-boundary checks and standalone Kotlin compilation of the pure domain policies/run command factory completed. A full Android/CodeAssist build is not available in this environment; this stage is not device-build verified.


## Architecture refactor — Stage 7: final audit and dependency correction

- Registered the PRoot-backed package repository as one application-scoped `PackageManagerRepository` binding in Koin and added it to the typed `AppDependencies` graph.
- Passed the repository contract to the package-management UI and Python LSP package-inventory refresh. Removed direct construction of the data adapter from presentation and code-intelligence orchestration.
- Fixed the package-inventory call to supply `project.dir` (the repository contract accepts a project directory). The shared adapter instance also centralizes pip-operation serialization.
- Audited Domain/Application imports and cross-package references; documented remaining orchestration coordinators, lifecycle ownership and verification limits in `ARCHITECTURE-AUDIT.md`.

Verification: pure Kotlin smoke tests passed for URL normalization, package-spec validation/parsing, camera command generation and bounded debugger buffering. ZIP integrity and required payload checks passed. Full CodeAssist build/device tests were not available.


## Architecture ownership refinement — LSP document and workspace configuration

- Extracted `LspDocumentSynchronizer` from `PythonLspController`. It owns LSP `didOpen`/`didChange` notifications, document version progression, and snapshot publication ordering. URI resolution and environment refresh are injected explicitly.
- Extracted `LspWorkspaceConfiguration` to own project interpreter selection/fingerprinting, project-local import-root discovery, Jedi settings generation, and throttled workspace configuration refresh.
- Updated `PythonLspController` to delegate document synchronization and workspace configuration while retaining the single project-session owner, request cancellation/freshness checks, and diagnostics aggregation. Environment revision changes and controller close reset the extracted configuration state.
- Updated `ARCHITECTURE.md` and `ARCHITECTURE-AUDIT.md` to reflect the new ownership boundaries.

Verification: reviewed all synchronization call sites (debounced document changes, request preparation, and refactor-applied document updates), verified the same project URI resolver is used, and checked reset paths for environment changes and controller shutdown. Full CodeAssist compilation and device regression tests were not run.


## Architecture ownership refinement — IDE shell lifecycle

- Extracted `ProjectExitCoordinator` to own the ordered intentional project-leave protocol, including restore-marker invalidation, optional session persistence, project debugger/test teardown, console/display/camera shutdown, and presentation reset. `IdeShell.leaveProject` now delegates to it.
- Preserved the existing project-feature, persistence, deletion-cleanup, and transient run-state extractions in the working tree: `ProjectFeatureFactory`, `IdeSessionPersistence`, `ProjectLifecycleCleanup`, and `IdeRunSessionState`. These are included in this full project archive.
- Updated the architecture and audit documents to reflect the actual ownership boundaries and remaining live run/bridge coordination in `IdeShell`.

Verification: compared the working tree with the supplied Stage 7 ZIP, reviewed the extracted coordinator call order against the previous inline `leaveProject` body, and compiled the extracted LSP document/workspace classes against minimal API stubs. Full Android/CodeAssist compilation and device regression tests were not run.

## Architecture ownership refinement — guest bridge and terminal run lifecycle

- Extracted `IdeBridgeCoordinator` from `IdeShell`. It now owns the guest-to-IDE bridge protocol callbacks (`prepare`, `start`, `port`, `done`, and `stop`), including terminal launch-plan creation, GUI/camera preparation, conflict metadata, HTTP-port verification, and dispatch into the shared run registry.
- The coordinator receives project editors, camera permission prompting, display launch actions, terminal completion, and stop actions through explicit constructor dependencies. It does not own Compose state, Activity launchers, the bridge server process, or a second run registry.
- Extracted `TerminalRunLifecycleCoordinator` to own terminal process stop/kill policy, Stop All routing, run completion, display-owner release, and camera release. `IdeShell` now provides narrow callbacks and compatibility methods for existing UI call sites.
- Preserved the bridge host-active gate, one-shot expiring launch plans, Main-thread registration, 20×100 ms run-registration wait, HTTP probe, display-owner assignment, and delayed display close check.

Verification: compared the extracted callback sequence with the prior inline handler and verified that the display-owner write and all callback guards remain present. ZIP payload and archive integrity checks completed. Full Android/CodeAssist compilation and device regression tests were not run.


## Architecture ownership refinement — Console display and completion

- Added `ConsoleDisplayLifecycleCoordinator` and delegated VNC/frame display startup from `IdeShell`.
- Added `ConsoleRunCompletionCoordinator` and delegated natural Console process-exit side-effects.
- Preserved existing display generation checks, 30-second first-frame wait, 100 ms polling cadence, 1.5-second VNC close delay, run finishing, camera release, and stale web URL clearing.
- Updated architecture and audit documentation to record the extracted owners and the remaining Console command orchestration boundary.

## Architecture ownership refinement — project recovery lifecycle

- Extracted the active-project recovery effects from `IdeRoot` into `ProjectRecoveryEffects`.
- Moved dirty-buffer snapshot scheduling, periodic recovery reconciliation, recursive watcher attachment, and workspace-level missing-project observation behind a dedicated presentation lifecycle adapter.
- Kept recovery storage in `ProjectAutoRecoveryManager`, recursive filesystem watching in `ProjectRecoveryWatcher`, editor buffer ownership in `EditorSession`, and project navigation/stop actions in the IDE host callback.
- Preserved debounce and polling timings, IO execution, cancellation behavior, and missing-project transition behavior.

Verification: source-level call-site and lifecycle review, required archive payload checks, and ZIP integrity validation. Full Android/CodeAssist compilation and device regression tests were not run.

## Ownership Refinement 5 — IdeRoot presentation boundaries

- Extracted Activity-scoped root ViewModel provisioning into `presentation/IdeRootViewModels.kt`.
- Extracted project LSP controller attachment/disposal and tab-document release into `EditorLspHost.kt`.
- Extracted Activity ON_STOP persistence/camera shutdown and periodic persistence scheduling into `presentation/IdeHostLifecycleEffects.kt`.
- Extracted Problems panel diagnostic aggregation and its 220 ms debounce into `EditorProblemCounts.kt`.
- Preserved existing ViewModel scopes, LSP controller project keying, document-close callback chaining, and lifecycle timings.


## Ownership Refinement 6 — LSP import policy extraction

- Extracted the project-interpreter AST import availability probe into `LspImportResolver`, including Base64 source transport, shell quoting, PRoot invocation timeout, JSON decoding, and missing-import diagnostic construction.
- Kept request scheduling, cancellation, document version/source freshness checks, and LSP/fallback diagnostic merging in `PythonLspController`.
- Extracted the pure workspace-reference occurrence classifier into `PythonReferenceClassifier`; the existing workspace index and refactor transaction implementation are unchanged.
- Compiled both extracted Kotlin classes independently against minimal API stubs.

## Architecture ownership refinement 7

- Extracted final Console command construction and shared run-registry publication into `ConsoleRunLaunchCoordinator`.
- Preserved command-state-before-registry-publication ordering with an explicit prepare/publish transaction.
- Kept source snapshots, web/camera preparation, conflict UI, Compose state, and display startup in the shell host; no runtime resources or run registry were duplicated.

## Ownership Refinement 8

- Added `ConsoleRunPlanningCoordinator` / `ConsoleRunPlan` to own deterministic source classification and Console/Terminal conflict identity derivation for each Console launch.
- Updated `IdeShell.runInConsole` to consume the immutable planning result instead of invoking `RunSourceAnalyzer` and `RunIdentityResolver` independently.
- Preserved the existing ordering and behavior for source snapshots, conflict prompts, asynchronous web/camera preparation, Compose run state, final command preparation/publication, and display startup.
- Updated architecture and audit documentation with the precise ownership boundary and remaining presentation-host responsibilities.

## Ownership Refinement 9 — IDE root environment boundary

- Extracted private workspace bootstrap state, background workspace resolution, error reporting, and retry handling into `presentation/IdeRootEnvironment.kt` (`rememberIdeWorkspace`).
- Extracted Activity host traversal into `rememberIdeHostActivity`, removing Android ContextWrapper traversal from the root composition function.
- Extracted theme/system-bar synchronization into `IdeWindowThemeEffect`; `IdeRoot` now supplies the current Activity and theme identifier rather than implementing Android window mutations inline.
- Preserved IO dispatch for workspace preparation, retry semantics, private workspace resolver, theme selection, status/navigation bar colors, and light-system-bar flags.
- These are presentation-boundary extractions: workspace filesystem policy remains in `workspaceRoot`, theme policy remains in `IdeTheme`, and the Activity remains the window owner.

Verification: source-level call-site review and archive payload/integrity checks. Full Android/CodeAssist compilation and device regression tests were not run.

## Ownership Refinement 10 — Editor indexing lifecycle and details presentation

- Added `editor/EditorIndexingSession.kt` as the single Compose lifecycle boundary for the project symbol index and Python-environment index monitors. It creates each monitor with project-scoped keys, collects their state, starts them when the editor session is composed, and closes them when that session leaves composition.
- Moved the index-chip visibility timing policy (immediate visibility while idle/indexing, short success/error feedback windows) into that indexing-session boundary. `IdeEditor` now consumes the session snapshot and retains only screen-level visibility and dialog-tab/filter choices.
- Extracted the complete code-intelligence index details surface into `editor/EditorIndexDetailsDialog.kt`. It receives monitor snapshots and explicit refresh/rebuild actions through its monitor references, while tab selection, filter text, and dismissal remain controlled by the parent screen.
- Preserved the existing monitor instances, project-keyed remember behavior, start/close lifecycle, status timing (850 ms ready / 2200 ms error), rebuild/refresh actions, package filtering, and dialog content. No duplicate index monitor or parallel cache was introduced.
- This pass establishes a reusable presentation boundary for editor indexing; it does not claim that `IdeEditor` or `PyEditor` has completed decomposition. Their remaining editor orchestration and document/IME ownership are still tracked for the next passes.

## Ownership Refinement 11 — PyEditor surface geometry

- Added `editor/EditorSurfaceCoordinatesState.kt` to own the active document's viewport/field/editor/gesture coordinates, popup hit-test registrations, and persistent caret/documentation anchor memos.
- Routed popup hit testing through the geometry owner and updated `PyEditor`/popup layers to share the same per-document coordinate and anchor instances.
- Preserved document-keyed lifetime, coordinate registration, popup placement, caret anchoring, and gesture coordinate semantics. `OpenTab`, TextField/IME state, `TextLayoutResult`, and scroll state remain single-owned by their existing editor/presentation owners.
- Updated architecture and audit documentation. Full Android/CodeAssist compilation and device regression tests were not run.


## Ownership Refinement 12 — editor scroll session

- Added `editor/EditorScrollSession.kt` with `EditorScrollSession` and `rememberEditorScrollSession`.
- Moved paired scroll-state construction, saved-view restoration state, 2D-pan activation, and dominant-axis nested-scroll arbitration out of `PyEditor`.
- Updated `PyEditor` to consume the session's shared horizontal/vertical states for its existing caret, zoom, gesture, and layout workflows.
- Preserved the existing scroll offsets and gesture policy; no duplicate scroll owner or document state was added.
- Full Android/CodeAssist build and device testing were not run.

## Ownership Refinement 13 — editor gutter geometry

- Added `editor/EditorGutterLayout.kt` as the immutable owner of gutter lane geometry and committed/pinch-preview width selection.
- Replaced inline geometry policy in `PyEditor` with one `EditorGutterLayout.calculate(...)` call; existing consumers still receive the same width values and font-specific width function.
- Preserved line-number/marker/fold sizing, density conversion, zoom-anchor preview hand-off, and text padding values.
- Updated architecture and audit documentation. Full Android/CodeAssist build and device testing were not run.


## Ownership Refinement 14 — pinch-zoom commit boundary

- Added `editor/EditorZoomCommitCoordinator.kt` to own the binding between the per-surface zoom session, shared scroll states, live geometry providers, font update callback, and the existing zoom-commit workflow.
- Reduced `PyEditor`'s inline commit transaction wiring to a coordinator call; the pinch gesture coordinator now delegates commit requests through this explicit boundary.
- Kept frame animation, scroll target calculation, commit token, compensation reset, and 700 ms recovery behavior in the existing `launchEditorZoomCommit` workflow.
- Geometry and word-wrap inputs are read through providers at commit time so recomposition changes are not captured as stale scalar values. The same `EditorZoomSessionState` remains the sole owner of mutable zoom state.
- Source-level call-site review and standalone Kotlin compilation against minimal Compose/API stubs were performed. Full Android/CodeAssist build and device regression tests were not run.

## Ownership Refinement 15 — editor viewport session

- Added `editor/EditorViewportSessionState.kt` as the per-document owner of measured viewport height/width, editable-field width, and the latest Compose `TextLayoutResult` snapshot.
- Routed viewport measurement, field-width updates, and text-layout callbacks from `PyEditor` into the session. Caret navigation, text-layout geometry, zoom anchoring, popup placement, gutter layers, and content sizing continue to read the same snapshot.
- Removed the unused standalone gutter-width state from `PyEditor`; committed and preview gutter geometry remain owned by `EditorGutterLayout` and `EditorZoomSessionState` respectively.
- Kept document text, TextField/IME selection, scroll offsets, and popup coordinate registrations in their existing single owners. No domain-layer dependency on Compose was introduced.
- Source-level call-site review and ZIP integrity checks were performed. Full Android/CodeAssist build and device regression tests were not run.

## Architecture Ownership Refinement 16

- Added `EditorSyntaxPresentation` and `rememberEditorSyntaxPresentation` to centralize syntax diagnostic visibility, per-file highlight-cache lifetime, and `EditorColors` transformation construction.
- Updated `PyEditor` to consume the syntax presentation result rather than owning those rendering decisions inline.
- Preserved diagnostic filtering rules, theme-sensitive highlighting, folded-document transformation, word-wrap indentation behavior, and cache identity by file path.
- Full Android/CodeAssist build and device regression were not performed.

## Architecture Ownership Refinement 17 — editor feature package ownership

- Moved the folded-document model and its folding-region types from the IDE root package into `ide/editor`, aligning document projection, source/display offset mapping, and fold-region identity with the editor feature that owns and consumes them.
- Moved the selection-toolbar state and overlay implementation into `ide/editor`; the toolbar is an editor presentation component shared by the code-input layer and rename workflow, not a root-level IDE component.
- Updated all call sites and imports, including syntax presentation, caret navigation, hover/tap workflows, popup/gutter layers, and code input. No document, selection, or toolbar state was duplicated and no runtime behavior was intentionally changed.
- This is a package/ownership-boundary correction rather than a claim that the `PyEditor` composition coordinator is fully decomposed. Its remaining live Compose orchestration is still subject to the final audit.

Verification: package declarations and all Kotlin references were scanned for stale root-package imports and duplicate imports; ZIP integrity and required/excluded project entries were checked. Full Android/CodeAssist compilation and device regression remain pending.

- Architecture ownership refinement 18: extracted reusable editor chrome primitives (`PySymbolBar`, `PySymbolKey`, `SaveGlyph`, and `IndexMetric`) from the `IdeEditor` screen coordinator into `editor/EditorChromeComponents.kt`, making their editor-feature presentation ownership explicit and reusable by the index-details dialog.

- Architecture ownership refinement 19: extracted `PythonNativeDiagnosticsSession` from `PythonLspController`, moving native checker debounce jobs, per-file freshness/snapshots, reset, removal, and disposal into a focused project-scoped collaborator while retaining one diagnostics merge/publication path.

- Architecture ownership refinement 20: extracted `PythonWorkspaceReferenceResolver` from `PythonLspController`; project-wide reference aggregation, safe URI mapping, open-buffer snapshots, occurrence classification, and bounded local-index supplementation now have a focused owner.

- Architecture ownership refinement 21: extracted the open-document tab strip and project-relative file breadcrumb from `IdeEditor` into `editor/EditorNavigationChrome.kt`. Tab persistence/closing and tree reveal/drawer behavior remain host-owned callbacks; `EditorSession` remains the sole state owner.


- Architecture ownership refinement 22: moved root-level notification permission prompting, Console URL observation, and terminal liveness reconciliation into `IdeRootRuntimeEffects`; isolated persisted-project launch resolution in immutable `IdeLaunchRestoreState`, and moved asynchronous web/camera preparation out of the shell into `ConsoleRunPreparationCoordinator`.

- Architecture ownership refinement 23: extracted `TerminalOutputBuffer` for bounded PTY output hand-off/back-pressure and `NotebookOutputBuffer` for bounded per-cell output accounting, MIME truncation, stream coalescing, and batched UI publication. Terminal Compose scheduling and notebook kernel/execution lifecycle remain with their existing owners.

## Architecture Ownership Refinement 24 — Final audit

- Corrected the terminal PTY output hand-off: oversized reads are split to stay within the active pending-character budget, back-pressure remains lossless, and partial drains preserve order without exceeding the frame budget.
- Corrected notebook output-buffer cleanup so document replacement and cell removal cancel stale batched notifications.
- Completed the final dependency-direction, DI construction-site, session-owner, and extracted-buffer audit; refreshed the architecture audit and completion documentation.
- This closes the planned architecture-refinement sequence for the current single-module CodeAssist project. Full CodeAssist build and on-device regression remain user-side acceptance checks.

## Build repair after Ownership Refinement 24

- Fixed missing imports in the extracted `EditorCodeInputLayer` for editor-session, editor-workflow, code-intelligence, editor presentation, and theme types. The extraction had moved the file into the parent `ide` package while its referenced types remained in dedicated subpackages; this caused a large cascade of unresolved-reference diagnostics.
- Corrected the web preparation coordinator's stale `WebServerGuess` type to the existing `WebServer` model used by the project resolver.
- Made Koin dependency types explicit for `NotebookRepository` and `RunOrchestrator` registrations to avoid Kotlin type-inference failures in the native CodeAssist builder.
