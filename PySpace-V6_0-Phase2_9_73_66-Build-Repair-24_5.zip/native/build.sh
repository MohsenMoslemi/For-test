#!/data/data/com.termux/files/usr/bin/bash
# Builds the PTY bridge for PySpace (arm64, minSdk 30).
# Run in Termux on an ARM64 device with clang installed.
# The resulting libptybridge.so is shipped prebuilt in
#   app/src/main/jniLibs/arm64-v8a/
# (same pattern as the prebuilt libproot.so runtime).
set -euo pipefail
cd "$(dirname "$0")"

TARGET="aarch64-linux-android30"

echo "== PTY functional test binary =="
clang --target="$TARGET" -O2 -DPTY_TEST_MAIN -o pty_test pty_bridge.c

echo "== JNI shared library =="
clang --target="$TARGET" -O2 -fPIC -shared -o libptybridge.so pty_bridge.c

echo "== ELF checks =="
readelf -h libptybridge.so | grep -E "Machine|Class"
echo "-- DT_NEEDED (must be system libs only) --"
readelf -d libptybridge.so | grep -E "NEEDED" || echo "(no DT_NEEDED)"
echo "-- JNI symbols --"
nm -D --defined-only libptybridge.so | grep "Java_com_codespace_ide" || {
    echo "ERROR: no JNI symbols exported"
    exit 1
}

echo "== installing into jniLibs =="
cp -f libptybridge.so ../app/src/main/jniLibs/arm64-v8a/libptybridge.so
ls -lh ../app/src/main/jniLibs/arm64-v8a/
echo DONE
