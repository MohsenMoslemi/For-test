/*
 * ptybridge: minimal PTY layer for PySpace.
 *
 * New file written for this project. No third-party code.
 *
 * What it does:
 *   - posix_openpt() / grantpt() / unlockpt() a PTY master (no forkpty
 *     assumption; only long-stable POSIX/bionic APIs are used),
 *   - fork(); the child gets a new session (setsid), opens the slave,
 *     makes it the controlling terminal (TIOCSCTTY), dups it onto
 *     stdin/stdout/stderr, applies the window size (TIOCSWINSZ) and
 *     execve()s the caller-supplied command (the existing PRoot command),
 *   - the parent keeps the master fd and reports exec/setup failures
 *     through a CLOEXEC status pipe (no silent failures).
 *
 * Only async-signal-safe calls are used between fork() and execve().
 *
 * Build (Termux, Android target matching minSdk 30):
 *   clang --target=aarch64-linux-android30 -O2 -fPIC -shared \
 *       -o libptybridge.so pty_bridge.c
 *
 * Test harness (runs on-device in Termux, exercises the real kernel PTY):
 *   clang --target=aarch64-linux-android30 -O2 -DPTY_TEST_MAIN \
 *       -o pty_test pty_bridge.c && ./pty_test
 */

#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <poll.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/resource.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>

#ifdef __ANDROID__
#include <jni.h>
#endif

/*
 * Last reported error (set on every -1 return).
 * NOTE: plain global behind a mutex, deliberately NOT __thread:
 * the available clang emits underaligned TLS segments that the
 * ARM64 Bionic loader rejects at load time. All users run on normal
 * (non-fork-child) threads, so a mutex is safe here. The forked child
 * never touches this state (it reports via the status pipe instead).
 */
#include <pthread.h>
static int pty_last_errno = 0;
static pthread_mutex_t pty_err_lock = PTHREAD_MUTEX_INITIALIZER;

static void pty_set_errno(int e) {
    pthread_mutex_lock(&pty_err_lock);
    pty_last_errno = e;
    pthread_mutex_unlock(&pty_err_lock);
}

static int pty_get_errno(void) {
    int e;
    pthread_mutex_lock(&pty_err_lock);
    e = pty_last_errno;
    pthread_mutex_unlock(&pty_err_lock);
    return e;
}

/* Shell-style decode shared by the JNI waitPid and the test harness. */
static int pty_decode_status(int status) {
    if (WIFEXITED(status)) {
        return WEXITSTATUS(status);
    }
    if (WIFSIGNALED(status)) {
        return 128 + WTERMSIG(status);
    }
    return -1;
}

/*
 * Spawn argv/envp attached to a fresh PTY.
 * rows/cols: initial window size (must be > 0).
 * On success returns 0 with *out_master / *out_pid set.
 * On failure returns -1 with pty_last_errno set (execve errno included).
 */
int pty_spawn(char* const* argv, char* const* envp,
              int rows, int cols,
              int* out_master, pid_t* out_pid) {
    if (!argv || !argv[0] || !out_master || !out_pid) {
        pty_set_errno(EINVAL);
        return -1;
    }
    if (rows <= 0 || cols <= 0 || rows > 1000 || cols > 1000) {
        pty_set_errno(EINVAL);
        return -1;
    }

    int master = posix_openpt(O_RDWR | O_NOCTTY);
    if (master < 0) {
        pty_set_errno(errno);
        return -1;
    }

    if (grantpt(master) != 0) {
        int e = errno;
        close(master);
        pty_set_errno(e);
        return -1;
    }
    if (unlockpt(master) != 0) {
        int e = errno;
        close(master);
        pty_set_errno(e);
        return -1;
    }

    /* Slave path without ptsname() static buffer: query the pty number. */
    unsigned int ptn = 0;
    if (ioctl(master, TIOCGPTN, &ptn) != 0) {
        int e = errno;
        close(master);
        pty_set_errno(e);
        return -1;
    }
    char slave_path[32];
    snprintf(slave_path, sizeof(slave_path), "/dev/pts/%u", ptn);

    /* CLOEXEC status pipe: child reports pre-exec errno; EOF means exec ok. */
    int errpipe[2];
    if (pipe(errpipe) != 0) {
        int e = errno;
        close(master);
        pty_set_errno(e);
        return -1;
    }
    (void) fcntl(errpipe[0], F_SETFD, FD_CLOEXEC);
    (void) fcntl(errpipe[1], F_SETFD, FD_CLOEXEC);

    pid_t pid = fork();
    if (pid < 0) {
        int e = errno;
        close(errpipe[0]);
        close(errpipe[1]);
        close(master);
        pty_set_errno(e);
        return -1;
    }

    if (pid == 0) {
        /* ---- child: async-signal-safe calls only from here ---- */
        close(errpipe[0]);

        if (setsid() < 0) {
            int e = errno;
            (void) write(errpipe[1], &e, sizeof(e));
            _exit(125);
        }

        int slave = open(slave_path, O_RDWR);
        if (slave < 0) {
            int e = errno;
            (void) write(errpipe[1], &e, sizeof(e));
            _exit(125);
        }

        if (ioctl(slave, TIOCSCTTY, 0) != 0) {
            int e = errno;
            (void) write(errpipe[1], &e, sizeof(e));
            _exit(125);
        }

        {
            struct winsize ws;
            memset(&ws, 0, sizeof(ws));
            ws.ws_row = (unsigned short) rows;
            ws.ws_col = (unsigned short) cols;
            /* Best effort: a size failure must not abort the spawn. */
            (void) ioctl(slave, TIOCSWINSZ, &ws);
        }

        if (dup2(slave, STDIN_FILENO) < 0 ||
            dup2(slave, STDOUT_FILENO) < 0 ||
            dup2(slave, STDERR_FILENO) < 0) {
            int e = errno;
            (void) write(errpipe[1], &e, sizeof(e));
            _exit(125);
        }

        /* Close everything except 0,1,2 (keep errpipe[1] for exec errors). */
        {
            long maxfd = 1024;
            struct rlimit rl;
            if (getrlimit(RLIMIT_NOFILE, &rl) == 0 &&
                rl.rlim_cur > 0 && rl.rlim_cur < 65536) {
                maxfd = (long) rl.rlim_cur;
            } else if (maxfd < 65536) {
                /* rlim_cur huge/unlimited: bounded sweep, no fd leak risk
                 * in practice for app processes. */
                maxfd = 65536;
            }
            for (long i = 3; i < maxfd; i++) {
                if (i != (long) errpipe[1]) {
                    close((int) i);
                }
            }
        }

        execve(argv[0], argv, envp);

        /* Only reached when execve fails. */
        {
            int e = errno;
            (void) write(errpipe[1], &e, sizeof(e));
        }
        _exit(127);
    }

    /* ---- parent ---- */
    close(errpipe[1]);

    int child_err = 0;
    size_t got = 0;
    while (got < sizeof(child_err)) {
        ssize_t n = read(errpipe[0],
                         ((char*) &child_err) + got,
                         sizeof(child_err) - got);
        if (n < 0) {
            if (errno == EINTR) {
                continue;
            }
            break;
        }
        if (n == 0) {
            break; /* EOF: exec succeeded, pipe auto-closed. */
        }
        got += (size_t) n;
    }
    close(errpipe[0]);

    if (got == sizeof(child_err)) {
        /* Child failed before exec: reap it and report its errno. */
        int status = 0;
        while (waitpid(pid, &status, 0) < 0 && errno == EINTR) {
        }
        close(master);
        pty_set_errno(child_err);
        return -1;
    }

    *out_master = master;
    *out_pid = pid;
    return 0;
}

/* Blocking wait with shell-style exit code (128+signal when signaled). */
int pty_waitpid(pid_t pid) {
    int status = 0;
    while (waitpid(pid, &status, 0) < 0) {
        if (errno == EINTR) {
            continue;
        }
        pty_set_errno(errno);
        return -1;
    }
    return pty_decode_status(status);
}

/* ============================ JNI bridge ============================ */

#ifdef __ANDROID__

static char** jni_strarray(JNIEnv* env, jobjectArray arr) {
    if (!arr) {
        return NULL;
    }
    jsize n = (*env)->GetArrayLength(env, arr);
    char** out = (char**) malloc((size_t) (n + 1) * sizeof(char*));
    if (!out) {
        return NULL;
    }
    for (jsize i = 0; i < n; i++) {
        jstring s = (jstring) (*env)->GetObjectArrayElement(env, arr, i);
        if (!s) {
            out[i] = strdup("");
            continue;
        }
        const char* utf = (*env)->GetStringUTFChars(env, s, NULL);
        out[i] = utf ? strdup(utf) : strdup("");
        if (utf) {
            (*env)->ReleaseStringUTFChars(env, s, utf);
        }
        (*env)->DeleteLocalRef(env, s);
        if (!out[i]) {
            out[i] = strdup("");
        }
    }
    out[n] = NULL;
    return out;
}

static void jni_freearray(char** a) {
    if (!a) {
        return;
    }
    for (int i = 0; a[i]; i++) {
        free(a[i]);
    }
    free(a);
}

JNIEXPORT jintArray JNICALL
Java_com_codespace_ide_PtyNative_open(
        JNIEnv* env, jobject thiz,
        jobjectArray argv, jobjectArray envp,
        jint rows, jint cols) {
    (void) thiz;
    if (!argv) {
        pty_set_errno(EINVAL);
        return NULL;
    }
    char** c_argv = jni_strarray(env, argv);
    char** c_envp = jni_strarray(env, envp);
    if (!c_argv) {
        jni_freearray(c_envp);
        pty_set_errno(ENOMEM);
        return NULL;
    }
    int master = -1;
    pid_t pid = -1;
    int rc = pty_spawn(c_argv, c_envp, rows, cols, &master, &pid);
    jni_freearray(c_argv);
    jni_freearray(c_envp);
    if (rc != 0) {
        return NULL;
    }
    jintArray out = (*env)->NewIntArray(env, 2);
    if (!out) {
        return NULL;
    }
    jint vals[2];
    vals[0] = master;
    vals[1] = (jint) pid;
    (*env)->SetIntArrayRegion(env, out, 0, 2, vals);
    return out;
}

/*
 * Blocking-ish read with a bounded poll so a close from another thread is
 * noticed quickly: >0 bytes, 0 = no data yet (keep looping), -1 = EOF/error.
 */
JNIEXPORT jint JNICALL
Java_com_codespace_ide_PtyNative_readFd(
        JNIEnv* env, jobject thiz, jint fd, jbyteArray buf, jint len) {
    (void) thiz;
    if (fd < 0 || !buf || len <= 0) {
        pty_set_errno(EINVAL);
        return -1;
    }
    struct pollfd pfd;
    pfd.fd = fd;
    pfd.events = POLLIN;
    pfd.revents = 0;
    int pr = poll(&pfd, 1, 250);
    if (pr < 0) {
        if (errno == EINTR) {
            return 0;
        }
        pty_set_errno(errno);
        return -1;
    }
    if (pr == 0) {
        return 0;
    }
    if (pfd.revents & POLLNVAL) {
        pty_set_errno(EBADF);
        return -1;
    }
    if (pfd.revents & POLLERR) {
        pty_set_errno(EIO);
        return -1;
    }
    /* POLLHUP falls through: a final read may still return data. */
    jbyte tmp[4096];
    jsize want = len < (jint) sizeof(tmp) ? len : (jint) sizeof(tmp);
    ssize_t n = read(fd, tmp, (size_t) want);
    if (n < 0) {
        if (errno == EINTR || errno == EAGAIN) {
            return 0;
        }
        pty_set_errno(errno);
        return -1;
    }
    if (n == 0) {
        return -1;
    }
    (*env)->SetByteArrayRegion(env, buf, 0, (jsize) n, tmp);
    return (jint) n;
}

/* Full-write loop: returns total bytes written or -1 on error. */
JNIEXPORT jint JNICALL
Java_com_codespace_ide_PtyNative_writeFd(
        JNIEnv* env, jobject thiz, jint fd, jbyteArray buf, jint len) {
    (void) thiz;
    if (fd < 0 || !buf || len <= 0) {
        pty_set_errno(EINVAL);
        return -1;
    }
    jbyte* data = (jbyte*) malloc((size_t) len);
    if (!data) {
        pty_set_errno(ENOMEM);
        return -1;
    }
    (*env)->GetByteArrayRegion(env, buf, 0, len, data);
    jint total = 0;
    while (total < len) {
        ssize_t n = write(fd, data + total, (size_t) (len - total));
        if (n < 0) {
            if (errno == EINTR) {
                continue;
            }
            pty_set_errno(errno);
            free(data);
            return total > 0 ? total : -1;
        }
        total += (jint) n;
    }
    free(data);
    return total;
}

JNIEXPORT jint JNICALL
Java_com_codespace_ide_PtyNative_setWinSize(
        JNIEnv* env, jobject thiz, jint fd, jint rows, jint cols) {
    (void) env;
    (void) thiz;
    if (fd < 0 || rows <= 0 || cols <= 0 || rows > 1000 || cols > 1000) {
        pty_set_errno(EINVAL);
        return -1;
    }
    struct winsize ws;
    memset(&ws, 0, sizeof(ws));
    ws.ws_row = (unsigned short) rows;
    ws.ws_col = (unsigned short) cols;
    if (ioctl(fd, TIOCSWINSZ, &ws) != 0) {
        pty_set_errno(errno);
        return -1;
    }
    return 0;
}

JNIEXPORT jint JNICALL
Java_com_codespace_ide_PtyNative_waitPid(
        JNIEnv* env, jobject thiz, jint pid) {
    (void) env;
    (void) thiz;
    if (pid <= 0) {
        pty_set_errno(EINVAL);
        return -1;
    }
    return pty_waitpid((pid_t) pid);
}

JNIEXPORT jint JNICALL
Java_com_codespace_ide_PtyNative_closeFd(
        JNIEnv* env, jobject thiz, jint fd) {
    (void) env;
    (void) thiz;
    if (fd < 0) {
        pty_set_errno(EINVAL);
        return -1;
    }
    if (close(fd) != 0) {
        pty_set_errno(errno);
        return -1;
    }
    return 0;
}

JNIEXPORT jint JNICALL
Java_com_codespace_ide_PtyNative_killPid(
        JNIEnv* env, jobject thiz, jint pid, jint sig) {
    (void) env;
    (void) thiz;
    if (pid <= 0 || sig <= 0) {
        pty_set_errno(EINVAL);
        return -1;
    }
    if (kill((pid_t) pid, (int) sig) != 0) {
        pty_set_errno(errno);
        return -1;
    }
    return 0;
}

/*
 * Signals a whole process group (negative-pid kill). Our spawned child
 * calls setsid(), so its PID is also its process group ID: kill(-pgid)
 * reaches the child AND every descendant (PRoot, python, uvicorn workers,
 * ...). Stopping a server MUST use this — killing only the leader orphans
 * the server and leaves it holding its port (Stop/Rerun looked dead).
 */
JNIEXPORT jint JNICALL
Java_com_codespace_ide_PtyNative_killProcessGroup(
        JNIEnv* env, jobject thiz, jint pgid, jint sig) {
    (void) env;
    (void) thiz;
    if (pgid <= 0 || sig <= 0) {
        pty_set_errno(EINVAL);
        return -1;
    }
    if (kill(-(pid_t) pgid, (int) sig) != 0) {
        pty_set_errno(errno);
        return -1;
    }
    return 0;
}

JNIEXPORT jboolean JNICALL
Java_com_codespace_ide_PtyNative_alive(
        JNIEnv* env, jobject thiz, jint pid) {
    (void) env;
    (void) thiz;
    if (pid <= 0) {
        return JNI_FALSE;
    }
    if (kill((pid_t) pid, 0) == 0) {
        return JNI_TRUE;
    }
    /* EPERM means the process exists but we may not signal it. */
    return errno == EPERM ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jstring JNICALL
Java_com_codespace_ide_PtyNative_lastError(
        JNIEnv* env, jobject thiz) {
    (void) thiz;
    char msg[256];
    int e = pty_get_errno();
    if (!e) {
        e = errno;
    }
    if (strerror_r(e, msg, sizeof(msg)) != 0) {
        snprintf(msg, sizeof(msg), "errno %d", e);
    }
    return (*env)->NewStringUTF(env, msg);
}

#endif /* __ANDROID__ */

/* ==================== on-device test harness ==================== */

#ifdef PTY_TEST_MAIN
#include <stdio.h>
#include <time.h>

static long now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (long) ts.tv_sec * 1000L + (long) ts.tv_nsec / 1000000L;
}

/* Drain master until EOF or deadline; prints everything to stdout. */
static void drain_until_eof(int master, long deadline_ms) {
    char buf[4096];
    while (now_ms() < deadline_ms) {
        struct pollfd pfd;
        pfd.fd = master;
        pfd.events = POLLIN;
        pfd.revents = 0;
        int pr = poll(&pfd, 1, 200);
        if (pr <= 0) {
            if (pr < 0 && errno != EINTR) {
                break;
            }
            continue;
        }
        ssize_t n = read(master, buf, sizeof(buf));
        if (n <= 0) {
            break;
        }
        fwrite(buf, 1, (size_t) n, stdout);
        fflush(stdout);
    }
}

static void msleep(long ms) {
    struct timespec ts;
    ts.tv_sec = ms / 1000;
    ts.tv_nsec = (ms % 1000) * 1000000L;
    nanosleep(&ts, NULL);
}

int main(void) {
    /* Interactive mksh: exercises spawn, write, read, resize, exit code. */
    char* const child_argv[] = { (char*) "/system/bin/sh", (char*) "-i", NULL };
    char* const child_envp[] = {
        (char*) "PATH=/system/bin:/vendor/bin",
        (char*) "TERM=xterm-256color",
        (char*) "HOME=/",
        NULL
    };

    int master = -1;
    pid_t pid = -1;
    if (pty_spawn(child_argv, child_envp, 24, 80, &master, &pid) != 0) {
        fprintf(stderr, "SPAWN FAILED errno=%d\n", pty_get_errno());
        return 2;
    }
    printf("SPAWN OK master=%d pid=%d\n", master, (int) pid);
    fflush(stdout);

    msleep(500);
    const char* c1 = "stty size; tty\n";
    (void) write(master, c1, strlen(c1));
    msleep(500);

    /* Runtime resize: TIOCSWINSZ on the master, like the app will do. */
    {
        struct winsize ws;
        memset(&ws, 0, sizeof(ws));
        ws.ws_row = 30;
        ws.ws_col = 100;
        if (ioctl(master, TIOCSWINSZ, &ws) != 0) {
            printf("RESIZE FAILED errno=%d\n", errno);
        } else {
            printf("RESIZE OK 30x100\n");
        }
        fflush(stdout);
    }
    const char* c2 = "stty size\n"
                     "test -t 0 && echo STDIN_TTY || echo STDIN_NOTTY\n"
                     "test -t 1 && echo STDOUT_TTY || echo STDOUT_NOTTY\n"
                     "test -t 2 && echo STDERR_TTY || echo STDERR_NOTTY\n"
                     "sleep 3 &\n"
                     "jobs\n"
                     "wait\n"
                     "exit 42\n";
    (void) write(master, c2, strlen(c2));

    drain_until_eof(master, now_ms() + 15000);

    int status = 0;
    while (waitpid(pid, &status, 0) < 0 && errno == EINTR) {
    }
    printf("CHILD_REAPED code=%d\n", pty_decode_status(status));
    close(master);
    return 0;
}
#endif /* PTY_TEST_MAIN */
