#!/data/data/com.termux/files/usr/bin/bash
# Builds the runtime-key native bridge (arm64, minSdk 30).
# Run in Termux on an ARM64 device with clang installed (same as build.sh).
# The resulting libkeybridge.so is shipped prebuilt in
#   app/src/main/jniLibs/arm64-v8a/
set -euo pipefail
cd "$(dirname "$0")"

TARGET="aarch64-linux-android30"

echo "== JNI shared library =="
clang --target="$TARGET" -O2 -fPIC -shared -o libkeybridge.so key_bridge.c

echo "== ELF checks =="
readelf -h libkeybridge.so | grep -E "Machine|Class"
echo "-- DT_NEEDED (must be system libs only) --"
readelf -d libkeybridge.so | grep -E "NEEDED" || echo "(no DT_NEEDED)"
echo "-- JNI symbols --"
nm -D --defined-only libkeybridge.so | grep "Java_com_codespace_ide" || {
    echo "ERROR: no JNI symbols exported"
    exit 1
}

echo "== installing into jniLibs =="
cp -f libkeybridge.so ../app/src/main/jniLibs/arm64-v8a/libkeybridge.so
ls -lh ../app/src/main/jniLibs/arm64-v8a/
echo DONE
